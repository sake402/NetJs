
//--TRIMMABLE-BOUNDARY-START(14)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Collections.Concurrent", 
    {
  "h": 14,
  "f": "System.Collections.Concurrent",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Collections.Concurrent",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Collections.Concurrent",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(2949134)
        $asm.$cls(`$scc.SCC.Partitioner<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner<>`, [TSource], ($self) => class Partitioner$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25772752910)
            /*bool */ get SupportsDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887851022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25772752910)
            
            //--TRIMMABLE-BOUNDARY-START(17182818318)
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(17182818318)
            
            //--TRIMMABLE-BOUNDARY-START(4297916430)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4297916430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297916430)
            
            //--TRIMMABLE-BOUNDARY-START(4297916430)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4297916430)
            
            static $H = 2949134;
            static $h = 2949134;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772752910),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 12887851022,
        "h": Number(BigInt(this.$h)|0x300000000n),
        "f": 50331777
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "H": 25772752910,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25772752910)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477785614),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$(TSource)).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetPartitions",
      "d": this.$h,
      "H": 21477785614,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21477785614),
//--TRIMMABLE-BOUNDARY-START(17182818318),
    {
      "r": $.$$.SCG.IEnumerable$$(TSource).$h,
      "n": "GetDynamicPartitions",
      "d": this.$h,
      "H": 17182818318,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182818318)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916430),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 4297916430,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297916430)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "H": 2949134,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner<${TSource?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner$${TSource?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2949134)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310734)
        $asm.$cls(`$scc.SCC.OrderablePartitioner<>`, (TSource) => $asm.$gt(`$scc.SCC.OrderablePartitioner<>`, [TSource], ($self) => class OrderablePartitioner$$ extends $.$scc.SCC.Partitioner$$(TSource)
        {
            //--TRIMMABLE-BOUNDARY-START(17181179918)
            $ctor$2(/*bool*/ keysOrderedInEachPartition, /*bool*/ keysOrderedAcrossPartitions, /*bool*/ keysNormalized)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181179918);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.KeysOrderedInEachPartition = keysOrderedInEachPartition;
                    this.KeysOrderedAcrossPartitions = keysOrderedAcrossPartitions;
                    this.KeysNormalized = keysNormalized;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181179918)
            
            //--TRIMMABLE-BOUNDARY-START(51540918286)
            /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(51540918286)
            
            //--TRIMMABLE-BOUNDARY-START(73015754766)
            /*bool*/ KeysOrderedInEachPartition = false;
            //--TRIMMABLE-BOUNDARY-END(73015754766)
            
            //--TRIMMABLE-BOUNDARY-START(68720787470)
            /*bool*/ KeysOrderedAcrossPartitions = false;
            //--TRIMMABLE-BOUNDARY-END(68720787470)
            
            //--TRIMMABLE-BOUNDARY-START(64425820174)
            /*bool*/ KeysNormalized = false;
            //--TRIMMABLE-BOUNDARY-END(64425820174)
            
            //--TRIMMABLE-BOUNDARY-START(60130852878)
            /*IList<IEnumerator<TSource>> */ GetPartitions(/*int*/ partitionCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IList<IEnumerator<KeyValuePair<long, TSource>>>*/ let orderablePartitions = this.GetOrderablePartitions(partitionCount);
                if (orderablePartitions.SCG$ICollection$$$Count !== partitionCount)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12("OrderablePartitioner_GetPartitions_WrongNumberOfPartitions");
                }
                /*IEnumerator<TSource>[]*/ let partitions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.IEnumerator$$(TSource)), null, [partitionCount], null);
                for(/*int*/ let i = 0; i < partitionCount; i++)
                {
                    $.$$.System.Array.$WriteT1.call(partitions, new ($.$scc.SCC.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(orderablePartitions.SCG$IList$$$get_Item(i)), i);
                }
                return partitions;
            }
            //--TRIMMABLE-BOUNDARY-END(60130852878)
            
            //--TRIMMABLE-BOUNDARY-START(47245950990)
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245950990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<KeyValuePair<long, TSource>>*/ let orderablePartitions = this.GetOrderableDynamicPartitions();
                return new ($.$scc.SCC.OrderablePartitioner$$(TSource).EnumerableDropIndices)().$ctor$1(orderablePartitions);
            }
            //--TRIMMABLE-BOUNDARY-END(47245950990)
            
            //--TRIMMABLE-BOUNDARY-START(1376270)
            static $_EnumerableDropIndices;
            static get EnumerableDropIndices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.OrderablePartitioner$$(TSource);
                return $cls.$_EnumerableDropIndices ??= $asm.$ncls(`$scc.SCC.OrderablePartitioner<${TSource?.$fullName}>.EnumerableDropIndices`, ($self) => class EnumerableDropIndices extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296343566)
                    /*IEnumerable<KeyValuePair<long, TSource>>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296343566)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591310862)
                    $ctor$1(/*IEnumerable<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591310862);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591310862)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245454)
                    /*IEnumerator<TSource> */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181245454);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(this._source.SCG$IEnumerable$$$GetEnumerator());
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181245454)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476212750)
                    /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476212750);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476212750)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278158)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886278158);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        ($.$as(this._source, $.$$.S.IDisposable))?.S$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886278158)
                    
                    //--TRIMMABLE-BOUNDARY-START(4355325953)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TSource>.GetEnumerator()
                    SCG$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355325953);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4355325953)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $H = 1376270;
                    static $h = 1376270;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181245454),
    {
      "r": $.$$.SCG.IEnumerator$$(TSource).$h,
      "n": "GetEnumerator",
      "d": 1376270,
      "H": 17181245454,
      "h": Number(BigInt(1376270)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181245454),
//--TRIMMABLE-BOUNDARY-START(12886278158),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1376270,
      "H": 12886278158,
      "h": Number(BigInt(1376270)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886278158)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343566),
    {
      "t": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "_source",
      "d": 1376270,
      "H": 4296343566,
      "h": Number(BigInt(1376270)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343566)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310862),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376270,
      "H": 8591310862,
      "h": Number(BigInt(1376270)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310862)
  ],
  "d": 1310734,
  "H": 1376270,
  "h": 1376270
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$(TSource), $.$$.SC$1.IEnumerable, $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>+EnumerableDropIndices`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}OrderablePartitioner$${TSource?.$getFullName(separator)}$${separator}EnumerableDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumerableDropIndices = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376270)
            
            //--TRIMMABLE-BOUNDARY-START(1441806)
            static $_EnumeratorDropIndices;
            static get EnumeratorDropIndices()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.OrderablePartitioner$$(TSource);
                return $cls.$_EnumeratorDropIndices ??= $asm.$ncls(`$scc.SCC.OrderablePartitioner<${TSource?.$fullName}>.EnumeratorDropIndices`, ($self) => class EnumeratorDropIndices extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296409102)
                    /*IEnumerator<KeyValuePair<long, TSource>>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296409102)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591376398)
                    $ctor$1(/*IEnumerator<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591376398);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591376398)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066212878)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066212878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._source.SC$1$IEnumerator$MoveNext();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066212878)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886343694)
                    /*TSource */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771245582);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._source.SCG$IEnumerator$$$Current.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886343694)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656147470)
                    /*object? */ get SC$1$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246082062);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$box((this).Current, TSource);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656147470)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181310990)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181310990);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._source.S$IDisposable$Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181310990)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361180174)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361180174);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._source.SC$1$IEnumerator$Reset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361180174)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TSource>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    static $H = 1441806;
                    static $h = 1441806;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886343694),
    {
      "p": TSource?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25771245582,
        "h": Number(BigInt(1441806)|0x600000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 1441806,
      "H": 12886343694,
      "h": Number(BigInt(1441806)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886343694),
//--TRIMMABLE-BOUNDARY-START(38656147470),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246082062,
        "h": Number(BigInt(1441806)|0xB00000000n),
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 1441806,
      "H": 38656147470,
      "h": Number(BigInt(1441806)|0x900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38656147470)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066212878),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1441806,
      "H": 30066212878,
      "h": Number(BigInt(1441806)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066212878),
//--TRIMMABLE-BOUNDARY-START(17181310990),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1441806,
      "H": 17181310990,
      "h": Number(BigInt(1441806)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181310990),
//--TRIMMABLE-BOUNDARY-START(34361180174),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1441806,
      "H": 34361180174,
      "h": Number(BigInt(1441806)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361180174)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409102),
    {
      "t": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "_source",
      "d": 1441806,
      "H": 4296409102,
      "h": Number(BigInt(1441806)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409102)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376398),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441806,
      "H": 8591376398,
      "h": Number(BigInt(1441806)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376398)
  ],
  "d": 1310734,
  "H": 1441806,
  "h": 1441806
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$(TSource), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>+EnumeratorDropIndices`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}OrderablePartitioner$${TSource?.$getFullName(separator)}$${separator}EnumeratorDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumeratorDropIndices = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1441806)
            
            static $H = 1310734;
            static $h = 1310734;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner$$(TSource); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015754766),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950983694,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "KeysOrderedInEachPartition",
      "d": this.$h,
      "H": 73015754766,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015754766),
//--TRIMMABLE-BOUNDARY-START(68720787470),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34361049102,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "KeysOrderedAcrossPartitions",
      "d": this.$h,
      "H": 68720787470,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720787470),
//--TRIMMABLE-BOUNDARY-START(64425820174),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25771114510,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "KeysNormalized",
      "d": this.$h,
      "H": 64425820174,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425820174)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835885582),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "H": 55835885582,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55835885582),
//--TRIMMABLE-BOUNDARY-START(51540918286),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "H": 51540918286,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540918286),
//--TRIMMABLE-BOUNDARY-START(60130852878),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$(TSource)).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetPartitions",
      "d": this.$h,
      "H": 60130852878,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130852878),
//--TRIMMABLE-BOUNDARY-START(47245950990),
    {
      "r": $.$$.SCG.IEnumerable$$(TSource).$h,
      "n": "GetDynamicPartitions",
      "d": this.$h,
      "H": 47245950990,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245950990)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181179918),
    {
      "p": [
        {
          "n": "keysOrderedInEachPartition",
          "p": 262145
        },
        {
          "n": "keysOrderedAcrossPartitions",
          "p": 262145
        },
        {
          "n": "keysNormalized",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 17181179918,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17181179918)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "H": 1310734,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$scc.SCC.OrderablePartitioner$$(TSource).EnumerableDropIndices, $.$scc.SCC.OrderablePartitioner$$(TSource).EnumeratorDropIndices ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}OrderablePartitioner$${TSource?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310734)
        
        

        //--TRIMMABLE-BOUNDARY-START(3145742)
        $asm.$cls(`$scc.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(523989155854)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(523989155854)
            
            //--TRIMMABLE-BOUNDARY-START(493924384782)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(493924384782);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(493924384782)
            
            //--TRIMMABLE-BOUNDARY-START(536874057742)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536874057742);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scc.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(536874057742)
            
            //--TRIMMABLE-BOUNDARY-START(489629417486)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489629417486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scc.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(489629417486)
            
            //--TRIMMABLE-BOUNDARY-START(485334450190)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485334450190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scc.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(485334450190)
            
            //--TRIMMABLE-BOUNDARY-START(167506870286)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506870286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(167506870286)
            
            //--TRIMMABLE-BOUNDARY-START(163211902990)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211902990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(163211902990)
            
            //--TRIMMABLE-BOUNDARY-START(158916935694)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916935694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(158916935694)
            
            //--TRIMMABLE-BOUNDARY-START(171801837582)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171801837582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scc.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(171801837582)
            
            //--TRIMMABLE-BOUNDARY-START(150327001102)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327001102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(150327001102)
            
            //--TRIMMABLE-BOUNDARY-START(146032033806)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032033806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(146032033806)
            
            //--TRIMMABLE-BOUNDARY-START(141737066510)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737066510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(141737066510)
            
            //--TRIMMABLE-BOUNDARY-START(154621968398)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621968398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scc.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(154621968398)
            
            //--TRIMMABLE-BOUNDARY-START(519694188558)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(519694188558)
            
            //--TRIMMABLE-BOUNDARY-START(511104253966)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(511104253966)
            
            //--TRIMMABLE-BOUNDARY-START(515399221262)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481039482894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$scc.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Collections.Concurrent", $.$scc.S.SR.$type.Assembly);
                    $.$scc.S.SR.s_resourceManager = temp;
                }
                return $.$scc.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(515399221262)
            
            //--TRIMMABLE-BOUNDARY-START(137442099214)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679744526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532579090446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(137442099214)
            
            //--TRIMMABLE-BOUNDARY-START(17183014926)
            static /*string */ get BlockingCollection_Add_ConcurrentCompleteAdd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161575950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "CompleteAdding may not be used concurrently with additions to the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183014926)
            
            //--TRIMMABLE-BOUNDARY-START(21477982222)
            static /*string */ get BlockingCollection_Add_Failed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751510542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying collection didn't accept the item.";
            }
            //--TRIMMABLE-BOUNDARY-END(21477982222)
            
            //--TRIMMABLE-BOUNDARY-START(25772949518)
            static /*string */ get BlockingCollection_CantAddAnyWhenCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341445134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "At least one of the specified collections is marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(25772949518)
            
            //--TRIMMABLE-BOUNDARY-START(30067916814)
            static /*string */ get BlockingCollection_CantTakeAnyWhenAllDone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931379726);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "All collections are marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(30067916814)
            
            //--TRIMMABLE-BOUNDARY-START(34362884110)
            static /*string */ get BlockingCollection_CantTakeWhenDone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240521314318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection argument is empty and has been marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(34362884110)
            
            //--TRIMMABLE-BOUNDARY-START(38657851406)
            static /*string */ get BlockingCollection_Completed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111248910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection has been marked as complete with regards to additions.";
            }
            //--TRIMMABLE-BOUNDARY-END(38657851406)
            
            //--TRIMMABLE-BOUNDARY-START(42952818702)
            static /*string */ get BlockingCollection_CopyTo_IncorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257701183502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array argument is of the incorrect type.";
            }
            //--TRIMMABLE-BOUNDARY-END(42952818702)
            
            //--TRIMMABLE-BOUNDARY-START(47247785998)
            static /*string */ get BlockingCollection_CopyTo_MultiDim()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291118094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array argument is multidimensional.";
            }
            //--TRIMMABLE-BOUNDARY-END(47247785998)
            
            //--TRIMMABLE-BOUNDARY-START(51542753294)
            static /*string */ get BlockingCollection_CopyTo_NonNegative()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881052686);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The index argument must be greater than or equal zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(51542753294)
            
            //--TRIMMABLE-BOUNDARY-START(85902491662)
            static /*string */ get Collection_CopyTo_TooManyElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343600529422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The number of elements in the collection is greater than the available space from index to the end of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(85902491662)
            
            //--TRIMMABLE-BOUNDARY-START(55837720590)
            static /*string */ get BlockingCollection_ctor_CountMoreThanCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283470987278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection argument contains more items than are allowed by the boundedCapacity.";
            }
            //--TRIMMABLE-BOUNDARY-END(55837720590)
            
            //--TRIMMABLE-BOUNDARY-START(60132687886)
            static /*string */ get BlockingCollection_Take_CollectionModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060921870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The underlying collection was modified from outside of the BlockingCollection<T>.";
            }
            //--TRIMMABLE-BOUNDARY-END(60132687886)
            
            //--TRIMMABLE-BOUNDARY-START(64427655182)
            static /*string */ get BlockingCollection_TimeoutInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300650856462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified timeout must represent a value between -1 and {0}, inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(64427655182)
            
            //--TRIMMABLE-BOUNDARY-START(180391772174)
            static /*string */ FormatBlockingCollection_TimeoutInvalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391772174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The specified timeout must represent a value between -1 and {0}, inclusive.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(180391772174)
            
            //--TRIMMABLE-BOUNDARY-START(68722622478)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_DispElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240791054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument contains at least one disposed element.";
            }
            //--TRIMMABLE-BOUNDARY-END(68722622478)
            
            //--TRIMMABLE-BOUNDARY-START(73017589774)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_LargeSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830725646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections length is greater than the supported range.";
            }
            //--TRIMMABLE-BOUNDARY-END(73017589774)
            
            //--TRIMMABLE-BOUNDARY-START(77312557070)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_NullElems()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326420660238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument contains at least one null element.";
            }
            //--TRIMMABLE-BOUNDARY-END(77312557070)
            
            //--TRIMMABLE-BOUNDARY-START(81607524366)
            static /*string */ get BlockingCollection_ValidateCollectionsArray_ZeroSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335010594830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collections argument is a zero-length array.";
            }
            //--TRIMMABLE-BOUNDARY-END(81607524366)
            
            //--TRIMMABLE-BOUNDARY-START(94492426254)
            static /*string */ get ConcurrentCollection_SyncRoot_NotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780398606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The SyncRoot property may not be used for the synchronization of concurrent collections.";
            }
            //--TRIMMABLE-BOUNDARY-END(94492426254)
            
            //--TRIMMABLE-BOUNDARY-START(98787393550)
            static /*string */ get ConcurrentDictionary_ArrayIncorrectType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370333198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The array is multidimensional, or the type parameter for the set cannot be cast automatically to the type of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(98787393550)
            
            //--TRIMMABLE-BOUNDARY-START(120262230030)
            static /*string */ get ConcurrentDictionary_SourceContainsDuplicateKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320006158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The source argument contains duplicate keys.";
            }
            //--TRIMMABLE-BOUNDARY-END(120262230030)
            
            //--TRIMMABLE-BOUNDARY-START(107377328142)
            static /*string */ get ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386550202382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The concurrencyLevel argument must be positive, or -1 to indicate a default level.";
            }
            //--TRIMMABLE-BOUNDARY-END(107377328142)
            
            //--TRIMMABLE-BOUNDARY-START(103082360846)
            static /*string */ get ConcurrentDictionary_ArrayNotLargeEnough()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377960267790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The index is equal to or greater than the length of the array, or the number of elements in the dictionary is greater than the available space from index to the end of the destination array.";
            }
            //--TRIMMABLE-BOUNDARY-END(103082360846)
            
            //--TRIMMABLE-BOUNDARY-START(115967262734)
            static /*string */ get ConcurrentDictionary_KeyAlreadyExisted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730071566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key already existed in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(115967262734)
            
            //--TRIMMABLE-BOUNDARY-START(111672295438)
            static /*string */ get ConcurrentDictionary_ItemKeyIsNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140136974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "TKey is a reference type and item.Key is null.";
            }
            //--TRIMMABLE-BOUNDARY-END(111672295438)
            
            //--TRIMMABLE-BOUNDARY-START(124557197326)
            static /*string */ get ConcurrentDictionary_TypeOfKeyIncorrect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420909940750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key was of an incorrect type for this dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(124557197326)
            
            //--TRIMMABLE-BOUNDARY-START(128852164622)
            static /*string */ get ConcurrentDictionary_TypeOfValueIncorrect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429499875342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value was of an incorrect type for this dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(128852164622)
            
            //--TRIMMABLE-BOUNDARY-START(133147131918)
            static /*string */ get ConcurrentStack_PushPopRange_InvalidCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438089809934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The sum of the startIndex and count arguments must be less than or equal to the collection's Count.";
            }
            //--TRIMMABLE-BOUNDARY-END(133147131918)
            
            //--TRIMMABLE-BOUNDARY-START(502514319374)
            static /*string */ get Partitioner_DynamicPartitionsNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463859613710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Dynamic partitions are not supported by this partitioner.";
            }
            //--TRIMMABLE-BOUNDARY-END(502514319374)
            
            //--TRIMMABLE-BOUNDARY-START(506809286670)
            static /*string */ get PartitionerStatic_CurrentCalledBeforeMoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472449548302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MoveNext must be called at least once before calling Current.";
            }
            //--TRIMMABLE-BOUNDARY-END(506809286670)
            
            //--TRIMMABLE-BOUNDARY-START(90197458958)
            static /*string */ get ConcurrentBag_Enumerator_EnumerationNotStartedOrAlreadyFinished()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190464014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has either not started or has already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(90197458958)
            
            //--TRIMMABLE-BOUNDARY-START(12888047630)
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571641358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given key '{0}' was not present in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888047630)
            
            //--TRIMMABLE-BOUNDARY-START(176096804878)
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176096804878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176096804878)
            
            //--TRIMMABLE-BOUNDARY-START(8593080334)
            static /*string */ get Arg_HTCapacityOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188981706766);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593080334)
            
            //--TRIMMABLE-BOUNDARY-START(498219352078)
            static /*string */ get InvalidOperation_IncompatibleComparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455269679118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The collection's comparer does not support the requested operation.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219352078)
            
            //--TRIMMABLE-BOUNDARY-START(4298113038)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298113038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(523989155854)
                    this.s_usingResourceKeys = $.$scc.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(523989155854)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298113038)
            
            static $h = 3145742;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 3145742
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3145742)
        
        

        //--TRIMMABLE-BOUNDARY-START(3080206)
        $asm.$cls(`$scc.SC.HashHelpers`, ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(30067851278)
            /*uint*/ static HashCollisionThreshold = 100;
            //--TRIMMABLE-BOUNDARY-END(30067851278)
            
            //--TRIMMABLE-BOUNDARY-START(42952753166)
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            //--TRIMMABLE-BOUNDARY-END(42952753166)
            
            //--TRIMMABLE-BOUNDARY-START(34362818574)
            /*int*/ static HashPrime = 101;
            //--TRIMMABLE-BOUNDARY-END(34362818574)
            
            //--TRIMMABLE-BOUNDARY-START(47247720462)
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.S.ReadOnlySpan$$($.$$.S.Int32))().$ctor$7([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(47247720462)
            
            //--TRIMMABLE-BOUNDARY-START(38657785870)
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657785870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.S.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            //--TRIMMABLE-BOUNDARY-END(38657785870)
            
            //--TRIMMABLE-BOUNDARY-START(25772883982)
            static /*int */ GetPrime(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772883982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (min < 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.Arg_HTCapacityOverflow);
                }
                let $en1 = $.$scc.SC.HashHelpers.Primes.GetEnumerator();
                while ($en1.MoveNext())
                {
                    let prime = $en1.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$scc.SC.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            //--TRIMMABLE-BOUNDARY-END(25772883982)
            
            //--TRIMMABLE-BOUNDARY-START(4298047502)
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298047502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.SD.Debug.Assert$4(2147483587/*MaxPrimeArrayLength*/ === $.$scc.SC.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$scc.SC.HashHelpers.GetPrime(newSize);
            }
            //--TRIMMABLE-BOUNDARY-END(4298047502)
            
            //--TRIMMABLE-BOUNDARY-START(21477916686)
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477916686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return BigInt.asUintN(64, 18446744073709551615n / BigInt(divisor) + 1n);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21477916686)
            
            //--TRIMMABLE-BOUNDARY-START(8593014798)
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593014798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast(((BigInt.asUintN(64, (BigInt.asUintN(64, ((BigInt.asUintN(64, multiplier * BigInt(value))) >> 32n) + 1n)) * BigInt(divisor))) >> 32n), $.$$.S.UInt32);
                $.$$.SD.Debug.Assert$4(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            //--TRIMMABLE-BOUNDARY-END(8593014798)
            
            static $h = 3080206;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247720462),
    {
      "p": $.$$.S.ReadOnlySpan$$($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182949390,
        "f": 50331688
      },
      "n": "Primes",
      "d": 3080206,
      "h": 47247720462,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(47247720462)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38657785870),
    {
      "r": 262145,
      "p": [
        {
          "n": "candidate",
          "p": 655361
        }
      ],
      "n": "IsPrime",
      "d": 3080206,
      "h": 38657785870,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38657785870),
//--TRIMMABLE-BOUNDARY-START(25772883982),
    {
      "r": 655361,
      "p": [
        {
          "n": "min",
          "p": 655361
        }
      ],
      "n": "GetPrime",
      "d": 3080206,
      "h": 25772883982,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25772883982),
//--TRIMMABLE-BOUNDARY-START(4298047502),
    {
      "r": 655361,
      "p": [
        {
          "n": "oldSize",
          "p": 655361
        }
      ],
      "n": "ExpandPrime",
      "d": 3080206,
      "h": 4298047502,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4298047502),
//--TRIMMABLE-BOUNDARY-START(21477916686),
    {
      "r": 983041,
      "p": [
        {
          "n": "divisor",
          "p": 720897
        }
      ],
      "n": "GetFastModMultiplier",
      "d": 3080206,
      "h": 21477916686,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21477916686),
//--TRIMMABLE-BOUNDARY-START(8593014798),
    {
      "r": 720897,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "divisor",
          "p": 720897
        },
        {
          "n": "multiplier",
          "p": 983041
        }
      ],
      "n": "FastMod",
      "d": 3080206,
      "h": 8593014798,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8593014798)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(30067851278),
    {
      "t": 720897,
      "n": "HashCollisionThreshold",
      "d": 3080206,
      "h": 30067851278,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30067851278),
//--TRIMMABLE-BOUNDARY-START(42952753166),
    {
      "t": 655361,
      "n": "MaxPrimeArrayLength",
      "d": 3080206,
      "h": 42952753166,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42952753166),
//--TRIMMABLE-BOUNDARY-START(34362818574),
    {
      "t": 655361,
      "n": "HashPrime",
      "d": 3080206,
      "h": 34362818574,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34362818574)
  ],
  "h": 3080206
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.HashHelpers`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3080206)
        
        

        //--TRIMMABLE-BOUNDARY-START(3211278)
        $asm.$cls(`$scc.S.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17183080462)
            static /*void */ ThrowKeyNullException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183080462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183080462)
            
            //--TRIMMABLE-BOUNDARY-START(8593145870)
            static /*void */ ThrowArgumentNullException$1(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593145870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.ArgumentNullException().$ctor$19(name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593145870)
            
            //--TRIMMABLE-BOUNDARY-START(4298178574)
            static /*void */ ThrowArgumentNullException(/*string*/ name, /*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298178574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.ArgumentNullException().$ctor$18(name, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298178574)
            
            //--TRIMMABLE-BOUNDARY-START(25773015054)
            static /*void */ ThrowValueNullException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773015054);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_TypeOfValueIncorrect);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773015054)
            
            //--TRIMMABLE-BOUNDARY-START(21478047758)
            static /*void */ ThrowOutOfMemoryException()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478047758);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.OutOfMemoryException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478047758)
            
            //--TRIMMABLE-BOUNDARY-START(12888113166)
            static /*void */ ThrowIncompatibleComparer()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888113166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.InvalidOperation_IncompatibleComparer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888113166)
            
            static $h = 3211278;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17183080462),
    {
      "r": 65537,
      "n": "ThrowKeyNullException",
      "d": 3211278,
      "h": 17183080462,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17183080462),
//--TRIMMABLE-BOUNDARY-START(8593145870),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "ThrowArgumentNullException",
      "o": "@$1",
      "d": 3211278,
      "h": 8593145870,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593145870),
//--TRIMMABLE-BOUNDARY-START(4298178574),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 3211278,
      "h": 4298178574,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4298178574),
//--TRIMMABLE-BOUNDARY-START(25773015054),
    {
      "r": 65537,
      "n": "ThrowValueNullException",
      "d": 3211278,
      "h": 25773015054,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25773015054),
//--TRIMMABLE-BOUNDARY-START(21478047758),
    {
      "r": 65537,
      "n": "ThrowOutOfMemoryException",
      "d": 3211278,
      "h": 21478047758,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21478047758),
//--TRIMMABLE-BOUNDARY-START(12888113166),
    {
      "r": 65537,
      "n": "ThrowIncompatibleComparer",
      "d": 3211278,
      "h": 12888113166,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12888113166)
  ],
  "h": 3211278
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211278)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245198)
        $asm.$cls(`$scc.SCC.IProducerConsumerCollectionDebugView<>`, (T) => $asm.$gt(`$scc.SCC.IProducerConsumerCollectionDebugView<>`, [T], ($self) => class IProducerConsumerCollectionDebugView$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296212494)
            /*IProducerConsumerCollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4296212494)
            
            //--TRIMMABLE-BOUNDARY-START(8591179790)
            $ctor$1(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179790);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179790)
            
            //--TRIMMABLE-BOUNDARY-START(21476081678)
            /*T[] */ get Items()
            {
                return this._collection.SCC$1$IProducerConsumerCollection$$$ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(21476081678)
            
            static $H = 1245198;
            static $h = 1245198;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476081678),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17181114382,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 21476081678,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476081678)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296212494),
    {
      "t": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h,
      "n": "_collection",
      "d": this.$h,
      "H": 4296212494,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296212494)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179790),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8591179790,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179790)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 1245198,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.IProducerConsumerCollectionDebugView<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}IProducerConsumerCollectionDebugView$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1245198)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507342)
        $asm.$cls(`$scc.SCC.Partitioner`, ($self) => class Partitioner
        {
            //--TRIMMABLE-BOUNDARY-START(4296474638)
            /*int*/ static CoreOversubscriptionRate = 3;
            //--TRIMMABLE-BOUNDARY-END(4296474638)
            
            //--TRIMMABLE-BOUNDARY-START(34361245710)
            static /*OrderablePartitioner<TSource> */ Create$6(TSource, /*IList<TSource>*/ list, /*bool*/ loadBalance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(list, "list");
                if (loadBalance)
                {
                    return (new ($.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource))().$ctor$4(list));
                }
                else 
                {
                    return (new ($.$scc.SCC.Partitioner.StaticIndexRangePartitionerForIList$$(TSource))().$ctor$4(list));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361245710)
            
            //--TRIMMABLE-BOUNDARY-START(38656213006)
            static /*OrderablePartitioner<TSource> */ Create$7(TSource, /*TSource[]*/ array, /*bool*/ loadBalance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (loadBalance)
                {
                    return (new ($.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource))().$ctor$4(array));
                }
                else 
                {
                    return (new ($.$scc.SCC.Partitioner.StaticIndexRangePartitionerForArray$$(TSource))().$ctor$4(array));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656213006)
            
            //--TRIMMABLE-BOUNDARY-START(30066278414)
            static /*OrderablePartitioner<TSource> */ Create$5(TSource, /*IEnumerable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066278414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.Partitioner.Create$4(TSource, source, 0/*EnumerablePartitionerOptions.None*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30066278414)
            
            //--TRIMMABLE-BOUNDARY-START(25771311118)
            static /*OrderablePartitioner<TSource> */ Create$4(TSource, /*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                if ((partitionerOptions & (~1/*EnumerablePartitionerOptions.NoBuffering*/)) !== 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("partitionerOptions");
                }
                return (new ($.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource))().$ctor$3(source, partitionerOptions));
            }
            //--TRIMMABLE-BOUNDARY-END(25771311118)
            
            //--TRIMMABLE-BOUNDARY-START(21476343822)
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$3(/*long*/ fromInclusive, /*long*/ toExclusive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476343822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.S.Int64, toExclusive, fromInclusive, "toExclusive");
                /*decimal*/ let range = BigInt.asIntN(64, $.$$.S.Decimal.op_Implicit$4(toExclusive) - $.$$.S.Decimal.op_Implicit$4(fromInclusive));
                /*long*/ let rangeSize = $.$$.S.Decimal.op_Explicit$5(($.$$.S.Decimal.op_Division(range, $.$$.S.Decimal.op_Implicit$3((($.$$.S.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/) | 0)))));
                if (rangeSize === 0n)
                {
                    rangeSize = 1n;
                }
                return $.$scc.SCC.Partitioner.Create$4($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64), $.$scc.SCC.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21476343822)
            
            //--TRIMMABLE-BOUNDARY-START(17181376526)
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$2(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.S.Int64, toExclusive, fromInclusive, "toExclusive");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int64, rangeSize, "rangeSize");
                return $.$scc.SCC.Partitioner.Create$4($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64), $.$scc.SCC.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17181376526)
            
            //--TRIMMABLE-BOUNDARY-START(47246147598)
            static /*IEnumerable<Tuple<long, long>> */ CreateRanges$1(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64)))().$ctor$1(function*()
                {
                    /*long*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*long*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = BigInt.asIntN(64, i + rangeSize))
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = BigInt.asIntN(64, i + rangeSize);
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(47246147598)
            
            //--TRIMMABLE-BOUNDARY-START(12886409230)
            static /*OrderablePartitioner<Tuple<int, int>> */ Create$1(/*int*/ fromInclusive, /*int*/ toExclusive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886409230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.S.Int32, toExclusive, fromInclusive, "toExclusive");
                /*long*/ let range = BigInt.asIntN(64, $.$cast(toExclusive, $.$$.S.Int64) - BigInt(fromInclusive));
                /*int*/ let rangeSize = $.$cast((range / BigInt($.$$.S.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/)), $.$$.S.Int32);
                if (rangeSize === 0)
                {
                    rangeSize = 1;
                }
                return $.$scc.SCC.Partitioner.Create$4($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$scc.SCC.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(12886409230)
            
            //--TRIMMABLE-BOUNDARY-START(8591441934)
            static /*OrderablePartitioner<Tuple<int, int>> */ Create(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591441934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.S.Int32, toExclusive, fromInclusive, "toExclusive");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, rangeSize, "rangeSize");
                return $.$scc.SCC.Partitioner.Create$4($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32), $.$scc.SCC.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8591441934)
            
            //--TRIMMABLE-BOUNDARY-START(42951180302)
            static /*IEnumerable<Tuple<int, int>> */ CreateRanges(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                return new ($.$$.N.YieldToIterator$$($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32)))().$ctor$1(function*()
                {
                    /*int*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*int*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = ((i + rangeSize) | 0))
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = $.$checked(i + rangeSize, 1);
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(42951180302)
            
            //--TRIMMABLE-BOUNDARY-START(1572878)
            static $_DynamicPartitionEnumerator_Abstract$$$;
            static DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionEnumerator_Abstract$$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract<,>`, (TSource, TSourceReader) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract<,>`, [TSource, TSourceReader], ($self) => class DynamicPartitionEnumerator_Abstract$$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(25771376654)
                    /*TSourceReader*/ _sharedReader = $.$default(TSourceReader);
                    //--TRIMMABLE-BOUNDARY-END(25771376654)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195886094)
                    /*int*/ static s_defaultMaxChunkSize = 0;
                    //--TRIMMABLE-BOUNDARY-END(90195886094)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296540174)
                    /*StrongBox<int>?*/ _currentChunkSize = null;
                    //--TRIMMABLE-BOUNDARY-END(4296540174)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886474766)
                    /*StrongBox<int>?*/ _localOffset = null;
                    //--TRIMMABLE-BOUNDARY-END(12886474766)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951245838)
                    /*int*/ static CHUNK_DOUBLING_RATE = 3;
                    //--TRIMMABLE-BOUNDARY-END(42951245838)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591507470)
                    /*int*/ _doublingCountdown = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591507470)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181442062)
                    /*int*/ _maxChunkSize = 0;
                    //--TRIMMABLE-BOUNDARY-END(17181442062)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476409358)
                    /*SharedLong*/ _sharedIndex = null;
                    //--TRIMMABLE-BOUNDARY-END(21476409358)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656278542)
                    $ctor$2(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        this.$ctor$1(sharedReader, sharedIndex, false);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38656278542);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656278542)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361311246)
                    $ctor$1(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex, /*bool*/ useSingleChunking)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361311246);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sharedReader = sharedReader;
                            this._sharedIndex = sharedIndex;
                            this._maxChunkSize = useSingleChunking ? 1 : $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader).s_defaultMaxChunkSize;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361311246)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900918798)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900918798);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900918798)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490853390)
                    /*object? */ get SC$1$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103080787982);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490853390)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605951502)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605951502);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._localOffset === null)
                        {
                            $.$$.SD.Debug.Assert$4(this._currentChunkSize === null, "_currentChunkSize == null");
                            this._localOffset = new ($.$$.SRC.StrongBox$$($.$$.S.Int32))().$ctor$2(-1);
                            this._currentChunkSize = new ($.$$.SRC.StrongBox$$($.$$.S.Int32))().$ctor$2(0);
                            this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                        }
                        $.$$.SD.Debug.Assert$4(this._currentChunkSize !== null, "_currentChunkSize != null");
                        if (this._localOffset.Value < ((this._currentChunkSize.Value - 1) | 0))
                        {
                            this._localOffset.Value++;
                            return true;
                        }
                        else 
                        {
                            $.$$.SD.Debug.Assert$4(this._localOffset.Value === ((this._currentChunkSize.Value - 1) | 0) || this._currentChunkSize.Value === 0, "_localOffset.Value == _currentChunkSize.Value - 1 || _currentChunkSize.Value == 0");
                            /*int*/ let requestedChunkSize;
                            if (this._currentChunkSize.Value === 0)
                            {
                                requestedChunkSize = 1;
                            }
                            else if (this._doublingCountdown > 0)
                            {
                                requestedChunkSize = this._currentChunkSize.Value;
                            }
                            else 
                            {
                                requestedChunkSize = $.$$.S.Math.Min$4(((this._currentChunkSize.Value * 2) | 0), this._maxChunkSize);
                                this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                            }
                            this._doublingCountdown--;
                            $.$$.SD.Debug.Assert$4(requestedChunkSize > 0 && requestedChunkSize <= this._maxChunkSize, "requestedChunkSize > 0 && requestedChunkSize <= _maxChunkSize");
                            if (this.GrabNextChunk(requestedChunkSize))
                            {
                                $.$$.SD.Debug.Assert$4(this._currentChunkSize.Value <= requestedChunkSize && this._currentChunkSize.Value > 0, "_currentChunkSize.Value <= requestedChunkSize && _currentChunkSize.Value > 0");
                                this._localOffset.Value = 0;
                                return true;
                            }
                            else 
                            {
                                return false;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605951502)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066343950)
                    //Static Initializer
                    static $sinit()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066343950);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        {
                            //--TRIMMABLE-BOUNDARY-START(90195886094)
                            this.s_defaultMaxChunkSize = $.$scc.SCC.Partitioner.GetDefaultChunkSize(TSource);
                            //--TRIMMABLE-BOUNDARY-END(90195886094)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066343950)
                    
                    static $H = 1572878;
                    static $h = 1572878;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310984206),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 68721049614,
        "h": Number(BigInt(this.$h)|0x1000000000n),
        "f": 50331908
      },
      "n": "HasNoElementsLeft",
      "d": this.$h,
      "H": 77310984206,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(77310984206),
//--TRIMMABLE-BOUNDARY-START(47246213134),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 60131115022,
        "h": Number(BigInt(this.$h)|0xE00000000n),
        "f": 50331905
      },
      "n": "Current",
      "d": this.$h,
      "H": 47246213134,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47246213134),
//--TRIMMABLE-BOUNDARY-START(94490853390),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 103080787982,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": this.$h,
      "H": 94490853390,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94490853390)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73016016910),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": this.$h,
      "H": 73016016910,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(73016016910),
//--TRIMMABLE-BOUNDARY-START(51541180430),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 51541180430,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51541180430),
//--TRIMMABLE-BOUNDARY-START(85900918798),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "H": 85900918798,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900918798),
//--TRIMMABLE-BOUNDARY-START(81605951502),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": this.$h,
      "H": 81605951502,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605951502)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771376654),
    {
      "t": TSourceReader?.$h??1638400,
      "n": "_sharedReader",
      "d": this.$h,
      "H": 25771376654,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(25771376654),
//--TRIMMABLE-BOUNDARY-START(90195886094),
    {
      "t": 655361,
      "n": "s_defaultMaxChunkSize",
      "d": this.$h,
      "H": 90195886094,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194340
    },
//--TRIMMABLE-BOUNDARY-END(90195886094),
//--TRIMMABLE-BOUNDARY-START(4296540174),
    {
      "t": $.$$.SRC.StrongBox$$($.$$.S.Int32).$h,
      "n": "_currentChunkSize",
      "d": this.$h,
      "H": 4296540174,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4296540174),
//--TRIMMABLE-BOUNDARY-START(12886474766),
    {
      "t": $.$$.SRC.StrongBox$$($.$$.S.Int32).$h,
      "n": "_localOffset",
      "d": this.$h,
      "H": 12886474766,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12886474766),
//--TRIMMABLE-BOUNDARY-START(42951245838),
    {
      "t": 655361,
      "n": "CHUNK_DOUBLING_RATE",
      "d": this.$h,
      "H": 42951245838,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42951245838),
//--TRIMMABLE-BOUNDARY-START(8591507470),
    {
      "t": 655361,
      "n": "_doublingCountdown",
      "d": this.$h,
      "H": 8591507470,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507470),
//--TRIMMABLE-BOUNDARY-START(17181442062),
    {
      "t": 655361,
      "n": "_maxChunkSize",
      "d": this.$h,
      "H": 17181442062,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(17181442062),
//--TRIMMABLE-BOUNDARY-START(21476409358),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": this.$h,
      "H": 21476409358,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(21476409358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38656278542),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1638400
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 38656278542,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38656278542),
//--TRIMMABLE-BOUNDARY-START(34361311246),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1638400
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 34361311246,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34361311246)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    },
    {
      "h": TSourceReader?.$h??1638400,
      "n": "TSourceReader"
    }
  ],
  "r": 2,
  "d": 1507342,
  "H": 1572878,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionEnumerator_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionEnumerator_Abstract$${TSource?.$getFullName(separator)}$${TSourceReader?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumerator_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            //--TRIMMABLE-BOUNDARY-END(1572878)
            
            //--TRIMMABLE-BOUNDARY-START(1900558)
            static $_DynamicPartitionerForIEnumerable$$;
            static DynamicPartitionerForIEnumerable$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionerForIEnumerable$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable<>`, [TSource], ($self) => class DynamicPartitionerForIEnumerable$$ extends $.$scc.SCC.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296867854)
                    /*IEnumerable<TSource>*/ _source = null;
                    //--TRIMMABLE-BOUNDARY-END(4296867854)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835150)
                    /*bool*/ _useSingleChunking = false;
                    //--TRIMMABLE-BOUNDARY-END(8591835150)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802446)
                    $ctor$3(/*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886802446);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._source = source;
                            this._useSingleChunking = ((partitionerOptions & 1/*EnumerablePartitionerOptions.NoBuffering*/) !== 0);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886802446)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066671630)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066671630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))), null, [partitionCount], null);
                        /*var*/ let partitionEnumerable = new ($.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.SCG$IEnumerable$$$GetEnumerator(), this._useSingleChunking, true);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.GetEnumerator(), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066671630)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771704334)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771704334);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.SCG$IEnumerable$$$GetEnumerator(), this._useSingleChunking, false);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771704334)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361638926)
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476737038);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361638926)
                    
                    //--TRIMMABLE-BOUNDARY-START(1966094)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1966094);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerable`, ($self) => class InternalPartitionEnumerable extends $.$$.S.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(42951639054)
                            /*IEnumerator<TSource>*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(42951639054)
                            
                            //--TRIMMABLE-BOUNDARY-START(34361704462)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(34361704462)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181835278)
                            /*KeyValuePair<long, TSource>[]?*/ _fillBuffer = null;
                            //--TRIMMABLE-BOUNDARY-END(17181835278)
                            
                            //--TRIMMABLE-BOUNDARY-START(25771769870)
                            /*int*/ _fillBufferSize = 0;
                            //--TRIMMABLE-BOUNDARY-END(25771769870)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476802574)
                            /*int*/ _fillBufferCurrentPosition = 0;
                            //--TRIMMABLE-BOUNDARY-END(21476802574)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296933390)
                            /*int*/ _activeCopiers = 0;
                            //--TRIMMABLE-BOUNDARY-END(4296933390)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066737166)
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            //--TRIMMABLE-BOUNDARY-END(30066737166)
                            
                            //--TRIMMABLE-BOUNDARY-START(47246606350)
                            /*SharedBool*/ _sourceDepleted = null;
                            //--TRIMMABLE-BOUNDARY-END(47246606350)
                            
                            //--TRIMMABLE-BOUNDARY-START(38656671758)
                            /*object*/ _sharedLock = null;
                            //--TRIMMABLE-BOUNDARY-END(38656671758)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886867982)
                            /*bool*/ _disposed = false;
                            //--TRIMMABLE-BOUNDARY-END(12886867982)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591900686)
                            /*SharedInt?*/ _activePartitionCount = null;
                            //--TRIMMABLE-BOUNDARY-END(8591900686)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541573646)
                            /*bool*/ _useSingleChunking = false;
                            //--TRIMMABLE-BOUNDARY-END(51541573646)
                            
                            //--TRIMMABLE-BOUNDARY-START(55836540942)
                            $ctor$1(/*IEnumerator<TSource>*/ sharedReader, /*bool*/ useSingleChunking, /*bool*/ isStaticPartitioning)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(55836540942);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.SCC.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                    this._hasNoElementsLeft = new $.$scc.SCC.Partitioner.SharedBool().$ctor$1(false);
                                    this._sourceDepleted = new $.$scc.SCC.Partitioner.SharedBool().$ctor$1(false);
                                    this._sharedLock = new $.$$.S.Object().$ctor();
                                    this._useSingleChunking = useSingleChunking;
                                    if (!this._useSingleChunking)
                                    {
                                        /*int*/ let fillBufferMultiplier = /*(Environment.ProcessorCount > 4) ? 4 : */ 1;
                                        this._fillBuffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), null, [((fillBufferMultiplier * $.$scc.SCC.Partitioner.GetDefaultChunkSize(TSource)) | 0)], null);
                                    }
                                    if (isStaticPartitioning)
                                    {
                                        this._activePartitionCount = new $.$scc.SCC.Partitioner.SharedInt().$ctor$1(0);
                                    }
                                    else 
                                    {
                                        this._activePartitionCount = null;
                                    }
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(55836540942)
                            
                            //--TRIMMABLE-BOUNDARY-START(64426475534)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(64426475534);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.S.ObjectDisposedException.ThrowIf(this._disposed, this);
                                return new ($.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerator)().$ctor$3(this._sharedReader, this._sharedIndex, this._hasNoElementsLeft, this._activePartitionCount, this, this._useSingleChunking);
                            }
                            //--TRIMMABLE-BOUNDARY-END(64426475534)
                            
                            //--TRIMMABLE-BOUNDARY-START(81606344718)
                            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(81606344718);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(81606344718)
                            
                            //--TRIMMABLE-BOUNDARY-START(85901312014)
                            /*void */ TryCopyFromFillBuffer(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(85901312014);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                actualNumElementsGrabbed.$v = 0;
                                /*KeyValuePair<long, TSource>[]?*/ let fillBufferLocalRef = this._fillBuffer;
                                if (fillBufferLocalRef === null)
                                {
                                    return;
                                }
                                if (this._fillBufferCurrentPosition >= this._fillBufferSize)
                                {
                                    return;
                                }
                                $.$$.ST$1.Interlocked.Increment($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.S.Int32));
                                /*int*/ let endPos = $.$$.ST$1.Interlocked.Add($.$ref(() => this._fillBufferCurrentPosition, ($v) => this._fillBufferCurrentPosition = $v, $.$$.S.Int32), requestedChunkSize);
                                /*int*/ let beginPos = ((endPos - requestedChunkSize) | 0);
                                if (beginPos < this._fillBufferSize)
                                {
                                    actualNumElementsGrabbed.$v = (endPos < this._fillBufferSize) ? endPos : ((this._fillBufferSize - beginPos) | 0);
                                    $.$$.S.Array.Copy(fillBufferLocalRef, beginPos, destArray, 0, actualNumElementsGrabbed.$v);
                                }
                                $.$$.ST$1.Interlocked.Decrement($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.S.Int32));
                            }
                            //--TRIMMABLE-BOUNDARY-END(85901312014)
                            
                            //--TRIMMABLE-BOUNDARY-START(77311377422)
                            /*bool */ GrabChunk(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(77311377422);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                actualNumElementsGrabbed.$v = 0;
                                if (this._hasNoElementsLeft.Value)
                                {
                                    return false;
                                }
                                if (this._useSingleChunking)
                                {
                                    return this.GrabChunk_Single(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                                else 
                                {
                                    return this.GrabChunk_Buffered(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(77311377422)
                            
                            //--TRIMMABLE-BOUNDARY-START(73016410126)
                            /*bool */ GrabChunk_Single(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(73016410126);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.SD.Debug.Assert$4(this._useSingleChunking, "Expected _useSingleChecking to be true");
                                $.$$.SD.Debug.Assert$1(requestedChunkSize === 1, `Got requested chunk size of ${$.$strNN(requestedChunkSize)} when single-chunking was on`);
                                $.$$.SD.Debug.Assert$1(actualNumElementsGrabbed.$v === 0, `Expected actualNumElementsGrabbed == 0, instead it is ${$.$strNN(actualNumElementsGrabbed.$v)}`);
                                $.$$.SD.Debug.Assert$1(destArray.length === 1, `Expected destArray to be of length 1, instead its length is ${$.$strNN(destArray.length)}`);
                                //lock(_sharedLock)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._hasNoElementsLeft.Value)
                                        {
                                            return false;
                                        }
                                        try
                                        {
                                            if (this._sharedReader.SC$1$IEnumerator$MoveNext())
                                            {
                                                this._sharedIndex.Value = BigInt.asIntN(64, this._sharedIndex.Value + 1n);
                                                $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.SCG$IEnumerator$$$Current), 0);
                                                actualNumElementsGrabbed.$v = 1;
                                                return true;
                                            }
                                            else 
                                            {
                                                this._sourceDepleted.Value = true;
                                                this._hasNoElementsLeft.Value = true;
                                                return false;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(this._sharedLock)
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(73016410126)
                            
                            //--TRIMMABLE-BOUNDARY-START(68721442830)
                            /*bool */ GrabChunk_Buffered(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(68721442830);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.SD.Debug.Assert$4(requestedChunkSize > 0, "requestedChunkSize > 0");
                                $.$$.SD.Debug.Assert$4(!this._useSingleChunking, "Did not expect to be in single-chunking mode");
                                this.TryCopyFromFillBuffer(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                if (actualNumElementsGrabbed.$v === requestedChunkSize)
                                {
                                    return true;
                                }
                                else if (this._sourceDepleted.Value)
                                {
                                    this._hasNoElementsLeft.Value = true;
                                    this._fillBuffer = null;
                                    return (actualNumElementsGrabbed.$v > 0);
                                }
                                //lock(_sharedLock)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._sourceDepleted.Value)
                                        {
                                            return (actualNumElementsGrabbed.$v > 0);
                                        }
                                        try
                                        {
                                            if (this._activeCopiers > 0)
                                            {
                                                /*SpinWait*/ let sw = new $.$$.ST$1.SpinWait();
                                                while(this._activeCopiers > 0)
                                                {
                                                    sw.SpinOnce();
                                                }
                                            }
                                            $.$$.SD.Debug.Assert$4(this._sharedIndex !== null, "_sharedIndex != null");
                                            for(; actualNumElementsGrabbed.$v < requestedChunkSize; actualNumElementsGrabbed.$v++)
                                            {
                                                if (this._sharedReader.SC$1$IEnumerator$MoveNext())
                                                {
                                                    this._sharedIndex.Value = BigInt.asIntN(64, this._sharedIndex.Value + 1n);
                                                    $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.SCG$IEnumerator$$$Current), actualNumElementsGrabbed.$v);
                                                }
                                                else 
                                                {
                                                    this._sourceDepleted.Value = true;
                                                    break;
                                                }
                                            }
                                            /*var*/ let localFillBufferRef = this._fillBuffer;
                                            if (this._sourceDepleted.Value === false && localFillBufferRef !== null && this._fillBufferCurrentPosition >= localFillBufferRef.length)
                                            {
                                                for(/*int*/ let i = 0; i < localFillBufferRef.length; i++)
                                                {
                                                    if (this._sharedReader.SC$1$IEnumerator$MoveNext())
                                                    {
                                                        this._sharedIndex.Value = BigInt.asIntN(64, this._sharedIndex.Value + 1n);
                                                        $.$$.System.Array.$WriteT1.call(localFillBufferRef, new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.SCG$IEnumerator$$$Current), i);
                                                    }
                                                    else 
                                                    {
                                                        this._sourceDepleted.Value = true;
                                                        this._fillBufferSize = i;
                                                        break;
                                                    }
                                                }
                                                this._fillBufferCurrentPosition = 0;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(this._sharedLock)
                                }
                                return (actualNumElementsGrabbed.$v > 0);
                            }
                            //--TRIMMABLE-BOUNDARY-END(68721442830)
                            
                            //--TRIMMABLE-BOUNDARY-START(60131508238)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(60131508238);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (!this._disposed)
                                {
                                    this._disposed = true;
                                    this._sharedReader.S$IDisposable$Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(60131508238)
                            
                            //--TRIMMABLE-BOUNDARY-START(4355325953)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            SCG$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4355325953);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4355325953)
                            
                            //--TRIMMABLE-BOUNDARY-START(4386062337)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            S$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4386062337);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4386062337)
                            
                            static $H = 1966094;
                            static $h = 1966094;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Object; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(64426475534),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 1966094,
      "H": 64426475534,
      "h": Number(BigInt(1966094)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426475534),
//--TRIMMABLE-BOUNDARY-START(85901312014),
    {
      "r": 65537,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryCopyFromFillBuffer",
      "d": 1966094,
      "H": 85901312014,
      "h": Number(BigInt(1966094)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85901312014),
//--TRIMMABLE-BOUNDARY-START(77311377422),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk",
      "d": 1966094,
      "H": 77311377422,
      "h": Number(BigInt(1966094)|0x1200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77311377422),
//--TRIMMABLE-BOUNDARY-START(73016410126),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk_Single",
      "d": 1966094,
      "H": 73016410126,
      "h": Number(BigInt(1966094)|0x1100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(73016410126),
//--TRIMMABLE-BOUNDARY-START(68721442830),
    {
      "r": 262145,
      "p": [
        {
          "n": "destArray",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h
        },
        {
          "n": "requestedChunkSize",
          "p": 655361
        },
        {
          "n": "actualNumElementsGrabbed",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "GrabChunk_Buffered",
      "d": 1966094,
      "H": 68721442830,
      "h": Number(BigInt(1966094)|0x1000000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68721442830),
//--TRIMMABLE-BOUNDARY-START(60131508238),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1966094,
      "H": 60131508238,
      "h": Number(BigInt(1966094)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131508238)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42951639054),
    {
      "t": $.$$.SCG.IEnumerator$$(TSource).$h,
      "n": "_sharedReader",
      "d": 1966094,
      "H": 42951639054,
      "h": Number(BigInt(1966094)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42951639054),
//--TRIMMABLE-BOUNDARY-START(34361704462),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 1966094,
      "H": 34361704462,
      "h": Number(BigInt(1966094)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361704462),
//--TRIMMABLE-BOUNDARY-START(17181835278),
    {
      "t": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "_fillBuffer",
      "d": 1966094,
      "H": 17181835278,
      "h": Number(BigInt(1966094)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181835278),
//--TRIMMABLE-BOUNDARY-START(25771769870),
    {
      "t": 655361,
      "n": "_fillBufferSize",
      "d": 1966094,
      "H": 25771769870,
      "h": Number(BigInt(1966094)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771769870),
//--TRIMMABLE-BOUNDARY-START(21476802574),
    {
      "t": 655361,
      "n": "_fillBufferCurrentPosition",
      "d": 1966094,
      "H": 21476802574,
      "h": Number(BigInt(1966094)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476802574),
//--TRIMMABLE-BOUNDARY-START(4296933390),
    {
      "t": 655361,
      "n": "_activeCopiers",
      "d": 1966094,
      "H": 4296933390,
      "h": Number(BigInt(1966094)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296933390),
//--TRIMMABLE-BOUNDARY-START(30066737166),
    {
      "t": 2359310,
      "n": "_hasNoElementsLeft",
      "d": 1966094,
      "H": 30066737166,
      "h": Number(BigInt(1966094)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066737166),
//--TRIMMABLE-BOUNDARY-START(47246606350),
    {
      "t": 2359310,
      "n": "_sourceDepleted",
      "d": 1966094,
      "H": 47246606350,
      "h": Number(BigInt(1966094)|0xB00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(47246606350),
//--TRIMMABLE-BOUNDARY-START(38656671758),
    {
      "t": 131073,
      "n": "_sharedLock",
      "d": 1966094,
      "H": 38656671758,
      "h": Number(BigInt(1966094)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38656671758),
//--TRIMMABLE-BOUNDARY-START(12886867982),
    {
      "t": 262145,
      "n": "_disposed",
      "d": 1966094,
      "H": 12886867982,
      "h": Number(BigInt(1966094)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886867982),
//--TRIMMABLE-BOUNDARY-START(8591900686),
    {
      "t": 2424846,
      "n": "_activePartitionCount",
      "d": 1966094,
      "H": 8591900686,
      "h": Number(BigInt(1966094)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591900686),
//--TRIMMABLE-BOUNDARY-START(51541573646),
    {
      "t": 262145,
      "n": "_useSingleChunking",
      "d": 1966094,
      "H": 51541573646,
      "h": Number(BigInt(1966094)|0xC00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(51541573646)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55836540942),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.SCG.IEnumerator$$(TSource).$h
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        },
        {
          "n": "isStaticPartitioning",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1966094,
      "H": 55836540942,
      "h": Number(BigInt(1966094)|0xD00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55836540942)
  ],
  "d": 1900558,
  "H": 1966094,
  "h": 1966094
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.SC$1.IEnumerable, $.$$.S.IDisposable ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIEnumerable<${TSource?.$fullName}>+InternalPartitionEnumerable`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIEnumerable$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1966094)
                    
                    //--TRIMMABLE-BOUNDARY-START(2031630)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(2031630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerator`, ($self) => class InternalPartitionEnumerator extends $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.SCG.IEnumerator$$(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(17181900814)
                            /*KeyValuePair<long, TSource>[]?*/ _localList = null;
                            //--TRIMMABLE-BOUNDARY-END(17181900814)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886933518)
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            //--TRIMMABLE-BOUNDARY-END(12886933518)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296998926)
                            /*SharedInt?*/ _activePartitionCount = null;
                            //--TRIMMABLE-BOUNDARY-END(4296998926)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591966222)
                            /*InternalPartitionEnumerable*/ _enumerable = null;
                            //--TRIMMABLE-BOUNDARY-END(8591966222)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476868110)
                            $ctor$3(/*IEnumerator<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex, /*SharedBool*/ hasNoElementsLeft, /*SharedInt?*/ activePartitionCount, /*InternalPartitionEnumerable*/ enumerable, /*bool*/ useSingleChunking)
                            {
                                super.$ctor$1(sharedReader, sharedIndex, useSingleChunking);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(21476868110);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._hasNoElementsLeft = hasNoElementsLeft;
                                    this._enumerable = enumerable;
                                    this._activePartitionCount = activePartitionCount;
                                    if (this._activePartitionCount !== null)
                                    {
                                        $.$$.ST$1.Interlocked.Increment($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.S.Int32));
                                    }
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476868110)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541639182)
                            /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51541639182);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                $.$$.SD.Debug.Assert$4(requestedChunkSize > 0, "requestedChunkSize > 0");
                                if (this.HasNoElementsLeft)
                                {
                                    return false;
                                }
                                this._localList ??= $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), null, [this._maxChunkSize], null);
                                return this._enumerable.GrabChunk(this._localList, requestedChunkSize, $.$ref(() => this._currentChunkSize.Value, ($v) => this._currentChunkSize.Value = $v, $.$$.S.Int32));
                            }
                            //--TRIMMABLE-BOUNDARY-END(51541639182)
                            
                            //--TRIMMABLE-BOUNDARY-START(55836606478)
                            /*bool */ get HasNoElementsLeft()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47246671886);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._hasNoElementsLeft.Value;
                            }
                            //--TRIMMABLE-BOUNDARY-END(55836606478)
                            
                            //--TRIMMABLE-BOUNDARY-START(25771835406)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(38656737294);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.SD.Debug.Assert$4(this._localList !== null, "_localList != null");
                                $.$$.SD.Debug.Assert$4(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return ($.$$.System.Array.$ReadT1.call(this._localList, this._localOffset.Value));
                            }
                            //--TRIMMABLE-BOUNDARY-END(25771835406)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066802702)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30066802702);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._activePartitionCount !== null && $.$$.ST$1.Interlocked.Decrement($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.S.Int32)) === 0)
                                {
                                    this._enumerable.Dispose();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(30066802702)
                            
                            static $H = 2031630;
                            static $h = 2031630;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.SCG.IEnumerator$$(TSource)); }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836606478),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 47246671886,
        "h": Number(BigInt(2031630)|0xB00000000n),
        "f": 50364420
      },
      "n": "HasNoElementsLeft",
      "d": 2031630,
      "H": 55836606478,
      "h": Number(BigInt(2031630)|0xD00000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(55836606478),
//--TRIMMABLE-BOUNDARY-START(25771835406),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38656737294,
        "h": Number(BigInt(2031630)|0x900000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 2031630,
      "H": 25771835406,
      "h": Number(BigInt(2031630)|0x600000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771835406)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541639182),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": 2031630,
      "H": 51541639182,
      "h": Number(BigInt(2031630)|0xC00000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51541639182),
//--TRIMMABLE-BOUNDARY-START(30066802702),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 2031630,
      "H": 30066802702,
      "h": Number(BigInt(2031630)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066802702)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181900814),
    {
      "t": $.$typeArray($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "_localList",
      "d": 2031630,
      "H": 17181900814,
      "h": Number(BigInt(2031630)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181900814),
//--TRIMMABLE-BOUNDARY-START(12886933518),
    {
      "t": 2359310,
      "n": "_hasNoElementsLeft",
      "d": 2031630,
      "H": 12886933518,
      "h": Number(BigInt(2031630)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886933518),
//--TRIMMABLE-BOUNDARY-START(4296998926),
    {
      "t": 2424846,
      "n": "_activePartitionCount",
      "d": 2031630,
      "H": 4296998926,
      "h": Number(BigInt(2031630)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296998926),
//--TRIMMABLE-BOUNDARY-START(8591966222),
    {
      "t": 1966094,
      "n": "_enumerable",
      "d": 2031630,
      "H": 8591966222,
      "h": Number(BigInt(2031630)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591966222)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476868110),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.SCG.IEnumerator$$(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        },
        {
          "n": "hasNoElementsLeft",
          "p": 2359310
        },
        {
          "n": "activePartitionCount",
          "p": 2424846
        },
        {
          "n": "enumerable",
          "p": 1966094
        },
        {
          "n": "useSingleChunking",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2031630,
      "H": 21476868110,
      "h": Number(BigInt(2031630)|0x500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476868110)
  ],
  "d": 1900558,
  "H": 2031630,
  "h": 2031630
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIEnumerable<${TSource?.$fullName}>+InternalPartitionEnumerator`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIEnumerable$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2031630)
                    
                    static $H = 1900558;
                    static $h = 1900558;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.OrderablePartitioner$$(TSource); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361638926),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476737038,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "H": 34361638926,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361638926)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066671630),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "H": 30066671630,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066671630),
//--TRIMMABLE-BOUNDARY-START(25771704334),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "H": 25771704334,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771704334)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867854),
    {
      "t": $.$$.SCG.IEnumerable$$(TSource).$h,
      "n": "_source",
      "d": this.$h,
      "H": 4296867854,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867854),
//--TRIMMABLE-BOUNDARY-START(8591835150),
    {
      "t": 262145,
      "n": "_useSingleChunking",
      "d": this.$h,
      "H": 8591835150,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591835150)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802446),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.SCG.IEnumerable$$(TSource).$h
        },
        {
          "n": "partitionerOptions",
          "p": 1114126
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12886802446,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886802446)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 1900558,
  "h": this.$h
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable, $.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIEnumerable<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIEnumerable$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIEnumerable$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(1900558)
            
            //--TRIMMABLE-BOUNDARY-START(2293774)
            static $_DynamicPartitionerForIndexRange_Abstract$$$;
            static DynamicPartitionerForIndexRange_Abstract$$$(TSource, TCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2293774);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionerForIndexRange_Abstract$$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>`, (TSource, TCollection) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>`, [TSource, TCollection], ($self) => class DynamicPartitionerForIndexRange_Abstract$$$ extends $.$scc.SCC.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297261070)
                    /*TCollection*/ _data = $.$default(TCollection);
                    //--TRIMMABLE-BOUNDARY-END(4297261070)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592228366)
                    $ctor$3(/*TCollection*/ data)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592228366);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._data = data;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592228366)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067064846)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067064846);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))), null, [partitionCount], null);
                        /*IEnumerable<KeyValuePair<long, TSource>>*/ let partitionEnumerable = this.GetOrderableDynamicPartitions_Factory(this._data);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.SCG$IEnumerable$$$GetEnumerator(), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067064846)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772097550)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772097550);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetOrderableDynamicPartitions_Factory(this._data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772097550)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362032142)
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182162958);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362032142)
                    
                    static $H = 2293774;
                    static $h = 2293774;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.OrderablePartitioner$$(TSource); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362032142),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17182162958,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50364417
      },
      "n": "SupportsDynamicPartitions",
      "d": this.$h,
      "H": 34362032142,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34362032142)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21477130254),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "data",
          "p": TCollection?.$h??1638400
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "H": 21477130254,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(21477130254),
//--TRIMMABLE-BOUNDARY-START(30067064846),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "H": 30067064846,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067064846),
//--TRIMMABLE-BOUNDARY-START(25772097550),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetOrderableDynamicPartitions",
      "d": this.$h,
      "H": 25772097550,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772097550)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297261070),
    {
      "t": TCollection?.$h??1638400,
      "n": "_data",
      "d": this.$h,
      "H": 4297261070,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297261070)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228366),
    {
      "p": [
        {
          "n": "data",
          "p": TCollection?.$h??1638400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8592228366,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8592228366)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    },
    {
      "h": TCollection?.$h??1638400,
      "n": "TCollection"
    }
  ],
  "r": 2,
  "d": 1507342,
  "H": 2293774,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIndexRange_Abstract<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIndexRange_Abstract$${TSource?.$getFullName(separator)}$${TCollection?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIndexRange_Abstract$$$ = $v))(TSource, TCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(2293774)
            
            //--TRIMMABLE-BOUNDARY-START(1638414)
            static $_DynamicPartitionEnumeratorForIndexRange_Abstract$$$;
            static DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, TSourceReader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>`, (TSource, TSourceReader) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>`, [TSource, TSourceReader], ($self) => class DynamicPartitionEnumeratorForIndexRange_Abstract$$$ extends $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
                {
                    //--TRIMMABLE-BOUNDARY-START(4296605710)
                    /*int*/ _startIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(4296605710)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591573006)
                    $ctor$3(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        super.$ctor$2(sharedReader, sharedIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8591573006);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591573006)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361376782)
                    /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361376782);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(requestedChunkSize > 0, "requestedChunkSize > 0");
                        while(!this.HasNoElementsLeft)
                        {
                            $.$$.SD.Debug.Assert$4(this._sharedIndex !== null, "_sharedIndex != null");
                            /*long*/ let oldSharedIndex = $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.S.Int64).$v;
                            if (this.HasNoElementsLeft)
                            {
                                return false;
                            }
                            /*long*/ let newSharedIndex = $.$$.S.Math.Min$5(BigInt(this.SourceCount - 1), BigInt.asIntN(64, oldSharedIndex + BigInt(requestedChunkSize)));
                            if ($.$$.ST$1.Interlocked.CompareExchange$4($.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.S.Int64), newSharedIndex, oldSharedIndex) === oldSharedIndex)
                            {
                                this._currentChunkSize.Value = $.$cast((BigInt.asIntN(64, newSharedIndex - oldSharedIndex)), $.$$.S.Int32);
                                this._localOffset.Value = -1;
                                this._startIndex = $.$cast((BigInt.asIntN(64, oldSharedIndex + 1n)), $.$$.S.Int32);
                                return true;
                            }
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361376782)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656344078)
                    /*bool */ get HasNoElementsLeft()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476474894);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4(this._sharedIndex !== null, "_sharedIndex != null");
                        return $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.S.Int64).$v >= BigInt(this.SourceCount - 1);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656344078)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886540302)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886540302);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886540302)
                    
                    static $H = 1638414;
                    static $h = 1638414;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951311374),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30066409486,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331908
      },
      "n": "SourceCount",
      "d": this.$h,
      "H": 42951311374,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(42951311374),
//--TRIMMABLE-BOUNDARY-START(38656344078),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21476474894,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "HasNoElementsLeft",
      "d": this.$h,
      "H": 38656344078,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(38656344078)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361376782),
    {
      "r": 262145,
      "p": [
        {
          "n": "requestedChunkSize",
          "p": 655361
        }
      ],
      "n": "GrabNextChunk",
      "d": this.$h,
      "H": 34361376782,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(34361376782),
//--TRIMMABLE-BOUNDARY-START(12886540302),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 12886540302,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886540302)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605710),
    {
      "t": 655361,
      "n": "_startIndex",
      "d": this.$h,
      "H": 4296605710,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4296605710)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573006),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": TSourceReader?.$h??1638400
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 8591573006,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8591573006)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    },
    {
      "h": TSourceReader?.$h??1638400,
      "n": "TSourceReader"
    }
  ],
  "r": 2,
  "d": 1507342,
  "H": 1638414,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionEnumeratorForIndexRange_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionEnumeratorForIndexRange_Abstract$${TSource?.$getFullName(separator)}$${TSourceReader?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            //--TRIMMABLE-BOUNDARY-END(1638414)
            
            //--TRIMMABLE-BOUNDARY-START(2097166)
            static $_DynamicPartitionerForIList$$;
            static DynamicPartitionerForIList$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionerForIList$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIList<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionerForIList<>`, [TSource], ($self) => class DynamicPartitionerForIList$$ extends $.$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.SCG.IList$$(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297064462)
                    $ctor$4(/*IList<TSource>*/ source)
                    {
                        super.$ctor$3(source);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297064462);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297064462)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592031758)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*IList<TSource>*/ _data)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8592031758);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592031758)
                    
                    //--TRIMMABLE-BOUNDARY-START(2162702)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(2162702);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerable`, ($self) => class InternalPartitionEnumerable extends $.$$.S.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(8592097294)
                            /*IList<TSource>*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(8592097294)
                            
                            //--TRIMMABLE-BOUNDARY-START(4297129998)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(4297129998)
                            
                            //--TRIMMABLE-BOUNDARY-START(12887064590)
                            $ctor$1(/*IList<TSource>*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12887064590);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.SCC.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12887064590)
                            
                            //--TRIMMABLE-BOUNDARY-START(17182031886)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17182031886);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return new ($.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17182031886)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476999182)
                            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476999182);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476999182)
                            
                            //--TRIMMABLE-BOUNDARY-START(4355325953)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            SCG$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4355325953);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4355325953)
                            
                            static $H = 2162702;
                            static $h = 2162702;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Object; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17182031886),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 2162702,
      "H": 17182031886,
      "h": Number(BigInt(2162702)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182031886)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592097294),
    {
      "t": $.$$.SCG.IList$$(TSource).$h,
      "n": "_sharedReader",
      "d": 2162702,
      "H": 8592097294,
      "h": Number(BigInt(2162702)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592097294),
//--TRIMMABLE-BOUNDARY-START(4297129998),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 2162702,
      "H": 4297129998,
      "h": Number(BigInt(2162702)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297129998)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887064590),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.SCG.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162702,
      "H": 12887064590,
      "h": Number(BigInt(2162702)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12887064590)
  ],
  "d": 2097166,
  "H": 2162702,
  "h": 2162702
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.SC$1.IEnumerable ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIList<${TSource?.$fullName}>+InternalPartitionEnumerable`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIList$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2162702)
                    
                    //--TRIMMABLE-BOUNDARY-START(2228238)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(2228238);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerator`, ($self) => class InternalPartitionEnumerator extends $.$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.SCG.IList$$(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(4297195534)
                            $ctor$4(/*IList<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(4297195534);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4297195534)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066999310)
                            /*int */ get SourceCount()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(25772032014);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._sharedReader.SCG$ICollection$$$Count;
                            }
                            //--TRIMMABLE-BOUNDARY-END(30066999310)
                            
                            //--TRIMMABLE-BOUNDARY-START(8592162830)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17182097422);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.SD.Debug.Assert$4(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), this._sharedReader.SCG$IList$$$get_Item(((this._startIndex + this._localOffset.Value) | 0)));
                            }
                            //--TRIMMABLE-BOUNDARY-END(8592162830)
                            
                            static $H = 2228238;
                            static $h = 2228238;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.SCG.IList$$(TSource)); }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066999310),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25772032014,
        "h": Number(BigInt(2228238)|0x600000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": 2228238,
      "H": 30066999310,
      "h": Number(BigInt(2228238)|0x700000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30066999310),
//--TRIMMABLE-BOUNDARY-START(8592162830),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17182097422,
        "h": Number(BigInt(2228238)|0x400000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 2228238,
      "H": 8592162830,
      "h": Number(BigInt(2228238)|0x200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8592162830)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195534),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$$.SCG.IList$$(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 2228238,
      "H": 4297195534,
      "h": Number(BigInt(2228238)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297195534)
  ],
  "d": 2097166,
  "H": 2228238,
  "h": 2228238
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIList<${TSource?.$fullName}>+InternalPartitionEnumerator`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIList$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(2228238)
                    
                    static $H = 2097166;
                    static $h = 2097166;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.SCG.IList$$(TSource)); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592031758),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "_data",
          "p": $.$$.SCG.IList$$(TSource).$h
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "H": 8592031758,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8592031758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064462),
    {
      "p": [
        {
          "n": "source",
          "p": $.$$.SCG.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4297064462,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297064462)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2097166,
  "h": this.$h
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerable, $.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForIList<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForIList$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2097166)
            
            //--TRIMMABLE-BOUNDARY-START(1703950)
            static $_DynamicPartitionerForArray$$;
            static DynamicPartitionerForArray$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1703950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_DynamicPartitionerForArray$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForArray<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.DynamicPartitionerForArray<>`, [TSource], ($self) => class DynamicPartitionerForArray$$ extends $.$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4296671246)
                    $ctor$4(/*TSource[]*/ source)
                    {
                        super.$ctor$3(source);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296671246);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296671246)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591638542)
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*TSource[]*/ _data)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591638542);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591638542)
                    
                    //--TRIMMABLE-BOUNDARY-START(1769486)
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1769486);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerable`, ($self) => class InternalPartitionEnumerable extends $.$$.S.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591704078)
                            /*TSource[]*/ _sharedReader = null;
                            //--TRIMMABLE-BOUNDARY-END(8591704078)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296736782)
                            /*SharedLong*/ _sharedIndex = null;
                            //--TRIMMABLE-BOUNDARY-END(4296736782)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886671374)
                            $ctor$1(/*TSource[]*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886671374);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.SCC.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886671374)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476605966)
                            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476605966);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return (this).GetEnumerator();
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476605966)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181638670)
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181638670);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return new ($.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181638670)
                            
                            //--TRIMMABLE-BOUNDARY-START(4355325953)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            SCG$IEnumerable$$$GetEnumerator()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4355325953);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.GetEnumerator(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4355325953)
                            
                            static $H = 1769486;
                            static $h = 1769486;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$$.S.Object; }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181638670),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "n": "GetEnumerator",
      "d": 1769486,
      "H": 17181638670,
      "h": Number(BigInt(1769486)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181638670)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591704078),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_sharedReader",
      "d": 1769486,
      "H": 8591704078,
      "h": Number(BigInt(1769486)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591704078),
//--TRIMMABLE-BOUNDARY-START(4296736782),
    {
      "t": 2490382,
      "n": "_sharedIndex",
      "d": 1769486,
      "H": 4296736782,
      "h": Number(BigInt(1769486)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296736782)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671374),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769486,
      "H": 12886671374,
      "h": Number(BigInt(1769486)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886671374)
  ],
  "d": 1703950,
  "H": 1769486,
  "h": 1769486
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.SC$1.IEnumerable ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForArray<${TSource?.$fullName}>+InternalPartitionEnumerable`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForArray$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1769486)
                    
                    //--TRIMMABLE-BOUNDARY-START(1835022)
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(1835022);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let $cls = $.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls(`$scc.SCC.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerator`, ($self) => class InternalPartitionEnumerator extends $.$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296802318)
                            $ctor$4(/*TSource[]*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(4296802318);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(4296802318)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066606094)
                            /*int */ get SourceCount()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(25771638798);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._sharedReader.length;
                            }
                            //--TRIMMABLE-BOUNDARY-END(30066606094)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591769614)
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17181704206);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.SD.Debug.Assert$4(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), $.$$.System.Array.$ReadT1.call(this._sharedReader, ((this._startIndex + this._localOffset.Value) | 0)));
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591769614)
                            
                            static $H = 1835022;
                            static $h = 1835022;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$b;
                            static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066606094),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25771638798,
        "h": Number(BigInt(1835022)|0x600000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": 1835022,
      "H": 30066606094,
      "h": Number(BigInt(1835022)|0x700000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(30066606094),
//--TRIMMABLE-BOUNDARY-START(8591769614),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17181704206,
        "h": Number(BigInt(1835022)|0x400000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": 1835022,
      "H": 8591769614,
      "h": Number(BigInt(1835022)|0x200000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(8591769614)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802318),
    {
      "p": [
        {
          "n": "sharedReader",
          "p": $.$typeArray(TSource).$h
        },
        {
          "n": "sharedIndex",
          "p": 2490382
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1835022,
      "H": 4296802318,
      "h": Number(BigInt(1835022)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296802318)
  ],
  "d": 1703950,
  "H": 1835022,
  "h": 1835022
}; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                            static $$fullName;
                            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForArray<${TSource?.$fullName}>+InternalPartitionEnumerator`; }
                            static $$getFullName = {};
                            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForArray$${TSource?.$getFullName(separator)}$${separator}InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1835022)
                    
                    static $H = 1703950;
                    static $h = 1703950;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591638542),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "_data",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": "GetOrderableDynamicPartitions_Factory",
      "d": this.$h,
      "H": 8591638542,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8591638542)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671246),
    {
      "p": [
        {
          "n": "source",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 4296671246,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296671246)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 1703950,
  "h": this.$h
}; }
                    static $$n;
                    static get $n() { return this.$$n ??= [ $.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerable, $.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+DynamicPartitionerForArray<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}DynamicPartitionerForArray$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(1703950)
            
            //--TRIMMABLE-BOUNDARY-START(2621454)
            static $_StaticIndexRangePartitioner$$$;
            static StaticIndexRangePartitioner$$$(TSource, TCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2621454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartitioner$$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartitioner<,>`, (TSource, TCollection) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartitioner<,>`, [TSource, TCollection], ($self) => class StaticIndexRangePartitioner$$$ extends $.$scc.SCC.OrderablePartitioner$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297588750)
                    $ctor$3()
                    {
                        super.$ctor$2(true, true, true);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297588750);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588750)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477457934)
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477457934);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, partitionCount, "partitionCount");
                        let [ quotient, remainder ] = $.$destructure($.$$.S.Math.DivRem$3(this.SourceCount, partitionCount), 2);
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))), null, [partitionCount], null);
                        /*int*/ let lastEndIndex = -1;
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            /*int*/ let startIndex = ((lastEndIndex + 1) | 0);
                            if (i < remainder)
                            {
                                lastEndIndex = ((startIndex + quotient) | 0);
                            }
                            else 
                            {
                                lastEndIndex = ((((startIndex + quotient) | 0) - 1) | 0);
                            }
                            $.$$.System.Array.$WriteT1.call(partitions, this.CreatePartition(startIndex, lastEndIndex), i);
                        }
                        return partitions;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477457934)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297588750)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297588750)
                    
                    static $H = 2621454;
                    static $h = 2621454;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.OrderablePartitioner$$(TSource); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772425230),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17182490638,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331908
      },
      "n": "SourceCount",
      "d": this.$h,
      "H": 25772425230,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2097412
    },
//--TRIMMABLE-BOUNDARY-END(25772425230)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592556046),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "H": 8592556046,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(8592556046),
//--TRIMMABLE-BOUNDARY-START(21477457934),
    {
      "r": $.$$.SCG.IList$$($.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))).$h,
      "p": [
        {
          "n": "partitionCount",
          "p": 655361
        }
      ],
      "n": "GetOrderablePartitions",
      "d": this.$h,
      "H": 21477457934,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477457934)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297588750),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 4297588750,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297588750)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    },
    {
      "h": TCollection?.$h??1638400,
      "n": "TCollection"
    }
  ],
  "r": 2,
  "d": 1507342,
  "H": 2621454,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartitioner<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartitioner$${TSource?.$getFullName(separator)}$${TCollection?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitioner$$$ = $v))(TSource, TCollection);
            }
            //--TRIMMABLE-BOUNDARY-END(2621454)
            
            //--TRIMMABLE-BOUNDARY-START(2555918)
            static $_StaticIndexRangePartition$$;
            static StaticIndexRangePartition$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2555918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartition$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartition<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartition<>`, [TSource], ($self) => class StaticIndexRangePartition$$ extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12887457806)
                    /*int*/ _startIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(12887457806)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297523214)
                    /*int*/ _endIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(4297523214)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592490510)
                    /*int*/ _offset = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592490510)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182425102)
                    $ctor$1(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17182425102);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._startIndex = startIndex;
                            this._endIndex = endIndex;
                            this._offset = ((startIndex - 1) | 0);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182425102)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772359694)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772359694);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772359694)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952228878)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952228878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.S.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952228878)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657261582)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657261582);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._endIndex)
                        {
                            this._offset++;
                            return true;
                        }
                        else 
                        {
                            this._offset = ((this._endIndex + 1) | 0);
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657261582)
                    
                    //--TRIMMABLE-BOUNDARY-START(47247196174)
                    /*object? */ get SC$1$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55837130766);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this).Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47247196174)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    static $H = 2555918;
                    static $h = 2555918;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477392398),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34362294286,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331905
      },
      "n": "Current",
      "d": this.$h,
      "H": 21477392398,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21477392398),
//--TRIMMABLE-BOUNDARY-START(47247196174),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55837130766,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": this.$h,
      "H": 47247196174,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(47247196174)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772359694),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 25772359694,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25772359694),
//--TRIMMABLE-BOUNDARY-START(42952228878),
    {
      "r": 65537,
      "n": "Reset",
      "d": this.$h,
      "H": 42952228878,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42952228878),
//--TRIMMABLE-BOUNDARY-START(38657261582),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": this.$h,
      "H": 38657261582,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38657261582)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12887457806),
    {
      "t": 655361,
      "n": "_startIndex",
      "d": this.$h,
      "H": 12887457806,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(12887457806),
//--TRIMMABLE-BOUNDARY-START(4297523214),
    {
      "t": 655361,
      "n": "_endIndex",
      "d": this.$h,
      "H": 4297523214,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(4297523214),
//--TRIMMABLE-BOUNDARY-START(8592490510),
    {
      "t": 655361,
      "n": "_offset",
      "d": this.$h,
      "H": 8592490510,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194308
    },
//--TRIMMABLE-BOUNDARY-END(8592490510)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182425102),
    {
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17182425102,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17182425102)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2555918,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartition<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartition$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartition$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2555918)
            
            //--TRIMMABLE-BOUNDARY-START(2752526)
            static $_StaticIndexRangePartitionerForIList$$;
            static StaticIndexRangePartitionerForIList$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2752526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForIList$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartitionerForIList<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartitionerForIList<>`, [TSource], ($self) => class StaticIndexRangePartitionerForIList$$ extends $.$scc.SCC.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.SCG.IList$$(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297719822)
                    /*IList<TSource>*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(4297719822)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592687118)
                    $ctor$4(/*IList<TSource>*/ list)
                    {
                        super.$ctor$3();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592687118);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(list !== null, "list != null");
                            this._list = list;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592687118)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772556302)
                    /*int */ get SourceCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477589006);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.SCG$ICollection$$$Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772556302)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887654414)
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887654414);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.Partitioner.StaticIndexRangePartitionForIList$$(TSource))().$ctor$2(this._list, startIndex, endIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887654414)
                    
                    static $H = 2752526;
                    static $h = 2752526;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.SCG.IList$$(TSource)); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772556302),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477589006,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": this.$h,
      "H": 25772556302,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25772556302)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887654414),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "H": 12887654414,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887654414)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297719822),
    {
      "t": $.$$.SCG.IList$$(TSource).$h,
      "n": "_list",
      "d": this.$h,
      "H": 4297719822,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297719822)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592687118),
    {
      "p": [
        {
          "n": "list",
          "p": $.$$.SCG.IList$$(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8592687118,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592687118)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2752526,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartitionerForIList<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartitionerForIList$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2752526)
            
            //--TRIMMABLE-BOUNDARY-START(2883598)
            static $_StaticIndexRangePartitionForIList$$;
            static StaticIndexRangePartitionForIList$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2883598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForIList$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartitionForIList<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartitionForIList<>`, [TSource], ($self) => class StaticIndexRangePartitionForIList$$ extends $.$scc.SCC.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297850894)
                    /*IList<TSource>*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(4297850894)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592818190)
                    $ctor$2(/*IList<TSource>*/ list, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592818190);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(startIndex >= 0 && endIndex <= ((list.SCG$ICollection$$$Count - 1) | 0), "startIndex >= 0 && endIndex <= list.Count - 1");
                            this._list = list;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592818190)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887785486)
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477720078);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.SD.Debug.Assert$4(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(BigInt(this._offset), this._list.SCG$IList$$$get_Item(this._offset)));
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887785486)
                    
                    static $H = 2883598;
                    static $h = 2883598;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887785486),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477720078,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": this.$h,
      "H": 12887785486,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887785486)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297850894),
    {
      "t": $.$$.SCG.IList$$(TSource).$h,
      "n": "_list",
      "d": this.$h,
      "H": 4297850894,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297850894)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592818190),
    {
      "p": [
        {
          "n": "list",
          "p": $.$$.SCG.IList$$(TSource).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 8592818190,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592818190)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2883598,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartitionForIList<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartitionForIList$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForIList$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2883598)
            
            //--TRIMMABLE-BOUNDARY-START(2686990)
            static $_StaticIndexRangePartitionerForArray$$;
            static StaticIndexRangePartitionerForArray$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2686990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForArray$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartitionerForArray<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartitionerForArray<>`, [TSource], ($self) => class StaticIndexRangePartitionerForArray$$ extends $.$scc.SCC.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource))
                {
                    //--TRIMMABLE-BOUNDARY-START(4297654286)
                    /*TSource[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4297654286)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592621582)
                    $ctor$4(/*TSource[]*/ array)
                    {
                        super.$ctor$3();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592621582);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(array !== null, "array != null");
                            this._array = array;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592621582)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772490766)
                    /*int */ get SourceCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477523470);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._array.length;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772490766)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887588878)
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887588878);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new ($.$scc.SCC.Partitioner.StaticIndexRangePartitionForArray$$(TSource))().$ctor$2(this._array, startIndex, endIndex);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887588878)
                    
                    static $H = 2686990;
                    static $h = 2686990;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource)); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772490766),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477523470,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364420
      },
      "n": "SourceCount",
      "d": this.$h,
      "H": 25772490766,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129924
    },
//--TRIMMABLE-BOUNDARY-END(25772490766)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12887588878),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)).$h,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "CreatePartition",
      "d": this.$h,
      "H": 12887588878,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12887588878)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297654286),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_array",
      "d": this.$h,
      "H": 4297654286,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297654286)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621582),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(TSource).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 8592621582,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592621582)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2686990,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartitionerForArray<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartitionerForArray$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2686990)
            
            //--TRIMMABLE-BOUNDARY-START(2818062)
            static $_StaticIndexRangePartitionForArray$$;
            static StaticIndexRangePartitionForArray$$(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2818062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForArray$$ ??= $asm.$ncls(`$scc.SCC.Partitioner.StaticIndexRangePartitionForArray<>`, (TSource) => $asm.$gt(`$scc.SCC.Partitioner.StaticIndexRangePartitionForArray<>`, [TSource], ($self) => class StaticIndexRangePartitionForArray$$ extends $.$scc.SCC.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    //--TRIMMABLE-BOUNDARY-START(4297785358)
                    /*TSource[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4297785358)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592752654)
                    $ctor$2(/*TSource[]*/ array, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592752654);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(startIndex >= 0 && endIndex <= ((array.length - 1) | 0), "startIndex >= 0 && endIndex <= array.Length - 1");
                            this._array = array;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592752654)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887719950)
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477654542);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.SD.Debug.Assert$4(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource))().$ctor$3(BigInt(this._offset), $.$$.System.Array.$ReadT1.call(this._array, this._offset)));
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887719950)
                    
                    static $H = 2818062;
                    static $h = 2818062;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scc.SCC.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887719950),
    {
      "p": $.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21477654542,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50364417
      },
      "n": "Current",
      "d": this.$h,
      "H": 12887719950,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12887719950)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297785358),
    {
      "t": $.$typeArray(TSource).$h,
      "n": "_array",
      "d": this.$h,
      "H": 4297785358,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785358)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592752654),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(TSource).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 8592752654,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8592752654)
  ],
  "s": [
    {
      "h": TSource?.$h??1572864,
      "n": "TSource"
    }
  ],
  "r": 1,
  "d": 1507342,
  "H": 2818062,
  "h": this.$h
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$($.$$.S.Int64, TSource)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+StaticIndexRangePartitionForArray<${TSource?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}StaticIndexRangePartitionForArray$${TSource?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForArray$$ = $v))(TSource);
            }
            //--TRIMMABLE-BOUNDARY-END(2818062)
            
            //--TRIMMABLE-BOUNDARY-START(2424846)
            static $_SharedInt;
            static get SharedInt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2424846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return $cls.$_SharedInt ??= $asm.$ncls(`$scc.SCC.Partitioner.SharedInt`, ($self) => class SharedInt extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592359438)
                    /*int*/ Value = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592359438)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297392142)
                    $ctor$1(/*int*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297392142);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297392142)
                    
                    static $h = 2424846;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592359438),
    {
      "t": 655361,
      "n": "Value",
      "d": 2424846,
      "h": 8592359438,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592359438)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392142),
    {
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2424846,
      "h": 4297392142,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297392142)
  ],
  "d": 1507342,
  "h": 2424846
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+SharedInt`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}SharedInt`; }
                }, $cls, ($v) => $cls.$_SharedInt = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2424846)
            
            //--TRIMMABLE-BOUNDARY-START(2359310)
            static $_SharedBool;
            static get SharedBool()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2359310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return $cls.$_SharedBool ??= $asm.$ncls(`$scc.SCC.Partitioner.SharedBool`, ($self) => class SharedBool extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592293902)
                    /*bool*/ Value = false;
                    //--TRIMMABLE-BOUNDARY-END(8592293902)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297326606)
                    $ctor$1(/*bool*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297326606);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297326606)
                    
                    static $h = 2359310;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592293902),
    {
      "t": 262145,
      "n": "Value",
      "d": 2359310,
      "h": 8592293902,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592293902)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326606),
    {
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359310,
      "h": 4297326606,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297326606)
  ],
  "d": 1507342,
  "h": 2359310
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+SharedBool`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}SharedBool`; }
                }, $cls, ($v) => $cls.$_SharedBool = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2359310)
            
            //--TRIMMABLE-BOUNDARY-START(2490382)
            static $_SharedLong;
            static get SharedLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2490382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.Partitioner;
                return $cls.$_SharedLong ??= $asm.$ncls(`$scc.SCC.Partitioner.SharedLong`, ($self) => class SharedLong extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8592424974)
                    /*long*/ Value = 0n;
                    //--TRIMMABLE-BOUNDARY-END(8592424974)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297457678)
                    $ctor$1(/*long*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4297457678);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457678)
                    
                    static $h = 2490382;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8592424974),
    {
      "t": 917505,
      "n": "Value",
      "d": 2490382,
      "h": 8592424974,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8592424974)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297457678),
    {
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2490382,
      "h": 4297457678,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4297457678)
  ],
  "d": 1507342,
  "h": 2490382
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner+SharedLong`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner${separator}SharedLong`; }
                }, $cls, ($v) => $cls.$_SharedLong = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2490382)
            
            //--TRIMMABLE-BOUNDARY-START(55836082190)
            /*int*/ static DEFAULT_BYTES_PER_UNIT = 128;
            //--TRIMMABLE-BOUNDARY-END(55836082190)
            
            //--TRIMMABLE-BOUNDARY-START(51541114894)
            /*int*/ static DEFAULT_BYTES_PER_CHUNK = 512;
            //--TRIMMABLE-BOUNDARY-END(51541114894)
            
            //--TRIMMABLE-BOUNDARY-START(60131049486)
            static /*int */ GetDefaultChunkSize(TSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049486);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let chunkSize;
                if (TSource.$type.IsValueType)
                {
                    {
                        chunkSize = 128/*DEFAULT_BYTES_PER_UNIT*/;
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4((512/*DEFAULT_BYTES_PER_CHUNK*/ % $.$$.S.IntPtr.Size) === 0, "bytes per chunk should be a multiple of pointer size");
                    chunkSize = ($.trunc(512/*DEFAULT_BYTES_PER_CHUNK*/ / $.$$.S.IntPtr.Size));
                }
                return chunkSize;
            }
            //--TRIMMABLE-BOUNDARY-END(60131049486)
            
            static $h = 1507342;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361245710),
    {
      "r": (TSource) => $.$scc.SCC.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "list",
          "p": (TSource) => $.$$.SCG.IList$$(TSource).$h
        },
        {
          "n": "loadBalance",
          "p": 262145
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$6",
      "d": 1507342,
      "h": 34361245710,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34361245710),
//--TRIMMABLE-BOUNDARY-START(38656213006),
    {
      "r": (TSource) => $.$scc.SCC.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "array",
          "p": (TSource) => $.$typeArray(TSource).$h
        },
        {
          "n": "loadBalance",
          "p": 262145
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$7",
      "d": 1507342,
      "h": 38656213006,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38656213006),
//--TRIMMABLE-BOUNDARY-START(30066278414),
    {
      "r": (TSource) => $.$scc.SCC.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$$.SCG.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$5",
      "d": 1507342,
      "h": 30066278414,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30066278414),
//--TRIMMABLE-BOUNDARY-START(25771311118),
    {
      "r": (TSource) => $.$scc.SCC.OrderablePartitioner$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$$.SCG.IEnumerable$$(TSource).$h
        },
        {
          "n": "partitionerOptions",
          "p": 1114126
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Create",
      "o": "@$4",
      "d": 1507342,
      "h": 25771311118,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25771311118),
//--TRIMMABLE-BOUNDARY-START(21476343822),
    {
      "r": $.$scc.SCC.OrderablePartitioner$$($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        }
      ],
      "n": "Create",
      "o": "@$3",
      "d": 1507342,
      "h": 21476343822,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476343822),
//--TRIMMABLE-BOUNDARY-START(17181376526),
    {
      "r": $.$scc.SCC.OrderablePartitioner$$($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        },
        {
          "n": "rangeSize",
          "p": 917505
        }
      ],
      "n": "Create",
      "o": "@$2",
      "d": 1507342,
      "h": 17181376526,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181376526),
//--TRIMMABLE-BOUNDARY-START(47246147598),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Tuple$$$($.$$.S.Int64, $.$$.S.Int64)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 917505
        },
        {
          "n": "toExclusive",
          "p": 917505
        },
        {
          "n": "rangeSize",
          "p": 917505
        }
      ],
      "n": "CreateRanges",
      "o": "@$1",
      "d": 1507342,
      "h": 47246147598,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47246147598),
//--TRIMMABLE-BOUNDARY-START(12886409230),
    {
      "r": $.$scc.SCC.OrderablePartitioner$$($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1507342,
      "h": 12886409230,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886409230),
//--TRIMMABLE-BOUNDARY-START(8591441934),
    {
      "r": $.$scc.SCC.OrderablePartitioner$$($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        },
        {
          "n": "rangeSize",
          "p": 655361
        }
      ],
      "n": "Create",
      "d": 1507342,
      "h": 8591441934,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591441934),
//--TRIMMABLE-BOUNDARY-START(42951180302),
    {
      "r": $.$$.SCG.IEnumerable$$($.$$.S.Tuple$$$($.$$.S.Int32, $.$$.S.Int32)).$h,
      "p": [
        {
          "n": "fromInclusive",
          "p": 655361
        },
        {
          "n": "toExclusive",
          "p": 655361
        },
        {
          "n": "rangeSize",
          "p": 655361
        }
      ],
      "n": "CreateRanges",
      "d": 1507342,
      "h": 42951180302,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42951180302),
//--TRIMMABLE-BOUNDARY-START(60131049486),
    {
      "r": 655361,
      "g": [
        "TSource"
      ],
      "n": "GetDefaultChunkSize",
      "d": 1507342,
      "h": 60131049486,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(60131049486)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296474638),
    {
      "t": 655361,
      "n": "CoreOversubscriptionRate",
      "d": 1507342,
      "h": 4296474638,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4296474638),
//--TRIMMABLE-BOUNDARY-START(55836082190),
    {
      "t": 655361,
      "n": "DEFAULT_BYTES_PER_UNIT",
      "d": 1507342,
      "h": 55836082190,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836082190),
//--TRIMMABLE-BOUNDARY-START(51541114894),
    {
      "t": 655361,
      "n": "DEFAULT_BYTES_PER_CHUNK",
      "d": 1507342,
      "h": 51541114894,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51541114894)
  ],
  "h": 1507342
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$scc.SCC.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader), $.$scc.SCC.Partitioner.DynamicPartitionerForIEnumerable$$(TSource), $.$scc.SCC.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, TCollection), $.$scc.SCC.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, TSourceReader), $.$scc.SCC.Partitioner.DynamicPartitionerForIList$$(TSource), $.$scc.SCC.Partitioner.DynamicPartitionerForArray$$(TSource), $.$scc.SCC.Partitioner.StaticIndexRangePartitioner$$$(TSource, TCollection), $.$scc.SCC.Partitioner.StaticIndexRangePartition$$(TSource), $.$scc.SCC.Partitioner.StaticIndexRangePartitionerForIList$$(TSource), $.$scc.SCC.Partitioner.StaticIndexRangePartitionForIList$$(TSource), $.$scc.SCC.Partitioner.StaticIndexRangePartitionerForArray$$(TSource), $.$scc.SCC.Partitioner.StaticIndexRangePartitionForArray$$(TSource), $.$scc.SCC.Partitioner.SharedInt, $.$scc.SCC.Partitioner.SharedBool, $.$scc.SCC.Partitioner.SharedLong ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.Partitioner`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}Partitioner`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507342)
        
        

        //--TRIMMABLE-BOUNDARY-START(131086)
        $asm.$cls(`$scc.SCC.BlockingCollectionDebugView<>`, (T) => $asm.$gt(`$scc.SCC.BlockingCollectionDebugView<>`, [T], ($self) => class BlockingCollectionDebugView$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098382)
            /*BlockingCollection<T>*/ _blockingCollection = null;
            //--TRIMMABLE-BOUNDARY-END(4295098382)
            
            //--TRIMMABLE-BOUNDARY-START(8590065678)
            $ctor$1(/*BlockingCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065678);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._blockingCollection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065678)
            
            //--TRIMMABLE-BOUNDARY-START(21474967566)
            /*T[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._blockingCollection.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967566)
            
            static $H = 131086;
            static $h = 131086;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967566),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180000270,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 21474967566,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21474967566)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098382),
    {
      "t": $.$scc.SCC.BlockingCollection$$(T).$h,
      "n": "_blockingCollection",
      "d": this.$h,
      "H": 4295098382,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098382)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065678),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$scc.SCC.BlockingCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590065678,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065678)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 131086,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.BlockingCollectionDebugView<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}BlockingCollectionDebugView$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131086)
        
        

        //--TRIMMABLE-BOUNDARY-START(917518)
        $asm.$cls(`$scc.SCC.ConcurrentDictionaryTypeProps<>`, (T) => $asm.$gt(`$scc.SCC.ConcurrentDictionaryTypeProps<>`, [T], ($self) => class ConcurrentDictionaryTypeProps$$
        {
            //--TRIMMABLE-BOUNDARY-START(8590852110)
            /*bool*/ static IsWriteAtomic = false;
            //--TRIMMABLE-BOUNDARY-END(8590852110)
            
            //--TRIMMABLE-BOUNDARY-START(12885819406)
            static /*bool */ IsWriteAtomicPrivate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!T.$type.IsValueType || T.$type === $.$$.S.IntPtr.$type || T.$type === $.$$.S.UIntPtr.$type)
                {
                    return true;
                }
                let $switch1 = $.$$.S.Type.GetTypeCode(T.$type);
                switch($switch1)
                {
                    case 3/*TypeCode.Boolean*/:
                    case 6/*TypeCode.Byte*/:
                    case 4/*TypeCode.Char*/:
                    case 7/*TypeCode.Int16*/:
                    case 9/*TypeCode.Int32*/:
                    case 5/*TypeCode.SByte*/:
                    case 13/*TypeCode.Single*/:
                    case 8/*TypeCode.UInt16*/:
                    case 10/*TypeCode.UInt32*/:
                    return true;
                    case 14/*TypeCode.Double*/:
                    case 11/*TypeCode.Int64*/:
                    case 12/*TypeCode.UInt64*/:
                    return $.$$.S.IntPtr.Size === 8;
                    default:
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885819406)
            
            //--TRIMMABLE-BOUNDARY-START(4295884814)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852110)
                    this.IsWriteAtomic = $.$scc.SCC.ConcurrentDictionaryTypeProps$$(T).IsWriteAtomicPrivate();
                    //--TRIMMABLE-BOUNDARY-END(8590852110)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295884814)
            
            static $H = 917518;
            static $h = 917518;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885819406),
    {
      "r": 262145,
      "n": "IsWriteAtomicPrivate",
      "d": this.$h,
      "H": 12885819406,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885819406)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852110),
    {
      "t": 262145,
      "n": "IsWriteAtomic",
      "d": this.$h,
      "H": 8590852110,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590852110)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 917518,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionaryTypeProps<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionaryTypeProps$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917518)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179662)
        $asm.$cls(`$scc.SCC.IDictionaryDebugView<,>`, (TKey, TValue) => $asm.$gt(`$scc.SCC.IDictionaryDebugView<,>`, [TKey, TValue], ($self) => class IDictionaryDebugView$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296146958)
            /*IDictionary<TKey, TValue>*/ _dictionary = null;
            //--TRIMMABLE-BOUNDARY-END(4296146958)
            
            //--TRIMMABLE-BOUNDARY-START(8591114254)
            $ctor$1(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591114254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (dictionary === null)
                    {
                        $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("dictionary");
                    }
                    this._dictionary = dictionary;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591114254)
            
            //--TRIMMABLE-BOUNDARY-START(21476016142)
            /*DebugViewDictionaryItem<TKey, TValue>[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181048846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let keyValuePairs = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$(TKey, TValue)), null, [this._dictionary.SCG$ICollection$$$Count], null);
                this._dictionary.SCG$ICollection$$$CopyTo(keyValuePairs, 0);
                /*var*/ let items = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scc.SCG.DebugViewDictionaryItem$$$(TKey, TValue)), null, [keyValuePairs.length], null);
                for(/*int*/ let i = 0; i < items.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(items, new ($.$scc.SCG.DebugViewDictionaryItem$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(keyValuePairs, i)), i);
                }
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016142)
            
            static $H = 1179662;
            static $h = 1179662;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476016142),
    {
      "p": $.$typeArray($.$scc.SCG.DebugViewDictionaryItem$$$(TKey, TValue)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17181048846,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 21476016142,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476016142)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296146958),
    {
      "t": $.$$.SCG.IDictionary$$$(TKey, TValue).$h,
      "n": "_dictionary",
      "d": this.$h,
      "H": 4296146958,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146958)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591114254),
    {
      "p": [
        {
          "n": "dictionary",
          "p": $.$$.SCG.IDictionary$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8591114254,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591114254)
  ],
  "s": [
    {
      "h": TKey?.$h??1572864,
      "n": "TKey",
      "f": 64
    },
    {
      "h": TValue?.$h??1638400,
      "n": "TValue"
    }
  ],
  "r": 2,
  "H": 1179662,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.IDictionaryDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}IDictionaryDebugView$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1179662)
        
        

        //--TRIMMABLE-BOUNDARY-START(983054)
        $asm.$cls(`$scc.SCC.ConcurrentStack<>`, (T) => $asm.$gt(`$scc.SCC.ConcurrentStack<>`, [T], ($self) => class ConcurrentStack$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(1048590)
            static $_Node;
            static get Node()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048590);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentStack$$(T);
                return $cls.$_Node ??= $asm.$ncls(`$scc.SCC.ConcurrentStack<${T?.$fullName}>.Node`, ($self) => class Node extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590983182)
                    /*T*/ _value = $.$default(T);
                    //--TRIMMABLE-BOUNDARY-END(8590983182)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015886)
                    /*Node?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(4296015886)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885950478)
                    $ctor$1(/*T*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885950478);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._value = value;
                            this._next = null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885950478)
                    
                    static $H = 1048590;
                    static $h = 1048590;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590983182),
    {
      "t": T?.$h??1572864,
      "n": "_value",
      "d": 1048590,
      "H": 8590983182,
      "h": Number(BigInt(1048590)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590983182),
//--TRIMMABLE-BOUNDARY-START(4296015886),
    {
      "t": 1048590,
      "n": "_next",
      "d": 1048590,
      "H": 4296015886,
      "h": Number(BigInt(1048590)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296015886)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885950478),
    {
      "p": [
        {
          "n": "value",
          "p": T?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048590,
      "H": 12885950478,
      "h": Number(BigInt(1048590)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885950478)
  ],
  "d": 983054,
  "H": 1048590,
  "h": 1048590
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>+Node`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentStack$${T?.$getFullName(separator)}$${separator}Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048590)
            
            //--TRIMMABLE-BOUNDARY-START(4295950350)
            /*Node?*/ _head = null;
            //--TRIMMABLE-BOUNDARY-END(4295950350)
            
            //--TRIMMABLE-BOUNDARY-START(17180852238)
            /*int*/ static BACKOFF_MAX_YIELDS = 8;
            //--TRIMMABLE-BOUNDARY-END(17180852238)
            
            //--TRIMMABLE-BOUNDARY-START(8590917646)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917646);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917646)
            
            //--TRIMMABLE-BOUNDARY-START(12885884942)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884942);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884942)
            
            //--TRIMMABLE-BOUNDARY-START(64425492494)
            /*void */ InitializeFromCollection(/*IEnumerable<T>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let lastNode = null;
                let $en1 = collection.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let element = $en1.SCG$IEnumerator$$$Current;
                    {
                        /*Node*/ let newNode = new ($.$scc.SCC.ConcurrentStack$$(T).Node)().$ctor$1(element);
                        newNode._next = lastNode;
                        lastNode = newNode;
                    }
                }
                this._head = lastNode;
            }
            //--TRIMMABLE-BOUNDARY-END(64425492494)
            
            //--TRIMMABLE-BOUNDARY-START(68720459790)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._head === null;
            }
            //--TRIMMABLE-BOUNDARY-END(68720459790)
            
            //--TRIMMABLE-BOUNDARY-START(34360721422)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                for(/*Node?*/ let curr = this._head; curr !== null; curr = curr._next)
                {
                    count++;
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721422)
            
            //--TRIMMABLE-BOUNDARY-START(120260067342)
            /*bool */ get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(120260067342)
            
            //--TRIMMABLE-BOUNDARY-START(124555034638)
            /*object */ get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034638)
            
            //--TRIMMABLE-BOUNDARY-START(21475819534)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._head = null;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819534)
            
            //--TRIMMABLE-BOUNDARY-START(98785230862)
            /*void */ SC$1$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                (this.ToList()).SC$1$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(98785230862)
            
            //--TRIMMABLE-BOUNDARY-START(30065754126)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToList().CopyTo$1(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754126)
            
            //--TRIMMABLE-BOUNDARY-START(73015427086)
            /*void */ Push(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node*/ let newNode = new ($.$scc.SCC.ConcurrentStack$$(T).Node)().$ctor$1(item);
                newNode._next = this._head;
                if ($.$$.ST$1.Interlocked.CompareExchange$14($.$scc.SCC.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.SCC.ConcurrentStack$$(T).Node), newNode, newNode._next) === newNode._next)
                {
                    return;
                }
                this.PushCore(newNode, newNode);
            }
            //--TRIMMABLE-BOUNDARY-END(73015427086)
            
            //--TRIMMABLE-BOUNDARY-START(85900328974)
            /*void */ PushRange$1(/*T[]*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900328974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(items, "items");
                this.PushRange(items, 0, items.length);
            }
            //--TRIMMABLE-BOUNDARY-END(85900328974)
            
            //--TRIMMABLE-BOUNDARY-START(81605361678)
            /*void */ PushRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return;
                }
                /*Node*/ let head, tail;
                head = tail = new ($.$scc.SCC.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, startIndex));
                for(/*int*/ let i = ((startIndex + 1) | 0); i < ((startIndex + count) | 0); i++)
                {
                    /*Node*/ let node = new ($.$scc.SCC.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, i));
                    node._next = head;
                    head = node;
                }
                tail._next = this._head;
                if ($.$$.ST$1.Interlocked.CompareExchange$14($.$scc.SCC.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.SCC.ConcurrentStack$$(T).Node), head, tail._next) === tail._next)
                {
                    return;
                }
                this.PushCore(head, tail);
            }
            //--TRIMMABLE-BOUNDARY-END(81605361678)
            
            //--TRIMMABLE-BOUNDARY-START(77310394382)
            /*void */ PushCore(/*Node*/ head, /*Node*/ tail)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310394382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpinWait*/ let spin = new $.$$.ST$1.SpinWait();
                do
                {
                    spin.SpinOnce$1(-1);
                    tail._next = this._head;
                }
                while($.$$.ST$1.Interlocked.CompareExchange$14($.$scc.SCC.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.SCC.ConcurrentStack$$(T).Node), head, tail._next) !== tail._next);
                if ($.$scc.SCC.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPushFailed(spin.Count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310394382)
            
            //--TRIMMABLE-BOUNDARY-START(171799674894)
            static /*void */ ValidatePushPopRangeInput(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799674894);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(items, "items");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, count, "count");
                /*int*/ let length = items.length;
                $.$$.S.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.S.Int32, startIndex, length, "startIndex");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, startIndex, "startIndex");
                if (((length - count) | 0) < startIndex)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentStack_PushPopRange_InvalidCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799674894)
            
            //--TRIMMABLE-BOUNDARY-START(90195296270)
            /*bool */ SCC$1$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Push(item);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90195296270)
            
            //--TRIMMABLE-BOUNDARY-START(146029871118)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                else 
                {
                    result.$v = head._value;
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029871118)
            
            //--TRIMMABLE-BOUNDARY-START(150324838414)
            /*bool */ TryPop(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324838414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                if ($.$$.ST$1.Interlocked.CompareExchange$14($.$scc.SCC.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.SCC.ConcurrentStack$$(T).Node), head._next, head) === head)
                {
                    result.$v = head._value;
                    return true;
                }
                return this.TryPopCore(result);
            }
            //--TRIMMABLE-BOUNDARY-END(150324838414)
            
            //--TRIMMABLE-BOUNDARY-START(167504707598)
            /*int */ TryPopRange$1(/*T[]*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504707598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(items, "items");
                return this.TryPopRange(items, 0, items.length);
            }
            //--TRIMMABLE-BOUNDARY-END(167504707598)
            
            //--TRIMMABLE-BOUNDARY-START(163209740302)
            /*int */ TryPopRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209740302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return 0;
                }
                /*Node?*/ let poppedHead;
                /*int*/ let nodesCount = this.TryPopCore$1(count, $.$ref(() => poppedHead, ($v) => poppedHead = $v, $.$scc.SCC.ConcurrentStack$$(T).Node));
                if (nodesCount > 0)
                {
                    $.$scc.SCC.ConcurrentStack$$(T).CopyRemovedItems(poppedHead, items, startIndex, nodesCount);
                }
                return nodesCount;
            }
            //--TRIMMABLE-BOUNDARY-END(163209740302)
            
            //--TRIMMABLE-BOUNDARY-START(154619805710)
            /*bool */ TryPopCore(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619805710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let poppedNode;
                if (this.TryPopCore$1(1, $.$ref(() => poppedNode, ($v) => poppedNode = $v, $.$scc.SCC.ConcurrentStack$$(T).Node)) === 1)
                {
                    result.$v = poppedNode._value;
                    return true;
                }
                result.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154619805710)
            
            //--TRIMMABLE-BOUNDARY-START(158914773006)
            /*int */ TryPopCore$1(/*int*/ count, /*out Node?*/ poppedHead)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914773006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SpinWait*/ let spin = new $.$$.ST$1.SpinWait();
                /*Node?*/ let head;
                /*Node*/ let next;
                /*int*/ let backoff = 1;
                while(true)
                {
                    head = this._head;
                    if (head === null)
                    {
                        if (count === 1 && $.$scc.SCC.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = null;
                        return 0;
                    }
                    next = head;
                    /*int*/ let nodesCount = 1;
                    for(; nodesCount < count && next._next !== null; nodesCount++)
                    {
                        next = next._next;
                    }
                    if ($.$$.ST$1.Interlocked.CompareExchange$14($.$scc.SCC.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.SCC.ConcurrentStack$$(T).Node), next._next, head) === head)
                    {
                        if (count === 1 && $.$scc.SCC.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = head;
                        return nodesCount;
                    }
                    for(/*int*/ let i = 0; i < backoff; i++)
                    {
                        spin.SpinOnce$1(-1);
                    }
                    if (spin.NextSpinWillYield)
                    {
                        backoff = $.$$.S.Random.Shared.Next$1(1, 8/*BACKOFF_MAX_YIELDS*/);
                    }
                    else 
                    {
                        backoff *= 2;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914773006)
            
            //--TRIMMABLE-BOUNDARY-START(25770786830)
            static /*void */ CopyRemovedItems(/*Node*/ head, /*T[]*/ collection, /*int*/ startIndex, /*int*/ nodesCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let current = head;
                for(/*int*/ let i = startIndex; i < ((startIndex + nodesCount) | 0); i++)
                {
                    $.$$.System.Array.$WriteT1.call(collection, current._value, i);
                    current = current._next;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770786830)
            
            //--TRIMMABLE-BOUNDARY-START(94490263566)
            /*bool */ SCC$1$IProducerConsumerCollection$$$TryTake(/*out T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490263566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryPop(item);
            }
            //--TRIMMABLE-BOUNDARY-END(94490263566)
            
            //--TRIMMABLE-BOUNDARY-START(133144969230)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let curr = this._head;
                return curr === null ? $.$$.S.Array.Empty(T) : $.$scc.SCC.ConcurrentStack$$(T).ToList$1(curr).ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(133144969230)
            
            //--TRIMMABLE-BOUNDARY-START(137439936526)
            /*List<T> */ ToList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439936526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.ConcurrentStack$$(T).ToList$1(this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(137439936526)
            
            //--TRIMMABLE-BOUNDARY-START(141734903822)
            static /*List<T> */ ToList$1(/*Node?*/ curr)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<T>*/ let list = new ($.$$.SCG.List$$(T))().$ctor$1();
                while(curr !== null)
                {
                    list.Add(curr._value);
                    curr = curr._next;
                }
                return list;
            }
            //--TRIMMABLE-BOUNDARY-END(141734903822)
            
            //--TRIMMABLE-BOUNDARY-START(55835557902)
            /*IEnumerator<T> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.ConcurrentStack$$(T).GetEnumerator$1(this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(55835557902)
            
            //--TRIMMABLE-BOUNDARY-START(60130525198)
            static /*IEnumerator<T> */ GetEnumerator$1(/*Node?*/ head)
            {
                return new ($.$$.N.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    /*Node?*/ let current = head;
                    while(current !== null)
                    {
                        yield current._value;
                        current = current._next;
                    }
                }.bind(this)).GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525198)
            
            //--TRIMMABLE-BOUNDARY-START(128850001934)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850001934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(128850001934)
            
            //--TRIMMABLE-BOUNDARY-START(4351787009)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            SCC$1$IProducerConsumerCollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4351787009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4351787009)
            
            //--TRIMMABLE-BOUNDARY-START(8646754305)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            SCC$1$IProducerConsumerCollection$$$ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8646754305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToArray(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8646754305)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(8590917646)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917646)
            
            static $H = 983054;
            static $h = 983054;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720459790),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540590606,
        "h": Number(BigInt(this.$h)|0xC00000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "H": 68720459790,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720459790),
//--TRIMMABLE-BOUNDARY-START(34360721422),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950656014,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "H": 34360721422,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360721422),
//--TRIMMABLE-BOUNDARY-START(120260067342),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107375165454,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331650
      },
      "n": "{63111169}.IsSynchronized",
      "o": "SC$1$ICollection$IsSynchronized",
      "d": this.$h,
      "H": 120260067342,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(120260067342),
//--TRIMMABLE-BOUNDARY-START(124555034638),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115965100046,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331650
      },
      "n": "{63111169}.SyncRoot",
      "o": "SC$1$ICollection$SyncRoot",
      "d": this.$h,
      "H": 124555034638,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124555034638)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64425492494),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$(T).$h
        }
      ],
      "n": "InitializeFromCollection",
      "d": this.$h,
      "H": 64425492494,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64425492494),
//--TRIMMABLE-BOUNDARY-START(21475819534),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 21475819534,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475819534),
//--TRIMMABLE-BOUNDARY-START(30065754126),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "H": 30065754126,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065754126),
//--TRIMMABLE-BOUNDARY-START(73015427086),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "Push",
      "d": this.$h,
      "H": 73015427086,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015427086),
//--TRIMMABLE-BOUNDARY-START(85900328974),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": "PushRange",
      "o": "@$1",
      "d": this.$h,
      "H": 85900328974,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900328974),
//--TRIMMABLE-BOUNDARY-START(81605361678),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "PushRange",
      "d": this.$h,
      "H": 81605361678,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605361678),
//--TRIMMABLE-BOUNDARY-START(77310394382),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": 1048590
        },
        {
          "n": "tail",
          "p": 1048590
        }
      ],
      "n": "PushCore",
      "d": this.$h,
      "H": 77310394382,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310394382),
//--TRIMMABLE-BOUNDARY-START(171799674894),
    {
      "r": 65537,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidatePushPopRangeInput",
      "d": this.$h,
      "H": 171799674894,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171799674894),
//--TRIMMABLE-BOUNDARY-START(146029871118),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "H": 146029871118,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029871118),
//--TRIMMABLE-BOUNDARY-START(150324838414),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPop",
      "d": this.$h,
      "H": 150324838414,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324838414),
//--TRIMMABLE-BOUNDARY-START(167504707598),
    {
      "r": 655361,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": "TryPopRange",
      "o": "@$1",
      "d": this.$h,
      "H": 167504707598,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504707598),
//--TRIMMABLE-BOUNDARY-START(163209740302),
    {
      "r": 655361,
      "p": [
        {
          "n": "items",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "TryPopRange",
      "d": this.$h,
      "H": 163209740302,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209740302),
//--TRIMMABLE-BOUNDARY-START(154619805710),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPopCore",
      "d": this.$h,
      "H": 154619805710,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619805710),
//--TRIMMABLE-BOUNDARY-START(158914773006),
    {
      "r": 655361,
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "poppedHead",
          "p": 1048590,
          "f": 2
        }
      ],
      "n": "TryPopCore",
      "o": "@$1",
      "d": this.$h,
      "H": 158914773006,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914773006),
//--TRIMMABLE-BOUNDARY-START(25770786830),
    {
      "r": 65537,
      "p": [
        {
          "n": "head",
          "p": 1048590
        },
        {
          "n": "collection",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "nodesCount",
          "p": 655361
        }
      ],
      "n": "CopyRemovedItems",
      "d": this.$h,
      "H": 25770786830,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770786830),
//--TRIMMABLE-BOUNDARY-START(133144969230),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "H": 133144969230,
      "h": Number(BigInt(this.$h)|0x1F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(133144969230),
//--TRIMMABLE-BOUNDARY-START(137439936526),
    {
      "r": $.$$.SCG.List$$(T).$h,
      "n": "ToList",
      "d": this.$h,
      "H": 137439936526,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439936526),
//--TRIMMABLE-BOUNDARY-START(141734903822),
    {
      "r": $.$$.SCG.List$$(T).$h,
      "p": [
        {
          "n": "curr",
          "p": 1048590
        }
      ],
      "n": "ToList",
      "o": "@$1",
      "d": this.$h,
      "H": 141734903822,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141734903822),
//--TRIMMABLE-BOUNDARY-START(55835557902),
    {
      "r": $.$$.SCG.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "H": 55835557902,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835557902),
//--TRIMMABLE-BOUNDARY-START(60130525198),
    {
      "r": $.$$.SCG.IEnumerator$$(T).$h,
      "p": [
        {
          "n": "head",
          "p": 1048590
        }
      ],
      "n": "GetEnumerator",
      "o": "@$1",
      "d": this.$h,
      "H": 60130525198,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(60130525198)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950350),
    {
      "t": 1048590,
      "n": "_head",
      "d": this.$h,
      "H": 4295950350,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950350),
//--TRIMMABLE-BOUNDARY-START(17180852238),
    {
      "t": 655361,
      "n": "BACKOFF_MAX_YIELDS",
      "d": this.$h,
      "H": 17180852238,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180852238)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917646),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590917646,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917646),
//--TRIMMABLE-BOUNDARY-START(12885884942),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12885884942,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885884942)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 983054,
  "h": this.$h,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 1245198,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCC$1.IProducerConsumerCollection$$(T), $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$scc.SCC.ConcurrentStack$$(T).Node ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentStack$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(983054)
        
        

        //--TRIMMABLE-BOUNDARY-START(262158)
        $asm.$cls(`$scc.SCC.ConcurrentBag<>`, (T) => $asm.$gt(`$scc.SCC.ConcurrentBag<>`, [T], ($self) => class ConcurrentBag$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590196750)
            /*ThreadLocal<WorkStealingQueue>*/ _locals = null;
            //--TRIMMABLE-BOUNDARY-END(8590196750)
            
            //--TRIMMABLE-BOUNDARY-START(12885164046)
            /*WorkStealingQueue?*/ _workStealingQueues = null;
            //--TRIMMABLE-BOUNDARY-END(12885164046)
            
            //--TRIMMABLE-BOUNDARY-START(4295229454)
            /*long*/ _emptyToNonEmptyListTransitionCount = 0n;
            //--TRIMMABLE-BOUNDARY-END(4295229454)
            
            //--TRIMMABLE-BOUNDARY-START(17180131342)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131342);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._locals = new ($.$$.ST$1.ThreadLocal$$($.$scc.SCC.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131342)
            
            //--TRIMMABLE-BOUNDARY-START(21475098638)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475098638);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._locals = new ($.$$.ST$1.ThreadLocal$$($.$scc.SCC.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                    /*WorkStealingQueue*/ let queue = this.GetCurrentThreadWorkStealingQueue(true);
                    let $en1 = collection.SCG$IEnumerable$$$GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en1.SCG$IEnumerator$$$Current;
                        {
                            queue.LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.S.Int64));
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098638)
            
            //--TRIMMABLE-BOUNDARY-START(25770065934)
            /*void */ Add(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770065934);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetCurrentThreadWorkStealingQueue(true).LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.S.Int64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065934)
            
            //--TRIMMABLE-BOUNDARY-START(115964379150)
            /*bool */ SCC$1$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add(item);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(115964379150)
            
            //--TRIMMABLE-BOUNDARY-START(171798953998)
            /*bool */ TryTake(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798953998);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPop(result)) || this.TrySteal(result, true);
            }
            //--TRIMMABLE-BOUNDARY-END(171798953998)
            
            //--TRIMMABLE-BOUNDARY-START(158914052110)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPeek(result)) || this.TrySteal(result, false);
            }
            //--TRIMMABLE-BOUNDARY-END(158914052110)
            
            //--TRIMMABLE-BOUNDARY-START(94489542670)
            /*WorkStealingQueue? */ GetCurrentThreadWorkStealingQueue(/*bool*/ forceCreate)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489542670);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._locals.Value ?? (forceCreate ? this.CreateWorkStealingQueueForCurrentThread() : null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489542670)
            
            //--TRIMMABLE-BOUNDARY-START(47244902414)
            /*WorkStealingQueue */ CreateWorkStealingQueueForCurrentThread()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(GlobalQueuesLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.GlobalQueuesLock)
                    {
                        /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                        /*WorkStealingQueue?*/ let queue = head !== null ? this.GetUnownedWorkStealingQueue() : null;
                        if (queue === null)
                        {
                            this._workStealingQueues = queue = new ($.$scc.SCC.ConcurrentBag$$(T).WorkStealingQueue)().$ctor$1(head);
                        }
                        this._locals.Value = queue;
                        return queue;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.GlobalQueuesLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244902414)
            
            //--TRIMMABLE-BOUNDARY-START(103079477262)
            /*WorkStealingQueue? */ GetUnownedWorkStealingQueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477262);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let currentThreadId = $.$$.S.Environment.CurrentManagedThreadId;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._ownerThreadId === currentThreadId)
                    {
                        return queue;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(103079477262)
            
            //--TRIMMABLE-BOUNDARY-START(163209019406)
            /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209019406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.SCC.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    if (take)
                    {
                        $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryTakeSteals();
                    }
                    else 
                    {
                        $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryPeekSteals();
                    }
                }
                while(true)
                {
                    /*long*/ let initialEmptyToNonEmptyCounts = $.$$.ST$1.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.S.Int64));
                    /*WorkStealingQueue?*/ let localQueue = this.GetCurrentThreadWorkStealingQueue(false);
                    /*bool*/ let gotItem = localQueue === null ? $.$scc.SCC.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, null, result, take) : ($.$scc.SCC.ConcurrentBag$$(T).TryStealFromTo(localQueue._nextQueue, null, result, take) || $.$scc.SCC.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, localQueue, result, take));
                    if (gotItem)
                    {
                        return true;
                    }
                    if ($.$$.ST$1.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.S.Int64)) === initialEmptyToNonEmptyCounts)
                    {
                        return false;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209019406)
            
            //--TRIMMABLE-BOUNDARY-START(167503986702)
            static /*bool */ TryStealFromTo(/*WorkStealingQueue?*/ startInclusive, /*WorkStealingQueue?*/ endExclusive, /*out T*/ result, /*bool*/ take)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986702);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*WorkStealingQueue?*/ let queue = startInclusive; queue !== endExclusive; queue = queue._nextQueue)
                {
                    if (queue.TrySteal(result, take))
                    {
                        return true;
                    }
                }
                result.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(167503986702)
            
            //--TRIMMABLE-BOUNDARY-START(38654967822)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                    /*int*/ let count = this.DangerousCount;
                    if (index > ((array.length - count) | 0))
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    try
                    {
                        /*int*/ let copied = this.CopyFromEachQueueToArray(array, index);
                        $.$$.SD.Debug.Assert$4(copied === count, "copied == count");
                    }
                    catch(e)
                    {
                        throw new $.$$.S.InvalidCastException().$ctor$11(e.Message, e);
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654967822)
            
            //--TRIMMABLE-BOUNDARY-START(34360000526)
            /*int */ CopyFromEachQueueToArray(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let i = index;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    i += queue.DangerousCopyTo(array, i);
                }
                return ((i - index) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(34360000526)
            
            //--TRIMMABLE-BOUNDARY-START(120259346446)
            /*void */ SC$1$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T[]?*/ let szArray = $.$as(array, $.$typeArray(T));
                if (szArray !== null)
                {
                    this.CopyTo(szArray, index);
                    return;
                }
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToArray().CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(120259346446)
            
            //--TRIMMABLE-BOUNDARY-START(154619084814)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084814);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues !== null)
                {
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        this.FreezeBag($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                        /*int*/ let count = this.DangerousCount;
                        if (count > 0)
                        {
                            /*var*/ let arr = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                            /*int*/ let copied = this.CopyFromEachQueueToArray(arr, 0);
                            $.$$.SD.Debug.Assert$4(copied === count, "copied == count");
                            return arr;
                        }
                    }
                    finally
                    {
                        {
                            this.UnfreezeBag(lockTaken);
                        }
                    }
                }
                return $.$$.S.Array.Empty(T);
            }
            //--TRIMMABLE-BOUNDARY-END(154619084814)
            
            //--TRIMMABLE-BOUNDARY-START(30065033230)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    local.LocalClear();
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        /*T?*/ let ignored;
                        while(queue.TrySteal($.$ref(() => ignored, ($v) => ignored = $v, T), true))
                        {
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033230)
            
            //--TRIMMABLE-BOUNDARY-START(98784509966)
            /*IEnumerator<T> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784509966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.ToArray()).SCG$IEnumerable$$$GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784509966)
            
            //--TRIMMABLE-BOUNDARY-START(150324117518)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324117518);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324117518)
            
            //--TRIMMABLE-BOUNDARY-START(42949935118)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._workStealingQueues === null)
                {
                    return 0;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                    return this.DangerousCount;
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935118)
            
            //--TRIMMABLE-BOUNDARY-START(51539869710)
            /*int */ get DangerousCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    //checked
                    {
                        count += queue.DangerousCount;
                    }
                }
                $.$$.SD.Debug.Assert$4(count >= 0, "count >= 0");
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(51539869710)
            
            //--TRIMMABLE-BOUNDARY-START(111669411854)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    if (!local.IsEmpty)
                    {
                        return false;
                    }
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return true;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (!queue.IsEmpty)
                        {
                            return false;
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(111669411854)
            
            //--TRIMMABLE-BOUNDARY-START(141734182926)
            /*bool */ get SC$1$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(141734182926)
            
            //--TRIMMABLE-BOUNDARY-START(146029150222)
            /*object */ get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215630);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(146029150222)
            
            //--TRIMMABLE-BOUNDARY-START(107374444558)
            /*object */ get GlobalQueuesLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._locals !== null, "_locals != null");
                return this._locals;
            }
            //--TRIMMABLE-BOUNDARY-END(107374444558)
            
            //--TRIMMABLE-BOUNDARY-START(55834837006)
            /*void */ FreezeBag(/*ref bool*/ lockTaken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!$.$$.ST$1.Monitor.IsEntered(this.GlobalQueuesLock), "!Monitor.IsEntered(GlobalQueuesLock)");
                $.$$.ST$1.Monitor.Enter(this.GlobalQueuesLock, lockTaken);
                /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    $.$$.ST$1.Monitor.Enter(queue, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => queue._frozen, ($v) => queue._frozen = $v, null, true));
                }
                $.$$.ST$1.Interlocked.MemoryBarrier();
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._currentOp !== 0/*Operation.None*/)
                    {
                        /*SpinWait*/ let spinner = new $.$$.ST$1.SpinWait();
                        do
                        {
                            spinner.SpinOnce();
                        }
                        while(queue._currentOp !== 0/*Operation.None*/);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837006)
            
            //--TRIMMABLE-BOUNDARY-START(176093921294)
            /*void */ UnfreezeBag(/*bool*/ lockTaken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this.GlobalQueuesLock) === lockTaken, "Monitor.IsEntered(GlobalQueuesLock) == lockTaken");
                if (lockTaken)
                {
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (queue._frozen)
                        {
                            queue._frozen = false;
                            $.$$.ST$1.Monitor.Exit(queue);
                        }
                    }
                    $.$$.ST$1.Monitor.Exit(this.GlobalQueuesLock);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093921294)
            
            //--TRIMMABLE-BOUNDARY-START(393230)
            static $_WorkStealingQueue;
            static get WorkStealingQueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(393230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentBag$$(T);
                return $cls.$_WorkStealingQueue ??= $asm.$ncls(`$scc.SCC.ConcurrentBag<${T?.$fullName}>.WorkStealingQueue`, ($self) => class WorkStealingQueue extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(77309804558)
                    /*int*/ static InitialSize = 32;
                    //--TRIMMABLE-BOUNDARY-END(77309804558)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489673742)
                    /*int*/ static StartIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(94489673742)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475229710)
                    /*int*/ _headIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(21475229710)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950066190)
                    /*int*/ _tailIndex = 2147483647;
                    //--TRIMMABLE-BOUNDARY-END(42950066190)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590327822)
                    /*T[]*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(8590327822)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770197006)
                    /*int*/ _mask = 31;
                    //--TRIMMABLE-BOUNDARY-END(25770197006)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295360526)
                    /*int*/ _addTakeCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295360526)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655098894)
                    /*int*/ _stealCount = 0;
                    //--TRIMMABLE-BOUNDARY-END(38655098894)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885295118)
                    /*Operation*/ _currentOp = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885295118)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180262414)
                    /*bool*/ _frozen = false;
                    //--TRIMMABLE-BOUNDARY-END(17180262414)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065164302)
                    /*WorkStealingQueue?*/ _nextQueue = null;
                    //--TRIMMABLE-BOUNDARY-END(30065164302)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360131598)
                    /*int*/ _ownerThreadId = 0;
                    //--TRIMMABLE-BOUNDARY-END(34360131598)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245033486)
                    $ctor$1(/*WorkStealingQueue?*/ nextQueue)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245033486);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._ownerThreadId = $.$$.S.Environment.CurrentManagedThreadId;
                            this._nextQueue = nextQueue;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245033486)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604771854)
                    /*bool */ get IsEmpty()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014837262);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return ((this._headIndex - this._tailIndex) | 0) >= 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604771854)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194706446)
                    /*void */ LocalPush(/*T*/ item, /*ref long*/ emptyToNonEmptyListTransitionCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90194706446);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.S.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            $.$$.ST$1.Interlocked.Exchange$14($.$scc.SCC.ConcurrentBag$$(T).Operation, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$scc.SCC.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null, true), 1/*Operation.Add*/);
                            /*int*/ let tail = this._tailIndex;
                            if (tail === 2147483647/*int.MaxValue*/)
                            {
                                this._currentOp = 0/*Operation.None*/;
                                //lock(this)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(this)
                                    {
                                        $.$$.SD.Debug.Assert$4(this._tailIndex === tail, "No other thread should be changing _tailIndex");
                                        this._headIndex &= this._mask;
                                        this._tailIndex = tail &= this._mask;
                                        $.$$.SD.Debug.Assert$4(((this._headIndex - this._tailIndex) | 0) <= 0, "_headIndex - _tailIndex <= 0");
                                        $.$$.ST$1.Interlocked.Exchange$14($.$scc.SCC.ConcurrentBag$$(T).Operation, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$scc.SCC.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null, true), 1/*Operation.Add*/);
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(this)
                                }
                            }
                            /*int*/ let head = this._headIndex;
                            if (!this._frozen && (((head - (((tail - 1) | 0))) | 0) < 0) && (((tail - (((head + this._mask) | 0))) | 0) < 0))
                            {
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.ST$1.Monitor.Enter(this, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                                head = this._headIndex;
                                /*int*/ let count = ((tail - head) | 0);
                                if (count >= this._mask)
                                {
                                    /*var*/ let newArray = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._array.length << 1], null);
                                    /*int*/ let headIdx = head & this._mask;
                                    if (headIdx === 0)
                                    {
                                        $.$$.S.Array.Copy$2(this._array, newArray, this._array.length);
                                    }
                                    else 
                                    {
                                        $.$$.S.Array.Copy(this._array, headIdx, newArray, 0, ((this._array.length - headIdx) | 0));
                                        $.$$.S.Array.Copy(this._array, 0, newArray, ((this._array.length - headIdx) | 0), headIdx);
                                    }
                                    this._array = newArray;
                                    this._headIndex = 0;
                                    this._tailIndex = tail = count;
                                    this._mask = (this._mask << 1) | 1;
                                }
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                                if (count === 0)
                                {
                                    $.$$.ST$1.Interlocked.Increment$1(emptyToNonEmptyListTransitionCount);
                                }
                                this._addTakeCount -= this._stealCount;
                                this._stealCount = 0;
                            }
                            //checked
                            {
                                this._addTakeCount++;
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.ST$1.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194706446)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899739150)
                    /*void */ LocalClear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85899739150);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.S.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        //lock(this)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this)
                            {
                                if (((this._headIndex - this._tailIndex) | 0) < 0)
                                {
                                    this._headIndex = this._tailIndex = 2147483647/*StartIndex*/;
                                    this._addTakeCount = this._stealCount = 0;
                                    $.$$.S.Array.Clear$1(this._array);
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899739150)
                    
                    //--TRIMMABLE-BOUNDARY-START(103079608334)
                    /*bool */ TryLocalPop(/*out T*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103079608334);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.S.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) >= 0)
                        {
                            result.$v = $.$default(T);
                            return false;
                        }
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            this._currentOp = 2/*Operation.Take*/;
                            $.$$.ST$1.Interlocked.Exchange$3($.$ref(() => this._tailIndex, ($v) => this._tailIndex = $v, $.$$.S.Int32), --tail);
                            if (!this._frozen && (((this._headIndex - tail) | 0) < 0))
                            {
                                /*int*/ let idx = tail & this._mask;
                                result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                this._addTakeCount--;
                                return true;
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.ST$1.Monitor.Enter(this, $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                                if (((this._headIndex - tail) | 0) <= 0)
                                {
                                    /*int*/ let idx = tail & this._mask;
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                    //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                    this._addTakeCount--;
                                    return true;
                                }
                                else 
                                {
                                    this._tailIndex = ((tail + 1) | 0);
                                    result.$v = $.$default(T);
                                    return false;
                                }
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.ST$1.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103079608334)
                    
                    //--TRIMMABLE-BOUNDARY-START(98784641038)
                    /*bool */ TryLocalPeek(/*out T*/ result)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98784641038);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.S.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) < 0)
                        {
                            //lock(this)
                            try
                            {
                                $.$$.ST$1.Monitor.Enter$1(this)
                                {
                                    if (((this._headIndex - tail) | 0) < 0)
                                    {
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, (((tail - 1) | 0)) & this._mask);
                                        return true;
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.ST$1.Monitor.Exit(this)
                            }
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98784641038)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374575630)
                    /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374575630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(this)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1(this)
                            {
                                /*int*/ let head = this._headIndex;
                                if (take)
                                {
                                    if ((((head - (((this._tailIndex - 2) | 0))) | 0) >= 0) && this._currentOp === 1/*Operation.Add*/)
                                    {
                                        /*SpinWait*/ let spinner = new $.$$.ST$1.SpinWait();
                                        do
                                        {
                                            spinner.SpinOnce();
                                        }
                                        while(this._currentOp === 1/*Operation.Add*/);
                                    }
                                    $.$$.ST$1.Interlocked.Exchange$3($.$ref(() => this._headIndex, ($v) => this._headIndex = $v, $.$$.S.Int32), ((head + 1) | 0));
                                    if (head < this._tailIndex)
                                    {
                                        /*int*/ let idx = head & this._mask;
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                        //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                        this._stealCount++;
                                        return true;
                                    }
                                    else 
                                    {
                                        this._headIndex = head;
                                    }
                                }
                                else if (head < this._tailIndex)
                                {
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, head & this._mask);
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit(this)
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374575630)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540000782)
                    /*int */ DangerousCopyTo(/*T[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540000782);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        $.$$.SD.Debug.Assert$4(this._frozen, "_frozen");
                        $.$$.SD.Debug.Assert$4(array !== null, "array != null");
                        $.$$.SD.Debug.Assert$4(arrayIndex >= 0 && arrayIndex <= array.length, "arrayIndex >= 0 && arrayIndex <= array.Length");
                        /*int*/ let headIndex = this._headIndex;
                        /*int*/ let count = this.DangerousCount;
                        $.$$.SD.Debug.Assert$4(count === (((this._tailIndex - this._headIndex) | 0)) || count === (((((this._tailIndex + 1) | 0) - this._headIndex) | 0)), "Count should be the same as tail - head, but allowing for the possibility that " + "a peek decremented _tailIndex before seeing that a freeze was happening.");
                        $.$$.SD.Debug.Assert$4(arrayIndex <= ((array.length - count) | 0), "arrayIndex <= array.Length - count");
                        for(/*int*/ let i = ((((arrayIndex + count) | 0) - 1) | 0); i >= arrayIndex; i--)
                        {
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(this._array, headIndex++ & this._mask), i);
                        }
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540000782)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834968078)
                    /*int */ get DangerousCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424902670);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        /*int*/ let stealCount = this._stealCount;
                        /*int*/ let addTakeCount = this._addTakeCount;
                        /*int*/ let count = ((addTakeCount - stealCount) | 0);
                        $.$$.SD.Debug.Assert$1(count >= 0, `Expected _addTakeCount (${$.$strNN(addTakeCount)}) >= _stealCount (${$.$strNN(stealCount)}).`);
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834968078)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590327822)
                        this._array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [32/*InitialSize*/], null);
                        //--TRIMMABLE-BOUNDARY-END(8590327822)
                        
                    }
                    static $H = 393230;
                    static $h = 393230;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(81604771854),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73014837262,
        "h": Number(BigInt(393230)|0x1100000000n),
        "f": 50331656
      },
      "n": "IsEmpty",
      "d": 393230,
      "H": 81604771854,
      "h": Number(BigInt(393230)|0x1300000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(81604771854),
//--TRIMMABLE-BOUNDARY-START(55834968078),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64424902670,
        "h": Number(BigInt(393230)|0xF00000000n),
        "f": 50331656
      },
      "n": "DangerousCount",
      "d": 393230,
      "H": 55834968078,
      "h": Number(BigInt(393230)|0xD00000000n),
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55834968078)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90194706446),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "emptyToNonEmptyListTransitionCount",
          "p": 917505,
          "f": 4
        }
      ],
      "n": "LocalPush",
      "d": 393230,
      "H": 90194706446,
      "h": Number(BigInt(393230)|0x1500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194706446),
//--TRIMMABLE-BOUNDARY-START(85899739150),
    {
      "r": 65537,
      "n": "LocalClear",
      "d": 393230,
      "H": 85899739150,
      "h": Number(BigInt(393230)|0x1400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85899739150),
//--TRIMMABLE-BOUNDARY-START(103079608334),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryLocalPop",
      "d": 393230,
      "H": 103079608334,
      "h": Number(BigInt(393230)|0x1800000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(103079608334),
//--TRIMMABLE-BOUNDARY-START(98784641038),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryLocalPeek",
      "d": 393230,
      "H": 98784641038,
      "h": Number(BigInt(393230)|0x1700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(98784641038),
//--TRIMMABLE-BOUNDARY-START(107374575630),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TrySteal",
      "d": 393230,
      "H": 107374575630,
      "h": Number(BigInt(393230)|0x1900000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(107374575630),
//--TRIMMABLE-BOUNDARY-START(51540000782),
    {
      "r": 655361,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "DangerousCopyTo",
      "d": 393230,
      "H": 51540000782,
      "h": Number(BigInt(393230)|0xC00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540000782)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(77309804558),
    {
      "t": 655361,
      "n": "InitialSize",
      "d": 393230,
      "H": 77309804558,
      "h": Number(BigInt(393230)|0x1200000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(77309804558),
//--TRIMMABLE-BOUNDARY-START(94489673742),
    {
      "t": 655361,
      "n": "StartIndex",
      "d": 393230,
      "H": 94489673742,
      "h": Number(BigInt(393230)|0x1600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(94489673742),
//--TRIMMABLE-BOUNDARY-START(21475229710),
    {
      "t": 655361,
      "n": "_headIndex",
      "d": 393230,
      "H": 21475229710,
      "h": Number(BigInt(393230)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229710),
//--TRIMMABLE-BOUNDARY-START(42950066190),
    {
      "t": 655361,
      "n": "_tailIndex",
      "d": 393230,
      "H": 42950066190,
      "h": Number(BigInt(393230)|0xA00000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(42950066190),
//--TRIMMABLE-BOUNDARY-START(8590327822),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": 393230,
      "H": 8590327822,
      "h": Number(BigInt(393230)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327822),
//--TRIMMABLE-BOUNDARY-START(25770197006),
    {
      "t": 655361,
      "n": "_mask",
      "d": 393230,
      "H": 25770197006,
      "h": Number(BigInt(393230)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770197006),
//--TRIMMABLE-BOUNDARY-START(4295360526),
    {
      "t": 655361,
      "n": "_addTakeCount",
      "d": 393230,
      "H": 4295360526,
      "h": Number(BigInt(393230)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360526),
//--TRIMMABLE-BOUNDARY-START(38655098894),
    {
      "t": 655361,
      "n": "_stealCount",
      "d": 393230,
      "H": 38655098894,
      "h": Number(BigInt(393230)|0x900000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655098894),
//--TRIMMABLE-BOUNDARY-START(12885295118),
    {
      "t": 327694,
      "n": "_currentOp",
      "d": 393230,
      "H": 12885295118,
      "h": Number(BigInt(393230)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885295118),
//--TRIMMABLE-BOUNDARY-START(17180262414),
    {
      "t": 262145,
      "n": "_frozen",
      "d": 393230,
      "H": 17180262414,
      "h": Number(BigInt(393230)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180262414),
//--TRIMMABLE-BOUNDARY-START(30065164302),
    {
      "t": 393230,
      "n": "_nextQueue",
      "d": 393230,
      "H": 30065164302,
      "h": Number(BigInt(393230)|0x700000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065164302),
//--TRIMMABLE-BOUNDARY-START(34360131598),
    {
      "t": 655361,
      "n": "_ownerThreadId",
      "d": 393230,
      "H": 34360131598,
      "h": Number(BigInt(393230)|0x800000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360131598)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245033486),
    {
      "p": [
        {
          "n": "nextQueue",
          "p": 393230
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393230,
      "H": 47245033486,
      "h": Number(BigInt(393230)|0xB00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245033486)
  ],
  "d": 262158,
  "H": 393230,
  "h": 393230
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>+WorkStealingQueue`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentBag$${T?.$getFullName(separator)}$${separator}WorkStealingQueue`; }
                }, $cls, ($v) => $cls.$_WorkStealingQueue = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(393230)
            
            //--TRIMMABLE-BOUNDARY-START(327694)
            static $_Operation;
            static get Operation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentBag$$(T);
                return $cls.$_Operation ??= $asm.$nstr(`$scc.SCC.ConcurrentBag<${T?.$fullName}>.Operation`, ($self) => class Operation extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static None = 0;
                    static Add = 1;
                    static Take = 2;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(327694);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Add": 1n,
                            "Take": 2n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295294990)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295294990);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295294990)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295294990)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295294990)
                    
                    static $H = 327694;
                    static $h = 327694;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885229582),
    {
      "t": 327694,
      "n": "None",
      "d": 327694,
      "H": 12885229582,
      "h": Number(BigInt(327694)|0x300000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229582),
//--TRIMMABLE-BOUNDARY-START(8590262286),
    {
      "t": 327694,
      "n": "Add",
      "d": 327694,
      "H": 8590262286,
      "h": Number(BigInt(327694)|0x200000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262286),
//--TRIMMABLE-BOUNDARY-START(17180196878),
    {
      "t": 327694,
      "n": "Take",
      "d": 327694,
      "H": 17180196878,
      "h": Number(BigInt(327694)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196878)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295294990),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327694,
      "H": 4295294990,
      "h": Number(BigInt(327694)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295294990)
  ],
  "d": 262158,
  "H": 327694,
  "h": 327694
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>+Operation`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentBag$${T?.$getFullName(separator)}$${separator}Operation`; }
                }, $cls, ($v) => $cls.$_Operation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327694)
            
            //--TRIMMABLE-BOUNDARY-START(4351787009)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            SCC$1$IProducerConsumerCollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4351787009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4351787009)
            
            //--TRIMMABLE-BOUNDARY-START(17236688897)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.TryTake(out T)
            SCC$1$IProducerConsumerCollection$$$TryTake()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17236688897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryTake(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17236688897)
            
            //--TRIMMABLE-BOUNDARY-START(8646754305)
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            SCC$1$IProducerConsumerCollection$$$ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8646754305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ToArray(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8646754305)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(17180131342)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180131342)
            
            static $H = 262158;
            static $h = 262158;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949935118),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64424771598,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "H": 42949935118,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949935118),
//--TRIMMABLE-BOUNDARY-START(51539869710),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73014706190,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "DangerousCount",
      "d": this.$h,
      "H": 51539869710,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51539869710),
//--TRIMMABLE-BOUNDARY-START(111669411854),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194575374,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "H": 111669411854,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669411854),
//--TRIMMABLE-BOUNDARY-START(141734182926),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849281038,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331650
      },
      "n": "{63111169}.IsSynchronized",
      "o": "SC$1$ICollection$IsSynchronized",
      "d": this.$h,
      "H": 141734182926,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(141734182926),
//--TRIMMABLE-BOUNDARY-START(146029150222),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137439215630,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331650
      },
      "n": "{63111169}.SyncRoot",
      "o": "SC$1$ICollection$SyncRoot",
      "d": this.$h,
      "H": 146029150222,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(146029150222),
//--TRIMMABLE-BOUNDARY-START(107374444558),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604640782,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331650
      },
      "n": "GlobalQueuesLock",
      "d": this.$h,
      "H": 107374444558,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(107374444558)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770065934),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "Add",
      "d": this.$h,
      "H": 25770065934,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770065934),
//--TRIMMABLE-BOUNDARY-START(171798953998),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryTake",
      "d": this.$h,
      "H": 171798953998,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171798953998),
//--TRIMMABLE-BOUNDARY-START(158914052110),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "H": 158914052110,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914052110),
//--TRIMMABLE-BOUNDARY-START(94489542670),
    {
      "r": 393230,
      "p": [
        {
          "n": "forceCreate",
          "p": 262145
        }
      ],
      "n": "GetCurrentThreadWorkStealingQueue",
      "d": this.$h,
      "H": 94489542670,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489542670),
//--TRIMMABLE-BOUNDARY-START(47244902414),
    {
      "r": 393230,
      "n": "CreateWorkStealingQueueForCurrentThread",
      "d": this.$h,
      "H": 47244902414,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244902414),
//--TRIMMABLE-BOUNDARY-START(103079477262),
    {
      "r": 393230,
      "n": "GetUnownedWorkStealingQueue",
      "d": this.$h,
      "H": 103079477262,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079477262),
//--TRIMMABLE-BOUNDARY-START(163209019406),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TrySteal",
      "d": this.$h,
      "H": 163209019406,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209019406),
//--TRIMMABLE-BOUNDARY-START(167503986702),
    {
      "r": 262145,
      "p": [
        {
          "n": "startInclusive",
          "p": 393230
        },
        {
          "n": "endExclusive",
          "p": 393230
        },
        {
          "n": "result",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "take",
          "p": 262145
        }
      ],
      "n": "TryStealFromTo",
      "d": this.$h,
      "H": 167503986702,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167503986702),
//--TRIMMABLE-BOUNDARY-START(38654967822),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "H": 38654967822,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967822),
//--TRIMMABLE-BOUNDARY-START(34360000526),
    {
      "r": 655361,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyFromEachQueueToArray",
      "d": this.$h,
      "H": 34360000526,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360000526),
//--TRIMMABLE-BOUNDARY-START(154619084814),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "H": 154619084814,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619084814),
//--TRIMMABLE-BOUNDARY-START(30065033230),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 30065033230,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065033230),
//--TRIMMABLE-BOUNDARY-START(98784509966),
    {
      "r": $.$$.SCG.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "H": 98784509966,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784509966),
//--TRIMMABLE-BOUNDARY-START(55834837006),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockTaken",
          "p": 262145,
          "f": 4
        }
      ],
      "n": "FreezeBag",
      "d": this.$h,
      "H": 55834837006,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834837006),
//--TRIMMABLE-BOUNDARY-START(176093921294),
    {
      "r": 65537,
      "p": [
        {
          "n": "lockTaken",
          "p": 262145
        }
      ],
      "n": "UnfreezeBag",
      "d": this.$h,
      "H": 176093921294,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176093921294)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196750),
    {
      "t": $.$$.ST$1.ThreadLocal$$($.$scc.SCC.ConcurrentBag$$(T).WorkStealingQueue).$h,
      "n": "_locals",
      "d": this.$h,
      "H": 8590196750,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196750),
//--TRIMMABLE-BOUNDARY-START(12885164046),
    {
      "t": 393230,
      "n": "_workStealingQueues",
      "d": this.$h,
      "H": 12885164046,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885164046),
//--TRIMMABLE-BOUNDARY-START(4295229454),
    {
      "t": 917505,
      "n": "_emptyToNonEmptyListTransitionCount",
      "d": this.$h,
      "H": 4295229454,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229454)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131342),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17180131342,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131342),
//--TRIMMABLE-BOUNDARY-START(21475098638),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 21475098638,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098638)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 262158,
  "h": this.$h,
  "a": [
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 1245198,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCC$1.IProducerConsumerCollection$$(T), $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$scc.SCC.ConcurrentBag$$(T).WorkStealingQueue, $.$scc.SCC.ConcurrentBag$$(T).Operation ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentBag$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262158)
        
        

        //--TRIMMABLE-BOUNDARY-START(65550)
        $asm.$cls(`$scc.SCC.BlockingCollection<>`, (T) => $asm.$gt(`$scc.SCC.BlockingCollection<>`, [T], ($self) => class BlockingCollection$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590000142)
            /*IProducerConsumerCollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(8590000142)
            
            //--TRIMMABLE-BOUNDARY-START(4295032846)
            /*int*/ _boundedCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(4295032846)
            
            //--TRIMMABLE-BOUNDARY-START(176093724686)
            /*int*/ static NON_BOUNDED = -1;
            //--TRIMMABLE-BOUNDARY-END(176093724686)
            
            //--TRIMMABLE-BOUNDARY-START(21474902030)
            /*SemaphoreSlim?*/ _freeNodes = null;
            //--TRIMMABLE-BOUNDARY-END(21474902030)
            
            //--TRIMMABLE-BOUNDARY-START(30064836622)
            /*SemaphoreSlim*/ _occupiedNodes = null;
            //--TRIMMABLE-BOUNDARY-END(30064836622)
            
            //--TRIMMABLE-BOUNDARY-START(25769869326)
            /*bool*/ _isDisposed = false;
            //--TRIMMABLE-BOUNDARY-END(25769869326)
            
            //--TRIMMABLE-BOUNDARY-START(12884967438)
            /*CancellationTokenSource*/ _consumersCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(12884967438)
            
            //--TRIMMABLE-BOUNDARY-START(34359803918)
            /*CancellationTokenSource*/ _producersCancellationTokenSource = null;
            //--TRIMMABLE-BOUNDARY-END(34359803918)
            
            //--TRIMMABLE-BOUNDARY-START(17179934734)
            /*int*/ _currentAdders = 0;
            //--TRIMMABLE-BOUNDARY-END(17179934734)
            
            //--TRIMMABLE-BOUNDARY-START(90194378766)
            /*int*/ static COMPLETE_ADDING_ON_MASK = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(90194378766)
            
            //--TRIMMABLE-BOUNDARY-START(73014509582)
            /*int */ get BoundedCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259149838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._boundedCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(73014509582)
            
            //--TRIMMABLE-BOUNDARY-START(167503790094)
            /*bool */ get IsAddingCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439019022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return (this._currentAdders === -2147483648/*COMPLETE_ADDING_ON_MASK*/);
            }
            //--TRIMMABLE-BOUNDARY-END(167503790094)
            
            //--TRIMMABLE-BOUNDARY-START(171798757390)
            /*bool */ get IsCompleted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return (this.IsAddingCompleted && (this._occupiedNodes.CurrentCount === 0));
            }
            //--TRIMMABLE-BOUNDARY-END(171798757390)
            
            //--TRIMMABLE-BOUNDARY-START(103079280654)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._occupiedNodes.CurrentCount;
            }
            //--TRIMMABLE-BOUNDARY-END(103079280654)
            
            //--TRIMMABLE-BOUNDARY-START(206158495758)
            /*bool */ get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273593870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(206158495758)
            
            //--TRIMMABLE-BOUNDARY-START(210453463054)
            /*object */ get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(210453463054)
            
            //--TRIMMABLE-BOUNDARY-START(38654771214)
            $ctor$1()
            {
                this.$ctor$3(new ($.$$.SCC$1.ConcurrentQueue$$(T))().$ctor$1());
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654771214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771214)
            
            //--TRIMMABLE-BOUNDARY-START(51539673102)
            $ctor$4(/*int*/ boundedCapacity)
            {
                this.$ctor$2(new ($.$$.SCC$1.ConcurrentQueue$$(T))().$ctor$1(), boundedCapacity);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539673102);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673102)
            
            //--TRIMMABLE-BOUNDARY-START(42949738510)
            $ctor$2(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949738510);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.S.Int32, boundedCapacity, "boundedCapacity");
                    /*int*/ let count = collection.SC$1$ICollection$Count;
                    if (count > boundedCapacity)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.BlockingCollection_ctor_CountMoreThanCapacity);
                    }
                    this.Initialize(collection, boundedCapacity, count);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949738510)
            
            //--TRIMMABLE-BOUNDARY-START(47244705806)
            $ctor$3(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244705806);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.Initialize(collection, -1/*NON_BOUNDED*/, collection.SC$1$ICollection$Count);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244705806)
            
            //--TRIMMABLE-BOUNDARY-START(163208822798)
            /*void */ Initialize(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity, /*int*/ collectionCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208822798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(boundedCapacity > 0 || boundedCapacity === -1/*NON_BOUNDED*/, "boundedCapacity > 0 || boundedCapacity == NON_BOUNDED");
                this._collection = collection;
                this._boundedCapacity = boundedCapacity;
                this._isDisposed = false;
                this._consumersCancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                this._producersCancellationTokenSource = new $.$$.ST$1.CancellationTokenSource().$ctor$1();
                if (boundedCapacity === -1/*NON_BOUNDED*/)
                {
                    this._freeNodes = null;
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(boundedCapacity > 0, "boundedCapacity > 0");
                    this._freeNodes = new $.$$.ST$1.SemaphoreSlim().$ctor$2(((boundedCapacity - collectionCount) | 0));
                }
                this._occupiedNodes = new $.$$.ST$1.SemaphoreSlim().$ctor$2(collectionCount);
            }
            //--TRIMMABLE-BOUNDARY-END(163208822798)
            
            //--TRIMMABLE-BOUNDARY-START(60129607694)
            /*void */ Add$1(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, $.$$.ST$1.CancellationToken.None);
                $.$$.SD.Debug.Assert$4(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            //--TRIMMABLE-BOUNDARY-END(60129607694)
            
            //--TRIMMABLE-BOUNDARY-START(55834640398)
            /*void */ Add(/*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.SD.Debug.Assert$4(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            //--TRIMMABLE-BOUNDARY-END(55834640398)
            
            //--TRIMMABLE-BOUNDARY-START(253403136014)
            /*bool */ TryAdd$3(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403136014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryAddWithNoTimeValidation(item, 0, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(253403136014)
            
            //--TRIMMABLE-BOUNDARY-START(249108168718)
            /*bool */ TryAdd$2(/*T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108168718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryAddWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.S.Int32), $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(249108168718)
            
            //--TRIMMABLE-BOUNDARY-START(244813201422)
            /*bool */ TryAdd$1(/*T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813201422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(244813201422)
            
            //--TRIMMABLE-BOUNDARY-START(240518234126)
            /*bool */ TryAdd(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518234126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(240518234126)
            
            //--TRIMMABLE-BOUNDARY-START(283467907086)
            /*bool */ TryAddWithNoTimeValidation(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283467907086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsAddingCompleted)
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_Completed);
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = true;
                if (this._freeNodes !== null)
                {
                    /*CancellationTokenSource?*/ let linkedTokenSource = null;
                    try
                    {
                        waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(0, new $.$$.ST$1.CancellationToken());
                        if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                        {
                            linkedTokenSource = $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._producersCancellationTokenSource.Token);
                            waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                        }
                    }
                    catch($e)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_Add_ConcurrentCompleteAdd);
                    }
                    finally
                    {
                        {
                            linkedTokenSource?.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*SpinWait*/ let spinner = new $.$$.ST$1.SpinWait();
                    while(true)
                    {
                        /*int*/ let observedAdders = this._currentAdders;
                        if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                        {
                            spinner.Reset();
                            while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                            {
                                spinner.SpinOnce();
                            }
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_Completed);
                        }
                        if ($.$$.ST$1.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.S.Int32), ((observedAdders + 1) | 0), observedAdders) === observedAdders)
                        {
                            $.$$.SD.Debug.Assert$4((((observedAdders + 1) | 0)) <= (~-2147483648/*COMPLETE_ADDING_ON_MASK*/), "The number of concurrent adders thread exceeded the maximum limit.");
                            break;
                        }
                        spinner.SpinOnce$1(-1);
                    }
                    /*bool*/ let addingSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        addingSucceeded = this._collection.SCC$1$IProducerConsumerCollection$$$TryAdd(item);
                        if (!addingSucceeded)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_Add_Failed);
                        }
                    }
                    finally
                    {
                        {
                            if (addingSucceeded)
                            {
                                this._occupiedNodes.Release();
                            }
                            else 
                            {
                                this._freeNodes?.Release();
                            }
                            $.$$.SD.Debug.Assert$4((this._currentAdders & ~-2147483648/*COMPLETE_ADDING_ON_MASK*/) > 0, "(_currentAdders & ~COMPLETE_ADDING_ON_MASK) > 0");
                            $.$$.ST$1.Interlocked.Decrement($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.S.Int32));
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            //--TRIMMABLE-BOUNDARY-END(283467907086)
            
            //--TRIMMABLE-BOUNDARY-START(219043397646)
            /*T */ Take()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043397646);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, $.$$.ST$1.CancellationToken.None))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(219043397646)
            
            //--TRIMMABLE-BOUNDARY-START(223338364942)
            /*T */ Take$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338364942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken))
                {
                    throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(223338364942)
            
            //--TRIMMABLE-BOUNDARY-START(300647776270)
            /*bool */ TryTake$3(/*out T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300647776270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryTake(item, 0, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(300647776270)
            
            //--TRIMMABLE-BOUNDARY-START(296352808974)
            /*bool */ TryTake$2(/*out T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352808974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryTakeWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.S.Int32), $.$$.ST$1.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(296352808974)
            
            //--TRIMMABLE-BOUNDARY-START(292057841678)
            /*bool */ TryTake$1(/*out T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292057841678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, $.$$.ST$1.CancellationToken.None, null);
            }
            //--TRIMMABLE-BOUNDARY-END(292057841678)
            
            //--TRIMMABLE-BOUNDARY-START(287762874382)
            /*bool */ TryTake(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287762874382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, cancellationToken, null);
            }
            //--TRIMMABLE-BOUNDARY-END(287762874382)
            
            //--TRIMMABLE-BOUNDARY-START(330712547342)
            /*bool */ TryTakeWithNoTimeValidation(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken, /*CancellationTokenSource?*/ combinedTokenSource)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712547342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                item.$v = $.$default(T);
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsCompleted)
                {
                    return false;
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = false;
                /*CancellationTokenSource?*/ let linkedTokenSource = combinedTokenSource;
                try
                {
                    waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$2(0);
                    if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                    {
                        linkedTokenSource ??= $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                        waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                    }
                }
                catch($e)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return false;
                }
                finally
                {
                    {
                        if (linkedTokenSource !== null && combinedTokenSource === null)
                        {
                            linkedTokenSource.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*bool*/ let removeSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        removeSucceeded = this._collection.SCC$1$IProducerConsumerCollection$$$TryTake(item);
                        if (!removeSucceeded)
                        {
                            throw new $.$$.S.InvalidOperationException().$ctor$12($.$scc.S.SR.BlockingCollection_Take_CollectionModified);
                        }
                    }
                    finally
                    {
                        {
                            if (removeSucceeded)
                            {
                                if (this._freeNodes !== null)
                                {
                                    $.$$.SD.Debug.Assert$4(this._boundedCapacity !== -1/*NON_BOUNDED*/, "_boundedCapacity != NON_BOUNDED");
                                    this._freeNodes.Release();
                                }
                            }
                            else 
                            {
                                this._occupiedNodes.Release();
                            }
                            if (this.IsCompleted)
                            {
                                this.CancelWaitingConsumers();
                            }
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            //--TRIMMABLE-BOUNDARY-END(330712547342)
            
            //--TRIMMABLE-BOUNDARY-START(68719542286)
            static /*int */ AddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tryAddAnyReturnValue = $.$scc.SCC.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, $.$$.ST$1.CancellationToken.None);
                $.$$.SD.Debug.Assert$4(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(68719542286)
            
            //--TRIMMABLE-BOUNDARY-START(64424574990)
            static /*int */ AddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424574990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let tryAddAnyReturnValue = $.$scc.SCC.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.SD.Debug.Assert$4(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(64424574990)
            
            //--TRIMMABLE-BOUNDARY-START(270583005198)
            static /*int */ TryAddToAny$3(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583005198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.BlockingCollection$$(T).TryAddToAny(collections, item, 0, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(270583005198)
            
            //--TRIMMABLE-BOUNDARY-START(266288037902)
            static /*int */ TryAddToAny$2(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288037902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryAddToAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.S.Int32), $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(266288037902)
            
            //--TRIMMABLE-BOUNDARY-START(261993070606)
            static /*int */ TryAddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993070606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(261993070606)
            
            //--TRIMMABLE-BOUNDARY-START(257698103310)
            static /*int */ TryAddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698103310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(257698103310)
            
            //--TRIMMABLE-BOUNDARY-START(274877972494)
            static /*int */ TryAddToAnyCore(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274877972494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateCollectionsArray(collections, true);
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.S.Environment.TickCount >>> 0);
                }
                /*int*/ let index = $.$scc.SCC.BlockingCollection$$(T).TryAddToAnyFast(collections, item);
                if (index > -1)
                {
                    return index;
                }
                /*CancellationToken[]*/ let collatedCancellationTokens;
                /*List<WaitHandle>*/ let handles = $.$scc.SCC.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, true, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.ST$1.CancellationToken)));
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    index = -1;
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        index = $.$$.ST$1.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        handles.RemoveAt(((handles.Count - 1) | 0));
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                            throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.S$IDisposable$Dispose();
                    }
                    $.$$.SD.Debug.Assert$4((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                    if (index === 258/*WaitHandle.WaitTimeout*/)
                    {
                        return OPERATION_FAILED;
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, index).TryAdd$3(item))
                    {
                        return index;
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.SCC.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                return OPERATION_FAILED;
            }
            //--TRIMMABLE-BOUNDARY-END(274877972494)
            
            //--TRIMMABLE-BOUNDARY-START(279172939790)
            static /*int */ TryAddToAnyFast(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279172939790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._freeNodes === null)
                    {
                        /*bool*/ let result = $.$$.System.Array.$ReadT1.call(collections, i).TryAdd$3(item);
                        $.$$.SD.Debug.Assert$4(result, "result");
                        return i;
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(279172939790)
            
            //--TRIMMABLE-BOUNDARY-START(158913855502)
            static /*List<WaitHandle> */ GetHandles(/*BlockingCollection<T>[]*/ collections, /*CancellationToken*/ externalCancellationToken, /*bool*/ isAddOperation, /*out CancellationToken[]*/ cancellationTokens)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913855502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(collections !== null, "collections != null");
                /*List<WaitHandle>*/ let handlesList = new ($.$$.SCG.List$$($.$$.ST$1.WaitHandle))().$ctor$3(((collections.length + 1) | 0));
                /*List<CancellationToken>*/ let tokensList = new ($.$$.SCG.List$$($.$$.ST$1.CancellationToken))().$ctor$3(((collections.length + 1) | 0));
                tokensList.Add(externalCancellationToken);
                if (isAddOperation)
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        /*BlockingCollection<T>*/ let c = $.$$.System.Array.$ReadT1.call(collections, i);
                        if (c._freeNodes !== null)
                        {
                            handlesList.Add(c._freeNodes.AvailableWaitHandle);
                            tokensList.Add(c._producersCancellationTokenSource.Token);
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(collections, i).IsCompleted)
                        {
                            continue;
                        }
                        handlesList.Add($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle);
                        tokensList.Add($.$$.System.Array.$ReadT1.call(collections, i)._consumersCancellationTokenSource.Token);
                    }
                }
                cancellationTokens.$v = tokensList.ToArray();
                return handlesList;
            }
            //--TRIMMABLE-BOUNDARY-END(158913855502)
            
            //--TRIMMABLE-BOUNDARY-START(335007514638)
            static /*int */ UpdateTimeOut(/*uint*/ startTime, /*int*/ originalWaitMillisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007514638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (originalWaitMillisecondsTimeout === 0)
                {
                    return 0;
                }
                $.$$.SD.Debug.Assert$4(originalWaitMillisecondsTimeout !== -1/*Timeout.Infinite*/, "originalWaitMillisecondsTimeout != Timeout.Infinite");
                /*uint*/ let elapsedMilliseconds = ((($.$$.S.Environment.TickCount >>> 0) - startTime) >>> 0);
                if (elapsedMilliseconds > 2147483647/*int.MaxValue*/)
                {
                    return 0;
                }
                /*int*/ let currentWaitTimeout = ((originalWaitMillisecondsTimeout - (elapsedMilliseconds | 0)) | 0);
                if (currentWaitTimeout <= 0)
                {
                    return 0;
                }
                return currentWaitTimeout;
            }
            //--TRIMMABLE-BOUNDARY-END(335007514638)
            
            //--TRIMMABLE-BOUNDARY-START(231928299534)
            static /*int */ TakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.BlockingCollection$$(T).TakeFromAny(collections, item, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(231928299534)
            
            //--TRIMMABLE-BOUNDARY-START(227633332238)
            static /*int */ TakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633332238);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let returnValue = $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, -1/*Timeout.Infinite*/, true, cancellationToken);
                $.$$.SD.Debug.Assert$4(returnValue >= 0 && returnValue < collections.length, "TryTakeFromAny() was expected to return an index within the bounds of the collections array.");
                return returnValue;
            }
            //--TRIMMABLE-BOUNDARY-END(227633332238)
            
            //--TRIMMABLE-BOUNDARY-START(317827645454)
            static /*int */ TryTakeFromAny$3(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827645454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAny$1(collections, item, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(317827645454)
            
            //--TRIMMABLE-BOUNDARY-START(313532678158)
            static /*int */ TryTakeFromAny$2(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532678158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.S.Int32), false, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(313532678158)
            
            //--TRIMMABLE-BOUNDARY-START(309237710862)
            static /*int */ TryTakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237710862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, $.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(309237710862)
            
            //--TRIMMABLE-BOUNDARY-START(304942743566)
            static /*int */ TryTakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304942743566);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(304942743566)
            
            //--TRIMMABLE-BOUNDARY-START(322122612750)
            static /*int */ TryTakeFromAnyCore(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122612750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scc.SCC.BlockingCollection$$(T).ValidateCollectionsArray(collections, false);
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if (!$.$$.System.Array.$ReadT1.call(collections, i).IsCompleted && $.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.CurrentCount > 0 && $.$$.System.Array.$ReadT1.call(collections, i).TryTake$3(item))
                    {
                        return i;
                    }
                }
                return $.$scc.SCC.BlockingCollection$$(T).TryTakeFromAnyCoreSlow(collections, item, millisecondsTimeout, isTakeOperation, externalCancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(322122612750)
            
            //--TRIMMABLE-BOUNDARY-START(326417580046)
            static /*int */ TryTakeFromAnyCoreSlow(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417580046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.S.Environment.TickCount >>> 0);
                }
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    /*CancellationToken[]*/ let collatedCancellationTokens;
                    /*List<WaitHandle>*/ let handles = $.$scc.SCC.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, false, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.ST$1.CancellationToken)));
                    if (handles.Count === 0 && isTakeOperation)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CantTakeAnyWhenAllDone, "collections");
                    }
                    if (handles.Count === 0)
                    {
                        break;
                    }
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        /*int*/ let index = $.$$.ST$1.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                        }
                        if (!linkedTokenSource.IsCancellationRequested)
                        {
                            $.$$.SD.Debug.Assert$4((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                            if (index === 258/*WaitHandle.WaitTimeout*/)
                            {
                                break;
                            }
                            if (collections.length !== ((handles.Count - 1) | 0))
                            {
                                for(/*int*/ let i = 0; i < collections.length; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle === handles.get_Item(index))
                                    {
                                        index = i;
                                        break;
                                    }
                                }
                            }
                            if ($.$$.System.Array.$ReadT1.call(collections, index).TryTake$3(item))
                            {
                                return index;
                            }
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.S$IDisposable$Dispose();
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.SCC.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                item.$v = $.$default(T);
                return OPERATION_FAILED;
            }
            //--TRIMMABLE-BOUNDARY-END(326417580046)
            
            //--TRIMMABLE-BOUNDARY-START(94489346062)
            /*void */ CompleteAdding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346062);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                if (this.IsAddingCompleted)
                {
                    return;
                }
                /*SpinWait*/ let spinner = new $.$$.ST$1.SpinWait();
                while(true)
                {
                    /*int*/ let observedAdders = this._currentAdders;
                    if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        return;
                    }
                    if ($.$$.ST$1.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.S.Int32), observedAdders | -2147483648/*COMPLETE_ADDING_ON_MASK*/, observedAdders) === observedAdders)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        if (this.Count === 0)
                        {
                            this.CancelWaitingConsumers();
                        }
                        this.CancelWaitingProducers();
                        return;
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489346062)
            
            //--TRIMMABLE-BOUNDARY-START(77309476878)
            /*void */ CancelWaitingConsumers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._consumersCancellationTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(77309476878)
            
            //--TRIMMABLE-BOUNDARY-START(81604444174)
            /*void */ CancelWaitingProducers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._producersCancellationTokenSource.Cancel();
            }
            //--TRIMMABLE-BOUNDARY-END(81604444174)
            
            //--TRIMMABLE-BOUNDARY-START(107374247950)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247950);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(107374247950)
            
            //--TRIMMABLE-BOUNDARY-START(111669215246)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215246);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._isDisposed)
                {
                    this._freeNodes?.Dispose();
                    this._occupiedNodes.Dispose();
                    this._isDisposed = true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669215246)
            
            //--TRIMMABLE-BOUNDARY-START(236223266830)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223266830);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._collection.SCC$1$IProducerConsumerCollection$$$ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(236223266830)
            
            //--TRIMMABLE-BOUNDARY-START(98784313358)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313358);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this).SC$1$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313358)
            
            //--TRIMMABLE-BOUNDARY-START(184683659278)
            /*void */ SC$1$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683659278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                /*T[]*/ let collectionSnapShot = this._collection.SCC$1$IProducerConsumerCollection$$$ToArray();
                try
                {
                    $.$$.S.Array.Copy(collectionSnapShot, 0, array, index, collectionSnapShot.length);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.S.ArgumentNullException)
                    {
                        throw new $.$$.S.ArgumentNullException().$ctor$19("array");
                    }
                    else if ($e instanceof $.$$.S.ArgumentOutOfRangeException)
                    {
                        throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.S.Int32), $.$scc.S.SR.BlockingCollection_CopyTo_NonNegative);
                    }
                    else if ($e instanceof $.$$.S.ArgumentException)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    else if ($e instanceof $.$$.S.RankException)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CopyTo_MultiDim, "array");
                    }
                    else if ($e instanceof $.$$.S.InvalidCastException)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else if ($e instanceof $.$$.S.ArrayTypeMismatchException)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184683659278)
            
            //--TRIMMABLE-BOUNDARY-START(150323920910)
            /*IEnumerable<T> */ GetConsumingEnumerable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150323920910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetConsumingEnumerable$1($.$$.ST$1.CancellationToken.None);
            }
            //--TRIMMABLE-BOUNDARY-END(150323920910)
            
            //--TRIMMABLE-BOUNDARY-START(154618888206)
            /*IEnumerable<T> */ GetConsumingEnumerable$1(/*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.N.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    if (this.IsCompleted)
                    {
                        return;
                    }
                    /*CancellationTokenSource*/ let linkedTokenSource = $.$$.ST$1.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                    try
                    {
                        /*T?*/ let item;
                        while(this.TryTakeWithNoTimeValidation($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken, linkedTokenSource))
                        {
                            yield item;
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.S$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(154618888206)
            
            //--TRIMMABLE-BOUNDARY-START(180388691982)
            /*IEnumerator<T> */ SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388691982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckDisposed();
                return this._collection.SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(180388691982)
            
            //--TRIMMABLE-BOUNDARY-START(214748430350)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748430350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).SCG$IEnumerable$$$GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(214748430350)
            
            //--TRIMMABLE-BOUNDARY-START(339302481934)
            static /*void */ ValidateCollectionsArray(/*BlockingCollection<T>[]*/ collections, /*bool*/ isAddOperation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302481934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(collections, "collections");
                if (collections.length < 1)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_ValidateCollectionsArray_ZeroSize, "collections");
                }
                if ((collections.length > 63) || ((collections.length === 63) && ($.$$.ST$1.Thread.CurrentThread.GetApartmentState() === 0/*ApartmentState.STA*/)))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("collections", $.$scc.S.SR.BlockingCollection_ValidateCollectionsArray_LargeSize);
                }
                for(/*int*/ let i = 0; i < collections.length; ++i)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i) === null)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_ValidateCollectionsArray_NullElems, "collections");
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._isDisposed)
                    {
                        throw new $.$$.S.ObjectDisposedException().$ctor$16("collections", $.$scc.S.SR.BlockingCollection_ValidateCollectionsArray_DispElems);
                    }
                    if (isAddOperation && $.$$.System.Array.$ReadT1.call(collections, i).IsAddingCompleted)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339302481934)
            
            //--TRIMMABLE-BOUNDARY-START(347892416526)
            static /*void */ ValidateTimeout(/*TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892416526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.S.Int64);
                if ((totalMilliseconds < 0n || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/)) && (totalMilliseconds !== BigInt(-1/*Timeout.Infinite*/)))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("timeout", timeout, $.$scc.S.SR.Format$2($.$$.SG.CultureInfo.InvariantCulture, $.$scc.S.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.S.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347892416526)
            
            //--TRIMMABLE-BOUNDARY-START(343597449230)
            static /*void */ ValidateMillisecondsTimeout(/*int*/ millisecondsTimeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597449230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((millisecondsTimeout < 0) && (millisecondsTimeout !== -1/*Timeout.Infinite*/))
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("millisecondsTimeout", $.$box(millisecondsTimeout, $.$$.S.Int32), $.$scc.S.SR.Format$2($.$$.SG.CultureInfo.InvariantCulture, $.$scc.S.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.S.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343597449230)
            
            //--TRIMMABLE-BOUNDARY-START(85899411470)
            /*void */ CheckDisposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ObjectDisposedException.ThrowIf(this._isDisposed, this);
            }
            //--TRIMMABLE-BOUNDARY-END(85899411470)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(38654771214)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38654771214)
            
            static $H = 65550;
            static $h = 65550;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014509582),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120259149838,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "BoundedCapacity",
      "d": this.$h,
      "H": 73014509582,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014509582),
//--TRIMMABLE-BOUNDARY-START(167503790094),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137439019022,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "n": "IsAddingCompleted",
      "d": this.$h,
      "H": 167503790094,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167503790094),
//--TRIMMABLE-BOUNDARY-START(171798757390),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146028953614,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "n": "IsCompleted",
      "d": this.$h,
      "H": 171798757390,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171798757390),
//--TRIMMABLE-BOUNDARY-START(103079280654),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849084430,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "H": 103079280654,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079280654),
//--TRIMMABLE-BOUNDARY-START(206158495758),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 193273593870,
        "h": Number(BigInt(this.$h)|0x2D00000000n),
        "f": 50331650
      },
      "n": "{63111169}.IsSynchronized",
      "o": "SC$1$ICollection$IsSynchronized",
      "d": this.$h,
      "H": 206158495758,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(206158495758),
//--TRIMMABLE-BOUNDARY-START(210453463054),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 201863528462,
        "h": Number(BigInt(this.$h)|0x2F00000000n),
        "f": 50331650
      },
      "n": "{63111169}.SyncRoot",
      "o": "SC$1$ICollection$SyncRoot",
      "d": this.$h,
      "H": 210453463054,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210453463054)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(163208822798),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h
        },
        {
          "n": "boundedCapacity",
          "p": 655361
        },
        {
          "n": "collectionCount",
          "p": 655361
        }
      ],
      "n": "Initialize",
      "d": this.$h,
      "H": 163208822798,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163208822798),
//--TRIMMABLE-BOUNDARY-START(60129607694),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": this.$h,
      "H": 60129607694,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129607694),
//--TRIMMABLE-BOUNDARY-START(55834640398),
    {
      "r": 65537,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Add",
      "d": this.$h,
      "H": 55834640398,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834640398),
//--TRIMMABLE-BOUNDARY-START(253403136014),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "TryAdd",
      "o": "@$3",
      "d": this.$h,
      "H": 253403136014,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403136014),
//--TRIMMABLE-BOUNDARY-START(249108168718),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "TryAdd",
      "o": "@$2",
      "d": this.$h,
      "H": 249108168718,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108168718),
//--TRIMMABLE-BOUNDARY-START(244813201422),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": this.$h,
      "H": 244813201422,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813201422),
//--TRIMMABLE-BOUNDARY-START(240518234126),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "H": 240518234126,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518234126),
//--TRIMMABLE-BOUNDARY-START(283467907086),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryAddWithNoTimeValidation",
      "d": this.$h,
      "H": 283467907086,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283467907086),
//--TRIMMABLE-BOUNDARY-START(219043397646),
    {
      "r": T?.$h??1572864,
      "n": "Take",
      "d": this.$h,
      "H": 219043397646,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219043397646),
//--TRIMMABLE-BOUNDARY-START(223338364942),
    {
      "r": T?.$h??1572864,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Take",
      "o": "@$1",
      "d": this.$h,
      "H": 223338364942,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223338364942),
//--TRIMMABLE-BOUNDARY-START(300647776270),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryTake",
      "o": "@$3",
      "d": this.$h,
      "H": 300647776270,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300647776270),
//--TRIMMABLE-BOUNDARY-START(296352808974),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "TryTake",
      "o": "@$2",
      "d": this.$h,
      "H": 296352808974,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296352808974),
//--TRIMMABLE-BOUNDARY-START(292057841678),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryTake",
      "o": "@$1",
      "d": this.$h,
      "H": 292057841678,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292057841678),
//--TRIMMABLE-BOUNDARY-START(287762874382),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryTake",
      "d": this.$h,
      "H": 287762874382,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287762874382),
//--TRIMMABLE-BOUNDARY-START(330712547342),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "combinedTokenSource",
          "p": 170983425
        }
      ],
      "n": "TryTakeWithNoTimeValidation",
      "d": this.$h,
      "H": 330712547342,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(330712547342),
//--TRIMMABLE-BOUNDARY-START(68719542286),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "AddToAny",
      "o": "@$1",
      "d": this.$h,
      "H": 68719542286,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719542286),
//--TRIMMABLE-BOUNDARY-START(64424574990),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "AddToAny",
      "d": this.$h,
      "H": 64424574990,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424574990),
//--TRIMMABLE-BOUNDARY-START(270583005198),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "TryAddToAny",
      "o": "@$3",
      "d": this.$h,
      "H": 270583005198,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583005198),
//--TRIMMABLE-BOUNDARY-START(266288037902),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "TryAddToAny",
      "o": "@$2",
      "d": this.$h,
      "H": 266288037902,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266288037902),
//--TRIMMABLE-BOUNDARY-START(261993070606),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryAddToAny",
      "o": "@$1",
      "d": this.$h,
      "H": 261993070606,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261993070606),
//--TRIMMABLE-BOUNDARY-START(257698103310),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryAddToAny",
      "d": this.$h,
      "H": 257698103310,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257698103310),
//--TRIMMABLE-BOUNDARY-START(274877972494),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "externalCancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryAddToAnyCore",
      "d": this.$h,
      "H": 274877972494,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(274877972494),
//--TRIMMABLE-BOUNDARY-START(279172939790),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864
        }
      ],
      "n": "TryAddToAnyFast",
      "d": this.$h,
      "H": 279172939790,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(279172939790),
//--TRIMMABLE-BOUNDARY-START(158913855502),
    {
      "r": $.$$.SCG.List$$($.$$.ST$1.WaitHandle).$h,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "externalCancellationToken",
          "p": 170852353
        },
        {
          "n": "isAddOperation",
          "p": 262145
        },
        {
          "n": "cancellationTokens",
          "p": $.$typeArray($.$$.ST$1.CancellationToken).$h,
          "f": 2
        }
      ],
      "n": "GetHandles",
      "d": this.$h,
      "H": 158913855502,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(158913855502),
//--TRIMMABLE-BOUNDARY-START(335007514638),
    {
      "r": 655361,
      "p": [
        {
          "n": "startTime",
          "p": 720897
        },
        {
          "n": "originalWaitMillisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "UpdateTimeOut",
      "d": this.$h,
      "H": 335007514638,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(335007514638),
//--TRIMMABLE-BOUNDARY-START(231928299534),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TakeFromAny",
      "o": "@$1",
      "d": this.$h,
      "H": 231928299534,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231928299534),
//--TRIMMABLE-BOUNDARY-START(227633332238),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TakeFromAny",
      "d": this.$h,
      "H": 227633332238,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227633332238),
//--TRIMMABLE-BOUNDARY-START(317827645454),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$3",
      "d": this.$h,
      "H": 317827645454,
      "h": Number(BigInt(this.$h)|0x4A00000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(317827645454),
//--TRIMMABLE-BOUNDARY-START(313532678158),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$2",
      "d": this.$h,
      "H": 313532678158,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(313532678158),
//--TRIMMABLE-BOUNDARY-START(309237710862),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "TryTakeFromAny",
      "o": "@$1",
      "d": this.$h,
      "H": 309237710862,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(309237710862),
//--TRIMMABLE-BOUNDARY-START(304942743566),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryTakeFromAny",
      "d": this.$h,
      "H": 304942743566,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304942743566),
//--TRIMMABLE-BOUNDARY-START(322122612750),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "isTakeOperation",
          "p": 262145
        },
        {
          "n": "externalCancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryTakeFromAnyCore",
      "d": this.$h,
      "H": 322122612750,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(322122612750),
//--TRIMMABLE-BOUNDARY-START(326417580046),
    {
      "r": 655361,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "item",
          "p": T?.$h??1572864,
          "f": 2
        },
        {
          "n": "millisecondsTimeout",
          "p": 655361
        },
        {
          "n": "isTakeOperation",
          "p": 262145
        },
        {
          "n": "externalCancellationToken",
          "p": 170852353
        }
      ],
      "n": "TryTakeFromAnyCoreSlow",
      "d": this.$h,
      "H": 326417580046,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(326417580046),
//--TRIMMABLE-BOUNDARY-START(94489346062),
    {
      "r": 65537,
      "n": "CompleteAdding",
      "d": this.$h,
      "H": 94489346062,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489346062),
//--TRIMMABLE-BOUNDARY-START(77309476878),
    {
      "r": 65537,
      "n": "CancelWaitingConsumers",
      "d": this.$h,
      "H": 77309476878,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309476878),
//--TRIMMABLE-BOUNDARY-START(81604444174),
    {
      "r": 65537,
      "n": "CancelWaitingProducers",
      "d": this.$h,
      "H": 81604444174,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604444174),
//--TRIMMABLE-BOUNDARY-START(107374247950),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 107374247950,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374247950),
//--TRIMMABLE-BOUNDARY-START(111669215246),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "H": 111669215246,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(111669215246),
//--TRIMMABLE-BOUNDARY-START(236223266830),
    {
      "r": $.$typeArray(T).$h,
      "n": "ToArray",
      "d": this.$h,
      "H": 236223266830,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223266830),
//--TRIMMABLE-BOUNDARY-START(98784313358),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": this.$h,
      "H": 98784313358,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784313358),
//--TRIMMABLE-BOUNDARY-START(150323920910),
    {
      "r": $.$$.SCG.IEnumerable$$(T).$h,
      "n": "GetConsumingEnumerable",
      "d": this.$h,
      "H": 150323920910,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150323920910),
//--TRIMMABLE-BOUNDARY-START(154618888206),
    {
      "r": $.$$.SCG.IEnumerable$$(T).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "GetConsumingEnumerable",
      "o": "@$1",
      "d": this.$h,
      "H": 154618888206,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154618888206),
//--TRIMMABLE-BOUNDARY-START(339302481934),
    {
      "r": 65537,
      "p": [
        {
          "n": "collections",
          "p": $.$typeArray($.$scc.SCC.BlockingCollection$$(T)).$h
        },
        {
          "n": "isAddOperation",
          "p": 262145
        }
      ],
      "n": "ValidateCollectionsArray",
      "d": this.$h,
      "H": 339302481934,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(339302481934),
//--TRIMMABLE-BOUNDARY-START(347892416526),
    {
      "r": 65537,
      "p": [
        {
          "n": "timeout",
          "p": 186646529
        }
      ],
      "n": "ValidateTimeout",
      "d": this.$h,
      "H": 347892416526,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(347892416526),
//--TRIMMABLE-BOUNDARY-START(343597449230),
    {
      "r": 65537,
      "p": [
        {
          "n": "millisecondsTimeout",
          "p": 655361
        }
      ],
      "n": "ValidateMillisecondsTimeout",
      "d": this.$h,
      "H": 343597449230,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(343597449230),
//--TRIMMABLE-BOUNDARY-START(85899411470),
    {
      "r": 65537,
      "n": "CheckDisposed",
      "d": this.$h,
      "H": 85899411470,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899411470)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000142),
    {
      "t": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h,
      "n": "_collection",
      "d": this.$h,
      "H": 8590000142,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000142),
//--TRIMMABLE-BOUNDARY-START(4295032846),
    {
      "t": 655361,
      "n": "_boundedCapacity",
      "d": this.$h,
      "H": 4295032846,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032846),
//--TRIMMABLE-BOUNDARY-START(176093724686),
    {
      "t": 655361,
      "n": "NON_BOUNDED",
      "d": this.$h,
      "H": 176093724686,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(176093724686),
//--TRIMMABLE-BOUNDARY-START(21474902030),
    {
      "t": 175636481,
      "n": "_freeNodes",
      "d": this.$h,
      "H": 21474902030,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21474902030),
//--TRIMMABLE-BOUNDARY-START(30064836622),
    {
      "t": 175636481,
      "n": "_occupiedNodes",
      "d": this.$h,
      "H": 30064836622,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30064836622),
//--TRIMMABLE-BOUNDARY-START(25769869326),
    {
      "t": 262145,
      "n": "_isDisposed",
      "d": this.$h,
      "H": 25769869326,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25769869326),
//--TRIMMABLE-BOUNDARY-START(12884967438),
    {
      "t": 170983425,
      "n": "_consumersCancellationTokenSource",
      "d": this.$h,
      "H": 12884967438,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12884967438),
//--TRIMMABLE-BOUNDARY-START(34359803918),
    {
      "t": 170983425,
      "n": "_producersCancellationTokenSource",
      "d": this.$h,
      "H": 34359803918,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34359803918),
//--TRIMMABLE-BOUNDARY-START(17179934734),
    {
      "t": 655361,
      "n": "_currentAdders",
      "d": this.$h,
      "H": 17179934734,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17179934734),
//--TRIMMABLE-BOUNDARY-START(90194378766),
    {
      "t": 655361,
      "n": "COMPLETE_ADDING_ON_MASK",
      "d": this.$h,
      "H": 90194378766,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(90194378766)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38654771214),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 38654771214,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771214),
//--TRIMMABLE-BOUNDARY-START(51539673102),
    {
      "p": [
        {
          "n": "boundedCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 51539673102,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539673102),
//--TRIMMABLE-BOUNDARY-START(42949738510),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h
        },
        {
          "n": "boundedCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 42949738510,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949738510),
//--TRIMMABLE-BOUNDARY-START(47244705806),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCC$1.IProducerConsumerCollection$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 47244705806,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705806)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 65550,
  "h": this.$h,
  "a": [
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "browser",
          "t": 1310721
        }
      ]
    },
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 131086,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}, Type = {_collection}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.S.IDisposable, $.$$.SCG.IReadOnlyCollection$$(T), $.$$.SCG.IEnumerable$$(T), $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.BlockingCollection<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}BlockingCollection$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65550)
        
        

        //--TRIMMABLE-BOUNDARY-START(3014670)
        $asm.$str(`$scc.SCG.DebugViewDictionaryItem<,>`, (TKey, TValue) => $asm.$gt(`$scc.SCG.DebugViewDictionaryItem<,>`, [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21477851150)
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477851150);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477851150)
            
            //--TRIMMABLE-BOUNDARY-START(17182883854)
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182883854);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182883854)
            
            //--TRIMMABLE-BOUNDARY-START(42952687630)
            /*TKey*/ Key = $.$default(TKey);
            //--TRIMMABLE-BOUNDARY-END(42952687630)
            
            //--TRIMMABLE-BOUNDARY-START(47247654926)
            /*TValue*/ Value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(47247654926)
            
            //--TRIMMABLE-BOUNDARY-START(12887916558)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887916558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887916558)
            
            //--TRIMMABLE-BOUNDARY-START(12887916558)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12887916558)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $H = 3014670;
            static $h = 3014670;
            static $g = 2;
            static $z = 2;
            static $f = 0b1011000000;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42952687630),
    {
      "p": TKey?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30067785742,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Key",
      "d": this.$h,
      "H": 42952687630,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 2,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42952687630),
//--TRIMMABLE-BOUNDARY-START(47247654926),
    {
      "p": TValue?.$h??1638400,
      "g": {
        "r": 0,
        "d": 0,
        "H": 38657720334,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "H": 47247654926,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 2,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47247654926)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477851150),
    {
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 21477851150,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477851150),
//--TRIMMABLE-BOUNDARY-START(17182883854),
    {
      "p": [
        {
          "n": "keyValue",
          "p": $.$$.SCG.KeyValuePair$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 17182883854,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182883854),
//--TRIMMABLE-BOUNDARY-START(12887916558),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 12887916558,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887916558)
  ],
  "s": [
    {
      "h": TKey?.$h??1572864,
      "n": "TKey"
    },
    {
      "h": TValue?.$h??1638400,
      "n": "TValue"
    }
  ],
  "r": 2,
  "H": 3014670,
  "h": this.$h,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{Value}",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "Name",
          "v": "[{Key}]",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Generic${separator}DebugViewDictionaryItem$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3014670)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114126)
        $asm.$str(`$scc.SCC.EnumerablePartitionerOptions`, ($self) => class EnumerablePartitionerOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static NoBuffering = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoBuffering": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296081422)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081422)
            
            //--TRIMMABLE-BOUNDARY-START(4296081422)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296081422)
            
            static $h = 1114126;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886016014),
    {
      "t": 1114126,
      "n": "None",
      "d": 1114126,
      "h": 12886016014,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886016014),
//--TRIMMABLE-BOUNDARY-START(8591048718),
    {
      "t": 1114126,
      "n": "NoBuffering",
      "d": 1114126,
      "h": 8591048718,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591048718)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081422),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114126,
      "h": 4296081422,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081422)
  ],
  "h": 1114126,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.EnumerablePartitionerOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}EnumerablePartitionerOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114126)
        
        

        //--TRIMMABLE-BOUNDARY-START(196622)
        $asm.$cls(`$scc.SCC.CDSCollectionETWBCLProvider`, ($self) => class CDSCollectionETWBCLProvider extends $.$$.SDT.EventSource
        {
            //--TRIMMABLE-BOUNDARY-START(60129738766)
            /*CDSCollectionETWBCLProvider*/ static Log = null;
            //--TRIMMABLE-BOUNDARY-END(60129738766)
            
            //--TRIMMABLE-BOUNDARY-START(8590131214)
            $ctor$10()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131214)
            
            //--TRIMMABLE-BOUNDARY-START(12885098510)
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            //--TRIMMABLE-BOUNDARY-END(12885098510)
            
            //--TRIMMABLE-BOUNDARY-START(51539804174)
            /*int*/ static CONCURRENTSTACK_FASTPUSHFAILED_ID = 1;
            //--TRIMMABLE-BOUNDARY-END(51539804174)
            
            //--TRIMMABLE-BOUNDARY-START(42949869582)
            /*int*/ static CONCURRENTSTACK_FASTPOPFAILED_ID = 2;
            //--TRIMMABLE-BOUNDARY-END(42949869582)
            
            //--TRIMMABLE-BOUNDARY-START(34359934990)
            /*int*/ static CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID = 3;
            //--TRIMMABLE-BOUNDARY-END(34359934990)
            
            //--TRIMMABLE-BOUNDARY-START(25770000398)
            /*int*/ static CONCURRENTBAG_TRYTAKESTEALS_ID = 4;
            //--TRIMMABLE-BOUNDARY-END(25770000398)
            
            //--TRIMMABLE-BOUNDARY-START(17180065806)
            /*int*/ static CONCURRENTBAG_TRYPEEKSTEALS_ID = 5;
            //--TRIMMABLE-BOUNDARY-END(17180065806)
            
            //--TRIMMABLE-BOUNDARY-START(55834771470)
            /*void */ ConcurrentStack_FastPushFailed(/*int*/ spinCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(1/*CONCURRENTSTACK_FASTPUSHFAILED_ID*/, spinCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834771470)
            
            //--TRIMMABLE-BOUNDARY-START(47244836878)
            /*void */ ConcurrentStack_FastPopFailed(/*int*/ spinCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(2/*CONCURRENTSTACK_FASTPOPFAILED_ID*/, spinCount);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244836878)
            
            //--TRIMMABLE-BOUNDARY-START(38654902286)
            /*void */ ConcurrentDictionary_AcquiringAllLocks(/*int*/ numOfBuckets)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(3/*CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID*/, numOfBuckets);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654902286)
            
            //--TRIMMABLE-BOUNDARY-START(30064967694)
            /*void */ ConcurrentBag_TryTakeSteals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(4/*CONCURRENTBAG_TRYTAKESTEALS_ID*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064967694)
            
            //--TRIMMABLE-BOUNDARY-START(21475033102)
            /*void */ ConcurrentBag_TryPeekSteals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(5/*CONCURRENTBAG_TRYPEEKSTEALS_ID*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475033102)
            
            //--TRIMMABLE-BOUNDARY-START(8590131214)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(8590131214)
            
            //--TRIMMABLE-BOUNDARY-START(4295163918)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60129738766)
                    this.Log = new $.$scc.SCC.CDSCollectionETWBCLProvider().$ctor$10();
                    //--TRIMMABLE-BOUNDARY-END(60129738766)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163918)
            
            static $h = 196622;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SDT.EventSource; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834771470),
    {
      "r": 65537,
      "p": [
        {
          "n": "spinCount",
          "p": 655361
        }
      ],
      "n": "ConcurrentStack_FastPushFailed",
      "d": 196622,
      "h": 55834771470,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 1,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834771470),
//--TRIMMABLE-BOUNDARY-START(47244836878),
    {
      "r": 65537,
      "p": [
        {
          "n": "spinCount",
          "p": 655361
        }
      ],
      "n": "ConcurrentStack_FastPopFailed",
      "d": 196622,
      "h": 47244836878,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 2,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244836878),
//--TRIMMABLE-BOUNDARY-START(38654902286),
    {
      "r": 65537,
      "p": [
        {
          "n": "numOfBuckets",
          "p": 655361
        }
      ],
      "n": "ConcurrentDictionary_AcquiringAllLocks",
      "d": 196622,
      "h": 38654902286,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 3,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 3,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654902286),
//--TRIMMABLE-BOUNDARY-START(30064967694),
    {
      "r": 65537,
      "n": "ConcurrentBag_TryTakeSteals",
      "d": 196622,
      "h": 30064967694,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 4,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30064967694),
//--TRIMMABLE-BOUNDARY-START(21475033102),
    {
      "r": 65537,
      "n": "ConcurrentBag_TryPeekSteals",
      "d": 196622,
      "h": 21475033102,
      "f": 16777217,
      "a": [
        {
          "t": 73465857,
          "c": 43023138817,
          "a": [
            {
              "v": 5,
              "t": 655361
            }
          ],
          "n": [
            {
              "n": "Level",
              "v": 5,
              "t": 74448897
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475033102)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60129738766),
    {
      "t": 196622,
      "n": "Log",
      "d": 196622,
      "h": 60129738766,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129738766),
//--TRIMMABLE-BOUNDARY-START(12885098510),
    {
      "t": 74383361,
      "n": "ALL_KEYWORDS",
      "d": 196622,
      "h": 12885098510,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885098510),
//--TRIMMABLE-BOUNDARY-START(51539804174),
    {
      "t": 655361,
      "n": "CONCURRENTSTACK_FASTPUSHFAILED_ID",
      "d": 196622,
      "h": 51539804174,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539804174),
//--TRIMMABLE-BOUNDARY-START(42949869582),
    {
      "t": 655361,
      "n": "CONCURRENTSTACK_FASTPOPFAILED_ID",
      "d": 196622,
      "h": 42949869582,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949869582),
//--TRIMMABLE-BOUNDARY-START(34359934990),
    {
      "t": 655361,
      "n": "CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID",
      "d": 196622,
      "h": 34359934990,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359934990),
//--TRIMMABLE-BOUNDARY-START(25770000398),
    {
      "t": 655361,
      "n": "CONCURRENTBAG_TRYTAKESTEALS_ID",
      "d": 196622,
      "h": 25770000398,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770000398),
//--TRIMMABLE-BOUNDARY-START(17180065806),
    {
      "t": 655361,
      "n": "CONCURRENTBAG_TRYPEEKSTEALS_ID",
      "d": 196622,
      "h": 17180065806,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180065806)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131214),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 196622,
      "h": 8590131214,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590131214)
  ],
  "h": 196622,
  "a": [
    {
      "t": 75563009,
      "c": 17255432193,
      "n": [
        {
          "n": "Name",
          "v": "System.Collections.Concurrent.ConcurrentCollectionsEventSource",
          "t": 1310721
        },
        {
          "n": "Guid",
          "v": "35167F8E-49B2-4b96-AB86-435B59336B5E",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.CDSCollectionETWBCLProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}CDSCollectionETWBCLProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196622)
        
        

        //--TRIMMABLE-BOUNDARY-START(458766)
        $asm.$cls(`$scc.SCC.ConcurrentDictionary<,>`, (TKey, TValue) => $asm.$gt(`$scc.SCC.ConcurrentDictionary<,>`, [TKey, TValue], ($self) => class ConcurrentDictionary$$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21475295246)
            /*Tables*/ _tables = null;
            //--TRIMMABLE-BOUNDARY-END(21475295246)
            
            //--TRIMMABLE-BOUNDARY-START(4295426062)
            /*int*/ _budget = 0;
            //--TRIMMABLE-BOUNDARY-END(4295426062)
            
            //--TRIMMABLE-BOUNDARY-START(12885360654)
            /*bool*/ _growLockArray = false;
            //--TRIMMABLE-BOUNDARY-END(12885360654)
            
            //--TRIMMABLE-BOUNDARY-START(8590393358)
            /*bool*/ _comparerIsDefaultForClasses = false;
            //--TRIMMABLE-BOUNDARY-END(8590393358)
            
            //--TRIMMABLE-BOUNDARY-START(17180327950)
            /*int*/ _initialCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(17180327950)
            
            //--TRIMMABLE-BOUNDARY-START(120259543054)
            /*int*/ static DefaultCapacity = 31;
            //--TRIMMABLE-BOUNDARY-END(120259543054)
            
            //--TRIMMABLE-BOUNDARY-START(266288431118)
            /*int*/ static MaxLockNumber = 1024;
            //--TRIMMABLE-BOUNDARY-END(266288431118)
            
            //--TRIMMABLE-BOUNDARY-START(25770262542)
            $ctor$1()
            {
                this.$ctor$6($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262542);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262542)
            
            //--TRIMMABLE-BOUNDARY-START(55835033614)
            $ctor$8(/*int*/ concurrencyLevel, /*int*/ capacity)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033614);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835033614)
            
            //--TRIMMABLE-BOUNDARY-START(34360197134)
            $ctor$3(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                this.$ctor$5($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, collection, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197134)
            
            //--TRIMMABLE-BOUNDARY-START(38655164430)
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164430);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655164430)
            
            //--TRIMMABLE-BOUNDARY-START(30065229838)
            $ctor$2(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229838);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229838)
            
            //--TRIMMABLE-BOUNDARY-START(42950131726)
            $ctor$5(/*int*/ concurrencyLevel, /*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), false, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950131726);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950131726)
            
            //--TRIMMABLE-BOUNDARY-START(51540066318)
            $ctor$7(/*int*/ concurrencyLevel, /*int*/ capacity, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540066318);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066318)
            
            //--TRIMMABLE-BOUNDARY-START(47245099022)
            $ctor$6(/*int*/ concurrencyLevel, /*int*/ capacity, /*bool*/ growLockArray, /*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245099022);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (concurrencyLevel <= 0)
                    {
                        if (concurrencyLevel !== -1)
                        {
                            throw new $.$$.S.ArgumentOutOfRangeException().$ctor$19("concurrencyLevel", $.$scc.S.SR.ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne);
                        }
                        concurrencyLevel = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel;
                    }
                    $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, capacity, "capacity");
                    if (capacity < concurrencyLevel)
                    {
                        capacity = concurrencyLevel;
                    }
                    capacity = $.$scc.SC.HashHelpers.GetPrime(capacity);
                    /*var*/ let locks = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [concurrencyLevel], null);
                    $.$$.System.Array.$WriteT1.call(locks, locks, 0);
                    for(/*int*/ let i = 1; i < locks.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(locks, new $.$$.S.Object().$ctor(), i);
                    }
                    /*var*/ let countPerLock = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [locks.length], null);
                    /*var*/ let buckets = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [capacity], null);
                    if (TKey.$type.IsValueType)
                    {
                        if (!(comparer === null) && $.$$.S.Object.ReferenceEquals(comparer, $.$$.SCG.EqualityComparer$$(TKey).Default))
                        {
                            comparer = null;
                        }
                    }
                    else 
                    {
                        comparer ??= $.$$.SCG.EqualityComparer$$(TKey).Default;
                        let stringComparer;
                        if (TKey.$type === $.$$.S.String.$type && $.$is($.$$.SCG.NonRandomizedStringEqualityComparer.GetStringComparer(comparer), $.$$.SCG.IEqualityComparer$$($.$$.S.String), { set $v($v){ stringComparer = $v; } }))
                        {
                            comparer = $.$cast(stringComparer, $.$$.SCG.IEqualityComparer$$(TKey));
                        }
                        else if ($.$$.S.Object.ReferenceEquals(comparer, $.$$.SCG.EqualityComparer$$(TKey).Default))
                        {
                            this._comparerIsDefaultForClasses = true;
                        }
                    }
                    this._tables = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(buckets, locks, countPerLock, comparer);
                    this._growLockArray = growLockArray;
                    this._initialCapacity = capacity;
                    this._budget = $.trunc(buckets.length / locks.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099022)
            
            //--TRIMMABLE-BOUNDARY-START(193273987086)
            /*AlternateLookup<TAlternateKey> */ GetAlternateLookup(TAlternateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273987086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    $.$scc.S.ThrowHelper.ThrowIncompatibleComparer();
                }
                return new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
            }
            //--TRIMMABLE-BOUNDARY-END(193273987086)
            
            //--TRIMMABLE-BOUNDARY-START(502511632398)
            /*bool */ TryGetAlternateLookup(TAlternateKey, /*out AlternateLookup<TAlternateKey>*/ lookup)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511632398);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    lookup.$v = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
                    return true;
                }
                lookup.$v = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(502511632398)
            
            //--TRIMMABLE-BOUNDARY-START(206158888974)
            static /*int */ GetCapacityFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206158888974);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        {
                            let c;
                            if ((c = collection, $.$is(c, $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)))))
                            {
                                return $.$$.S.Math.Max$4(31/*DefaultCapacity*/, c.SCG$ICollection$$$Count);
                            }
                        }
                        {
                            let rc;
                            if ((rc = collection, $.$is(rc, $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)))))
                            {
                                return $.$$.S.Math.Max$4(31/*DefaultCapacity*/, rc.SCG$IReadOnlyCollection$$$Count);
                            }
                        }
                        return 31/*DefaultCapacity*/;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206158888974)
            
            //--TRIMMABLE-BOUNDARY-START(219043790862)
            /*int */ GetHashCode$1(/*IEqualityComparer<TKey>?*/ comparer, /*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.S.Object.GetHashCodeT(TKey, key) : comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$GetHashCode`](key);
                }
                $.$$.SD.Debug.Assert$4(!(comparer === null), "comparer is not null");
                return this._comparerIsDefaultForClasses ? $.$$.S.Object.GetHashCodeT(TKey, key) : comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$GetHashCode`](key);
            }
            //--TRIMMABLE-BOUNDARY-END(219043790862)
            
            //--TRIMMABLE-BOUNDARY-START(270583398414)
            static /*bool */ NodeEqualsKey(/*IEqualityComparer<TKey>?*/ comparer, /*Node*/ node, /*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583398414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.SCG.EqualityComparer$$(TKey).Default.Equals$2(node._key, key) : comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](node._key, key);
                }
                $.$$.SD.Debug.Assert$4(!(comparer === null), "comparer is not null");
                return comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](node._key, key);
            }
            //--TRIMMABLE-BOUNDARY-END(270583398414)
            
            //--TRIMMABLE-BOUNDARY-START(249108561934)
            /*void */ InitializeFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108561934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = collection.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let pair = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (pair.Key === null)
                        {
                            $.$scc.S.ThrowHelper.ThrowKeyNullException();
                        }
                        if (!this.TryAddInternal(this._tables, pair.Key, null, pair.Value, false, false, $.$discardRef()))
                        {
                            throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_SourceContainsDuplicateKeys);
                        }
                    }
                }
                if (this._budget === 0)
                {
                    /*Tables*/ let tables = this._tables;
                    this._budget = $.trunc(tables._buckets.length / tables._locks.length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249108561934)
            
            //--TRIMMABLE-BOUNDARY-START(493921697806)
            /*bool */ TryAdd(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921697806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryAddInternal(this._tables, key, null, value, false, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(493921697806)
            
            //--TRIMMABLE-BOUNDARY-START(98784706574)
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784706574);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryGetValue(key, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784706574)
            
            //--TRIMMABLE-BOUNDARY-START(519691501582)
            /*bool */ TryRemove$1(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691501582);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryRemoveInternal(key, value, false, $.$default(TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(519691501582)
            
            //--TRIMMABLE-BOUNDARY-START(515396534286)
            /*bool */ TryRemove(/*KeyValuePair<TKey, TValue>*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396534286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (item.Key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException("item", $.$scc.S.SR.ConcurrentDictionary_ItemKeyIsNull);
                }
                return this.TryRemoveInternal(item.Key, $.$discardRef(), true, item.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(515396534286)
            
            //--TRIMMABLE-BOUNDARY-START(523986468878)
            /*bool */ TryRemoveInternal(/*TKey*/ key, /*out TValue*/ value, /*bool*/ matchValue, /*TValue?*/ oldValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986468878);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*uint*/ let lockNo;
                    /*object[]*/ let locks = tables._locks;
                    /*ref Node?*/ let bucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.S.UInt32));
                    //lock(locks[lockNo])
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                            {
                                $.$$.SD.Debug.Assert$4((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                if (hashcode === curr._hashcode && $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, curr, key))
                                {
                                    if (matchValue)
                                    {
                                        /*bool*/ let valuesMatch = $.$$.SCG.EqualityComparer$$(TValue).Default.Equals$2(oldValue, curr._value);
                                        if (!valuesMatch)
                                        {
                                            value.$v = $.$default(TValue);
                                            return false;
                                        }
                                    }
                                    if (prev === null)
                                    {
                                        bucket.$v = curr._next;
                                    }
                                    else 
                                    {
                                        prev._next = curr._next;
                                    }
                                    value.$v = curr._value;
                                    let $t5 = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                    $.$$.System.Array.$WriteT1.call(tables._countPerLock, $t5 - 1, lockNo);
                                    return true;
                                }
                                prev = curr;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                    value.$v = $.$default(TValue);
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(523986468878)
            
            //--TRIMMABLE-BOUNDARY-START(506806599694)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806599694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    /*int*/ let hashcode = $.$$.S.Object.GetHashCodeT(TKey, key);
                    for(/*Node?*/ let n = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.SCG.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(!(comparer === null), "comparer is not null");
                    /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                    for(/*Node?*/ let n = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(506806599694)
            
            //--TRIMMABLE-BOUNDARY-START(511101566990)
            static /*bool */ TryGetValueInternal(/*Tables*/ tables, /*TKey*/ key, /*int*/ hashcode, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101566990);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    for(/*Node?*/ let n = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.SCG.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(!(comparer === null), "comparer is not null");
                    for(/*Node?*/ let n = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$Equals`](n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(511101566990)
            
            //--TRIMMABLE-BOUNDARY-START(528281436174)
            /*bool */ TryUpdate(/*TKey*/ key, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281436174);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryUpdateInternal(this._tables, key, null, newValue, comparisonValue);
            }
            //--TRIMMABLE-BOUNDARY-END(528281436174)
            
            //--TRIMMABLE-BOUNDARY-START(532576403470)
            /*bool */ TryUpdateInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576403470);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.SD.Debug.Assert$4(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                /*EqualityComparer<TValue>*/ let valueComparer = $.$$.SCG.EqualityComparer$$(TValue).Default;
                while(true)
                {
                    /*uint*/ let lockNo;
                    /*object[]*/ let locks = tables._locks;
                    /*ref Node?*/ let bucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.S.UInt32));
                    //lock(locks[lockNo])
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                            {
                                $.$$.SD.Debug.Assert$4((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                if (hashcode === node._hashcode && $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                                {
                                    if (valueComparer.Equals$2(node._value, comparisonValue))
                                    {
                                        if (!TValue.$type.IsValueType || $.$scc.SCC.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                        {
                                            node._value = newValue;
                                        }
                                        else 
                                        {
                                            /*var*/ let newNode = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, newValue, hashcode, node._next);
                                            if (prev === null)
                                            {
                                                bucket.$v = newNode;
                                            }
                                            else 
                                            {
                                                prev._next = newNode;
                                            }
                                        }
                                        return true;
                                    }
                                    return false;
                                }
                                prev = node;
                            }
                            return false;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(532576403470)
            
            //--TRIMMABLE-BOUNDARY-START(90194771982)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194771982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    if (this.AreAllBucketsEmpty())
                    {
                        return;
                    }
                    /*Tables*/ let tables = this._tables;
                    /*var*/ let newTables = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [$.$scc.SC.HashHelpers.GetPrime(this._initialCapacity)], null), tables._locks, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [tables._countPerLock.length], null), tables._comparer);
                    this._tables = newTables;
                    this._budget = $.$$.S.Math.Max$4(1, $.trunc(newTables._buckets.length / newTables._locks.length));
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194771982)
            
            //--TRIMMABLE-BOUNDARY-START(296353202190)
            /*void */ SCG$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353202190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    this.CopyToPairs(array, index);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(296353202190)
            
            //--TRIMMABLE-BOUNDARY-START(489626730510)
            /*KeyValuePair<TKey, TValue>[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626730510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.S.Array.Empty($.$$.SCG.KeyValuePair$$$(TKey, TValue));
                    }
                    /*var*/ let array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.SCG.KeyValuePair$$$(TKey, TValue)), null, [count], null);
                    this.CopyToPairs(array, 0);
                    return array;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(489626730510)
            
            //--TRIMMABLE-BOUNDARY-START(111669608462)
            /*void */ CopyToPairs(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608462);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i11 = 0;
                let $arr11 = this._tables._buckets;
                while ($i11 < $arr11.length)
                {
                    let bucket = $arr11[$i11++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.SCG.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.SD.Debug.Assert$4(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669608462)
            
            //--TRIMMABLE-BOUNDARY-START(103079673870)
            /*void */ CopyToEntries(/*DictionaryEntry[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i12 = 0;
                let $arr12 = this._tables._buckets;
                while ($i12 < $arr12.length)
                {
                    let bucket = $arr12[$i12++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new $.$$.SC$1.DictionaryEntry().$ctor$3($.$box(current._key, TKey), $.$box(current._value, TValue)), index);
                        $.$$.SD.Debug.Assert$4(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079673870)
            
            //--TRIMMABLE-BOUNDARY-START(107374641166)
            /*void */ CopyToObjects(/*object[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i13 = 0;
                let $arr13 = this._tables._buckets;
                while ($i13 < $arr13.length)
                {
                    let bucket = $arr13[$i13++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.SCG.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.SD.Debug.Assert$4(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374641166)
            
            //--TRIMMABLE-BOUNDARY-START(214748823566)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748823566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Enumerator)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748823566)
            
            //--TRIMMABLE-BOUNDARY-START(655374)
            static $_Enumerator;
            static get Enumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$ncls(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`, ($self) => class Enumerator extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590589966)
                    /*ConcurrentDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(8590589966)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622670)
                    /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ _buckets = null;
                    //--TRIMMABLE-BOUNDARY-END(4295622670)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524558)
                    /*Node?*/ _node = null;
                    //--TRIMMABLE-BOUNDARY-END(17180524558)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885557262)
                    /*int*/ _i = -1;
                    //--TRIMMABLE-BOUNDARY-END(12885557262)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426446)
                    /*KeyValuePair<TKey, TValue>*/ Current;
                    //--TRIMMABLE-BOUNDARY-END(30065426446)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425164814)
                    /*object */ get SC$1$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425164814)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540262926)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540262926);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._buckets = null;
                        this._node = null;
                        this.Current = new ($.$$.SCG.KeyValuePair$$$(TKey, TValue))();
                        this._i = -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540262926)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393742)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360393742);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393742)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245295630)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245295630);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        while(true)
                        {
                            let node;
                            if ($.$is(this._node, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node, { set $v($v){ node = $v; } }))
                            {
                                this.Current = new ($.$$.SCG.KeyValuePair$$$(TKey, TValue))().$ctor$3(node._key, node._value);
                                this._node = node._next;
                                return true;
                            }
                            /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ let buckets = this._buckets ??= this._dictionary._tables._buckets;
                            $.$$.SD.Debug.Assert$4(!(buckets === null), "buckets is not null");
                            /*int*/ let i = ((this._i + 1) | 0);
                            if ((i >>> 0) >= (buckets.length >>> 0))
                            {
                                return false;
                            }
                            this._node = $.$$.System.Array.$ReadT1.call(buckets, i)._node;
                            this._i = i;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245295630)
                    
                    //--TRIMMABLE-BOUNDARY-START(12945326081)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get SCG$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4355391489);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945326081)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    //Begin primary constructor
                    /*ConcurrentDictionary<TKey, TValue>*/ dictionary = null;
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/dictionary)
                    {
                        this.dictionary = dictionary;
                        super.$ctor();
                        //--TRIMMABLE-BOUNDARY-START(8590589966)
                        //depends on primary constructor parameter
                        this._dictionary = this.dictionary;
                        //--TRIMMABLE-BOUNDARY-END(8590589966)
                        
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(30065426446)
                        this.Current = $.$default($.$$.SCG.KeyValuePair$$$(TKey, TValue));
                        //--TRIMMABLE-BOUNDARY-END(30065426446)
                        
                    }
                    static $H = 655374;
                    static $h = 655374;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065426446),
    {
      "p": $.$$.SCG.KeyValuePair$$$(TKey, TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950328334,
        "h": Number(BigInt(655374)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 60130197518,
        "h": Number(BigInt(655374)|0xE00000000n),
        "f": 83886082
      },
      "n": "Current",
      "d": 655374,
      "H": 30065426446,
      "h": Number(BigInt(655374)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065426446),
//--TRIMMABLE-BOUNDARY-START(64425164814),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73015099406,
        "h": Number(BigInt(655374)|0x1100000000n),
        "f": 50331650
      },
      "n": "{63504385}.Current",
      "o": "SC$1$IEnumerator$Current",
      "d": 655374,
      "H": 64425164814,
      "h": Number(BigInt(655374)|0xF00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425164814)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540262926),
    {
      "r": 65537,
      "n": "Reset",
      "d": 655374,
      "H": 51540262926,
      "h": Number(BigInt(655374)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540262926),
//--TRIMMABLE-BOUNDARY-START(34360393742),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 655374,
      "H": 34360393742,
      "h": Number(BigInt(655374)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393742),
//--TRIMMABLE-BOUNDARY-START(47245295630),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 655374,
      "H": 47245295630,
      "h": Number(BigInt(655374)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295630)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590589966),
    {
      "t": 458766,
      "n": "_dictionary",
      "d": 655374,
      "H": 8590589966,
      "h": Number(BigInt(655374)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590589966),
//--TRIMMABLE-BOUNDARY-START(4295622670),
    {
      "t": $.$typeArray($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,
      "n": "_buckets",
      "d": 655374,
      "H": 4295622670,
      "h": Number(BigInt(655374)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622670),
//--TRIMMABLE-BOUNDARY-START(17180524558),
    {
      "t": 720910,
      "n": "_node",
      "d": 655374,
      "H": 17180524558,
      "h": Number(BigInt(655374)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524558),
//--TRIMMABLE-BOUNDARY-START(12885557262),
    {
      "t": 655361,
      "n": "_i",
      "d": 655374,
      "H": 12885557262,
      "h": Number(BigInt(655374)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557262)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770459150),
    {
      "p": [
        {
          "n": "dictionary",
          "p": 458766
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655374,
      "H": 25770459150,
      "h": Number(BigInt(655374)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459150)
  ],
  "d": 458766,
  "H": 655374,
  "h": 655374
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)), $.$$.S.IDisposable, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+Enumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655374)
            
            //--TRIMMABLE-BOUNDARY-START(498216665102)
            /*bool */ TryAddInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ value, /*bool*/ updateIfExists, /*bool*/ acquireLock, /*out TValue*/ resultingValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216665102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.SD.Debug.Assert$4(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                while(true)
                {
                    /*uint*/ let lockNo;
                    /*object[]*/ let locks = tables._locks;
                    /*ref Node?*/ let bucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.S.UInt32));
                    /*bool*/ let resizeDesired = false;
                    /*bool*/ let forceRehash = false;
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        if (acquireLock)
                        {
                            $.$$.ST$1.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                        }
                        if (tables !== this._tables)
                        {
                            tables = this._tables;
                            if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                            {
                                comparer = tables._comparer;
                                hashcode = this.GetHashCode$1(comparer, key);
                            }
                            continue;
                        }
                        /*uint*/ let collisionCount = 0;
                        /*Node?*/ let prev = null;
                        for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                        {
                            $.$$.SD.Debug.Assert$4((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                            if (hashcode === node._hashcode && $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                            {
                                if (updateIfExists)
                                {
                                    if (!TValue.$type.IsValueType || $.$scc.SCC.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                    {
                                        node._value = value;
                                    }
                                    else 
                                    {
                                        /*var*/ let newNode = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                        if (prev === null)
                                        {
                                            bucket.$v = newNode;
                                        }
                                        else 
                                        {
                                            prev._next = newNode;
                                        }
                                    }
                                    resultingValue.$v = value;
                                }
                                else 
                                {
                                    resultingValue.$v = node._value;
                                }
                                return false;
                            }
                            prev = node;
                            if (!TKey.$type.IsValueType)
                            {
                                collisionCount++;
                            }
                        }
                        /*var*/ let resultNode = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(key, value, hashcode, bucket.$v);
                        bucket.$v = resultNode;
                        //checked
                        {
                            let $t18 = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                            $.$$.System.Array.$WriteT1.call(tables._countPerLock, $t18 + 1, lockNo);
                        }
                        if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this._budget)
                        {
                            resizeDesired = true;
                        }
                        if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.SCG.NonRandomizedStringEqualityComparer))
                        {
                            forceRehash = true;
                        }
                    }
                    finally
                    {
                        {
                            if (lockTaken)
                            {
                                $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                            }
                        }
                    }
                    if ($.$$.S.Boolean.op_BitwiseOr$2(resizeDesired, forceRehash))
                    {
                        this.GrowTable(tables, resizeDesired, forceRehash);
                    }
                    resultingValue.$v = value;
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(498216665102)
            
            //--TRIMMABLE-BOUNDARY-START(476741828622)
            /*TValue*/ get_Item$1(/*TKey*/ key)
            {
                /*TValue?*/ let value;
                if (!this.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).ThrowKeyNotFoundException(key);
                }
                return value;
            }
            /*void*/ set_Item$1(/*TKey*/ key, /*TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                this.TryAddInternal(this._tables, key, null, value, true, true, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(476741828622)
            
            //--TRIMMABLE-BOUNDARY-START(485331763214)
            static /*void */ ThrowKeyNotFoundException(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(485331763214);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.SCG.KeyNotFoundException().$ctor$12($.$scc.S.SR.Format$6($.$scc.S.SR.Arg_KeyNotFoundWithKey, $.$dsp(key, TKey, ($t) => $t.ToString)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(485331763214)
            
            //--TRIMMABLE-BOUNDARY-START(94489739278)
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = this._tables._comparer;
                if (TKey.$type === $.$$.S.String.$type)
                {
                    let ec;
                    if ($.$is((($.$as(comparer, $.$$.SCG.NonRandomizedStringEqualityComparer))?.GetUnderlyingEqualityComparer() ?? null), $.$$.SCG.IEqualityComparer$$($.$$.S.String), { set $v($v){ ec = $v; } }))
                    {
                        return $.$cast(ec, $.$$.SCG.IEqualityComparer$$(TKey));
                    }
                }
                return comparer ?? $.$$.SCG.EqualityComparer$$(TKey).Default;
            }
            //--TRIMMABLE-BOUNDARY-END(94489739278)
            
            //--TRIMMABLE-BOUNDARY-START(115964575758)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    return this.GetCountNoLocks();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964575758)
            
            //--TRIMMABLE-BOUNDARY-START(210453856270)
            /*int */ GetCountNoLocks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = 0;
                let $i21 = 0;
                let $arr21 = this._tables._countPerLock;
                while ($i21 < $arr21.length)
                {
                    let value = $arr21[$i21++];
                    //checked
                    {
                        count += value;
                    }
                }
                return count;
            }
            //--TRIMMABLE-BOUNDARY-END(210453856270)
            
            //--TRIMMABLE-BOUNDARY-START(227633725454)
            /*TValue */ GetOrAdd(/*TKey*/ key, /*Func<TKey, TValue>*/ valueFactory)
            {
                /*TValue?*/ let resultingValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                if (!$.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(227633725454)
            
            //--TRIMMABLE-BOUNDARY-START(236223660046)
            /*TValue */ GetOrAdd$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ valueFactory, /*TArg*/ factoryArgument)
            {
                /*TValue?*/ let resultingValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223660046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                if (!$.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(236223660046)
            
            //--TRIMMABLE-BOUNDARY-START(231928692750)
            /*TValue */ GetOrAdd$1(/*TKey*/ key, /*TValue*/ value)
            {
                /*TValue?*/ let resultingValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                if (!$.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, value, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            //--TRIMMABLE-BOUNDARY-END(231928692750)
            
            //--TRIMMABLE-BOUNDARY-START(81604837390)
            /*TValue */ AddOrUpdate$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ addValueFactory, /*Func<TKey, TValue, TArg, TValue>*/ updateValueFactory, /*TArg*/ factoryArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837390);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue, factoryArgument);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604837390)
            
            //--TRIMMABLE-BOUNDARY-START(73014902798)
            /*TValue */ AddOrUpdate(/*TKey*/ key, /*Func<TKey, TValue>*/ addValueFactory, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014902798)
            
            //--TRIMMABLE-BOUNDARY-START(77309870094)
            /*TValue */ AddOrUpdate$1(/*TKey*/ key, /*TValue*/ addValue, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (updateValueFactory === null)
                {
                    $.$scc.S.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValue, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309870094)
            
            //--TRIMMABLE-BOUNDARY-START(257698496526)
            /*bool */ get IsEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.AreAllBucketsEmpty())
                {
                    return false;
                }
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    return this.AreAllBucketsEmpty();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698496526)
            
            //--TRIMMABLE-BOUNDARY-START(317828038670)
            /*void */ SCG$IDictionary$$$$Add(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828038670);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryAdd(key, value))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_KeyAlreadyExisted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317828038670)
            
            //--TRIMMABLE-BOUNDARY-START(322123005966)
            /*bool */ SCG$IDictionary$$$$Remove(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(322123005966);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryRemove$1(key, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(322123005966)
            
            //--TRIMMABLE-BOUNDARY-START(261993463822)
            /*ICollection<TKey> */ get Keys()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(261993463822)
            
            //--TRIMMABLE-BOUNDARY-START(343597842446)
            /*IEnumerable<TKey> */ get SCG$IReadOnlyDictionary$$$$Keys()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(343597842446)
            
            //--TRIMMABLE-BOUNDARY-START(536871370766)
            /*ICollection<TValue> */ get Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(536871370766)
            
            //--TRIMMABLE-BOUNDARY-START(347892809742)
            /*IEnumerable<TValue> */ get SCG$IReadOnlyDictionary$$$$Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(347892809742)
            
            //--TRIMMABLE-BOUNDARY-START(287763267598)
            /*void */ SCG$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287763267598);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).SCG$IDictionary$$$$Add(keyValuePair.Key, keyValuePair.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763267598)
            
            //--TRIMMABLE-BOUNDARY-START(292058234894)
            /*bool */ SCG$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    /*TValue?*/ let value;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(292058234894);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryGetValue(keyValuePair.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.SCG.EqualityComparer$$(TValue).Default.Equals$2(value, keyValuePair.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292058234894)
            
            //--TRIMMABLE-BOUNDARY-START(309238104078)
            /*bool */ get SCG$ICollection$$$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(309238104078)
            
            //--TRIMMABLE-BOUNDARY-START(313533071374)
            /*bool */ SCG$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(313533071374);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryRemove(keyValuePair);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313533071374)
            
            //--TRIMMABLE-BOUNDARY-START(472446861326)
            /*IEnumerator */ SC$1$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(472446861326);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(472446861326)
            
            //--TRIMMABLE-BOUNDARY-START(382252548110)
            /*void */ SC$1$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252548110);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).SCG$IDictionary$$$$Add($.$cast(key, TKey), $.$cast(value, TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(382252548110)
            
            //--TRIMMABLE-BOUNDARY-START(386547515406)
            /*bool */ SC$1$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547515406);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                return $.$is(key, TKey, { set $v($v){ tkey = $v; } }) && this.ContainsKey(tkey);
            }
            //--TRIMMABLE-BOUNDARY-END(386547515406)
            
            //--TRIMMABLE-BOUNDARY-START(433792155662)
            /*IDictionaryEnumerator */ SC$1$IDictionary$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(433792155662);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DictionaryEnumerator)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(433792155662)
            
            //--TRIMMABLE-BOUNDARY-START(438087122958)
            /*bool */ get SC$1$IDictionary$IsFixedSize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(438087122958)
            
            //--TRIMMABLE-BOUNDARY-START(442382090254)
            /*bool */ get SC$1$IDictionary$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(442382090254)
            
            //--TRIMMABLE-BOUNDARY-START(446677057550)
            /*ICollection */ get SC$1$IDictionary$Keys()
            {
                return this.GetKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(446677057550)
            
            //--TRIMMABLE-BOUNDARY-START(450972024846)
            /*void */ SC$1$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972024846);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                if ($.$is(key, TKey, { set $v($v){ tkey = $v; } }))
                {
                    this.TryRemove$1(tkey, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450972024846)
            
            //--TRIMMABLE-BOUNDARY-START(468151894030)
            /*ICollection */ get SC$1$IDictionary$Values()
            {
                return this.GetValues();
            }
            //--TRIMMABLE-BOUNDARY-END(468151894030)
            
            //--TRIMMABLE-BOUNDARY-START(463856926734)
            //--TRIMMABLE-BOUNDARY-START(90257555457)
            /*object?*/ SC$1$IDictionary$get_Item(/*object*/ key)
            {
                /*TValue?*/ let value;
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                if ($.$is(key, TKey, { set $v($v){ tkey = $v; } }) && this.TryGetValue(tkey, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    return $.$box(value, TValue);
                }
                return null;
            }
            /*void*/ SC$1$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                if (key === null)
                {
                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).set_Item$1($.$cast(key, TKey), $.$cast(value, TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(90257555457)
            
            //--TRIMMABLE-BOUNDARY-END(463856926734)
            
            //--TRIMMABLE-BOUNDARY-START(481036795918)
            static /*void */ ThrowIfInvalidObjectValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036795918);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(value === null))
                {
                    if (!($.$is(value, TValue)))
                    {
                        $.$scc.S.ThrowHelper.ThrowValueNullException();
                    }
                }
                else if (!($.$default(TValue) === null))
                {
                    $.$scc.S.ThrowHelper.ThrowValueNullException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(481036795918)
            
            //--TRIMMABLE-BOUNDARY-START(352187777038)
            /*void */ SC$1$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187777038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.S.ArgumentOutOfRangeException.ThrowIfNegative($.$$.S.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$14($.$scc.S.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    let pairs;
                    if ($.$is(array, $.$typeArray($.$$.SCG.KeyValuePair$$$(TKey, TValue)), { set $v($v){ pairs = $v; } }))
                    {
                        this.CopyToPairs(pairs, index);
                        return;
                    }
                    let entries;
                    if ($.$is(array, $.$typeArray($.$$.SC$1.DictionaryEntry), { set $v($v){ entries = $v; } }))
                    {
                        this.CopyToEntries(entries, index);
                        return;
                    }
                    let objects;
                    if ($.$is(array, $.$typeArray($.$$.S.Object), { set $v($v){ objects = $v; } }))
                    {
                        this.CopyToObjects(objects, index);
                        return;
                    }
                    throw new $.$$.S.ArgumentException().$ctor$13($.$scc.S.SR.ConcurrentDictionary_ArrayIncorrectType, "array");
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352187777038)
            
            //--TRIMMABLE-BOUNDARY-START(373662613518)
            /*bool */ get SC$1$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(373662613518)
            
            //--TRIMMABLE-BOUNDARY-START(377957580814)
            /*object */ get SC$1$ICollection$SyncRoot()
            {
                throw new $.$$.S.NotSupportedException().$ctor$12($.$scc.S.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            //--TRIMMABLE-BOUNDARY-END(377957580814)
            
            //--TRIMMABLE-BOUNDARY-START(85899804686)
            /*bool */ AreAllBucketsEmpty()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899804686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !$.$$.S.MemoryExtensions.ContainsAnyExcept$8($.$$.S.Int32, $.$$.S.Span$$($.$$.S.Int32).op_Implicit($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Int32, this._tables._countPerLock)), 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899804686)
            
            //--TRIMMABLE-BOUNDARY-START(244813594638)
            /*void */ GrowTable(/*Tables*/ tables, /*bool*/ resizeDesired, /*bool*/ forceRehashIfNonRandomized)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireFirstLock($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    if (tables !== this._tables)
                    {
                        return;
                    }
                    /*int*/ let newLength = tables._buckets.length;
                    /*IEqualityComparer<TKey>?*/ let upgradeComparer = null;
                    let nrsec;
                    if (forceRehashIfNonRandomized && $.$is(tables._comparer, $.$$.SCG.NonRandomizedStringEqualityComparer, { set $v($v){ nrsec = $v; } }))
                    {
                        upgradeComparer = $.$cast(nrsec.GetUnderlyingEqualityComparer(), $.$$.SCG.IEqualityComparer$$(TKey));
                    }
                    if (resizeDesired)
                    {
                        if (upgradeComparer === null && this.GetCountNoLocks() < $.trunc(tables._buckets.length / 4))
                        {
                            this._budget = ((2 * this._budget) | 0);
                            if (this._budget < 0)
                            {
                                this._budget = 2147483647/*int.MaxValue*/;
                            }
                            return;
                        }
                        if ((newLength = ((tables._buckets.length * 2) | 0)) < 0 || (newLength = $.$scc.SC.HashHelpers.GetPrime(newLength)) > $.$$.S.Array.MaxLength)
                        {
                            newLength = $.$$.S.Array.MaxLength;
                            this._budget = 2147483647/*int.MaxValue*/;
                        }
                    }
                    /*object[]*/ let newLocks = tables._locks;
                    if (this._growLockArray && tables._locks.length < 1024/*MaxLockNumber*/)
                    {
                        newLocks = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), null, [((tables._locks.length * 2) | 0)], null);
                        $.$$.S.Array.Copy$2(tables._locks, newLocks, tables._locks.length);
                        for(/*int*/ let i = tables._locks.length; i < newLocks.length; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(newLocks, new $.$$.S.Object().$ctor(), i);
                        }
                    }
                    /*var*/ let newBuckets = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [newLength], null);
                    /*var*/ let newCountPerLock = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Int32), null, [newLocks.length], null);
                    /*var*/ let newTables = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(newBuckets, newLocks, newCountPerLock, upgradeComparer ?? tables._comparer);
                    $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(tables, $.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    let $i40 = 0;
                    let $arr40 = tables._buckets;
                    while ($i40 < $arr40.length)
                    {
                        let bucket = $arr40[$i40++];
                        /*Node?*/ let current = bucket._node;
                        while(!(current === null))
                        {
                            /*uint*/ let newLockNo;
                            /*int*/ let hashCode = upgradeComparer === null ? current._hashcode : upgradeComparer[`SCG$IEqualityComparer$${TKey.$getFullName('$')}$GetHashCode`](current._key);
                            /*Node?*/ let next = current._next;
                            /*ref Node?*/ let newBucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(newTables, hashCode, $.$ref(() => newLockNo, ($v) => newLockNo = $v, $.$$.S.UInt32));
                            newBucket.$v = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(current._key, current._value, hashCode, newBucket.$v);
                            //checked
                            {
                                let $t42 = $.$$.System.Array.$ReadT1.call(newCountPerLock, newLockNo);
                                $.$$.System.Array.$WriteT1.call(newCountPerLock, $t42 + 1, newLockNo);
                            }
                            current = next;
                        }
                    }
                    this._budget = $.$$.S.Math.Max$4(1, $.trunc(newBuckets.length / newLocks.length));
                    this._tables = newTables;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813594638)
            
            //--TRIMMABLE-BOUNDARY-START(124554510350)
            static /*int */ get DefaultConcurrencyLevel()
            {
                return $.$$.S.Environment.ProcessorCount;
            }
            //--TRIMMABLE-BOUNDARY-END(124554510350)
            
            //--TRIMMABLE-BOUNDARY-START(60130000910)
            /*void */ AcquireAllLocks(/*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scc.SCC.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.SCC.CDSCollectionETWBCLProvider.Log.ConcurrentDictionary_AcquiringAllLocks(this._tables._buckets.length);
                }
                this.AcquireFirstLock(locksAcquired);
                $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(this._tables, locksAcquired);
                $.$$.SD.Debug.Assert$4(locksAcquired.$v === this._tables._locks.length, "locksAcquired == _tables._locks.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(60130000910)
            
            //--TRIMMABLE-BOUNDARY-START(64424968206)
            /*void */ AcquireFirstLock(/*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let locks = this._tables._locks;
                $.$$.SD.Debug.Assert$4(locksAcquired.$v === 0, "locksAcquired == 0");
                $.$$.SD.Debug.Assert$4(!$.$$.ST$1.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "!Monitor.IsEntered(locks[0])");
                $.$$.ST$1.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, 0));
                locksAcquired.$v = 1;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968206)
            
            //--TRIMMABLE-BOUNDARY-START(68719935502)
            static /*void */ AcquirePostFirstLock(/*Tables*/ tables, /*ref int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let locks = tables._locks;
                $.$$.SD.Debug.Assert$4($.$$.ST$1.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "Monitor.IsEntered(locks[0])");
                $.$$.SD.Debug.Assert$4(locksAcquired.$v === 1, "locksAcquired == 1");
                for(/*int*/ let i = 1; i < locks.length; i++)
                {
                    $.$$.ST$1.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, i));
                    locksAcquired.$v++;
                }
                $.$$.SD.Debug.Assert$4(locksAcquired.$v === locks.length, "locksAcquired == locks.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(68719935502)
            
            //--TRIMMABLE-BOUNDARY-START(274878365710)
            /*void */ ReleaseLocks(/*int*/ locksAcquired)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878365710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(locksAcquired >= 0, "locksAcquired >= 0");
                /*object[]*/ let locks = this._tables._locks;
                for(/*int*/ let i = 0; i < locksAcquired; i++)
                {
                    $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274878365710)
            
            //--TRIMMABLE-BOUNDARY-START(223338758158)
            /*ReadOnlyCollection<TKey> */ GetKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338758158);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.SCO.ReadOnlyCollection$$(TKey).Empty;
                    }
                    /*var*/ let keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [count], null);
                    /*int*/ let i = 0;
                    let $i46 = 0;
                    let $arr46 = this._tables._buckets;
                    while ($i46 < $arr46.length)
                    {
                        let bucket = $arr46[$i46++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._key, i);
                            i++;
                        }
                    }
                    $.$$.SD.Debug.Assert$4(i === count, "i == count");
                    return new ($.$$.SCO.ReadOnlyCollection$$(TKey))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338758158)
            
            //--TRIMMABLE-BOUNDARY-START(240518627342)
            /*ReadOnlyCollection<TValue> */ GetValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.S.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.SCO.ReadOnlyCollection$$(TValue).Empty;
                    }
                    /*var*/ let keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [count], null);
                    /*int*/ let i = 0;
                    let $i48 = 0;
                    let $arr48 = this._tables._buckets;
                    while ($i48 < $arr48.length)
                    {
                        let bucket = $arr48[$i48++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._value, i);
                            i++;
                        }
                    }
                    $.$$.SD.Debug.Assert$4(i === count, "i == count");
                    return new ($.$$.SCO.ReadOnlyCollection$$(TValue))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518627342)
            
            //--TRIMMABLE-BOUNDARY-START(851982)
            static $_VolatileNode;
            static get VolatileNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(851982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_VolatileNode ??= $asm.$nstr(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.VolatileNode`, ($self) => class VolatileNode extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819278)
                    /*Node?*/ _node = null;
                    //--TRIMMABLE-BOUNDARY-END(4295819278)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786574)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590786574);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590786574)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786574)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590786574)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._node = this._node;
                        return copy;
                    }
                    static $H = 851982;
                    static $h = 851982;
                    static $z = 4;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819278),
    {
      "t": 720910,
      "n": "_node",
      "d": 851982,
      "H": 4295819278,
      "h": Number(BigInt(851982)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295819278)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786574),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851982,
      "H": 8590786574,
      "h": Number(BigInt(851982)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786574)
  ],
  "d": 458766,
  "H": 851982,
  "h": 851982
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+VolatileNode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}VolatileNode`; }
                }, $cls, ($v) => $cls.$_VolatileNode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851982)
            
            //--TRIMMABLE-BOUNDARY-START(720910)
            static $_Node;
            static get Node()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720910);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Node ??= $asm.$ncls(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Node`, ($self) => class Node extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655502)
                    /*TKey*/ _key = $.$default(TKey);
                    //--TRIMMABLE-BOUNDARY-END(8590655502)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180590094)
                    /*TValue*/ _value = $.$default(TValue);
                    //--TRIMMABLE-BOUNDARY-END(17180590094)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885622798)
                    /*Node?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(12885622798)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295688206)
                    /*int*/ _hashcode = 0;
                    //--TRIMMABLE-BOUNDARY-END(4295688206)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475557390)
                    $ctor$1(/*TKey*/ key, /*TValue*/ value, /*int*/ hashcode, /*Node?*/ next)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475557390);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._key = key;
                            this._value = value;
                            this._next = next;
                            this._hashcode = hashcode;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475557390)
                    
                    static $H = 720910;
                    static $h = 720910;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655502),
    {
      "t": TKey?.$h??1572864,
      "n": "_key",
      "d": 720910,
      "H": 8590655502,
      "h": Number(BigInt(720910)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590655502),
//--TRIMMABLE-BOUNDARY-START(17180590094),
    {
      "t": TValue?.$h??1638400,
      "n": "_value",
      "d": 720910,
      "H": 17180590094,
      "h": Number(BigInt(720910)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180590094),
//--TRIMMABLE-BOUNDARY-START(12885622798),
    {
      "t": 720910,
      "n": "_next",
      "d": 720910,
      "H": 12885622798,
      "h": Number(BigInt(720910)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885622798),
//--TRIMMABLE-BOUNDARY-START(4295688206),
    {
      "t": 655361,
      "n": "_hashcode",
      "d": 720910,
      "H": 4295688206,
      "h": Number(BigInt(720910)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295688206)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475557390),
    {
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "next",
          "p": 720910
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720910,
      "H": 21475557390,
      "h": Number(BigInt(720910)|0x500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475557390)
  ],
  "d": 458766,
  "H": 720910,
  "h": 720910
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+Node`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(720910)
            
            //--TRIMMABLE-BOUNDARY-START(197568954382)
            static /*Node? */ GetBucket(/*Tables*/ tables, /*int*/ hashcode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*VolatileNode[]*/ let buckets = tables._buckets;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    return $.$$.System.Array.$ReadT1.call(buckets, (hashcode >>> 0) % (buckets.length >>> 0))._node;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568954382)
            
            //--TRIMMABLE-BOUNDARY-START(201863921678)
            static /*ref Node? */ GetBucketAndLock(/*Tables*/ tables, /*int*/ hashcode, /*out uint*/ lockNo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*VolatileNode[]*/ let buckets = tables._buckets;
                /*uint*/ let bucketNo;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    bucketNo = (hashcode >>> 0) % (buckets.length >>> 0);
                }
                lockNo.$v = bucketNo % (tables._locks.length >>> 0);
                return $.$ref(() => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node, ($v) => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node = $v, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node);
            }
            //--TRIMMABLE-BOUNDARY-END(201863921678)
            
            //--TRIMMABLE-BOUNDARY-START(786446)
            static $_Tables;
            static get Tables()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786446);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Tables ??= $asm.$ncls(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Tables`, ($self) => class Tables extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590721038)
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    //--TRIMMABLE-BOUNDARY-END(8590721038)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753742)
                    /*VolatileNode[]*/ _buckets = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753742)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655630)
                    /*ulong*/ _fastModBucketsMultiplier = 0n;
                    //--TRIMMABLE-BOUNDARY-END(17180655630)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475622926)
                    /*object[]*/ _locks = null;
                    //--TRIMMABLE-BOUNDARY-END(21475622926)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688334)
                    /*int[]*/ _countPerLock = null;
                    //--TRIMMABLE-BOUNDARY-END(12885688334)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590222)
                    $ctor$1(/*VolatileNode[]*/ buckets, /*object[]*/ locks, /*int[]*/ countPerLock, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770590222);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(TKey.$type.IsValueType || !(comparer === null), "typeof(TKey).IsValueType || comparer is not null");
                            this._buckets = buckets;
                            this._locks = locks;
                            this._countPerLock = countPerLock;
                            this._comparer = comparer;
                            //if (IntPtr.Size == 8) { ... }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590222)
                    
                    static $H = 786446;
                    static $h = 786446;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590721038),
    {
      "t": $.$$.SCG.IEqualityComparer$$(TKey).$h,
      "n": "_comparer",
      "d": 786446,
      "H": 8590721038,
      "h": Number(BigInt(786446)|0x200000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590721038),
//--TRIMMABLE-BOUNDARY-START(4295753742),
    {
      "t": $.$typeArray($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,
      "n": "_buckets",
      "d": 786446,
      "H": 4295753742,
      "h": Number(BigInt(786446)|0x100000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295753742),
//--TRIMMABLE-BOUNDARY-START(17180655630),
    {
      "t": 983041,
      "n": "_fastModBucketsMultiplier",
      "d": 786446,
      "H": 17180655630,
      "h": Number(BigInt(786446)|0x400000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180655630),
//--TRIMMABLE-BOUNDARY-START(21475622926),
    {
      "t": $.$typeArray($.$$.S.Object).$h,
      "n": "_locks",
      "d": 786446,
      "H": 21475622926,
      "h": Number(BigInt(786446)|0x500000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475622926),
//--TRIMMABLE-BOUNDARY-START(12885688334),
    {
      "t": $.$typeArray($.$$.S.Int32).$h,
      "n": "_countPerLock",
      "d": 786446,
      "H": 12885688334,
      "h": Number(BigInt(786446)|0x300000000n),
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885688334)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770590222),
    {
      "p": [
        {
          "n": "buckets",
          "p": $.$typeArray($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h
        },
        {
          "n": "locks",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "countPerLock",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786446,
      "H": 25770590222,
      "h": Number(BigInt(786446)|0x600000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770590222)
  ],
  "d": 458766,
  "H": 786446,
  "h": 786446
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+Tables`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}Tables`; }
                }, $cls, ($v) => $cls.$_Tables = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786446)
            
            //--TRIMMABLE-BOUNDARY-START(589838)
            static $_DictionaryEnumerator;
            static get DictionaryEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589838);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_DictionaryEnumerator ??= $asm.$ncls(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.DictionaryEnumerator`, ($self) => class DictionaryEnumerator extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557134)
                    /*IEnumerator<KeyValuePair<TKey, TValue>>*/ _enumerator = null;
                    //--TRIMMABLE-BOUNDARY-END(4295557134)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524430)
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590524430);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._enumerator = dictionary.GetEnumerator();
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590524430)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459022)
                    /*DictionaryEntry */ get Entry()
                    {
                        return new $.$$.SC$1.DictionaryEntry().$ctor$3($.$box(this._enumerator.SCG$IEnumerator$$$Current.Key, TKey), $.$box(this._enumerator.SCG$IEnumerator$$$Current.Value, TValue));
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459022)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835164686)
                    /*object */ get Key()
                    {
                        return $.$box(this._enumerator.SCG$IEnumerator$$$Current.Key, TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835164686)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720066574)
                    /*object? */ get Value()
                    {
                        return $.$box(this._enumerator.SCG$IEnumerator$$$Current.Value, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720066574)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491726)
                    /*object */ get Current()
                    {
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885491726)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130131982)
                    /*bool */ MoveNext()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60130131982);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._enumerator.SC$1$IEnumerator$MoveNext();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130131982)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425099278)
                    /*void */ Reset()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425099278);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._enumerator.SC$1$IEnumerator$Reset();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425099278)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538144257)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get SC$1$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34423046145);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538144257)
                    
                    //--TRIMMABLE-BOUNDARY-START(30128078849)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get SC$1$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38718013441);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30128078849)
                    
                    //--TRIMMABLE-BOUNDARY-START(12948209665)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get SC$1$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4358275073);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12948209665)
                    
                    //--TRIMMABLE-BOUNDARY-START(17243373569)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    SC$1$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17243373569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17243373569)
                    
                    //--TRIMMABLE-BOUNDARY-START(12948406273)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get SC$1$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4358471681);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12948406273)
                    
                    //--TRIMMABLE-BOUNDARY-START(21538340865)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    SC$1$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21538340865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21538340865)
                    
                    static $H = 589838;
                    static $h = 589838;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180459022),
    {
      "p": 57409537,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360328206,
        "h": Number(BigInt(589838)|0x800000000n),
        "f": 50331649
      },
      "n": "Entry",
      "d": 589838,
      "H": 17180459022,
      "h": Number(BigInt(589838)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180459022),
//--TRIMMABLE-BOUNDARY-START(55835164686),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950262798,
        "h": Number(BigInt(589838)|0xA00000000n),
        "f": 50331649
      },
      "n": "Key",
      "d": 589838,
      "H": 55835164686,
      "h": Number(BigInt(589838)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835164686),
//--TRIMMABLE-BOUNDARY-START(68720066574),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 51540197390,
        "h": Number(BigInt(589838)|0xC00000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": 589838,
      "H": 68720066574,
      "h": Number(BigInt(589838)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720066574),
//--TRIMMABLE-BOUNDARY-START(12885491726),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770393614,
        "h": Number(BigInt(589838)|0x600000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 589838,
      "H": 12885491726,
      "h": Number(BigInt(589838)|0x300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885491726)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130131982),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 589838,
      "H": 60130131982,
      "h": Number(BigInt(589838)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130131982),
//--TRIMMABLE-BOUNDARY-START(64425099278),
    {
      "r": 65537,
      "n": "Reset",
      "d": 589838,
      "H": 64425099278,
      "h": Number(BigInt(589838)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425099278)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557134),
    {
      "t": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "_enumerator",
      "d": 589838,
      "H": 4295557134,
      "h": Number(BigInt(589838)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557134)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524430),
    {
      "p": [
        {
          "n": "dictionary",
          "p": 458766
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589838,
      "H": 8590524430,
      "h": Number(BigInt(589838)|0x200000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590524430)
  ],
  "d": 458766,
  "H": 589838,
  "h": 589838
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SC$1.IDictionaryEnumerator, $.$$.SC$1.IEnumerator ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+DictionaryEnumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}DictionaryEnumerator`; }
                }, $cls, ($v) => $cls.$_DictionaryEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589838)
            
            //--TRIMMABLE-BOUNDARY-START(253403529230)
            static /*bool */ IsCompatibleKey(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(!(tables === null), "tables is not null");
                return $.$is(tables._comparer, $.$$.SCG.IAlternateEqualityComparer$$$(TAlternateKey, TKey));
            }
            //--TRIMMABLE-BOUNDARY-END(253403529230)
            
            //--TRIMMABLE-BOUNDARY-START(188979019790)
            static /*IAlternateEqualityComparer<TAlternateKey, TKey> */ GetAlternateComparer(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979019790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, tables), "IsCompatibleKey<TAlternateKey>(tables)");
                return tables._comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(188979019790)
            
            //--TRIMMABLE-BOUNDARY-START(524302)
            static $_AlternateLookup$$;
            static AlternateLookup$$(TAlternateKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524302);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue);
                return ($cls.$_AlternateLookup$$ ??= $asm.$nstr(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.AlternateLookup<>`, (TAlternateKey) => $asm.$gt(`$scc.SCC.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.AlternateLookup<>`, [TAlternateKey], ($self) => class AlternateLookup$$ extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426190)
                    $ctor$3(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885426190);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(!(dictionary === null), "dictionary is not null");
                            $.$$.SD.Debug.Assert$4($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, dictionary._tables), "IsCompatibleKey<TAlternateKey>(dictionary._tables)");
                            this.Dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885426190)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360782)
                    /*ConcurrentDictionary<TKey, TValue>*/ Dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(21475360782)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540131854)
                    /*TValue*/ get_Item$1(/*TAlternateKey*/ key)
                    {
                        /*TValue?*/ let value;
                        return this.TryGetValue$1(key, $.$ref(() => value, ($v) => value = $v, TValue)) ? value : (() =>
                        {
        throw new $.$$.SCG.KeyNotFoundException().$ctor$9()                })();
                    }
                    /*void*/ set_Item$1(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        this.TryAdd(key, value, true, $.$discardRef());
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540131854)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180393486)
                    /*bool */ ContainsKey(/*TAlternateKey*/ key)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180393486);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryGetValue$1(key, $.$discardRef());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180393486)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130066446)
                    /*bool */ TryAdd$1(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60130066446);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryAdd(key, value, false, $.$discardRef());
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130066446)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835099150)
                    /*bool */ TryAdd(/*TAlternateKey*/ key, /*TValue*/ value, /*bool*/ updateIfExists, /*out TValue*/ resultingValue)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835099150);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.S.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$GetHashCode`](key);
                        while(true)
                        {
                            /*uint*/ let lockNo;
                            /*object[]*/ let locks = tables._locks;
                            /*ref Node?*/ let bucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.S.UInt32));
                            /*bool*/ let resizeDesired = false;
                            /*bool*/ let forceRehash = false;
                            /*bool*/ let lockTaken = false;
                            try
                            {
                                $.$$.ST$1.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Boolean, () => lockTaken, ($v) => lockTaken = $v, null, true));
                                if (tables !== this.Dictionary._tables)
                                {
                                    tables = this.Dictionary._tables;
                                    if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                                    {
                                        comparer = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                        hashcode = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$GetHashCode`](key);
                                    }
                                    continue;
                                }
                                /*uint*/ let collisionCount = 0;
                                /*Node?*/ let prev = null;
                                for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                                {
                                    $.$$.SD.Debug.Assert$4((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                    if (hashcode === node._hashcode && comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$Equals`](key, node._key))
                                    {
                                        if (updateIfExists)
                                        {
                                            if (!TValue.$type.IsValueType || $.$scc.SCC.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                            {
                                                node._value = value;
                                            }
                                            else 
                                            {
                                                /*var*/ let newNode = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                                if (prev === null)
                                                {
                                                    bucket.$v = newNode;
                                                }
                                                else 
                                                {
                                                    prev._next = newNode;
                                                }
                                            }
                                            resultingValue.$v = value;
                                        }
                                        else 
                                        {
                                            resultingValue.$v = node._value;
                                        }
                                        return false;
                                    }
                                    prev = node;
                                    if (!TKey.$type.IsValueType)
                                    {
                                        collisionCount++;
                                    }
                                }
                                /*TKey*/ let actualKey = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$Create`](key);
                                if (actualKey === null)
                                {
                                    $.$scc.S.ThrowHelper.ThrowKeyNullException();
                                }
                                /*var*/ let resultNode = new ($.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(actualKey, value, hashcode, bucket.$v);
                                bucket.$v = resultNode;
                                //checked
                                {
                                    let $t54 = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                    $.$$.System.Array.$WriteT1.call(tables._countPerLock, $t54 + 1, lockNo);
                                }
                                if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this.Dictionary._budget)
                                {
                                    resizeDesired = true;
                                }
                                if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.SCG.NonRandomizedStringEqualityComparer))
                                {
                                    forceRehash = true;
                                }
                            }
                            finally
                            {
                                {
                                    if (lockTaken)
                                    {
                                        $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                                    }
                                }
                            }
                            if ($.$$.S.Boolean.op_BitwiseOr$2(resizeDesired, forceRehash))
                            {
                                this.Dictionary.GrowTable(tables, resizeDesired, forceRehash);
                            }
                            resultingValue.$v = value;
                            return true;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835099150)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720001038)
                    /*bool */ TryGetValue$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68720001038);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryGetValue(key, $.$discardRef(), value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720001038)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425033742)
                    /*bool */ TryGetValue(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425033742);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.S.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$GetHashCode`](key);
                        for(/*Node?*/ let n = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                        {
                            if (hashcode === n._hashcode && comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$Equals`](key, n._key))
                            {
                                actualKey.$v = n._key;
                                value.$v = n._value;
                                return true;
                            }
                        }
                        actualKey.$v = $.$default(TKey);
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425033742)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309935630)
                    /*bool */ TryRemove$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(77309935630);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.TryRemove(key, $.$discardRef(), value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309935630)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014968334)
                    /*bool */ TryRemove(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014968334);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (key === null)
                        {
                            $.$scc.S.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$GetHashCode`](key);
                        while(true)
                        {
                            /*uint*/ let lockNo;
                            /*object[]*/ let locks = tables._locks;
                            /*ref Node?*/ let bucket = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.S.UInt32));
                            if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) !== 0)
                            {
                                //lock(locks[lockNo])
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                    {
                                        if (tables !== this.Dictionary._tables)
                                        {
                                            tables = this.Dictionary._tables;
                                            if (!$.$$.S.Object.ReferenceEquals(comparer, tables._comparer))
                                            {
                                                comparer = $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                                hashcode = comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$GetHashCode`](key);
                                            }
                                            continue;
                                        }
                                        /*Node?*/ let prev = null;
                                        for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                                        {
                                            $.$$.SD.Debug.Assert$4((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                            if (hashcode === curr._hashcode && comparer[`SCG$IAlternateEqualityComparer$${TAlternateKey.$getFullName('$')}$${TKey.$getFullName('$')}$Equals`](key, curr._key))
                                            {
                                                if (prev === null)
                                                {
                                                    bucket.$v = curr._next;
                                                }
                                                else 
                                                {
                                                    prev._next = curr._next;
                                                }
                                                actualKey.$v = curr._key;
                                                value.$v = curr._value;
                                                let $t59 = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                                $.$$.System.Array.$WriteT1.call(tables._countPerLock, $t59 - 1, lockNo);
                                                return true;
                                            }
                                            prev = curr;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                }
                            }
                            actualKey.$v = $.$default(TKey);
                            value.$v = $.$default(TValue);
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014968334)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458894)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590458894);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458894)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458894)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590458894)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Dictionary = this.Dictionary;
                        return copy;
                    }
                    static $H = 524302;
                    static $h = 524302;
                    static $g = 1;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360782),
    {
      "p": 458766,
      "g": {
        "r": 0,
        "d": 0,
        "H": 30065295374,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Dictionary",
      "d": this.$h,
      "H": 21475360782,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360782),
//--TRIMMABLE-BOUNDARY-START(51540131854),
    {
      "p": TValue?.$h??1638400,
      "i": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 38655229966,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 47245164558,
        "h": Number(BigInt(this.$h)|0xB00000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 51540131854,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540131854)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180393486),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        }
      ],
      "n": "ContainsKey",
      "d": this.$h,
      "H": 17180393486,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393486),
//--TRIMMABLE-BOUNDARY-START(60130066446),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "TryAdd",
      "o": "@$1",
      "d": this.$h,
      "H": 60130066446,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130066446),
//--TRIMMABLE-BOUNDARY-START(55835099150),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        },
        {
          "n": "updateIfExists",
          "p": 262145
        },
        {
          "n": "resultingValue",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "H": 55835099150,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835099150),
//--TRIMMABLE-BOUNDARY-START(68720001038),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "o": "@$1",
      "d": this.$h,
      "H": 68720001038,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720001038),
//--TRIMMABLE-BOUNDARY-START(64425033742),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "actualKey",
          "p": TKey?.$h??1572864,
          "f": 2
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "H": 64425033742,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425033742),
//--TRIMMABLE-BOUNDARY-START(77309935630),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "o": "@$1",
      "d": this.$h,
      "H": 77309935630,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309935630),
//--TRIMMABLE-BOUNDARY-START(73014968334),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TAlternateKey?.$h??1572864
        },
        {
          "n": "actualKey",
          "p": TKey?.$h??1572864,
          "f": 2
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "H": 73014968334,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014968334)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426190),
    {
      "p": [
        {
          "n": "dictionary",
          "p": 458766
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 12885426190,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885426190),
//--TRIMMABLE-BOUNDARY-START(8590458894),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 8590458894,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458894)
  ],
  "s": [
    {
      "h": TAlternateKey?.$h??1572864,
      "n": "TAlternateKey",
      "f": 64
    }
  ],
  "r": 1,
  "d": 458766,
  "H": 524302,
  "h": this.$h
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>+AlternateLookup<${TAlternateKey?.$fullName}>`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$${separator}AlternateLookup$${TAlternateKey?.$getFullName(separator)}$`; }
                }), $cls, ($v) => $cls.$_AlternateLookup$$ = $v))(TAlternateKey);
            }
            //--TRIMMABLE-BOUNDARY-END(524302)
            
            //--TRIMMABLE-BOUNDARY-START(17240096769)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            SCG$IDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17240096769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17240096769)
            
            //--TRIMMABLE-BOUNDARY-START(51599835137)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            SCG$IDictionary$$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51599835137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51599835137)
            
            //--TRIMMABLE-BOUNDARY-START(25830031361)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Keys.get
            get SCG$IDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38714933249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(25830031361)
            
            //--TRIMMABLE-BOUNDARY-START(34419965953)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Values.get
            get SCG$IDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64484737025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(34419965953)
            
            //--TRIMMABLE-BOUNDARY-START(8650162177)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            SCG$IDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650162177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650162177)
            
            //--TRIMMABLE-BOUNDARY-START(60189769729)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            SCG$IDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60189769729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60189769729)
            
            //--TRIMMABLE-BOUNDARY-START(30124802049)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get SCG$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534867457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124802049)
            
            //--TRIMMABLE-BOUNDARY-START(8649965569)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            SCG$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649965569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649965569)
            
            //--TRIMMABLE-BOUNDARY-START(8653176833)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            SC$1$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653176833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653176833)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(4355784705)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            SCG$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355784705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355784705)
            
            //--TRIMMABLE-BOUNDARY-START(43010490369)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            SCG$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43010490369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43010490369)
            
            //--TRIMMABLE-BOUNDARY-START(12945719297)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            SCG$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945719297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12945719297)
            
            //--TRIMMABLE-BOUNDARY-START(12945653761)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get SCG$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355719169);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12945653761)
            
            //--TRIMMABLE-BOUNDARY-START(4355325953)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey, TValue>>.GetEnumerator()
            SCG$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355325953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355325953)
            
            //--TRIMMABLE-BOUNDARY-START(25770262542)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(25770262542)
            
            static $H = 458766;
            static $h = 458766;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(476741828622),
    {
      "p": TValue?.$h??1638400,
      "i": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 167504183310,
        "h": Number(BigInt(this.$h)|0x2700000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 283468300302,
        "h": Number(BigInt(this.$h)|0x4200000000n),
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": this.$h,
      "H": 476741828622,
      "h": Number(BigInt(this.$h)|0x6F00000000n),
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(476741828622),
//--TRIMMABLE-BOUNDARY-START(94489739278),
    {
      "p": $.$$.SCG.IEqualityComparer$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144444942,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "n": "Comparer",
      "d": this.$h,
      "H": 94489739278,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489739278),
//--TRIMMABLE-BOUNDARY-START(115964575758),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 141734379534,
        "h": Number(BigInt(this.$h)|0x2100000000n),
        "f": 50331649
      },
      "n": "Count",
      "d": this.$h,
      "H": 115964575758,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964575758),
//--TRIMMABLE-BOUNDARY-START(257698496526),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 158914248718,
        "h": Number(BigInt(this.$h)|0x2500000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "H": 257698496526,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698496526),
//--TRIMMABLE-BOUNDARY-START(261993463822),
    {
      "p": $.$$.SCG.ICollection$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 176094117902,
        "h": Number(BigInt(this.$h)|0x2900000000n),
        "f": 50331649
      },
      "n": "Keys",
      "d": this.$h,
      "H": 261993463822,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261993463822),
//--TRIMMABLE-BOUNDARY-START(343597842446),
    {
      "p": $.$$.SCG.IEnumerable$$(TKey).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 330712940558,
        "h": Number(BigInt(this.$h)|0x4D00000000n),
        "f": 50331650
      },
      "n": "{$.$$.SCG.IReadOnlyDictionary$$$(TKey, TValue).$h}.Keys",
      "o": "SCG$IReadOnlyDictionary$$$$Keys",
      "d": this.$h,
      "H": 343597842446,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(343597842446),
//--TRIMMABLE-BOUNDARY-START(536871370766),
    {
      "p": $.$$.SCG.ICollection$$(TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 184684052494,
        "h": Number(BigInt(this.$h)|0x2B00000000n),
        "f": 50331649
      },
      "n": "Values",
      "d": this.$h,
      "H": 536871370766,
      "h": Number(BigInt(this.$h)|0x7D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(536871370766),
//--TRIMMABLE-BOUNDARY-START(347892809742),
    {
      "p": $.$$.SCG.IEnumerable$$(TValue).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 339302875150,
        "h": Number(BigInt(this.$h)|0x4F00000000n),
        "f": 50331650
      },
      "n": "{$.$$.SCG.IReadOnlyDictionary$$$(TKey, TValue).$h}.Values",
      "o": "SCG$IReadOnlyDictionary$$$$Values",
      "d": this.$h,
      "H": 347892809742,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(347892809742),
//--TRIMMABLE-BOUNDARY-START(309238104078),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 304943136782,
        "h": Number(BigInt(this.$h)|0x4700000000n),
        "f": 50331650
      },
      "n": "{$.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h}.IsReadOnly",
      "o": "SCG$ICollection$$$IsReadOnly",
      "d": this.$h,
      "H": 309238104078,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(309238104078),
//--TRIMMABLE-BOUNDARY-START(438087122958),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 395137449998,
        "h": Number(BigInt(this.$h)|0x5C00000000n),
        "f": 50331650
      },
      "n": "{63242241}.IsFixedSize",
      "o": "SC$1$IDictionary$IsFixedSize",
      "d": this.$h,
      "H": 438087122958,
      "h": Number(BigInt(this.$h)|0x6600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(438087122958),
//--TRIMMABLE-BOUNDARY-START(442382090254),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 403727384590,
        "h": Number(BigInt(this.$h)|0x5E00000000n),
        "f": 50331650
      },
      "n": "{63242241}.IsReadOnly",
      "o": "SC$1$IDictionary$IsReadOnly",
      "d": this.$h,
      "H": 442382090254,
      "h": Number(BigInt(this.$h)|0x6700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(442382090254),
//--TRIMMABLE-BOUNDARY-START(446677057550),
    {
      "p": 63111169,
      "g": {
        "r": 0,
        "d": 0,
        "H": 420907253774,
        "h": Number(BigInt(this.$h)|0x6200000000n),
        "f": 50331650
      },
      "n": "{63242241}.Keys",
      "o": "SC$1$IDictionary$Keys",
      "d": this.$h,
      "H": 446677057550,
      "h": Number(BigInt(this.$h)|0x6800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(446677057550),
//--TRIMMABLE-BOUNDARY-START(468151894030),
    {
      "p": 63111169,
      "g": {
        "r": 0,
        "d": 0,
        "H": 429497188366,
        "h": Number(BigInt(this.$h)|0x6400000000n),
        "f": 50331650
      },
      "n": "{63242241}.Values",
      "o": "SC$1$IDictionary$Values",
      "d": this.$h,
      "H": 468151894030,
      "h": Number(BigInt(this.$h)|0x6D00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(468151894030),
//--TRIMMABLE-BOUNDARY-START(463856926734),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "H": 412317319182,
        "h": Number(BigInt(this.$h)|0x6000000000n),
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 459561959438,
        "h": Number(BigInt(this.$h)|0x6B00000000n),
        "f": 83886082
      },
      "n": "{63242241}.this[]",
      "o": "SC$1$IDictionary$Item",
      "d": this.$h,
      "H": 463856926734,
      "h": Number(BigInt(this.$h)|0x6C00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(463856926734),
//--TRIMMABLE-BOUNDARY-START(373662613518),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 360777711630,
        "h": Number(BigInt(this.$h)|0x5400000000n),
        "f": 50331650
      },
      "n": "{63111169}.IsSynchronized",
      "o": "SC$1$ICollection$IsSynchronized",
      "d": this.$h,
      "H": 373662613518,
      "h": Number(BigInt(this.$h)|0x5700000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(373662613518),
//--TRIMMABLE-BOUNDARY-START(377957580814),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "H": 369367646222,
        "h": Number(BigInt(this.$h)|0x5600000000n),
        "f": 50331650
      },
      "n": "{63111169}.SyncRoot",
      "o": "SC$1$ICollection$SyncRoot",
      "d": this.$h,
      "H": 377957580814,
      "h": Number(BigInt(this.$h)|0x5800000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(377957580814),
//--TRIMMABLE-BOUNDARY-START(124554510350),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 150324314126,
        "h": Number(BigInt(this.$h)|0x2300000000n),
        "f": 50331682
      },
      "n": "DefaultConcurrencyLevel",
      "d": this.$h,
      "H": 124554510350,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(124554510350)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(193273987086),
    {
      "r": (TAlternateKey) => $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,
      "g": [
        "TAlternateKey"
      ],
      "n": "GetAlternateLookup",
      "d": this.$h,
      "H": 193273987086,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(193273987086),
//--TRIMMABLE-BOUNDARY-START(502511632398),
    {
      "r": 262145,
      "p": [
        {
          "n": "lookup",
          "p": (TAlternateKey) => $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,
          "f": 2
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "TryGetAlternateLookup",
      "d": this.$h,
      "H": 502511632398,
      "h": Number(BigInt(this.$h)|0x7500000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(502511632398),
//--TRIMMABLE-BOUNDARY-START(206158888974),
    {
      "r": 655361,
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": "GetCapacityFromCollection",
      "d": this.$h,
      "H": 206158888974,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158888974),
//--TRIMMABLE-BOUNDARY-START(219043790862),
    {
      "r": 655361,
      "p": [
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        },
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": this.$h,
      "H": 219043790862,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219043790862),
//--TRIMMABLE-BOUNDARY-START(270583398414),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        },
        {
          "n": "node",
          "p": 720910
        },
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "NodeEqualsKey",
      "d": this.$h,
      "H": 270583398414,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(270583398414),
//--TRIMMABLE-BOUNDARY-START(249108561934),
    {
      "r": 65537,
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": "InitializeFromCollection",
      "d": this.$h,
      "H": 249108561934,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(249108561934),
//--TRIMMABLE-BOUNDARY-START(493921697806),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "TryAdd",
      "d": this.$h,
      "H": 493921697806,
      "h": Number(BigInt(this.$h)|0x7300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(493921697806),
//--TRIMMABLE-BOUNDARY-START(98784706574),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "ContainsKey",
      "d": this.$h,
      "H": 98784706574,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784706574),
//--TRIMMABLE-BOUNDARY-START(519691501582),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryRemove",
      "o": "@$1",
      "d": this.$h,
      "H": 519691501582,
      "h": Number(BigInt(this.$h)|0x7900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(519691501582),
//--TRIMMABLE-BOUNDARY-START(515396534286),
    {
      "r": 262145,
      "p": [
        {
          "n": "item",
          "p": $.$$.SCG.KeyValuePair$$$(TKey, TValue).$h
        }
      ],
      "n": "TryRemove",
      "d": this.$h,
      "H": 515396534286,
      "h": Number(BigInt(this.$h)|0x7800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(515396534286),
//--TRIMMABLE-BOUNDARY-START(523986468878),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        },
        {
          "n": "matchValue",
          "p": 262145
        },
        {
          "n": "oldValue",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "TryRemoveInternal",
      "d": this.$h,
      "H": 523986468878,
      "h": Number(BigInt(this.$h)|0x7A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(523986468878),
//--TRIMMABLE-BOUNDARY-START(506806599694),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryGetValue",
      "d": this.$h,
      "H": 506806599694,
      "h": Number(BigInt(this.$h)|0x7600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(506806599694),
//--TRIMMABLE-BOUNDARY-START(511101566990),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryGetValueInternal",
      "d": this.$h,
      "H": 511101566990,
      "h": Number(BigInt(this.$h)|0x7700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(511101566990),
//--TRIMMABLE-BOUNDARY-START(528281436174),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "newValue",
          "p": TValue?.$h??1638400
        },
        {
          "n": "comparisonValue",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "TryUpdate",
      "d": this.$h,
      "H": 528281436174,
      "h": Number(BigInt(this.$h)|0x7B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(528281436174),
//--TRIMMABLE-BOUNDARY-START(532576403470),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "nullableHashcode",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "newValue",
          "p": TValue?.$h??1638400
        },
        {
          "n": "comparisonValue",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "TryUpdateInternal",
      "d": this.$h,
      "H": 532576403470,
      "h": Number(BigInt(this.$h)|0x7C00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(532576403470),
//--TRIMMABLE-BOUNDARY-START(90194771982),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 90194771982,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90194771982),
//--TRIMMABLE-BOUNDARY-START(489626730510),
    {
      "r": $.$typeArray($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "ToArray",
      "d": this.$h,
      "H": 489626730510,
      "h": Number(BigInt(this.$h)|0x7200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(489626730510),
//--TRIMMABLE-BOUNDARY-START(111669608462),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToPairs",
      "d": this.$h,
      "H": 111669608462,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669608462),
//--TRIMMABLE-BOUNDARY-START(103079673870),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.SC$1.DictionaryEntry).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToEntries",
      "d": this.$h,
      "H": 103079673870,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079673870),
//--TRIMMABLE-BOUNDARY-START(107374641166),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyToObjects",
      "d": this.$h,
      "H": 107374641166,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(107374641166),
//--TRIMMABLE-BOUNDARY-START(214748823566),
    {
      "r": $.$$.SCG.IEnumerator$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "H": 214748823566,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214748823566),
//--TRIMMABLE-BOUNDARY-START(498216665102),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "nullableHashcode",
          "p": $.$typeNullable($.$$.S.Int32).$h
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        },
        {
          "n": "updateIfExists",
          "p": 262145
        },
        {
          "n": "acquireLock",
          "p": 262145
        },
        {
          "n": "resultingValue",
          "p": TValue?.$h??1638400,
          "f": 2
        }
      ],
      "n": "TryAddInternal",
      "d": this.$h,
      "H": 498216665102,
      "h": Number(BigInt(this.$h)|0x7400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(498216665102),
//--TRIMMABLE-BOUNDARY-START(485331763214),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        }
      ],
      "n": "ThrowKeyNotFoundException",
      "d": this.$h,
      "H": 485331763214,
      "h": Number(BigInt(this.$h)|0x7100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(485331763214),
//--TRIMMABLE-BOUNDARY-START(210453856270),
    {
      "r": 655361,
      "n": "GetCountNoLocks",
      "d": this.$h,
      "H": 210453856270,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210453856270),
//--TRIMMABLE-BOUNDARY-START(227633725454),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "valueFactory",
          "p": $.$$.S.Func$$$(TKey, TValue).$h
        }
      ],
      "n": "GetOrAdd",
      "d": this.$h,
      "H": 227633725454,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(227633725454),
//--TRIMMABLE-BOUNDARY-START(236223660046),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "valueFactory",
          "p": (TArg) => $.$$.S.Func$$$$(TKey, TArg, TValue).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "GetOrAdd",
      "o": "@$2",
      "d": this.$h,
      "H": 236223660046,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(236223660046),
//--TRIMMABLE-BOUNDARY-START(231928692750),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "value",
          "p": TValue?.$h??1638400
        }
      ],
      "n": "GetOrAdd",
      "o": "@$1",
      "d": this.$h,
      "H": 231928692750,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231928692750),
//--TRIMMABLE-BOUNDARY-START(81604837390),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "addValueFactory",
          "p": (TArg) => $.$$.S.Func$$$$(TKey, TArg, TValue).$h
        },
        {
          "n": "updateValueFactory",
          "p": (TArg) => $.$$.S.Func$$$$$(TKey, TValue, TArg, TValue).$h
        },
        {
          "n": "factoryArgument",
          "p": (TArg) => TArg.$h
        }
      ],
      "g": [
        "TArg"
      ],
      "n": "AddOrUpdate",
      "o": "@$2",
      "d": this.$h,
      "H": 81604837390,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16908289
    },
//--TRIMMABLE-BOUNDARY-END(81604837390),
//--TRIMMABLE-BOUNDARY-START(73014902798),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "addValueFactory",
          "p": $.$$.S.Func$$$(TKey, TValue).$h
        },
        {
          "n": "updateValueFactory",
          "p": $.$$.S.Func$$$$(TKey, TValue, TValue).$h
        }
      ],
      "n": "AddOrUpdate",
      "d": this.$h,
      "H": 73014902798,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014902798),
//--TRIMMABLE-BOUNDARY-START(77309870094),
    {
      "r": TValue?.$h??1638400,
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1572864
        },
        {
          "n": "addValue",
          "p": TValue?.$h??1638400
        },
        {
          "n": "updateValueFactory",
          "p": $.$$.S.Func$$$$(TKey, TValue, TValue).$h
        }
      ],
      "n": "AddOrUpdate",
      "o": "@$1",
      "d": this.$h,
      "H": 77309870094,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309870094),
//--TRIMMABLE-BOUNDARY-START(481036795918),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ThrowIfInvalidObjectValue",
      "d": this.$h,
      "H": 481036795918,
      "h": Number(BigInt(this.$h)|0x7000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(481036795918),
//--TRIMMABLE-BOUNDARY-START(85899804686),
    {
      "r": 262145,
      "n": "AreAllBucketsEmpty",
      "d": this.$h,
      "H": 85899804686,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899804686),
//--TRIMMABLE-BOUNDARY-START(244813594638),
    {
      "r": 65537,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "resizeDesired",
          "p": 262145
        },
        {
          "n": "forceRehashIfNonRandomized",
          "p": 262145
        }
      ],
      "n": "GrowTable",
      "d": this.$h,
      "H": 244813594638,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(244813594638),
//--TRIMMABLE-BOUNDARY-START(60130000910),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquireAllLocks",
      "d": this.$h,
      "H": 60130000910,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(60130000910),
//--TRIMMABLE-BOUNDARY-START(64424968206),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquireFirstLock",
      "d": this.$h,
      "H": 64424968206,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64424968206),
//--TRIMMABLE-BOUNDARY-START(68719935502),
    {
      "r": 65537,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "locksAcquired",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "AcquirePostFirstLock",
      "d": this.$h,
      "H": 68719935502,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(68719935502),
//--TRIMMABLE-BOUNDARY-START(274878365710),
    {
      "r": 65537,
      "p": [
        {
          "n": "locksAcquired",
          "p": 655361
        }
      ],
      "n": "ReleaseLocks",
      "d": this.$h,
      "H": 274878365710,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274878365710),
//--TRIMMABLE-BOUNDARY-START(223338758158),
    {
      "r": $.$$.SCO.ReadOnlyCollection$$(TKey).$h,
      "n": "GetKeys",
      "d": this.$h,
      "H": 223338758158,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223338758158),
//--TRIMMABLE-BOUNDARY-START(240518627342),
    {
      "r": $.$$.SCO.ReadOnlyCollection$$(TValue).$h,
      "n": "GetValues",
      "d": this.$h,
      "H": 240518627342,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(240518627342),
//--TRIMMABLE-BOUNDARY-START(197568954382),
    {
      "r": 720910,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "hashcode",
          "p": 655361
        }
      ],
      "n": "GetBucket",
      "d": this.$h,
      "H": 197568954382,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(197568954382),
//--TRIMMABLE-BOUNDARY-START(201863921678),
    {
      "r": 720910,
      "p": [
        {
          "n": "tables",
          "p": 786446
        },
        {
          "n": "hashcode",
          "p": 655361
        },
        {
          "n": "lockNo",
          "p": 720897,
          "f": 2
        }
      ],
      "n": "GetBucketAndLock",
      "d": this.$h,
      "H": 201863921678,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863921678),
//--TRIMMABLE-BOUNDARY-START(253403529230),
    {
      "r": 262145,
      "p": [
        {
          "n": "tables",
          "p": 786446
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "IsCompatibleKey",
      "d": this.$h,
      "H": 253403529230,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(253403529230),
//--TRIMMABLE-BOUNDARY-START(188979019790),
    {
      "r": (TAlternateKey) => $.$$.SCG.IAlternateEqualityComparer$$$(TAlternateKey, TKey).$h,
      "p": [
        {
          "n": "tables",
          "p": 786446
        }
      ],
      "g": [
        "TAlternateKey"
      ],
      "n": "GetAlternateComparer",
      "d": this.$h,
      "H": 188979019790,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(188979019790)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475295246),
    {
      "t": 786446,
      "n": "_tables",
      "d": this.$h,
      "H": 21475295246,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475295246),
//--TRIMMABLE-BOUNDARY-START(4295426062),
    {
      "t": 655361,
      "n": "_budget",
      "d": this.$h,
      "H": 4295426062,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426062),
//--TRIMMABLE-BOUNDARY-START(12885360654),
    {
      "t": 262145,
      "n": "_growLockArray",
      "d": this.$h,
      "H": 12885360654,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885360654),
//--TRIMMABLE-BOUNDARY-START(8590393358),
    {
      "t": 262145,
      "n": "_comparerIsDefaultForClasses",
      "d": this.$h,
      "H": 8590393358,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590393358),
//--TRIMMABLE-BOUNDARY-START(17180327950),
    {
      "t": 655361,
      "n": "_initialCapacity",
      "d": this.$h,
      "H": 17180327950,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180327950),
//--TRIMMABLE-BOUNDARY-START(120259543054),
    {
      "t": 655361,
      "n": "DefaultCapacity",
      "d": this.$h,
      "H": 120259543054,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(120259543054),
//--TRIMMABLE-BOUNDARY-START(266288431118),
    {
      "t": 655361,
      "n": "MaxLockNumber",
      "d": this.$h,
      "H": 266288431118,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(266288431118)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770262542),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 25770262542,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262542),
//--TRIMMABLE-BOUNDARY-START(55835033614),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": this.$h,
      "H": 55835033614,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835033614),
//--TRIMMABLE-BOUNDARY-START(34360197134),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 34360197134,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197134),
//--TRIMMABLE-BOUNDARY-START(38655164430),
    {
      "p": [
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 38655164430,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655164430),
//--TRIMMABLE-BOUNDARY-START(30065229838),
    {
      "p": [
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 30065229838,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229838),
//--TRIMMABLE-BOUNDARY-START(42950131726),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "collection",
          "p": $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)).$h
        },
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 42950131726,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950131726),
//--TRIMMABLE-BOUNDARY-START(51540066318),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "H": 51540066318,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540066318),
//--TRIMMABLE-BOUNDARY-START(47245099022),
    {
      "p": [
        {
          "n": "concurrencyLevel",
          "p": 655361
        },
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "growLockArray",
          "p": 262145
        },
        {
          "n": "comparer",
          "p": $.$$.SCG.IEqualityComparer$$(TKey).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "H": 47245099022,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47245099022)
  ],
  "s": [
    {
      "h": TKey?.$h??1572864,
      "n": "TKey",
      "f": 64
    },
    {
      "h": TValue?.$h??1638400,
      "n": "TValue"
    }
  ],
  "r": 2,
  "H": 458766,
  "h": this.$h,
  "a": [
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 1179662,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IDictionary$$$(TKey, TValue), $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)), $.$$.SC$1.IDictionary, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyDictionary$$$(TKey, TValue), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$(TKey, TValue)), $.$$.SC$1.IEnumerable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Enumerator, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).VolatileNode, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Node, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).Tables, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).DictionaryEnumerator, $.$scc.SCC.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Collections${separator}Concurrent${separator}ConcurrentDictionary$${TKey?.$getFullName(separator)}$${TValue?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458766)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading"));
})();
//--TRIMMABLE-BOUNDARY-END(14)
