
(function ($global, $, $$, $sc, $sdt, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.Concurrent", 
    {"h":6,"f":"System.Collections.Concurrent","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Collections.Concurrent","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Collections.Concurrent","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scc.System.Collections.Concurrent.Partitioner<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner<>", [TSource], ($self) => class Partitioner$$ extends $.$$.System.Object
        {
            /*bool */ get SupportsDynamicPartitions()
            {
                return false;
            }
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2949126;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331777},"n":"SupportsDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097281}],"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$(TSource)).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473},{"r":$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,"n":"GetDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777220}],"g":[TSource?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.Partitioner<${TSource?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.OrderablePartitioner<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.OrderablePartitioner<>", [TSource], ($self) => class OrderablePartitioner$$ extends $.$scc.System.Collections.Concurrent.Partitioner$$(TSource)
        {
            $ctor$2(/*bool*/ keysOrderedInEachPartition, /*bool*/ keysOrderedAcrossPartitions, /*bool*/ keysNormalized)
            {
                super.$ctor$1();
                {
                    this.KeysOrderedInEachPartition = keysOrderedInEachPartition;
                    this.KeysOrderedAcrossPartitions = keysOrderedAcrossPartitions;
                    this.KeysNormalized = keysNormalized;
                }
                return this;
            }
            /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.Partitioner_DynamicPartitionsNotSupported);
            }
            /*bool*/ KeysOrderedInEachPartition = false;
            /*bool*/ KeysOrderedAcrossPartitions = false;
            /*bool*/ KeysNormalized = false;
            /*IList<IEnumerator<TSource>> */ GetPartitions(/*int*/ partitionCount)
            {
                /*IList<IEnumerator<KeyValuePair<long, TSource>>>*/ let orderablePartitions = this.GetOrderablePartitions(partitionCount);
                if (orderablePartitions.System$Collections$Generic$ICollection$$$Count !== partitionCount)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12("OrderablePartitioner_GetPartitions_WrongNumberOfPartitions");
                }
                /*IEnumerator<TSource>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$(TSource)), null, [partitionCount], null);
                for(/*int*/ let i = 0; i < partitionCount; i++)
                {
                    $.$$.System.Array.$WriteT1.call(partitions, new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(orderablePartitions.System$Collections$Generic$IList$$$get_Item(i, [$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))])), i);
                }
                return partitions;
            }
            /*IEnumerable<TSource> */ GetDynamicPartitions()
            {
                /*IEnumerable<KeyValuePair<long, TSource>>*/ let orderablePartitions = this.GetOrderableDynamicPartitions();
                return new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumerableDropIndices)().$ctor$1(orderablePartitions);
            }
            static $_EnumerableDropIndices;
            static get EnumerableDropIndices()
            {
                let $cls = $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource);
                return $cls.$_EnumerableDropIndices ??= $asm.$ncls("$scc.System.Collections.Concurrent.OrderablePartitioner$$.EnumerableDropIndices", ($self) => class EnumerableDropIndices extends $.$$.System.Object
                {
                    /*IEnumerable<KeyValuePair<long, TSource>>*/ _source = null;
                    $ctor$1(/*IEnumerable<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            this._source = source;
                        }
                        return this;
                    }
                    /*IEnumerator<TSource> */ GetEnumerator()
                    {
                        return new ($.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumeratorDropIndices)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)]));
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).GetEnumerator();
                    }
                    /*void */ Dispose()
                    {
                        ($.$as(this._source, $.$$.System.IDisposable))?.System$IDisposable$Dispose();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TSource>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 1376262;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"_source","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,31719425,57540609],"d":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.IEnumerable, $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>.EnumerableDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumerableDropIndices = $v);
            }
            static $_EnumeratorDropIndices;
            static get EnumeratorDropIndices()
            {
                let $cls = $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource);
                return $cls.$_EnumeratorDropIndices ??= $asm.$ncls("$scc.System.Collections.Concurrent.OrderablePartitioner$$.EnumeratorDropIndices", ($self) => class EnumeratorDropIndices extends $.$$.System.Object
                {
                    /*IEnumerator<KeyValuePair<long, TSource>>*/ _source = null;
                    $ctor$1(/*IEnumerator<KeyValuePair<long, TSource>>*/ source)
                    {
                        super.$ctor();
                        {
                            this._source = source;
                        }
                        return this;
                    }
                    /*bool */ MoveNext()
                    {
                        return this._source.System$Collections$IEnumerator$MoveNext();
                    }
                    /*TSource */ get Current()
                    {
                        return this._source.System$Collections$Generic$IEnumerator$$$Current.Value;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return $.$box((this).Current, TSource);
                    }
                    /*void */ Dispose()
                    {
                        this._source.System$IDisposable$Dispose();
                    }
                    /*void */ Reset()
                    {
                        this._source.System$Collections$IEnumerator$Reset();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TSource>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 1441798;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TSource?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331650},"n":"{31850497}.Current","o":"System$Collections$IEnumerator$Current","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097154}],"m":[{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"_source","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,57540609,31850497],"d":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TSource), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>.EnumeratorDropIndices`; }
                }, $cls, ($v) => $cls.$_EnumeratorDropIndices = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this.KeysOrderedInEachPartition = false;
                this.KeysOrderedAcrossPartitions = false;
                this.KeysNormalized = false;
            }
            static $h = 1310726;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"KeysOrderedInEachPartition","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":50331649},"n":"KeysOrderedAcrossPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"n":"KeysNormalized","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153}],"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetOrderablePartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777473},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetOrderableDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777345},{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$(TSource)).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16809985},{"r":$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,"n":"GetDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16809985}],"c":[{"p":[{"n":"keysOrderedInEachPartition","p":262145},{"n":"keysOrderedAcrossPartitions","p":262145},{"n":"keysNormalized","p":262145}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777220}],"g":[TSource?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumerableDropIndices.$h,$.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).EnumeratorDropIndices.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner$$(TSource); }
            static get $fullName() { return `System.Collections.Concurrent.OrderablePartitioner<${TSource?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            /*uint*/ static HashCollisionThreshold = 100;
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            /*int*/ static HashPrime = 101;
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            static /*int */ GetPrime(/*int*/ min)
            {
                if (min < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$scc.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$scc.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(2147483587/*MaxPrimeArrayLength*/ === $.$scc.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$scc.System.Collections.HashHelpers.GetPrime(newSize);
            }
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                return 18446744073709551615n / BigInt(divisor) + 1n;
            }
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$$.System.UInt32);
                $.$$.System.Diagnostics.Debug.Assert$2(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            static $h = 3080198;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":21477916678,"f":50331688},"n":"Primes","d":3080198,"h":17182949382,"f":2097192}],"m":[{"r":262145,"p":[{"n":"candidate","p":655361}],"n":"IsPrime","d":3080198,"h":25772883974,"f":16777249},{"r":655361,"p":[{"n":"min","p":655361}],"n":"GetPrime","d":3080198,"h":30067851270,"f":16777249},{"r":655361,"p":[{"n":"oldSize","p":655361}],"n":"ExpandPrime","d":3080198,"h":34362818566,"f":16777249},{"r":983041,"p":[{"n":"divisor","p":720897}],"n":"GetFastModMultiplier","d":3080198,"h":38657785862,"f":16777249},{"r":720897,"p":[{"n":"value","p":720897},{"n":"divisor","p":720897},{"n":"multiplier","p":983041}],"n":"FastMod","d":3080198,"h":42952753158,"f":16777249}],"l":[{"t":720897,"n":"HashCollisionThreshold","d":3080198,"h":4298047494,"f":4194337},{"t":655361,"n":"MaxPrimeArrayLength","d":3080198,"h":8593014790,"f":4194337},{"t":655361,"n":"HashPrime","d":3080198,"h":12887982086,"f":4194337}],"h":3080198}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        
        $asm.$cls("$scc.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowKeyNullException()
            {
                return $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("key");
            }
            static /*void */ ThrowArgumentNullException$1(/*string*/ name)
            {
                throw new $.$$.System.ArgumentNullException().$ctor$19(name);
            }
            static /*void */ ThrowArgumentNullException(/*string*/ name, /*string*/ message)
            {
                throw new $.$$.System.ArgumentNullException().$ctor$18(name, message);
            }
            static /*void */ ThrowValueNullException()
            {
                throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfValueIncorrect);
            }
            static /*void */ ThrowOutOfMemoryException()
            {
                throw new $.$$.System.OutOfMemoryException().$ctor$9();
            }
            static /*void */ ThrowIncompatibleComparer()
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.InvalidOperation_IncompatibleComparer);
            }
            static $h = 3211270;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"n":"ThrowKeyNullException","d":3211270,"h":4298178566,"f":16777256},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"ThrowArgumentNullException","o":"@$1","d":3211270,"h":8593145862,"f":16777256},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"message","p":1310721}],"n":"ThrowArgumentNullException","d":3211270,"h":12888113158,"f":16777256},{"r":65537,"n":"ThrowValueNullException","d":3211270,"h":17183080454,"f":16777256},{"r":65537,"n":"ThrowOutOfMemoryException","d":3211270,"h":21478047750,"f":16777256},{"r":65537,"n":"ThrowIncompatibleComparer","d":3211270,"h":25773015046,"f":16777256}],"h":3211270}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$cls("$scc.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$scc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$scc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$scc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections.Concurrent", $.$scc.System.SR.$type.Assembly);
                    $.$scc.System.SR.s_resourceManager = temp;
                }
                return $.$scc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$scc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$scc.System.SR.resourceCulture = value;
            }
            static /*string */ get BlockingCollection_Add_ConcurrentCompleteAdd()
            {
                return "CompleteAdding may not be used concurrently with additions to the collection.";
            }
            static /*string */ get BlockingCollection_Add_Failed()
            {
                return "The underlying collection didn't accept the item.";
            }
            static /*string */ get BlockingCollection_CantAddAnyWhenCompleted()
            {
                return "At least one of the specified collections is marked as complete with regards to additions.";
            }
            static /*string */ get BlockingCollection_CantTakeAnyWhenAllDone()
            {
                return "All collections are marked as complete with regards to additions.";
            }
            static /*string */ get BlockingCollection_CantTakeWhenDone()
            {
                return "The collection argument is empty and has been marked as complete with regards to additions.";
            }
            static /*string */ get BlockingCollection_Completed()
            {
                return "The collection has been marked as complete with regards to additions.";
            }
            static /*string */ get BlockingCollection_CopyTo_IncorrectType()
            {
                return "The array argument is of the incorrect type.";
            }
            static /*string */ get BlockingCollection_CopyTo_MultiDim()
            {
                return "The array argument is multidimensional.";
            }
            static /*string */ get BlockingCollection_CopyTo_NonNegative()
            {
                return "The index argument must be greater than or equal zero.";
            }
            static /*string */ get Collection_CopyTo_TooManyElems()
            {
                return "The number of elements in the collection is greater than the available space from index to the end of the destination array.";
            }
            static /*string */ get BlockingCollection_ctor_CountMoreThanCapacity()
            {
                return "The collection argument contains more items than are allowed by the boundedCapacity.";
            }
            static /*string */ get BlockingCollection_Take_CollectionModified()
            {
                return "The underlying collection was modified from outside of the BlockingCollection<T>.";
            }
            static /*string */ get BlockingCollection_TimeoutInvalid()
            {
                return "The specified timeout must represent a value between -1 and {0}, inclusive.";
            }
            static /*string */ FormatBlockingCollection_TimeoutInvalid(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The specified timeout must represent a value between -1 and {0}, inclusive.", arg1);
            }
            static /*string */ get BlockingCollection_ValidateCollectionsArray_DispElems()
            {
                return "The collections argument contains at least one disposed element.";
            }
            static /*string */ get BlockingCollection_ValidateCollectionsArray_LargeSize()
            {
                return "The collections length is greater than the supported range.";
            }
            static /*string */ get BlockingCollection_ValidateCollectionsArray_NullElems()
            {
                return "The collections argument contains at least one null element.";
            }
            static /*string */ get BlockingCollection_ValidateCollectionsArray_ZeroSize()
            {
                return "The collections argument is a zero-length array.";
            }
            static /*string */ get ConcurrentCollection_SyncRoot_NotSupported()
            {
                return "The SyncRoot property may not be used for the synchronization of concurrent collections.";
            }
            static /*string */ get ConcurrentDictionary_ArrayIncorrectType()
            {
                return "The array is multidimensional, or the type parameter for the set cannot be cast automatically to the type of the destination array.";
            }
            static /*string */ get ConcurrentDictionary_SourceContainsDuplicateKeys()
            {
                return "The source argument contains duplicate keys.";
            }
            static /*string */ get ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne()
            {
                return "The concurrencyLevel argument must be positive, or -1 to indicate a default level.";
            }
            static /*string */ get ConcurrentDictionary_ArrayNotLargeEnough()
            {
                return "The index is equal to or greater than the length of the array, or the number of elements in the dictionary is greater than the available space from index to the end of the destination array.";
            }
            static /*string */ get ConcurrentDictionary_KeyAlreadyExisted()
            {
                return "The key already existed in the dictionary.";
            }
            static /*string */ get ConcurrentDictionary_ItemKeyIsNull()
            {
                return "TKey is a reference type and item.Key is null.";
            }
            static /*string */ get ConcurrentDictionary_TypeOfKeyIncorrect()
            {
                return "The key was of an incorrect type for this dictionary.";
            }
            static /*string */ get ConcurrentDictionary_TypeOfValueIncorrect()
            {
                return "The value was of an incorrect type for this dictionary.";
            }
            static /*string */ get ConcurrentStack_PushPopRange_InvalidCount()
            {
                return "The sum of the startIndex and count arguments must be less than or equal to the collection's Count.";
            }
            static /*string */ get Partitioner_DynamicPartitionsNotSupported()
            {
                return "Dynamic partitions are not supported by this partitioner.";
            }
            static /*string */ get PartitionerStatic_CurrentCalledBeforeMoveNext()
            {
                return "MoveNext must be called at least once before calling Current.";
            }
            static /*string */ get ConcurrentBag_Enumerator_EnumerationNotStartedOrAlreadyFinished()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            static /*string */ get Arg_HTCapacityOverflow()
            {
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            static /*string */ get InvalidOperation_IncompatibleComparer()
            {
                return "The collection's comparer does not support the requested operation.";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$scc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3145734;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3145734}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView<>", [T], ($self) => class IProducerConsumerCollectionDebugView$$ extends $.$$.System.Object
        {
            /*IProducerConsumerCollection<T>*/ _collection = null;
            $ctor$1(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                return this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
            }
            static $h = 1245190;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"collection","p":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.IProducerConsumerCollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.Partitioner", ($self) => class Partitioner
        {
            /*int*/ static CoreOversubscriptionRate = 3;
            static /*OrderablePartitioner<TSource> */ Create$6(TSource, /*IList<TSource>*/ list, /*bool*/ loadBalance)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(list, "list");
                if (loadBalance)
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource))().$ctor$4(list));
                }
                else 
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList$$(TSource))().$ctor$4(list));
                }
            }
            static /*OrderablePartitioner<TSource> */ Create$7(TSource, /*TSource[]*/ array, /*bool*/ loadBalance)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (loadBalance)
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource))().$ctor$4(array));
                }
                else 
                {
                    return (new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray$$(TSource))().$ctor$4(array));
                }
            }
            static /*OrderablePartitioner<TSource> */ Create$5(TSource, /*IEnumerable<TSource>*/ source)
            {
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4(TSource, source, 0/*EnumerablePartitionerOptions.None*/);
            }
            static /*OrderablePartitioner<TSource> */ Create$4(TSource, /*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if ((partitionerOptions & (~1/*EnumerablePartitionerOptions.NoBuffering*/)) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("partitionerOptions");
                }
                return (new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource))().$ctor$3(source, partitionerOptions));
            }
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$3(/*long*/ fromInclusive, /*long*/ toExclusive)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int64, toExclusive, fromInclusive, "toExclusive");
                /*decimal*/ let range = $.$$.System.Decimal.op_Subtraction($.$$.System.Decimal.op_Implicit$4(toExclusive), $.$$.System.Decimal.op_Implicit$4(fromInclusive));
                /*long*/ let rangeSize = $.$$.System.Decimal.op_Explicit$7(($.$$.System.Decimal.op_Division(range, ($.$$.System.Decimal.op_Implicit$3((($.$$.System.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/) | 0))))));
                if (rangeSize === 0n)
                {
                    rangeSize = 1n;
                }
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            static /*OrderablePartitioner<Tuple<long, long>> */ Create$2(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int64, toExclusive, fromInclusive, "toExclusive");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int64, rangeSize, "rangeSize");
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges$1(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            static /*IEnumerable<Tuple<long, long>> */ CreateRanges$1(/*long*/ fromInclusive, /*long*/ toExclusive, /*long*/ rangeSize)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*long*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*long*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = i + rangeSize)
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = i + rangeSize;
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            static /*OrderablePartitioner<Tuple<int, int>> */ Create$1(/*int*/ fromInclusive, /*int*/ toExclusive)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int32, toExclusive, fromInclusive, "toExclusive");
                /*long*/ let range = $.$cast(toExclusive, $.$$.System.Int64) - BigInt(fromInclusive);
                /*int*/ let rangeSize = $.$cast((range / (BigInt($.$$.System.Environment.ProcessorCount * 3/*CoreOversubscriptionRate*/))), $.$$.System.Int32);
                if (rangeSize === 0)
                {
                    rangeSize = 1;
                }
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            static /*OrderablePartitioner<Tuple<int, int>> */ Create(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThanOrEqual($.$$.System.Int32, toExclusive, fromInclusive, "toExclusive");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, rangeSize, "rangeSize");
                return $.$scc.System.Collections.Concurrent.Partitioner.Create$4($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32), $.$scc.System.Collections.Concurrent.Partitioner.CreateRanges(fromInclusive, toExclusive, rangeSize), 1/*EnumerablePartitionerOptions.NoBuffering*/);
            }
            static /*IEnumerable<Tuple<int, int>> */ CreateRanges(/*int*/ fromInclusive, /*int*/ toExclusive, /*int*/ rangeSize)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let $from, to;
                    /*bool*/ let shouldQuit = false;
                    for(/*int*/ let i = fromInclusive; (i < toExclusive) && !shouldQuit; i = ((i + rangeSize) | 0))
                    {
                        $from = i;
                        try
                        {
                            //checked
                            {
                                to = $.$checked(i + rangeSize, 1);
                            }
                        }
                        catch($e)
                        {
                            to = toExclusive;
                            shouldQuit = true;
                        }
                        if (to > toExclusive)
                        {
                            to = toExclusive;
                        }
                        yield new ($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$1($from, to);
                    }
                }.bind(this));
            }
            static $_DynamicPartitionEnumerator_Abstract$$$;
            static DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionEnumerator_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<,>", (TSource, TSourceReader) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<,>", [TSource, TSourceReader], ($self) => class DynamicPartitionEnumerator_Abstract$$$ extends $.$$.System.Object
                {
                    /*TSourceReader*/ _sharedReader = $.$default(TSourceReader);
                    /*int*/ static s_defaultMaxChunkSize = 0;
                    /*StrongBox<int>?*/ _currentChunkSize = null;
                    /*StrongBox<int>?*/ _localOffset = null;
                    /*int*/ static CHUNK_DOUBLING_RATE = 3;
                    /*int*/ _doublingCountdown = 0;
                    /*int*/ _maxChunkSize = 0;
                    /*SharedLong*/ _sharedIndex = null;
                    $ctor$2(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        this.$ctor$1(sharedReader, sharedIndex, false);
                        {
                        }
                        return this;
                    }
                    $ctor$1(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex, /*bool*/ useSingleChunking)
                    {
                        super.$ctor();
                        {
                            this._sharedReader = sharedReader;
                            this._sharedIndex = sharedIndex;
                            this._maxChunkSize = useSingleChunking ? 1 : $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader).s_defaultMaxChunkSize;
                        }
                        return this;
                    }
                    /*void */ Reset()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return (this).Current;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._localOffset === null)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize === null, "_currentChunkSize == null");
                            this._localOffset = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32))().$ctor$2(-1);
                            this._currentChunkSize = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32))().$ctor$2(0);
                            this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize !== null, "_currentChunkSize != null");
                        if (this._localOffset.Value < ((this._currentChunkSize.Value - 1) | 0))
                        {
                            this._localOffset.Value++;
                            return true;
                        }
                        else 
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value === ((this._currentChunkSize.Value - 1) | 0) || this._currentChunkSize.Value === 0, "_localOffset.Value == _currentChunkSize.Value - 1 || _currentChunkSize.Value == 0");
                            /*int*/ let requestedChunkSize;
                            if (this._currentChunkSize.Value === 0)
                            {
                                requestedChunkSize = 1;
                            }
                            else if (this._doublingCountdown > 0)
                            {
                                requestedChunkSize = this._currentChunkSize.Value;
                            }
                            else 
                            {
                                requestedChunkSize = $.$$.System.Math.Min$4(((this._currentChunkSize.Value * 2) | 0), this._maxChunkSize);
                                this._doublingCountdown = 3/*CHUNK_DOUBLING_RATE*/;
                            }
                            this._doublingCountdown--;
                            $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0 && requestedChunkSize <= this._maxChunkSize, "requestedChunkSize > 0 && requestedChunkSize <= _maxChunkSize");
                            if (this.GrabNextChunk(requestedChunkSize))
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(this._currentChunkSize.Value <= requestedChunkSize && this._currentChunkSize.Value > 0, "_currentChunkSize.Value <= requestedChunkSize && _currentChunkSize.Value > 0");
                                this._localOffset.Value = 0;
                                return true;
                            }
                            else 
                            {
                                return false;
                            }
                        }
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_defaultMaxChunkSize = $.$scc.System.Collections.Concurrent.Partitioner.GetDefaultChunkSize(TSource);
                        }
                    }
                    static $h = 1572870;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xD00000000n),"f":50331908},"n":"HasNoElementsLeft","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2097412},{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331905},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097409},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1300000000n),"f":50331650},"n":"{31850497}.Current","o":"System$Collections$IEnumerator$Current","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":2097154}],"m":[{"r":262145,"p":[{"n":"requestedChunkSize","p":655361}],"n":"GrabNextChunk","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777476},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777473},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217},{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217}],"l":[{"t":TSourceReader?.$h??1572864,"n":"_sharedReader","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194308},{"t":655361,"n":"s_defaultMaxChunkSize","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194340},{"t":$.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32).$h,"n":"_currentChunkSize","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194308},{"t":$.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Int32).$h,"n":"_localOffset","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194308},{"t":655361,"n":"CHUNK_DOUBLING_RATE","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194338},{"t":655361,"n":"_doublingCountdown","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":655361,"n":"_maxChunkSize","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194308},{"t":2490374,"n":"_sharedIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194308}],"c":[{"p":[{"n":"sharedReader","p":TSourceReader?.$h??1572864},{"n":"sharedIndex","p":2490374}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777220},{"p":[{"n":"sharedReader","p":TSourceReader?.$h??1572864},{"n":"sharedIndex","p":2490374},{"n":"useSingleChunking","p":262145}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777220}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"g":[TSource?.$h??1507328,TSourceReader?.$h??1572864],"r":2,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumerator_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            static $_DynamicPartitionerForIEnumerable$$;
            static DynamicPartitionerForIEnumerable$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIEnumerable$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<>", [TSource], ($self) => class DynamicPartitionerForIEnumerable$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*bool*/ _useSingleChunking = false;
                    $ctor$3(/*IEnumerable<TSource>*/ source, /*EnumerablePartitionerOptions*/ partitionerOptions)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            this._source = source;
                            this._useSingleChunking = ((partitionerOptions & 1/*EnumerablePartitionerOptions.NoBuffering*/) !== 0);
                        }
                        return this;
                    }
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*var*/ let partitionEnumerable = new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]), this._useSingleChunking, true);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.GetEnumerator(), i);
                        }
                        return partitions;
                    }
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable)().$ctor$1(this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]), this._useSingleChunking, false);
                    }
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        return true;
                    }
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            /*IEnumerator<TSource>*/ _sharedReader = null;
                            /*SharedLong*/ _sharedIndex = null;
                            /*KeyValuePair<long, TSource>[]?*/ _fillBuffer = null;
                            /*int*/ _fillBufferSize = 0;
                            /*int*/ _fillBufferCurrentPosition = 0;
                            /*int*/ _activeCopiers = 0;
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            /*SharedBool*/ _sourceDepleted = null;
                            /*object*/ _sharedLock = null;
                            /*bool*/ _disposed = false;
                            /*SharedInt?*/ _activePartitionCount = null;
                            /*bool*/ _useSingleChunking = false;
                            $ctor$1(/*IEnumerator<TSource>*/ sharedReader, /*bool*/ useSingleChunking, /*bool*/ isStaticPartitioning)
                            {
                                super.$ctor();
                                {
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                    this._hasNoElementsLeft = new $.$scc.System.Collections.Concurrent.Partitioner.SharedBool().$ctor$1(false);
                                    this._sourceDepleted = new $.$scc.System.Collections.Concurrent.Partitioner.SharedBool().$ctor$1(false);
                                    this._sharedLock = new $.$$.System.Object().$ctor();
                                    this._useSingleChunking = useSingleChunking;
                                    if (!this._useSingleChunking)
                                    {
                                        /*int*/ let fillBufferMultiplier = /*(Environment.ProcessorCount > 4) ? 4 : */ 1;
                                        this._fillBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), null, [((fillBufferMultiplier * $.$scc.System.Collections.Concurrent.Partitioner.GetDefaultChunkSize(TSource)) | 0)], null);
                                    }
                                    if (isStaticPartitioning)
                                    {
                                        this._activePartitionCount = new $.$scc.System.Collections.Concurrent.Partitioner.SharedInt().$ctor$1(0);
                                    }
                                    else 
                                    {
                                        this._activePartitionCount = null;
                                    }
                                }
                                return this;
                            }
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                $.$$.System.ObjectDisposedException.ThrowIf(this._disposed, this);
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerator)().$ctor$3(this._sharedReader, this._sharedIndex, this._hasNoElementsLeft, this._activePartitionCount, this, this._useSingleChunking);
                            }
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                return (this).GetEnumerator();
                            }
                            /*void */ TryCopyFromFillBuffer(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                actualNumElementsGrabbed.$v = 0;
                                /*KeyValuePair<long, TSource>[]?*/ let fillBufferLocalRef = this._fillBuffer;
                                if (fillBufferLocalRef === null)
                                {
                                    return;
                                }
                                if (this._fillBufferCurrentPosition >= this._fillBufferSize)
                                {
                                    return;
                                }
                                $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.System.Int32));
                                /*int*/ let endPos = $.$$.System.Threading.Interlocked.Add($.$ref(() => this._fillBufferCurrentPosition, ($v) => this._fillBufferCurrentPosition = $v, $.$$.System.Int32), requestedChunkSize);
                                /*int*/ let beginPos = ((endPos - requestedChunkSize) | 0);
                                if (beginPos < this._fillBufferSize)
                                {
                                    actualNumElementsGrabbed.$v = (endPos < this._fillBufferSize) ? endPos : ((this._fillBufferSize - beginPos) | 0);
                                    $.$$.System.Array.Copy$2(fillBufferLocalRef, beginPos, destArray, 0, actualNumElementsGrabbed.$v);
                                }
                                $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._activeCopiers, ($v) => this._activeCopiers = $v, $.$$.System.Int32));
                            }
                            /*bool */ GrabChunk(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                actualNumElementsGrabbed.$v = 0;
                                if (this._hasNoElementsLeft.Value)
                                {
                                    return false;
                                }
                                if (this._useSingleChunking)
                                {
                                    return this.GrabChunk_Single(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                                else 
                                {
                                    return this.GrabChunk_Buffered(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                }
                            }
                            /*bool */ GrabChunk_Single(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(this._useSingleChunking, "Expected _useSingleChecking to be true");
                                $.$$.System.Diagnostics.Debug.Assert$4(requestedChunkSize === 1, `Got requested chunk size of ${requestedChunkSize} when single-chunking was on`);
                                $.$$.System.Diagnostics.Debug.Assert$4(actualNumElementsGrabbed.$v === 0, `Expected actualNumElementsGrabbed == 0, instead it is ${actualNumElementsGrabbed.$v}`);
                                $.$$.System.Diagnostics.Debug.Assert$4(destArray.length === 1, `Expected destArray to be of length 1, instead its length is ${destArray.length}`);
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._hasNoElementsLeft.Value)
                                        {
                                            return false;
                                        }
                                        try
                                        {
                                            if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                            {
                                                this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), 0);
                                                actualNumElementsGrabbed.$v = 1;
                                                return true;
                                            }
                                            else 
                                            {
                                                this._sourceDepleted.Value = true;
                                                this._hasNoElementsLeft.Value = true;
                                                return false;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this._sharedLock)
                                }
                            }
                            /*bool */ GrabChunk_Buffered(/*KeyValuePair<long, TSource>[]*/ destArray, /*int*/ requestedChunkSize, /*ref int*/ actualNumElementsGrabbed)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                                $.$$.System.Diagnostics.Debug.Assert$2(!this._useSingleChunking, "Did not expect to be in single-chunking mode");
                                this.TryCopyFromFillBuffer(destArray, requestedChunkSize, actualNumElementsGrabbed);
                                if (actualNumElementsGrabbed.$v === requestedChunkSize)
                                {
                                    return true;
                                }
                                else if (this._sourceDepleted.Value)
                                {
                                    this._hasNoElementsLeft.Value = true;
                                    this._fillBuffer = null;
                                    return (actualNumElementsGrabbed.$v > 0);
                                }
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this._sharedLock)
                                    {
                                        if (this._sourceDepleted.Value)
                                        {
                                            return (actualNumElementsGrabbed.$v > 0);
                                        }
                                        try
                                        {
                                            if (this._activeCopiers > 0)
                                            {
                                                /*SpinWait*/ let sw = new $.$$.System.Threading.SpinWait();
                                                while(this._activeCopiers > 0)
                                                {
                                                    sw.SpinOnce();
                                                }
                                            }
                                            $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                                            for(; actualNumElementsGrabbed.$v < requestedChunkSize; actualNumElementsGrabbed.$v++)
                                            {
                                                if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                                {
                                                    this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                    $.$$.System.Array.$WriteT1.call(destArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), actualNumElementsGrabbed.$v);
                                                }
                                                else 
                                                {
                                                    this._sourceDepleted.Value = true;
                                                    break;
                                                }
                                            }
                                            /*var*/ let localFillBufferRef = this._fillBuffer;
                                            if (this._sourceDepleted.Value === false && localFillBufferRef !== null && this._fillBufferCurrentPosition >= localFillBufferRef.length)
                                            {
                                                for(/*int*/ let i = 0; i < localFillBufferRef.length; i++)
                                                {
                                                    if (this._sharedReader.System$Collections$IEnumerator$MoveNext())
                                                    {
                                                        this._sharedIndex.Value = this._sharedIndex.Value + 1n;
                                                        $.$$.System.Array.$WriteT1.call(localFillBufferRef, new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(this._sharedIndex.Value, this._sharedReader.System$Collections$Generic$IEnumerator$$$Current), i);
                                                    }
                                                    else 
                                                    {
                                                        this._sourceDepleted.Value = true;
                                                        this._fillBufferSize = i;
                                                        break;
                                                    }
                                                }
                                                this._fillBufferCurrentPosition = 0;
                                            }
                                        }
                                        catch($e)
                                        {
                                            this._sourceDepleted.Value = true;
                                            this._hasNoElementsLeft.Value = true;
                                            throw $e;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this._sharedLock)
                                }
                                return (actualNumElementsGrabbed.$v > 0);
                            }
                            /*void */ Dispose()
                            {
                                if (!this._disposed)
                                {
                                    this._disposed = true;
                                    this._sharedReader.System$IDisposable$Dispose();
                                }
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                return this.GetEnumerator(...arguments);
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            static $h = 1966086;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217},{"r":65537,"p":[{"n":"destArray","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h},{"n":"requestedChunkSize","p":655361},{"n":"actualNumElementsGrabbed","p":655361,"f":4}],"n":"TryCopyFromFillBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777218},{"r":262145,"p":[{"n":"destArray","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h},{"n":"requestedChunkSize","p":655361},{"n":"actualNumElementsGrabbed","p":655361,"f":4}],"n":"GrabChunk","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777224},{"r":262145,"p":[{"n":"destArray","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h},{"n":"requestedChunkSize","p":655361},{"n":"actualNumElementsGrabbed","p":655361,"f":4}],"n":"GrabChunk_Single","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777224},{"r":262145,"p":[{"n":"destArray","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h},{"n":"requestedChunkSize","p":655361},{"n":"actualNumElementsGrabbed","p":655361,"f":4}],"n":"GrabChunk_Buffered","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777224},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h,"n":"_sharedReader","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2490374,"n":"_sharedIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"_fillBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655361,"n":"_fillBufferSize","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"_fillBufferCurrentPosition","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":655361,"n":"_activeCopiers","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":2359302,"n":"_hasNoElementsLeft","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306},{"t":2359302,"n":"_sourceDepleted","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194306},{"t":131073,"n":"_sharedLock","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4194306},{"t":262145,"n":"_disposed","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":4194306},{"t":2424838,"n":"_activePartitionCount","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":4194306},{"t":262145,"n":"_useSingleChunking","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":4194306}],"c":[{"p":[{"n":"sharedReader","p":$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h},{"n":"useSingleChunking","p":262145},{"n":"isStaticPartitioning","p":262145}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,31719425,57540609],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable, $.$$.System.IDisposable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.System.Collections.Generic.IEnumerator$$(TSource))
                        {
                            /*KeyValuePair<long, TSource>[]?*/ _localList = null;
                            /*SharedBool*/ _hasNoElementsLeft = null;
                            /*SharedInt?*/ _activePartitionCount = null;
                            /*InternalPartitionEnumerable*/ _enumerable = null;
                            $ctor$3(/*IEnumerator<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex, /*SharedBool*/ hasNoElementsLeft, /*SharedInt?*/ activePartitionCount, /*InternalPartitionEnumerable*/ enumerable, /*bool*/ useSingleChunking)
                            {
                                super.$ctor$1(sharedReader, sharedIndex, useSingleChunking);
                                {
                                    this._hasNoElementsLeft = hasNoElementsLeft;
                                    this._enumerable = enumerable;
                                    this._activePartitionCount = activePartitionCount;
                                    if (this._activePartitionCount !== null)
                                    {
                                        $.$$.System.Threading.Interlocked.Increment($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.System.Int32));
                                    }
                                }
                                return this;
                            }
                            /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                                if (this.HasNoElementsLeft)
                                {
                                    return false;
                                }
                                this._localList ??= $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), null, [this._maxChunkSize], null);
                                return this._enumerable.GrabChunk(this._localList, requestedChunkSize, $.$ref(() => this._currentChunkSize.Value, ($v) => this._currentChunkSize.Value = $v, $.$$.System.Int32));
                            }
                            /*bool */ get HasNoElementsLeft()
                            {
                                return this._hasNoElementsLeft.Value;
                            }
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localList !== null, "_localList != null");
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return ($.$$.System.Array.$ReadT1.call(this._localList, this._localOffset.Value));
                            }
                            /*void */ Dispose()
                            {
                                if (this._activePartitionCount !== null && $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._activePartitionCount.Value, ($v) => this._activePartitionCount.Value = $v, $.$$.System.Int32)) === 0)
                                {
                                    this._enumerable.Dispose();
                                }
                            }
                            static $h = 2031622;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1572870,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50364420},"n":"HasNoElementsLeft","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2129924},{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50364417},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2129921}],"m":[{"r":262145,"p":[{"n":"requestedChunkSize","p":655361}],"n":"GrabNextChunk","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16809988},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16809985}],"l":[{"t":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"_localList","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2359302,"n":"_hasNoElementsLeft","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":2424838,"n":"_activePartitionCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable.$h,"n":"_enumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306}],"c":[{"p":[{"n":"sharedReader","p":$.$$.System.Collections.Generic.IEnumerator$$(TSource).$h},{"n":"sharedIndex","p":2490374},{"n":"hasNoElementsLeft","p":2359302},{"n":"activePartitionCount","p":2424838},{"n":"enumerable","p":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable.$h},{"n":"useSingleChunking","p":262145}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, $.$$.System.Collections.Generic.IEnumerator$$(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    static $h = 1900550;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50364417},"n":"SupportsDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2129921}],"m":[{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetOrderablePartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16809985},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetOrderableDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809985}],"l":[{"t":$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h,"n":"_source","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":262145,"n":"_useSingleChunking","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"source","p":$.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"partitionerOptions","p":1114118}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777224}],"g":[TSource?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerable.$h,$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable$$(TSource).InternalPartitionEnumerator.$h],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIEnumerable<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIEnumerable$$ = $v))(TSource);
            }
            static $_DynamicPartitionerForIndexRange_Abstract$$$;
            static DynamicPartitionerForIndexRange_Abstract$$$(TSource, TCollection)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIndexRange_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>", (TSource, TCollection) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<,>", [TSource, TCollection], ($self) => class DynamicPartitionerForIndexRange_Abstract$$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    /*TCollection*/ _data = $.$default(TCollection);
                    $ctor$3(/*TCollection*/ data)
                    {
                        super.$ctor$2(true, false, true);
                        {
                            this._data = data;
                        }
                        return this;
                    }
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*IEnumerable<KeyValuePair<long, TSource>>*/ let partitionEnumerable = this.GetOrderableDynamicPartitions_Factory(this._data);
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(partitions, partitionEnumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)]), i);
                        }
                        return partitions;
                    }
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions()
                    {
                        return this.GetOrderableDynamicPartitions_Factory(this._data);
                    }
                    /*bool */ get SupportsDynamicPartitions()
                    {
                        return true;
                    }
                    static $h = 2293766;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50364417},"n":"SupportsDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2129921}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"data","p":TCollection?.$h??1572864}],"n":"GetOrderableDynamicPartitions_Factory","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777476},{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetOrderablePartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16809985},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetOrderableDynamicPartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809985}],"l":[{"t":TCollection?.$h??1572864,"n":"_data","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"data","p":TCollection?.$h??1572864}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777220}],"g":[TSource?.$h??1507328,TCollection?.$h??1572864],"r":2,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIndexRange_Abstract$$$ = $v))(TSource, TCollection);
            }
            static $_DynamicPartitionEnumeratorForIndexRange_Abstract$$$;
            static DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, TSourceReader)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>", (TSource, TSourceReader) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<,>", [TSource, TSourceReader], ($self) => class DynamicPartitionEnumeratorForIndexRange_Abstract$$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader)
                {
                    /*int*/ _startIndex = 0;
                    $ctor$3(/*TSourceReader*/ sharedReader, /*SharedLong*/ sharedIndex)
                    {
                        super.$ctor$2(sharedReader, sharedIndex);
                        {
                        }
                        return this;
                    }
                    /*bool */ GrabNextChunk(/*int*/ requestedChunkSize)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(requestedChunkSize > 0, "requestedChunkSize > 0");
                        while(!this.HasNoElementsLeft)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                            /*long*/ let oldSharedIndex = $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64).$v;
                            if (this.HasNoElementsLeft)
                            {
                                return false;
                            }
                            /*long*/ let newSharedIndex = $.$$.System.Math.Min$5(BigInt(this.SourceCount - 1), oldSharedIndex + BigInt(requestedChunkSize));
                            if ($.$$.System.Threading.Interlocked.CompareExchange$4($.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64), newSharedIndex, oldSharedIndex) === oldSharedIndex)
                            {
                                this._currentChunkSize.Value = $.$cast((newSharedIndex - oldSharedIndex), $.$$.System.Int32);
                                this._localOffset.Value = -1;
                                this._startIndex = $.$cast((oldSharedIndex + 1n), $.$$.System.Int32);
                                return true;
                            }
                        }
                        return false;
                    }
                    /*bool */ get HasNoElementsLeft()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._sharedIndex !== null, "_sharedIndex != null");
                        return $.$ref(() => this._sharedIndex.Value, ($v) => this._sharedIndex.Value = $v, $.$$.System.Int64).$v >= BigInt(this.SourceCount - 1);
                    }
                    /*void */ Dispose()
                    {
                    }
                    static $h = 1638406;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331908},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097412},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50364420},"n":"HasNoElementsLeft","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2129924}],"m":[{"r":262145,"p":[{"n":"requestedChunkSize","p":655361}],"n":"GrabNextChunk","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809988},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16809985}],"l":[{"t":655361,"n":"_startIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194308}],"c":[{"p":[{"n":"sharedReader","p":TSourceReader?.$h??1572864},{"n":"sharedIndex","p":2490374}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777220}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"g":[TSource?.$h??1507328,TSourceReader?.$h??1572864],"r":2,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumerator_Abstract$$$(TSource, TSourceReader); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract<${TSource?.$fullName},${TSourceReader?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionEnumeratorForIndexRange_Abstract$$$ = $v))(TSource, TSourceReader);
            }
            static $_DynamicPartitionerForIList$$;
            static DynamicPartitionerForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<>", [TSource], ($self) => class DynamicPartitionerForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                {
                    $ctor$4(/*IList<TSource>*/ source)
                    {
                        super.$ctor$3(source);
                        {
                        }
                        return this;
                    }
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*IList<TSource>*/ _data)
                    {
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            /*IList<TSource>*/ _sharedReader = null;
                            /*SharedLong*/ _sharedIndex = null;
                            $ctor$1(/*IList<TSource>*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                return (this).GetEnumerator();
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                return this.GetEnumerator(...arguments);
                            }
                            static $h = 2162694;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IList$$(TSource).$h,"n":"_sharedReader","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2490374,"n":"_sharedIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"sharedReader","p":$.$$.System.Collections.Generic.IList$$(TSource).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,31719425],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                        {
                            $ctor$4(/*IList<TSource>*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                }
                                return this;
                            }
                            /*int */ get SourceCount()
                            {
                                return this._sharedReader.System$Collections$Generic$ICollection$$$Count;
                            }
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), this._sharedReader.System$Collections$Generic$IList$$$get_Item(((this._startIndex + this._localOffset.Value) | 0), [TSource]));
                            }
                            static $h = 2228230;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1638406,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50364420},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2129924},{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50364417},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2129921}],"c":[{"p":[{"n":"sharedReader","p":$.$$.System.Collections.Generic.IList$$(TSource).$h},{"n":"sharedIndex","p":2490374}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    static $h = 2097158;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2293766,"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"_data","p":$.$$.System.Collections.Generic.IList$$(TSource).$h}],"n":"GetOrderableDynamicPartitions_Factory","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16809988}],"c":[{"p":[{"n":"source","p":$.$$.System.Collections.Generic.IList$$(TSource).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[TSource?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerable.$h,$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList$$(TSource).InternalPartitionEnumerator.$h],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForIList$$ = $v))(TSource);
            }
            static $_DynamicPartitionerForArray$$;
            static DynamicPartitionerForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_DynamicPartitionerForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<>", [TSource], ($self) => class DynamicPartitionerForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                {
                    $ctor$4(/*TSource[]*/ source)
                    {
                        super.$ctor$3(source);
                        {
                        }
                        return this;
                    }
                    /*IEnumerable<KeyValuePair<long, TSource>> */ GetOrderableDynamicPartitions_Factory(/*TSource[]*/ _data)
                    {
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerable)().$ctor$1(_data);
                    }
                    static $_InternalPartitionEnumerable;
                    static get InternalPartitionEnumerable()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerable ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$.InternalPartitionEnumerable", ($self) => class InternalPartitionEnumerable extends $.$$.System.Object
                        {
                            /*TSource[]*/ _sharedReader = null;
                            /*SharedLong*/ _sharedIndex = null;
                            $ctor$1(/*TSource[]*/ sharedReader)
                            {
                                super.$ctor();
                                {
                                    this._sharedReader = sharedReader;
                                    this._sharedIndex = new $.$scc.System.Collections.Concurrent.Partitioner.SharedLong().$ctor$1(BigInt(-1));
                                }
                                return this;
                            }
                            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                            {
                                return (this).GetEnumerator();
                            }
                            /*IEnumerator<KeyValuePair<long, TSource>> */ GetEnumerator()
                            {
                                return new ($.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerator)().$ctor$4(this._sharedReader, this._sharedIndex);
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<long, TSource>>.GetEnumerator()
                            System$Collections$Generic$IEnumerable$$$GetEnumerator()
                            {
                                return this.GetEnumerator(...arguments);
                            }
                            static $h = 1769478;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$typeArray(TSource).$h,"n":"_sharedReader","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":2490374,"n":"_sharedIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"sharedReader","p":$.$typeArray(TSource).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,31719425],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.Collections.IEnumerable ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerable`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerable = $v);
                    }
                    static $_InternalPartitionEnumerator;
                    static get InternalPartitionEnumerator()
                    {
                        let $cls = $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource);
                        return $cls.$_InternalPartitionEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$.InternalPartitionEnumerator", ($self) => class InternalPartitionEnumerator extends $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource))
                        {
                            $ctor$4(/*TSource[]*/ sharedReader, /*SharedLong*/ sharedIndex)
                            {
                                super.$ctor$3(sharedReader, sharedIndex);
                                {
                                }
                                return this;
                            }
                            /*int */ get SourceCount()
                            {
                                return this._sharedReader.length;
                            }
                            /*KeyValuePair<long, TSource> */ get Current()
                            {
                                if (this._currentChunkSize === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                                }
                                $.$$.System.Diagnostics.Debug.Assert$2(this._localOffset.Value >= 0 && this._localOffset.Value < this._currentChunkSize.Value, "_localOffset!.Value >= 0 && _localOffset.Value < _currentChunkSize.Value");
                                return new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._startIndex + this._localOffset.Value), $.$$.System.Array.$ReadT1.call(this._sharedReader, ((this._startIndex + this._localOffset.Value) | 0)));
                            }
                            static $h = 1835014;
                            static $f = 0b10000000011010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":1638406,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50364420},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2129924},{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50364417},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2129921}],"c":[{"p":[{"n":"sharedReader","p":$.$typeArray(TSource).$h},{"n":"sharedIndex","p":2490374}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"d":$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).$h,"h":this.$h}; }
                            static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionEnumeratorForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>.InternalPartitionEnumerator`; }
                        }, $cls, ($v) => $cls.$_InternalPartitionEnumerator = $v);
                    }
                    static $h = 1703942;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2293766,"m":[{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"_data","p":$.$typeArray(TSource).$h}],"n":"GetOrderableDynamicPartitions_Factory","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16809988}],"c":[{"p":[{"n":"source","p":$.$typeArray(TSource).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224}],"g":[TSource?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerable.$h,$.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray$$(TSource).InternalPartitionEnumerator.$h],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.DynamicPartitionerForIndexRange_Abstract$$$(TSource, $.$typeArray(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.DynamicPartitionerForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DynamicPartitionerForArray$$ = $v))(TSource);
            }
            static $_StaticIndexRangePartitioner$$$;
            static StaticIndexRangePartitioner$$$(TSource, TCollection)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitioner$$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<,>", (TSource, TCollection) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<,>", [TSource, TCollection], ($self) => class StaticIndexRangePartitioner$$$ extends $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource)
                {
                    $ctor$3()
                    {
                        super.$ctor$2(true, true, true);
                        {
                        }
                        return this;
                    }
                    /*IList<IEnumerator<KeyValuePair<long, TSource>>> */ GetOrderablePartitions(/*int*/ partitionCount)
                    {
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, partitionCount, "partitionCount");
                        const { Item1: quotient, Item2: remainder } = $.$$.System.Math.DivRem$3(this.SourceCount, partitionCount);
                        /*IEnumerator<KeyValuePair<long, TSource>>[]*/ let partitions = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))), null, [partitionCount], null);
                        /*int*/ let lastEndIndex = -1;
                        for(/*int*/ let i = 0; i < partitionCount; i++)
                        {
                            /*int*/ let startIndex = ((lastEndIndex + 1) | 0);
                            if (i < remainder)
                            {
                                lastEndIndex = ((startIndex + quotient) | 0);
                            }
                            else 
                            {
                                lastEndIndex = ((((startIndex + quotient) | 0) - 1) | 0);
                            }
                            $.$$.System.Array.$WriteT1.call(partitions, this.CreatePartition(startIndex, lastEndIndex), i);
                        }
                        return partitions;
                    }
                    static $h = 2621446;
                    static $g = 2;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331908},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097412}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":"CreatePartition","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777476},{"r":$.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))).$h,"p":[{"n":"partitionCount","p":655361}],"n":"GetOrderablePartitions","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809985}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777220}],"g":[TSource?.$h??1507328,TCollection?.$h??1572864],"r":2,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner<${TSource?.$fullName},${TCollection?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitioner$$$ = $v))(TSource, TCollection);
            }
            static $_StaticIndexRangePartition$$;
            static StaticIndexRangePartition$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartition$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<>", [TSource], ($self) => class StaticIndexRangePartition$$ extends $.$$.System.Object
                {
                    /*int*/ _startIndex = 0;
                    /*int*/ _endIndex = 0;
                    /*int*/ _offset = 0;
                    $ctor$1(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor();
                        {
                            this._startIndex = startIndex;
                            this._endIndex = endIndex;
                            this._offset = ((startIndex - 1) | 0);
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                    }
                    /*void */ Reset()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._offset < this._endIndex)
                        {
                            this._offset++;
                            return true;
                        }
                        else 
                        {
                            this._offset = ((this._endIndex + 1) | 0);
                            return false;
                        }
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return (this).Current;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<long, TSource>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 2555910;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331905},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097409},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331650},"n":"{31850497}.Current","o":"System$Collections$IEnumerator$Current","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097154}],"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217}],"l":[{"t":655361,"n":"_startIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194308},{"t":655361,"n":"_endIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194308},{"t":655361,"n":"_offset","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194308}],"c":[{"p":[{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777220}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"g":[TSource?.$h??1507328],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartition<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartition$$ = $v))(TSource);
            }
            static $_StaticIndexRangePartitionerForIList$$;
            static StaticIndexRangePartitionerForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<>", [TSource], ($self) => class StaticIndexRangePartitionerForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource))
                {
                    /*IList<TSource>*/ _list = null;
                    $ctor$4(/*IList<TSource>*/ list)
                    {
                        super.$ctor$3();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                            this._list = list;
                        }
                        return this;
                    }
                    /*int */ get SourceCount()
                    {
                        return this._list.System$Collections$Generic$ICollection$$$Count;
                    }
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList$$(TSource))().$ctor$2(this._list, startIndex, endIndex);
                    }
                    static $h = 2752518;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2621446,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50364420},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2129924}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":"CreatePartition","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809988}],"l":[{"t":$.$$.System.Collections.Generic.IList$$(TSource).$h,"n":"_list","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"list","p":$.$$.System.Collections.Generic.IList$$(TSource).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777224}],"g":[TSource?.$h??1507328],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$$.System.Collections.Generic.IList$$(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForIList$$ = $v))(TSource);
            }
            static $_StaticIndexRangePartitionForIList$$;
            static StaticIndexRangePartitionForIList$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForIList$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<>", [TSource], ($self) => class StaticIndexRangePartitionForIList$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    /*IList<TSource>*/ _list = null;
                    $ctor$2(/*IList<TSource>*/ list, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(startIndex >= 0 && endIndex <= ((list.System$Collections$Generic$ICollection$$$Count - 1) | 0), "startIndex >= 0 && endIndex <= list.Count - 1");
                            this._list = list;
                        }
                        return this;
                    }
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._offset), this._list.System$Collections$Generic$IList$$$get_Item(this._offset, [TSource])));
                    }
                    static $h = 2883590;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50364417},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2129921}],"l":[{"t":$.$$.System.Collections.Generic.IList$$(TSource).$h,"n":"_list","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"list","p":$.$$.System.Collections.Generic.IList$$(TSource).$h},{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"g":[TSource?.$h??1507328],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForIList<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForIList$$ = $v))(TSource);
            }
            static $_StaticIndexRangePartitionerForArray$$;
            static StaticIndexRangePartitionerForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionerForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<>", [TSource], ($self) => class StaticIndexRangePartitionerForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource))
                {
                    /*TSource[]*/ _array = null;
                    $ctor$4(/*TSource[]*/ array)
                    {
                        super.$ctor$3();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(array !== null, "array != null");
                            this._array = array;
                        }
                        return this;
                    }
                    /*int */ get SourceCount()
                    {
                        return this._array.length;
                    }
                    /*IEnumerator<KeyValuePair<long, TSource>> */ CreatePartition(/*int*/ startIndex, /*int*/ endIndex)
                    {
                        return new ($.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray$$(TSource))().$ctor$2(this._array, startIndex, endIndex);
                    }
                    static $h = 2686982;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2621446,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50364420},"n":"SourceCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2129924}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,"p":[{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":"CreatePartition","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16809988}],"l":[{"t":$.$typeArray(TSource).$h,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"array","p":$.$typeArray(TSource).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777224}],"g":[TSource?.$h??1507328],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitioner$$$(TSource, $.$typeArray(TSource)); }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionerForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionerForArray$$ = $v))(TSource);
            }
            static $_StaticIndexRangePartitionForArray$$;
            static StaticIndexRangePartitionForArray$$(TSource)
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return ($cls.$_StaticIndexRangePartitionForArray$$ ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<>", (TSource) => $asm.$gt("$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<>", [TSource], ($self) => class StaticIndexRangePartitionForArray$$ extends $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource)
                {
                    /*TSource[]*/ _array = null;
                    $ctor$2(/*TSource[]*/ array, /*int*/ startIndex, /*int*/ endIndex)
                    {
                        super.$ctor$1(startIndex, endIndex);
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(startIndex >= 0 && endIndex <= ((array.length - 1) | 0), "startIndex >= 0 && endIndex <= array.Length - 1");
                            this._array = array;
                        }
                        return this;
                    }
                    /*KeyValuePair<long, TSource> */ get Current()
                    {
                        if (this._offset < this._startIndex)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.PartitionerStatic_CurrentCalledBeforeMoveNext);
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this._offset >= this._startIndex && this._offset <= this._endIndex, "_offset >= _startIndex && _offset <= _endIndex");
                        return (new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource))().$ctor$3(BigInt(this._offset), $.$$.System.Array.$ReadT1.call(this._array, this._offset)));
                    }
                    static $h = 2818054;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"p":[{"p":$.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50364417},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2129921}],"l":[{"t":$.$typeArray(TSource).$h,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"array","p":$.$typeArray(TSource).$h},{"n":"startIndex","p":655361},{"n":"endIndex","p":655361}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)).$h,57540609,31850497],"g":[TSource?.$h??1507328],"r":1,"d":1507334,"h":this.$h}; }
                    static get $b() { return $.$scc.System.Collections.Concurrent.Partitioner.StaticIndexRangePartition$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.Int64, TSource)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.StaticIndexRangePartitionForArray<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_StaticIndexRangePartitionForArray$$ = $v))(TSource);
            }
            static $_SharedInt;
            static get SharedInt()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedInt ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedInt", ($self) => class SharedInt extends $.$$.System.Object
                {
                    /*int*/ Value = 0;
                    $ctor$1(/*int*/ value)
                    {
                        super.$ctor();
                        {
                            this.Value = value;
                        }
                        return this;
                    }
                    static $h = 2424838;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"Value","d":2424838,"h":4297392134,"f":4194312}],"c":[{"p":[{"n":"value","p":655361}],"n":".ctor","o":"$ctor$1","d":2424838,"h":8592359430,"f":16777224}],"d":1507334,"h":2424838}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedInt`; }
                }, $cls, ($v) => $cls.$_SharedInt = $v);
            }
            static $_SharedBool;
            static get SharedBool()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedBool ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedBool", ($self) => class SharedBool extends $.$$.System.Object
                {
                    /*bool*/ Value = false;
                    $ctor$1(/*bool*/ value)
                    {
                        super.$ctor();
                        {
                            this.Value = value;
                        }
                        return this;
                    }
                    static $h = 2359302;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":262145,"n":"Value","d":2359302,"h":4297326598,"f":4194312}],"c":[{"p":[{"n":"value","p":262145}],"n":".ctor","o":"$ctor$1","d":2359302,"h":8592293894,"f":16777224}],"d":1507334,"h":2359302}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedBool`; }
                }, $cls, ($v) => $cls.$_SharedBool = $v);
            }
            static $_SharedLong;
            static get SharedLong()
            {
                let $cls = $.$scc.System.Collections.Concurrent.Partitioner;
                return $cls.$_SharedLong ??= $asm.$ncls("$scc.System.Collections.Concurrent.Partitioner.SharedLong", ($self) => class SharedLong extends $.$$.System.Object
                {
                    /*long*/ Value = 0n;
                    $ctor$1(/*long*/ value)
                    {
                        super.$ctor();
                        {
                            this.Value = value;
                        }
                        return this;
                    }
                    static $h = 2490374;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":917505,"n":"Value","d":2490374,"h":4297457670,"f":4194312}],"c":[{"p":[{"n":"value","p":917505}],"n":".ctor","o":"$ctor$1","d":2490374,"h":8592424966,"f":16777224}],"d":1507334,"h":2490374}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.Partitioner.SharedLong`; }
                }, $cls, ($v) => $cls.$_SharedLong = $v);
            }
            /*int*/ static DEFAULT_BYTES_PER_UNIT = 128;
            /*int*/ static DEFAULT_BYTES_PER_CHUNK = 512;
            static /*int */ GetDefaultChunkSize(TSource)
            {
                /*int*/ let chunkSize;
                if (TSource.$type.IsValueType)
                {
                    {
                        chunkSize = 128/*DEFAULT_BYTES_PER_UNIT*/;
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((512/*DEFAULT_BYTES_PER_CHUNK*/ % $.$$.System.IntPtr.Size) === 0, "bytes per chunk should be a multiple of pointer size");
                    chunkSize = ($.trunc(512/*DEFAULT_BYTES_PER_CHUNK*/ / $.$$.System.IntPtr.Size));
                }
                return chunkSize;
            }
            static $h = 1507334;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"p":[{"n":"list","p":(TSource) => $.$$.System.Collections.Generic.IList$$(TSource).$h},{"n":"loadBalance","p":262145}],"g":["TSource"],"n":"Create","o":"@$6","d":1507334,"h":8591441926,"f":16908321},{"r":(TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"p":[{"n":"array","p":(TSource) => $.$typeArray(TSource).$h},{"n":"loadBalance","p":262145}],"g":["TSource"],"n":"Create","o":"@$7","d":1507334,"h":12886409222,"f":16908321},{"r":(TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Create","o":"@$5","d":1507334,"h":17181376518,"f":16908321},{"r":(TSource) => $.$scc.System.Collections.Concurrent.OrderablePartitioner$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"partitionerOptions","p":1114118}],"g":["TSource"],"n":"Create","o":"@$4","d":1507334,"h":21476343814,"f":16908321},{"r":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,"p":[{"n":"fromInclusive","p":917505},{"n":"toExclusive","p":917505}],"n":"Create","o":"@$3","d":1507334,"h":25771311110,"f":16777249},{"r":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,"p":[{"n":"fromInclusive","p":917505},{"n":"toExclusive","p":917505},{"n":"rangeSize","p":917505}],"n":"Create","o":"@$2","d":1507334,"h":30066278406,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Tuple$$$($.$$.System.Int64, $.$$.System.Int64)).$h,"p":[{"n":"fromInclusive","p":917505},{"n":"toExclusive","p":917505},{"n":"rangeSize","p":917505}],"n":"CreateRanges","o":"@$1","d":1507334,"h":34361245702,"f":16777250},{"r":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,"p":[{"n":"fromInclusive","p":655361},{"n":"toExclusive","p":655361}],"n":"Create","o":"@$1","d":1507334,"h":38656212998,"f":16777249},{"r":$.$scc.System.Collections.Concurrent.OrderablePartitioner$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,"p":[{"n":"fromInclusive","p":655361},{"n":"toExclusive","p":655361},{"n":"rangeSize","p":655361}],"n":"Create","d":1507334,"h":42951180294,"f":16777249},{"r":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Tuple$$$($.$$.System.Int32, $.$$.System.Int32)).$h,"p":[{"n":"fromInclusive","p":655361},{"n":"toExclusive","p":655361},{"n":"rangeSize","p":655361}],"n":"CreateRanges","d":1507334,"h":47246147590,"f":16777250},{"r":655361,"g":["TSource"],"n":"GetDefaultChunkSize","d":1507334,"h":124555558918,"f":16908322}],"l":[{"t":655361,"n":"CoreOversubscriptionRate","d":1507334,"h":4296474630,"f":4194338},{"t":655361,"n":"DEFAULT_BYTES_PER_UNIT","d":1507334,"h":115965624326,"f":4194338},{"t":655361,"n":"DEFAULT_BYTES_PER_CHUNK","d":1507334,"h":120260591622,"f":4194338}],"j":[1572870,1900550,2293766,1638406,2097158,1703942,2621446,2555910,2752518,2883590,2686982,2818054,2424838,2359302,2490374],"h":1507334}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.Partitioner`; }
        });
        
        $asm.$cls("$scc.System.Collections.Concurrent.BlockingCollectionDebugView<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.BlockingCollectionDebugView<>", [T], ($self) => class BlockingCollectionDebugView$$ extends $.$$.System.Object
        {
            /*BlockingCollection<T>*/ _blockingCollection = null;
            $ctor$1(/*BlockingCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._blockingCollection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                return this._blockingCollection.ToArray();
            }
            static $h = 131078;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$scc.System.Collections.Concurrent.BlockingCollection$$(T).$h,"n":"_blockingCollection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"collection","p":$.$scc.System.Collections.Concurrent.BlockingCollection$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.BlockingCollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps<>", [T], ($self) => class ConcurrentDictionaryTypeProps$$
        {
            /*bool*/ static IsWriteAtomic = false;
            static /*bool */ IsWriteAtomicPrivate()
            {
                if (!T.$type.IsValueType || $.$$.System.Type.op_Equality$1(T.$type, $.$$.System.IntPtr.$type) || $.$$.System.Type.op_Equality$1(T.$type, $.$$.System.UIntPtr.$type))
                {
                    return true;
                }
                let $switch1 = $.$$.System.Type.GetTypeCode(T.$type);
                switch($switch1)
                {
                    case 3/*TypeCode.Boolean*/:
                    case 6/*TypeCode.Byte*/:
                    case 4/*TypeCode.Char*/:
                    case 7/*TypeCode.Int16*/:
                    case 9/*TypeCode.Int32*/:
                    case 5/*TypeCode.SByte*/:
                    case 13/*TypeCode.Single*/:
                    case 8/*TypeCode.UInt16*/:
                    case 10/*TypeCode.UInt32*/:
                    return true;
                    case 14/*TypeCode.Double*/:
                    case 11/*TypeCode.Int64*/:
                    case 12/*TypeCode.UInt64*/:
                    return $.$$.System.IntPtr.Size === 8;
                    default:
                    return false;
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IsWriteAtomic = $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(T).IsWriteAtomicPrivate();
                }
            }
            static $h = 917510;
            static $g = 1;
            static $f = 0b1010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"n":"IsWriteAtomicPrivate","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777250}],"l":[{"t":262145,"n":"IsWriteAtomic","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194344}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionaryTypeProps<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.IDictionaryDebugView<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Concurrent.IDictionaryDebugView<,>", [TKey, TValue], ($self) => class IDictionaryDebugView$$$ extends $.$$.System.Object
        {
            /*IDictionary<TKey, TValue>*/ _dictionary = null;
            $ctor$1(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                super.$ctor();
                {
                    if (dictionary === null)
                    {
                        $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("dictionary");
                    }
                    this._dictionary = dictionary;
                }
                return this;
            }
            /*DebugViewDictionaryItem<TKey, TValue>[] */ get Items()
            {
                /*var*/ let keyValuePairs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [this._dictionary.System$Collections$Generic$ICollection$$$Count], null);
                this._dictionary.System$Collections$Generic$ICollection$$$CopyTo(keyValuePairs, 0, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                /*var*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)), null, [keyValuePairs.length], null);
                for(/*int*/ let i = 0; i < items.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(items, new ($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(keyValuePairs, i)), i);
                }
                return items;
            }
            static $h = 1179654;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$scc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h,"n":"_dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"dictionary","p":$.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"g":[TKey?.$h??1507328,TValue?.$h??1572864],"s":[{"n":"TKey","f":64},null],"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Concurrent.IDictionaryDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentStack<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentStack<>", [T], ($self) => class ConcurrentStack$$ extends $.$$.System.Object
        {
            static $_Node;
            static get Node()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T);
                return $cls.$_Node ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentStack$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    /*T*/ _value = $.$default(T);
                    /*Node?*/ _next = null;
                    $ctor$1(/*T*/ value)
                    {
                        super.$ctor();
                        {
                            this._value = value;
                            this._next = null;
                        }
                        return this;
                    }
                    static $h = 1048582;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":T?.$h??1507328,"n":"_value","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194312},{"t":this.$h,"n":"_next","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194312}],"c":[{"p":[{"n":"value","p":T?.$h??1507328}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777224}],"d":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            /*Node?*/ _head = null;
            /*int*/ static BACKOFF_MAX_YIELDS = 8;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            /*void */ InitializeFromCollection(/*IEnumerable<T>*/ collection)
            {
                /*Node?*/ let lastNode = null;
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*Node*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1(element);
                        newNode._next = lastNode;
                        lastNode = newNode;
                    }
                }
                this._head = lastNode;
            }
            /*bool */ get IsEmpty()
            {
                return this._head === null;
            }
            /*int */ get Count()
            {
                /*int*/ let count = 0;
                for(/*Node?*/ let curr = this._head; curr !== null; curr = curr._next)
                {
                    count++;
                }
                return count;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            /*void */ Clear()
            {
                this._head = null;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                (this.ToList()).System$Collections$ICollection$CopyTo(array, index);
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToList().CopyTo(array, index);
            }
            /*void */ Push(/*T*/ item)
            {
                /*Node*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1(item);
                newNode._next = this._head;
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), newNode, newNode._next) === newNode._next)
                {
                    return;
                }
                this.PushCore(newNode, newNode);
            }
            /*void */ PushRange$1(/*T[]*/ items)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                this.PushRange(items, 0, items.length);
            }
            /*void */ PushRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return;
                }
                /*Node*/ let head, tail;
                head = tail = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, startIndex));
                for(/*int*/ let i = ((startIndex + 1) | 0); i < ((startIndex + count) | 0); i++)
                {
                    /*Node*/ let node = new ($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(items, i));
                    node._next = head;
                    head = node;
                }
                tail._next = this._head;
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head, tail._next) === tail._next)
                {
                    return;
                }
                this.PushCore(head, tail);
            }
            /*void */ PushCore(/*Node*/ head, /*Node*/ tail)
            {
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                do
                {
                    spin.SpinOnce$1(-1);
                    tail._next = this._head;
                }
                while($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head, tail._next) !== tail._next);
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPushFailed(spin.Count);
                }
            }
            static /*void */ ValidatePushPopRangeInput(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                /*int*/ let length = items.length;
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, startIndex, length, "startIndex");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, startIndex, "startIndex");
                if (((length - count) | 0) < startIndex)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentStack_PushPopRange_InvalidCount);
                }
            }
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                this.Push(item);
                return true;
            }
            /*bool */ TryPeek(/*out T*/ result)
            {
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                else 
                {
                    result.$v = head._value;
                    return true;
                }
            }
            /*bool */ TryPop(/*out T*/ result)
            {
                /*Node?*/ let head = this._head;
                if (head === null)
                {
                    result.$v = $.$default(T);
                    return false;
                }
                if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), head._next, head) === head)
                {
                    result.$v = head._value;
                    return true;
                }
                return this.TryPopCore$1(result);
            }
            /*int */ TryPopRange$1(/*T[]*/ items)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                return this.TryPopRange(items, 0, items.length);
            }
            /*int */ TryPopRange(/*T[]*/ items, /*int*/ startIndex, /*int*/ count)
            {
                $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ValidatePushPopRangeInput(items, startIndex, count);
                if (count === 0)
                {
                    return 0;
                }
                /*Node?*/ let poppedHead;
                /*int*/ let nodesCount = this.TryPopCore(count, $.$ref(() => poppedHead, ($v) => poppedHead = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node));
                if (nodesCount > 0)
                {
                    $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).CopyRemovedItems(poppedHead, items, startIndex, nodesCount);
                }
                return nodesCount;
            }
            /*bool */ TryPopCore$1(/*out T*/ result)
            {
                /*Node?*/ let poppedNode;
                if (this.TryPopCore(1, $.$ref(() => poppedNode, ($v) => poppedNode = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node)) === 1)
                {
                    result.$v = poppedNode._value;
                    return true;
                }
                result.$v = $.$default(T);
                return false;
            }
            /*int */ TryPopCore(/*int*/ count, /*out Node?*/ poppedHead)
            {
                /*SpinWait*/ let spin = new $.$$.System.Threading.SpinWait();
                /*Node?*/ let head;
                /*Node*/ let next;
                /*int*/ let backoff = 1;
                while(true)
                {
                    head = this._head;
                    if (head === null)
                    {
                        if (count === 1 && $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = null;
                        return 0;
                    }
                    next = head;
                    /*int*/ let nodesCount = 1;
                    for(; nodesCount < count && next._next !== null; nodesCount++)
                    {
                        next = next._next;
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node, $.$ref(() => this._head, ($v) => this._head = $v, $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node), next._next, head) === head)
                    {
                        if (count === 1 && $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                        {
                            $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentStack_FastPopFailed(spin.Count);
                        }
                        poppedHead.$v = head;
                        return nodesCount;
                    }
                    for(/*int*/ let i = 0; i < backoff; i++)
                    {
                        spin.SpinOnce$1(-1);
                    }
                    if (spin.NextSpinWillYield)
                    {
                        backoff = $.$$.System.Random.Shared.Next$1(1, 8/*BACKOFF_MAX_YIELDS*/);
                    }
                    else 
                    {
                        backoff *= 2;
                    }
                }
            }
            static /*void */ CopyRemovedItems(/*Node*/ head, /*T[]*/ collection, /*int*/ startIndex, /*int*/ nodesCount)
            {
                /*Node?*/ let current = head;
                for(/*int*/ let i = startIndex; i < ((startIndex + nodesCount) | 0); i++)
                {
                    $.$$.System.Array.$WriteT1.call(collection, current._value, i);
                    current = current._next;
                }
            }
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake(/*out T*/ item)
            {
                return this.TryPop(item);
            }
            /*T[] */ ToArray()
            {
                /*Node?*/ let curr = this._head;
                return curr === null ? $.$$.System.Array.Empty(T) : $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ToList$1(curr).ToArray();
            }
            /*List<T> */ ToList()
            {
                return $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).ToList$1(this._head);
            }
            static /*List<T> */ ToList$1(/*Node?*/ curr)
            {
                /*List<T>*/ let list = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                while(curr !== null)
                {
                    list.Add(curr._value);
                    curr = curr._next;
                }
                return list;
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                return $.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).GetEnumerator$1(this._head);
            }
            static /*IEnumerator<T> */ GetEnumerator$1(/*Node?*/ head)
            {
                return new ($.$$.NetJs.YieldToIterator$$(T))().$ctor$1(function*()
                {
                    /*Node?*/ let current = head;
                    while(current !== null)
                    {
                        yield current._value;
                        current = current._next;
                    }
                }.bind(this)).GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            System$Collections$Concurrent$IProducerConsumerCollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray()
            {
                return this.ToArray(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 983046;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097154}],"m":[{"r":65537,"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"n":"InitializeFromCollection","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777218},{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"index","p":655361}],"n":"CopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Push","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":65537,"p":[{"n":"items","p":$.$typeArray(T).$h}],"n":"PushRange","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":65537,"p":[{"n":"items","p":$.$typeArray(T).$h},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"PushRange","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217},{"r":65537,"p":[{"n":"head","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h},{"n":"tail","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h}],"n":"PushCore","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777218},{"r":65537,"p":[{"n":"items","p":$.$typeArray(T).$h},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"ValidatePushPopRangeInput","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777250},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryPop","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777217},{"r":655361,"p":[{"n":"items","p":$.$typeArray(T).$h}],"n":"TryPopRange","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777217},{"r":655361,"p":[{"n":"items","p":$.$typeArray(T).$h},{"n":"startIndex","p":655361},{"n":"count","p":655361}],"n":"TryPopRange","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777217},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryPopCore","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777218},{"r":655361,"p":[{"n":"count","p":655361},{"n":"poppedHead","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h,"f":2}],"n":"TryPopCore","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777218},{"r":65537,"p":[{"n":"head","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h},{"n":"collection","p":$.$typeArray(T).$h},{"n":"startIndex","p":655361},{"n":"nodesCount","p":655361}],"n":"CopyRemovedItems","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":16777250},{"r":$.$typeArray(T).$h,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.List$$(T).$h,"n":"ToList","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":16777218},{"r":$.$$.System.Collections.Generic.List$$(T).$h,"p":[{"n":"curr","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h}],"n":"ToList","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2200000000n),"f":16777250},{"r":$.$$.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$(T).$h,"p":[{"n":"head","p":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h}],"n":"GetEnumerator","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2400000000n),"f":16777250}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h,"n":"_head","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":655361,"n":"BACKOFF_MAX_YIELDS","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"i":[$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,31457281,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425],"g":[T?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.ConcurrentStack$$(T).Node.$h],"r":1,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView$$().$h,"t":142475265}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentStack<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentBag<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentBag<>", [T], ($self) => class ConcurrentBag$$ extends $.$$.System.Object
        {
            /*ThreadLocal<WorkStealingQueue>*/ _locals = null;
            /*WorkStealingQueue?*/ _workStealingQueues = null;
            /*long*/ _emptyToNonEmptyListTransitionCount = 0n;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._locals = new ($.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                }
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._locals = new ($.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue))().$ctor$1();
                    /*WorkStealingQueue*/ let queue = this.GetCurrentThreadWorkStealingQueue(true);
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            queue.LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
                        }
                    }
                }
                return this;
            }
            /*void */ Add(/*T*/ item)
            {
                return this.GetCurrentThreadWorkStealingQueue(true).LocalPush(item, $.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
            }
            /*bool */ System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(/*T*/ item)
            {
                this.Add(item);
                return true;
            }
            /*bool */ TryTake(/*out T*/ result)
            {
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPop(result)) || this.TrySteal(result, true);
            }
            /*bool */ TryPeek(/*out T*/ result)
            {
                /*WorkStealingQueue?*/ let queue = this.GetCurrentThreadWorkStealingQueue(false);
                return (queue !== null && queue.TryLocalPeek(result)) || this.TrySteal(result, false);
            }
            /*WorkStealingQueue? */ GetCurrentThreadWorkStealingQueue(/*bool*/ forceCreate)
            {
                return this._locals.Value ?? (forceCreate ? this.CreateWorkStealingQueueForCurrentThread() : null);
            }
            /*WorkStealingQueue */ CreateWorkStealingQueueForCurrentThread()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.GlobalQueuesLock)
                    {
                        /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                        /*WorkStealingQueue?*/ let queue = head !== null ? this.GetUnownedWorkStealingQueue() : null;
                        if (queue === null)
                        {
                            this._workStealingQueues = queue = new ($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue)().$ctor$1(head);
                        }
                        this._locals.Value = queue;
                        return queue;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.GlobalQueuesLock)
                }
            }
            /*WorkStealingQueue? */ GetUnownedWorkStealingQueue()
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let currentThreadId = $.$$.System.Environment.CurrentManagedThreadId;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._ownerThreadId === currentThreadId)
                    {
                        return queue;
                    }
                }
                return null;
            }
            /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
            {
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    if (take)
                    {
                        $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryTakeSteals();
                    }
                    else 
                    {
                        $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentBag_TryPeekSteals();
                    }
                }
                while(true)
                {
                    /*long*/ let initialEmptyToNonEmptyCounts = $.$$.System.Threading.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64));
                    /*WorkStealingQueue?*/ let localQueue = this.GetCurrentThreadWorkStealingQueue(false);
                    /*bool*/ let gotItem = localQueue === null ? $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, null, result, take) : ($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(localQueue._nextQueue, null, result, take) || $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).TryStealFromTo(this._workStealingQueues, localQueue, result, take));
                    if (gotItem)
                    {
                        return true;
                    }
                    if ($.$$.System.Threading.Interlocked.Read($.$ref(() => this._emptyToNonEmptyListTransitionCount, ($v) => this._emptyToNonEmptyListTransitionCount = $v, $.$$.System.Int64)) === initialEmptyToNonEmptyCounts)
                    {
                        return false;
                    }
                }
            }
            static /*bool */ TryStealFromTo(/*WorkStealingQueue?*/ startInclusive, /*WorkStealingQueue?*/ endExclusive, /*out T*/ result, /*bool*/ take)
            {
                for(/*WorkStealingQueue?*/ let queue = startInclusive; queue !== endExclusive; queue = queue._nextQueue)
                {
                    if (queue.TrySteal(result, take))
                    {
                        return true;
                    }
                }
                result.$v = $.$default(T);
                return false;
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    /*int*/ let count = this.DangerousCount;
                    if (index > ((array.length - count) | 0))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    try
                    {
                        /*int*/ let copied = this.CopyFromEachQueueToArray(array, index);
                        $.$$.System.Diagnostics.Debug.Assert$2(copied === count, "copied == count");
                    }
                    catch(e)
                    {
                        throw new $.$$.System.InvalidCastException().$ctor$11(e.Message, e);
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            /*int */ CopyFromEachQueueToArray(/*T[]*/ array, /*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "Monitor.IsEntered(GlobalQueuesLock)");
                /*int*/ let i = index;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    i += queue.DangerousCopyTo(array, i);
                }
                return ((i - index) | 0);
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                /*T[]?*/ let szArray = $.$as(array, $.$typeArray(T));
                if (szArray !== null)
                {
                    this.CopyTo(szArray, index);
                    return;
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                this.ToArray().CopyTo(array, index);
            }
            /*T[] */ ToArray()
            {
                if (this._workStealingQueues !== null)
                {
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                        /*int*/ let count = this.DangerousCount;
                        if (count > 0)
                        {
                            /*var*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                            /*int*/ let copied = this.CopyFromEachQueueToArray(arr, 0);
                            $.$$.System.Diagnostics.Debug.Assert$2(copied === count, "copied == count");
                            return arr;
                        }
                    }
                    finally
                    {
                        {
                            this.UnfreezeBag(lockTaken);
                        }
                    }
                }
                return $.$$.System.Array.Empty(T);
            }
            /*void */ Clear()
            {
                if (this._workStealingQueues === null)
                {
                    return;
                }
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    local.LocalClear();
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        /*T?*/ let ignored;
                        while(queue.TrySteal($.$ref(() => ignored, ($v) => ignored = $v, T), true))
                        {
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                return (this.ToArray()).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*int */ get Count()
            {
                if (this._workStealingQueues === null)
                {
                    return 0;
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    return this.DangerousCount;
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
            }
            /*int */ get DangerousCount()
            {
                /*int*/ let count = 0;
                for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                {
                    //checked
                    {
                        count += queue.DangerousCount;
                    }
                }
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0, "count >= 0");
                return count;
            }
            /*bool */ get IsEmpty()
            {
                /*WorkStealingQueue?*/ let local = this.GetCurrentThreadWorkStealingQueue(false);
                if (local !== null)
                {
                    if (!local.IsEmpty)
                    {
                        return false;
                    }
                    if (local._nextQueue === null && local === this._workStealingQueues)
                    {
                        return true;
                    }
                }
                /*bool*/ let lockTaken = false;
                try
                {
                    this.FreezeBag($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (!queue.IsEmpty)
                        {
                            return false;
                        }
                    }
                }
                finally
                {
                    {
                        this.UnfreezeBag(lockTaken);
                    }
                }
                return true;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            /*object */ get GlobalQueuesLock()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._locals !== null, "_locals != null");
                return this._locals;
            }
            /*void */ FreezeBag(/*ref bool*/ lockTaken)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock), "!Monitor.IsEntered(GlobalQueuesLock)");
                $.$$.System.Threading.Monitor.Enter(this.GlobalQueuesLock, lockTaken);
                /*WorkStealingQueue?*/ let head = this._workStealingQueues;
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    $.$$.System.Threading.Monitor.Enter(queue, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => queue._frozen, ($v) => queue._frozen = $v, null));
                }
                $.$$.System.Threading.Interlocked.MemoryBarrier();
                for(/*WorkStealingQueue?*/ let queue = head; queue !== null; queue = queue._nextQueue)
                {
                    if (queue._currentOp !== 0/*Operation.None*/)
                    {
                        /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                        do
                        {
                            spinner.SpinOnce();
                        }
                        while(queue._currentOp !== 0/*Operation.None*/);
                    }
                }
            }
            /*void */ UnfreezeBag(/*bool*/ lockTaken)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this.GlobalQueuesLock) === lockTaken, "Monitor.IsEntered(GlobalQueuesLock) == lockTaken");
                if (lockTaken)
                {
                    for(/*WorkStealingQueue?*/ let queue = this._workStealingQueues; queue !== null; queue = queue._nextQueue)
                    {
                        if (queue._frozen)
                        {
                            queue._frozen = false;
                            $.$$.System.Threading.Monitor.Exit(queue);
                        }
                    }
                    $.$$.System.Threading.Monitor.Exit(this.GlobalQueuesLock);
                }
            }
            static $_WorkStealingQueue;
            static get WorkStealingQueue()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T);
                return $cls.$_WorkStealingQueue ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentBag$$.WorkStealingQueue", ($self) => class WorkStealingQueue extends $.$$.System.Object
                {
                    /*int*/ static InitialSize = 32;
                    /*int*/ static StartIndex = 2147483647;
                    /*int*/ _headIndex = 2147483647;
                    /*int*/ _tailIndex = 2147483647;
                    /*T[]*/ _array = null;
                    /*int*/ _mask = 31;
                    /*int*/ _addTakeCount = 0;
                    /*int*/ _stealCount = 0;
                    /*Operation*/ _currentOp = 0;
                    /*bool*/ _frozen = false;
                    /*WorkStealingQueue?*/ _nextQueue = null;
                    /*int*/ _ownerThreadId = 0;
                    $ctor$1(/*WorkStealingQueue?*/ nextQueue)
                    {
                        super.$ctor();
                        {
                            this._ownerThreadId = $.$$.System.Environment.CurrentManagedThreadId;
                            this._nextQueue = nextQueue;
                        }
                        return this;
                    }
                    /*bool */ get IsEmpty()
                    {
                        return ((this._headIndex - this._tailIndex) | 0) >= 0;
                    }
                    /*void */ LocalPush(/*T*/ item, /*ref long*/ emptyToNonEmptyListTransitionCount)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            $.$$.System.Threading.Interlocked.Exchange$14($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null), 1/*Operation.Add*/);
                            /*int*/ let tail = this._tailIndex;
                            if (tail === 2147483647/*int.MaxValue*/)
                            {
                                this._currentOp = 0/*Operation.None*/;
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(this)
                                    {
                                        $.$$.System.Diagnostics.Debug.Assert$2(this._tailIndex === tail, "No other thread should be changing _tailIndex");
                                        this._headIndex &= this._mask;
                                        this._tailIndex = tail &= this._mask;
                                        $.$$.System.Diagnostics.Debug.Assert$2(((this._headIndex - this._tailIndex) | 0) <= 0, "_headIndex - _tailIndex <= 0");
                                        $.$$.System.Threading.Interlocked.Exchange$14($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation, () => this._currentOp, ($v) => this._currentOp = $v, null), 1/*Operation.Add*/);
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(this)
                                }
                            }
                            /*int*/ let head = this._headIndex;
                            if (!this._frozen && (((head - (((tail - 1) | 0))) | 0) < 0) && (((tail - (((head + this._mask) | 0))) | 0) < 0))
                            {
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.System.Threading.Monitor.Enter(this, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                head = this._headIndex;
                                /*int*/ let count = ((tail - head) | 0);
                                if (count >= this._mask)
                                {
                                    /*var*/ let newArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._array.length << 1], null);
                                    /*int*/ let headIdx = head & this._mask;
                                    if (headIdx === 0)
                                    {
                                        $.$$.System.Array.Copy(this._array, newArray, this._array.length);
                                    }
                                    else 
                                    {
                                        $.$$.System.Array.Copy$2(this._array, headIdx, newArray, 0, ((this._array.length - headIdx) | 0));
                                        $.$$.System.Array.Copy$2(this._array, 0, newArray, ((this._array.length - headIdx) | 0), headIdx);
                                    }
                                    this._array = newArray;
                                    this._headIndex = 0;
                                    this._tailIndex = tail = count;
                                    this._mask = (this._mask << 1) | 1;
                                }
                                $.$$.System.Array.$WriteT1.call(this._array, item, tail & this._mask);
                                this._tailIndex = ((tail + 1) | 0);
                                if (count === 0)
                                {
                                    $.$$.System.Threading.Interlocked.Increment$1(emptyToNonEmptyListTransitionCount);
                                }
                                this._addTakeCount -= this._stealCount;
                                this._stealCount = 0;
                            }
                            //checked
                            {
                                this._addTakeCount++;
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.System.Threading.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    /*void */ LocalClear()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this)
                            {
                                if (((this._headIndex - this._tailIndex) | 0) < 0)
                                {
                                    this._headIndex = this._tailIndex = 2147483647/*StartIndex*/;
                                    this._addTakeCount = this._stealCount = 0;
                                    $.$$.System.Array.Clear$1(this._array);
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*bool */ TryLocalPop(/*out T*/ result)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) >= 0)
                        {
                            result.$v = $.$default(T);
                            return false;
                        }
                        /*bool*/ let lockTaken = false;
                        try
                        {
                            this._currentOp = 2/*Operation.Take*/;
                            $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._tailIndex, ($v) => this._tailIndex = $v, $.$$.System.Int32), --tail);
                            if (!this._frozen && (((this._headIndex - tail) | 0) < 0))
                            {
                                /*int*/ let idx = tail & this._mask;
                                result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                this._addTakeCount--;
                                return true;
                            }
                            else 
                            {
                                this._currentOp = 0/*Operation.None*/;
                                $.$$.System.Threading.Monitor.Enter(this, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                if (((this._headIndex - tail) | 0) <= 0)
                                {
                                    /*int*/ let idx = tail & this._mask;
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                    //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                    this._addTakeCount--;
                                    return true;
                                }
                                else 
                                {
                                    this._tailIndex = ((tail + 1) | 0);
                                    result.$v = $.$default(T);
                                    return false;
                                }
                            }
                        }
                        finally
                        {
                            {
                                this._currentOp = 0/*Operation.None*/;
                                if (lockTaken)
                                {
                                    $.$$.System.Threading.Monitor.Exit(this);
                                }
                            }
                        }
                    }
                    /*bool */ TryLocalPeek(/*out T*/ result)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Environment.CurrentManagedThreadId === this._ownerThreadId, "Environment.CurrentManagedThreadId == _ownerThreadId");
                        /*int*/ let tail = this._tailIndex;
                        if (((this._headIndex - tail) | 0) < 0)
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(this)
                                {
                                    if (((this._headIndex - tail) | 0) < 0)
                                    {
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, (((tail - 1) | 0)) & this._mask);
                                        return true;
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(this)
                            }
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    /*bool */ TrySteal(/*out T*/ result, /*bool*/ take)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this)
                            {
                                /*int*/ let head = this._headIndex;
                                if (take)
                                {
                                    if ((((head - (((this._tailIndex - 2) | 0))) | 0) >= 0) && this._currentOp === 1/*Operation.Add*/)
                                    {
                                        /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                                        do
                                        {
                                            spinner.SpinOnce();
                                        }
                                        while(this._currentOp === 1/*Operation.Add*/);
                                    }
                                    $.$$.System.Threading.Interlocked.Exchange$3($.$ref(() => this._headIndex, ($v) => this._headIndex = $v, $.$$.System.Int32), ((head + 1) | 0));
                                    if (head < this._tailIndex)
                                    {
                                        /*int*/ let idx = head & this._mask;
                                        result.$v = $.$$.System.Array.$ReadT1.call(this._array, idx);
                                        //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                                        this._stealCount++;
                                        return true;
                                    }
                                    else 
                                    {
                                        this._headIndex = head;
                                    }
                                }
                                else if (head < this._tailIndex)
                                {
                                    result.$v = $.$$.System.Array.$ReadT1.call(this._array, head & this._mask);
                                    return true;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this)
                        }
                        result.$v = $.$default(T);
                        return false;
                    }
                    /*int */ DangerousCopyTo(/*T[]*/ array, /*int*/ arrayIndex)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        $.$$.System.Diagnostics.Debug.Assert$2(this._frozen, "_frozen");
                        $.$$.System.Diagnostics.Debug.Assert$2(array !== null, "array != null");
                        $.$$.System.Diagnostics.Debug.Assert$2(arrayIndex >= 0 && arrayIndex <= array.length, "arrayIndex >= 0 && arrayIndex <= array.Length");
                        /*int*/ let headIndex = this._headIndex;
                        /*int*/ let count = this.DangerousCount;
                        $.$$.System.Diagnostics.Debug.Assert$2(count === (((this._tailIndex - this._headIndex) | 0)) || count === (((((this._tailIndex + 1) | 0) - this._headIndex) | 0)), "Count should be the same as tail - head, but allowing for the possibility that " + "a peek decremented _tailIndex before seeing that a freeze was happening.");
                        $.$$.System.Diagnostics.Debug.Assert$2(arrayIndex <= ((array.length - count) | 0), "arrayIndex <= array.Length - count");
                        for(/*int*/ let i = ((((arrayIndex + count) | 0) - 1) | 0); i >= arrayIndex; i--)
                        {
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(this._array, headIndex++ & this._mask), i);
                        }
                        return count;
                    }
                    /*int */ get DangerousCount()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered(this), "Monitor.IsEntered(this)");
                        /*int*/ let stealCount = this._stealCount;
                        /*int*/ let addTakeCount = this._addTakeCount;
                        /*int*/ let count = ((addTakeCount - stealCount) | 0);
                        $.$$.System.Diagnostics.Debug.Assert$4(count >= 0, `Expected _addTakeCount (${addTakeCount}) >= _stealCount (${stealCount}).`);
                        return count;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [32/*InitialSize*/], null);
                    }
                    static $h = 393222;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xF00000000n),"f":50331656},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1700000000n),"f":50331656},"n":"DangerousCount","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":2097160}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328},{"n":"emptyToNonEmptyListTransitionCount","p":917505,"f":4}],"n":"LocalPush","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777224},{"r":65537,"n":"LocalClear","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777224},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryLocalPop","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777224},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryLocalPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777224},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2},{"n":"take","p":262145}],"n":"TrySteal","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777224},{"r":655361,"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"arrayIndex","p":655361}],"n":"DangerousCopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777224}],"l":[{"t":655361,"n":"InitialSize","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338},{"t":655361,"n":"StartIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194338},{"t":655361,"n":"_headIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655361,"n":"_tailIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":$.$typeArray(T).$h,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":655361,"n":"_mask","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":655361,"n":"_addTakeCount","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306},{"t":655361,"n":"_stealCount","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194306},{"t":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation.$h,"n":"_currentOp","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4194312},{"t":262145,"n":"_frozen","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":4194312},{"t":this.$h,"n":"_nextQueue","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":4194312},{"t":655361,"n":"_ownerThreadId","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":4194312}],"c":[{"p":[{"n":"nextQueue","p":this.$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777224}],"d":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>.WorkStealingQueue`; }
                }, $cls, ($v) => $cls.$_WorkStealingQueue = $v);
            }
            static $_Operation;
            static get Operation()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentBag$$(T);
                return $cls.$_Operation ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentBag$$.Operation", ($self) => class Operation extends $.$$.System.Enum
                {
                    static None = 0;
                    static Add = 1;
                    static Take = 2;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "Add": 1n,
                            "Take": 2n
                        };
                    }
                    static $h = 327686;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":this.$h,"n":"None","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194337},{"t":this.$h,"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194337},{"t":this.$h,"n":"Take","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>.Operation`; }
                }, $cls, ($v) => $cls.$_Operation = $v);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.CopyTo(T[], int)
            System$Collections$Concurrent$IProducerConsumerCollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.TryTake(out T)
            System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake()
            {
                return this.TryTake(...arguments);
            }
            //Generated interface implemetation for System.Collections.Concurrent.IProducerConsumerCollection<T>.ToArray()
            System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray()
            {
                return this.ToArray(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<T>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 262150;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1700000000n),"f":50331649},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1900000000n),"f":50331650},"n":"DangerousCount","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":50331649},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2100000000n),"f":50331650},"n":"GlobalQueuesLock","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":2097154}],"m":[{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryTake","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217},{"r":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h,"p":[{"n":"forceCreate","p":262145}],"n":"GetCurrentThreadWorkStealingQueue","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777218},{"r":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h,"n":"CreateWorkStealingQueueForCurrentThread","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777218},{"r":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h,"n":"GetUnownedWorkStealingQueue","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777218},{"r":262145,"p":[{"n":"result","p":T?.$h??1507328,"f":2},{"n":"take","p":262145}],"n":"TrySteal","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777218},{"r":262145,"p":[{"n":"startInclusive","p":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h},{"n":"endExclusive","p":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h},{"n":"result","p":T?.$h??1507328,"f":2},{"n":"take","p":262145}],"n":"TryStealFromTo","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777250},{"r":65537,"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"index","p":655361}],"n":"CopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217},{"r":655361,"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"index","p":655361}],"n":"CopyFromEachQueueToArray","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777218},{"r":$.$typeArray(T).$h,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217},{"r":65537,"p":[{"n":"lockTaken","p":262145,"f":4}],"n":"FreezeBag","d":this.$h,"h":Number(BigInt(this.$h)|0x2200000000n),"f":16777218},{"r":65537,"p":[{"n":"lockTaken","p":262145}],"n":"UnfreezeBag","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":16777218}],"l":[{"t":$.$$.System.Threading.ThreadLocal$$($.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue).$h,"n":"_locals","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h,"n":"_workStealingQueues","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":917505,"n":"_emptyToNonEmptyListTransitionCount","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"i":[$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,31457281,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425],"g":[T?.$h??1507328],"j":[$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).WorkStealingQueue.$h,$.$scc.System.Collections.Concurrent.ConcurrentBag$$(T).Operation.$h],"r":1,"h":this.$h,"a":[{"t":37945345,"c":8627879937,"a":[{"v":$.$scc.System.Collections.Concurrent.IProducerConsumerCollectionDebugView$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentBag<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.BlockingCollection<>", (T) => $asm.$gt("$scc.System.Collections.Concurrent.BlockingCollection<>", [T], ($self) => class BlockingCollection$$ extends $.$$.System.Object
        {
            /*IProducerConsumerCollection<T>*/ _collection = null;
            /*int*/ _boundedCapacity = 0;
            /*int*/ static NON_BOUNDED = -1;
            /*SemaphoreSlim?*/ _freeNodes = null;
            /*SemaphoreSlim*/ _occupiedNodes = null;
            /*bool*/ _isDisposed = false;
            /*CancellationTokenSource*/ _consumersCancellationTokenSource = null;
            /*CancellationTokenSource*/ _producersCancellationTokenSource = null;
            /*int*/ _currentAdders = 0;
            /*int*/ static COMPLETE_ADDING_ON_MASK = -2147483648;
            /*int */ get BoundedCapacity()
            {
                this.CheckDisposed();
                return this._boundedCapacity;
            }
            /*bool */ get IsAddingCompleted()
            {
                this.CheckDisposed();
                return (this._currentAdders === -2147483648/*COMPLETE_ADDING_ON_MASK*/);
            }
            /*bool */ get IsCompleted()
            {
                this.CheckDisposed();
                return (this.IsAddingCompleted && (this._occupiedNodes.CurrentCount === 0));
            }
            /*int */ get Count()
            {
                this.CheckDisposed();
                return this._occupiedNodes.CurrentCount;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                this.CheckDisposed();
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            $ctor$1()
            {
                this.$ctor$3(new ($.$$.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1());
                {
                }
                return this;
            }
            $ctor$4(/*int*/ boundedCapacity)
            {
                this.$ctor$2(new ($.$$.System.Collections.Concurrent.ConcurrentQueue$$(T))().$ctor$1(), boundedCapacity);
                {
                }
                return this;
            }
            $ctor$2(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, boundedCapacity, "boundedCapacity");
                    /*int*/ let count = collection.System$Collections$ICollection$Count;
                    if (count > boundedCapacity)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.BlockingCollection_ctor_CountMoreThanCapacity);
                    }
                    this.Initialize(collection, boundedCapacity, count);
                }
                return this;
            }
            $ctor$3(/*IProducerConsumerCollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.Initialize(collection, -1/*NON_BOUNDED*/, collection.System$Collections$ICollection$Count);
                }
                return this;
            }
            /*void */ Initialize(/*IProducerConsumerCollection<T>*/ collection, /*int*/ boundedCapacity, /*int*/ collectionCount)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(boundedCapacity > 0 || boundedCapacity === -1/*NON_BOUNDED*/, "boundedCapacity > 0 || boundedCapacity == NON_BOUNDED");
                this._collection = collection;
                this._boundedCapacity = boundedCapacity;
                this._isDisposed = false;
                this._consumersCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                this._producersCancellationTokenSource = new $.$$.System.Threading.CancellationTokenSource().$ctor$1();
                if (boundedCapacity === -1/*NON_BOUNDED*/)
                {
                    this._freeNodes = null;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(boundedCapacity > 0, "boundedCapacity > 0");
                    this._freeNodes = new $.$$.System.Threading.SemaphoreSlim().$ctor$2(((boundedCapacity - collectionCount) | 0));
                }
                this._occupiedNodes = new $.$$.System.Threading.SemaphoreSlim().$ctor$2(collectionCount);
            }
            /*void */ Add$1(/*T*/ item)
            {
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            /*void */ Add(/*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                /*bool*/ let tryAddReturnValue = this.TryAddWithNoTimeValidation(item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddReturnValue, "TryAdd() was expected to return true.");
            }
            /*bool */ TryAdd$3(/*T*/ item)
            {
                return this.TryAddWithNoTimeValidation(item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ TryAdd$2(/*T*/ item, /*TimeSpan*/ timeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryAddWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ TryAdd$1(/*T*/ item, /*int*/ millisecondsTimeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ TryAdd(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryAddWithNoTimeValidation(item, millisecondsTimeout, cancellationToken);
            }
            /*bool */ TryAddWithNoTimeValidation(/*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                this.CheckDisposed();
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsAddingCompleted)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Completed);
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = true;
                if (this._freeNodes !== null)
                {
                    /*CancellationTokenSource?*/ let linkedTokenSource = null;
                    try
                    {
                        waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(0, new $.$$.System.Threading.CancellationToken());
                        if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                        {
                            linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._producersCancellationTokenSource.Token);
                            waitForSemaphoreWasSuccessful = this._freeNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                        }
                    }
                    catch($e)
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Add_ConcurrentCompleteAdd);
                    }
                    finally
                    {
                        {
                            linkedTokenSource?.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                    while(true)
                    {
                        /*int*/ let observedAdders = this._currentAdders;
                        if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                        {
                            spinner.Reset();
                            while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                            {
                                spinner.SpinOnce();
                            }
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Completed);
                        }
                        if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32), ((observedAdders + 1) | 0), observedAdders) === observedAdders)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((((observedAdders + 1) | 0)) <= (~-2147483648/*COMPLETE_ADDING_ON_MASK*/), "The number of concurrent adders thread exceeded the maximum limit.");
                            break;
                        }
                        spinner.SpinOnce$1(-1);
                    }
                    /*bool*/ let addingSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        addingSucceeded = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$TryAdd(item, [T]);
                        if (!addingSucceeded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Add_Failed);
                        }
                    }
                    finally
                    {
                        {
                            if (addingSucceeded)
                            {
                                this._occupiedNodes.Release();
                            }
                            else 
                            {
                                this._freeNodes?.Release();
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2((this._currentAdders & ~-2147483648/*COMPLETE_ADDING_ON_MASK*/) > 0, "(_currentAdders & ~COMPLETE_ADDING_ON_MASK) > 0");
                            $.$$.System.Threading.Interlocked.Decrement($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32));
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            /*T */ Take()
            {
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            /*T */ Take$1(/*CancellationToken*/ cancellationToken)
            {
                /*T?*/ let item;
                if (!this.TryTake($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_CantTakeWhenDone);
                }
                return item;
            }
            /*bool */ TryTake$3(/*out T*/ item)
            {
                return this.TryTake(item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ TryTake$2(/*out T*/ item, /*TimeSpan*/ timeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return this.TryTakeWithNoTimeValidation(item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None, null);
            }
            /*bool */ TryTake$1(/*out T*/ item, /*int*/ millisecondsTimeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None, null);
            }
            /*bool */ TryTake(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return this.TryTakeWithNoTimeValidation(item, millisecondsTimeout, cancellationToken, null);
            }
            /*bool */ TryTakeWithNoTimeValidation(/*out T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken, /*CancellationTokenSource?*/ combinedTokenSource)
            {
                this.CheckDisposed();
                item.$v = $.$default(T);
                cancellationToken.ThrowIfCancellationRequested();
                if (this.IsCompleted)
                {
                    return false;
                }
                /*bool*/ let waitForSemaphoreWasSuccessful = false;
                /*CancellationTokenSource?*/ let linkedTokenSource = combinedTokenSource;
                try
                {
                    waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$2(0);
                    if (waitForSemaphoreWasSuccessful === false && millisecondsTimeout !== 0)
                    {
                        linkedTokenSource ??= $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                        waitForSemaphoreWasSuccessful = this._occupiedNodes.Wait$1(millisecondsTimeout, linkedTokenSource.Token);
                    }
                }
                catch($e)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return false;
                }
                finally
                {
                    {
                        if (linkedTokenSource !== null && combinedTokenSource === null)
                        {
                            linkedTokenSource.Dispose();
                        }
                    }
                }
                if (waitForSemaphoreWasSuccessful)
                {
                    /*bool*/ let removeSucceeded = false;
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        removeSucceeded = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$TryTake(item, [T]);
                        if (!removeSucceeded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scc.System.SR.BlockingCollection_Take_CollectionModified);
                        }
                    }
                    finally
                    {
                        {
                            if (removeSucceeded)
                            {
                                if (this._freeNodes !== null)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(this._boundedCapacity !== -1/*NON_BOUNDED*/, "_boundedCapacity != NON_BOUNDED");
                                    this._freeNodes.Release();
                                }
                            }
                            else 
                            {
                                this._occupiedNodes.Release();
                            }
                            if (this.IsCompleted)
                            {
                                this.CancelWaitingConsumers();
                            }
                        }
                    }
                }
                return waitForSemaphoreWasSuccessful;
            }
            static /*int */ AddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                /*int*/ let tryAddAnyReturnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, $.$$.System.Threading.CancellationToken.None);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            static /*int */ AddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*CancellationToken*/ cancellationToken)
            {
                /*int*/ let tryAddAnyReturnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, -1/*Timeout.Infinite*/, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(tryAddAnyReturnValue >= 0 && tryAddAnyReturnValue < collections.length, "TryAddToAny() was expected to return an index within the bounds of the collections array.");
                return tryAddAnyReturnValue;
            }
            static /*int */ TryAddToAny$3(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAny(collections, item, 0, $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TryAddToAny$2(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*TimeSpan*/ timeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TryAddToAny$1(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TryAddToAny(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyCore(collections, item, millisecondsTimeout, cancellationToken);
            }
            static /*int */ TryAddToAnyCore(/*BlockingCollection<T>[]*/ collections, /*T*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ externalCancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateCollectionsArray(collections, true);
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.System.Environment.TickCount >>> 0);
                }
                /*int*/ let index = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryAddToAnyFast(collections, item);
                if (index > -1)
                {
                    return index;
                }
                /*CancellationToken[]*/ let collatedCancellationTokens;
                /*List<WaitHandle>*/ let handles = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, true, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.System.Threading.CancellationToken)));
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    index = -1;
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        index = $.$$.System.Threading.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        handles.RemoveAt(((handles.Count - 1) | 0));
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                    if (index === 258/*WaitHandle.WaitTimeout*/)
                    {
                        return OPERATION_FAILED;
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, index).TryAdd$3(item))
                    {
                        return index;
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                return OPERATION_FAILED;
            }
            static /*int */ TryAddToAnyFast(/*BlockingCollection<T>[]*/ collections, /*T*/ item)
            {
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._freeNodes === null)
                    {
                        /*bool*/ let result = $.$$.System.Array.$ReadT1.call(collections, i).TryAdd$3(item);
                        $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                        return i;
                    }
                }
                return -1;
            }
            static /*List<WaitHandle> */ GetHandles(/*BlockingCollection<T>[]*/ collections, /*CancellationToken*/ externalCancellationToken, /*bool*/ isAddOperation, /*out CancellationToken[]*/ cancellationTokens)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(collections !== null, "collections != null");
                /*List<WaitHandle>*/ let handlesList = new ($.$$.System.Collections.Generic.List$$($.$$.System.Threading.WaitHandle))().$ctor$3(((collections.length + 1) | 0));
                /*List<CancellationToken>*/ let tokensList = new ($.$$.System.Collections.Generic.List$$($.$$.System.Threading.CancellationToken))().$ctor$3(((collections.length + 1) | 0));
                tokensList.Add(externalCancellationToken);
                if (isAddOperation)
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        /*BlockingCollection<T>*/ let c = $.$$.System.Array.$ReadT1.call(collections, i);
                        if (c._freeNodes !== null)
                        {
                            handlesList.Add(c._freeNodes.AvailableWaitHandle);
                            tokensList.Add(c._producersCancellationTokenSource.Token);
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < collections.length; i++)
                    {
                        if ($.$$.System.Array.$ReadT1.call(collections, i).IsCompleted)
                        {
                            continue;
                        }
                        handlesList.Add($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle);
                        tokensList.Add($.$$.System.Array.$ReadT1.call(collections, i)._consumersCancellationTokenSource.Token);
                    }
                }
                cancellationTokens.$v = tokensList.ToArray();
                return handlesList;
            }
            static /*int */ UpdateTimeOut(/*uint*/ startTime, /*int*/ originalWaitMillisecondsTimeout)
            {
                if (originalWaitMillisecondsTimeout === 0)
                {
                    return 0;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(originalWaitMillisecondsTimeout !== -1/*Timeout.Infinite*/, "originalWaitMillisecondsTimeout != Timeout.Infinite");
                /*uint*/ let elapsedMilliseconds = ((($.$$.System.Environment.TickCount >>> 0) - startTime) >>> 0);
                if (elapsedMilliseconds > 2147483647/*int.MaxValue*/)
                {
                    return 0;
                }
                /*int*/ let currentWaitTimeout = ((originalWaitMillisecondsTimeout - (elapsedMilliseconds | 0)) | 0);
                if (currentWaitTimeout <= 0)
                {
                    return 0;
                }
                return currentWaitTimeout;
            }
            static /*int */ TakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TakeFromAny(collections, item, $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*CancellationToken*/ cancellationToken)
            {
                /*int*/ let returnValue = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, -1/*Timeout.Infinite*/, true, cancellationToken);
                $.$$.System.Diagnostics.Debug.Assert$2(returnValue >= 0 && returnValue < collections.length, "TryTakeFromAny() was expected to return an index within the bounds of the collections array.");
                return returnValue;
            }
            static /*int */ TryTakeFromAny$3(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item)
            {
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAny$1(collections, item, 0);
            }
            static /*int */ TryTakeFromAny$2(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*TimeSpan*/ timeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateTimeout(timeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, $.$cast(timeout.TotalMilliseconds, $.$$.System.Int32), false, $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TryTakeFromAny$1(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, $.$$.System.Threading.CancellationToken.None);
            }
            static /*int */ TryTakeFromAny(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*CancellationToken*/ cancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateMillisecondsTimeout(millisecondsTimeout);
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCore(collections, item, millisecondsTimeout, false, cancellationToken);
            }
            static /*int */ TryTakeFromAnyCore(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).ValidateCollectionsArray(collections, false);
                for(/*int*/ let i = 0; i < collections.length; i++)
                {
                    if (!$.$$.System.Array.$ReadT1.call(collections, i).IsCompleted && $.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.CurrentCount > 0 && $.$$.System.Array.$ReadT1.call(collections, i).TryTake$3(item))
                    {
                        return i;
                    }
                }
                return $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).TryTakeFromAnyCoreSlow(collections, item, millisecondsTimeout, isTakeOperation, externalCancellationToken);
            }
            static /*int */ TryTakeFromAnyCoreSlow(/*BlockingCollection<T>[]*/ collections, /*out T?*/ item, /*int*/ millisecondsTimeout, /*bool*/ isTakeOperation, /*CancellationToken*/ externalCancellationToken)
            {
                /*int*/ let OPERATION_FAILED = -1;
                /*int*/ let timeout = millisecondsTimeout;
                /*uint*/ let startTime = 0;
                if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                {
                    startTime = ($.$$.System.Environment.TickCount >>> 0);
                }
                while(millisecondsTimeout === -1/*Timeout.Infinite*/ || timeout >= 0)
                {
                    /*CancellationToken[]*/ let collatedCancellationTokens;
                    /*List<WaitHandle>*/ let handles = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).GetHandles(collections, externalCancellationToken, false, $.$ref(() => collatedCancellationTokens, ($v) => collatedCancellationTokens = $v, $.$typeArray($.$$.System.Threading.CancellationToken)));
                    if (handles.Count === 0 && isTakeOperation)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantTakeAnyWhenAllDone, "collections");
                    }
                    if (handles.Count === 0)
                    {
                        break;
                    }
                    let linkedTokenSource = null;
                    try
                    {
                        linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$3(collatedCancellationTokens);
                        handles.Add(linkedTokenSource.Token.WaitHandle);
                        /*int*/ let index = $.$$.System.Threading.WaitHandle.WaitAny$3(handles.ToArray(), timeout);
                        if (linkedTokenSource.IsCancellationRequested)
                        {
                            externalCancellationToken.ThrowIfCancellationRequested();
                        }
                        if (!linkedTokenSource.IsCancellationRequested)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((index === 258/*WaitHandle.WaitTimeout*/) || (index >= 0 && index < handles.Count), "(index == WaitHandle.WaitTimeout) || (index >= 0 && index < handles.Count)");
                            if (index === 258/*WaitHandle.WaitTimeout*/)
                            {
                                break;
                            }
                            if (collections.length !== ((handles.Count - 1) | 0))
                            {
                                for(/*int*/ let i = 0; i < collections.length; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(collections, i)._occupiedNodes.AvailableWaitHandle === handles.get_Item(index))
                                    {
                                        index = i;
                                        break;
                                    }
                                }
                            }
                            if ($.$$.System.Array.$ReadT1.call(collections, index).TryTake$3(item))
                            {
                                return index;
                            }
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                    if (millisecondsTimeout !== -1/*Timeout.Infinite*/)
                    {
                        timeout = $.$scc.System.Collections.Concurrent.BlockingCollection$$(T).UpdateTimeOut(startTime, millisecondsTimeout);
                    }
                }
                item.$v = $.$default(T);
                return OPERATION_FAILED;
            }
            /*void */ CompleteAdding()
            {
                this.CheckDisposed();
                if (this.IsAddingCompleted)
                {
                    return;
                }
                /*SpinWait*/ let spinner = new $.$$.System.Threading.SpinWait();
                while(true)
                {
                    /*int*/ let observedAdders = this._currentAdders;
                    if ((observedAdders & -2147483648/*COMPLETE_ADDING_ON_MASK*/) !== 0)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        return;
                    }
                    if ($.$$.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._currentAdders, ($v) => this._currentAdders = $v, $.$$.System.Int32), observedAdders | -2147483648/*COMPLETE_ADDING_ON_MASK*/, observedAdders) === observedAdders)
                    {
                        spinner.Reset();
                        while(this._currentAdders !== -2147483648/*COMPLETE_ADDING_ON_MASK*/)
                        {
                            spinner.SpinOnce();
                        }
                        if (this.Count === 0)
                        {
                            this.CancelWaitingConsumers();
                        }
                        this.CancelWaitingProducers();
                        return;
                    }
                    spinner.SpinOnce$1(-1);
                }
            }
            /*void */ CancelWaitingConsumers()
            {
                this._consumersCancellationTokenSource.Cancel();
            }
            /*void */ CancelWaitingProducers()
            {
                this._producersCancellationTokenSource.Cancel();
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!this._isDisposed)
                {
                    this._freeNodes?.Dispose();
                    this._occupiedNodes.Dispose();
                    this._isDisposed = true;
                }
            }
            /*T[] */ ToArray()
            {
                this.CheckDisposed();
                return this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                (this).System$Collections$ICollection$CopyTo(array, index);
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.CheckDisposed();
                /*T[]*/ let collectionSnapShot = this._collection.System$Collections$Concurrent$IProducerConsumerCollection$$$ToArray([T]);
                try
                {
                    $.$$.System.Array.Copy$2(collectionSnapShot, 0, array, index, collectionSnapShot.length);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.ArgumentNullException)
                    {
                        throw new $.$$.System.ArgumentNullException().$ctor$19("array");
                    }
                    else if ($e instanceof $.$$.System.ArgumentOutOfRangeException)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$scc.System.SR.BlockingCollection_CopyTo_NonNegative);
                    }
                    else if ($e instanceof $.$$.System.ArgumentException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.Collection_CopyTo_TooManyElems, "index");
                    }
                    else if ($e instanceof $.$$.System.RankException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_MultiDim, "array");
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else if ($e instanceof $.$$.System.ArrayTypeMismatchException)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CopyTo_IncorrectType, "array");
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*IEnumerable<T> */ GetConsumingEnumerable()
            {
                return this.GetConsumingEnumerable$1($.$$.System.Threading.CancellationToken.None);
            }
            /*IEnumerable<T> */ GetConsumingEnumerable$1(/*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (this.IsCompleted)
                    {
                        return;
                    }
                    /*CancellationTokenSource*/ let linkedTokenSource = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken, this._consumersCancellationTokenSource.Token);
                    try
                    {
                        /*T?*/ let item;
                        while(this.TryTakeWithNoTimeValidation($.$ref(() => item, ($v) => item = $v, T), -1/*Timeout.Infinite*/, cancellationToken, linkedTokenSource))
                        {
                            yield item;
                        }
                    }
                    finally
                    {
                        linkedTokenSource?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                this.CheckDisposed();
                return this._collection.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static /*void */ ValidateCollectionsArray(/*BlockingCollection<T>[]*/ collections, /*bool*/ isAddOperation)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collections, "collections");
                if (collections.length < 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_ZeroSize, "collections");
                }
                if ((collections.length > 63) || ((collections.length === 63) && ($.$$.System.Threading.Thread.CurrentThread.GetApartmentState() === 0/*ApartmentState.STA*/)))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("collections", $.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_LargeSize);
                }
                for(/*int*/ let i = 0; i < collections.length; ++i)
                {
                    if ($.$$.System.Array.$ReadT1.call(collections, i) === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_NullElems, "collections");
                    }
                    if ($.$$.System.Array.$ReadT1.call(collections, i)._isDisposed)
                    {
                        throw new $.$$.System.ObjectDisposedException().$ctor$16("collections", $.$scc.System.SR.BlockingCollection_ValidateCollectionsArray_DispElems);
                    }
                    if (isAddOperation && $.$$.System.Array.$ReadT1.call(collections, i).IsAddingCompleted)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.BlockingCollection_CantAddAnyWhenCompleted, "collections");
                    }
                }
            }
            static /*void */ ValidateTimeout(/*TimeSpan*/ timeout)
            {
                /*long*/ let totalMilliseconds = $.$cast(timeout.TotalMilliseconds, $.$$.System.Int64);
                if ((totalMilliseconds < 0n || totalMilliseconds > BigInt(2147483647/*int.MaxValue*/)) && (totalMilliseconds !== BigInt(-1/*Timeout.Infinite*/)))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("timeout", timeout, $.$scc.System.SR.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$scc.System.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.System.Int32)));
                }
            }
            static /*void */ ValidateMillisecondsTimeout(/*int*/ millisecondsTimeout)
            {
                if ((millisecondsTimeout < 0) && (millisecondsTimeout !== -1/*Timeout.Infinite*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("millisecondsTimeout", $.$box(millisecondsTimeout, $.$$.System.Int32), $.$scc.System.SR.Format$2($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$scc.System.SR.BlockingCollection_TimeoutInvalid, $.$box(2147483647/*int.MaxValue*/, $.$$.System.Int32)));
                }
            }
            /*void */ CheckDisposed()
            {
                $.$$.System.ObjectDisposedException.ThrowIf(this._isDisposed, this);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            static $h = 65542;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"n":"BoundedCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331649},"n":"IsAddingCompleted","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"IsCompleted","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1200000000n),"f":50331649},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1400000000n),"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1600000000n),"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2097154}],"m":[{"r":65537,"p":[{"n":"collection","p":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h},{"n":"boundedCapacity","p":655361},{"n":"collectionCount","p":655361}],"n":"Initialize","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777218},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328}],"n":"Add","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777217},{"r":65537,"p":[{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125829121}],"n":"Add","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328}],"n":"TryAdd","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328},{"n":"timeout","p":140574721}],"n":"TryAdd","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361}],"n":"TryAdd","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"TryAddWithNoTimeValidation","d":this.$h,"h":Number(BigInt(this.$h)|0x2200000000n),"f":16777218},{"r":T?.$h??1507328,"n":"Take","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":16777217},{"r":T?.$h??1507328,"p":[{"n":"cancellationToken","p":125829121}],"n":"Take","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2400000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryTake","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x2500000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2},{"n":"timeout","p":140574721}],"n":"TryTake","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x2600000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361}],"n":"TryTake","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2700000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"TryTake","d":this.$h,"h":Number(BigInt(this.$h)|0x2800000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121},{"n":"combinedTokenSource","p":125960193}],"n":"TryTakeWithNoTimeValidation","d":this.$h,"h":Number(BigInt(this.$h)|0x2900000000n),"f":16777218},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328}],"n":"AddToAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2A00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328},{"n":"cancellationToken","p":125829121}],"n":"AddToAny","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328}],"n":"TryAddToAny","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328},{"n":"timeout","p":140574721}],"n":"TryAddToAny","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361}],"n":"TryAddToAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"TryAddToAny","d":this.$h,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328},{"n":"millisecondsTimeout","p":655361},{"n":"externalCancellationToken","p":125829121}],"n":"TryAddToAnyCore","d":this.$h,"h":Number(BigInt(this.$h)|0x3000000000n),"f":16777250},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328}],"n":"TryAddToAnyFast","d":this.$h,"h":Number(BigInt(this.$h)|0x3100000000n),"f":16777250},{"r":$.$$.System.Collections.Generic.List$$($.$$.System.Threading.WaitHandle).$h,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"externalCancellationToken","p":125829121},{"n":"isAddOperation","p":262145},{"n":"cancellationTokens","p":$.$typeArray($.$$.System.Threading.CancellationToken).$h,"f":2}],"n":"GetHandles","d":this.$h,"h":Number(BigInt(this.$h)|0x3200000000n),"f":16777250},{"r":655361,"p":[{"n":"startTime","p":720897},{"n":"originalWaitMillisecondsTimeout","p":655361}],"n":"UpdateTimeOut","d":this.$h,"h":Number(BigInt(this.$h)|0x3300000000n),"f":16777250},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TakeFromAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3400000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"cancellationToken","p":125829121}],"n":"TakeFromAny","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2}],"n":"TryTakeFromAny","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x3600000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"timeout","p":140574721}],"n":"TryTakeFromAny","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361}],"n":"TryTakeFromAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3800000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361},{"n":"cancellationToken","p":125829121}],"n":"TryTakeFromAny","d":this.$h,"h":Number(BigInt(this.$h)|0x3900000000n),"f":16777249},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361},{"n":"isTakeOperation","p":262145},{"n":"externalCancellationToken","p":125829121}],"n":"TryTakeFromAnyCore","d":this.$h,"h":Number(BigInt(this.$h)|0x3A00000000n),"f":16777250},{"r":655361,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"item","p":T?.$h??1507328,"f":2},{"n":"millisecondsTimeout","p":655361},{"n":"isTakeOperation","p":262145},{"n":"externalCancellationToken","p":125829121}],"n":"TryTakeFromAnyCoreSlow","d":this.$h,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":16777250},{"r":65537,"n":"CompleteAdding","d":this.$h,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":16777217},{"r":65537,"n":"CancelWaitingConsumers","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":16777218},{"r":65537,"n":"CancelWaitingProducers","d":this.$h,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":16777218},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x4000000000n),"f":16777348},{"r":$.$typeArray(T).$h,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"index","p":655361}],"n":"CopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x4200000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$(T).$h,"n":"GetConsumingEnumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x4400000000n),"f":16777217},{"r":$.$$.System.Collections.Generic.IEnumerable$$(T).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"GetConsumingEnumerable","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x4500000000n),"f":16777217},{"r":65537,"p":[{"n":"collections","p":$.$typeArray($.$scc.System.Collections.Concurrent.BlockingCollection$$(T)).$h},{"n":"isAddOperation","p":262145}],"n":"ValidateCollectionsArray","d":this.$h,"h":Number(BigInt(this.$h)|0x4800000000n),"f":16777250},{"r":65537,"p":[{"n":"timeout","p":140574721}],"n":"ValidateTimeout","d":this.$h,"h":Number(BigInt(this.$h)|0x4900000000n),"f":16777250},{"r":65537,"p":[{"n":"millisecondsTimeout","p":655361}],"n":"ValidateMillisecondsTimeout","d":this.$h,"h":Number(BigInt(this.$h)|0x4A00000000n),"f":16777250},{"r":65537,"n":"CheckDisposed","d":this.$h,"h":Number(BigInt(this.$h)|0x4B00000000n),"f":16777218}],"l":[{"t":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h,"n":"_collection","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":655361,"n":"_boundedCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":655361,"n":"NON_BOUNDED","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194338},{"t":130613249,"n":"_freeNodes","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":130613249,"n":"_occupiedNodes","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":262145,"n":"_isDisposed","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194306},{"t":125960193,"n":"_consumersCancellationTokenSource","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194306},{"t":125960193,"n":"_producersCancellationTokenSource","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":4194306},{"t":655361,"n":"_currentAdders","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":4194306},{"t":655361,"n":"COMPLETE_ADDING_ON_MASK","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777217},{"p":[{"n":"boundedCapacity","p":655361}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h},{"n":"boundedCapacity","p":655361}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Concurrent.IProducerConsumerCollection$$(T).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777217}],"i":[31457281,57540609,$.$$.System.Collections.Generic.IReadOnlyCollection$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,31719425],"g":[T?.$h??1507328],"r":1,"h":this.$h,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"browser","t":1310721}]},{"t":37945345,"c":8627879937,"a":[{"v":$.$scc.System.Collections.Concurrent.BlockingCollectionDebugView$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}, Type = {_collection}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.IDisposable, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.BlockingCollection<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$scc.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.System.ValueType
        {
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            /*TKey*/ Key = $.$default(TKey);
            /*TValue*/ Value = $.$default(TValue);
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 3014662;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":TKey?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"n":"Key","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":2,"t":37486593}]}]},{"p":TValue?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":2,"t":37486593}]}]}],"c":[{"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217},{"p":[{"n":"keyValue","p":$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217}],"g":[TKey?.$h??1507328,TValue?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{Value}","t":1310721}],"n":[{"n":"Name","v":"[{Key}]","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$str("$scc.System.Collections.Concurrent.EnumerablePartitionerOptions", ($self) => class EnumerablePartitionerOptions extends $.$$.System.Enum
        {
            static None = 0;
            static NoBuffering = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "NoBuffering": 1n
                };
            }
            static $h = 1114118;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1114118,"n":"None","d":1114118,"h":4296081414,"f":4194337},{"t":1114118,"n":"NoBuffering","d":1114118,"h":8591048710,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1114118,"h":12886016006,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1114118,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Concurrent.EnumerablePartitionerOptions`; }
        });
        
        $asm.$cls("$scc.System.Collections.Concurrent.ConcurrentDictionary<,>", (TKey, TValue) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionary<,>", [TKey, TValue], ($self) => class ConcurrentDictionary$$$ extends $.$$.System.Object
        {
            /*Tables*/ _tables = null;
            /*int*/ _budget = 0;
            /*bool*/ _growLockArray = false;
            /*bool*/ _comparerIsDefaultForClasses = false;
            /*int*/ _initialCapacity = 0;
            /*int*/ static DefaultCapacity = 31;
            /*int*/ static MaxLockNumber = 1024;
            $ctor$1()
            {
                this.$ctor$6($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, null);
                {
                }
                return this;
            }
            $ctor$8(/*int*/ concurrencyLevel, /*int*/ capacity)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, null);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                this.$ctor$5($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, collection, null);
                {
                }
                return this;
            }
            $ctor$4(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, 31/*DefaultCapacity*/, true, comparer);
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), comparer);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            $ctor$5(/*int*/ concurrencyLevel, /*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetCapacityFromCollection(collection), false, comparer);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.InitializeFromCollection(collection);
                }
                return this;
            }
            $ctor$7(/*int*/ concurrencyLevel, /*int*/ capacity, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$6(concurrencyLevel, capacity, false, comparer);
                {
                }
                return this;
            }
            $ctor$6(/*int*/ concurrencyLevel, /*int*/ capacity, /*bool*/ growLockArray, /*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    if (concurrencyLevel <= 0)
                    {
                        if (concurrencyLevel !== -1)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("concurrencyLevel", $.$scc.System.SR.ConcurrentDictionary_ConcurrencyLevelMustBePositiveOrNegativeOne);
                        }
                        concurrencyLevel = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DefaultConcurrencyLevel;
                    }
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    if (capacity < concurrencyLevel)
                    {
                        capacity = concurrencyLevel;
                    }
                    capacity = $.$scc.System.Collections.HashHelpers.GetPrime(capacity);
                    /*var*/ let locks = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [concurrencyLevel], null);
                    $.$$.System.Array.$WriteT1.call(locks, locks, 0);
                    for(/*int*/ let i = 1; i < locks.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(locks, new $.$$.System.Object().$ctor(), i);
                    }
                    /*var*/ let countPerLock = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [locks.length], null);
                    /*var*/ let buckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [capacity], null);
                    if (TKey.$type.IsValueType)
                    {
                        if (!(comparer === null) && $.$$.System.Object.ReferenceEquals(comparer, $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default))
                        {
                            comparer = null;
                        }
                    }
                    else 
                    {
                        comparer ??= $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                        let stringComparer;
                        if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is($.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer.GetStringComparer(comparer), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ stringComparer = v; } }))
                        {
                            comparer = $.$cast(stringComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                        }
                        else if ($.$$.System.Object.ReferenceEquals(comparer, $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default))
                        {
                            this._comparerIsDefaultForClasses = true;
                        }
                    }
                    this._tables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(buckets, locks, countPerLock, comparer);
                    this._growLockArray = growLockArray;
                    this._initialCapacity = capacity;
                    this._budget = $.trunc(buckets.length / locks.length);
                }
                return this;
            }
            /*AlternateLookup<TAlternateKey> */ GetAlternateLookup(TAlternateKey)
            {
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    $.$scc.System.ThrowHelper.ThrowIncompatibleComparer();
                }
                return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
            }
            /*bool */ TryGetAlternateLookup(TAlternateKey, /*out AlternateLookup<TAlternateKey>*/ lookup)
            {
                if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, this._tables))
                {
                    lookup.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))().$ctor$3(this);
                    return true;
                }
                lookup.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey))();
                return false;
            }
            static /*int */ GetCapacityFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                return (() =>
                {
                    {
                        let c;
                        if ((c = collection, $.$is(c, $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))))
                        {
                            return $.$$.System.Math.Max$4(31/*DefaultCapacity*/, c.System$Collections$Generic$ICollection$$$Count);
                        }
                    }
                    {
                        let rc;
                        if ((rc = collection, $.$is(rc, $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))))
                        {
                            return $.$$.System.Math.Max$4(31/*DefaultCapacity*/, rc.System$Collections$Generic$IReadOnlyCollection$$$Count);
                        }
                    }
                    return 31/*DefaultCapacity*/;
                })();
            }
            /*int */ GetHashCode$1(/*IEqualityComparer<TKey>?*/ comparer, /*TKey*/ key)
            {
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.System.Object.GetHashCodeT(TKey, key) : comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                return this._comparerIsDefaultForClasses ? $.$$.System.Object.GetHashCodeT(TKey, key) : comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]);
            }
            static /*bool */ NodeEqualsKey(/*IEqualityComparer<TKey>?*/ comparer, /*Node*/ node, /*TKey*/ key)
            {
                if (TKey.$type.IsValueType)
                {
                    return comparer === null ? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(node._key, key) : comparer.System$Collections$Generic$IEqualityComparer$$$Equals(node._key, key, [TKey]);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                return comparer.System$Collections$Generic$IEqualityComparer$$$Equals(node._key, key, [TKey]);
            }
            /*void */ InitializeFromCollection(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var pair = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (pair.Key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        if (!this.TryAddInternal(this._tables, pair.Key, null, pair.Value, false, false, $.$discardRef()))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_SourceContainsDuplicateKeys);
                        }
                    }
                }
                if (this._budget === 0)
                {
                    /*Tables*/ let tables = this._tables;
                    this._budget = $.trunc(tables._buckets.length / tables._locks.length);
                }
            }
            /*bool */ TryAdd(/*TKey*/ key, /*TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryAddInternal(this._tables, key, null, value, false, true, $.$discardRef());
            }
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                return this.TryGetValue(key, $.$discardRef());
            }
            /*bool */ TryRemove$1(/*TKey*/ key, /*out TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryRemoveInternal(key, value, false, $.$default(TValue));
            }
            /*bool */ TryRemove(/*KeyValuePair<TKey, TValue>*/ item)
            {
                if (item.Key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException("item", $.$scc.System.SR.ConcurrentDictionary_ItemKeyIsNull);
                }
                return this.TryRemoveInternal(item.Key, $.$discardRef(), true, item.Value);
            }
            /*bool */ TryRemoveInternal(/*TKey*/ key, /*out TValue*/ value, /*bool*/ matchValue, /*TValue?*/ oldValue)
            {
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                if (hashcode === curr._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, curr, key))
                                {
                                    if (matchValue)
                                    {
                                        /*bool*/ let valuesMatch = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(oldValue, curr._value);
                                        if (!valuesMatch)
                                        {
                                            value.$v = $.$default(TValue);
                                            return false;
                                        }
                                    }
                                    if (prev === null)
                                    {
                                        bucket.$v = curr._next;
                                    }
                                    else 
                                    {
                                        prev._next = curr._next;
                                    }
                                    value.$v = curr._value;
                                    (() =>
                                    {
                                        let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                        $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old - 1, lockNo);
                                        return $old;
                                    })();
                                    return true;
                                }
                                prev = curr;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                    value.$v = $.$default(TValue);
                    return false;
                }
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    /*int*/ let hashcode = $.$$.System.Object.GetHashCodeT(TKey, key);
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                    /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(n._key, key, [TKey]))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            static /*bool */ TryGetValueInternal(/*Tables*/ tables, /*TKey*/ key, /*int*/ hashcode, /*out TValue*/ value)
            {
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                if (TKey.$type.IsValueType && comparer === null)
                {
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(n._key, key))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                    for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                    {
                        if (hashcode === n._hashcode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(n._key, key, [TKey]))
                        {
                            value.$v = n._value;
                            return true;
                        }
                    }
                }
                value.$v = $.$default(TValue);
                return false;
            }
            /*bool */ TryUpdate(/*TKey*/ key, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                return this.TryUpdateInternal(this._tables, key, null, newValue, comparisonValue);
            }
            /*bool */ TryUpdateInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ newValue, /*TValue*/ comparisonValue)
            {
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.System.Diagnostics.Debug.Assert$2(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                /*EqualityComparer<TValue>*/ let valueComparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                        {
                            if (tables !== this._tables)
                            {
                                tables = this._tables;
                                if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                {
                                    comparer = tables._comparer;
                                    hashcode = this.GetHashCode$1(comparer, key);
                                }
                                continue;
                            }
                            /*Node?*/ let prev = null;
                            for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                if (hashcode === node._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                                {
                                    if (valueComparer.Equals$2(node._value, comparisonValue))
                                    {
                                        if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                        {
                                            node._value = newValue;
                                        }
                                        else 
                                        {
                                            /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, newValue, hashcode, node._next);
                                            if (prev === null)
                                            {
                                                bucket.$v = newNode;
                                            }
                                            else 
                                            {
                                                prev._next = newNode;
                                            }
                                        }
                                        return true;
                                    }
                                    return false;
                                }
                                prev = node;
                            }
                            return false;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                    }
                }
            }
            /*void */ Clear()
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    if (this.AreAllBucketsEmpty())
                    {
                        return;
                    }
                    /*Tables*/ let tables = this._tables;
                    /*var*/ let newTables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [$.$scc.System.Collections.HashHelpers.GetPrime(this._initialCapacity)], null), tables._locks, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [tables._countPerLock.length], null), tables._comparer);
                    this._tables = newTables;
                    this._budget = $.$$.System.Math.Max$4(1, $.trunc(newTables._buckets.length / newTables._locks.length));
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    this.CopyToPairs(array, index);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*KeyValuePair<TKey, TValue>[] */ ToArray()
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Array.Empty($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    /*var*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [count], null);
                    this.CopyToPairs(array, 0);
                    return array;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*void */ CopyToPairs(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            /*void */ CopyToEntries(/*DictionaryEntry[]*/ array, /*int*/ index)
            {
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(current._key, TKey), $.$box(current._value, TValue)), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            /*void */ CopyToObjects(/*object[]*/ array, /*int*/ index)
            {
                let $i1 = 0;
                let $arr1 = this._tables._buckets;
                while ($i1 < $arr1.length)
                {
                    let bucket = $arr1[$i1++];
                    for(/*Node?*/ let current = bucket._node; !(current === null); current = current._next)
                    {
                        $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(current._key, current._value), index);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 2147483647/*int.MaxValue*/, "This method should only be called when there's no overflow risk");
                        index++;
                    }
                }
            }
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ GetEnumerator()
            {
                return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Enumerator)().$ctor$1(this);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.Object
                {
                    /*ConcurrentDictionary<TKey, TValue>*/ _dictionary = null;
                    /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ _buckets = null;
                    /*Node?*/ _node = null;
                    /*int*/ _i = -1;
                    /*KeyValuePair<TKey, TValue>*/ Current;
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    /*void */ Reset()
                    {
                        this._buckets = null;
                        this._node = null;
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                        this._i = -1;
                    }
                    /*void */ Dispose()
                    {
                    }
                    /*bool */ MoveNext()
                    {
                        while(true)
                        {
                            let node;
                            if ($.$is(this._node, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node, { set $v(v){ node = v; } }))
                            {
                                this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(node._key, node._value);
                                this._node = node._next;
                                return true;
                            }
                            /*ConcurrentDictionary<TKey, TValue>.VolatileNode[]?*/ let buckets = this._buckets ??= this._dictionary._tables._buckets;
                            $.$$.System.Diagnostics.Debug.Assert$2(!(buckets === null), "buckets is not null");
                            /*int*/ let i = ((this._i + 1) | 0);
                            if ((i >>> 0) >= (buckets.length >>> 0))
                            {
                                return false;
                            }
                            this._node = $.$$.System.Array.$ReadT1.call(buckets, i)._node;
                            this._i = i;
                        }
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //Begin primary constructor
                    /*ConcurrentDictionary<TKey, TValue>*/ dictionary = null;
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/$dictionary)
                    {
                        this.dictionary = $dictionary;
                        //depends on primary constructor parameter
                        this._dictionary = this.dictionary;
                        return this
                    }
                    //End primary constructor
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Current = $.$default($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    static $h = 655366;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x900000000n),"f":83886082},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331650},"n":"{31850497}.Current","o":"System$Collections$IEnumerator$Current","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097154}],"m":[{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777217},{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"n":"_dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,"n":"_buckets","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h,"n":"_node","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"_i","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306}],"c":[{"p":[{"n":"dictionary","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217}],"i":[$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,57540609,31850497],"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            /*bool */ TryAddInternal(/*Tables*/ tables, /*TKey*/ key, /*int?*/ nullableHashcode, /*TValue*/ value, /*bool*/ updateIfExists, /*bool*/ acquireLock, /*out TValue*/ resultingValue)
            {
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = nullableHashcode ?? this.GetHashCode$1(comparer, key);
                $.$$.System.Diagnostics.Debug.Assert$2(nullableHashcode === null || nullableHashcode === hashcode, "nullableHashcode is null || nullableHashcode == hashcode");
                while(true)
                {
                    /*object[]*/ let locks = tables._locks;
                    /*uint*/ let lockNo;
                    /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                    /*bool*/ let resizeDesired = false;
                    /*bool*/ let forceRehash = false;
                    /*bool*/ let lockTaken = false;
                    try
                    {
                        if (acquireLock)
                        {
                            $.$$.System.Threading.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                        }
                        if (tables !== this._tables)
                        {
                            tables = this._tables;
                            if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                            {
                                comparer = tables._comparer;
                                hashcode = this.GetHashCode$1(comparer, key);
                            }
                            continue;
                        }
                        /*uint*/ let collisionCount = 0;
                        /*Node?*/ let prev = null;
                        for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                            if (hashcode === node._hashcode && $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).NodeEqualsKey(comparer, node, key))
                            {
                                if (updateIfExists)
                                {
                                    if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                    {
                                        node._value = value;
                                    }
                                    else 
                                    {
                                        /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                        if (prev === null)
                                        {
                                            bucket.$v = newNode;
                                        }
                                        else 
                                        {
                                            prev._next = newNode;
                                        }
                                    }
                                    resultingValue.$v = value;
                                }
                                else 
                                {
                                    resultingValue.$v = node._value;
                                }
                                return false;
                            }
                            prev = node;
                            if (!TKey.$type.IsValueType)
                            {
                                collisionCount++;
                            }
                        }
                        /*var*/ let resultNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(key, value, hashcode, bucket.$v);
                        bucket.$v = resultNode;
                        //checked
                        {
                            (() =>
                            {
                                let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old + 1, lockNo);
                                return $old;
                            })();
                        }
                        if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this._budget)
                        {
                            resizeDesired = true;
                        }
                        if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                        {
                            forceRehash = true;
                        }
                    }
                    finally
                    {
                        {
                            if (lockTaken)
                            {
                                $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                            }
                        }
                    }
                    if ($.$$.System.Boolean.op_BitwiseOr(resizeDesired, forceRehash))
                    {
                        this.GrowTable(tables, resizeDesired, forceRehash);
                    }
                    resultingValue.$v = value;
                    return true;
                }
            }
            /*TValue*/ get_Item(/*TKey*/ key)
            {
                /*TValue?*/ let value;
                if (!this.TryGetValue(key, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowKeyNotFoundException(key);
                }
                return value;
            }
            /*void*/ set_Item(/*TKey*/ key, /*TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                this.TryAddInternal(this._tables, key, null, value, true, true, $.$discardRef());
            }
            static /*void */ ThrowKeyNotFoundException(/*TKey*/ key)
            {
                throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$scc.System.SR.Format$6($.$scc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
            }
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                /*IEqualityComparer<TKey>?*/ let comparer = this._tables._comparer;
                if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type))
                {
                    let ec;
                    if ($.$is((($.$as(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))?.GetUnderlyingEqualityComparer() ?? null), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ ec = v; } }))
                    {
                        return $.$cast(ec, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    }
                }
                return comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
            }
            /*int */ get Count()
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    return this.GetCountNoLocks();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*int */ GetCountNoLocks()
            {
                /*int*/ let count = 0;
                let $i1 = 0;
                let $arr1 = this._tables._countPerLock;
                while ($i1 < $arr1.length)
                {
                    let value = $arr1[$i1++];
                    //checked
                    {
                        count += value;
                    }
                }
                return count;
            }
            /*TValue */ GetOrAdd(/*TKey*/ key, /*Func<TKey, TValue>*/ valueFactory)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            /*TValue */ GetOrAdd$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ valueFactory, /*TArg*/ factoryArgument)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (valueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("valueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, valueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            /*TValue */ GetOrAdd$1(/*TKey*/ key, /*TValue*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                /*TValue?*/ let resultingValue;
                if (!$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                {
                    this.TryAddInternal(tables, key, hashcode, value, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue));
                }
                return resultingValue;
            }
            /*TValue */ AddOrUpdate$2(TArg, /*TKey*/ key, /*Func<TKey, TArg, TValue>*/ addValueFactory, /*Func<TKey, TValue, TArg, TValue>*/ updateValueFactory, /*TArg*/ factoryArgument)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue, factoryArgument);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key, factoryArgument), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            /*TValue */ AddOrUpdate(/*TKey*/ key, /*Func<TKey, TValue>*/ addValueFactory, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (addValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("addValueFactory");
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValueFactory.Invoke(key), false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            /*TValue */ AddOrUpdate$1(/*TKey*/ key, /*TValue*/ addValue, /*Func<TKey, TValue, TValue>*/ updateValueFactory)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (updateValueFactory === null)
                {
                    $.$scc.System.ThrowHelper.ThrowArgumentNullException$1("updateValueFactory");
                }
                /*Tables*/ let tables = this._tables;
                /*IEqualityComparer<TKey>?*/ let comparer = tables._comparer;
                /*int*/ let hashcode = this.GetHashCode$1(comparer, key);
                while(true)
                {
                    /*TValue?*/ let oldValue;
                    if ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).TryGetValueInternal(tables, key, hashcode, $.$ref(() => oldValue, ($v) => oldValue = $v, TValue)))
                    {
                        /*TValue*/ let newValue = updateValueFactory.Invoke(key, oldValue);
                        if (this.TryUpdateInternal(tables, key, hashcode, newValue, oldValue))
                        {
                            return newValue;
                        }
                    }
                    else 
                    {
                        /*TValue*/ let resultingValue;
                        if (this.TryAddInternal(tables, key, hashcode, addValue, false, true, $.$ref(() => resultingValue, ($v) => resultingValue = $v, TValue)))
                        {
                            return resultingValue;
                        }
                    }
                    if (tables !== this._tables)
                    {
                        tables = this._tables;
                        if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                        {
                            comparer = tables._comparer;
                            hashcode = this.GetHashCode$1(comparer, key);
                        }
                    }
                }
            }
            /*bool */ get IsEmpty()
            {
                if (!this.AreAllBucketsEmpty())
                {
                    return false;
                }
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    return this.AreAllBucketsEmpty();
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*void */ System$Collections$Generic$IDictionary$$$$Add(/*TKey*/ key, /*TValue*/ value)
            {
                if (!this.TryAdd(key, value))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_KeyAlreadyExisted);
                }
            }
            /*bool */ System$Collections$Generic$IDictionary$$$$Remove(/*TKey*/ key)
            {
                return this.TryRemove$1(key, $.$discardRef());
            }
            /*ICollection<TKey> */ get Keys$1()
            {
                return this.GetKeys();
            }
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.GetKeys();
            }
            /*ICollection<TValue> */ get Values()
            {
                return this.GetValues();
            }
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.GetValues();
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                return (this).System$Collections$Generic$IDictionary$$$$Add(keyValuePair.Key, keyValuePair.Value, [TKey, TValue]);
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                /*TValue?*/ let value;
                return this.TryGetValue(keyValuePair.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, keyValuePair.Value);
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                return this.TryRemove(keyValuePair);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).GetEnumerator();
            }
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).System$Collections$Generic$IDictionary$$$$Add($.$cast(key, TKey), $.$cast(value, TValue), [TKey, TValue]);
            }
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                return $.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.ContainsKey(tkey);
            }
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DictionaryEnumerator)().$ctor$1(this);
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.GetKeys();
            }
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    this.TryRemove$1(tkey, $.$discardRef());
                }
            }
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.GetValues();
            }
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                let tkey;
                /*TValue?*/ let value;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.TryGetValue(tkey, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    return $.$box(value, TValue);
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                if (key === null)
                {
                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_TypeOfKeyIncorrect);
                }
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).ThrowIfInvalidObjectValue(value);
                (this).set_Item($.$cast(key, TKey), $.$cast(value, TValue));
            }
            static /*void */ ThrowIfInvalidObjectValue(/*object?*/ value)
            {
                if (!(value === null))
                {
                    if (!($.$is(value, TValue)))
                    {
                        $.$scc.System.ThrowHelper.ThrowValueNullException();
                    }
                }
                else if (!($.$default(TValue) === null))
                {
                    $.$scc.System.ThrowHelper.ThrowValueNullException();
                }
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (((array.length - count) | 0) < index)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scc.System.SR.ConcurrentDictionary_ArrayNotLargeEnough);
                    }
                    let pairs;
                    if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ pairs = v; } }))
                    {
                        this.CopyToPairs(pairs, index);
                        return;
                    }
                    let entries;
                    if ($.$is(array, $.$typeArray($.$$.System.Collections.DictionaryEntry), { set $v(v){ entries = v; } }))
                    {
                        this.CopyToEntries(entries, index);
                        return;
                    }
                    let objects;
                    if ($.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                    {
                        this.CopyToObjects(objects, index);
                        return;
                    }
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scc.System.SR.ConcurrentDictionary_ArrayIncorrectType, "array");
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$scc.System.SR.ConcurrentCollection_SyncRoot_NotSupported);
            }
            /*bool */ AreAllBucketsEmpty()
            {
                return !$.$$.System.MemoryExtensions.ContainsAnyExcept$8($.$$.System.Int32, $.$$.System.Span$$($.$$.System.Int32).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Int32, this._tables._countPerLock)), 0);
            }
            /*void */ GrowTable(/*Tables*/ tables, /*bool*/ resizeDesired, /*bool*/ forceRehashIfNonRandomized)
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireFirstLock($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    if (tables !== this._tables)
                    {
                        return;
                    }
                    /*int*/ let newLength = tables._buckets.length;
                    /*IEqualityComparer<TKey>?*/ let upgradeComparer = null;
                    let nrsec;
                    if (forceRehashIfNonRandomized && $.$is(tables._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer, { set $v(v){ nrsec = v; } }))
                    {
                        upgradeComparer = $.$cast(nrsec.GetUnderlyingEqualityComparer(), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    }
                    if (resizeDesired)
                    {
                        if (upgradeComparer === null && this.GetCountNoLocks() < $.trunc(tables._buckets.length / 4))
                        {
                            this._budget = ((2 * this._budget) | 0);
                            if (this._budget < 0)
                            {
                                this._budget = 2147483647/*int.MaxValue*/;
                            }
                            return;
                        }
                        if ((newLength = ((tables._buckets.length * 2) | 0)) < 0 || (newLength = $.$scc.System.Collections.HashHelpers.GetPrime(newLength)) > $.$$.System.Array.MaxLength)
                        {
                            newLength = $.$$.System.Array.MaxLength;
                            this._budget = 2147483647/*int.MaxValue*/;
                        }
                    }
                    /*object[]*/ let newLocks = tables._locks;
                    if (this._growLockArray && tables._locks.length < 1024/*MaxLockNumber*/)
                    {
                        newLocks = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((tables._locks.length * 2) | 0)], null);
                        $.$$.System.Array.Copy(tables._locks, newLocks, tables._locks.length);
                        for(/*int*/ let i = tables._locks.length; i < newLocks.length; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(newLocks, new $.$$.System.Object().$ctor(), i);
                        }
                    }
                    /*var*/ let newBuckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode), null, [newLength], null);
                    /*var*/ let newCountPerLock = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [newLocks.length], null);
                    /*var*/ let newTables = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables)().$ctor$1(newBuckets, newLocks, newCountPerLock, upgradeComparer ?? tables._comparer);
                    $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(tables, $.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    let $i3 = 0;
                    let $arr3 = tables._buckets;
                    while ($i3 < $arr3.length)
                    {
                        let bucket = $arr3[$i3++];
                        /*Node?*/ let current = bucket._node;
                        while(!(current === null))
                        {
                            /*int*/ let hashCode = upgradeComparer === null ? current._hashcode : upgradeComparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(current._key, [TKey]);
                            /*Node?*/ let next = current._next;
                            /*uint*/ let newLockNo;
                            /*ref Node?*/ let newBucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(newTables, hashCode, $.$ref(() => newLockNo, ($v) => newLockNo = $v, $.$$.System.UInt32));
                            newBucket.$v = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(current._key, current._value, hashCode, newBucket.$v);
                            //checked
                            {
                                (() =>
                                {
                                    let $old = $.$$.System.Array.$ReadT1.call(newCountPerLock, newLockNo);
                                    $.$$.System.Array.$WriteT1.call(newCountPerLock, $old + 1, newLockNo);
                                    return $old;
                                })();
                            }
                            current = next;
                        }
                    }
                    this._budget = $.$$.System.Math.Max$4(1, $.trunc(newBuckets.length / newLocks.length));
                    this._tables = newTables;
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            static /*int */ get DefaultConcurrencyLevel()
            {
                return $.$$.System.Environment.ProcessorCount;
            }
            /*void */ AcquireAllLocks(/*ref int*/ locksAcquired)
            {
                if ($.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.IsEnabled())
                {
                    $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider.Log.ConcurrentDictionary_AcquiringAllLocks(this._tables._buckets.length);
                }
                this.AcquireFirstLock(locksAcquired);
                $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AcquirePostFirstLock(this._tables, locksAcquired);
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === this._tables._locks.length, "locksAcquired == _tables._locks.Length");
            }
            /*void */ AcquireFirstLock(/*ref int*/ locksAcquired)
            {
                /*object[]*/ let locks = this._tables._locks;
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === 0, "locksAcquired == 0");
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.Threading.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "!Monitor.IsEntered(locks[0])");
                $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, 0));
                locksAcquired.$v = 1;
            }
            static /*void */ AcquirePostFirstLock(/*Tables*/ tables, /*ref int*/ locksAcquired)
            {
                /*object[]*/ let locks = tables._locks;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Threading.Monitor.IsEntered($.$$.System.Array.$ReadT1.call(locks, 0)), "Monitor.IsEntered(locks[0])");
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === 1, "locksAcquired == 1");
                for(/*int*/ let i = 1; i < locks.length; i++)
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, i));
                    locksAcquired.$v++;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired.$v === locks.length, "locksAcquired == locks.Length");
            }
            /*void */ ReleaseLocks(/*int*/ locksAcquired)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(locksAcquired >= 0, "locksAcquired >= 0");
                /*object[]*/ let locks = this._tables._locks;
                for(/*int*/ let i = 0; i < locksAcquired; i++)
                {
                    $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, i));
                }
            }
            /*ReadOnlyCollection<TKey> */ GetKeys()
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey).Empty;
                    }
                    /*var*/ let keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [count], null);
                    /*int*/ let i = 0;
                    let $i2 = 0;
                    let $arr2 = this._tables._buckets;
                    while ($i2 < $arr2.length)
                    {
                        let bucket = $arr2[$i2++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._key, i);
                            i++;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(i === count, "i == count");
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            /*ReadOnlyCollection<TValue> */ GetValues()
            {
                /*int*/ let locksAcquired = 0;
                try
                {
                    this.AcquireAllLocks($.$ref(() => locksAcquired, ($v) => locksAcquired = $v, $.$$.System.Int32));
                    /*int*/ let count = this.GetCountNoLocks();
                    if (count === 0)
                    {
                        return $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue).Empty;
                    }
                    /*var*/ let keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [count], null);
                    /*int*/ let i = 0;
                    let $i2 = 0;
                    let $arr2 = this._tables._buckets;
                    while ($i2 < $arr2.length)
                    {
                        let bucket = $arr2[$i2++];
                        for(/*Node?*/ let node = bucket._node; !(node === null); node = node._next)
                        {
                            $.$$.System.Array.$WriteT1.call(keys, node._value, i);
                            i++;
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(i === count, "i == count");
                    return new ($.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue))().$ctor$1(keys);
                }
                finally
                {
                    {
                        this.ReleaseLocks(locksAcquired);
                    }
                }
            }
            static $_VolatileNode;
            static get VolatileNode()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_VolatileNode ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.VolatileNode", ($self) => class VolatileNode extends $.$$.System.ValueType
                {
                    /*Node?*/  get _node() { return this.$getField(0, 4); }
                    /*Node?*/  set _node(value) { this.$setField(0, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._node = this._node;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._node = null;
                    }
                    static $h = 851974;
                    static $z = 4;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h,"n":"_node","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.VolatileNode`; }
                }, $cls, ($v) => $cls.$_VolatileNode = $v);
            }
            static $_Node;
            static get Node()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Node ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    /*TKey*/ _key = $.$default(TKey);
                    /*TValue*/ _value = $.$default(TValue);
                    /*Node?*/ _next = null;
                    /*int*/ _hashcode = 0;
                    $ctor$1(/*TKey*/ key, /*TValue*/ value, /*int*/ hashcode, /*Node?*/ next)
                    {
                        super.$ctor();
                        {
                            this._key = key;
                            this._value = value;
                            this._next = next;
                            this._hashcode = hashcode;
                        }
                        return this;
                    }
                    static $h = 720902;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":TKey?.$h??1507328,"n":"_key","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194312},{"t":TValue?.$h??1572864,"n":"_value","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194312},{"t":this.$h,"n":"_next","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194312},{"t":655361,"n":"_hashcode","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194312}],"c":[{"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864},{"n":"hashcode","p":655361},{"n":"next","p":this.$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777224}],"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            static /*Node? */ GetBucket(/*Tables*/ tables, /*int*/ hashcode)
            {
                /*VolatileNode[]*/ let buckets = tables._buckets;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    return $.$$.System.Array.$ReadT1.call(buckets, (hashcode >>> 0) % (buckets.length >>> 0))._node;
                }
            }
            static /*ref Node? */ GetBucketAndLock(/*Tables*/ tables, /*int*/ hashcode, /*out uint*/ lockNo)
            {
                /*VolatileNode[]*/ let buckets = tables._buckets;
                /*uint*/ let bucketNo;
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    bucketNo = (hashcode >>> 0) % (buckets.length >>> 0);
                }
                lockNo.$v = bucketNo % (tables._locks.length >>> 0);
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node, () => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node, ($v) => $.$$.System.Array.$ReadT1.call(buckets, bucketNo)._node = $v, null);
            }
            static $_Tables;
            static get Tables()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_Tables ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.Tables", ($self) => class Tables extends $.$$.System.Object
                {
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    /*VolatileNode[]*/ _buckets = null;
                    /*ulong*/ _fastModBucketsMultiplier = 0n;
                    /*object[]*/ _locks = null;
                    /*int[]*/ _countPerLock = null;
                    $ctor$1(/*VolatileNode[]*/ buckets, /*object[]*/ locks, /*int[]*/ countPerLock, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(TKey.$type.IsValueType || !(comparer === null), "typeof(TKey).IsValueType || comparer is not null");
                            this._buckets = buckets;
                            this._locks = locks;
                            this._countPerLock = countPerLock;
                            this._comparer = comparer;
                            //if (IntPtr.Size == 8) { ... }
                        }
                        return this;
                    }
                    static $h = 786438;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"n":"_comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194312},{"t":$.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h,"n":"_buckets","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194312},{"t":983041,"n":"_fastModBucketsMultiplier","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194312},{"t":$.$typeArray($.$$.System.Object).$h,"n":"_locks","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194312},{"t":$.$typeArray($.$$.System.Int32).$h,"n":"_countPerLock","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194312}],"c":[{"p":[{"n":"buckets","p":$.$typeArray($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode).$h},{"n":"locks","p":$.$typeArray($.$$.System.Object).$h},{"n":"countPerLock","p":$.$typeArray($.$$.System.Int32).$h},{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777224}],"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Tables`; }
                }, $cls, ($v) => $cls.$_Tables = $v);
            }
            static $_DictionaryEnumerator;
            static get DictionaryEnumerator()
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return $cls.$_DictionaryEnumerator ??= $asm.$ncls("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.DictionaryEnumerator", ($self) => class DictionaryEnumerator extends $.$$.System.Object
                {
                    /*IEnumerator<KeyValuePair<TKey, TValue>>*/ _enumerator = null;
                    $ctor$1(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        this._enumerator = dictionary.GetEnumerator();
                        return this;
                    }
                    /*DictionaryEntry */ get Entry()
                    {
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, TKey), $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value, TValue));
                    }
                    /*object */ get Key()
                    {
                        return $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Key, TKey);
                    }
                    /*object? */ get Value()
                    {
                        return $.$box(this._enumerator.System$Collections$Generic$IEnumerator$$$Current.Value, TValue);
                    }
                    /*object */ get Current()
                    {
                        return this.Entry;
                    }
                    /*bool */ MoveNext()
                    {
                        return this._enumerator.System$Collections$IEnumerator$MoveNext();
                    }
                    /*void */ Reset()
                    {
                        return this._enumerator.System$Collections$IEnumerator$Reset();
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return this.Key;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return this.Value;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return this.Entry;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 589830;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":25821185,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Entry","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"Key","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,"n":"_enumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"dictionary","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777224}],"i":[31653889,31850497],"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.DictionaryEnumerator`; }
                }, $cls, ($v) => $cls.$_DictionaryEnumerator = $v);
            }
            static /*bool */ IsCompatibleKey(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(tables === null), "tables is not null");
                return $.$is(tables._comparer, $.$$.System.Collections.Generic.IAlternateEqualityComparer$$$(TAlternateKey, TKey));
            }
            static /*IAlternateEqualityComparer<TAlternateKey, TKey> */ GetAlternateComparer(TAlternateKey, /*ConcurrentDictionary<TKey, TValue>.Tables*/ tables)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, tables), "IsCompatibleKey<TAlternateKey>(tables)");
                return tables._comparer;
            }
            static $_AlternateLookup$$;
            static AlternateLookup$$(TAlternateKey)
            {
                let $cls = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue);
                return ($cls.$_AlternateLookup$$ ??= $asm.$nstr("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.AlternateLookup<>", (TAlternateKey) => $asm.$gt("$scc.System.Collections.Concurrent.ConcurrentDictionary$$$.AlternateLookup<>", [TAlternateKey], ($self) => class AlternateLookup$$ extends $.$$.System.ValueType
                {
                    $ctor$3(/*ConcurrentDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor$1();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(dictionary === null), "dictionary is not null");
                            $.$$.System.Diagnostics.Debug.Assert$2($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).IsCompatibleKey(TAlternateKey, dictionary._tables), "IsCompatibleKey<TAlternateKey>(dictionary._tables)");
                            this.Dictionary = dictionary;
                        }
                        return this;
                    }
                    /*ConcurrentDictionary<TKey, TValue>*/ Dictionary = null;
                    /*TValue*/ get_Item(/*TAlternateKey*/ key)
                    {
                        /*TValue?*/ let value;
                        return this.TryGetValue$1(key, $.$ref(() => value, ($v) => value = $v, TValue)) ? value : (() =>
                        {
        throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$9()                })();
                    }
                    /*void*/ set_Item(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        this.TryAdd(key, value, true, $.$discardRef());
                    }
                    /*bool */ ContainsKey(/*TAlternateKey*/ key)
                    {
                        return this.TryGetValue$1(key, $.$discardRef());
                    }
                    /*bool */ TryAdd$1(/*TAlternateKey*/ key, /*TValue*/ value)
                    {
                        return this.TryAdd(key, value, false, $.$discardRef());
                    }
                    /*bool */ TryAdd(/*TAlternateKey*/ key, /*TValue*/ value, /*bool*/ updateIfExists, /*out TValue*/ resultingValue)
                    {
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        while(true)
                        {
                            /*object[]*/ let locks = tables._locks;
                            /*uint*/ let lockNo;
                            /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                            /*bool*/ let resizeDesired = false;
                            /*bool*/ let forceRehash = false;
                            /*bool*/ let lockTaken = false;
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter($.$$.System.Array.$ReadT1.call(locks, lockNo), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Boolean, () => lockTaken, ($v) => lockTaken = $v, null));
                                if (tables !== this.Dictionary._tables)
                                {
                                    tables = this.Dictionary._tables;
                                    if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                    {
                                        comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                        hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                                    }
                                    continue;
                                }
                                /*uint*/ let collisionCount = 0;
                                /*Node?*/ let prev = null;
                                for(/*Node?*/ let node = bucket.$v; !(node === null); node = node._next)
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2((prev === null && node === bucket.$v) || prev._next === node, "(prev is null && node == bucket) || prev!._next == node");
                                    if (hashcode === node._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, node._key, [TAlternateKey, TKey]))
                                    {
                                        if (updateIfExists)
                                        {
                                            if (!TValue.$type.IsValueType || $.$scc.System.Collections.Concurrent.ConcurrentDictionaryTypeProps$$(TValue).IsWriteAtomic)
                                            {
                                                node._value = value;
                                            }
                                            else 
                                            {
                                                /*var*/ let newNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(node._key, value, hashcode, node._next);
                                                if (prev === null)
                                                {
                                                    bucket.$v = newNode;
                                                }
                                                else 
                                                {
                                                    prev._next = newNode;
                                                }
                                            }
                                            resultingValue.$v = value;
                                        }
                                        else 
                                        {
                                            resultingValue.$v = node._value;
                                        }
                                        return false;
                                    }
                                    prev = node;
                                    if (!TKey.$type.IsValueType)
                                    {
                                        collisionCount++;
                                    }
                                }
                                /*TKey*/ let actualKey = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Create(key, [TAlternateKey, TKey]);
                                if (actualKey === null)
                                {
                                    $.$scc.System.ThrowHelper.ThrowKeyNullException();
                                }
                                /*var*/ let resultNode = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node)().$ctor$1(actualKey, value, hashcode, bucket.$v);
                                bucket.$v = resultNode;
                                //checked
                                {
                                    (() =>
                                    {
                                        let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                        $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old + 1, lockNo);
                                        return $old;
                                    })();
                                }
                                if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) > this.Dictionary._budget)
                                {
                                    resizeDesired = true;
                                }
                                if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                                {
                                    forceRehash = true;
                                }
                            }
                            finally
                            {
                                {
                                    if (lockTaken)
                                    {
                                        $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo));
                                    }
                                }
                            }
                            if ($.$$.System.Boolean.op_BitwiseOr(resizeDesired, forceRehash))
                            {
                                this.Dictionary.GrowTable(tables, resizeDesired, forceRehash);
                            }
                            resultingValue.$v = value;
                            return true;
                        }
                    }
                    /*bool */ TryGetValue$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        return this.TryGetValue(key, $.$discardRef(), value);
                    }
                    /*bool */ TryGetValue(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        for(/*Node?*/ let n = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucket(tables, hashcode); !(n === null); n = n._next)
                        {
                            if (hashcode === n._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, n._key, [TAlternateKey, TKey]))
                            {
                                actualKey.$v = n._key;
                                value.$v = n._value;
                                return true;
                            }
                        }
                        actualKey.$v = $.$default(TKey);
                        value.$v = $.$default(TValue);
                        return false;
                    }
                    /*bool */ TryRemove$1(/*TAlternateKey*/ key, /*out TValue*/ value)
                    {
                        return this.TryRemove(key, $.$discardRef(), value);
                    }
                    /*bool */ TryRemove(/*TAlternateKey*/ key, /*out TKey*/ actualKey, /*out TValue*/ value)
                    {
                        if (key === null)
                        {
                            $.$scc.System.ThrowHelper.ThrowKeyNullException();
                        }
                        /*Tables*/ let tables = this.Dictionary._tables;
                        /*IAlternateEqualityComparer<TAlternateKey, TKey>*/ let comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                        /*int*/ let hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                        while(true)
                        {
                            /*object[]*/ let locks = tables._locks;
                            /*uint*/ let lockNo;
                            /*ref Node?*/ let bucket = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetBucketAndLock(tables, hashcode, $.$ref(() => lockNo, ($v) => lockNo = $v, $.$$.System.UInt32));
                            if ($.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo) !== 0)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                    {
                                        if (tables !== this.Dictionary._tables)
                                        {
                                            tables = this.Dictionary._tables;
                                            if (!$.$$.System.Object.ReferenceEquals(comparer, tables._comparer))
                                            {
                                                comparer = $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).GetAlternateComparer(TAlternateKey, tables);
                                                hashcode = comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$GetHashCode(key, [TAlternateKey, TKey]);
                                            }
                                            continue;
                                        }
                                        /*Node?*/ let prev = null;
                                        for(/*Node?*/ let curr = bucket.$v; !(curr === null); curr = curr._next)
                                        {
                                            $.$$.System.Diagnostics.Debug.Assert$2((prev === null && curr === bucket.$v) || prev._next === curr, "(prev is null && curr == bucket) || prev!._next == curr");
                                            if (hashcode === curr._hashcode && comparer.System$Collections$Generic$IAlternateEqualityComparer$$$$Equals(key, curr._key, [TAlternateKey, TKey]))
                                            {
                                                if (prev === null)
                                                {
                                                    bucket.$v = curr._next;
                                                }
                                                else 
                                                {
                                                    prev._next = curr._next;
                                                }
                                                actualKey.$v = curr._key;
                                                value.$v = curr._value;
                                                (() =>
                                                {
                                                    let $old = $.$$.System.Array.$ReadT1.call(tables._countPerLock, lockNo);
                                                    $.$$.System.Array.$WriteT1.call(tables._countPerLock, $old - 1, lockNo);
                                                    return $old;
                                                })();
                                                return true;
                                            }
                                            prev = curr;
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit($.$$.System.Array.$ReadT1.call(locks, lockNo))
                                }
                            }
                            actualKey.$v = $.$default(TKey);
                            value.$v = $.$default(TValue);
                            return false;
                        }
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Dictionary = this.Dictionary;
                        return copy;
                    }
                    static $h = 524294;
                    static $g = 1;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Dictionary","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153},{"p":TValue?.$h??1572864,"i":[{"n":"key","p":TAlternateKey?.$h??1507328}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":83886081},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"m":[{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328}],"n":"ContainsKey","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864}],"n":"TryAdd","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864},{"n":"updateIfExists","p":262145},{"n":"resultingValue","p":TValue?.$h??1572864,"f":2}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777218},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryGetValue","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"actualKey","p":TKey?.$h??1507328,"f":2},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryRemove","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TAlternateKey?.$h??1507328},{"n":"actualKey","p":TKey?.$h??1507328,"f":2},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryRemove","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217}],"c":[{"p":[{"n":"dictionary","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217}],"g":[TAlternateKey?.$h??1507328],"s":[{"n":"TAlternateKey","f":64}],"r":1,"d":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>.AlternateLookup<${TAlternateKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_AlternateLookup$$ = $v))(TAlternateKey);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Keys.get
            get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Values.get
            get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey, TValue>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 458758;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":TValue?.$h??1572864,"i":[{"n":"key","p":TKey?.$h??1507328}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2900000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2A00000000n),"f":83886081},"n":"Item","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x2800000000n),"f":2097153},{"p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":50331649},"n":"Comparer","d":this.$h,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":50331649},"n":"Count","d":this.$h,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3800000000n),"f":50331649},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":2097153},{"p":$.$$.System.Collections.Generic.ICollection$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":50331649},"n":"Keys","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$(TKey).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":50331650},"n":"{$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h}.Keys","o":"System$Collections$Generic$IReadOnlyDictionary$$$$Keys","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":2097154},{"p":$.$$.System.Collections.Generic.ICollection$$(TValue).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x4000000000n),"f":50331649},"n":"Values","d":this.$h,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":2097153},{"p":$.$$.System.Collections.Generic.IEnumerable$$(TValue).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x4200000000n),"f":50331650},"n":"{$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h}.Values","o":"System$Collections$Generic$IReadOnlyDictionary$$$$Values","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x4600000000n),"f":50331650},"n":"{$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h}.IsReadOnly","o":"System$Collections$Generic$ICollection$$$IsReadOnly","d":this.$h,"h":Number(BigInt(this.$h)|0x4500000000n),"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x4D00000000n),"f":50331650},"n":"{31588353}.IsFixedSize","o":"System$Collections$IDictionary$IsFixedSize","d":this.$h,"h":Number(BigInt(this.$h)|0x4C00000000n),"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x4F00000000n),"f":50331650},"n":"{31588353}.IsReadOnly","o":"System$Collections$IDictionary$IsReadOnly","d":this.$h,"h":Number(BigInt(this.$h)|0x4E00000000n),"f":2097154},{"p":31457281,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5100000000n),"f":50331650},"n":"{31588353}.Keys","o":"System$Collections$IDictionary$Keys","d":this.$h,"h":Number(BigInt(this.$h)|0x5000000000n),"f":2097154},{"p":31457281,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5400000000n),"f":50331650},"n":"{31588353}.Values","o":"System$Collections$IDictionary$Values","d":this.$h,"h":Number(BigInt(this.$h)|0x5300000000n),"f":2097154},{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5600000000n),"f":50331650},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5700000000n),"f":83886082},"n":"{31588353}.this[]","o":"System$Collections$IDictionary$Item","d":this.$h,"h":Number(BigInt(this.$h)|0x5500000000n),"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5B00000000n),"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":this.$h,"h":Number(BigInt(this.$h)|0x5A00000000n),"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x5D00000000n),"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":this.$h,"h":Number(BigInt(this.$h)|0x5C00000000n),"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x6100000000n),"f":50331682},"n":"DefaultConcurrencyLevel","d":this.$h,"h":Number(BigInt(this.$h)|0x6000000000n),"f":2097186}],"m":[{"r":(TAlternateKey) => $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,"g":["TAlternateKey"],"n":"GetAlternateLookup","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16908289},{"r":262145,"p":[{"n":"lookup","p":(TAlternateKey) => $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).AlternateLookup$$(TAlternateKey).$h,"f":2}],"g":["TAlternateKey"],"n":"TryGetAlternateLookup","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16908289},{"r":655361,"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h}],"n":"GetCapacityFromCollection","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777250},{"r":655361,"p":[{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h},{"n":"key","p":TKey?.$h??1507328}],"n":"GetHashCode","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777218},{"r":262145,"p":[{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h},{"n":"node","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h},{"n":"key","p":TKey?.$h??1507328}],"n":"NodeEqualsKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777250},{"r":65537,"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h}],"n":"InitializeFromCollection","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777218},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864}],"n":"TryAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"ContainsKey","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryRemove","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217},{"r":262145,"p":[{"n":"item","p":$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h}],"n":"TryRemove","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777217},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864,"f":2},{"n":"matchValue","p":262145},{"n":"oldValue","p":TValue?.$h??1572864}],"n":"TryRemoveInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777218},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryGetValue","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777217},{"r":262145,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"key","p":TKey?.$h??1507328},{"n":"hashcode","p":655361},{"n":"value","p":TValue?.$h??1572864,"f":2}],"n":"TryGetValueInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":16777250},{"r":262145,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"newValue","p":TValue?.$h??1572864},{"n":"comparisonValue","p":TValue?.$h??1572864}],"n":"TryUpdate","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":16777217},{"r":262145,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"key","p":TKey?.$h??1507328},{"n":"nullableHashcode","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"newValue","p":TValue?.$h??1572864},{"n":"comparisonValue","p":TValue?.$h??1572864}],"n":"TryUpdateInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":16777218},{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":16777217},{"r":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,"n":"ToArray","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h},{"n":"index","p":655361}],"n":"CopyToPairs","d":this.$h,"h":Number(BigInt(this.$h)|0x2200000000n),"f":16777218},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.Collections.DictionaryEntry).$h},{"n":"index","p":655361}],"n":"CopyToEntries","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":16777218},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.Object).$h},{"n":"index","p":655361}],"n":"CopyToObjects","d":this.$h,"h":Number(BigInt(this.$h)|0x2400000000n),"f":16777218},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x2500000000n),"f":16777217},{"r":262145,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"key","p":TKey?.$h??1507328},{"n":"nullableHashcode","p":$.$typeNullable($.$$.System.Int32).$h},{"n":"value","p":TValue?.$h??1572864},{"n":"updateIfExists","p":262145},{"n":"acquireLock","p":262145},{"n":"resultingValue","p":TValue?.$h??1572864,"f":2}],"n":"TryAddInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x2700000000n),"f":16777218},{"r":65537,"p":[{"n":"key","p":TKey?.$h??1507328}],"n":"ThrowKeyNotFoundException","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":16777250},{"r":655361,"n":"GetCountNoLocks","d":this.$h,"h":Number(BigInt(this.$h)|0x3000000000n),"f":16777218},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"valueFactory","p":$.$$.System.Func$$$(TKey, TValue).$h}],"n":"GetOrAdd","d":this.$h,"h":Number(BigInt(this.$h)|0x3100000000n),"f":16777217},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"valueFactory","p":(TArg) => $.$$.System.Func$$$$(TKey, TArg, TValue).$h},{"n":"factoryArgument","p":(TArg) => TArg.$h}],"g":["TArg"],"n":"GetOrAdd","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3200000000n),"f":16908289},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864}],"n":"GetOrAdd","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3300000000n),"f":16777217},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"addValueFactory","p":(TArg) => $.$$.System.Func$$$$(TKey, TArg, TValue).$h},{"n":"updateValueFactory","p":(TArg) => $.$$.System.Func$$$$$(TKey, TValue, TArg, TValue).$h},{"n":"factoryArgument","p":(TArg) => TArg.$h}],"g":["TArg"],"n":"AddOrUpdate","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3400000000n),"f":16908289},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"addValueFactory","p":$.$$.System.Func$$$(TKey, TValue).$h},{"n":"updateValueFactory","p":$.$$.System.Func$$$$(TKey, TValue, TValue).$h}],"n":"AddOrUpdate","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":16777217},{"r":TValue?.$h??1572864,"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"addValue","p":TValue?.$h??1572864},{"n":"updateValueFactory","p":$.$$.System.Func$$$$(TKey, TValue, TValue).$h}],"n":"AddOrUpdate","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3600000000n),"f":16777217},{"r":65537,"p":[{"n":"value","p":131073}],"n":"ThrowIfInvalidObjectValue","d":this.$h,"h":Number(BigInt(this.$h)|0x5800000000n),"f":16777250},{"r":262145,"n":"AreAllBucketsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x5E00000000n),"f":16777218},{"r":65537,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"resizeDesired","p":262145},{"n":"forceRehashIfNonRandomized","p":262145}],"n":"GrowTable","d":this.$h,"h":Number(BigInt(this.$h)|0x5F00000000n),"f":16777218},{"r":65537,"p":[{"n":"locksAcquired","p":655361,"f":4}],"n":"AcquireAllLocks","d":this.$h,"h":Number(BigInt(this.$h)|0x6200000000n),"f":16777218},{"r":65537,"p":[{"n":"locksAcquired","p":655361,"f":4}],"n":"AcquireFirstLock","d":this.$h,"h":Number(BigInt(this.$h)|0x6300000000n),"f":16777218},{"r":65537,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"locksAcquired","p":655361,"f":4}],"n":"AcquirePostFirstLock","d":this.$h,"h":Number(BigInt(this.$h)|0x6400000000n),"f":16777250},{"r":65537,"p":[{"n":"locksAcquired","p":655361}],"n":"ReleaseLocks","d":this.$h,"h":Number(BigInt(this.$h)|0x6500000000n),"f":16777218},{"r":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TKey).$h,"n":"GetKeys","d":this.$h,"h":Number(BigInt(this.$h)|0x6600000000n),"f":16777218},{"r":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$(TValue).$h,"n":"GetValues","d":this.$h,"h":Number(BigInt(this.$h)|0x6700000000n),"f":16777218},{"r":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"hashcode","p":655361}],"n":"GetBucket","d":this.$h,"h":Number(BigInt(this.$h)|0x6A00000000n),"f":16777250},{"r":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h},{"n":"hashcode","p":655361},{"n":"lockNo","p":720897,"f":2}],"n":"GetBucketAndLock","d":this.$h,"h":Number(BigInt(this.$h)|0x6B00000000n),"f":16777250},{"r":262145,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h}],"g":["TAlternateKey"],"n":"IsCompatibleKey","d":this.$h,"h":Number(BigInt(this.$h)|0x6E00000000n),"f":16908322},{"r":(TAlternateKey) => $.$$.System.Collections.Generic.IAlternateEqualityComparer$$$(TAlternateKey, TKey).$h,"p":[{"n":"tables","p":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h}],"g":["TAlternateKey"],"n":"GetAlternateComparer","d":this.$h,"h":Number(BigInt(this.$h)|0x6F00000000n),"f":16908322}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h,"n":"_tables","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":655361,"n":"_budget","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":262145,"n":"_growLockArray","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":262145,"n":"_comparerIsDefaultForClasses","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306},{"t":655361,"n":"_initialCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":4194306},{"t":655361,"n":"DefaultCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":4194338},{"t":655361,"n":"MaxLockNumber","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"p":[{"n":"concurrencyLevel","p":655361},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$8","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777217},{"p":[{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217},{"p":[{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h},{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777217},{"p":[{"n":"concurrencyLevel","p":655361},{"n":"collection","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h},{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777217},{"p":[{"n":"concurrencyLevel","p":655361},{"n":"capacity","p":655361},{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$7","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777217},{"p":[{"n":"concurrencyLevel","p":655361},{"n":"capacity","p":655361},{"n":"growLockArray","p":262145},{"n":"comparer","p":$.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777224}],"i":[$.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,31588353,31457281,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).$h,31719425],"g":[TKey?.$h??1507328,TValue?.$h??1572864],"s":[{"n":"TKey","f":64},null],"j":[$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Enumerator.$h,$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).VolatileNode.$h,$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Node.$h,$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).Tables.$h,$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TKey, TValue).DictionaryEnumerator.$h,524294],"r":2,"h":this.$h,"a":[{"t":37945345,"c":8627879937,"a":[{"v":$.$scc.System.Collections.Concurrent.IDictionaryDebugView$$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Count}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Concurrent.ConcurrentDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider", ($self) => class CDSCollectionETWBCLProvider extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            /*CDSCollectionETWBCLProvider*/ static Log = null;
            $ctor$10()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*EventKeywords*/ static ALL_KEYWORDS = -1n;
            /*int*/ static CONCURRENTSTACK_FASTPUSHFAILED_ID = 1;
            /*int*/ static CONCURRENTSTACK_FASTPOPFAILED_ID = 2;
            /*int*/ static CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID = 3;
            /*int*/ static CONCURRENTBAG_TRYTAKESTEALS_ID = 4;
            /*int*/ static CONCURRENTBAG_TRYPEEKSTEALS_ID = 5;
            /*void */ ConcurrentStack_FastPushFailed(/*int*/ spinCount)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(1/*CONCURRENTSTACK_FASTPUSHFAILED_ID*/, spinCount);
                }
            }
            /*void */ ConcurrentStack_FastPopFailed(/*int*/ spinCount)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(2/*CONCURRENTSTACK_FASTPOPFAILED_ID*/, spinCount);
                }
            }
            /*void */ ConcurrentDictionary_AcquiringAllLocks(/*int*/ numOfBuckets)
            {
                if (this.IsEnabled$2(3/*EventLevel.Warning*/, -1n))
                {
                    this.WriteEvent$5(3/*CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID*/, numOfBuckets);
                }
            }
            /*void */ ConcurrentBag_TryTakeSteals()
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(4/*CONCURRENTBAG_TRYTAKESTEALS_ID*/);
                }
            }
            /*void */ ConcurrentBag_TryPeekSteals()
            {
                if (this.IsEnabled$2(5/*EventLevel.Verbose*/, -1n))
                {
                    this.WriteEvent$18(5/*CONCURRENTBAG_TRYPEEKSTEALS_ID*/);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$scc.System.Collections.Concurrent.CDSCollectionETWBCLProvider().$ctor$10();
                }
            }
            static $h = 196614;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":65537,"p":[{"n":"spinCount","p":655361}],"n":"ConcurrentStack_FastPushFailed","d":196614,"h":38654902278,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Level","v":3,"t":40960001}]}]},{"r":65537,"p":[{"n":"spinCount","p":655361}],"n":"ConcurrentStack_FastPopFailed","d":196614,"h":42949869574,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Level","v":3,"t":40960001}]}]},{"r":65537,"p":[{"n":"numOfBuckets","p":655361}],"n":"ConcurrentDictionary_AcquiringAllLocks","d":196614,"h":47244836870,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":3,"t":655361}],"n":[{"n":"Level","v":3,"t":40960001}]}]},{"r":65537,"n":"ConcurrentBag_TryTakeSteals","d":196614,"h":51539804166,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":4,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001}]}]},{"r":65537,"n":"ConcurrentBag_TryPeekSteals","d":196614,"h":55834771462,"f":16777217,"a":[{"t":39976961,"c":4334944257,"a":[{"v":5,"t":655361}],"n":[{"n":"Level","v":5,"t":40960001}]}]}],"l":[{"t":196614,"n":"Log","d":196614,"h":4295163910,"f":4194337},{"t":40894465,"n":"ALL_KEYWORDS","d":196614,"h":12885098502,"f":4194338},{"t":655361,"n":"CONCURRENTSTACK_FASTPUSHFAILED_ID","d":196614,"h":17180065798,"f":4194338},{"t":655361,"n":"CONCURRENTSTACK_FASTPOPFAILED_ID","d":196614,"h":21475033094,"f":4194338},{"t":655361,"n":"CONCURRENTDICTIONARY_ACQUIRINGALLLOCKS_ID","d":196614,"h":25770000390,"f":4194338},{"t":655361,"n":"CONCURRENTBAG_TRYTAKESTEALS_ID","d":196614,"h":30064967686,"f":4194338},{"t":655361,"n":"CONCURRENTBAG_TRYPEEKSTEALS_ID","d":196614,"h":34359934982,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$10","d":196614,"h":8590131206,"f":16777218}],"i":[57540609],"h":196614,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"System.Collections.Concurrent.ConcurrentCollectionsEventSource","t":1310721},{"n":"Guid","v":"35167F8E-49B2-4b96-AB86-435B59336B5E","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Collections.Concurrent.CDSCollectionETWBCLProvider`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading"))