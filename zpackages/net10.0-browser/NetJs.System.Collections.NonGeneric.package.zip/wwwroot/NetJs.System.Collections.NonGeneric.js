
//--TRIMMABLE-BOUNDARY-START(16)
(function ($global, $, $$, $sm, $spu, $sr, $st) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.NonGeneric", 
    {
  "h": 16,
  "f": "System.Collections.NonGeneric",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Collections.NonGeneric",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Collections.NonGeneric",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(655376)
        $asm.$cls("$scn.System.Collections.ReadOnlyCollectionBase", ($self) => class ReadOnlyCollectionBase extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(38655361040)
            /*ArrayList*/ InnerList$ = null;
            /*ArrayList */ get InnerList()
            {
                return this.InnerList$ ??= new $.$$.System.Collections.ArrayList().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(38655361040)
            
            //--TRIMMABLE-BOUNDARY-START(12885557264)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557264)
            
            //--TRIMMABLE-BOUNDARY-START(64425164816)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540262928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(64425164816)
            
            //--TRIMMABLE-BOUNDARY-START(68720132112)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130197520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(68720132112)
            
            //--TRIMMABLE-BOUNDARY-START(42950328336)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950328336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InnerList.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(42950328336)
            
            //--TRIMMABLE-BOUNDARY-START(34360393744)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360393744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(34360393744)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(4357619713)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357619713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357619713)
            
            //--TRIMMABLE-BOUNDARY-START(8590589968)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590589968)
            
            static $h = 655376;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655361040),
    {
      "p": 54460417,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426448,
        "f": 50331652
      },
      "n": "InnerList",
      "d": 655376,
      "h": 38655361040,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(38655361040),
//--TRIMMABLE-BOUNDARY-START(12885557264),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475491856,
        "f": 50331777
      },
      "n": "Count",
      "d": 655376,
      "h": 12885557264,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(12885557264),
//--TRIMMABLE-BOUNDARY-START(64425164816),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540262928,
        "f": 50331650
      },
      "n": "{62390273}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 655376,
      "h": 64425164816,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64425164816),
//--TRIMMABLE-BOUNDARY-START(68720132112),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197520,
        "f": 50331650
      },
      "n": "{62390273}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 655376,
      "h": 68720132112,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(68720132112)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360393744),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 655376,
      "h": 34360393744,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360393744)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590589968),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655376,
      "h": 8590589968,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590589968)
  ],
  "i": [62390273,62652417
  ],
  "h": 655376
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.ReadOnlyCollectionBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655376)
        
        
        //--TRIMMABLE-BOUNDARY-START(262160)
        $asm.$cls("$scn.System.Collections.DictionaryBase", ($self) => class DictionaryBase extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229456)
            /*Hashtable?*/ _hashtable = null;
            //--TRIMMABLE-BOUNDARY-END(4295229456)
            
            //--TRIMMABLE-BOUNDARY-START(60129804304)
            /*Hashtable */ get InnerHashtable()
            {
                return this._hashtable ??= new $.$$.System.Collections.Hashtable().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(60129804304)
            
            //--TRIMMABLE-BOUNDARY-START(25770065936)
            /*IDictionary */ get Dictionary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770065936)
            
            //--TRIMMABLE-BOUNDARY-START(21475098640)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._hashtable === null ? 0 : this._hashtable.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098640)
            
            //--TRIMMABLE-BOUNDARY-START(188978823184)
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619084816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(188978823184)
            
            //--TRIMMABLE-BOUNDARY-START(184683855888)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029150224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(184683855888)
            
            //--TRIMMABLE-BOUNDARY-START(124554313744)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(124554313744)
            
            //--TRIMMABLE-BOUNDARY-START(193273790480)
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798954000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(193273790480)
            
            //--TRIMMABLE-BOUNDARY-START(128849281040)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259346448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(128849281040)
            
            //--TRIMMABLE-BOUNDARY-START(214748626960)
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388888592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(214748626960)
            
            //--TRIMMABLE-BOUNDARY-START(17180131344)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InnerHashtable.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(17180131344)
            
            //--TRIMMABLE-BOUNDARY-START(210453659664)
            //--TRIMMABLE-BOUNDARY-START(90256834561)
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                /*object?*/ let currentValue = this.InnerHashtable.get_Item(key);
                this.OnGet(key, currentValue);
                return currentValue;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                this.OnValidate(key, value);
                /*bool*/ let keyExists = true;
                /*object?*/ let temp = this.InnerHashtable.get_Item(key);
                if (temp === null)
                {
                    keyExists = this.InnerHashtable.Contains(key);
                }
                this.OnSet(key, temp, value);
                this.InnerHashtable.set_Item(key, value);
                try
                {
                    this.OnSetComplete(key, temp, value);
                }
                catch($e)
                {
                    if (keyExists)
                    {
                        this.InnerHashtable.set_Item(key, temp);
                    }
                    else 
                    {
                        this.InnerHashtable.Remove(key);
                    }
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90256834561)
            
            //--TRIMMABLE-BOUNDARY-END(210453659664)
            
            //--TRIMMABLE-BOUNDARY-START(137439215632)
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.Contains(key);
            }
            //--TRIMMABLE-BOUNDARY-END(137439215632)
            
            //--TRIMMABLE-BOUNDARY-START(133144248336)
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidate(key, value);
                this.OnInsert(key, value);
                this.InnerHashtable.Add(key, value);
                try
                {
                    this.OnInsertComplete(key, value);
                }
                catch($e)
                {
                    this.InnerHashtable.Remove(key);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144248336)
            
            //--TRIMMABLE-BOUNDARY-START(12885164048)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnClear();
                this.InnerHashtable.Clear();
                this.OnClearComplete();
            }
            //--TRIMMABLE-BOUNDARY-END(12885164048)
            
            //--TRIMMABLE-BOUNDARY-START(197568757776)
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568757776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InnerHashtable.Contains(key))
                {
                    /*object?*/ let temp = this.InnerHashtable.get_Item(key);
                    this.OnValidate(key, temp);
                    this.OnRemove(key, temp);
                    this.InnerHashtable.Remove(key);
                    try
                    {
                        this.OnRemoveComplete(key, temp);
                    }
                    catch($e)
                    {
                        this.InnerHashtable.Add(key, temp);
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568757776)
            
            //--TRIMMABLE-BOUNDARY-START(55834837008)
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(55834837008)
            
            //--TRIMMABLE-BOUNDARY-START(219043594256)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043594256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerHashtable.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(219043594256)
            
            //--TRIMMABLE-BOUNDARY-START(73014706192)
            /*object? */ OnGet(/*object*/ key, /*object?*/ currentValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return currentValue;
            }
            //--TRIMMABLE-BOUNDARY-END(73014706192)
            
            //--TRIMMABLE-BOUNDARY-START(94489542672)
            /*void */ OnSet(/*object*/ key, /*object?*/ oldValue, /*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489542672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94489542672)
            
            //--TRIMMABLE-BOUNDARY-START(77309673488)
            /*void */ OnInsert(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309673488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77309673488)
            
            //--TRIMMABLE-BOUNDARY-START(64424771600)
            /*void */ OnClear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64424771600)
            
            //--TRIMMABLE-BOUNDARY-START(85899608080)
            /*void */ OnRemove(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899608080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85899608080)
            
            //--TRIMMABLE-BOUNDARY-START(103079477264)
            /*void */ OnValidate(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(103079477264)
            
            //--TRIMMABLE-BOUNDARY-START(98784509968)
            /*void */ OnSetComplete(/*object*/ key, /*object?*/ oldValue, /*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784509968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98784509968)
            
            //--TRIMMABLE-BOUNDARY-START(81604640784)
            /*void */ OnInsertComplete(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81604640784)
            
            //--TRIMMABLE-BOUNDARY-START(68719738896)
            /*void */ OnClearComplete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719738896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719738896)
            
            //--TRIMMABLE-BOUNDARY-START(90194575376)
            /*void */ OnRemoveComplete(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(90194575376)
            
            //--TRIMMABLE-BOUNDARY-START(8652455937)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652455937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652455937)
            
            //--TRIMMABLE-BOUNDARY-START(60192063489)
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60192063489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60192063489)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(8590196752)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196752)
            
            static $h = 262160;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129804304),
    {
      "p": 61931521,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539869712,
        "f": 50331652
      },
      "n": "InnerHashtable",
      "d": 262160,
      "h": 60129804304,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(60129804304),
//--TRIMMABLE-BOUNDARY-START(25770065936),
    {
      "p": 62521345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949935120,
        "f": 50331652
      },
      "n": "Dictionary",
      "d": 262160,
      "h": 25770065936,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(25770065936),
//--TRIMMABLE-BOUNDARY-START(21475098640),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360000528,
        "f": 50331649
      },
      "n": "Count",
      "d": 262160,
      "h": 21475098640,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475098640),
//--TRIMMABLE-BOUNDARY-START(188978823184),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619084816,
        "f": 50331650
      },
      "n": "{62521345}.IsReadOnly",
      "o": "System$Collections$IDictionary$IsReadOnly",
      "d": 262160,
      "h": 188978823184,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(188978823184),
//--TRIMMABLE-BOUNDARY-START(184683855888),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029150224,
        "f": 50331650
      },
      "n": "{62521345}.IsFixedSize",
      "o": "System$Collections$IDictionary$IsFixedSize",
      "d": 262160,
      "h": 184683855888,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(184683855888),
//--TRIMMABLE-BOUNDARY-START(124554313744),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669411856,
        "f": 50331650
      },
      "n": "{62390273}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 262160,
      "h": 124554313744,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(124554313744),
//--TRIMMABLE-BOUNDARY-START(193273790480),
    {
      "p": 62390273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171798954000,
        "f": 50331650
      },
      "n": "{62521345}.Keys",
      "o": "System$Collections$IDictionary$Keys",
      "d": 262160,
      "h": 193273790480,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(193273790480),
//--TRIMMABLE-BOUNDARY-START(128849281040),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259346448,
        "f": 50331650
      },
      "n": "{62390273}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 262160,
      "h": 128849281040,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128849281040),
//--TRIMMABLE-BOUNDARY-START(214748626960),
    {
      "p": 62390273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180388888592,
        "f": 50331650
      },
      "n": "{62521345}.Values",
      "o": "System$Collections$IDictionary$Values",
      "d": 262160,
      "h": 214748626960,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(214748626960),
//--TRIMMABLE-BOUNDARY-START(210453659664),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209019408,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158692368,
        "f": 83886082
      },
      "n": "{62521345}.this[]",
      "o": "System$Collections$IDictionary$Item",
      "d": 262160,
      "h": 210453659664,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(210453659664)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131344),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 262160,
      "h": 17180131344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131344),
//--TRIMMABLE-BOUNDARY-START(12885164048),
    {
      "r": 65537,
      "n": "Clear",
      "d": 262160,
      "h": 12885164048,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164048),
//--TRIMMABLE-BOUNDARY-START(55834837008),
    {
      "r": 62586881,
      "n": "GetEnumerator",
      "d": 262160,
      "h": 55834837008,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834837008),
//--TRIMMABLE-BOUNDARY-START(73014706192),
    {
      "r": 131073,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "currentValue",
          "p": 131073
        }
      ],
      "n": "OnGet",
      "d": 262160,
      "h": 73014706192,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(73014706192),
//--TRIMMABLE-BOUNDARY-START(94489542672),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "oldValue",
          "p": 131073
        },
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "OnSet",
      "d": 262160,
      "h": 94489542672,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(94489542672),
//--TRIMMABLE-BOUNDARY-START(77309673488),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnInsert",
      "d": 262160,
      "h": 77309673488,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(77309673488),
//--TRIMMABLE-BOUNDARY-START(64424771600),
    {
      "r": 65537,
      "n": "OnClear",
      "d": 262160,
      "h": 64424771600,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64424771600),
//--TRIMMABLE-BOUNDARY-START(85899608080),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnRemove",
      "d": 262160,
      "h": 85899608080,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(85899608080),
//--TRIMMABLE-BOUNDARY-START(103079477264),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnValidate",
      "d": 262160,
      "h": 103079477264,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(103079477264),
//--TRIMMABLE-BOUNDARY-START(98784509968),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "oldValue",
          "p": 131073
        },
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "OnSetComplete",
      "d": 262160,
      "h": 98784509968,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(98784509968),
//--TRIMMABLE-BOUNDARY-START(81604640784),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnInsertComplete",
      "d": 262160,
      "h": 81604640784,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(81604640784),
//--TRIMMABLE-BOUNDARY-START(68719738896),
    {
      "r": 65537,
      "n": "OnClearComplete",
      "d": 262160,
      "h": 68719738896,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68719738896),
//--TRIMMABLE-BOUNDARY-START(90194575376),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnRemoveComplete",
      "d": 262160,
      "h": 90194575376,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90194575376)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229456),
    {
      "t": 61931521,
      "n": "_hashtable",
      "d": 262160,
      "h": 4295229456,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590196752),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262160,
      "h": 8590196752,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590196752)
  ],
  "i": [62521345,62390273,62652417
  ],
  "h": 262160
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.DictionaryBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262160)
        
        
        //--TRIMMABLE-BOUNDARY-START(196624)
        $asm.$cls("$scn.System.Collections.CollectionBase", ($self) => class CollectionBase extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163920)
            /*ArrayList*/ _list = null;
            //--TRIMMABLE-BOUNDARY-END(4295163920)
            
            //--TRIMMABLE-BOUNDARY-START(8590131216)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131216);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._list = new $.$$.System.Collections.ArrayList().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131216)
            
            //--TRIMMABLE-BOUNDARY-START(12885098512)
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885098512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._list = new $.$$.System.Collections.ArrayList().$ctor$3(capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885098512)
            
            //--TRIMMABLE-BOUNDARY-START(68719673360)
            /*ArrayList */ get InnerList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list;
            }
            //--TRIMMABLE-BOUNDARY-END(68719673360)
            
            //--TRIMMABLE-BOUNDARY-START(73014640656)
            /*IList */ get List()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014640656)
            
            //--TRIMMABLE-BOUNDARY-START(17180065808)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359934992);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.Capacity;
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554248208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InnerList.Capacity = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065808)
            
            //--TRIMMABLE-BOUNDARY-START(25770000400)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000400)
            
            //--TRIMMABLE-BOUNDARY-START(21475033104)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033104);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnClear();
                this.InnerList.Clear();
                this.OnClearComplete();
            }
            //--TRIMMABLE-BOUNDARY-END(21475033104)
            
            //--TRIMMABLE-BOUNDARY-START(115964313616)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                /*object?*/ let temp = this.InnerList.get_Item(index);
                this.OnValidate(temp);
                this.OnRemove(index, temp);
                this.InnerList.RemoveAt(index);
                try
                {
                    this.OnRemoveComplete(index, temp);
                }
                catch($e)
                {
                    this.InnerList.Insert(index, temp);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964313616)
            
            //--TRIMMABLE-BOUNDARY-START(206158626832)
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388823056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(206158626832)
            
            //--TRIMMABLE-BOUNDARY-START(201863659536)
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798888464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(201863659536)
            
            //--TRIMMABLE-BOUNDARY-START(150324051984)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439150096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(150324051984)
            
            //--TRIMMABLE-BOUNDARY-START(154619019280)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(154619019280)
            
            //--TRIMMABLE-BOUNDARY-START(128849215504)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849215504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InnerList.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(128849215504)
            
            //--TRIMMABLE-BOUNDARY-START(223338496016)
            //--TRIMMABLE-BOUNDARY-START(77372391425)
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return this.InnerList.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this.OnValidate(value);
                /*object?*/ let temp = this.InnerList.get_Item(index);
                this.OnSet(index, temp, value);
                this.InnerList.set_Item(index, value);
                try
                {
                    this.OnSetComplete(index, temp, value);
                }
                catch($e)
                {
                    this.InnerList.set_Item(index, temp);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77372391425)
            
            //--TRIMMABLE-BOUNDARY-END(223338496016)
            
            //--TRIMMABLE-BOUNDARY-START(163208953872)
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208953872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.Contains(value);
            }
            //--TRIMMABLE-BOUNDARY-END(163208953872)
            
            //--TRIMMABLE-BOUNDARY-START(158913986576)
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158913986576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidate(value);
                this.OnInsert(this.InnerList.Count, value);
                /*int*/ let index = this.InnerList.Add(value);
                try
                {
                    this.OnInsertComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.RemoveAt(index);
                    throw $e;
                }
                return index;
            }
            //--TRIMMABLE-BOUNDARY-END(158913986576)
            
            //--TRIMMABLE-BOUNDARY-START(210453594128)
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453594128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnValidate(value);
                /*int*/ let index = this.InnerList.IndexOf$2(value);
                if (index < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scn.System.SR.Arg_RemoveArgNotFound);
                }
                this.OnRemove(index, value);
                this.InnerList.RemoveAt(index);
                try
                {
                    this.OnRemoveComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.Insert(index, value);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210453594128)
            
            //--TRIMMABLE-BOUNDARY-START(193273724944)
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273724944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.IndexOf$2(value);
            }
            //--TRIMMABLE-BOUNDARY-END(193273724944)
            
            //--TRIMMABLE-BOUNDARY-START(197568692240)
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568692240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index > this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                this.OnValidate(value);
                this.OnInsert(index, value);
                this.InnerList.Insert(index, value);
                try
                {
                    this.OnInsertComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.RemoveAt(index);
                    throw $e;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568692240)
            
            //--TRIMMABLE-BOUNDARY-START(64424706064)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InnerList.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(64424706064)
            
            //--TRIMMABLE-BOUNDARY-START(103079411728)
            /*void */ OnSet(/*int*/ index, /*object?*/ oldValue, /*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079411728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(103079411728)
            
            //--TRIMMABLE-BOUNDARY-START(85899542544)
            /*void */ OnInsert(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899542544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85899542544)
            
            //--TRIMMABLE-BOUNDARY-START(77309607952)
            /*void */ OnClear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309607952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77309607952)
            
            //--TRIMMABLE-BOUNDARY-START(94489477136)
            /*void */ OnRemove(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489477136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94489477136)
            
            //--TRIMMABLE-BOUNDARY-START(111669346320)
            /*void */ OnValidate(/*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
            }
            //--TRIMMABLE-BOUNDARY-END(111669346320)
            
            //--TRIMMABLE-BOUNDARY-START(107374379024)
            /*void */ OnSetComplete(/*int*/ index, /*object?*/ oldValue, /*object?*/ newValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374379024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(107374379024)
            
            //--TRIMMABLE-BOUNDARY-START(90194509840)
            /*void */ OnInsertComplete(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(90194509840)
            
            //--TRIMMABLE-BOUNDARY-START(81604575248)
            /*void */ OnClearComplete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(81604575248)
            
            //--TRIMMABLE-BOUNDARY-START(98784444432)
            /*void */ OnRemoveComplete(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784444432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(98784444432)
            
            //--TRIMMABLE-BOUNDARY-START(8652914689)
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652914689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652914689)
            
            //--TRIMMABLE-BOUNDARY-START(64487489537)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64487489537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64487489537)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(4357619713)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357619713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357619713)
            
            static $h = 196624;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719673360),
    {
      "p": 54460417,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804176,
        "f": 50331652
      },
      "n": "InnerList",
      "d": 196624,
      "h": 68719673360,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(68719673360),
//--TRIMMABLE-BOUNDARY-START(73014640656),
    {
      "p": 62980097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129738768,
        "f": 50331652
      },
      "n": "List",
      "d": 196624,
      "h": 73014640656,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(73014640656),
//--TRIMMABLE-BOUNDARY-START(17180065808),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359934992,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554248208,
        "f": 83886081
      },
      "n": "Capacity",
      "d": 196624,
      "h": 17180065808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180065808),
//--TRIMMABLE-BOUNDARY-START(25770000400),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869584,
        "f": 50331649
      },
      "n": "Count",
      "d": 196624,
      "h": 25770000400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770000400),
//--TRIMMABLE-BOUNDARY-START(206158626832),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180388823056,
        "f": 50331650
      },
      "n": "{62980097}.IsReadOnly",
      "o": "System$Collections$IList$IsReadOnly",
      "d": 196624,
      "h": 206158626832,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(206158626832),
//--TRIMMABLE-BOUNDARY-START(201863659536),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171798888464,
        "f": 50331650
      },
      "n": "{62980097}.IsFixedSize",
      "o": "System$Collections$IList$IsFixedSize",
      "d": 196624,
      "h": 201863659536,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(201863659536),
//--TRIMMABLE-BOUNDARY-START(150324051984),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439150096,
        "f": 50331650
      },
      "n": "{62390273}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 196624,
      "h": 150324051984,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(150324051984),
//--TRIMMABLE-BOUNDARY-START(154619019280),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029084688,
        "f": 50331650
      },
      "n": "{62390273}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 196624,
      "h": 154619019280,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(154619019280),
//--TRIMMABLE-BOUNDARY-START(223338496016),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978757648,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219043528720,
        "f": 83886082
      },
      "n": "{62980097}.this[]",
      "o": "System$Collections$IList$Item",
      "d": 196624,
      "h": 223338496016,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(223338496016)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475033104),
    {
      "r": 65537,
      "n": "Clear",
      "d": 196624,
      "h": 21475033104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033104),
//--TRIMMABLE-BOUNDARY-START(115964313616),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 196624,
      "h": 115964313616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964313616),
//--TRIMMABLE-BOUNDARY-START(64424706064),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 196624,
      "h": 64424706064,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424706064),
//--TRIMMABLE-BOUNDARY-START(103079411728),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "oldValue",
          "p": 131073
        },
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "OnSet",
      "d": 196624,
      "h": 103079411728,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(103079411728),
//--TRIMMABLE-BOUNDARY-START(85899542544),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnInsert",
      "d": 196624,
      "h": 85899542544,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(85899542544),
//--TRIMMABLE-BOUNDARY-START(77309607952),
    {
      "r": 65537,
      "n": "OnClear",
      "d": 196624,
      "h": 77309607952,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(77309607952),
//--TRIMMABLE-BOUNDARY-START(94489477136),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnRemove",
      "d": 196624,
      "h": 94489477136,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(94489477136),
//--TRIMMABLE-BOUNDARY-START(111669346320),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnValidate",
      "d": 196624,
      "h": 111669346320,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(111669346320),
//--TRIMMABLE-BOUNDARY-START(107374379024),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "oldValue",
          "p": 131073
        },
        {
          "n": "newValue",
          "p": 131073
        }
      ],
      "n": "OnSetComplete",
      "d": 196624,
      "h": 107374379024,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(107374379024),
//--TRIMMABLE-BOUNDARY-START(90194509840),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnInsertComplete",
      "d": 196624,
      "h": 90194509840,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(90194509840),
//--TRIMMABLE-BOUNDARY-START(81604575248),
    {
      "r": 65537,
      "n": "OnClearComplete",
      "d": 196624,
      "h": 81604575248,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(81604575248),
//--TRIMMABLE-BOUNDARY-START(98784444432),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "OnRemoveComplete",
      "d": 196624,
      "h": 98784444432,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(98784444432)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163920),
    {
      "t": 54460417,
      "n": "_list",
      "d": 196624,
      "h": 4295163920,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131216),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196624,
      "h": 8590131216,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590131216),
//--TRIMMABLE-BOUNDARY-START(12885098512),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196624,
      "h": 12885098512,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(12885098512)
  ],
  "i": [62980097,62390273,62652417
  ],
  "h": 196624
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.CollectionBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196624)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441808)
        $asm.$cls("$scn.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(296354185232)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(296354185232)
            
            //--TRIMMABLE-BOUNDARY-START(287764250640)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(287764250640)
            
            //--TRIMMABLE-BOUNDARY-START(292059217936)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224643088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$scn.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections.NonGeneric", $.$scn.System.SR.$type.Assembly);
                    $.$scn.System.SR.s_resourceManager = temp;
                }
                return $.$scn.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(292059217936)
            
            //--TRIMMABLE-BOUNDARY-START(42951114768)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915231760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scn.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239087120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scn.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42951114768)
            
            //--TRIMMABLE-BOUNDARY-START(21476278288)
            static /*string */ get Argument_AddingDuplicate_OldAndNewKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Item has already been added. Key in dictionary: '{0}'  Key being added: '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(21476278288)
            
            //--TRIMMABLE-BOUNDARY-START(81605820432)
            static /*string */ FormatArgument_AddingDuplicate_OldAndNewKeys(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("Item has already been added. Key in dictionary: '{0}'  Key being added: '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(81605820432)
            
            //--TRIMMABLE-BOUNDARY-START(8591376400)
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591376400)
            
            //--TRIMMABLE-BOUNDARY-START(12886343696)
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only single dimensional arrays are supported for the requested action.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886343696)
            
            //--TRIMMABLE-BOUNDARY-START(17181310992)
            static /*string */ get Arg_RemoveArgNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot remove the specified item because it was not found in the specified Collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181310992)
            
            //--TRIMMABLE-BOUNDARY-START(25771245584)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771245584)
            
            //--TRIMMABLE-BOUNDARY-START(30066212880)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145427984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066212880)
            
            //--TRIMMABLE-BOUNDARY-START(34361180176)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361180176)
            
            //--TRIMMABLE-BOUNDARY-START(38656147472)
            static /*string */ get ArgumentOutOfRange_SmallCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325297168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "capacity was less than the current size.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656147472)
            
            //--TRIMMABLE-BOUNDARY-START(253404512272)
            static /*string */ get InvalidOperation_EmptyQueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505166352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Queue empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(253404512272)
            
            //--TRIMMABLE-BOUNDARY-START(257699479568)
            static /*string */ get InvalidOperation_EmptyStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095100944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stack empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(257699479568)
            
            //--TRIMMABLE-BOUNDARY-START(261994446864)
            static /*string */ get InvalidOperation_EnumEnded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685035536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(261994446864)
            
            //--TRIMMABLE-BOUNDARY-START(266289414160)
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274970128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Collection was modified after the enumerator was instantiated.";
            }
            //--TRIMMABLE-BOUNDARY-END(266289414160)
            
            //--TRIMMABLE-BOUNDARY-START(270584381456)
            static /*string */ get InvalidOperation_EnumNotStarted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864904720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has not started. Call MoveNext.";
            }
            //--TRIMMABLE-BOUNDARY-END(270584381456)
            
            //--TRIMMABLE-BOUNDARY-START(274879348752)
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454839312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has either not started or has already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(274879348752)
            
            //--TRIMMABLE-BOUNDARY-START(279174316048)
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044773904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(279174316048)
            
            //--TRIMMABLE-BOUNDARY-START(283469283344)
            static /*string */ get NotSupported_SortedListNestedWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634708496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation is not supported on SortedList nested types because they require modifying the original SortedList.";
            }
            //--TRIMMABLE-BOUNDARY-END(283469283344)
            
            //--TRIMMABLE-BOUNDARY-START(300649152528)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(300649152528)
            
            //--TRIMMABLE-BOUNDARY-START(249109544976)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249109544976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109544976)
            
            //--TRIMMABLE-BOUNDARY-START(313534054416)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(313534054416);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scn.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313534054416)
            
            //--TRIMMABLE-BOUNDARY-START(244814577680)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814577680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scn.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(244814577680)
            
            //--TRIMMABLE-BOUNDARY-START(240519610384)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519610384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scn.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(240519610384)
            
            //--TRIMMABLE-BOUNDARY-START(73015885840)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(73015885840)
            
            //--TRIMMABLE-BOUNDARY-START(68720918544)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918544)
            
            //--TRIMMABLE-BOUNDARY-START(64425951248)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951248)
            
            //--TRIMMABLE-BOUNDARY-START(77310853136)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(77310853136)
            
            //--TRIMMABLE-BOUNDARY-START(55836016656)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836016656)
            
            //--TRIMMABLE-BOUNDARY-START(51541049360)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(51541049360)
            
            //--TRIMMABLE-BOUNDARY-START(47246082064)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246082064)
            
            //--TRIMMABLE-BOUNDARY-START(60130983952)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(60130983952)
            
            //--TRIMMABLE-BOUNDARY-START(4296409104)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(300649152528)
                    this.s_usingResourceKeys = $.$scn.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(300649152528)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296409104)
            
            static $h = 1441808;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1441808
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441808)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114128)
        $asm.$cls("$scn.System.Collections.Specialized.CollectionsUtil", ($self) => class CollectionsUtil extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591048720)
            static /*Hashtable */ CreateCaseInsensitiveHashtable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.Collections.Hashtable().$ctor$9($.$$.System.StringComparer.CurrentCultureIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(8591048720)
            
            //--TRIMMABLE-BOUNDARY-START(17180983312)
            static /*Hashtable */ CreateCaseInsensitiveHashtable$2(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.Collections.Hashtable().$ctor$11(capacity, $.$$.System.StringComparer.CurrentCultureIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(17180983312)
            
            //--TRIMMABLE-BOUNDARY-START(12886016016)
            static /*Hashtable */ CreateCaseInsensitiveHashtable$1(/*IDictionary*/ d)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.Collections.Hashtable().$ctor$3(d, $.$$.System.StringComparer.CurrentCultureIgnoreCase);
            }
            //--TRIMMABLE-BOUNDARY-END(12886016016)
            
            //--TRIMMABLE-BOUNDARY-START(21475950608)
            static /*SortedList */ CreateCaseInsensitiveSortedList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.SortedList().$ctor$3($.$scn.System.Collections.CaseInsensitiveComparer.Default);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950608)
            
            //--TRIMMABLE-BOUNDARY-START(4296081424)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296081424)
            
            static $h = 1114128;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048720),
    {
      "r": 61931521,
      "n": "CreateCaseInsensitiveHashtable",
      "d": 1114128,
      "h": 8591048720,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591048720),
//--TRIMMABLE-BOUNDARY-START(17180983312),
    {
      "r": 61931521,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "CreateCaseInsensitiveHashtable",
      "o": "@$2",
      "d": 1114128,
      "h": 17180983312,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180983312),
//--TRIMMABLE-BOUNDARY-START(12886016016),
    {
      "r": 61931521,
      "p": [
        {
          "n": "d",
          "p": 62521345
        }
      ],
      "n": "CreateCaseInsensitiveHashtable",
      "o": "@$1",
      "d": 1114128,
      "h": 12886016016,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886016016),
//--TRIMMABLE-BOUNDARY-START(21475950608),
    {
      "r": 720912,
      "n": "CreateCaseInsensitiveSortedList",
      "d": 1114128,
      "h": 21475950608,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475950608)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081424),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114128,
      "h": 4296081424,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081424)
  ],
  "h": 1114128
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Specialized.CollectionsUtil`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114128)
        
        
        //--TRIMMABLE-BOUNDARY-START(131088)
        $asm.$cls("$scn.System.Collections.CaseInsensitiveHashCodeProvider", ($self) => class CaseInsensitiveHashCodeProvider extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098384)
            /*CompareInfo*/ _compareInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295098384)
            
            //--TRIMMABLE-BOUNDARY-START(12885032976)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885032976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._compareInfo = $.$$.System.Globalization.CultureInfo.CurrentCulture.CompareInfo;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032976)
            
            //--TRIMMABLE-BOUNDARY-START(17180000272)
            $ctor$2(/*CultureInfo*/ culture)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(culture, "culture");
                    this._compareInfo = culture.CompareInfo;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000272)
            
            //--TRIMMABLE-BOUNDARY-START(21474967568)
            static /*CaseInsensitiveHashCodeProvider */ get Default()
            {
                return new $.$scn.System.Collections.CaseInsensitiveHashCodeProvider().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967568)
            
            //--TRIMMABLE-BOUNDARY-START(25769934864)
            /*CaseInsensitiveHashCodeProvider*/ static DefaultInvariant$ = null;
            static /*CaseInsensitiveHashCodeProvider */ get DefaultInvariant()
            {
                return $.$scn.System.Collections.CaseInsensitiveHashCodeProvider.DefaultInvariant$ ??= new $.$scn.System.Collections.CaseInsensitiveHashCodeProvider().$ctor$2($.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(25769934864)
            
            //--TRIMMABLE-BOUNDARY-START(47244771344)
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                /*string?*/ let s = $.$as(obj, $.$$.System.String);
                return $.$$.System.String.op_Inequality(s, null) ? this._compareInfo.GetHashCode$2(s, 1/*CompareOptions.IgnoreCase*/) : $.$$.System.Object.GetHashCode.call(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(47244771344)
            
            //--TRIMMABLE-BOUNDARY-START(4357881857)
            //Generated interface implemetation for System.Collections.IHashCodeProvider.GetHashCode(object)
            System$Collections$IHashCodeProvider$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357881857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357881857)
            
            static $h = 131088;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967568),
    {
      "p": 131088,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359869456,
        "f": 50331681
      },
      "n": "Default",
      "d": 131088,
      "h": 21474967568,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21474967568),
//--TRIMMABLE-BOUNDARY-START(25769934864),
    {
      "p": 131088,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949804048,
        "f": 50331681
      },
      "n": "DefaultInvariant",
      "d": 131088,
      "h": 25769934864,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25769934864)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244771344),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 131088,
      "h": 47244771344,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244771344)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098384),
    {
      "t": 83361793,
      "n": "_compareInfo",
      "d": 131088,
      "h": 4295098384,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098384)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885032976),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131088,
      "h": 12885032976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885032976),
//--TRIMMABLE-BOUNDARY-START(17180000272),
    {
      "p": [
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131088,
      "h": 17180000272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180000272)
  ],
  "i": [62914561
  ],
  "h": 131088,
  "a": [
    {
      "t": 103743489,
      "c": 30168514561,
      "a": [
        {
          "v": "CaseInsensitiveHashCodeProvider has been deprecated. Use StringComparer instead.",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IHashCodeProvider ]; }
            static get $fullName() { return `System.Collections.CaseInsensitiveHashCodeProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131088)
        
        
        //--TRIMMABLE-BOUNDARY-START(65552)
        $asm.$cls("$scn.System.Collections.CaseInsensitiveComparer", ($self) => class CaseInsensitiveComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032848)
            /*CompareInfo*/ _compareInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295032848)
            
            //--TRIMMABLE-BOUNDARY-START(47244705808)
            /*CaseInsensitiveComparer?*/ static s_InvariantCaseInsensitiveComparer = null;
            //--TRIMMABLE-BOUNDARY-END(47244705808)
            
            //--TRIMMABLE-BOUNDARY-START(8590000144)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000144);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._compareInfo = $.$$.System.Globalization.CultureInfo.CurrentCulture.CompareInfo;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000144)
            
            //--TRIMMABLE-BOUNDARY-START(12884967440)
            $ctor$2(/*CultureInfo*/ culture)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967440);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(culture, "culture");
                    this._compareInfo = culture.CompareInfo;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967440)
            
            //--TRIMMABLE-BOUNDARY-START(21474902032)
            static /*CaseInsensitiveComparer */ get Default()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.CaseInsensitiveComparer().$ctor$2($.$$.System.Globalization.CultureInfo.CurrentCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(21474902032)
            
            //--TRIMMABLE-BOUNDARY-START(25769869328)
            static /*CaseInsensitiveComparer */ get DefaultInvariant()
            {
                return $.$scn.System.Collections.CaseInsensitiveComparer.s_InvariantCaseInsensitiveComparer ??= new $.$scn.System.Collections.CaseInsensitiveComparer().$ctor$2($.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(25769869328)
            
            //--TRIMMABLE-BOUNDARY-START(17179934736)
            /*int */ Compare(/*object?*/ a, /*object?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let sa = $.$as(a, $.$$.System.String);
                /*string?*/ let sb = $.$as(b, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(sa, null) && $.$$.System.String.op_Inequality(sb, null))
                {
                    return this._compareInfo.Compare$5(sa, sb, 1/*CompareOptions.IgnoreCase*/);
                }
                else 
                {
                    return $.$$.System.Collections.Comparer.Default.Compare(a, b);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17179934736)
            
            //--TRIMMABLE-BOUNDARY-START(4357423105)
            //Generated interface implemetation for System.Collections.IComparer.Compare(object?, object?)
            System$Collections$IComparer$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357423105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357423105)
            
            static $h = 65552;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474902032),
    {
      "p": 65552,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359803920,
        "f": 50331681
      },
      "n": "Default",
      "d": 65552,
      "h": 21474902032,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21474902032),
//--TRIMMABLE-BOUNDARY-START(25769869328),
    {
      "p": 65552,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949738512,
        "f": 50331681
      },
      "n": "DefaultInvariant",
      "d": 65552,
      "h": 25769869328,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25769869328)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17179934736),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 131073
        },
        {
          "n": "b",
          "p": 131073
        }
      ],
      "n": "Compare",
      "d": 65552,
      "h": 17179934736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934736)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032848),
    {
      "t": 83361793,
      "n": "_compareInfo",
      "d": 65552,
      "h": 4295032848,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032848),
//--TRIMMABLE-BOUNDARY-START(47244705808),
    {
      "t": 65552,
      "n": "s_InvariantCaseInsensitiveComparer",
      "d": 65552,
      "h": 47244705808,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244705808)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000144),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65552,
      "h": 8590000144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000144),
//--TRIMMABLE-BOUNDARY-START(12884967440),
    {
      "p": [
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65552,
      "h": 12884967440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967440)
  ],
  "i": [62455809
  ],
  "h": 65552
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer ]; }
            static get $fullName() { return `System.Collections.CaseInsensitiveComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65552)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179664)
        $asm.$cls("$scn.System.Collections.Stack", ($self) => class Stack extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296146960)
            /*object?[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4296146960)
            
            //--TRIMMABLE-BOUNDARY-START(12886081552)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(12886081552)
            
            //--TRIMMABLE-BOUNDARY-START(17181048848)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(17181048848)
            
            //--TRIMMABLE-BOUNDARY-START(8591114256)
            /*int*/ static _defaultCapacity = 10;
            //--TRIMMABLE-BOUNDARY-END(8591114256)
            
            //--TRIMMABLE-BOUNDARY-START(34360918032)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918032);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [10/*_defaultCapacity*/], null);
                    this._size = 0;
                    this._version = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360918032)
            
            //--TRIMMABLE-BOUNDARY-START(42950852624)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950852624);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCapacity, "initialCapacity");
                    if (initialCapacity < 10/*_defaultCapacity*/)
                    {
                        initialCapacity = 10/*_defaultCapacity*/;
                    }
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [initialCapacity], null);
                    this._size = 0;
                    this._version = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950852624)
            
            //--TRIMMABLE-BOUNDARY-START(38655885328)
            $ctor$2(/*ICollection*/ col)
            {
                this.$ctor$3($.$firstOf((col?.System$Collections$ICollection$Count ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("col") }));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655885328);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IEnumerator*/ let en = col.System$Collections$IEnumerable$GetEnumerator();
                    while(en.System$Collections$IEnumerator$MoveNext())
                    {
                        this.Push(en.System$Collections$IEnumerator$Current);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655885328)
            
            //--TRIMMABLE-BOUNDARY-START(64425689104)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015623696);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(64425689104)
            
            //--TRIMMABLE-BOUNDARY-START(98785427472)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605558288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98785427472)
            
            //--TRIMMABLE-BOUNDARY-START(120260263952)
            /*object */ get SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(120260263952)
            
            //--TRIMMABLE-BOUNDARY-START(47245819920)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245819920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Array.Clear(this._array, 0, this._size);
                this._size = 0;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(47245819920)
            
            //--TRIMMABLE-BOUNDARY-START(51540787216)
            /*object */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540787216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Stack*/ let s = new $.$scn.System.Collections.Stack().$ctor$3(this._size);
                s._size = this._size;
                $.$$.System.Array.Copy(this._array, s._array, this._size);
                s._version = this._version;
                return s;
            }
            //--TRIMMABLE-BOUNDARY-END(51540787216)
            
            //--TRIMMABLE-BOUNDARY-START(55835754512)
            /*bool */ Contains(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835754512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = this._size;
                while(count-- > 0)
                {
                    if (obj === null)
                    {
                        if ($.$$.System.Array.$ReadT1.call(this._array, count) === null)
                        {
                            return true;
                        }
                    }
                    else if ($.$$.System.Array.$ReadT1.call(this._array, count) !== null && $.$$.System.Object.Equals$1.call($.$$.System.Array.$ReadT1.call(this._array, count), obj))
                    {
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(55835754512)
            
            //--TRIMMABLE-BOUNDARY-START(60130721808)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130721808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scn.System.SR.Argument_InvalidOffLen);
                }
                /*int*/ let i = 0;
                /*object?[]?*/ let objArray = $.$as(array, $.$typeArray($.$$.System.Object));
                if (objArray !== null)
                {
                    while(i < this._size)
                    {
                        $.$$.System.Array.$WriteT1.call(objArray, $.$$.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), ((i + index) | 0));
                        i++;
                    }
                }
                else 
                {
                    while(i < this._size)
                    {
                        array.SetValue$2($.$$.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), ((i + index) | 0));
                        i++;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130721808)
            
            //--TRIMMABLE-BOUNDARY-START(94490460176)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490460176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.Stack.StackEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(94490460176)
            
            //--TRIMMABLE-BOUNDARY-START(103080394768)
            /*object? */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080394768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EmptyStack);
                }
                return $.$$.System.Array.$ReadT1.call(this._array, ((this._size - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(103080394768)
            
            //--TRIMMABLE-BOUNDARY-START(107375362064)
            /*object? */ Pop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375362064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EmptyStack);
                }
                this._version++;
                /*object?*/ let obj = $.$$.System.Array.$ReadT1.call(this._array, --this._size);
                $.$$.System.Array.$WriteT1.call(this._array, null, this._size);
                return obj;
            }
            //--TRIMMABLE-BOUNDARY-END(107375362064)
            
            //--TRIMMABLE-BOUNDARY-START(111670329360)
            /*void */ Push(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670329360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === this._array.length)
                {
                    /*object[]*/ let newArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [((2 * this._array.length) | 0)], null);
                    $.$$.System.Array.Copy(this._array, newArray, this._size);
                    this._array = newArray;
                }
                $.$$.System.Array.$WriteT1.call(this._array, obj, this._size++);
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(111670329360)
            
            //--TRIMMABLE-BOUNDARY-START(115965296656)
            static /*Stack */ Synchronized(/*Stack*/ stack)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965296656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(stack, "stack");
                return new $.$scn.System.Collections.Stack.SyncStack().$ctor$4(stack);
            }
            //--TRIMMABLE-BOUNDARY-END(115965296656)
            
            //--TRIMMABLE-BOUNDARY-START(124555231248)
            /*object?[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555231248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Object);
                }
                /*object?[]*/ let objArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this._size], null);
                /*int*/ let i = 0;
                while(i < this._size)
                {
                    $.$$.System.Array.$WriteT1.call(objArray, $.$$.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), i);
                    i++;
                }
                return objArray;
            }
            //--TRIMMABLE-BOUNDARY-END(124555231248)
            
            //--TRIMMABLE-BOUNDARY-START(1376272)
            static $_SyncStack;
            static get SyncStack()
            {
                let $cls = $.$scn.System.Collections.Stack;
                return $cls.$_SyncStack ??= $asm.$ncls("$scn.System.Collections.Stack.SyncStack", ($self) => class SyncStack extends $.$scn.System.Collections.Stack
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310864)
                    /*Stack*/ _s = null;
                    //--TRIMMABLE-BOUNDARY-END(8591310864)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343568)
                    /*object*/ _root = null;
                    //--TRIMMABLE-BOUNDARY-END(4296343568)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278160)
                    $ctor$4(/*Stack*/ stack)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886278160);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._s = stack;
                            this._root = stack.SyncRoot;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886278160)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720853008)
                    /*bool */ get IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540983824);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720853008)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900722192)
                    /*object */ get SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130918416);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._root;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900722192)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361114640)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951049232);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.Count;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361114640)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771180048)
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771180048);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.Contains(obj);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771180048)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476212752)
                    /*object */ Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476212752);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return new $.$scn.System.Collections.Stack.SyncStack().$ctor$4($.$cast(this._s.Clone(), $.$scn.System.Collections.Stack));
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476212752)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245456)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181245456);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._s.Clear();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181245456)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066147344)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066147344);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._s.CopyTo(array, arrayIndex);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066147344)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605754896)
                    /*void */ Push(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605754896);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._s.Push(value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605754896)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310787600)
                    /*object? */ Pop()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310787600);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.Pop();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310787600)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425885712)
                    /*IEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425885712);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425885712)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015820304)
                    /*object? */ Peek()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015820304);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.Peek();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015820304)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195689488)
                    /*object?[] */ ToArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90195689488);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._s.ToArray();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195689488)
                    
                    static $h = 1376272;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1179664,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720853008),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540983824,
        "f": 50364417
      },
      "n": "IsSynchronized",
      "d": 1376272,
      "h": 68720853008,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68720853008),
//--TRIMMABLE-BOUNDARY-START(85900722192),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130918416,
        "f": 50364417
      },
      "n": "SyncRoot",
      "d": 1376272,
      "h": 85900722192,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85900722192),
//--TRIMMABLE-BOUNDARY-START(34361114640),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951049232,
        "f": 50364417
      },
      "n": "Count",
      "d": 1376272,
      "h": 34361114640,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34361114640)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180048),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 1376272,
      "h": 25771180048,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771180048),
//--TRIMMABLE-BOUNDARY-START(21476212752),
    {
      "r": 131073,
      "n": "Clone",
      "d": 1376272,
      "h": 21476212752,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476212752),
//--TRIMMABLE-BOUNDARY-START(17181245456),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1376272,
      "h": 17181245456,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181245456),
//--TRIMMABLE-BOUNDARY-START(30066147344),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1376272,
      "h": 30066147344,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066147344),
//--TRIMMABLE-BOUNDARY-START(81605754896),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 1376272,
      "h": 81605754896,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605754896),
//--TRIMMABLE-BOUNDARY-START(77310787600),
    {
      "r": 131073,
      "n": "Pop",
      "d": 1376272,
      "h": 77310787600,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310787600),
//--TRIMMABLE-BOUNDARY-START(64425885712),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 1376272,
      "h": 64425885712,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425885712),
//--TRIMMABLE-BOUNDARY-START(73015820304),
    {
      "r": 131073,
      "n": "Peek",
      "d": 1376272,
      "h": 73015820304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015820304),
//--TRIMMABLE-BOUNDARY-START(90195689488),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": 1376272,
      "h": 90195689488,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195689488)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591310864),
    {
      "t": 1179664,
      "n": "_s",
      "d": 1376272,
      "h": 8591310864,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591310864),
//--TRIMMABLE-BOUNDARY-START(4296343568),
    {
      "t": 131073,
      "n": "_root",
      "d": 1376272,
      "h": 4296343568,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343568)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886278160),
    {
      "p": [
        {
          "n": "stack",
          "p": 1179664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1376272,
      "h": 12886278160,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886278160)
  ],
  "i": [62390273,62652417,89980929
  ],
  "d": 1179664,
  "h": 1376272
}; }
                    static get $b() { return $.$scn.System.Collections.Stack; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Stack.SyncStack`; }
                }, $cls, ($v) => $cls.$_SyncStack = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376272)
            
            //--TRIMMABLE-BOUNDARY-START(1310736)
            static $_StackEnumerator;
            static get StackEnumerator()
            {
                let $cls = $.$scn.System.Collections.Stack;
                return $cls.$_StackEnumerator ??= $asm.$ncls("$scn.System.Collections.Stack.StackEnumerator", ($self) => class StackEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12886212624)
                    /*Stack*/ _stack = null;
                    //--TRIMMABLE-BOUNDARY-END(12886212624)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591245328)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591245328)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181179920)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(17181179920)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296278032)
                    /*object?*/ _currentElement = null;
                    //--TRIMMABLE-BOUNDARY-END(4296278032)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476147216)
                    $ctor$1(/*Stack*/ stack)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476147216);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._stack = stack;
                            this._version = this._stack._version;
                            this._index = -2;
                            this._currentElement = null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476147216)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771114512)
                    /*object */ Clone()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25771114512);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$clone(this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771114512)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950983696)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950983696);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*bool*/ let retval;
                        if (this._version !== this._stack._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index === -2)
                        {
                            this._index = ((this._stack._size - 1) | 0);
                            retval = (this._index >= 0);
                            if (retval)
                            {
                                this._currentElement = $.$$.System.Array.$ReadT1.call(this._stack._array, this._index);
                            }
                            return retval;
                        }
                        if (this._index === -1)
                        {
                            return false;
                        }
                        retval = (--this._index >= 0);
                        if (retval)
                        {
                            this._currentElement = $.$$.System.Array.$ReadT1.call(this._stack._array, this._index);
                        }
                        else 
                        {
                            this._currentElement = null;
                        }
                        return retval;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950983696)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066081808)
                    /*object? */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656016400);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === -2)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumNotStarted);
                        }
                        if (this._index === -1)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumEnded);
                        }
                        return this._currentElement;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066081808)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245950992)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245950992);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._stack._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = -2;
                        this._currentElement = null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245950992)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947685377)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357750785);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947685377)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537619969)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537619969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537619969)
                    
                    //--TRIMMABLE-BOUNDARY-START(4384948225)
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4384948225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clone(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4384948225)
                    
                    static $h = 1310736;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066081808),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656016400,
        "f": 50331649
      },
      "n": "Current",
      "d": 1310736,
      "h": 30066081808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066081808)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771114512),
    {
      "r": 131073,
      "n": "Clone",
      "d": 1310736,
      "h": 25771114512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771114512),
//--TRIMMABLE-BOUNDARY-START(42950983696),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1310736,
      "h": 42950983696,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950983696),
//--TRIMMABLE-BOUNDARY-START(47245950992),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1310736,
      "h": 47245950992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245950992)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886212624),
    {
      "t": 1179664,
      "n": "_stack",
      "d": 1310736,
      "h": 12886212624,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886212624),
//--TRIMMABLE-BOUNDARY-START(8591245328),
    {
      "t": 655361,
      "n": "_index",
      "d": 1310736,
      "h": 8591245328,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591245328),
//--TRIMMABLE-BOUNDARY-START(17181179920),
    {
      "t": 655361,
      "n": "_version",
      "d": 1310736,
      "h": 17181179920,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181179920),
//--TRIMMABLE-BOUNDARY-START(4296278032),
    {
      "t": 131073,
      "n": "_currentElement",
      "d": 1310736,
      "h": 4296278032,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296278032)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476147216),
    {
      "p": [
        {
          "n": "stack",
          "p": 1179664
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310736,
      "h": 21476147216,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476147216)
  ],
  "i": [62783489,89980929
  ],
  "d": 1179664,
  "h": 1310736
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Stack.StackEnumerator`; }
                }, $cls, ($v) => $cls.$_StackEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1310736)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(34422128641)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012063233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422128641)
            
            //--TRIMMABLE-BOUNDARY-START(25832194049)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832194049)
            
            //--TRIMMABLE-BOUNDARY-START(4357619713)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357619713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357619713)
            
            //--TRIMMABLE-BOUNDARY-START(4384948225)
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384948225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clone(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384948225)
            
            static $h = 1179664;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425689104),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015623696,
        "f": 50331777
      },
      "n": "Count",
      "d": 1179664,
      "h": 64425689104,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(64425689104),
//--TRIMMABLE-BOUNDARY-START(98785427472),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605558288,
        "f": 50331777
      },
      "n": "IsSynchronized",
      "d": 1179664,
      "h": 98785427472,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(98785427472),
//--TRIMMABLE-BOUNDARY-START(120260263952),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195492880,
        "f": 50331777
      },
      "n": "SyncRoot",
      "d": 1179664,
      "h": 120260263952,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120260263952)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245819920),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1179664,
      "h": 47245819920,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245819920),
//--TRIMMABLE-BOUNDARY-START(51540787216),
    {
      "r": 131073,
      "n": "Clone",
      "d": 1179664,
      "h": 51540787216,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540787216),
//--TRIMMABLE-BOUNDARY-START(55835754512),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 1179664,
      "h": 55835754512,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835754512),
//--TRIMMABLE-BOUNDARY-START(60130721808),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1179664,
      "h": 60130721808,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60130721808),
//--TRIMMABLE-BOUNDARY-START(94490460176),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 1179664,
      "h": 94490460176,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94490460176),
//--TRIMMABLE-BOUNDARY-START(103080394768),
    {
      "r": 131073,
      "n": "Peek",
      "d": 1179664,
      "h": 103080394768,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080394768),
//--TRIMMABLE-BOUNDARY-START(107375362064),
    {
      "r": 131073,
      "n": "Pop",
      "d": 1179664,
      "h": 107375362064,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107375362064),
//--TRIMMABLE-BOUNDARY-START(111670329360),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 1179664,
      "h": 111670329360,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111670329360),
//--TRIMMABLE-BOUNDARY-START(115965296656),
    {
      "r": 1179664,
      "p": [
        {
          "n": "stack",
          "p": 1179664
        }
      ],
      "n": "Synchronized",
      "d": 1179664,
      "h": 115965296656,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115965296656),
//--TRIMMABLE-BOUNDARY-START(124555231248),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": 1179664,
      "h": 124555231248,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124555231248)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296146960),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_array",
      "d": 1179664,
      "h": 4296146960,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146960),
//--TRIMMABLE-BOUNDARY-START(12886081552),
    {
      "t": 655361,
      "n": "_size",
      "d": 1179664,
      "h": 12886081552,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081552),
//--TRIMMABLE-BOUNDARY-START(17181048848),
    {
      "t": 655361,
      "n": "_version",
      "d": 1179664,
      "h": 17181048848,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181048848),
//--TRIMMABLE-BOUNDARY-START(8591114256),
    {
      "t": 655361,
      "n": "_defaultCapacity",
      "d": 1179664,
      "h": 8591114256,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591114256)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360918032),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179664,
      "h": 34360918032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360918032),
//--TRIMMABLE-BOUNDARY-START(42950852624),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179664,
      "h": 42950852624,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950852624),
//--TRIMMABLE-BOUNDARY-START(38655885328),
    {
      "p": [
        {
          "n": "col",
          "p": 62390273
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179664,
      "h": 38655885328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655885328)
  ],
  "i": [62390273,62652417,89980929
  ],
  "j": [1376272,1310736
  ],
  "h": 1179664,
  "a": [
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    },
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.Stack`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179664)
        
        
        //--TRIMMABLE-BOUNDARY-START(393232)
        $asm.$cls("$scn.System.Collections.Queue", ($self) => class Queue extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360528)
            /*object?[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295360528)
            
            //--TRIMMABLE-BOUNDARY-START(12885295120)
            /*int*/ _head = 0;
            //--TRIMMABLE-BOUNDARY-END(12885295120)
            
            //--TRIMMABLE-BOUNDARY-START(21475229712)
            /*int*/ _tail = 0;
            //--TRIMMABLE-BOUNDARY-END(21475229712)
            
            //--TRIMMABLE-BOUNDARY-START(17180262416)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(17180262416)
            
            //--TRIMMABLE-BOUNDARY-START(8590327824)
            /*int*/ _growFactor = 0;
            //--TRIMMABLE-BOUNDARY-END(8590327824)
            
            //--TRIMMABLE-BOUNDARY-START(25770197008)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(25770197008)
            
            //--TRIMMABLE-BOUNDARY-START(128849412112)
            /*int*/ static MinimumGrow = 4;
            //--TRIMMABLE-BOUNDARY-END(128849412112)
            
            //--TRIMMABLE-BOUNDARY-START(42950066192)
            $ctor$1()
            {
                this.$ctor$3(32, $.$cast(2, $.$$.System.Single));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950066192);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950066192)
            
            //--TRIMMABLE-BOUNDARY-START(55834968080)
            $ctor$4(/*int*/ capacity)
            {
                this.$ctor$3(capacity, $.$cast(2, $.$$.System.Single));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834968080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968080)
            
            //--TRIMMABLE-BOUNDARY-START(51540000784)
            $ctor$3(/*int*/ capacity, /*float*/ growFactor)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540000784);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Single, growFactor, 1, "growFactor");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Single, growFactor, 10, "growFactor");
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [capacity], null);
                    this._head = 0;
                    this._tail = 0;
                    this._size = 0;
                    this._growFactor = $.$cast((growFactor * 100), $.$$.System.Int32);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000784)
            
            //--TRIMMABLE-BOUNDARY-START(47245033488)
            $ctor$2(/*ICollection*/ col)
            {
                this.$ctor$4($.$firstOf((col?.System$Collections$ICollection$Count ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("col") }));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245033488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*IEnumerator*/ let en = col.System$Collections$IEnumerable$GetEnumerator();
                    while(en.System$Collections$IEnumerator$MoveNext())
                    {
                        this.Enqueue(en.System$Collections$IEnumerator$Current);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245033488)
            
            //--TRIMMABLE-BOUNDARY-START(77309804560)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(77309804560)
            
            //--TRIMMABLE-BOUNDARY-START(64424902672)
            /*object */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Queue*/ let q = new $.$scn.System.Collections.Queue().$ctor$4(this._size);
                q._size = this._size;
                /*int*/ let numToCopy = this._size;
                /*int*/ let firstPart = (((this._array.length - this._head) | 0) < numToCopy) ? ((this._array.length - this._head) | 0) : numToCopy;
                $.$$.System.Array.Copy$2(this._array, this._head, q._array, 0, firstPart);
                numToCopy -= firstPart;
                if (numToCopy > 0)
                {
                    $.$$.System.Array.Copy$2(this._array, 0, q._array, ((this._array.length - this._head) | 0), numToCopy);
                }
                q._version = this._version;
                return q;
            }
            //--TRIMMABLE-BOUNDARY-END(64424902672)
            
            //--TRIMMABLE-BOUNDARY-START(124554444816)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079608336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(124554444816)
            
            //--TRIMMABLE-BOUNDARY-START(146029281296)
            /*object */ get SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(146029281296)
            
            //--TRIMMABLE-BOUNDARY-START(60129935376)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size !== 0)
                {
                    if (this._head < this._tail)
                    {
                        $.$$.System.Array.Clear(this._array, this._head, this._size);
                    }
                    else 
                    {
                        $.$$.System.Array.Clear(this._array, this._head, ((this._array.length - this._head) | 0));
                        $.$$.System.Array.Clear(this._array, 0, this._tail);
                    }
                    this._size = 0;
                }
                this._head = 0;
                this._tail = 0;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935376)
            
            //--TRIMMABLE-BOUNDARY-START(73014837264)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*int*/ let arrayLen = array.length;
                if (((arrayLen - index) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scn.System.SR.Argument_InvalidOffLen);
                }
                /*int*/ let numToCopy = this._size;
                if (numToCopy === 0)
                {
                    return;
                }
                /*int*/ let firstPart = (((this._array.length - this._head) | 0) < numToCopy) ? ((this._array.length - this._head) | 0) : numToCopy;
                $.$$.System.Array.Copy$2(this._array, this._head, array, index, firstPart);
                numToCopy -= firstPart;
                if (numToCopy > 0)
                {
                    $.$$.System.Array.Copy$2(this._array, 0, array, ((((index + this._array.length) | 0) - this._head) | 0), numToCopy);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014837264)
            
            //--TRIMMABLE-BOUNDARY-START(85899739152)
            /*void */ Enqueue(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === this._array.length)
                {
                    /*int*/ let newcapacity = $.$cast(($.$cast(this._array.length, $.$$.System.Int64) * $.$cast(this._growFactor, $.$$.System.Int64) / 100n), $.$$.System.Int32);
                    if (newcapacity < ((this._array.length + 4/*MinimumGrow*/) | 0))
                    {
                        newcapacity = ((this._array.length + 4/*MinimumGrow*/) | 0);
                    }
                    this.SetCapacity(newcapacity);
                }
                $.$$.System.Array.$WriteT1.call(this._array, obj, this._tail);
                this._tail = (((this._tail + 1) | 0)) % this._array.length;
                this._size++;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(85899739152)
            
            //--TRIMMABLE-BOUNDARY-START(120259477520)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259477520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.Queue.QueueEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(120259477520)
            
            //--TRIMMABLE-BOUNDARY-START(81604771856)
            /*object? */ Dequeue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604771856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EmptyQueue);
                }
                /*object?*/ let removed = $.$$.System.Array.$ReadT1.call(this._array, this._head);
                $.$$.System.Array.$WriteT1.call(this._array, null, this._head);
                this._head = (((this._head + 1) | 0)) % this._array.length;
                this._size--;
                this._version++;
                return removed;
            }
            //--TRIMMABLE-BOUNDARY-END(81604771856)
            
            //--TRIMMABLE-BOUNDARY-START(133144379408)
            /*object? */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144379408);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Count === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EmptyQueue);
                }
                return $.$$.System.Array.$ReadT1.call(this._array, this._head);
            }
            //--TRIMMABLE-BOUNDARY-END(133144379408)
            
            //--TRIMMABLE-BOUNDARY-START(141734314000)
            static /*Queue */ Synchronized(/*Queue*/ queue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(queue, "queue");
                return new $.$scn.System.Collections.Queue.SynchronizedQueue().$ctor$5(queue);
            }
            //--TRIMMABLE-BOUNDARY-END(141734314000)
            
            //--TRIMMABLE-BOUNDARY-START(68719869968)
            /*bool */ Contains(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719869968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = this._head;
                /*int*/ let count = this._size;
                while(count-- > 0)
                {
                    if (obj === null)
                    {
                        if ($.$$.System.Array.$ReadT1.call(this._array, index) === null)
                        {
                            return true;
                        }
                    }
                    else if ($.$$.System.Array.$ReadT1.call(this._array, index) !== null && $.$$.System.Object.Equals$1.call($.$$.System.Array.$ReadT1.call(this._array, index), obj))
                    {
                        return true;
                    }
                    index = (((index + 1) | 0)) % this._array.length;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(68719869968)
            
            //--TRIMMABLE-BOUNDARY-START(115964510224)
            /*object? */ GetElement(/*int*/ i)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.$ReadT1.call(this._array, (((this._head + i) | 0)) % this._array.length);
            }
            //--TRIMMABLE-BOUNDARY-END(115964510224)
            
            //--TRIMMABLE-BOUNDARY-START(150324248592)
            /*object?[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248592);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    return $.$$.System.Array.Empty($.$$.System.Object);
                }
                /*object[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this._size], null);
                if (this._head < this._tail)
                {
                    $.$$.System.Array.Copy$2(this._array, this._head, arr, 0, this._size);
                }
                else 
                {
                    $.$$.System.Array.Copy$2(this._array, this._head, arr, 0, ((this._array.length - this._head) | 0));
                    $.$$.System.Array.Copy$2(this._array, 0, arr, ((this._array.length - this._head) | 0), this._tail);
                }
                return arr;
            }
            //--TRIMMABLE-BOUNDARY-END(150324248592)
            
            //--TRIMMABLE-BOUNDARY-START(137439346704)
            /*void */ SetCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439346704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let newarray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [capacity], null);
                if (this._size > 0)
                {
                    if (this._head < this._tail)
                    {
                        $.$$.System.Array.Copy$2(this._array, this._head, newarray, 0, this._size);
                    }
                    else 
                    {
                        $.$$.System.Array.Copy$2(this._array, this._head, newarray, 0, ((this._array.length - this._head) | 0));
                        $.$$.System.Array.Copy$2(this._array, 0, newarray, ((this._array.length - this._head) | 0), this._tail);
                    }
                }
                this._array = newarray;
                this._head = 0;
                this._tail = (this._size === capacity) ? 0 : this._size;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(137439346704)
            
            //--TRIMMABLE-BOUNDARY-START(154619215888)
            /*void */ TrimToSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619215888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetCapacity(this._size);
            }
            //--TRIMMABLE-BOUNDARY-END(154619215888)
            
            //--TRIMMABLE-BOUNDARY-START(589840)
            static $_SynchronizedQueue;
            static get SynchronizedQueue()
            {
                let $cls = $.$scn.System.Collections.Queue;
                return $cls.$_SynchronizedQueue ??= $asm.$ncls("$scn.System.Collections.Queue.SynchronizedQueue", ($self) => class SynchronizedQueue extends $.$scn.System.Collections.Queue
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557136)
                    /*Queue*/ _q = null;
                    //--TRIMMABLE-BOUNDARY-END(4295557136)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524432)
                    /*object*/ _root = null;
                    //--TRIMMABLE-BOUNDARY-END(8590524432)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491728)
                    $ctor$5(/*Queue*/ q)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885491728);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._q = q;
                            this._root = this._q.SyncRoot;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885491728)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310001168)
                    /*bool */ get IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130131984);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310001168)
                    
                    //--TRIMMABLE-BOUNDARY-START(85899935760)
                    /*object */ get SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720066576);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._root;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85899935760)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360328208)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540197392);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.Count;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360328208)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459024)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180459024);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._q.Clear();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459024)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475426320)
                    /*object */ Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475426320);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return new $.$scn.System.Collections.Queue.SynchronizedQueue().$ctor$5($.$cast(this._q.Clone(), $.$scn.System.Collections.Queue));
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475426320)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393616)
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770393616);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.Contains(obj);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770393616)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065360912)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065360912);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._q.CopyTo(array, arrayIndex);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065360912)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950262800)
                    /*void */ Enqueue(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950262800);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._q.Enqueue(value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950262800)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295504)
                    /*object? */ Dequeue()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655295504);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.Dequeue();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655295504)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015033872)
                    /*IEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015033872);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015033872)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604968464)
                    /*object? */ Peek()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81604968464);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.Peek();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604968464)
                    
                    //--TRIMMABLE-BOUNDARY-START(90194903056)
                    /*object?[] */ ToArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90194903056);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._q.ToArray();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90194903056)
                    
                    //--TRIMMABLE-BOUNDARY-START(94489870352)
                    /*void */ TrimToSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94489870352);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._q.TrimToSize();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94489870352)
                    
                    static $h = 589840;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 393232,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310001168),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130131984,
        "f": 50364417
      },
      "n": "IsSynchronized",
      "d": 589840,
      "h": 77310001168,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310001168),
//--TRIMMABLE-BOUNDARY-START(85899935760),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066576,
        "f": 50364417
      },
      "n": "SyncRoot",
      "d": 589840,
      "h": 85899935760,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(85899935760),
//--TRIMMABLE-BOUNDARY-START(34360328208),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197392,
        "f": 50364417
      },
      "n": "Count",
      "d": 589840,
      "h": 34360328208,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360328208)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180459024),
    {
      "r": 65537,
      "n": "Clear",
      "d": 589840,
      "h": 17180459024,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180459024),
//--TRIMMABLE-BOUNDARY-START(21475426320),
    {
      "r": 131073,
      "n": "Clone",
      "d": 589840,
      "h": 21475426320,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475426320),
//--TRIMMABLE-BOUNDARY-START(25770393616),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 589840,
      "h": 25770393616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770393616),
//--TRIMMABLE-BOUNDARY-START(30065360912),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 589840,
      "h": 30065360912,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065360912),
//--TRIMMABLE-BOUNDARY-START(42950262800),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Enqueue",
      "d": 589840,
      "h": 42950262800,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950262800),
//--TRIMMABLE-BOUNDARY-START(38655295504),
    {
      "r": 131073,
      "n": "Dequeue",
      "d": 589840,
      "h": 38655295504,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655295504),
//--TRIMMABLE-BOUNDARY-START(73015033872),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 589840,
      "h": 73015033872,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015033872),
//--TRIMMABLE-BOUNDARY-START(81604968464),
    {
      "r": 131073,
      "n": "Peek",
      "d": 589840,
      "h": 81604968464,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604968464),
//--TRIMMABLE-BOUNDARY-START(90194903056),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": 589840,
      "h": 90194903056,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90194903056),
//--TRIMMABLE-BOUNDARY-START(94489870352),
    {
      "r": 65537,
      "n": "TrimToSize",
      "d": 589840,
      "h": 94489870352,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489870352)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557136),
    {
      "t": 393232,
      "n": "_q",
      "d": 589840,
      "h": 4295557136,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557136),
//--TRIMMABLE-BOUNDARY-START(8590524432),
    {
      "t": 131073,
      "n": "_root",
      "d": 589840,
      "h": 8590524432,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524432)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491728),
    {
      "p": [
        {
          "n": "q",
          "p": 393232
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 589840,
      "h": 12885491728,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885491728)
  ],
  "i": [62390273,62652417,89980929
  ],
  "d": 393232,
  "h": 589840
}; }
                    static get $b() { return $.$scn.System.Collections.Queue; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Queue.SynchronizedQueue`; }
                }, $cls, ($v) => $cls.$_SynchronizedQueue = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589840)
            
            //--TRIMMABLE-BOUNDARY-START(524304)
            static $_QueueEnumerator;
            static get QueueEnumerator()
            {
                let $cls = $.$scn.System.Collections.Queue;
                return $cls.$_QueueEnumerator ??= $asm.$ncls("$scn.System.Collections.Queue.QueueEnumerator", ($self) => class QueueEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885426192)
                    /*Queue*/ _q = null;
                    //--TRIMMABLE-BOUNDARY-END(12885426192)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590458896)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(8590458896)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180393488)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180393488)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295491600)
                    /*object?*/ _currentElement = null;
                    //--TRIMMABLE-BOUNDARY-END(4295491600)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360784)
                    $ctor$1(/*Queue*/ q)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475360784);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._q = q;
                            this._version = this._q._version;
                            this._index = 0;
                            this._currentElement = this._q._array;
                            if (this._q._size === 0)
                            {
                                this._index = -1;
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475360784)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770328080)
                    /*object */ Clone()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25770328080);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$clone(this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770328080)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950197264)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950197264);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._q._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index < 0)
                        {
                            this._currentElement = this._q._array;
                            return false;
                        }
                        this._currentElement = this._q.GetElement(this._index);
                        this._index++;
                        if (this._index === this._q._size)
                        {
                            this._index = -1;
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950197264)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065295376)
                    /*object? */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655229968);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._currentElement === this._q._array)
                        {
                            if (this._index === 0)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumNotStarted);
                            }
                            else 
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumEnded);
                            }
                        }
                        return this._currentElement;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065295376)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245164560)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245164560);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._q._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._q._size === 0)
                        {
                            this._index = -1;
                        }
                        else 
                        {
                            this._index = 0;
                        }
                        this._currentElement = this._q._array;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245164560)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947685377)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357750785);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947685377)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537619969)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537619969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537619969)
                    
                    //--TRIMMABLE-BOUNDARY-START(4384948225)
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4384948225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clone(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4384948225)
                    
                    static $h = 524304;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065295376),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655229968,
        "f": 50331649
      },
      "n": "Current",
      "d": 524304,
      "h": 30065295376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065295376)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770328080),
    {
      "r": 131073,
      "n": "Clone",
      "d": 524304,
      "h": 25770328080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328080),
//--TRIMMABLE-BOUNDARY-START(42950197264),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 524304,
      "h": 42950197264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950197264),
//--TRIMMABLE-BOUNDARY-START(47245164560),
    {
      "r": 65537,
      "n": "Reset",
      "d": 524304,
      "h": 47245164560,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245164560)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426192),
    {
      "t": 393232,
      "n": "_q",
      "d": 524304,
      "h": 12885426192,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426192),
//--TRIMMABLE-BOUNDARY-START(8590458896),
    {
      "t": 655361,
      "n": "_index",
      "d": 524304,
      "h": 8590458896,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458896),
//--TRIMMABLE-BOUNDARY-START(17180393488),
    {
      "t": 655361,
      "n": "_version",
      "d": 524304,
      "h": 17180393488,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393488),
//--TRIMMABLE-BOUNDARY-START(4295491600),
    {
      "t": 131073,
      "n": "_currentElement",
      "d": 524304,
      "h": 4295491600,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491600)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475360784),
    {
      "p": [
        {
          "n": "q",
          "p": 393232
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524304,
      "h": 21475360784,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475360784)
  ],
  "i": [62783489,89980929
  ],
  "d": 393232,
  "h": 524304
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Queue.QueueEnumerator`; }
                }, $cls, ($v) => $cls.$_QueueEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524304)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(34422128641)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012063233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422128641)
            
            //--TRIMMABLE-BOUNDARY-START(25832194049)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832194049)
            
            //--TRIMMABLE-BOUNDARY-START(4357619713)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357619713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357619713)
            
            //--TRIMMABLE-BOUNDARY-START(4384948225)
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384948225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clone(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384948225)
            
            static $h = 393232;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309804560),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489673744,
        "f": 50331777
      },
      "n": "Count",
      "d": 393232,
      "h": 77309804560,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(77309804560),
//--TRIMMABLE-BOUNDARY-START(124554444816),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079608336,
        "f": 50331777
      },
      "n": "IsSynchronized",
      "d": 393232,
      "h": 124554444816,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124554444816),
//--TRIMMABLE-BOUNDARY-START(146029281296),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669542928,
        "f": 50331777
      },
      "n": "SyncRoot",
      "d": 393232,
      "h": 146029281296,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(146029281296)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64424902672),
    {
      "r": 131073,
      "n": "Clone",
      "d": 393232,
      "h": 64424902672,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64424902672),
//--TRIMMABLE-BOUNDARY-START(60129935376),
    {
      "r": 65537,
      "n": "Clear",
      "d": 393232,
      "h": 60129935376,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60129935376),
//--TRIMMABLE-BOUNDARY-START(73014837264),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 393232,
      "h": 73014837264,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73014837264),
//--TRIMMABLE-BOUNDARY-START(85899739152),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Enqueue",
      "d": 393232,
      "h": 85899739152,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899739152),
//--TRIMMABLE-BOUNDARY-START(120259477520),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 393232,
      "h": 120259477520,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259477520),
//--TRIMMABLE-BOUNDARY-START(81604771856),
    {
      "r": 131073,
      "n": "Dequeue",
      "d": 393232,
      "h": 81604771856,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604771856),
//--TRIMMABLE-BOUNDARY-START(133144379408),
    {
      "r": 131073,
      "n": "Peek",
      "d": 393232,
      "h": 133144379408,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(133144379408),
//--TRIMMABLE-BOUNDARY-START(141734314000),
    {
      "r": 393232,
      "p": [
        {
          "n": "queue",
          "p": 393232
        }
      ],
      "n": "Synchronized",
      "d": 393232,
      "h": 141734314000,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734314000),
//--TRIMMABLE-BOUNDARY-START(68719869968),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 393232,
      "h": 68719869968,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68719869968),
//--TRIMMABLE-BOUNDARY-START(115964510224),
    {
      "r": 131073,
      "p": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "n": "GetElement",
      "d": 393232,
      "h": 115964510224,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964510224),
//--TRIMMABLE-BOUNDARY-START(150324248592),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "ToArray",
      "d": 393232,
      "h": 150324248592,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150324248592),
//--TRIMMABLE-BOUNDARY-START(137439346704),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "SetCapacity",
      "d": 393232,
      "h": 137439346704,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137439346704),
//--TRIMMABLE-BOUNDARY-START(154619215888),
    {
      "r": 65537,
      "n": "TrimToSize",
      "d": 393232,
      "h": 154619215888,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(154619215888)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360528),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_array",
      "d": 393232,
      "h": 4295360528,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360528),
//--TRIMMABLE-BOUNDARY-START(12885295120),
    {
      "t": 655361,
      "n": "_head",
      "d": 393232,
      "h": 12885295120,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885295120),
//--TRIMMABLE-BOUNDARY-START(21475229712),
    {
      "t": 655361,
      "n": "_tail",
      "d": 393232,
      "h": 21475229712,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229712),
//--TRIMMABLE-BOUNDARY-START(17180262416),
    {
      "t": 655361,
      "n": "_size",
      "d": 393232,
      "h": 17180262416,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180262416),
//--TRIMMABLE-BOUNDARY-START(8590327824),
    {
      "t": 655361,
      "n": "_growFactor",
      "d": 393232,
      "h": 8590327824,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590327824),
//--TRIMMABLE-BOUNDARY-START(25770197008),
    {
      "t": 655361,
      "n": "_version",
      "d": 393232,
      "h": 25770197008,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770197008),
//--TRIMMABLE-BOUNDARY-START(128849412112),
    {
      "t": 655361,
      "n": "MinimumGrow",
      "d": 393232,
      "h": 128849412112,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(128849412112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950066192),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393232,
      "h": 42950066192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950066192),
//--TRIMMABLE-BOUNDARY-START(55834968080),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393232,
      "h": 55834968080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834968080),
//--TRIMMABLE-BOUNDARY-START(51540000784),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "growFactor",
          "p": 1114113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393232,
      "h": 51540000784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540000784),
//--TRIMMABLE-BOUNDARY-START(47245033488),
    {
      "p": [
        {
          "n": "col",
          "p": 62390273
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393232,
      "h": 47245033488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245033488)
  ],
  "i": [62390273,62652417,89980929
  ],
  "j": [589840,524304
  ],
  "h": 393232,
  "a": [
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    },
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.Queue`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393232)
        
        
        //--TRIMMABLE-BOUNDARY-START(720912)
        $asm.$cls("$scn.System.Collections.SortedList", ($self) => class SortedList extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(231928954896)
            /*object[]*/ keys = null;
            //--TRIMMABLE-BOUNDARY-END(231928954896)
            
            //--TRIMMABLE-BOUNDARY-START(300648431632)
            /*object?[]*/ values = null;
            //--TRIMMABLE-BOUNDARY-END(300648431632)
            
            //--TRIMMABLE-BOUNDARY-START(4295688208)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(4295688208)
            
            //--TRIMMABLE-BOUNDARY-START(309238366224)
            /*int*/ version = 0;
            //--TRIMMABLE-BOUNDARY-END(309238366224)
            
            //--TRIMMABLE-BOUNDARY-START(73015164944)
            /*IComparer*/ comparer = null;
            //--TRIMMABLE-BOUNDARY-END(73015164944)
            
            //--TRIMMABLE-BOUNDARY-START(227633987600)
            /*KeyList?*/ keyList = null;
            //--TRIMMABLE-BOUNDARY-END(227633987600)
            
            //--TRIMMABLE-BOUNDARY-START(296353464336)
            /*ValueList?*/ valueList = null;
            //--TRIMMABLE-BOUNDARY-END(296353464336)
            
            //--TRIMMABLE-BOUNDARY-START(30065491984)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065491984);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.keys = $.$$.System.Array.Empty($.$$.System.Object);
                    this.values = $.$$.System.Array.Empty($.$$.System.Object);
                    this._size = 0;
                    this.comparer = new $.$$.System.Collections.Comparer().$ctor$1($.$$.System.Globalization.CultureInfo.CurrentCulture);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065491984)
            
            //--TRIMMABLE-BOUNDARY-START(51540328464)
            $ctor$6(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540328464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCapacity, "initialCapacity");
                    this.keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [initialCapacity], null);
                    this.values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [initialCapacity], null);
                    this.comparer = new $.$$.System.Collections.Comparer().$ctor$1($.$$.System.Globalization.CultureInfo.CurrentCulture);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540328464)
            
            //--TRIMMABLE-BOUNDARY-START(38655426576)
            $ctor$3(/*IComparer?*/ comparer)
            {
                this.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (comparer !== null)
                    {
                        this.comparer = comparer;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426576)
            
            //--TRIMMABLE-BOUNDARY-START(34360459280)
            $ctor$2(/*IComparer?*/ comparer, /*int*/ capacity)
            {
                this.$ctor$3(comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360459280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Capacity = capacity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459280)
            
            //--TRIMMABLE-BOUNDARY-START(47245361168)
            $ctor$5(/*IDictionary*/ d)
            {
                this.$ctor$4(d, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245361168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245361168)
            
            //--TRIMMABLE-BOUNDARY-START(42950393872)
            $ctor$4(/*IDictionary*/ d, /*IComparer?*/ comparer)
            {
                this.$ctor$2(comparer, $.$firstOf((d?.System$Collections$ICollection$Count ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("d") }));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393872);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    d.System$Collections$IDictionary$Keys.System$Collections$ICollection$CopyTo(this.keys, 0);
                    d.System$Collections$IDictionary$Values.System$Collections$ICollection$CopyTo(this.values, 0);
                    $.$$.System.Array.Sort$4(this.keys, comparer);
                    for(/*int*/ let i = 0; i < this.keys.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(this.values, d.System$Collections$IDictionary$get_Item($.$$.System.Array.$ReadT1.call(this.keys, i)), i);
                    }
                    this._size = d.System$Collections$ICollection$Count;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393872)
            
            //--TRIMMABLE-BOUNDARY-START(55835295760)
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch(this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scn.System.SR.Format$5($.$scn.System.SR.Argument_AddingDuplicate_OldAndNewKeys, this.GetKey(i), key));
                }
                this.Insert(~i, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(55835295760)
            
            //--TRIMMABLE-BOUNDARY-START(60130263056)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.keys.length;
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403791376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$scn.System.SR.ArgumentOutOfRange_SmallCapacity);
                }
                if (value !== this.keys.length)
                {
                    if (value > 0)
                    {
                        /*object[]*/ let newKeys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [value], null);
                        /*object[]*/ let newValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [value], null);
                        if (this._size > 0)
                        {
                            $.$$.System.Array.Copy(this.keys, newKeys, this._size);
                            $.$$.System.Array.Copy(this.values, newValues, this._size);
                        }
                        this.keys = newKeys;
                        this.values = newValues;
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._size === 0, "Size is not zero");
                        this.keys = $.$$.System.Array.Empty($.$$.System.Object);
                        this.values = $.$$.System.Array.Empty($.$$.System.Object);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130263056)
            
            //--TRIMMABLE-BOUNDARY-START(94490001424)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001424)
            
            //--TRIMMABLE-BOUNDARY-START(236223922192)
            /*ICollection */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyList();
            }
            //--TRIMMABLE-BOUNDARY-END(236223922192)
            
            //--TRIMMABLE-BOUNDARY-START(304943398928)
            /*ICollection */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueList();
            }
            //--TRIMMABLE-BOUNDARY-END(304943398928)
            
            //--TRIMMABLE-BOUNDARY-START(219044053008)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(219044053008)
            
            //--TRIMMABLE-BOUNDARY-START(214749085712)
            /*bool */ get IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(214749085712)
            
            //--TRIMMABLE-BOUNDARY-START(223339020304)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(223339020304)
            
            //--TRIMMABLE-BOUNDARY-START(274878627856)
            /*object */ get SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(274878627856)
            
            //--TRIMMABLE-BOUNDARY-START(64425230352)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.version++;
                $.$$.System.Array.Clear(this.keys, 0, this._size);
                $.$$.System.Array.Clear(this.values, 0, this._size);
                this._size = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230352)
            
            //--TRIMMABLE-BOUNDARY-START(68720197648)
            /*object */ Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SortedList*/ let sl = new $.$scn.System.Collections.SortedList().$ctor$6(this._size);
                $.$$.System.Array.Copy(this.keys, sl.keys, this._size);
                $.$$.System.Array.Copy(this.values, sl.values, this._size);
                sl._size = this._size;
                sl.version = this.version;
                sl.comparer = this.comparer;
                return sl;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197648)
            
            //--TRIMMABLE-BOUNDARY-START(77310132240)
            /*bool */ Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfKey(key) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132240)
            
            //--TRIMMABLE-BOUNDARY-START(81605099536)
            /*bool */ ContainsKey(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfKey(key) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099536)
            
            //--TRIMMABLE-BOUNDARY-START(85900066832)
            /*bool */ ContainsValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfValue(value) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066832)
            
            //--TRIMMABLE-BOUNDARY-START(90195034128)
            /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                if (((array.length - arrayIndex) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scn.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    /*DictionaryEntry*/ let entry = new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i));
                    array.SetValue$2(entry.Clone(), ((i + arrayIndex) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195034128)
            
            //--TRIMMABLE-BOUNDARY-START(287763529744)
            /*DebugViewDictionaryItem<object, object?>[] */ ToDebugViewDictionaryItemArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763529744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$$.System.Object, $.$$.System.Object)), null, [this.Count], null);
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    $.$$.System.Array.$WriteT1.call(array, new ($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$$.System.Object, $.$$.System.Object))().$ctor$4($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i)), i);
                }
                return array;
            }
            //--TRIMMABLE-BOUNDARY-END(287763529744)
            
            //--TRIMMABLE-BOUNDARY-START(98784968720)
            /*void */ EnsureCapacity(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newCapacity = this.keys.length === 0 ? 16 : ((this.keys.length * 2) | 0);
                if (BigInt((newCapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newCapacity = $.$$.System.Array.MaxLength;
                }
                if (newCapacity < min)
                {
                    newCapacity = min;
                }
                this.Capacity = newCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968720)
            
            //--TRIMMABLE-BOUNDARY-START(180389347344)
            /*object? */ GetByIndex(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.values, index);
            }
            //--TRIMMABLE-BOUNDARY-END(180389347344)
            
            //--TRIMMABLE-BOUNDARY-START(279173595152)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173595152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this, 0, this._size, 3/*SortedListEnumerator.DictEntry*/);
            }
            //--TRIMMABLE-BOUNDARY-END(279173595152)
            
            //--TRIMMABLE-BOUNDARY-START(184684314640)
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684314640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this, 0, this._size, 3/*SortedListEnumerator.DictEntry*/);
            }
            //--TRIMMABLE-BOUNDARY-END(184684314640)
            
            //--TRIMMABLE-BOUNDARY-START(188979281936)
            /*object */ GetKey(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979281936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.keys, index);
            }
            //--TRIMMABLE-BOUNDARY-END(188979281936)
            
            //--TRIMMABLE-BOUNDARY-START(193274249232)
            /*IList */ GetKeyList()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274249232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.keyList ??= new $.$scn.System.Collections.SortedList.KeyList().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274249232)
            
            //--TRIMMABLE-BOUNDARY-START(197569216528)
            /*IList */ GetValueList()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569216528);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.valueList ??= new $.$scn.System.Collections.SortedList.ValueList().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569216528)
            
            //--TRIMMABLE-BOUNDARY-START(283468562448)
            /*object?*/ get_Item$1(/*object*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    return $.$$.System.Array.$ReadT1.call(this.values, i);
                }
                return null;
            }
            /*void*/ set_Item$1(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch(this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    $.$$.System.Array.$WriteT1.call(this.values, value, i);
                    this.version++;
                    return;
                }
                this.Insert(~i, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468562448)
            
            //--TRIMMABLE-BOUNDARY-START(201864183824)
            /*int */ IndexOfKey(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*int*/ let ret = $.$$.System.Array.BinarySearch(this.keys, 0, this._size, key, this.comparer);
                return ret >= 0 ? ret : -1;
            }
            //--TRIMMABLE-BOUNDARY-END(201864183824)
            
            //--TRIMMABLE-BOUNDARY-START(206159151120)
            /*int */ IndexOfValue(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159151120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.IndexOf$3($.$$.System.Object, this.values, value, 0, this._size);
            }
            //--TRIMMABLE-BOUNDARY-END(206159151120)
            
            //--TRIMMABLE-BOUNDARY-START(210454118416)
            /*void */ Insert(/*int*/ index, /*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454118416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === this.keys.length)
                {
                    this.EnsureCapacity(((this._size + 1) | 0));
                }
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, index, this.keys, ((index + 1) | 0), ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, index, this.values, ((index + 1) | 0), ((this._size - index) | 0));
                }
                $.$$.System.Array.$WriteT1.call(this.keys, key, index);
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this._size++;
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(210454118416)
            
            //--TRIMMABLE-BOUNDARY-START(244813856784)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813856784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this._size--;
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, ((index + 1) | 0), this.keys, index, ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, ((index + 1) | 0), this.values, index, ((this._size - index) | 0));
                }
                $.$$.System.Array.$WriteT1.call(this.keys, null, this._size);
                $.$$.System.Array.$WriteT1.call(this.values, null, this._size);
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(244813856784)
            
            //--TRIMMABLE-BOUNDARY-START(240518889488)
            /*void */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518889488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    this.RemoveAt(i);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518889488)
            
            //--TRIMMABLE-BOUNDARY-START(266288693264)
            /*void */ SetByIndex(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(266288693264)
            
            //--TRIMMABLE-BOUNDARY-START(270583660560)
            static /*SortedList */ Synchronized(/*SortedList*/ list)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583660560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(list, "list");
                return new $.$scn.System.Collections.SortedList.SyncSortedList().$ctor$7(list);
            }
            //--TRIMMABLE-BOUNDARY-END(270583660560)
            
            //--TRIMMABLE-BOUNDARY-START(292058497040)
            /*void */ TrimToSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058497040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Capacity = this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(292058497040)
            
            //--TRIMMABLE-BOUNDARY-START(983056)
            static $_SyncSortedList;
            static get SyncSortedList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_SyncSortedList ??= $asm.$ncls("$scn.System.Collections.SortedList.SyncSortedList", ($self) => class SyncSortedList extends $.$scn.System.Collections.SortedList
                {
                    //--TRIMMABLE-BOUNDARY-START(4295950352)
                    /*SortedList*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(4295950352)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917648)
                    /*object*/ _root = null;
                    //--TRIMMABLE-BOUNDARY-END(8590917648)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885884944)
                    $ctor$7(/*SortedList*/ list)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885884944);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._list = list;
                            this._root = list.SyncRoot;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885884944)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540590608)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720459792);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.Count;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540590608)
                    
                    //--TRIMMABLE-BOUNDARY-START(180389609488)
                    /*object */ get SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111670132752);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._root;
                    }
                    //--TRIMMABLE-BOUNDARY-END(180389609488)
                    
                    //--TRIMMABLE-BOUNDARY-START(150324838416)
                    /*bool */ get IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900328976);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(150324838416)
                    
                    //--TRIMMABLE-BOUNDARY-START(146029871120)
                    /*bool */ get IsFixedSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310394384);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.IsFixedSize;
                    }
                    //--TRIMMABLE-BOUNDARY-END(146029871120)
                    
                    //--TRIMMABLE-BOUNDARY-START(154619805712)
                    /*bool */ get IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94490263568);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(154619805712)
                    
                    //--TRIMMABLE-BOUNDARY-START(184684576784)
                    /*object?*/ get_Item$1(/*object*/ key)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.get_Item$1(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void*/ set_Item$1(/*object*/ key, /*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.set_Item$1(key, value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(184684576784)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852240)
                    /*void */ Add(/*object*/ key, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180852240);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.Add(key, value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180852240)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475819536)
                    /*int */ get Capacity()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130525200);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.Capacity;
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475819536)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770786832)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770786832);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.Clear();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770786832)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065754128)
                    /*object */ Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065754128);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.Clone();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065754128)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360721424)
                    /*bool */ Contains(/*object*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360721424);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.Contains(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360721424)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655688720)
                    /*bool */ ContainsKey(/*object*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655688720);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.ContainsKey(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655688720)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950656016)
                    /*bool */ ContainsValue(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950656016);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.ContainsValue(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950656016)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245623312)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245623312);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.CopyTo(array, index);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245623312)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965100048)
                    /*object? */ GetByIndex(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115965100048);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.GetByIndex(index);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(115965100048)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260067344)
                    /*IDictionaryEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120260067344);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260067344)
                    
                    //--TRIMMABLE-BOUNDARY-START(124555034640)
                    /*object */ GetKey(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(124555034640);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.GetKey(index);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(124555034640)
                    
                    //--TRIMMABLE-BOUNDARY-START(128850001936)
                    /*IList */ GetKeyList()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128850001936);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.GetKeyList();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(128850001936)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144969232)
                    /*IList */ GetValueList()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133144969232);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.GetValueList();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144969232)
                    
                    //--TRIMMABLE-BOUNDARY-START(137439936528)
                    /*int */ IndexOfKey(/*object*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137439936528);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.IndexOfKey(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(137439936528)
                    
                    //--TRIMMABLE-BOUNDARY-START(141734903824)
                    /*int */ IndexOfValue(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(141734903824);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                return this._list.IndexOfValue(value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(141734903824)
                    
                    //--TRIMMABLE-BOUNDARY-START(163209740304)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(163209740304);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.RemoveAt(index);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(163209740304)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914773008)
                    /*void */ Remove(/*object*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(158914773008);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.Remove(key);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(158914773008)
                    
                    //--TRIMMABLE-BOUNDARY-START(176094642192)
                    /*void */ SetByIndex(/*int*/ index, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(176094642192);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.SetByIndex(index, value);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(176094642192)
                    
                    //--TRIMMABLE-BOUNDARY-START(188979544080)
                    /*DebugViewDictionaryItem<object, object?>[] */ ToDebugViewDictionaryItemArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(188979544080);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.ToDebugViewDictionaryItemArray();
                    }
                    //--TRIMMABLE-BOUNDARY-END(188979544080)
                    
                    //--TRIMMABLE-BOUNDARY-START(193274511376)
                    /*void */ TrimToSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(193274511376);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this._root)
                            {
                                this._list.TrimToSize();
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(193274511376)
                    
                    static $h = 983056;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 720912,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540590608),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720459792,
        "f": 50364417
      },
      "n": "Count",
      "d": 983056,
      "h": 51540590608,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(51540590608),
//--TRIMMABLE-BOUNDARY-START(180389609488),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670132752,
        "f": 50364417
      },
      "n": "SyncRoot",
      "d": 983056,
      "h": 180389609488,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389609488),
//--TRIMMABLE-BOUNDARY-START(150324838416),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900328976,
        "f": 50364417
      },
      "n": "IsReadOnly",
      "d": 983056,
      "h": 150324838416,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324838416),
//--TRIMMABLE-BOUNDARY-START(146029871120),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310394384,
        "f": 50364417
      },
      "n": "IsFixedSize",
      "d": 983056,
      "h": 146029871120,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029871120),
//--TRIMMABLE-BOUNDARY-START(154619805712),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490263568,
        "f": 50364417
      },
      "n": "IsSynchronized",
      "d": 983056,
      "h": 154619805712,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(154619805712),
//--TRIMMABLE-BOUNDARY-START(184684576784),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080198160,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799674896,
        "f": 83918849
      },
      "n": "Item",
      "o": "@$1",
      "d": 983056,
      "h": 184684576784,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684576784),
//--TRIMMABLE-BOUNDARY-START(21475819536),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130525200,
        "f": 50364417
      },
      "n": "Capacity",
      "d": 983056,
      "h": 21475819536,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475819536)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180852240),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 983056,
      "h": 17180852240,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180852240),
//--TRIMMABLE-BOUNDARY-START(25770786832),
    {
      "r": 65537,
      "n": "Clear",
      "d": 983056,
      "h": 25770786832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770786832),
//--TRIMMABLE-BOUNDARY-START(30065754128),
    {
      "r": 131073,
      "n": "Clone",
      "d": 983056,
      "h": 30065754128,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065754128),
//--TRIMMABLE-BOUNDARY-START(34360721424),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 983056,
      "h": 34360721424,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360721424),
//--TRIMMABLE-BOUNDARY-START(38655688720),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "ContainsKey",
      "d": 983056,
      "h": 38655688720,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655688720),
//--TRIMMABLE-BOUNDARY-START(42950656016),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "ContainsValue",
      "d": 983056,
      "h": 42950656016,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950656016),
//--TRIMMABLE-BOUNDARY-START(47245623312),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 983056,
      "h": 47245623312,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245623312),
//--TRIMMABLE-BOUNDARY-START(115965100048),
    {
      "r": 131073,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetByIndex",
      "d": 983056,
      "h": 115965100048,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965100048),
//--TRIMMABLE-BOUNDARY-START(120260067344),
    {
      "r": 62586881,
      "n": "GetEnumerator",
      "d": 983056,
      "h": 120260067344,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260067344),
//--TRIMMABLE-BOUNDARY-START(124555034640),
    {
      "r": 131073,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetKey",
      "d": 983056,
      "h": 124555034640,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555034640),
//--TRIMMABLE-BOUNDARY-START(128850001936),
    {
      "r": 62980097,
      "n": "GetKeyList",
      "d": 983056,
      "h": 128850001936,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850001936),
//--TRIMMABLE-BOUNDARY-START(133144969232),
    {
      "r": 62980097,
      "n": "GetValueList",
      "d": 983056,
      "h": 133144969232,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144969232),
//--TRIMMABLE-BOUNDARY-START(137439936528),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "IndexOfKey",
      "d": 983056,
      "h": 137439936528,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137439936528),
//--TRIMMABLE-BOUNDARY-START(141734903824),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IndexOfValue",
      "d": 983056,
      "h": 141734903824,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734903824),
//--TRIMMABLE-BOUNDARY-START(163209740304),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 983056,
      "h": 163209740304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209740304),
//--TRIMMABLE-BOUNDARY-START(158914773008),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 983056,
      "h": 158914773008,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914773008),
//--TRIMMABLE-BOUNDARY-START(176094642192),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetByIndex",
      "d": 983056,
      "h": 176094642192,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094642192),
//--TRIMMABLE-BOUNDARY-START(188979544080),
    {
      "r": $.$typeArray($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$$.System.Object, $.$$.System.Object)).$h,
      "n": "ToDebugViewDictionaryItemArray",
      "d": 983056,
      "h": 188979544080,
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(188979544080),
//--TRIMMABLE-BOUNDARY-START(193274511376),
    {
      "r": 65537,
      "n": "TrimToSize",
      "d": 983056,
      "h": 193274511376,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274511376)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950352),
    {
      "t": 720912,
      "n": "_list",
      "d": 983056,
      "h": 4295950352,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950352),
//--TRIMMABLE-BOUNDARY-START(8590917648),
    {
      "t": 131073,
      "n": "_root",
      "d": 983056,
      "h": 8590917648,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917648)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885884944),
    {
      "p": [
        {
          "n": "list",
          "p": 720912
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 983056,
      "h": 12885884944,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885884944)
  ],
  "i": [62521345,62390273,62652417,89980929
  ],
  "d": 720912,
  "h": 983056,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$scn.System.Collections.SortedList; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.SortedList.SyncSortedList`; }
                }, $cls, ($v) => $cls.$_SyncSortedList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983056)
            
            //--TRIMMABLE-BOUNDARY-START(917520)
            static $_SortedListEnumerator;
            static get SortedListEnumerator()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_SortedListEnumerator ??= $asm.$ncls("$scn.System.Collections.SortedList.SortedListEnumerator", ($self) => class SortedListEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721296)
                    /*SortedList*/ _sortedList = null;
                    //--TRIMMABLE-BOUNDARY-END(25770721296)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754000)
                    /*object*/ _key = null;
                    //--TRIMMABLE-BOUNDARY-END(21475754000)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655888)
                    /*object?*/ _value = null;
                    //--TRIMMABLE-BOUNDARY-END(34360655888)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786704)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180786704)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065688592)
                    /*int*/ _startIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(30065688592)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590852112)
                    /*int*/ _endIndex = 0;
                    //--TRIMMABLE-BOUNDARY-END(8590852112)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655623184)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(38655623184)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884816)
                    /*bool*/ _current = false;
                    //--TRIMMABLE-BOUNDARY-END(4295884816)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819408)
                    /*int*/ _getObjectRetType = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885819408)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080132624)
                    /*int*/ static Keys$1 = 1;
                    //--TRIMMABLE-BOUNDARY-END(103080132624)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260001808)
                    /*int*/ static Values = 2;
                    //--TRIMMABLE-BOUNDARY-END(120260001808)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835492368)
                    /*int*/ static DictEntry = 3;
                    //--TRIMMABLE-BOUNDARY-END(55835492368)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950590480)
                    $ctor$1(/*SortedList*/ sortedList, /*int*/ index, /*int*/ count, /*int*/ getObjRetType)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42950590480);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sortedList = sortedList;
                            this._index = index;
                            this._startIndex = index;
                            this._endIndex = ((index + count) | 0);
                            this._version = sortedList.version;
                            this._getObjectRetType = getObjRetType;
                            this._current = false;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950590480)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245557776)
                    /*object */ Clone()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245557776);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$clone(this);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245557776)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785165328)
                    /*object */ get Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900263440);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785165328)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375099920)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107375099920);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index < this._endIndex)
                        {
                            this._key = $.$$.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._value = $.$$.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            this._current = true;
                            return true;
                        }
                        this._key = null;
                        this._value = null;
                        this._current = false;
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375099920)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130459664)
                    /*DictionaryEntry */ get Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310328848);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3(this._key, this._value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130459664)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540525072)
                    /*object? */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720394256);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current === false)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getObjectRetType === 1/*Keys*/)
                        {
                            return this._key;
                        }
                        else if (this._getObjectRetType === 2/*Values*/)
                        {
                            return this._value;
                        }
                        else 
                        {
                            return new $.$$.System.Collections.DictionaryEntry().$ctor$3(this._key, this._value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540525072)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965034512)
                    /*object? */ get Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94490198032);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115965034512)
                    
                    //--TRIMMABLE-BOUNDARY-START(111670067216)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111670067216);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = this._startIndex;
                        this._current = false;
                        this._key = null;
                        this._value = null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(111670067216)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537423361)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34422325249);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537423361)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127357953)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717292545);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127357953)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947488769)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357554177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947488769)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947685377)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357750785);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947685377)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537619969)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537619969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537619969)
                    
                    //--TRIMMABLE-BOUNDARY-START(4384948225)
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4384948225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clone(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4384948225)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(21475754000)
                        this._key = null;
                        //--TRIMMABLE-BOUNDARY-END(21475754000)
                        
                    }
                    static $h = 917520;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(98785165328),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900263440,
        "f": 50331649
      },
      "n": "Key",
      "d": 917520,
      "h": 98785165328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785165328),
//--TRIMMABLE-BOUNDARY-START(60130459664),
    {
      "p": 56688641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310328848,
        "f": 50331649
      },
      "n": "Entry",
      "d": 917520,
      "h": 60130459664,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130459664),
//--TRIMMABLE-BOUNDARY-START(51540525072),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720394256,
        "f": 50331649
      },
      "n": "Current",
      "d": 917520,
      "h": 51540525072,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540525072),
//--TRIMMABLE-BOUNDARY-START(115965034512),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490198032,
        "f": 50331649
      },
      "n": "Value",
      "d": 917520,
      "h": 115965034512,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115965034512)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245557776),
    {
      "r": 131073,
      "n": "Clone",
      "d": 917520,
      "h": 47245557776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557776),
//--TRIMMABLE-BOUNDARY-START(107375099920),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 917520,
      "h": 107375099920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375099920),
//--TRIMMABLE-BOUNDARY-START(111670067216),
    {
      "r": 65537,
      "n": "Reset",
      "d": 917520,
      "h": 111670067216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670067216)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770721296),
    {
      "t": 720912,
      "n": "_sortedList",
      "d": 917520,
      "h": 25770721296,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770721296),
//--TRIMMABLE-BOUNDARY-START(21475754000),
    {
      "t": 131073,
      "n": "_key",
      "d": 917520,
      "h": 21475754000,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475754000),
//--TRIMMABLE-BOUNDARY-START(34360655888),
    {
      "t": 131073,
      "n": "_value",
      "d": 917520,
      "h": 34360655888,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360655888),
//--TRIMMABLE-BOUNDARY-START(17180786704),
    {
      "t": 655361,
      "n": "_index",
      "d": 917520,
      "h": 17180786704,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180786704),
//--TRIMMABLE-BOUNDARY-START(30065688592),
    {
      "t": 655361,
      "n": "_startIndex",
      "d": 917520,
      "h": 30065688592,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065688592),
//--TRIMMABLE-BOUNDARY-START(8590852112),
    {
      "t": 655361,
      "n": "_endIndex",
      "d": 917520,
      "h": 8590852112,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852112),
//--TRIMMABLE-BOUNDARY-START(38655623184),
    {
      "t": 655361,
      "n": "_version",
      "d": 917520,
      "h": 38655623184,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655623184),
//--TRIMMABLE-BOUNDARY-START(4295884816),
    {
      "t": 262145,
      "n": "_current",
      "d": 917520,
      "h": 4295884816,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884816),
//--TRIMMABLE-BOUNDARY-START(12885819408),
    {
      "t": 655361,
      "n": "_getObjectRetType",
      "d": 917520,
      "h": 12885819408,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819408),
//--TRIMMABLE-BOUNDARY-START(103080132624),
    {
      "t": 655361,
      "n": "Keys",
      "o": "@$1",
      "d": 917520,
      "h": 103080132624,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080132624),
//--TRIMMABLE-BOUNDARY-START(120260001808),
    {
      "t": 655361,
      "n": "Values",
      "d": 917520,
      "h": 120260001808,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120260001808),
//--TRIMMABLE-BOUNDARY-START(55835492368),
    {
      "t": 655361,
      "n": "DictEntry",
      "d": 917520,
      "h": 55835492368,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835492368)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950590480),
    {
      "p": [
        {
          "n": "sortedList",
          "p": 720912
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "getObjRetType",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917520,
      "h": 42950590480,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42950590480)
  ],
  "i": [62586881,62783489,89980929
  ],
  "d": 720912,
  "h": 917520
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.SortedList.SortedListEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917520)
            
            //--TRIMMABLE-BOUNDARY-START(786448)
            static $_KeyList;
            static get KeyList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_KeyList ??= $asm.$ncls("$scn.System.Collections.SortedList.KeyList", ($self) => class KeyList extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(124554838032)
                    /*SortedList*/ sortedList = null;
                    //--TRIMMABLE-BOUNDARY-END(124554838032)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295753744)
                    $ctor$1(/*SortedList*/ sortedList)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295753744);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.sortedList = sortedList;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295753744)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770590224)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360524816);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList._size;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770590224)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785034256)
                    /*bool */ get IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540394000);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785034256)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490066960)
                    /*bool */ get IsFixedSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950459408);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490066960)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080001552)
                    /*bool */ get IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130328592);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.IsSynchronized;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080001552)
                    
                    //--TRIMMABLE-BOUNDARY-START(128849805328)
                    /*object */ get SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310197776);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128849805328)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721040)
                    /*int */ Add(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590721040);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721040)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688336)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885688336);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688336)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655632)
                    /*bool */ Contains(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655632);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.Contains(key);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655632)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475622928)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475622928);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        $.$$.System.Array.Copy$2(this.sortedList.keys, 0, array, arrayIndex, this.sortedList.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475622928)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195099664)
                    /*void */ Insert(/*int*/ index, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90195099664);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195099664)
                    
                    //--TRIMMABLE-BOUNDARY-START(133144772624)
                    /*object?*/ get_Item$1(/*int*/ index)
                    {
                        return this.sortedList.GetKey(index);
                    }
                    /*void*/ set_Item$1(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_KeyCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(133144772624)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605165072)
                    /*IEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605165072);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this.sortedList, 0, this.sortedList.Count, 1/*SortedListEnumerator.Keys*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605165072)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900132368)
                    /*int */ IndexOf(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900132368);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                        /*int*/ let i = $.$$.System.Array.BinarySearch(this.sortedList.keys, 0, this.sortedList.Count, key, this.sortedList.comparer);
                        if (i >= 0)
                        {
                            return i;
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900132368)
                    
                    //--TRIMMABLE-BOUNDARY-START(107374968848)
                    /*void */ Remove(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107374968848);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(107374968848)
                    
                    //--TRIMMABLE-BOUNDARY-START(111669936144)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111669936144);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(111669936144)
                    
                    //--TRIMMABLE-BOUNDARY-START(38717685761)
                    //Generated interface implemetation for System.Collections.IList.this[int].get
                    System$Collections$IList$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717685761);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38717685761)
                    
                    //--TRIMMABLE-BOUNDARY-START(73077424129)
                    //Generated interface implemetation for System.Collections.IList.this[int].set
                    System$Collections$IList$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73077424129);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73077424129)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357947393)
                    //Generated interface implemetation for System.Collections.IList.Add(object?)
                    System$Collections$IList$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357947393);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357947393)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947881985)
                    //Generated interface implemetation for System.Collections.IList.Contains(object?)
                    System$Collections$IList$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12947881985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947881985)
                    
                    //--TRIMMABLE-BOUNDARY-START(8652914689)
                    //Generated interface implemetation for System.Collections.IList.Clear()
                    System$Collections$IList$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652914689);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8652914689)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127751169)
                    //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
                    get System$Collections$IList$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55897554945);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127751169)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537816577)
                    //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
                    get System$Collections$IList$IsFixedSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51602587649);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsFixedSize;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537816577)
                    
                    //--TRIMMABLE-BOUNDARY-START(43012653057)
                    //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
                    System$Collections$IList$IndexOf()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43012653057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IndexOf(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(43012653057)
                    
                    //--TRIMMABLE-BOUNDARY-START(47307620353)
                    //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
                    System$Collections$IList$Insert()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47307620353);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Insert(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47307620353)
                    
                    //--TRIMMABLE-BOUNDARY-START(60192522241)
                    //Generated interface implemetation for System.Collections.IList.Remove(object?)
                    System$Collections$IList$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60192522241);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60192522241)
                    
                    //--TRIMMABLE-BOUNDARY-START(64487489537)
                    //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
                    System$Collections$IList$RemoveAt()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64487489537);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveAt(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64487489537)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357357569)
                    //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
                    System$Collections$ICollection$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357357569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357357569)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    //--TRIMMABLE-BOUNDARY-START(34422128641)
                    //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
                    get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43012063233);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34422128641)
                    
                    //--TRIMMABLE-BOUNDARY-START(25832194049)
                    //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
                    get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717095937);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsSynchronized;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25832194049)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357619713)
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357619713)
                    
                    static $h = 786448;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770590224),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360524816,
        "f": 50331649
      },
      "n": "Count",
      "d": 786448,
      "h": 25770590224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770590224),
//--TRIMMABLE-BOUNDARY-START(98785034256),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540394000,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 786448,
      "h": 98785034256,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785034256),
//--TRIMMABLE-BOUNDARY-START(94490066960),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950459408,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 786448,
      "h": 94490066960,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490066960),
//--TRIMMABLE-BOUNDARY-START(103080001552),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130328592,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 786448,
      "h": 103080001552,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080001552),
//--TRIMMABLE-BOUNDARY-START(128849805328),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310197776,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 786448,
      "h": 128849805328,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849805328),
//--TRIMMABLE-BOUNDARY-START(133144772624),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720263184,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259870736,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 786448,
      "h": 133144772624,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144772624)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590721040),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 786448,
      "h": 8590721040,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721040),
//--TRIMMABLE-BOUNDARY-START(12885688336),
    {
      "r": 65537,
      "n": "Clear",
      "d": 786448,
      "h": 12885688336,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688336),
//--TRIMMABLE-BOUNDARY-START(17180655632),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 786448,
      "h": 17180655632,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655632),
//--TRIMMABLE-BOUNDARY-START(21475622928),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 786448,
      "h": 21475622928,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622928),
//--TRIMMABLE-BOUNDARY-START(90195099664),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 786448,
      "h": 90195099664,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195099664),
//--TRIMMABLE-BOUNDARY-START(81605165072),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 786448,
      "h": 81605165072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605165072),
//--TRIMMABLE-BOUNDARY-START(85900132368),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "IndexOf",
      "d": 786448,
      "h": 85900132368,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900132368),
//--TRIMMABLE-BOUNDARY-START(107374968848),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 786448,
      "h": 107374968848,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374968848),
//--TRIMMABLE-BOUNDARY-START(111669936144),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 786448,
      "h": 111669936144,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669936144)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124554838032),
    {
      "t": 720912,
      "n": "sortedList",
      "d": 786448,
      "h": 124554838032,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124554838032)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753744),
    {
      "p": [
        {
          "n": "sortedList",
          "p": 720912
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786448,
      "h": 4295753744,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295753744)
  ],
  "i": [62980097,62390273,62652417
  ],
  "d": 720912,
  "h": 786448,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.SortedList.KeyList`; }
                }, $cls, ($v) => $cls.$_KeyList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786448)
            
            //--TRIMMABLE-BOUNDARY-START(1048592)
            static $_ValueList;
            static get ValueList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_ValueList ??= $asm.$ncls("$scn.System.Collections.SortedList.ValueList", ($self) => class ValueList extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(124555100176)
                    /*SortedList*/ sortedList = null;
                    //--TRIMMABLE-BOUNDARY-END(124555100176)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296015888)
                    $ctor$1(/*SortedList*/ sortedList)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296015888);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.sortedList = sortedList;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296015888)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770852368)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360786960);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList._size;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770852368)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785296400)
                    /*bool */ get IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540656144);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785296400)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490329104)
                    /*bool */ get IsFixedSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950721552);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490329104)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080263696)
                    /*bool */ get IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130590736);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.IsSynchronized;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080263696)
                    
                    //--TRIMMABLE-BOUNDARY-START(128850067472)
                    /*object */ get SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310459920);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(128850067472)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590983184)
                    /*int */ Add(/*object?*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590983184);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590983184)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885950480)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885950480);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885950480)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180917776)
                    /*bool */ Contains(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180917776);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.sortedList.ContainsValue(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180917776)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475885072)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475885072);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        $.$$.System.Array.Copy$2(this.sortedList.values, 0, array, arrayIndex, this.sortedList.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475885072)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195361808)
                    /*void */ Insert(/*int*/ index, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90195361808);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195361808)
                    
                    //--TRIMMABLE-BOUNDARY-START(133145034768)
                    /*object?*/ get_Item$1(/*int*/ index)
                    {
                        return this.sortedList.GetByIndex(index);
                    }
                    /*void*/ set_Item$1(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(133145034768)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605427216)
                    /*IEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605427216);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this.sortedList, 0, this.sortedList.Count, 2/*SortedListEnumerator.Values*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605427216)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900394512)
                    /*int */ IndexOf(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900394512);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.Array.IndexOf$3($.$$.System.Object, this.sortedList.values, value, 0, this.sortedList.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900394512)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375230992)
                    /*void */ Remove(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(107375230992);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375230992)
                    
                    //--TRIMMABLE-BOUNDARY-START(111670198288)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111670198288);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(111670198288)
                    
                    //--TRIMMABLE-BOUNDARY-START(38717685761)
                    //Generated interface implemetation for System.Collections.IList.this[int].get
                    System$Collections$IList$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717685761);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38717685761)
                    
                    //--TRIMMABLE-BOUNDARY-START(73077424129)
                    //Generated interface implemetation for System.Collections.IList.this[int].set
                    System$Collections$IList$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73077424129);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73077424129)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357947393)
                    //Generated interface implemetation for System.Collections.IList.Add(object?)
                    System$Collections$IList$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357947393);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357947393)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947881985)
                    //Generated interface implemetation for System.Collections.IList.Contains(object?)
                    System$Collections$IList$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12947881985);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947881985)
                    
                    //--TRIMMABLE-BOUNDARY-START(8652914689)
                    //Generated interface implemetation for System.Collections.IList.Clear()
                    System$Collections$IList$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652914689);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8652914689)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127751169)
                    //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
                    get System$Collections$IList$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55897554945);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127751169)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537816577)
                    //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
                    get System$Collections$IList$IsFixedSize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51602587649);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsFixedSize;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537816577)
                    
                    //--TRIMMABLE-BOUNDARY-START(43012653057)
                    //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
                    System$Collections$IList$IndexOf()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43012653057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IndexOf(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(43012653057)
                    
                    //--TRIMMABLE-BOUNDARY-START(47307620353)
                    //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
                    System$Collections$IList$Insert()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47307620353);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Insert(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47307620353)
                    
                    //--TRIMMABLE-BOUNDARY-START(60192522241)
                    //Generated interface implemetation for System.Collections.IList.Remove(object?)
                    System$Collections$IList$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60192522241);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60192522241)
                    
                    //--TRIMMABLE-BOUNDARY-START(64487489537)
                    //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
                    System$Collections$IList$RemoveAt()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64487489537);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveAt(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64487489537)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357357569)
                    //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
                    System$Collections$ICollection$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357357569);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357357569)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    //--TRIMMABLE-BOUNDARY-START(34422128641)
                    //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
                    get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43012063233);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34422128641)
                    
                    //--TRIMMABLE-BOUNDARY-START(25832194049)
                    //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
                    get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717095937);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsSynchronized;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25832194049)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357619713)
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357619713)
                    
                    static $h = 1048592;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770852368),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360786960,
        "f": 50331649
      },
      "n": "Count",
      "d": 1048592,
      "h": 25770852368,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770852368),
//--TRIMMABLE-BOUNDARY-START(98785296400),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540656144,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1048592,
      "h": 98785296400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785296400),
//--TRIMMABLE-BOUNDARY-START(94490329104),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950721552,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 1048592,
      "h": 94490329104,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490329104),
//--TRIMMABLE-BOUNDARY-START(103080263696),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130590736,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 1048592,
      "h": 103080263696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080263696),
//--TRIMMABLE-BOUNDARY-START(128850067472),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310459920,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 1048592,
      "h": 128850067472,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128850067472),
//--TRIMMABLE-BOUNDARY-START(133145034768),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720525328,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120260132880,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1048592,
      "h": 133145034768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145034768)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983184),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 1048592,
      "h": 8590983184,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590983184),
//--TRIMMABLE-BOUNDARY-START(12885950480),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1048592,
      "h": 12885950480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885950480),
//--TRIMMABLE-BOUNDARY-START(17180917776),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 1048592,
      "h": 17180917776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917776),
//--TRIMMABLE-BOUNDARY-START(21475885072),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1048592,
      "h": 21475885072,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885072),
//--TRIMMABLE-BOUNDARY-START(90195361808),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 1048592,
      "h": 90195361808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195361808),
//--TRIMMABLE-BOUNDARY-START(81605427216),
    {
      "r": 62783489,
      "n": "GetEnumerator",
      "d": 1048592,
      "h": 81605427216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605427216),
//--TRIMMABLE-BOUNDARY-START(85900394512),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IndexOf",
      "d": 1048592,
      "h": 85900394512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900394512),
//--TRIMMABLE-BOUNDARY-START(107375230992),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 1048592,
      "h": 107375230992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375230992),
//--TRIMMABLE-BOUNDARY-START(111670198288),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1048592,
      "h": 111670198288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111670198288)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(124555100176),
    {
      "t": 720912,
      "n": "sortedList",
      "d": 1048592,
      "h": 124555100176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(124555100176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015888),
    {
      "p": [
        {
          "n": "sortedList",
          "p": 720912
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048592,
      "h": 4296015888,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296015888)
  ],
  "i": [62980097,62390273,62652417
  ],
  "d": 720912,
  "h": 1048592,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.SortedList.ValueList`; }
                }, $cls, ($v) => $cls.$_ValueList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048592)
            
            //--TRIMMABLE-BOUNDARY-START(38717227009)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717227009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38717227009)
            
            //--TRIMMABLE-BOUNDARY-START(85961867265)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85961867265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85961867265)
            
            //--TRIMMABLE-BOUNDARY-START(47307161601)
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73076965377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(47307161601)
            
            //--TRIMMABLE-BOUNDARY-START(55897096193)
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94551801857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(55897096193)
            
            //--TRIMMABLE-BOUNDARY-START(12947423233)
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12947423233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12947423233)
            
            //--TRIMMABLE-BOUNDARY-START(4357488641)
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357488641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(8652455937)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652455937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652455937)
            
            //--TRIMMABLE-BOUNDARY-START(30127292417)
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68781998081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30127292417)
            
            //--TRIMMABLE-BOUNDARY-START(21537357825)
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64487030785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(21537357825)
            
            //--TRIMMABLE-BOUNDARY-START(60192063489)
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60192063489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60192063489)
            
            //--TRIMMABLE-BOUNDARY-START(77371932673)
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77371932673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(77371932673)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(34422128641)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43012063233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34422128641)
            
            //--TRIMMABLE-BOUNDARY-START(25832194049)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832194049)
            
            //--TRIMMABLE-BOUNDARY-START(4384948225)
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4384948225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clone(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4384948225)
            
            static $h = 720912;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60130263056),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903312,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253403791376,
        "f": 83886209
      },
      "n": "Capacity",
      "d": 720912,
      "h": 60130263056,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130263056),
//--TRIMMABLE-BOUNDARY-START(94490001424),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837904,
        "f": 50331777
      },
      "n": "Count",
      "d": 720912,
      "h": 94490001424,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94490001424),
//--TRIMMABLE-BOUNDARY-START(236223922192),
    {
      "p": 62390273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914510864,
        "f": 50331777
      },
      "n": "Keys",
      "o": "@$1",
      "d": 720912,
      "h": 236223922192,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(236223922192),
//--TRIMMABLE-BOUNDARY-START(304943398928),
    {
      "p": 62390273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094380048,
        "f": 50331777
      },
      "n": "Values",
      "d": 720912,
      "h": 304943398928,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(304943398928),
//--TRIMMABLE-BOUNDARY-START(219044053008),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144707088,
        "f": 50331777
      },
      "n": "IsReadOnly",
      "d": 720912,
      "h": 219044053008,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(219044053008),
//--TRIMMABLE-BOUNDARY-START(214749085712),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554772496,
        "f": 50331777
      },
      "n": "IsFixedSize",
      "d": 720912,
      "h": 214749085712,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(214749085712),
//--TRIMMABLE-BOUNDARY-START(223339020304),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734641680,
        "f": 50331777
      },
      "n": "IsSynchronized",
      "d": 720912,
      "h": 223339020304,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(223339020304),
//--TRIMMABLE-BOUNDARY-START(274878627856),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504445456,
        "f": 50331777
      },
      "n": "SyncRoot",
      "d": 720912,
      "h": 274878627856,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(274878627856),
//--TRIMMABLE-BOUNDARY-START(283468562448),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324576272,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261993725968,
        "f": 83886209
      },
      "n": "Item",
      "o": "@$1",
      "d": 720912,
      "h": 283468562448,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(283468562448)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835295760),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 720912,
      "h": 55835295760,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835295760),
//--TRIMMABLE-BOUNDARY-START(64425230352),
    {
      "r": 65537,
      "n": "Clear",
      "d": 720912,
      "h": 64425230352,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425230352),
//--TRIMMABLE-BOUNDARY-START(68720197648),
    {
      "r": 131073,
      "n": "Clone",
      "d": 720912,
      "h": 68720197648,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720197648),
//--TRIMMABLE-BOUNDARY-START(77310132240),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 720912,
      "h": 77310132240,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77310132240),
//--TRIMMABLE-BOUNDARY-START(81605099536),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "ContainsKey",
      "d": 720912,
      "h": 81605099536,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81605099536),
//--TRIMMABLE-BOUNDARY-START(85900066832),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "ContainsValue",
      "d": 720912,
      "h": 85900066832,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900066832),
//--TRIMMABLE-BOUNDARY-START(90195034128),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "arrayIndex",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 720912,
      "h": 90195034128,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90195034128),
//--TRIMMABLE-BOUNDARY-START(287763529744),
    {
      "r": $.$typeArray($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$$.System.Object, $.$$.System.Object)).$h,
      "n": "ToDebugViewDictionaryItemArray",
      "d": 720912,
      "h": 287763529744,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(287763529744),
//--TRIMMABLE-BOUNDARY-START(98784968720),
    {
      "r": 65537,
      "p": [
        {
          "n": "min",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 720912,
      "h": 98784968720,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784968720),
//--TRIMMABLE-BOUNDARY-START(180389347344),
    {
      "r": 131073,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetByIndex",
      "d": 720912,
      "h": 180389347344,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(180389347344),
//--TRIMMABLE-BOUNDARY-START(184684314640),
    {
      "r": 62586881,
      "n": "GetEnumerator",
      "d": 720912,
      "h": 184684314640,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(184684314640),
//--TRIMMABLE-BOUNDARY-START(188979281936),
    {
      "r": 131073,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetKey",
      "d": 720912,
      "h": 188979281936,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(188979281936),
//--TRIMMABLE-BOUNDARY-START(193274249232),
    {
      "r": 62980097,
      "n": "GetKeyList",
      "d": 720912,
      "h": 193274249232,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(193274249232),
//--TRIMMABLE-BOUNDARY-START(197569216528),
    {
      "r": 62980097,
      "n": "GetValueList",
      "d": 720912,
      "h": 197569216528,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(197569216528),
//--TRIMMABLE-BOUNDARY-START(201864183824),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "IndexOfKey",
      "d": 720912,
      "h": 201864183824,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(201864183824),
//--TRIMMABLE-BOUNDARY-START(206159151120),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IndexOfValue",
      "d": 720912,
      "h": 206159151120,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(206159151120),
//--TRIMMABLE-BOUNDARY-START(210454118416),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 720912,
      "h": 210454118416,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454118416),
//--TRIMMABLE-BOUNDARY-START(244813856784),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 720912,
      "h": 244813856784,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(244813856784),
//--TRIMMABLE-BOUNDARY-START(240518889488),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 720912,
      "h": 240518889488,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(240518889488),
//--TRIMMABLE-BOUNDARY-START(266288693264),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetByIndex",
      "d": 720912,
      "h": 266288693264,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(266288693264),
//--TRIMMABLE-BOUNDARY-START(270583660560),
    {
      "r": 720912,
      "p": [
        {
          "n": "list",
          "p": 720912
        }
      ],
      "n": "Synchronized",
      "d": 720912,
      "h": 270583660560,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583660560),
//--TRIMMABLE-BOUNDARY-START(292058497040),
    {
      "r": 65537,
      "n": "TrimToSize",
      "d": 720912,
      "h": 292058497040,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(292058497040)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(231928954896),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "keys",
      "d": 720912,
      "h": 231928954896,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(231928954896),
//--TRIMMABLE-BOUNDARY-START(300648431632),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "values",
      "d": 720912,
      "h": 300648431632,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(300648431632),
//--TRIMMABLE-BOUNDARY-START(4295688208),
    {
      "t": 655361,
      "n": "_size",
      "d": 720912,
      "h": 4295688208,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688208),
//--TRIMMABLE-BOUNDARY-START(309238366224),
    {
      "t": 655361,
      "n": "version",
      "d": 720912,
      "h": 309238366224,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(309238366224),
//--TRIMMABLE-BOUNDARY-START(73015164944),
    {
      "t": 62455809,
      "n": "comparer",
      "d": 720912,
      "h": 73015164944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(73015164944),
//--TRIMMABLE-BOUNDARY-START(227633987600),
    {
      "t": 786448,
      "n": "keyList",
      "d": 720912,
      "h": 227633987600,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(227633987600),
//--TRIMMABLE-BOUNDARY-START(296353464336),
    {
      "t": 1048592,
      "n": "valueList",
      "d": 720912,
      "h": 296353464336,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(296353464336)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065491984),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720912,
      "h": 30065491984,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065491984),
//--TRIMMABLE-BOUNDARY-START(51540328464),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 720912,
      "h": 51540328464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540328464),
//--TRIMMABLE-BOUNDARY-START(38655426576),
    {
      "p": [
        {
          "n": "comparer",
          "p": 62455809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720912,
      "h": 38655426576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426576),
//--TRIMMABLE-BOUNDARY-START(34360459280),
    {
      "p": [
        {
          "n": "comparer",
          "p": 62455809
        },
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720912,
      "h": 34360459280,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360459280),
//--TRIMMABLE-BOUNDARY-START(47245361168),
    {
      "p": [
        {
          "n": "d",
          "p": 62521345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720912,
      "h": 47245361168,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361168),
//--TRIMMABLE-BOUNDARY-START(42950393872),
    {
      "p": [
        {
          "n": "d",
          "p": 62521345
        },
        {
          "n": "comparer",
          "p": 62455809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720912,
      "h": 42950393872,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393872)
  ],
  "i": [62521345,62390273,62652417,89980929
  ],
  "j": [983056,917520,786448,1048592
  ],
  "h": 720912,
  "a": [
    {
      "t": 70713345,
      "c": 21545549825,
      "a": [
        {
          "v": null,
          "t": 187760641
        }
      ]
    },
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "Count = {Count}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.SortedList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720912)
        
        
        //--TRIMMABLE-BOUNDARY-START(327696)
        $asm.$str("$scn.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$scn.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21475164176)
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164176)
            
            //--TRIMMABLE-BOUNDARY-START(17180196880)
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196880)
            
            //--TRIMMABLE-BOUNDARY-START(42950000656)
            /*TKey*/ Key = $.$default(TKey);
            //--TRIMMABLE-BOUNDARY-END(42950000656)
            
            //--TRIMMABLE-BOUNDARY-START(47244967952)
            /*TValue*/ Value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(47244967952)
            
            //--TRIMMABLE-BOUNDARY-START(12885229584)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229584)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 327696;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950000656),
    {
      "p": TKey?.$h??1507328,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x700000000n),
        "f": 50331649
      },
      "n": "Key",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70189057,
          "c": 8660123649,
          "a": [
            {
              "v": 2,
              "t": 70254593
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950000656),
//--TRIMMABLE-BOUNDARY-START(47244967952),
    {
      "p": TValue?.$h??1572864,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x900000000n),
        "f": 50331649
      },
      "n": "Value",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70189057,
          "c": 8660123649,
          "a": [
            {
              "v": 2,
              "t": 70254593
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47244967952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475164176),
    {
      "p": [
        {
          "n": "key",
          "p": TKey?.$h??1507328
        },
        {
          "n": "value",
          "p": TValue?.$h??1572864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164176),
//--TRIMMABLE-BOUNDARY-START(17180196880),
    {
      "p": [
        {
          "n": "keyValue",
          "p": $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196880),
//--TRIMMABLE-BOUNDARY-START(12885229584),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229584)
  ],
  "g": [TKey?.$h??1507328,TValue?.$h??1572864
  ],
  "r": 2,
  "h": this.$h,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{Value}",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "Name",
          "v": "[{Key}]",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327696)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading"))
//--TRIMMABLE-BOUNDARY-END(16)
