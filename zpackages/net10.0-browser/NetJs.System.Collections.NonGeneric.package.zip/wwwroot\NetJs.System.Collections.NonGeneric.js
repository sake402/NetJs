
(function ($global, $, $spc, $sm, $spu, $st, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.NonGeneric", 
    {"h":35,"f":"System.Collections.NonGeneric","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Collections.NonGeneric","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Collections.NonGeneric","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scn.System.Collections.ReadOnlyCollectionBase", ($self) => class ReadOnlyCollectionBase extends $.$spc.System.Object
        {
            /*ArrayList*/ InnerList$ = null;
            /*ArrayList */ get InnerList()
            {
                return this.InnerList$ ??= new $.$spc.System.Collections.ArrayList().$ctor$1();
            }
            /*int */ get Count()
            {
                return this.InnerList.Count;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return this.InnerList.IsSynchronized;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this.InnerList.SyncRoot;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.InnerList.CopyTo$1(array, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this.InnerList.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 589859;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":23592961,"g":{"r":0,"d":0,"h":12885491747,"f":4},"n":"InnerList","d":589859,"h":8590524451,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":21475426339,"f":129},"n":"Count","d":589859,"h":17180459043,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":30065360931,"f":2},"n":"{31326209}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":589859,"h":25770393635,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":38655295523,"f":2},"n":"{31326209}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":589859,"h":34360328227,"f":2}],"m":[{"r":31719425,"n":"GetEnumerator","d":589859,"h":47245230115,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":589859,"h":51540197411,"f":4}],"i":[31326209,31588353],"h":589859}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.ReadOnlyCollectionBase`; }
        });
        
        $asm.$cls("$scn.System.Collections.DictionaryBase", ($self) => class DictionaryBase extends $.$spc.System.Object
        {
            /*Hashtable?*/ _hashtable = null;
            /*Hashtable */ get InnerHashtable()
            {
                return this._hashtable ??= new $.$spc.System.Collections.Hashtable().$ctor$2();
            }
            /*IDictionary */ get Dictionary()
            {
                return this;
            }
            /*int */ get Count()
            {
                return this._hashtable === null ? 0 : this._hashtable.Count;
            }
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return this.InnerHashtable.IsReadOnly;
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return this.InnerHashtable.IsFixedSize;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return this.InnerHashtable.IsSynchronized;
            }
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.InnerHashtable.Keys;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this.InnerHashtable.SyncRoot;
            }
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.InnerHashtable.Values;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.InnerHashtable.CopyTo(array, index);
            }
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                /*object?*/ let currentValue = this.InnerHashtable.get_Item(key);
                this.OnGet(key, currentValue);
                return currentValue;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                this.OnValidate(key, value);
                /*bool*/ let keyExists = true;
                /*object?*/ let temp = this.InnerHashtable.get_Item(key);
                if (temp === null)
                {
                    keyExists = this.InnerHashtable.Contains(key);
                }
                this.OnSet(key, temp, value);
                this.InnerHashtable.set_Item(key, value);
                try
                {
                    this.OnSetComplete(key, temp, value);
                }
                catch($e)
                {
                    if (keyExists)
                    {
                        this.InnerHashtable.set_Item(key, temp);
                    }
                    else 
                    {
                        this.InnerHashtable.Remove(key);
                    }
                    throw $e;
                }
            }
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                return this.InnerHashtable.Contains(key);
            }
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                this.OnValidate(key, value);
                this.OnInsert(key, value);
                this.InnerHashtable.Add(key, value);
                try
                {
                    this.OnInsertComplete(key, value);
                }
                catch($e)
                {
                    this.InnerHashtable.Remove(key);
                    throw $e;
                }
            }
            /*void */ Clear()
            {
                this.OnClear();
                this.InnerHashtable.Clear();
                this.OnClearComplete();
            }
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                if (this.InnerHashtable.Contains(key))
                {
                    /*object?*/ let temp = this.InnerHashtable.get_Item(key);
                    this.OnValidate(key, temp);
                    this.OnRemove(key, temp);
                    this.InnerHashtable.Remove(key);
                    try
                    {
                        this.OnRemoveComplete(key, temp);
                    }
                    catch($e)
                    {
                        this.InnerHashtable.Add(key, temp);
                        throw $e;
                    }
                }
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                return this.InnerHashtable.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.InnerHashtable.GetEnumerator();
            }
            /*object? */ OnGet(/*object*/ key, /*object?*/ currentValue)
            {
                return currentValue;
            }
            /*void */ OnSet(/*object*/ key, /*object?*/ oldValue, /*object?*/ newValue)
            {
            }
            /*void */ OnInsert(/*object*/ key, /*object?*/ value)
            {
            }
            /*void */ OnClear()
            {
            }
            /*void */ OnRemove(/*object*/ key, /*object?*/ value)
            {
            }
            /*void */ OnValidate(/*object*/ key, /*object?*/ value)
            {
            }
            /*void */ OnSetComplete(/*object*/ key, /*object?*/ oldValue, /*object?*/ newValue)
            {
            }
            /*void */ OnInsertComplete(/*object*/ key, /*object?*/ value)
            {
            }
            /*void */ OnClearComplete()
            {
            }
            /*void */ OnRemoveComplete(/*object*/ key, /*object?*/ value)
            {
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 262179;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":30932993,"g":{"r":0,"d":0,"h":12885164067,"f":4},"n":"InnerHashtable","d":262179,"h":8590196771,"f":4},{"p":31457281,"g":{"r":0,"d":0,"h":21475098659,"f":4},"n":"Dictionary","d":262179,"h":17180131363,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":30065033251,"f":1},"n":"Count","d":262179,"h":25770065955,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38654967843,"f":2},"n":"{31457281}.IsReadOnly","o":"System$Collections$IDictionary$IsReadOnly","d":262179,"h":34360000547,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":47244902435,"f":2},"n":"{31457281}.IsFixedSize","o":"System$Collections$IDictionary$IsFixedSize","d":262179,"h":42949935139,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":55834837027,"f":2},"n":"{31326209}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":262179,"h":51539869731,"f":2},{"p":31326209,"g":{"r":0,"d":0,"h":64424771619,"f":2},"n":"{31457281}.Keys","o":"System$Collections$IDictionary$Keys","d":262179,"h":60129804323,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":73014706211,"f":2},"n":"{31326209}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":262179,"h":68719738915,"f":2},{"p":31326209,"g":{"r":0,"d":0,"h":81604640803,"f":2},"n":"{31457281}.Values","o":"System$Collections$IDictionary$Values","d":262179,"h":77309673507,"f":2},{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":94489542691,"f":2},"s":{"r":0,"d":0,"h":98784509987,"f":2},"n":"{31457281}.this[]","o":"System$Collections$IDictionary$Item","d":262179,"h":90194575395,"f":2}],"m":[{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":262179,"h":85899608099,"f":1},{"r":65537,"n":"Clear","d":262179,"h":111669411875,"f":1},{"r":31522817,"n":"GetEnumerator","d":262179,"h":120259346467,"f":1},{"r":131073,"p":[{"n":"key","p":131073},{"n":"currentValue","p":131073}],"n":"OnGet","d":262179,"h":128849281059,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"oldValue","p":131073},{"n":"newValue","p":131073}],"n":"OnSet","d":262179,"h":133144248355,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"OnInsert","d":262179,"h":137439215651,"f":132},{"r":65537,"n":"OnClear","d":262179,"h":141734182947,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"OnRemove","d":262179,"h":146029150243,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"OnValidate","d":262179,"h":150324117539,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"oldValue","p":131073},{"n":"newValue","p":131073}],"n":"OnSetComplete","d":262179,"h":154619084835,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"OnInsertComplete","d":262179,"h":158914052131,"f":132},{"r":65537,"n":"OnClearComplete","d":262179,"h":163209019427,"f":132},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"OnRemoveComplete","d":262179,"h":167503986723,"f":132}],"l":[{"t":30932993,"n":"_hashtable","d":262179,"h":4295229475,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":262179,"h":171798954019,"f":4}],"i":[31457281,31326209,31588353],"h":262179}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.DictionaryBase`; }
        });
        
        $asm.$cls("$scn.System.Collections.CollectionBase", ($self) => class CollectionBase extends $.$spc.System.Object
        {
            /*ArrayList*/ _list = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._list = new $.$spc.System.Collections.ArrayList().$ctor$1();
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                    this._list = new $.$spc.System.Collections.ArrayList().$ctor$2(capacity);
                }
                return this;
            }
            /*ArrayList */ get InnerList()
            {
                return this._list;
            }
            /*IList */ get List()
            {
                return this;
            }
            /*int */ get Capacity()
            {
                return this.InnerList.Capacity;
            }
            /*int */ set Capacity(value)
            {
                this.InnerList.Capacity = value;
            }
            /*int */ get Count()
            {
                return this._list.Count;
            }
            /*void */ Clear()
            {
                this.OnClear();
                this.InnerList.Clear();
                this.OnClearComplete();
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                /*object?*/ let temp = this.InnerList.get_Item(index);
                this.OnValidate(temp);
                this.OnRemove(index, temp);
                this.InnerList.RemoveAt(index);
                try
                {
                    this.OnRemoveComplete(index, temp);
                }
                catch($e)
                {
                    this.InnerList.Insert(index, temp);
                    throw $e;
                }
            }
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return this.InnerList.IsReadOnly;
            }
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return this.InnerList.IsFixedSize;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return this.InnerList.IsSynchronized;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this.InnerList.SyncRoot;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.InnerList.CopyTo$1(array, index);
            }
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return this.InnerList.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this.OnValidate(value);
                /*object?*/ let temp = this.InnerList.get_Item(index);
                this.OnSet(index, temp, value);
                this.InnerList.set_Item(index, value);
                try
                {
                    this.OnSetComplete(index, temp, value);
                }
                catch($e)
                {
                    this.InnerList.set_Item(index, temp);
                    throw $e;
                }
            }
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                return this.InnerList.Contains(value);
            }
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                this.OnValidate(value);
                this.OnInsert(this.InnerList.Count, value);
                /*int*/ let index = this.InnerList.Add(value);
                try
                {
                    this.OnInsertComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.RemoveAt(index);
                    throw $e;
                }
                return index;
            }
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                this.OnValidate(value);
                /*int*/ let index = this.InnerList.IndexOf(value);
                if (index < 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scn.System.SR.Arg_RemoveArgNotFound);
                }
                this.OnRemove(index, value);
                this.InnerList.RemoveAt(index);
                try
                {
                    this.OnRemoveComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.Insert(index, value);
                    throw $e;
                }
            }
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                return this.InnerList.IndexOf(value);
            }
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                if (index < 0 || index > this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                this.OnValidate(value);
                this.OnInsert(index, value);
                this.InnerList.Insert(index, value);
                try
                {
                    this.OnInsertComplete(index, value);
                }
                catch($e)
                {
                    this.InnerList.RemoveAt(index);
                    throw $e;
                }
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this.InnerList.GetEnumerator();
            }
            /*void */ OnSet(/*int*/ index, /*object?*/ oldValue, /*object?*/ newValue)
            {
            }
            /*void */ OnInsert(/*int*/ index, /*object?*/ value)
            {
            }
            /*void */ OnClear()
            {
            }
            /*void */ OnRemove(/*int*/ index, /*object?*/ value)
            {
            }
            /*void */ OnValidate(/*object*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
            }
            /*void */ OnSetComplete(/*int*/ index, /*object?*/ oldValue, /*object?*/ newValue)
            {
            }
            /*void */ OnInsertComplete(/*int*/ index, /*object?*/ value)
            {
            }
            /*void */ OnClearComplete()
            {
            }
            /*void */ OnRemoveComplete(/*int*/ index, /*object?*/ value)
            {
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 196643;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":23592961,"g":{"r":0,"d":0,"h":21475033123,"f":4},"n":"InnerList","d":196643,"h":17180065827,"f":4},{"p":31916033,"g":{"r":0,"d":0,"h":30064967715,"f":4},"n":"List","d":196643,"h":25770000419,"f":4},{"p":655361,"g":{"r":0,"d":0,"h":38654902307,"f":1},"s":{"r":0,"d":0,"h":42949869603,"f":1},"n":"Capacity","d":196643,"h":34359935011,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51539804195,"f":1},"n":"Count","d":196643,"h":47244836899,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719673379,"f":2},"n":"{31916033}.IsReadOnly","o":"System$Collections$IList$IsReadOnly","d":196643,"h":64424706083,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":77309607971,"f":2},"n":"{31916033}.IsFixedSize","o":"System$Collections$IList$IsFixedSize","d":196643,"h":73014640675,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":85899542563,"f":2},"n":"{31326209}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":196643,"h":81604575267,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":94489477155,"f":2},"n":"{31326209}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":196643,"h":90194509859,"f":2},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":107374379043,"f":2},"s":{"r":0,"d":0,"h":111669346339,"f":2},"n":"{31916033}.this[]","o":"System$Collections$IList$Item","d":196643,"h":103079411747,"f":2}],"m":[{"r":65537,"n":"Clear","d":196643,"h":55834771491,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":196643,"h":60129738787,"f":1},{"r":31719425,"n":"GetEnumerator","d":196643,"h":137439150115,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"oldValue","p":131073},{"n":"newValue","p":131073}],"n":"OnSet","d":196643,"h":141734117411,"f":132},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"OnInsert","d":196643,"h":146029084707,"f":132},{"r":65537,"n":"OnClear","d":196643,"h":150324052003,"f":132},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"OnRemove","d":196643,"h":154619019299,"f":132},{"r":65537,"p":[{"n":"value","p":131073}],"n":"OnValidate","d":196643,"h":158913986595,"f":132},{"r":65537,"p":[{"n":"index","p":655361},{"n":"oldValue","p":131073},{"n":"newValue","p":131073}],"n":"OnSetComplete","d":196643,"h":163208953891,"f":132},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"OnInsertComplete","d":196643,"h":167503921187,"f":132},{"r":65537,"n":"OnClearComplete","d":196643,"h":171798888483,"f":132},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"OnRemoveComplete","d":196643,"h":176093855779,"f":132}],"l":[{"t":23592961,"n":"_list","d":196643,"h":4295163939,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":196643,"h":8590131235,"f":4},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":196643,"h":12885098531,"f":4}],"i":[31916033,31326209,31588353],"h":196643}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.CollectionBase`; }
        });
        
        $asm.$cls("$scn.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$scn.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Collections.NonGeneric", $.$scn.System.SR.$type.Assembly);
                    $.$scn.System.SR.s_resourceManager = temp;
                }
                return $.$scn.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$scn.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$scn.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddingDuplicate_OldAndNewKeys()
            {
                return "Item has already been added. Key in dictionary: '{0}'  Key being added: '{1}'";
            }
            static /*string */ FormatArgument_AddingDuplicate_OldAndNewKeys(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Item has already been added. Key in dictionary: '{0}'  Key being added: '{1}'", arg1, arg2);
            }
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                return "Only single dimensional arrays are supported for the requested action.";
            }
            static /*string */ get Arg_RemoveArgNotFound()
            {
                return "Cannot remove the specified item because it was not found in the specified Collection.";
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            static /*string */ get ArgumentOutOfRange_SmallCapacity()
            {
                return "capacity was less than the current size.";
            }
            static /*string */ get InvalidOperation_EmptyQueue()
            {
                return "Queue empty.";
            }
            static /*string */ get InvalidOperation_EmptyStack()
            {
                return "Stack empty.";
            }
            static /*string */ get InvalidOperation_EnumEnded()
            {
                return "Enumeration already finished.";
            }
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                return "Collection was modified after the enumerator was instantiated.";
            }
            static /*string */ get InvalidOperation_EnumNotStarted()
            {
                return "Enumeration has not started. Call MoveNext.";
            }
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            static /*string */ get NotSupported_SortedListNestedWrite()
            {
                return "This operation is not supported on SortedList nested types because they require modifying the original SortedList.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$scn.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scn.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$scn.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scn.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scn.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$scn.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1245219;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1245219}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$scn.System.Collections.Specialized.CollectionsUtil", ($self) => class CollectionsUtil extends $.$spc.System.Object
        {
            static /*Hashtable */ CreateCaseInsensitiveHashtable()
            {
                return new $.$spc.System.Collections.Hashtable().$ctor$7($.$spc.System.StringComparer.CurrentCultureIgnoreCase);
            }
            static /*Hashtable */ CreateCaseInsensitiveHashtable$1(/*int*/ capacity)
            {
                return new $.$spc.System.Collections.Hashtable().$ctor$9(capacity, $.$spc.System.StringComparer.CurrentCultureIgnoreCase);
            }
            static /*Hashtable */ CreateCaseInsensitiveHashtable$2(/*IDictionary*/ d)
            {
                return new $.$spc.System.Collections.Hashtable().$ctor$13(d, $.$spc.System.StringComparer.CurrentCultureIgnoreCase);
            }
            static /*SortedList */ CreateCaseInsensitiveSortedList()
            {
                return new $.$scn.System.Collections.SortedList().$ctor$3($.$scn.System.Collections.CaseInsensitiveComparer.Default);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 983075;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":30932993,"n":"CreateCaseInsensitiveHashtable","d":983075,"h":4295950371,"f":33},{"r":30932993,"p":[{"n":"capacity","p":655361}],"n":"CreateCaseInsensitiveHashtable","o":"@$1","d":983075,"h":8590917667,"f":33},{"r":30932993,"p":[{"n":"d","p":31457281}],"n":"CreateCaseInsensitiveHashtable","o":"@$2","d":983075,"h":12885884963,"f":33},{"r":655395,"n":"CreateCaseInsensitiveSortedList","d":983075,"h":17180852259,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":983075,"h":21475819555,"f":1}],"h":983075}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Collections.Specialized.CollectionsUtil`; }
        });
        
        $asm.$cls("$scn.System.Collections.CaseInsensitiveComparer", ($self) => class CaseInsensitiveComparer extends $.$spc.System.Object
        {
            /*CompareInfo*/ _compareInfo = null;
            /*CaseInsensitiveComparer?*/ static s_InvariantCaseInsensitiveComparer = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._compareInfo = $.$spc.System.Globalization.CultureInfo.CurrentCulture.CompareInfo;
                }
                return this;
            }
            $ctor$2(/*CultureInfo*/ culture)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(culture, "culture");
                    this._compareInfo = culture.CompareInfo;
                }
                return this;
            }
            static /*CaseInsensitiveComparer */ get Default()
            {
                return new $.$scn.System.Collections.CaseInsensitiveComparer().$ctor$2($.$spc.System.Globalization.CultureInfo.CurrentCulture);
            }
            static /*CaseInsensitiveComparer */ get DefaultInvariant()
            {
                return $.$scn.System.Collections.CaseInsensitiveComparer.s_InvariantCaseInsensitiveComparer ??= new $.$scn.System.Collections.CaseInsensitiveComparer().$ctor$2($.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*int */ Compare(/*object?*/ a, /*object?*/ b)
            {
                /*string?*/ let sa = $.$as(a, $.$spc.System.String);
                /*string?*/ let sb = $.$as(b, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(sa, null) && $.$spc.System.String.op_Inequality(sb, null))
                {
                    return this._compareInfo.Compare$1(sa, sb, 1/*CompareOptions.IgnoreCase*/);
                }
                else 
                {
                    return $.$spc.System.Collections.Comparer.Default.Compare(a, b);
                }
            }
            //Generated interface implemetation for System.Collections.IComparer.Compare(object?, object?)
            System$Collections$IComparer$Compare()
            {
                return this.Compare(...arguments);
            }
            static $h = 65571;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":65571,"g":{"r":0,"d":0,"h":25769869347,"f":33},"n":"Default","d":65571,"h":21474902051,"f":33},{"p":65571,"g":{"r":0,"d":0,"h":34359803939,"f":33},"n":"DefaultInvariant","d":65571,"h":30064836643,"f":33}],"m":[{"r":655361,"p":[{"n":"a","p":131073},{"n":"b","p":131073}],"n":"Compare","d":65571,"h":38654771235,"f":1}],"l":[{"t":50528257,"n":"_compareInfo","d":65571,"h":4295032867,"f":2},{"t":65571,"n":"s_InvariantCaseInsensitiveComparer","d":65571,"h":8590000163,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":65571,"h":12884967459,"f":1},{"p":[{"n":"culture","p":51118081}],"n":".ctor","o":"$ctor$2","d":65571,"h":17179934755,"f":1}],"i":[31391745],"h":65571}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer ]; }
            static get $fullName() { return `System.Collections.CaseInsensitiveComparer`; }
        });
        
        $asm.$cls("$scn.System.Collections.CaseInsensitiveHashCodeProvider", ($self) => class CaseInsensitiveHashCodeProvider extends $.$spc.System.Object
        {
            /*CompareInfo*/ _compareInfo = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._compareInfo = $.$spc.System.Globalization.CultureInfo.CurrentCulture.CompareInfo;
                }
                return this;
            }
            $ctor$2(/*CultureInfo*/ culture)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(culture, "culture");
                    this._compareInfo = culture.CompareInfo;
                }
                return this;
            }
            static /*CaseInsensitiveHashCodeProvider */ get Default()
            {
                return new $.$scn.System.Collections.CaseInsensitiveHashCodeProvider().$ctor$1();
            }
            /*CaseInsensitiveHashCodeProvider*/ static DefaultInvariant$ = null;
            static /*CaseInsensitiveHashCodeProvider */ get DefaultInvariant()
            {
                return $.$scn.System.Collections.CaseInsensitiveHashCodeProvider.DefaultInvariant$ ??= new $.$scn.System.Collections.CaseInsensitiveHashCodeProvider().$ctor$2($.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(obj, "obj");
                /*string?*/ let s = $.$as(obj, $.$spc.System.String);
                return $.$spc.System.String.op_Inequality(s, null) ? this._compareInfo.GetHashCode$1(s, 1/*CompareOptions.IgnoreCase*/) : $.$spc.System.Object.GetHashCode.call(obj);
            }
            //Generated interface implemetation for System.Collections.IHashCodeProvider.GetHashCode(object)
            System$Collections$IHashCodeProvider$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            static $h = 131107;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131107,"g":{"r":0,"d":0,"h":21474967587,"f":33},"n":"Default","d":131107,"h":17180000291,"f":33},{"p":131107,"g":{"r":0,"d":0,"h":34359869475,"f":33},"n":"DefaultInvariant","d":131107,"h":30064902179,"f":33}],"m":[{"r":655361,"p":[{"n":"obj","p":131073}],"n":"GetHashCode","o":"@$1","d":131107,"h":38654836771,"f":1}],"l":[{"t":50528257,"n":"_compareInfo","d":131107,"h":4295098403,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":131107,"h":8590065699,"f":1},{"p":[{"n":"culture","p":51118081}],"n":".ctor","o":"$ctor$2","d":131107,"h":12885032995,"f":1}],"i":[31850497],"h":131107,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"CaseInsensitiveHashCodeProvider has been deprecated. Use StringComparer instead.","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IHashCodeProvider ]; }
            static get $fullName() { return `System.Collections.CaseInsensitiveHashCodeProvider`; }
        });
        
        $asm.$cls("$scn.System.Collections.Queue", ($self) => class Queue extends $.$spc.System.Object
        {
            /*object?[]*/ _array = null;
            /*int*/ _head = 0;
            /*int*/ _tail = 0;
            /*int*/ _size = 0;
            /*int*/ _growFactor = 0;
            /*int*/ _version = 0;
            /*int*/ static MinimumGrow = 4;
            $ctor$1()
            {
                this.$ctor$3(32, $.$cast(2, $.$spc.System.Single));
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                this.$ctor$3(capacity, $.$cast(2, $.$spc.System.Single));
                {
                }
                return this;
            }
            $ctor$3(/*int*/ capacity, /*float*/ growFactor)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, capacity, "capacity");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Single, growFactor, 1, "growFactor");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Single, growFactor, 10, "growFactor");
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [capacity], null);
                    this._head = 0;
                    this._tail = 0;
                    this._size = 0;
                    this._growFactor = $.$cast((growFactor * 100), $.$spc.System.Int32);
                }
                return this;
            }
            $ctor$4(/*ICollection*/ col)
            {
                this.$ctor$2($.$firstOf((col?.System$Collections$ICollection$Count ?? null), () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("col") }));
                {
                    /*IEnumerator*/ let en = col.System$Collections$IEnumerable$GetEnumerator();
                    while(en.System$Collections$IEnumerator$MoveNext())
                    {
                        this.Enqueue(en.System$Collections$IEnumerator$Current);
                    }
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*object */ Clone()
            {
                /*Queue*/ let q = new $.$scn.System.Collections.Queue().$ctor$2(this._size);
                q._size = this._size;
                /*int*/ let numToCopy = this._size;
                /*int*/ let firstPart = (((this._array.length - this._head) | 0) < numToCopy) ? ((this._array.length - this._head) | 0) : numToCopy;
                $.$spc.System.Array.Copy$1(this._array, this._head, q._array, 0, firstPart);
                numToCopy -= firstPart;
                if (numToCopy > 0)
                {
                    $.$spc.System.Array.Copy$1(this._array, 0, q._array, ((this._array.length - this._head) | 0), numToCopy);
                }
                q._version = this._version;
                return q;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*void */ Clear()
            {
                if (this._size !== 0)
                {
                    if (this._head < this._tail)
                    {
                        $.$spc.System.Array.Clear$1(this._array, this._head, this._size);
                    }
                    else 
                    {
                        $.$spc.System.Array.Clear$1(this._array, this._head, ((this._array.length - this._head) | 0));
                        $.$spc.System.Array.Clear$1(this._array, 0, this._tail);
                    }
                    this._size = 0;
                }
                this._head = 0;
                this._tail = 0;
                this._version++;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                if ($.$spc.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                /*int*/ let arrayLen = array.length;
                if (((arrayLen - index) | 0) < this._size)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scn.System.SR.Argument_InvalidOffLen);
                }
                /*int*/ let numToCopy = this._size;
                if (numToCopy === 0)
                {
                    return;
                }
                /*int*/ let firstPart = (((this._array.length - this._head) | 0) < numToCopy) ? ((this._array.length - this._head) | 0) : numToCopy;
                $.$spc.System.Array.Copy$1(this._array, this._head, array, index, firstPart);
                numToCopy -= firstPart;
                if (numToCopy > 0)
                {
                    $.$spc.System.Array.Copy$1(this._array, 0, array, ((((index + this._array.length) | 0) - this._head) | 0), numToCopy);
                }
            }
            /*void */ Enqueue(/*object?*/ obj)
            {
                if (this._size === this._array.length)
                {
                    /*int*/ let newcapacity = $.$cast(($.$cast(this._array.length, $.$spc.System.Int64) * $.$cast(this._growFactor, $.$spc.System.Int64) / 100n), $.$spc.System.Int32);
                    if (newcapacity < ((this._array.length + 4/*MinimumGrow*/) | 0))
                    {
                        newcapacity = ((this._array.length + 4/*MinimumGrow*/) | 0);
                    }
                    this.SetCapacity(newcapacity);
                }
                $.$spc.System.Array.$WriteT1.call(this._array, obj, this._tail);
                this._tail = (((this._tail + 1) | 0)) % this._array.length;
                this._size++;
                this._version++;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new $.$scn.System.Collections.Queue.QueueEnumerator().$ctor$1(this);
            }
            /*object? */ Dequeue()
            {
                if (this.Count === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EmptyQueue);
                }
                /*object?*/ let removed = $.$spc.System.Array.$ReadT1.call(this._array, this._head);
                $.$spc.System.Array.$WriteT1.call(this._array, null, this._head);
                this._head = (((this._head + 1) | 0)) % this._array.length;
                this._size--;
                this._version++;
                return removed;
            }
            /*object? */ Peek()
            {
                if (this.Count === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EmptyQueue);
                }
                return $.$spc.System.Array.$ReadT1.call(this._array, this._head);
            }
            static /*Queue */ Synchronized(/*Queue*/ queue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(queue, "queue");
                return new $.$scn.System.Collections.Queue.SynchronizedQueue().$ctor$5(queue);
            }
            /*bool */ Contains(/*object?*/ obj)
            {
                /*int*/ let index = this._head;
                /*int*/ let count = this._size;
                while(count-- > 0)
                {
                    if (obj === null)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(this._array, index) === null)
                        {
                            return true;
                        }
                    }
                    else if ($.$spc.System.Array.$ReadT1.call(this._array, index) !== null && $.$spc.System.Object.Equals.call($.$spc.System.Array.$ReadT1.call(this._array, index), obj))
                    {
                        return true;
                    }
                    index = (((index + 1) | 0)) % this._array.length;
                }
                return false;
            }
            /*object? */ GetElement(/*int*/ i)
            {
                return $.$spc.System.Array.$ReadT1.call(this._array, (((this._head + i) | 0)) % this._array.length);
            }
            /*object?[] */ ToArray()
            {
                if (this._size === 0)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Object);
                }
                /*object[]*/ let arr = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this._size], null);
                if (this._head < this._tail)
                {
                    $.$spc.System.Array.Copy$1(this._array, this._head, arr, 0, this._size);
                }
                else 
                {
                    $.$spc.System.Array.Copy$1(this._array, this._head, arr, 0, ((this._array.length - this._head) | 0));
                    $.$spc.System.Array.Copy$1(this._array, 0, arr, ((this._array.length - this._head) | 0), this._tail);
                }
                return arr;
            }
            /*void */ SetCapacity(/*int*/ capacity)
            {
                /*object[]*/ let newarray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [capacity], null);
                if (this._size > 0)
                {
                    if (this._head < this._tail)
                    {
                        $.$spc.System.Array.Copy$1(this._array, this._head, newarray, 0, this._size);
                    }
                    else 
                    {
                        $.$spc.System.Array.Copy$1(this._array, this._head, newarray, 0, ((this._array.length - this._head) | 0));
                        $.$spc.System.Array.Copy$1(this._array, 0, newarray, ((this._array.length - this._head) | 0), this._tail);
                    }
                }
                this._array = newarray;
                this._head = 0;
                this._tail = (this._size === capacity) ? 0 : this._size;
                this._version++;
            }
            /*void */ TrimToSize()
            {
                this.SetCapacity(this._size);
            }
            static $_SynchronizedQueue;
            static get SynchronizedQueue()
            {
                let $cls = $.$scn.System.Collections.Queue;
                return $cls.$_SynchronizedQueue ??= $asm.$ncls("$scn.System.Collections.Queue.SynchronizedQueue", ($self) => class SynchronizedQueue extends $.$scn.System.Collections.Queue
                {
                    /*Queue*/ _q = null;
                    /*object*/ _root = null;
                    $ctor$5(/*Queue*/ q)
                    {
                        super.$ctor$1();
                        {
                            this._q = q;
                            this._root = this._q.SyncRoot;
                        }
                        return this;
                    }
                    /*bool */ get IsSynchronized()
                    {
                        return true;
                    }
                    /*object */ get SyncRoot()
                    {
                        return this._root;
                    }
                    /*int */ get Count()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.Count;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Clear()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._q.Clear();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object */ Clone()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return new $.$scn.System.Collections.Queue.SynchronizedQueue().$ctor$5($.$cast(this._q.Clone(), $.$scn.System.Collections.Queue));
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.Contains(obj);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._q.CopyTo(array, arrayIndex);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Enqueue(/*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._q.Enqueue(value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object? */ Dequeue()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.Dequeue();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object? */ Peek()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.Peek();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object?[] */ ToArray()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._q.ToArray();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ TrimToSize()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._q.TrimToSize();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    static $h = 524323;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":393251,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475360803,"f":32769},"n":"IsSynchronized","d":524323,"h":17180393507,"f":32769},{"p":131073,"g":{"r":0,"d":0,"h":30065295395,"f":32769},"n":"SyncRoot","d":524323,"h":25770328099,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":38655229987,"f":32769},"n":"Count","d":524323,"h":34360262691,"f":32769}],"m":[{"r":65537,"n":"Clear","d":524323,"h":42950197283,"f":32769},{"r":131073,"n":"Clone","d":524323,"h":47245164579,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":524323,"h":51540131875,"f":32769},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":524323,"h":55835099171,"f":32769},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Enqueue","d":524323,"h":60130066467,"f":32769},{"r":131073,"n":"Dequeue","d":524323,"h":64425033763,"f":32769},{"r":31719425,"n":"GetEnumerator","d":524323,"h":68720001059,"f":32769},{"r":131073,"n":"Peek","d":524323,"h":73014968355,"f":32769},{"r":0,"n":"ToArray","d":524323,"h":77309935651,"f":32769},{"r":65537,"n":"TrimToSize","d":524323,"h":81604902947,"f":32769}],"l":[{"t":393251,"n":"_q","d":524323,"h":4295491619,"f":2},{"t":131073,"n":"_root","d":524323,"h":8590458915,"f":2}],"c":[{"p":[{"n":"q","p":393251}],"n":".ctor","o":"$ctor$5","d":524323,"h":12885426211,"f":8}],"i":[31326209,31588353,57147393],"d":393251,"h":524323}; }
                    static get $b() { return $.$scn.System.Collections.Queue; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Queue.SynchronizedQueue`; }
                }, $cls, ($v) => $cls.$_SynchronizedQueue = $v);
            }
            static $_QueueEnumerator;
            static get QueueEnumerator()
            {
                let $cls = $.$scn.System.Collections.Queue;
                return $cls.$_QueueEnumerator ??= $asm.$ncls("$scn.System.Collections.Queue.QueueEnumerator", ($self) => class QueueEnumerator extends $.$spc.System.Object
                {
                    /*Queue*/ _q = null;
                    /*int*/ _index = 0;
                    /*int*/ _version = 0;
                    /*object?*/ _currentElement = null;
                    $ctor$1(/*Queue*/ q)
                    {
                        super.$ctor();
                        {
                            this._q = q;
                            this._version = this._q._version;
                            this._index = 0;
                            this._currentElement = this._q._array;
                            if (this._q._size === 0)
                            {
                                this._index = -1;
                            }
                        }
                        return this;
                    }
                    /*object */ Clone()
                    {
                        return $.$clone(this);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._q._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index < 0)
                        {
                            this._currentElement = this._q._array;
                            return false;
                        }
                        this._currentElement = this._q.GetElement(this._index);
                        this._index++;
                        if (this._index === this._q._size)
                        {
                            this._index = -1;
                        }
                        return true;
                    }
                    /*object? */ get Current()
                    {
                        if (this._currentElement === this._q._array)
                        {
                            if (this._index === 0)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumNotStarted);
                            }
                            else 
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumEnded);
                            }
                        }
                        return this._currentElement;
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._q._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._q._size === 0)
                        {
                            this._index = -1;
                        }
                        else 
                        {
                            this._index = 0;
                        }
                        this._currentElement = this._q._array;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        return this.Clone(...arguments);
                    }
                    static $h = 458787;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":38655164451,"f":1},"n":"Current","d":458787,"h":34360197155,"f":1}],"m":[{"r":131073,"n":"Clone","d":458787,"h":25770262563,"f":1},{"r":262145,"n":"MoveNext","d":458787,"h":30065229859,"f":1},{"r":65537,"n":"Reset","d":458787,"h":42950131747,"f":1}],"l":[{"t":393251,"n":"_q","d":458787,"h":4295426083,"f":2},{"t":655361,"n":"_index","d":458787,"h":8590393379,"f":2},{"t":655361,"n":"_version","d":458787,"h":12885360675,"f":2},{"t":131073,"n":"_currentElement","d":458787,"h":17180327971,"f":2}],"c":[{"p":[{"n":"q","p":393251}],"n":".ctor","o":"$ctor$1","d":458787,"h":21475295267,"f":8}],"i":[31719425,57147393],"d":393251,"h":458787}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Queue.QueueEnumerator`; }
                }, $cls, ($v) => $cls.$_QueueEnumerator = $v);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                return this.Clone(...arguments);
            }
            static $h = 393251;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":55834968099,"f":129},"n":"Count","d":393251,"h":51540000803,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":68719869987,"f":129},"n":"IsSynchronized","d":393251,"h":64424902691,"f":129},{"p":131073,"g":{"r":0,"d":0,"h":77309804579,"f":129},"n":"SyncRoot","d":393251,"h":73014837283,"f":129}],"m":[{"r":131073,"n":"Clone","d":393251,"h":60129935395,"f":129},{"r":65537,"n":"Clear","d":393251,"h":81604771875,"f":129},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":393251,"h":85899739171,"f":129},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"Enqueue","d":393251,"h":90194706467,"f":129},{"r":31719425,"n":"GetEnumerator","d":393251,"h":94489673763,"f":129},{"r":131073,"n":"Dequeue","d":393251,"h":98784641059,"f":129},{"r":131073,"n":"Peek","d":393251,"h":103079608355,"f":129},{"r":393251,"p":[{"n":"queue","p":393251}],"n":"Synchronized","d":393251,"h":107374575651,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":393251,"h":111669542947,"f":129},{"r":131073,"p":[{"n":"i","p":655361}],"n":"GetElement","d":393251,"h":115964510243,"f":8},{"r":0,"n":"ToArray","d":393251,"h":120259477539,"f":129},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"SetCapacity","d":393251,"h":124554444835,"f":2},{"r":65537,"n":"TrimToSize","d":393251,"h":128849412131,"f":129}],"l":[{"t":0,"n":"_array","d":393251,"h":4295360547,"f":2},{"t":655361,"n":"_head","d":393251,"h":8590327843,"f":2},{"t":655361,"n":"_tail","d":393251,"h":12885295139,"f":2},{"t":655361,"n":"_size","d":393251,"h":17180262435,"f":2},{"t":655361,"n":"_growFactor","d":393251,"h":21475229731,"f":2},{"t":655361,"n":"_version","d":393251,"h":25770197027,"f":2},{"t":655361,"n":"MinimumGrow","d":393251,"h":30065164323,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":393251,"h":34360131619,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":393251,"h":38655098915,"f":1},{"p":[{"n":"capacity","p":655361},{"n":"growFactor","p":1114113}],"n":".ctor","o":"$ctor$3","d":393251,"h":42950066211,"f":1},{"p":[{"n":"col","p":31326209}],"n":".ctor","o":"$ctor$4","d":393251,"h":47245033507,"f":1}],"i":[31326209,31588353,57147393],"j":[524323,458787],"h":393251,"a":[{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.Queue`; }
        });
        
        $asm.$cls("$scn.System.Collections.Stack", ($self) => class Stack extends $.$spc.System.Object
        {
            /*object?[]*/ _array = null;
            /*int*/ _size = 0;
            /*int*/ _version = 0;
            /*int*/ static _defaultCapacity = 10;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [10/*_defaultCapacity*/], null);
                    this._size = 0;
                    this._version = 0;
                }
                return this;
            }
            $ctor$2(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, initialCapacity, "initialCapacity");
                    if (initialCapacity < 10/*_defaultCapacity*/)
                    {
                        initialCapacity = 10/*_defaultCapacity*/;
                    }
                    this._array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [initialCapacity], null);
                    this._size = 0;
                    this._version = 0;
                }
                return this;
            }
            $ctor$3(/*ICollection*/ col)
            {
                this.$ctor$2($.$firstOf((col?.System$Collections$ICollection$Count ?? null), () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("col") }));
                {
                    /*IEnumerator*/ let en = col.System$Collections$IEnumerable$GetEnumerator();
                    while(en.System$Collections$IEnumerator$MoveNext())
                    {
                        this.Push(en.System$Collections$IEnumerator$Current);
                    }
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*void */ Clear()
            {
                $.$spc.System.Array.Clear$1(this._array, 0, this._size);
                this._size = 0;
                this._version++;
            }
            /*object */ Clone()
            {
                /*Stack*/ let s = new $.$scn.System.Collections.Stack().$ctor$2(this._size);
                s._size = this._size;
                $.$spc.System.Array.Copy(this._array, s._array, this._size);
                s._version = this._version;
                return s;
            }
            /*bool */ Contains(/*object?*/ obj)
            {
                /*int*/ let count = this._size;
                while(count-- > 0)
                {
                    if (obj === null)
                    {
                        if ($.$spc.System.Array.$ReadT1.call(this._array, count) === null)
                        {
                            return true;
                        }
                    }
                    else if ($.$spc.System.Array.$ReadT1.call(this._array, count) !== null && $.$spc.System.Object.Equals.call($.$spc.System.Array.$ReadT1.call(this._array, count), obj))
                    {
                        return true;
                    }
                }
                return false;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                if ($.$spc.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._size)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scn.System.SR.Argument_InvalidOffLen);
                }
                /*int*/ let i = 0;
                /*object?[]?*/ let objArray = $.$as(array, $.$typeArray($.$spc.System.Object));
                if (objArray !== null)
                {
                    while(i < this._size)
                    {
                        $.$spc.System.Array.$WriteT1.call(objArray, $.$spc.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), ((i + index) | 0));
                        i++;
                    }
                }
                else 
                {
                    while(i < this._size)
                    {
                        array.SetValue($.$spc.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), ((i + index) | 0));
                        i++;
                    }
                }
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new $.$scn.System.Collections.Stack.StackEnumerator().$ctor$1(this);
            }
            /*object? */ Peek()
            {
                if (this._size === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EmptyStack);
                }
                return $.$spc.System.Array.$ReadT1.call(this._array, ((this._size - 1) | 0));
            }
            /*object? */ Pop()
            {
                if (this._size === 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EmptyStack);
                }
                this._version++;
                /*object?*/ let obj = $.$spc.System.Array.$ReadT1.call(this._array, --this._size);
                $.$spc.System.Array.$WriteT1.call(this._array, null, this._size);
                return obj;
            }
            /*void */ Push(/*object?*/ obj)
            {
                if (this._size === this._array.length)
                {
                    /*object[]*/ let newArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [((2 * this._array.length) | 0)], null);
                    $.$spc.System.Array.Copy(this._array, newArray, this._size);
                    this._array = newArray;
                }
                $.$spc.System.Array.$WriteT1.call(this._array, obj, this._size++);
                this._version++;
            }
            static /*Stack */ Synchronized(/*Stack*/ stack)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(stack, "stack");
                return new $.$scn.System.Collections.Stack.SyncStack().$ctor$4(stack);
            }
            /*object?[] */ ToArray()
            {
                if (this._size === 0)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Object);
                }
                /*object?[]*/ let objArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this._size], null);
                /*int*/ let i = 0;
                while(i < this._size)
                {
                    $.$spc.System.Array.$WriteT1.call(objArray, $.$spc.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), i);
                    i++;
                }
                return objArray;
            }
            static $_SyncStack;
            static get SyncStack()
            {
                let $cls = $.$scn.System.Collections.Stack;
                return $cls.$_SyncStack ??= $asm.$ncls("$scn.System.Collections.Stack.SyncStack", ($self) => class SyncStack extends $.$scn.System.Collections.Stack
                {
                    /*Stack*/ _s = null;
                    /*object*/ _root = null;
                    $ctor$4(/*Stack*/ stack)
                    {
                        super.$ctor$1();
                        {
                            this._s = stack;
                            this._root = stack.SyncRoot;
                        }
                        return this;
                    }
                    /*bool */ get IsSynchronized()
                    {
                        return true;
                    }
                    /*object */ get SyncRoot()
                    {
                        return this._root;
                    }
                    /*int */ get Count()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.Count;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.Contains(obj);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object */ Clone()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return new $.$scn.System.Collections.Stack.SyncStack().$ctor$4($.$cast(this._s.Clone(), $.$scn.System.Collections.Stack));
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Clear()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._s.Clear();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._s.CopyTo(array, arrayIndex);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Push(/*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._s.Push(value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object? */ Pop()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.Pop();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object? */ Peek()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.Peek();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object?[] */ ToArray()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._s.ToArray();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    static $h = 1179683;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048611,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476016163,"f":32769},"n":"IsSynchronized","d":1179683,"h":17181048867,"f":32769},{"p":131073,"g":{"r":0,"d":0,"h":30065950755,"f":32769},"n":"SyncRoot","d":1179683,"h":25770983459,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":38655885347,"f":32769},"n":"Count","d":1179683,"h":34360918051,"f":32769}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":1179683,"h":42950852643,"f":32769},{"r":131073,"n":"Clone","d":1179683,"h":47245819939,"f":32769},{"r":65537,"n":"Clear","d":1179683,"h":51540787235,"f":32769},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":1179683,"h":55835754531,"f":32769},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Push","d":1179683,"h":60130721827,"f":32769},{"r":131073,"n":"Pop","d":1179683,"h":64425689123,"f":32769},{"r":31719425,"n":"GetEnumerator","d":1179683,"h":68720656419,"f":32769},{"r":131073,"n":"Peek","d":1179683,"h":73015623715,"f":32769},{"r":0,"n":"ToArray","d":1179683,"h":77310591011,"f":32769}],"l":[{"t":1048611,"n":"_s","d":1179683,"h":4296146979,"f":2},{"t":131073,"n":"_root","d":1179683,"h":8591114275,"f":2}],"c":[{"p":[{"n":"stack","p":1048611}],"n":".ctor","o":"$ctor$4","d":1179683,"h":12886081571,"f":8}],"i":[31326209,31588353,57147393],"d":1048611,"h":1179683}; }
                    static get $b() { return $.$scn.System.Collections.Stack; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Stack.SyncStack`; }
                }, $cls, ($v) => $cls.$_SyncStack = $v);
            }
            static $_StackEnumerator;
            static get StackEnumerator()
            {
                let $cls = $.$scn.System.Collections.Stack;
                return $cls.$_StackEnumerator ??= $asm.$ncls("$scn.System.Collections.Stack.StackEnumerator", ($self) => class StackEnumerator extends $.$spc.System.Object
                {
                    /*Stack*/ _stack = null;
                    /*int*/ _index = 0;
                    /*int*/ _version = 0;
                    /*object?*/ _currentElement = null;
                    $ctor$1(/*Stack*/ stack)
                    {
                        super.$ctor();
                        {
                            this._stack = stack;
                            this._version = this._stack._version;
                            this._index = -2;
                            this._currentElement = null;
                        }
                        return this;
                    }
                    /*object */ Clone()
                    {
                        return $.$clone(this);
                    }
                    /*bool */ MoveNext()
                    {
                        /*bool*/ let retval;
                        if (this._version !== this._stack._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index === -2)
                        {
                            this._index = ((this._stack._size - 1) | 0);
                            retval = (this._index >= 0);
                            if (retval)
                            {
                                this._currentElement = $.$spc.System.Array.$ReadT1.call(this._stack._array, this._index);
                            }
                            return retval;
                        }
                        if (this._index === -1)
                        {
                            return false;
                        }
                        retval = (--this._index >= 0);
                        if (retval)
                        {
                            this._currentElement = $.$spc.System.Array.$ReadT1.call(this._stack._array, this._index);
                        }
                        else 
                        {
                            this._currentElement = null;
                        }
                        return retval;
                    }
                    /*object? */ get Current()
                    {
                        if (this._index === -2)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumNotStarted);
                        }
                        if (this._index === -1)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumEnded);
                        }
                        return this._currentElement;
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._stack._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = -2;
                        this._currentElement = null;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        return this.Clone(...arguments);
                    }
                    static $h = 1114147;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":38655819811,"f":1},"n":"Current","d":1114147,"h":34360852515,"f":1}],"m":[{"r":131073,"n":"Clone","d":1114147,"h":25770917923,"f":1},{"r":262145,"n":"MoveNext","d":1114147,"h":30065885219,"f":1},{"r":65537,"n":"Reset","d":1114147,"h":42950787107,"f":1}],"l":[{"t":1048611,"n":"_stack","d":1114147,"h":4296081443,"f":2},{"t":655361,"n":"_index","d":1114147,"h":8591048739,"f":2},{"t":655361,"n":"_version","d":1114147,"h":12886016035,"f":2},{"t":131073,"n":"_currentElement","d":1114147,"h":17180983331,"f":2}],"c":[{"p":[{"n":"stack","p":1048611}],"n":".ctor","o":"$ctor$1","d":1114147,"h":21475950627,"f":8}],"i":[31719425,57147393],"d":1048611,"h":1114147}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.Stack.StackEnumerator`; }
                }, $cls, ($v) => $cls.$_StackEnumerator = $v);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                return this.Clone(...arguments);
            }
            static $h = 1048611;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":38655754275,"f":129},"n":"Count","d":1048611,"h":34360786979,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":47245688867,"f":129},"n":"IsSynchronized","d":1048611,"h":42950721571,"f":129},{"p":131073,"g":{"r":0,"d":0,"h":55835623459,"f":129},"n":"SyncRoot","d":1048611,"h":51540656163,"f":129}],"m":[{"r":65537,"n":"Clear","d":1048611,"h":60130590755,"f":129},{"r":131073,"n":"Clone","d":1048611,"h":64425558051,"f":129},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":1048611,"h":68720525347,"f":129},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":1048611,"h":73015492643,"f":129},{"r":31719425,"n":"GetEnumerator","d":1048611,"h":77310459939,"f":129},{"r":131073,"n":"Peek","d":1048611,"h":81605427235,"f":129},{"r":131073,"n":"Pop","d":1048611,"h":85900394531,"f":129},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"Push","d":1048611,"h":90195361827,"f":129},{"r":1048611,"p":[{"n":"stack","p":1048611}],"n":"Synchronized","d":1048611,"h":94490329123,"f":33},{"r":0,"n":"ToArray","d":1048611,"h":98785296419,"f":129}],"l":[{"t":0,"n":"_array","d":1048611,"h":4296015907,"f":2},{"t":655361,"n":"_size","d":1048611,"h":8590983203,"f":2},{"t":655361,"n":"_version","d":1048611,"h":12885950499,"f":2},{"t":655361,"n":"_defaultCapacity","d":1048611,"h":17180917795,"f":34}],"c":[{"n":".ctor","o":"$ctor$1","d":1048611,"h":21475885091,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$2","d":1048611,"h":25770852387,"f":1},{"p":[{"n":"col","p":31326209}],"n":".ctor","o":"$ctor$3","d":1048611,"h":30065819683,"f":1}],"i":[31326209,31588353,57147393],"j":[1179683,1114147],"h":1048611,"a":[{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.Stack`; }
        });
        
        $asm.$cls("$scn.System.Collections.SortedList", ($self) => class SortedList extends $.$spc.System.Object
        {
            /*object[]*/ keys = null;
            /*object?[]*/ values = null;
            /*int*/ _size = 0;
            /*int*/ version = 0;
            /*IComparer*/ comparer = null;
            /*KeyList?*/ keyList = null;
            /*ValueList?*/ valueList = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.keys = $.$spc.System.Array.Empty($.$spc.System.Object);
                    this.values = $.$spc.System.Array.Empty($.$spc.System.Object);
                    this._size = 0;
                    this.comparer = new $.$spc.System.Collections.Comparer().$ctor$1($.$spc.System.Globalization.CultureInfo.CurrentCulture);
                }
                return this;
            }
            $ctor$2(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, initialCapacity, "initialCapacity");
                    this.keys = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [initialCapacity], null);
                    this.values = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [initialCapacity], null);
                    this.comparer = new $.$spc.System.Collections.Comparer().$ctor$1($.$spc.System.Globalization.CultureInfo.CurrentCulture);
                }
                return this;
            }
            $ctor$3(/*IComparer?*/ comparer)
            {
                this.$ctor$1();
                {
                    if (comparer !== null)
                    {
                        this.comparer = comparer;
                    }
                }
                return this;
            }
            $ctor$4(/*IComparer?*/ comparer, /*int*/ capacity)
            {
                this.$ctor$3(comparer);
                {
                    this.Capacity = capacity;
                }
                return this;
            }
            $ctor$5(/*IDictionary*/ d)
            {
                this.$ctor$6(d, null);
                {
                }
                return this;
            }
            $ctor$6(/*IDictionary*/ d, /*IComparer?*/ comparer)
            {
                this.$ctor$4(comparer, $.$firstOf((d?.System$Collections$ICollection$Count ?? null), () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("d") }));
                {
                    d.System$Collections$IDictionary$Keys.System$Collections$ICollection$CopyTo(this.keys, 0);
                    d.System$Collections$IDictionary$Values.System$Collections$ICollection$CopyTo(this.values, 0);
                    $.$spc.System.Array.Sort$4(this.keys, comparer);
                    for(/*int*/ let i = 0; i < this.keys.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(this.values, d.System$Collections$IDictionary$get_Item($.$spc.System.Array.$ReadT1.call(this.keys, i)), i);
                    }
                    this._size = d.System$Collections$ICollection$Count;
                }
                return this;
            }
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let i = $.$spc.System.Array.BinarySearch$3(this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scn.System.SR.Format$1($.$scn.System.SR.Argument_AddingDuplicate_OldAndNewKeys, this.GetKey(i), key));
                }
                this.Insert(~i, key, value);
            }
            /*int */ get Capacity()
            {
                return this.keys.length;
            }
            /*int */ set Capacity(value)
            {
                if (value < this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$scn.System.SR.ArgumentOutOfRange_SmallCapacity);
                }
                if (value !== this.keys.length)
                {
                    if (value > 0)
                    {
                        /*object[]*/ let newKeys = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [value], null);
                        /*object[]*/ let newValues = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [value], null);
                        if (this._size > 0)
                        {
                            $.$spc.System.Array.Copy(this.keys, newKeys, this._size);
                            $.$spc.System.Array.Copy(this.values, newValues, this._size);
                        }
                        this.keys = newKeys;
                        this.values = newValues;
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._size === 0, "Size is not zero");
                        this.keys = $.$spc.System.Array.Empty($.$spc.System.Object);
                        this.values = $.$spc.System.Array.Empty($.$spc.System.Object);
                    }
                }
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*ICollection */ get Keys()
            {
                return this.GetKeyList();
            }
            /*ICollection */ get Values()
            {
                return this.GetValueList();
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*bool */ get IsFixedSize()
            {
                return false;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*void */ Clear()
            {
                this.version++;
                $.$spc.System.Array.Clear$1(this.keys, 0, this._size);
                $.$spc.System.Array.Clear$1(this.values, 0, this._size);
                this._size = 0;
            }
            /*object */ Clone()
            {
                /*SortedList*/ let sl = new $.$scn.System.Collections.SortedList().$ctor$2(this._size);
                $.$spc.System.Array.Copy(this.keys, sl.keys, this._size);
                $.$spc.System.Array.Copy(this.values, sl.values, this._size);
                sl._size = this._size;
                sl.version = this.version;
                sl.comparer = this.comparer;
                return sl;
            }
            /*bool */ Contains(/*object*/ key)
            {
                return this.IndexOfKey(key) >= 0;
            }
            /*bool */ ContainsKey(/*object*/ key)
            {
                return this.IndexOfKey(key) >= 0;
            }
            /*bool */ ContainsValue(/*object?*/ value)
            {
                return this.IndexOfValue(value) >= 0;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                if ($.$spc.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, arrayIndex, "arrayIndex");
                if (((array.length - arrayIndex) | 0) < this.Count)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scn.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    /*DictionaryEntry*/ let entry = new $.$spc.System.Collections.DictionaryEntry().$ctor$2($.$spc.System.Array.$ReadT1.call(this.keys, i), $.$spc.System.Array.$ReadT1.call(this.values, i));
                    array.SetValue(entry.Clone(), ((i + arrayIndex) | 0));
                }
            }
            /*DebugViewDictionaryItem<object, object?>[] */ ToDebugViewDictionaryItemArray()
            {
                /*var*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$spc.System.Object, $.$spc.System.Object)), null, [this.Count], null);
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(array, new ($.$scn.System.Collections.Generic.DebugViewDictionaryItem$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$2($.$spc.System.Array.$ReadT1.call(this.keys, i), $.$spc.System.Array.$ReadT1.call(this.values, i)), i);
                }
                return array;
            }
            /*void */ EnsureCapacity(/*int*/ min)
            {
                /*int*/ let newCapacity = this.keys.length === 0 ? 16 : ((this.keys.length * 2) | 0);
                if (BigInt((newCapacity >>> 0)) > BigInt($.$spc.System.Array.MaxLength))
                {
                    newCapacity = $.$spc.System.Array.MaxLength;
                }
                if (newCapacity < min)
                {
                    newCapacity = min;
                }
                this.Capacity = newCapacity;
            }
            /*object? */ GetByIndex(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$spc.System.Array.$ReadT1.call(this.values, index);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this, 0, this._size, 3/*SortedListEnumerator.DictEntry*/);
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this, 0, this._size, 3/*SortedListEnumerator.DictEntry*/);
            }
            /*object */ GetKey(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$spc.System.Array.$ReadT1.call(this.keys, index);
            }
            /*IList */ GetKeyList()
            {
                return this.keyList ??= new $.$scn.System.Collections.SortedList.KeyList().$ctor$1(this);
            }
            /*IList */ GetValueList()
            {
                return this.valueList ??= new $.$scn.System.Collections.SortedList.ValueList().$ctor$1(this);
            }
            /*object?*/ get_Item(/*object*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    return $.$spc.System.Array.$ReadT1.call(this.values, i);
                }
                return null;
            }
            /*void*/ set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let i = $.$spc.System.Array.BinarySearch$3(this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    $.$spc.System.Array.$WriteT1.call(this.values, value, i);
                    this.version++;
                    return;
                }
                this.Insert(~i, key, value);
            }
            /*int */ IndexOfKey(/*object*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let ret = $.$spc.System.Array.BinarySearch$3(this.keys, 0, this._size, key, this.comparer);
                return ret >= 0 ? ret : -1;
            }
            /*int */ IndexOfValue(/*object?*/ value)
            {
                return $.$spc.System.Array.IndexOf$5($.$spc.System.Object, this.values, value, 0, this._size);
            }
            /*void */ Insert(/*int*/ index, /*object*/ key, /*object?*/ value)
            {
                if (this._size === this.keys.length)
                {
                    this.EnsureCapacity(((this._size + 1) | 0));
                }
                if (index < this._size)
                {
                    $.$spc.System.Array.Copy$1(this.keys, index, this.keys, ((index + 1) | 0), ((this._size - index) | 0));
                    $.$spc.System.Array.Copy$1(this.values, index, this.values, ((index + 1) | 0), ((this._size - index) | 0));
                }
                $.$spc.System.Array.$WriteT1.call(this.keys, key, index);
                $.$spc.System.Array.$WriteT1.call(this.values, value, index);
                this._size++;
                this.version++;
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this._size--;
                if (index < this._size)
                {
                    $.$spc.System.Array.Copy$1(this.keys, ((index + 1) | 0), this.keys, index, ((this._size - index) | 0));
                    $.$spc.System.Array.Copy$1(this.values, ((index + 1) | 0), this.values, index, ((this._size - index) | 0));
                }
                $.$spc.System.Array.$WriteT1.call(this.keys, null, this._size);
                $.$spc.System.Array.$WriteT1.call(this.values, null, this._size);
                this.version++;
            }
            /*void */ Remove(/*object*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    this.RemoveAt(i);
                }
            }
            /*void */ SetByIndex(/*int*/ index, /*object?*/ value)
            {
                if (index < 0 || index >= this.Count)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("index", $.$scn.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                $.$spc.System.Array.$WriteT1.call(this.values, value, index);
                this.version++;
            }
            static /*SortedList */ Synchronized(/*SortedList*/ list)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(list, "list");
                return new $.$scn.System.Collections.SortedList.SyncSortedList().$ctor$7(list);
            }
            /*void */ TrimToSize()
            {
                this.Capacity = this._size;
            }
            static $_SyncSortedList;
            static get SyncSortedList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_SyncSortedList ??= $asm.$ncls("$scn.System.Collections.SortedList.SyncSortedList", ($self) => class SyncSortedList extends $.$scn.System.Collections.SortedList
                {
                    /*SortedList*/ _list = null;
                    /*object*/ _root = null;
                    $ctor$7(/*SortedList*/ list)
                    {
                        super.$ctor$1();
                        {
                            this._list = list;
                            this._root = list.SyncRoot;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.Count;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object */ get SyncRoot()
                    {
                        return this._root;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return this._list.IsReadOnly;
                    }
                    /*bool */ get IsFixedSize()
                    {
                        return this._list.IsFixedSize;
                    }
                    /*bool */ get IsSynchronized()
                    {
                        return true;
                    }
                    /*object?*/ get_Item(/*object*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.get_Item(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void*/ set_Item(/*object*/ key, /*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.set_Item(key, value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Add(/*object*/ key, /*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.Add(key, value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*int */ get Capacity()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.Capacity;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Clear()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.Clear();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object */ Clone()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.Clone();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*bool */ Contains(/*object*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.Contains(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*bool */ ContainsKey(/*object*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.ContainsKey(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*bool */ ContainsValue(/*object?*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.ContainsValue(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.CopyTo(array, index);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object? */ GetByIndex(/*int*/ index)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.GetByIndex(index);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*IDictionaryEnumerator */ GetEnumerator()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.GetEnumerator();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*object */ GetKey(/*int*/ index)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.GetKey(index);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*IList */ GetKeyList()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.GetKeyList();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*IList */ GetValueList()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.GetValueList();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*int */ IndexOfKey(/*object*/ key)
                    {
                        $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.IndexOfKey(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*int */ IndexOfValue(/*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                return this._list.IndexOfValue(value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.RemoveAt(index);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ Remove(/*object*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.Remove(key);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*void */ SetByIndex(/*int*/ index, /*object?*/ value)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.SetByIndex(index, value);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    /*DebugViewDictionaryItem<object, object?>[] */ ToDebugViewDictionaryItemArray()
                    {
                        return this._list.ToDebugViewDictionaryItemArray();
                    }
                    /*void */ TrimToSize()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this._root)
                            {
                                this._list.TrimToSize();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this._root)
                        }
                    }
                    static $h = 852003;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":655395,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21475688483,"f":32769},"n":"Count","d":852003,"h":17180721187,"f":32769},{"p":131073,"g":{"r":0,"d":0,"h":30065623075,"f":32769},"n":"SyncRoot","d":852003,"h":25770655779,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655557667,"f":32769},"n":"IsReadOnly","d":852003,"h":34360590371,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245492259,"f":32769},"n":"IsFixedSize","d":852003,"h":42950524963,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835426851,"f":32769},"n":"IsSynchronized","d":852003,"h":51540459555,"f":32769},{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":64425361443,"f":32769},"s":{"r":0,"d":0,"h":68720328739,"f":32769},"n":"Item","o":"@$2","d":852003,"h":60130394147,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":81605230627,"f":32769},"n":"Capacity","d":852003,"h":77310263331,"f":32769}],"m":[{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Add","d":852003,"h":73015296035,"f":32769},{"r":65537,"n":"Clear","d":852003,"h":85900197923,"f":32769},{"r":131073,"n":"Clone","d":852003,"h":90195165219,"f":32769},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":852003,"h":94490132515,"f":32769},{"r":262145,"p":[{"n":"key","p":131073}],"n":"ContainsKey","d":852003,"h":98785099811,"f":32769},{"r":262145,"p":[{"n":"key","p":131073}],"n":"ContainsValue","d":852003,"h":103080067107,"f":32769},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":852003,"h":107375034403,"f":32769},{"r":131073,"p":[{"n":"index","p":655361}],"n":"GetByIndex","d":852003,"h":111670001699,"f":32769},{"r":31522817,"n":"GetEnumerator","d":852003,"h":115964968995,"f":32769},{"r":131073,"p":[{"n":"index","p":655361}],"n":"GetKey","d":852003,"h":120259936291,"f":32769},{"r":31916033,"n":"GetKeyList","d":852003,"h":124554903587,"f":32769},{"r":31916033,"n":"GetValueList","d":852003,"h":128849870883,"f":32769},{"r":655361,"p":[{"n":"key","p":131073}],"n":"IndexOfKey","d":852003,"h":133144838179,"f":32769},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOfValue","d":852003,"h":137439805475,"f":32769},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":852003,"h":141734772771,"f":32769},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":852003,"h":146029740067,"f":32769},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"SetByIndex","d":852003,"h":150324707363,"f":32769},{"r":0,"n":"ToDebugViewDictionaryItemArray","d":852003,"h":154619674659,"f":32776},{"r":65537,"n":"TrimToSize","d":852003,"h":158914641955,"f":32769}],"l":[{"t":655395,"n":"_list","d":852003,"h":4295819299,"f":2},{"t":131073,"n":"_root","d":852003,"h":8590786595,"f":2}],"c":[{"p":[{"n":"list","p":655395}],"n":".ctor","o":"$ctor$7","d":852003,"h":12885753891,"f":8}],"i":[31457281,31326209,31588353,57147393],"d":655395,"h":852003,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$scn.System.Collections.SortedList; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.SortedList.SyncSortedList`; }
                }, $cls, ($v) => $cls.$_SyncSortedList = $v);
            }
            static $_SortedListEnumerator;
            static get SortedListEnumerator()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_SortedListEnumerator ??= $asm.$ncls("$scn.System.Collections.SortedList.SortedListEnumerator", ($self) => class SortedListEnumerator extends $.$spc.System.Object
                {
                    /*SortedList*/ _sortedList = null;
                    /*object*/ _key = null;
                    /*object?*/ _value = null;
                    /*int*/ _index = 0;
                    /*int*/ _startIndex = 0;
                    /*int*/ _endIndex = 0;
                    /*int*/ _version = 0;
                    /*bool*/ _current = false;
                    /*int*/ _getObjectRetType = 0;
                    /*int*/ static Keys = 1;
                    /*int*/ static Values = 2;
                    /*int*/ static DictEntry = 3;
                    $ctor$1(/*SortedList*/ sortedList, /*int*/ index, /*int*/ count, /*int*/ getObjRetType)
                    {
                        super.$ctor();
                        {
                            this._sortedList = sortedList;
                            this._index = index;
                            this._startIndex = index;
                            this._endIndex = ((index + count) | 0);
                            this._version = sortedList.version;
                            this._getObjectRetType = getObjRetType;
                            this._current = false;
                        }
                        return this;
                    }
                    /*object */ Clone()
                    {
                        return $.$clone(this);
                    }
                    /*object */ get Key()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._key;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._index < this._endIndex)
                        {
                            this._key = $.$spc.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._value = $.$spc.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            this._current = true;
                            return true;
                        }
                        this._key = null;
                        this._value = null;
                        this._current = false;
                        return false;
                    }
                    /*DictionaryEntry */ get Entry()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$spc.System.Collections.DictionaryEntry().$ctor$2(this._key, this._value);
                    }
                    /*object? */ get Current()
                    {
                        if (this._current === false)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getObjectRetType === 1/*Keys*/)
                        {
                            return this._key;
                        }
                        else if (this._getObjectRetType === 2/*Values*/)
                        {
                            return this._value;
                        }
                        else 
                        {
                            return new $.$spc.System.Collections.DictionaryEntry().$ctor$2(this._key, this._value);
                        }
                    }
                    /*object? */ get Value()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._current === false)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._value;
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scn.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = this._startIndex;
                        this._current = false;
                        this._key = null;
                        this._value = null;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return this.Key;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return this.Value;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return this.Entry;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //Generated interface implemetation for System.ICloneable.Clone()
                    System$ICloneable$Clone()
                    {
                        return this.Clone(...arguments);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._key = null;
                    }
                    static $h = 786467;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":68720263203,"f":1},"n":"Key","d":786467,"h":64425295907,"f":1},{"p":25690113,"g":{"r":0,"d":0,"h":81605165091,"f":1},"n":"Entry","d":786467,"h":77310197795,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":90195099683,"f":1},"n":"Current","d":786467,"h":85900132387,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":98785034275,"f":1},"n":"Value","d":786467,"h":94490066979,"f":1}],"m":[{"r":131073,"n":"Clone","d":786467,"h":60130328611,"f":1},{"r":262145,"n":"MoveNext","d":786467,"h":73015230499,"f":1},{"r":65537,"n":"Reset","d":786467,"h":103080001571,"f":1}],"l":[{"t":655395,"n":"_sortedList","d":786467,"h":4295753763,"f":2},{"t":131073,"n":"_key","d":786467,"h":8590721059,"f":2},{"t":131073,"n":"_value","d":786467,"h":12885688355,"f":2},{"t":655361,"n":"_index","d":786467,"h":17180655651,"f":2},{"t":655361,"n":"_startIndex","d":786467,"h":21475622947,"f":2},{"t":655361,"n":"_endIndex","d":786467,"h":25770590243,"f":2},{"t":655361,"n":"_version","d":786467,"h":30065557539,"f":2},{"t":262145,"n":"_current","d":786467,"h":34360524835,"f":2},{"t":655361,"n":"_getObjectRetType","d":786467,"h":38655492131,"f":2},{"t":655361,"n":"Keys","d":786467,"h":42950459427,"f":40},{"t":655361,"n":"Values","d":786467,"h":47245426723,"f":40},{"t":655361,"n":"DictEntry","d":786467,"h":51540394019,"f":40}],"c":[{"p":[{"n":"sortedList","p":655395},{"n":"index","p":655361},{"n":"count","p":655361},{"n":"getObjRetType","p":655361}],"n":".ctor","o":"$ctor$1","d":786467,"h":55835361315,"f":8}],"i":[31522817,31719425,57147393],"d":655395,"h":786467}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionaryEnumerator, $.$spc.System.Collections.IEnumerator, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Collections.SortedList.SortedListEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListEnumerator = $v);
            }
            static $_KeyList;
            static get KeyList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_KeyList ??= $asm.$ncls("$scn.System.Collections.SortedList.KeyList", ($self) => class KeyList extends $.$spc.System.Object
                {
                    /*SortedList*/ sortedList = null;
                    $ctor$1(/*SortedList*/ sortedList)
                    {
                        super.$ctor();
                        {
                            this.sortedList = sortedList;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this.sortedList._size;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get IsFixedSize()
                    {
                        return true;
                    }
                    /*bool */ get IsSynchronized()
                    {
                        return this.sortedList.IsSynchronized;
                    }
                    /*object */ get SyncRoot()
                    {
                        return this.sortedList.SyncRoot;
                    }
                    /*int */ Add(/*object?*/ key)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ Clear()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*bool */ Contains(/*object?*/ key)
                    {
                        return this.sortedList.Contains(key);
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        if (array !== null && $.$spc.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        $.$spc.System.Array.Copy$1(this.sortedList.keys, 0, array, arrayIndex, this.sortedList.Count);
                    }
                    /*void */ Insert(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*object?*/ get_Item(/*int*/ index)
                    {
                        return this.sortedList.GetKey(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_KeyCollectionSet);
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this.sortedList, 0, this.sortedList.Count, 1/*SortedListEnumerator.Keys*/);
                    }
                    /*int */ IndexOf(/*object?*/ key)
                    {
                        $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                        /*int*/ let i = $.$spc.System.Array.BinarySearch$3(this.sortedList.keys, 0, this.sortedList.Count, key, this.sortedList.comparer);
                        if (i >= 0)
                        {
                            return i;
                        }
                        return -1;
                    }
                    /*void */ Remove(/*object?*/ key)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //Generated interface implemetation for System.Collections.IList.this[int].get
                    System$Collections$IList$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.this[int].set
                    System$Collections$IList$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Add(object?)
                    System$Collections$IList$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Contains(object?)
                    System$Collections$IList$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Clear()
                    System$Collections$IList$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
                    get System$Collections$IList$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
                    get System$Collections$IList$IsFixedSize()
                    {
                        return this.IsFixedSize;
                    }
                    //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
                    System$Collections$IList$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
                    System$Collections$IList$Insert()
                    {
                        return this.Insert(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Remove(object?)
                    System$Collections$IList$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
                    System$Collections$IList$RemoveAt()
                    {
                        return this.RemoveAt(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
                    System$Collections$ICollection$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
                    get System$Collections$ICollection$SyncRoot()
                    {
                        return this.SyncRoot;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
                    get System$Collections$ICollection$IsSynchronized()
                    {
                        return this.IsSynchronized;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    static $h = 720931;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180590115,"f":1},"n":"Count","d":720931,"h":12885622819,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770524707,"f":1},"n":"IsReadOnly","d":720931,"h":21475557411,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360459299,"f":1},"n":"IsFixedSize","d":720931,"h":30065492003,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950393891,"f":1},"n":"IsSynchronized","d":720931,"h":38655426595,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":51540328483,"f":1},"n":"SyncRoot","d":720931,"h":47245361187,"f":1},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":81605099555,"f":1},"s":{"r":0,"d":0,"h":85900066851,"f":1},"n":"Item","o":"@$2","d":720931,"h":77310132259,"f":1}],"m":[{"r":655361,"p":[{"n":"key","p":131073}],"n":"Add","d":720931,"h":55835295779,"f":1},{"r":65537,"n":"Clear","d":720931,"h":60130263075,"f":1},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":720931,"h":64425230371,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":720931,"h":68720197667,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":720931,"h":73015164963,"f":1},{"r":31719425,"n":"GetEnumerator","d":720931,"h":90195034147,"f":1},{"r":655361,"p":[{"n":"key","p":131073}],"n":"IndexOf","d":720931,"h":94490001443,"f":1},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":720931,"h":98784968739,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":720931,"h":103079936035,"f":1}],"l":[{"t":655395,"n":"sortedList","d":720931,"h":4295688227,"f":2}],"c":[{"p":[{"n":"sortedList","p":655395}],"n":".ctor","o":"$ctor$1","d":720931,"h":8590655523,"f":8}],"i":[31916033,31326209,31588353],"d":655395,"h":720931,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.SortedList.KeyList`; }
                }, $cls, ($v) => $cls.$_KeyList = $v);
            }
            static $_ValueList;
            static get ValueList()
            {
                let $cls = $.$scn.System.Collections.SortedList;
                return $cls.$_ValueList ??= $asm.$ncls("$scn.System.Collections.SortedList.ValueList", ($self) => class ValueList extends $.$spc.System.Object
                {
                    /*SortedList*/ sortedList = null;
                    $ctor$1(/*SortedList*/ sortedList)
                    {
                        super.$ctor();
                        {
                            this.sortedList = sortedList;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this.sortedList._size;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get IsFixedSize()
                    {
                        return true;
                    }
                    /*bool */ get IsSynchronized()
                    {
                        return this.sortedList.IsSynchronized;
                    }
                    /*object */ get SyncRoot()
                    {
                        return this.sortedList.SyncRoot;
                    }
                    /*int */ Add(/*object?*/ key)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ Clear()
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*bool */ Contains(/*object?*/ value)
                    {
                        return this.sortedList.ContainsValue(value);
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        if (array !== null && $.$spc.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$scn.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        $.$spc.System.Array.Copy$1(this.sortedList.values, 0, array, arrayIndex, this.sortedList.Count);
                    }
                    /*void */ Insert(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*object?*/ get_Item(/*int*/ index)
                    {
                        return this.sortedList.GetByIndex(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        return new $.$scn.System.Collections.SortedList.SortedListEnumerator().$ctor$1(this.sortedList, 0, this.sortedList.Count, 2/*SortedListEnumerator.Values*/);
                    }
                    /*int */ IndexOf(/*object?*/ value)
                    {
                        return $.$spc.System.Array.IndexOf$5($.$spc.System.Object, this.sortedList.values, value, 0, this.sortedList.Count);
                    }
                    /*void */ Remove(/*object?*/ value)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        throw new $.$spc.System.NotSupportedException().$ctor$10($.$scn.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //Generated interface implemetation for System.Collections.IList.this[int].get
                    System$Collections$IList$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.this[int].set
                    System$Collections$IList$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Add(object?)
                    System$Collections$IList$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Contains(object?)
                    System$Collections$IList$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Clear()
                    System$Collections$IList$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.IsReadOnly.get
                    get System$Collections$IList$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.IList.IsFixedSize.get
                    get System$Collections$IList$IsFixedSize()
                    {
                        return this.IsFixedSize;
                    }
                    //Generated interface implemetation for System.Collections.IList.IndexOf(object?)
                    System$Collections$IList$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Insert(int, object?)
                    System$Collections$IList$Insert()
                    {
                        return this.Insert(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.Remove(object?)
                    System$Collections$IList$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
                    System$Collections$IList$RemoveAt()
                    {
                        return this.RemoveAt(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
                    System$Collections$ICollection$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
                    get System$Collections$ICollection$SyncRoot()
                    {
                        return this.SyncRoot;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
                    get System$Collections$ICollection$IsSynchronized()
                    {
                        return this.IsSynchronized;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    static $h = 917539;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180786723,"f":1},"n":"Count","d":917539,"h":12885819427,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770721315,"f":1},"n":"IsReadOnly","d":917539,"h":21475754019,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360655907,"f":1},"n":"IsFixedSize","d":917539,"h":30065688611,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950590499,"f":1},"n":"IsSynchronized","d":917539,"h":38655623203,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":51540525091,"f":1},"n":"SyncRoot","d":917539,"h":47245557795,"f":1},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":81605296163,"f":1},"s":{"r":0,"d":0,"h":85900263459,"f":1},"n":"Item","o":"@$2","d":917539,"h":77310328867,"f":1}],"m":[{"r":655361,"p":[{"n":"key","p":131073}],"n":"Add","d":917539,"h":55835492387,"f":1},{"r":65537,"n":"Clear","d":917539,"h":60130459683,"f":1},{"r":262145,"p":[{"n":"value","p":131073}],"n":"Contains","d":917539,"h":64425426979,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":917539,"h":68720394275,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"Insert","d":917539,"h":73015361571,"f":1},{"r":31719425,"n":"GetEnumerator","d":917539,"h":90195230755,"f":1},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOf","d":917539,"h":94490198051,"f":1},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Remove","d":917539,"h":98785165347,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":917539,"h":103080132643,"f":1}],"l":[{"t":655395,"n":"sortedList","d":917539,"h":4295884835,"f":2}],"c":[{"p":[{"n":"sortedList","p":655395}],"n":".ctor","o":"$ctor$1","d":917539,"h":8590852131,"f":8}],"i":[31916033,31326209,31588353],"d":655395,"h":917539,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.SortedList.ValueList`; }
                }, $cls, ($v) => $cls.$_ValueList = $v);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                return this.Keys;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.ICloneable.Clone()
            System$ICloneable$Clone()
            {
                return this.Clone(...arguments);
            }
            static $h = 655395;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":68720132131,"f":129},"s":{"r":0,"d":0,"h":73015099427,"f":129},"n":"Capacity","d":655395,"h":64425164835,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":81605034019,"f":129},"n":"Count","d":655395,"h":77310066723,"f":129},{"p":31326209,"g":{"r":0,"d":0,"h":90194968611,"f":129},"n":"Keys","d":655395,"h":85900001315,"f":129},{"p":31326209,"g":{"r":0,"d":0,"h":98784903203,"f":129},"n":"Values","d":655395,"h":94489935907,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":107374837795,"f":129},"n":"IsReadOnly","d":655395,"h":103079870499,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":115964772387,"f":129},"n":"IsFixedSize","d":655395,"h":111669805091,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":124554706979,"f":129},"n":"IsSynchronized","d":655395,"h":120259739683,"f":129},{"p":131073,"g":{"r":0,"d":0,"h":133144641571,"f":129},"n":"SyncRoot","d":655395,"h":128849674275,"f":129},{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":201864118307,"f":129},"s":{"r":0,"d":0,"h":206159085603,"f":129},"n":"Item","o":"@$2","d":655395,"h":197569151011,"f":129}],"m":[{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Add","d":655395,"h":60130197539,"f":129},{"r":65537,"n":"Clear","d":655395,"h":137439608867,"f":129},{"r":131073,"n":"Clone","d":655395,"h":141734576163,"f":129},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":655395,"h":146029543459,"f":129},{"r":262145,"p":[{"n":"key","p":131073}],"n":"ContainsKey","d":655395,"h":150324510755,"f":129},{"r":262145,"p":[{"n":"value","p":131073}],"n":"ContainsValue","d":655395,"h":154619478051,"f":129},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"arrayIndex","p":655361}],"n":"CopyTo","d":655395,"h":158914445347,"f":129},{"r":0,"n":"ToDebugViewDictionaryItemArray","d":655395,"h":163209412643,"f":136},{"r":65537,"p":[{"n":"min","p":655361}],"n":"EnsureCapacity","d":655395,"h":167504379939,"f":2},{"r":131073,"p":[{"n":"index","p":655361}],"n":"GetByIndex","d":655395,"h":171799347235,"f":129},{"r":31522817,"n":"GetEnumerator","d":655395,"h":180389281827,"f":129},{"r":131073,"p":[{"n":"index","p":655361}],"n":"GetKey","d":655395,"h":184684249123,"f":129},{"r":31916033,"n":"GetKeyList","d":655395,"h":188979216419,"f":129},{"r":31916033,"n":"GetValueList","d":655395,"h":193274183715,"f":129},{"r":655361,"p":[{"n":"key","p":131073}],"n":"IndexOfKey","d":655395,"h":210454052899,"f":129},{"r":655361,"p":[{"n":"value","p":131073}],"n":"IndexOfValue","d":655395,"h":214749020195,"f":129},{"r":65537,"p":[{"n":"index","p":655361},{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Insert","d":655395,"h":219043987491,"f":2},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":655395,"h":223338954787,"f":129},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":655395,"h":227633922083,"f":129},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"SetByIndex","d":655395,"h":231928889379,"f":129},{"r":655395,"p":[{"n":"list","p":655395}],"n":"Synchronized","d":655395,"h":236223856675,"f":33},{"r":65537,"n":"TrimToSize","d":655395,"h":240518823971,"f":129}],"l":[{"t":0,"n":"keys","d":655395,"h":4295622691,"f":2},{"t":0,"n":"values","d":655395,"h":8590589987,"f":2},{"t":655361,"n":"_size","d":655395,"h":12885557283,"f":2},{"t":655361,"n":"version","d":655395,"h":17180524579,"f":2},{"t":31391745,"n":"comparer","d":655395,"h":21475491875,"f":2},{"t":720931,"n":"keyList","d":655395,"h":25770459171,"f":2},{"t":917539,"n":"valueList","d":655395,"h":30065426467,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":655395,"h":34360393763,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$2","d":655395,"h":38655361059,"f":1},{"p":[{"n":"comparer","p":31391745}],"n":".ctor","o":"$ctor$3","d":655395,"h":42950328355,"f":1},{"p":[{"n":"comparer","p":31391745},{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":655395,"h":47245295651,"f":1},{"p":[{"n":"d","p":31457281}],"n":".ctor","o":"$ctor$5","d":655395,"h":51540262947,"f":1},{"p":[{"n":"d","p":31457281},{"n":"comparer","p":31391745}],"n":".ctor","o":"$ctor$6","d":655395,"h":55835230243,"f":1}],"i":[31457281,31326209,31588353,57147393],"j":[852003,786467,720931,917539],"h":655395,"a":[{"t":37879809,"c":8627814401,"a":[{"v":null,"t":142606337}]},{"t":37552129,"c":8627486721,"a":[{"v":"Count = {Count}","t":1310721}]},{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Collections.SortedList`; }
        });
        
        $asm.$str("$scn.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$scn.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$spc.System.ValueType
        {
            $ctor$2(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            /*TKey*/ Key = $.$default(TKey);
            /*TValue*/ Value = $.$default(TValue);
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 327715;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":TKey?.$h??1507328,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},"n":"Key","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":1,"a":[{"t":37355521,"c":4332322817,"a":[{"v":2,"t":37421057}]}]},{"p":TValue?.$h??1572864,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":1},"n":"Value","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":1,"a":[{"t":37355521,"c":4332322817,"a":[{"v":2,"t":37421057}]}]}],"c":[{"p":[{"n":"key","p":TKey?.$h??1507328},{"n":"value","p":TValue?.$h??1572864}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":1},{"p":[{"n":"keyValue","p":$.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1},{"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":1}],"g":[TKey?.$h??1507328,TValue?.$h??1572864],"r":2,"h":this.$h,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{Value}","t":1310721}],"n":[{"n":"Name","v":"[{Key}]","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime"))