
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.Specialized", 
    {"h":36,"f":"System.Collections.Specialized","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Collections.Specialized","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Collections.Specialized","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scs.System.Collections.Specialized.IOrderedDictionary", ($self) => class IOrderedDictionary
        {
            static $h = 327716;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":8590262308,"f":50331905},"s":{"r":0,"d":0,"h":12885229604,"f":83886337},"n":"Item","o":"System$Collections$Specialized$IOrderedDictionary$Item","d":327716,"h":4295295012,"f":2097409}],"m":[{"r":31653889,"n":"GetEnumerator","o":"System$Collections$Specialized$IOrderedDictionary$GetEnumerator","d":327716,"h":17180196900,"f":16777473},{"r":65537,"p":[{"n":"index","p":655361},{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Insert","o":"System$Collections$Specialized$IOrderedDictionary$Insert","d":327716,"h":21475164196,"f":16777473},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","o":"System$Collections$Specialized$IOrderedDictionary$RemoveAt","d":327716,"h":25770131492,"f":16777473}],"i":[31588353,31457281,31719425],"h":327716}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.IOrderedDictionary`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.NameObjectCollectionBase", ($self) => class NameObjectCollectionBase extends $.$$.System.Object
        {
            /*bool*/ _readOnly = false;
            /*ArrayList*/ _entriesArray = null;
            /*IEqualityComparer*/ _keyComparer = null;
            /*Hashtable*/ _entriesTable = null;
            /*NameObjectEntry?*/ _nullKeyEntry = null;
            /*KeysCollection?*/ _keys = null;
            /*int*/ _version = 0;
            /*StringComparer*/ static s_defaultComparer = null;
            $ctor$1()
            {
                this.$ctor$2($.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer);
                {
                }
                return this;
            }
            $ctor$2(/*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor();
                {
                    this._keyComparer = equalityComparer ?? $.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer;
                    this.Reset();
                }
                return this;
            }
            $ctor$4(/*int*/ capacity, /*IEqualityComparer?*/ equalityComparer)
            {
                this.$ctor$2(equalityComparer);
                {
                    this.Reset$1(capacity);
                }
                return this;
            }
            $ctor$3(/*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    this._keyComparer = new $.$scs.System.Collections.CompatibleComparer().$ctor$1(hashProvider, comparer);
                    this.Reset();
                }
                return this;
            }
            $ctor$5(/*int*/ capacity, /*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    this._keyComparer = new $.$scs.System.Collections.CompatibleComparer().$ctor$1(hashProvider, comparer);
                    this.Reset$1(capacity);
                }
                return this;
            }
            $ctor$6(/*int*/ capacity)
            {
                super.$ctor();
                {
                    this._keyComparer = $.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer;
                    this.Reset$1(capacity);
                }
                return this;
            }
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Reset()
            {
                this._entriesArray = new $.$$.System.Collections.ArrayList().$ctor$1();
                this._entriesTable = new $.$$.System.Collections.Hashtable().$ctor$9(this._keyComparer);
                this._nullKeyEntry = null;
                this._version++;
            }
            /*void */ Reset$1(/*int*/ capacity)
            {
                this._entriesArray = new $.$$.System.Collections.ArrayList().$ctor$3(capacity);
                this._entriesTable = new $.$$.System.Collections.Hashtable().$ctor$11(capacity, this._keyComparer);
                this._nullKeyEntry = null;
                this._version++;
            }
            /*NameObjectEntry? */ FindEntry(/*string?*/ key)
            {
                if ($.$$.System.String.op_Inequality(key, null))
                {
                    return $.$cast(this._entriesTable.get_Item(key), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                }
                else 
                {
                    return this._nullKeyEntry;
                }
            }
            /*IEqualityComparer */ get Comparer()
            {
                return this._keyComparer;
            }
            /*IEqualityComparer */ set Comparer(value)
            {
                this._keyComparer = value;
            }
            /*bool */ get IsReadOnly()
            {
                return this._readOnly;
            }
            /*bool */ set IsReadOnly(value)
            {
                this._readOnly = value;
            }
            /*bool */ BaseHasKeys()
            {
                return (this._entriesTable.Count > 0);
            }
            /*void */ BaseAdd(/*string?*/ name, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry*/ let entry = new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry().$ctor$1(name, value);
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    if (this._entriesTable.get_Item(name) === null)
                    {
                        this._entriesTable.Add(name, entry);
                    }
                }
                else 
                {
                    this._nullKeyEntry ??= entry;
                }
                this._entriesArray.Add(entry);
                this._version++;
            }
            /*void */ BaseRemove(/*string?*/ name)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    this._entriesTable.Remove(name);
                    for(/*int*/ let i = ((this._entriesArray.Count - 1) | 0); i >= 0; i--)
                    {
                        if (this._keyComparer.System$Collections$IEqualityComparer$Equals(name, this.BaseGetKey(i)))
                        {
                            this._entriesArray.RemoveAt(i);
                        }
                    }
                }
                else 
                {
                    this._nullKeyEntry = null;
                    for(/*int*/ let i = ((this._entriesArray.Count - 1) | 0); i >= 0; i--)
                    {
                        if ($.$$.System.String.op_Equality(this.BaseGetKey(i), null))
                        {
                            this._entriesArray.RemoveAt(i);
                        }
                    }
                }
                this._version++;
            }
            /*void */ BaseRemoveAt(/*int*/ index)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*string?*/ let key = this.BaseGetKey(index);
                if ($.$$.System.String.op_Inequality(key, null))
                {
                    this._entriesTable.Remove(key);
                }
                else 
                {
                    this._nullKeyEntry = null;
                }
                this._entriesArray.RemoveAt(index);
                this._version++;
            }
            /*void */ BaseClear()
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.Reset();
            }
            /*object? */ BaseGet$1(/*string?*/ name)
            {
                /*NameObjectEntry?*/ let e = this.FindEntry(name);
                return e?.Value ?? null;
            }
            /*void */ BaseSet$1(/*string?*/ name, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry?*/ let entry = this.FindEntry(name);
                if (entry !== null)
                {
                    entry.Value = value;
                    this._version++;
                }
                else 
                {
                    this.BaseAdd(name, value);
                }
            }
            /*object? */ BaseGet(/*int*/ index)
            {
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                return entry.Value;
            }
            /*string? */ BaseGetKey(/*int*/ index)
            {
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                return entry.Key;
            }
            /*void */ BaseSet(/*int*/ index, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                entry.Value = value;
                this._version++;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator().$ctor$1(this);
            }
            /*int */ get Count()
            {
                return this._entriesArray.Count;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._entriesArray.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                for(/*IEnumerator*/ let e = this.GetEnumerator(); e.System$Collections$IEnumerator$MoveNext(); )
                {
                    array.SetValue$2(e.System$Collections$IEnumerator$Current, index++);
                }
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*string?[] */ BaseGetAllKeys()
            {
                /*int*/ let n = this._entriesArray.Count;
                /*string?[]*/ let allKeys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allKeys, this.BaseGetKey(i), i);
                }
                return allKeys;
            }
            /*object?[] */ BaseGetAllValues()
            {
                /*int*/ let n = this._entriesArray.Count;
                /*object?[]*/ let allValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [n], null);
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allValues, this.BaseGet(i), i);
                }
                return allValues;
            }
            /*object?[] */ BaseGetAllValues$1(/*Type*/ type)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*int*/ let n = this._entriesArray.Count;
                /*object?[]*/ let allValues = $.$cast($.$$.System.Array.CreateInstance$2(type, n), $.$typeArray($.$$.System.Object));
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allValues, this.BaseGet(i), i);
                }
                return allValues;
            }
            /*KeysCollection */ get Keys$1()
            {
                return this._keys ??= new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.KeysCollection().$ctor$1(this);
            }
            static $_NameObjectEntry;
            static get NameObjectEntry()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_NameObjectEntry ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry", ($self) => class NameObjectEntry extends $.$$.System.Object
                {
                    $ctor$1(/*string?*/ name, /*object?*/ value)
                    {
                        super.$ctor();
                        {
                            this.Key = name;
                            this.Value = value;
                        }
                        return this;
                    }
                    /*string?*/ Key = null;
                    /*object?*/ Value = null;
                    static $h = 852004;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Key","d":852004,"h":8590786596,"f":4194312},{"t":131073,"n":"Value","d":852004,"h":12885753892,"f":4194312}],"c":[{"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":".ctor","o":"$ctor$1","d":852004,"h":4295819300,"f":16777224}],"d":720932,"h":852004}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry`; }
                }, $cls, ($v) => $cls.$_NameObjectEntry = $v);
            }
            static $_NameObjectKeysEnumerator;
            static get NameObjectKeysEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_NameObjectKeysEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator", ($self) => class NameObjectKeysEnumerator extends $.$$.System.Object
                {
                    /*int*/ _pos = 0;
                    /*NameObjectCollectionBase*/ _coll = null;
                    /*int*/ _version = 0;
                    $ctor$1(/*NameObjectCollectionBase*/ coll)
                    {
                        super.$ctor();
                        {
                            this._coll = coll;
                            this._version = this._coll._version;
                            this._pos = -1;
                        }
                        return this;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._coll._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._pos < ((this._coll.Count - 1) | 0))
                        {
                            this._pos++;
                            return true;
                        }
                        else 
                        {
                            this._pos = this._coll.Count;
                            return false;
                        }
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._coll._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._pos = -1;
                    }
                    /*object? */ get Current()
                    {
                        if (this._pos >= 0 && this._pos < this._coll.Count)
                        {
                            return this._coll.BaseGetKey(this._pos);
                        }
                        else 
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 917540;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":34360655908,"f":50331649},"n":"Current","d":917540,"h":30065688612,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":917540,"h":21475754020,"f":16777217},{"r":65537,"n":"Reset","d":917540,"h":25770721316,"f":16777217}],"l":[{"t":655361,"n":"_pos","d":917540,"h":4295884836,"f":4194306},{"t":720932,"n":"_coll","d":917540,"h":8590852132,"f":4194306},{"t":655361,"n":"_version","d":917540,"h":12885819428,"f":4194306}],"c":[{"p":[{"n":"coll","p":720932}],"n":".ctor","o":"$ctor$1","d":917540,"h":17180786724,"f":16777224}],"i":[31850497],"d":720932,"h":917540}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator`; }
                }, $cls, ($v) => $cls.$_NameObjectKeysEnumerator = $v);
            }
            static $_KeysCollection;
            static get KeysCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_KeysCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.KeysCollection", ($self) => class KeysCollection extends $.$$.System.Object
                {
                    /*NameObjectCollectionBase*/ _coll = null;
                    $ctor$1(/*NameObjectCollectionBase*/ coll)
                    {
                        super.$ctor();
                        {
                            this._coll = coll;
                        }
                        return this;
                    }
                    /*string? */ Get(/*int*/ index)
                    {
                        return this._coll.BaseGetKey(index);
                    }
                    /*string?*/ get_Item(/*int*/ index)
                    {
                        return this.Get(index);
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        return new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator().$ctor$1(this._coll);
                    }
                    /*int */ get Count()
                    {
                        return this._coll.Count;
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._coll.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                        }
                        for(/*IEnumerator*/ let e = this.GetEnumerator(); e.System$Collections$IEnumerator$MoveNext(); )
                        {
                            array.SetValue$2(e.System$Collections$IEnumerator$Current, index++);
                        }
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._coll).System$Collections$ICollection$SyncRoot;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    static $h = 786468;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":21475622948,"f":50331649},"n":"Item","o":"@$2","d":786468,"h":17180655652,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":34360524836,"f":50331649},"n":"Count","d":786468,"h":30065557540,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":47245426724,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":786468,"h":42950459428,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":55835361316,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":786468,"h":51540394020,"f":2097154}],"m":[{"r":1310721,"p":[{"n":"index","p":655361}],"n":"Get","d":786468,"h":12885688356,"f":16777345},{"r":31850497,"n":"GetEnumerator","d":786468,"h":25770590244,"f":16777217}],"l":[{"t":720932,"n":"_coll","d":786468,"h":4295753764,"f":4194306}],"c":[{"p":[{"n":"coll","p":720932}],"n":".ctor","o":"$ctor$1","d":786468,"h":8590721060,"f":16777224}],"i":[31457281,31719425],"d":720932,"h":786468}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.KeysCollection`; }
                }, $cls, ($v) => $cls.$_KeysCollection = $v);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object?)
            System$Runtime$Serialization$IDeserializationCallback$OnDeserialization()
            {
                return this.OnDeserialization(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultComparer = $.$$.System.Globalization.GlobalizationExtensions.GetStringComparer($.$$.System.Globalization.CultureInfo.InvariantCulture.CompareInfo, 1/*CompareOptions.IgnoreCase*/);
                }
            }
            static $h = 720932;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":31916033,"g":{"r":0,"d":0,"h":94490001444,"f":50331656},"s":{"r":0,"d":0,"h":98784968740,"f":83886088},"n":"Comparer","d":720932,"h":90195034148,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":107374903332,"f":50331652},"s":{"r":0,"d":0,"h":111669870628,"f":83886084},"n":"IsReadOnly","d":720932,"h":103079936036,"f":2097156},{"p":655361,"g":{"r":0,"d":0,"h":167504445476,"f":50331777},"n":"Count","d":720932,"h":163209478180,"f":2097281},{"p":131073,"g":{"r":0,"d":0,"h":180389347364,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":720932,"h":176094380068,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":188979281956,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":720932,"h":184684314660,"f":2097154},{"p":786468,"g":{"r":0,"d":0,"h":210454118436,"f":50331777},"n":"Keys","o":"@$1","d":720932,"h":206159151140,"f":2097281}],"m":[{"r":65537,"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":720932,"h":68720197668,"f":16777345,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":65537,"p":[{"n":"sender","p":131073}],"n":"OnDeserialization","d":720932,"h":73015164964,"f":16777345},{"r":65537,"n":"Reset","d":720932,"h":77310132260,"f":16777218},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"Reset","o":"@$1","d":720932,"h":81605099556,"f":16777218},{"r":852004,"p":[{"n":"key","p":1310721}],"n":"FindEntry","d":720932,"h":85900066852,"f":16777218},{"r":262145,"n":"BaseHasKeys","d":720932,"h":115964837924,"f":16777220},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"BaseAdd","d":720932,"h":120259805220,"f":16777220},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"BaseRemove","d":720932,"h":124554772516,"f":16777220},{"r":65537,"p":[{"n":"index","p":655361}],"n":"BaseRemoveAt","d":720932,"h":128849739812,"f":16777220},{"r":65537,"n":"BaseClear","d":720932,"h":133144707108,"f":16777220},{"r":131073,"p":[{"n":"name","p":1310721}],"n":"BaseGet","o":"@$1","d":720932,"h":137439674404,"f":16777220},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":131073}],"n":"BaseSet","o":"@$1","d":720932,"h":141734641700,"f":16777220},{"r":131073,"p":[{"n":"index","p":655361}],"n":"BaseGet","d":720932,"h":146029608996,"f":16777220},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"BaseGetKey","d":720932,"h":150324576292,"f":16777220},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":131073}],"n":"BaseSet","d":720932,"h":154619543588,"f":16777220},{"r":31850497,"n":"GetEnumerator","d":720932,"h":158914510884,"f":16777345},{"r":$.$typeArray($.$$.System.String).$h,"n":"BaseGetAllKeys","d":720932,"h":193274249252,"f":16777220},{"r":$.$typeArray($.$$.System.Object).$h,"n":"BaseGetAllValues","d":720932,"h":197569216548,"f":16777220},{"r":$.$typeArray($.$$.System.Object).$h,"p":[{"n":"type","p":142475265}],"n":"BaseGetAllValues","o":"@$1","d":720932,"h":201864183844,"f":16777220}],"l":[{"t":262145,"n":"_readOnly","d":720932,"h":4295688228,"f":4194306},{"t":23724033,"n":"_entriesArray","d":720932,"h":8590655524,"f":4194306},{"t":31916033,"n":"_keyComparer","d":720932,"h":12885622820,"f":4194306},{"t":31064065,"n":"_entriesTable","d":720932,"h":17180590116,"f":4194306},{"t":852004,"n":"_nullKeyEntry","d":720932,"h":21475557412,"f":4194306},{"t":786468,"n":"_keys","d":720932,"h":25770524708,"f":4194306},{"t":655361,"n":"_version","d":720932,"h":30065492004,"f":4194306},{"t":119275521,"n":"s_defaultComparer","d":720932,"h":34360459300,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":720932,"h":38655426596,"f":16777220},{"p":[{"n":"equalityComparer","p":31916033}],"n":".ctor","o":"$ctor$2","d":720932,"h":42950393892,"f":16777220},{"p":[{"n":"capacity","p":655361},{"n":"equalityComparer","p":31916033}],"n":".ctor","o":"$ctor$4","d":720932,"h":47245361188,"f":16777220},{"p":[{"n":"hashProvider","p":31981569},{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$3","d":720932,"h":51540328484,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use NameObjectCollectionBase(IEqualityComparer) instead.","t":1310721}]}]},{"p":[{"n":"capacity","p":655361},{"n":"hashProvider","p":31981569},{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$5","d":720932,"h":55835295780,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use NameObjectCollectionBase(Int32, IEqualityComparer) instead.","t":1310721}]}]},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$6","d":720932,"h":60130263076,"f":16777220},{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$7","d":720932,"h":64425230372,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"i":[31457281,31719425,113246209,112984065],"j":[852004,917540,786468],"h":720932}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase`; }
        });
        
        $asm.$cls("$scs.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$scs.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections.Specialized", $.$scs.System.SR.$type.Assembly);
                    $.$scs.System.SR.s_resourceManager = temp;
                }
                return $.$scs.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$scs.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$scs.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                return "Collection was modified after the enumerator was instantiated.";
            }
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get Arg_MultiRank()
            {
                return "Multi dimension array is not supported on this operation.";
            }
            static /*string */ get Arg_InsufficientSpace()
            {
                return "Insufficient space in the target location to copy the information.";
            }
            static /*string */ get CollectionReadOnly()
            {
                return "Collection is read-only.";
            }
            static /*string */ get BitVectorFull()
            {
                return "Bit vector is full.";
            }
            static /*string */ get OrderedDictionary_ReadOnly()
            {
                return "The OrderedDictionary is read-only and cannot be modified.";
            }
            static /*string */ get Argument_ImplementIComparable()
            {
                return "At least one object must implement IComparable.";
            }
            static /*string */ get OrderedDictionary_SerializationMismatch()
            {
                return "There was an error deserializing the OrderedDictionary.  The ArrayList does not contain DictionaryEntries.";
            }
            static /*string */ get Serialization_InvalidOnDeser()
            {
                return "OnDeserialization method was called while the object was not being deserialized.";
            }
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            static /*string */ get NotSupported_ValueCollectionSet()
            {
                return "Mutating a value collection derived from a dictionary is not allowed.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$scs.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scs.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$scs.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scs.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scs.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$scs.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1507364;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1507364}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$scs.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 1441828;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1441828,"h":4296409124,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":1441828,"h":8591376420,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":1441828,"h":12886343716,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":1441828,"h":17181311012,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":1441828,"h":21476278308,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":1441828,"h":25771245604,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":1441828,"h":30066212900,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":1441828,"h":34361180196,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":1441828,"h":38656147492,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":1441828,"h":42951114788,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":1441828,"h":47246082084,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":1441828,"h":51541049380,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":1441828,"h":55836016676,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":1441828,"h":60130983972,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":1441828,"h":64425951268,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":1441828,"h":68720918564,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":1441828,"h":73015885860,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":1441828,"h":77310853156,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":1441828,"h":81605820452,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":1441828,"h":85900787748,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":1441828,"h":90195755044,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":1441828,"h":94490722340,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":1441828,"h":98785689636,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":1441828,"h":103080656932,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":1441828,"h":107375624228,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":1441828,"h":111670591524,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":1441828,"h":115965558820,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":1441828,"h":120260526116,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":1441828,"h":124555493412,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":1441828,"h":128850460708,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":1441828,"h":133145428004,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":1441828,"h":137440395300,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":1441828,"h":141735362596,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":1441828,"h":146030329892,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":1441828,"h":150325297188,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":1441828,"h":154620264484,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":1441828,"h":158915231780,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":1441828,"h":163210199076,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":1441828,"h":167505166372,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":1441828,"h":171800133668,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":1441828,"h":176095100964,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":1441828,"h":180390068260,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":1441828,"h":184685035556,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":1441828,"h":188980002852,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":1441828,"h":193274970148,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":1441828,"h":197569937444,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":1441828,"h":201864904740,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":1441828,"h":206159872036,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":1441828,"h":210454839332,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":1441828,"h":214749806628,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":1441828,"h":219044773924,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":1441828,"h":223339741220,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":1441828,"h":227634708516,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":1441828,"h":231929675812,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":1441828,"h":236224643108,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":1441828,"h":240519610404,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":1441828,"h":244814577700,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":1441828,"h":249109544996,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":1441828,"h":253404512292,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":1441828,"h":257699479588,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":1441828,"h":261994446884,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":1441828,"h":266289414180,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":1441828,"h":270584381476,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":1441828,"h":274879348772,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":1441828,"h":279174316068,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":1441828,"h":283469283364,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":1441828,"h":287764250660,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":1441828,"h":292059217956,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":1441828,"h":296354185252,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":1441828,"h":300649152548,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":1441828,"h":304944119844,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":1441828,"h":309239087140,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":1441828,"h":313534054436,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":1441828,"h":317829021732,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":1441828,"h":322123989028,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":1441828,"h":326418956324,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":1441828,"h":330713923620,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":1441828,"h":335008890916,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":1441828,"h":339303858212,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":1441828,"h":343598825508,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":1441828,"h":347893792804,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":1441828,"h":352188760100,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":1441828,"h":356483727396,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":1441828,"h":360778694692,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":1441828,"h":365073661988,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":1441828,"h":369368629284,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":1441828,"h":373663596580,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":1441828,"h":377958563876,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":1441828,"h":382253531172,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":1441828,"h":386548498468,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":1441828,"h":390843465764,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":1441828,"h":395138433060,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":1441828,"h":399433400356,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":1441828,"h":403728367652,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":1441828,"h":408023334948,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":1441828,"h":412318302244,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":1441828,"h":416613269540,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":1441828,"h":420908236836,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":1441828,"h":425203204132,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":1441828,"h":429498171428,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":1441828,"h":433793138724,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":1441828,"h":438088106020,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":1441828,"h":442383073316,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":1441828,"h":446678040612,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":1441828,"h":450973007908,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":1441828,"h":455267975204,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":1441828,"h":459562942500,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":1441828,"h":463857909796,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":1441828,"h":468152877092,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":1441828,"h":472447844388,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":1441828,"h":476742811684,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":1441828,"h":481037778980,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":1441828,"h":485332746276,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":1441828,"h":489627713572,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":1441828,"h":493922680868,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":1441828,"h":498217648164,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":1441828,"h":502512615460,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":1441828,"h":506807582756,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":1441828,"h":511102550052,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":1441828,"h":515397517348,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":1441828,"h":519692484644,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":1441828,"h":523987451940,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":1441828,"h":528282419236,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":1441828,"h":532577386532,"f":4194344}],"h":1441828}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.StringEnumerator", ($self) => class StringEnumerator extends $.$$.System.Object
        {
            /*System.Collections.IEnumerator*/ _baseEnumerator = null;
            $ctor$1(/*StringCollection*/ mappings)
            {
                super.$ctor();
                {
                    this._baseEnumerator = (mappings).System$Collections$IEnumerable$GetEnumerator();
                }
                return this;
            }
            /*string? */ get Current()
            {
                return $.$cast((this._baseEnumerator.System$Collections$IEnumerator$Current), $.$$.System.String);
            }
            /*bool */ MoveNext()
            {
                return this._baseEnumerator.System$Collections$IEnumerator$MoveNext();
            }
            /*void */ Reset()
            {
                this._baseEnumerator.System$Collections$IEnumerator$Reset();
            }
            static $h = 1376292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181245476,"f":50331649},"n":"Current","d":1376292,"h":12886278180,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":1376292,"h":21476212772,"f":16777217},{"r":65537,"n":"Reset","d":1376292,"h":25771180068,"f":16777217}],"l":[{"t":31850497,"n":"_baseEnumerator","d":1376292,"h":4296343588,"f":4194306}],"c":[{"p":[{"n":"mappings","p":1245220}],"n":".ctor","o":"$ctor$1","d":1376292,"h":8591310884,"f":16777224}],"h":1376292}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Specialized.StringEnumerator`; }
        });
        
        $asm.$cls("$scs.System.Collections.CompatibleComparer", ($self) => class CompatibleComparer extends $.$$.System.Object
        {
            /*IHashCodeProvider?*/ _hcp = null;
            /*IComparer?*/ _comparer = null;
            $ctor$1(/*IHashCodeProvider?*/ hashCodeProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    this._hcp = hashCodeProvider;
                    this._comparer = comparer;
                }
                return this;
            }
            /*IHashCodeProvider? */ get HashCodeProvider()
            {
                return this._hcp;
            }
            /*IComparer? */ get Comparer()
            {
                return this._comparer;
            }
            /*bool */ Equals$2(/*object?*/ a, /*object?*/ b)
            {
                return this.Compare(a, b) === 0;
            }
            /*int */ Compare(/*object?*/ a, /*object?*/ b)
            {
                if (a === b)
                {
                    return 0;
                }
                if (a === null)
                {
                    return -1;
                }
                if (b === null)
                {
                    return 1;
                }
                if (this._comparer !== null)
                {
                    return this._comparer.System$Collections$IComparer$Compare(a, b);
                }
                let ia;
                if ($.$is(a, $.$$.System.IComparable, { set $v(v){ ia = v; } }))
                {
                    return ia.System$IComparable$CompareTo(b);
                }
                throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Argument_ImplementIComparable);
            }
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                return this._hcp !== null ? this._hcp.System$Collections$IHashCodeProvider$GetHashCode(obj) : $.$$.System.Object.GetHashCode.call(obj);
            }
            //Generated interface implemetation for System.Collections.IEqualityComparer.Equals(object?, object?)
            System$Collections$IEqualityComparer$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEqualityComparer.GetHashCode(object)
            System$Collections$IEqualityComparer$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            static $h = 65572;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":31981569,"g":{"r":0,"d":0,"h":21474902052,"f":50331656},"n":"HashCodeProvider","d":65572,"h":17179934756,"f":2097160},{"p":31522817,"g":{"r":0,"d":0,"h":30064836644,"f":50331656},"n":"Comparer","d":65572,"h":25769869348,"f":2097160}],"m":[{"r":262145,"p":[{"n":"a","p":131073},{"n":"b","p":131073}],"n":"Equals","o":"@$2","d":65572,"h":34359803940,"f":16777217},{"r":655361,"p":[{"n":"a","p":131073},{"n":"b","p":131073}],"n":"Compare","d":65572,"h":38654771236,"f":16777217},{"r":655361,"p":[{"n":"obj","p":131073}],"n":"GetHashCode","o":"@$1","d":65572,"h":42949738532,"f":16777217}],"l":[{"t":31981569,"n":"_hcp","d":65572,"h":4295032868,"f":4194306},{"t":31522817,"n":"_comparer","d":65572,"h":8590000164,"f":4194306}],"c":[{"p":[{"n":"hashCodeProvider","p":31981569},{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$1","d":65572,"h":12884967460,"f":16777224}],"i":[31916033],"h":65572}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer ]; }
            static get $fullName() { return `System.Collections.CompatibleComparer`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.StringDictionary", ($self) => class StringDictionary extends $.$$.System.Object
        {
            /*Hashtable*/ contents = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                return this.contents.Count;
            }
            /*bool */ get IsSynchronized()
            {
                return this.contents.IsSynchronized;
            }
            /*string?*/ get_Item(/*string*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return $.$cast(this.contents.get_Item($.$$.System.String.ToLowerInvariant.call(key)), $.$$.System.String);
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.set_Item($.$$.System.String.ToLowerInvariant.call(key), value);
            }
            /*ICollection */ get Keys$1()
            {
                return this.contents.Keys;
            }
            /*object */ get SyncRoot()
            {
                return this.contents.SyncRoot;
            }
            /*ICollection */ get Values()
            {
                return this.contents.Values;
            }
            /*void */ Add(/*string*/ key, /*string?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.Add($.$$.System.String.ToLowerInvariant.call(key), value);
            }
            /*void */ Clear()
            {
                this.contents.Clear();
            }
            /*bool */ ContainsKey(/*string*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return this.contents.ContainsKey($.$$.System.String.ToLowerInvariant.call(key));
            }
            /*bool */ ContainsValue(/*string?*/ value)
            {
                return this.contents.ContainsValue(value);
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.contents.CopyTo(array, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this.contents.GetEnumerator();
            }
            /*void */ Remove(/*string*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.Remove($.$$.System.String.ToLowerInvariant.call(key));
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.contents = new $.$$.System.Collections.Hashtable().$ctor$1();
            }
            static $h = 1310756;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181179940,"f":50331777},"n":"Count","d":1310756,"h":12886212644,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":25771114532,"f":50331777},"n":"IsSynchronized","d":1310756,"h":21476147236,"f":2097281},{"p":1310721,"i":[{"n":"key","p":1310721}],"g":{"r":0,"d":0,"h":34361049124,"f":50331777},"s":{"r":0,"d":0,"h":38656016420,"f":83886209},"n":"Item","o":"@$2","d":1310756,"h":30066081828,"f":2097281},{"p":31457281,"g":{"r":0,"d":0,"h":47245951012,"f":50331777},"n":"Keys","o":"@$1","d":1310756,"h":42950983716,"f":2097281},{"p":131073,"g":{"r":0,"d":0,"h":55835885604,"f":50331777},"n":"SyncRoot","d":1310756,"h":51540918308,"f":2097281},{"p":31457281,"g":{"r":0,"d":0,"h":64425820196,"f":50331777},"n":"Values","d":1310756,"h":60130852900,"f":2097281}],"m":[{"r":65537,"p":[{"n":"key","p":1310721},{"n":"value","p":1310721}],"n":"Add","d":1310756,"h":68720787492,"f":16777345},{"r":65537,"n":"Clear","d":1310756,"h":73015754788,"f":16777345},{"r":262145,"p":[{"n":"key","p":1310721}],"n":"ContainsKey","d":1310756,"h":77310722084,"f":16777345},{"r":262145,"p":[{"n":"value","p":1310721}],"n":"ContainsValue","d":1310756,"h":81605689380,"f":16777345},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":1310756,"h":85900656676,"f":16777345},{"r":31850497,"n":"GetEnumerator","d":1310756,"h":90195623972,"f":16777345},{"r":65537,"p":[{"n":"key","p":1310721}],"n":"Remove","d":1310756,"h":94490591268,"f":16777345}],"l":[{"t":31064065,"n":"contents","d":1310756,"h":4296278052,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1310756,"h":8591245348,"f":16777217}],"i":[31719425],"h":1310756,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]},{"t":393255,"c":17180262439,"a":[{"v":"System.Diagnostics.Design.StringDictionaryCodeDomSerializer, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.ComponentModel.Design.Serialization.CodeDomSerializer, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.StringDictionary`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.StringCollection", ($self) => class StringCollection extends $.$$.System.Object
        {
            /*ArrayList*/ data = null;
            /*string?*/ get_Item(/*int*/ index)
            {
                return ($.$cast(this.data.get_Item(index), $.$$.System.String));
            }
            /*void*/ set_Item(/*int*/ index, /*string?*/ value)
            {
                this.data.set_Item(index, value);
            }
            /*int */ get Count()
            {
                return this.data.Count;
            }
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return false;
            }
            /*int */ Add(/*string?*/ value)
            {
                return this.data.Add(value);
            }
            /*void */ AddRange(/*string?[]*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.data.AddRange(value);
            }
            /*void */ Clear()
            {
                this.data.Clear();
            }
            /*bool */ Contains(/*string?*/ value)
            {
                return this.data.Contains(value);
            }
            /*void */ CopyTo(/*string?[]*/ array, /*int*/ index)
            {
                this.data.CopyTo(array, index);
            }
            /*StringEnumerator */ GetEnumerator()
            {
                return new $.$scs.System.Collections.Specialized.StringEnumerator().$ctor$1(this);
            }
            /*int */ IndexOf(/*string?*/ value)
            {
                return this.data.IndexOf$2(value);
            }
            /*void */ Insert(/*int*/ index, /*string?*/ value)
            {
                this.data.Insert(index, value);
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*void */ Remove(/*string?*/ value)
            {
                this.data.Remove(value);
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                this.data.RemoveAt(index);
            }
            /*object */ get SyncRoot()
            {
                return this.data.SyncRoot;
            }
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                this.set_Item(index, $.$cast(value, $.$$.System.String));
            }
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                return this.Add($.$cast(value, $.$$.System.String));
            }
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                return this.Contains($.$cast(value, $.$$.System.String));
            }
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                return this.IndexOf($.$cast(value, $.$$.System.String));
            }
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                this.Insert(index, $.$cast(value, $.$$.System.String));
            }
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                this.Remove($.$cast(value, $.$$.System.String));
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                this.data.CopyTo(array, index);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.data.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.data = new $.$$.System.Collections.ArrayList().$ctor$1();
            }
            static $h = 1245220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":12886147108,"f":50331649},"s":{"r":0,"d":0,"h":17181114404,"f":83886081},"n":"Item","o":"@$2","d":1245220,"h":8591179812,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25771048996,"f":50331649},"n":"Count","d":1245220,"h":21476081700,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":34360983588,"f":50331650},"n":"{32047105}.IsReadOnly","o":"System$Collections$IList$IsReadOnly","d":1245220,"h":30066016292,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":42950918180,"f":50331650},"n":"{32047105}.IsFixedSize","o":"System$Collections$IList$IsFixedSize","d":1245220,"h":38655950884,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":85900591140,"f":50331649},"n":"IsReadOnly","d":1245220,"h":81605623844,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94490525732,"f":50331649},"n":"IsSynchronized","d":1245220,"h":90195558436,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":111670394916,"f":50331649},"n":"SyncRoot","d":1245220,"h":107375427620,"f":2097153},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":120260329508,"f":50331650},"s":{"r":0,"d":0,"h":124555296804,"f":83886082},"n":"{32047105}.this[]","o":"System$Collections$IList$Item","d":1245220,"h":115965362212,"f":2097154}],"m":[{"r":655361,"p":[{"n":"value","p":1310721}],"n":"Add","d":1245220,"h":47245885476,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$$.System.String).$h}],"n":"AddRange","d":1245220,"h":51540852772,"f":16777217},{"r":65537,"n":"Clear","d":1245220,"h":55835820068,"f":16777217},{"r":262145,"p":[{"n":"value","p":1310721}],"n":"Contains","d":1245220,"h":60130787364,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$$.System.String).$h},{"n":"index","p":655361}],"n":"CopyTo","d":1245220,"h":64425754660,"f":16777217},{"r":1376292,"n":"GetEnumerator","d":1245220,"h":68720721956,"f":16777217},{"r":655361,"p":[{"n":"value","p":1310721}],"n":"IndexOf","d":1245220,"h":73015689252,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":1310721}],"n":"Insert","d":1245220,"h":77310656548,"f":16777217},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"Remove","d":1245220,"h":98785493028,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":1245220,"h":103080460324,"f":16777217}],"l":[{"t":23724033,"n":"data","d":1245220,"h":4296212516,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1245220,"h":158915035172,"f":16777217}],"i":[32047105,31457281,31719425],"h":1245220,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.StringCollection`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.HybridDictionary", ($self) => class HybridDictionary extends $.$$.System.Object
        {
            /*int*/ static CutoverPoint = 9;
            /*int*/ static InitialHashtableSize = 13;
            /*int*/ static FixedSizeCutoverPoint = 6;
            /*ListDictionary?*/ list = null;
            /*Hashtable?*/ hashtable = null;
            /*bool*/ caseInsensitive = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*int*/ initialSize)
            {
                this.$ctor$3(initialSize, false);
                {
                }
                return this;
            }
            $ctor$2(/*bool*/ caseInsensitive)
            {
                super.$ctor();
                {
                    this.caseInsensitive = caseInsensitive;
                }
                return this;
            }
            $ctor$3(/*int*/ initialSize, /*bool*/ caseInsensitive)
            {
                super.$ctor();
                {
                    this.caseInsensitive = caseInsensitive;
                    if (initialSize >= 6/*FixedSizeCutoverPoint*/)
                    {
                        if (caseInsensitive)
                        {
                            this.hashtable = new $.$$.System.Collections.Hashtable().$ctor$11(initialSize, $.$$.System.StringComparer.OrdinalIgnoreCase);
                        }
                        else 
                        {
                            this.hashtable = new $.$$.System.Collections.Hashtable().$ctor$16(initialSize);
                        }
                    }
                }
                return this;
            }
            /*object?*/ get_Item(/*object*/ key)
            {
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.get_Item(key);
                }
                else if (cachedList !== null)
                {
                    return cachedList.get_Item(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
                return null;
            }
            /*void*/ set_Item(/*object*/ key, /*object?*/ value)
            {
                if (this.hashtable !== null)
                {
                    this.hashtable.set_Item(key, value);
                }
                else if (this.list !== null)
                {
                    if (this.list.Count >= ((9/*CutoverPoint*/ - 1) | 0))
                    {
                        this.ChangeOver();
                        $.$$.System.Diagnostics.Debug.Assert$2(this.hashtable !== null, "hashtable != null");
                        this.hashtable.set_Item(key, value);
                    }
                    else 
                    {
                        this.list.set_Item(key, value);
                    }
                }
                else 
                {
                    this.list = new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                    this.list.set_Item(key, value);
                }
            }
            /*ListDictionary */ get List()
            {
                return this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
            }
            /*void */ ChangeOver()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.list !== null, "list != null");
                /*IDictionaryEnumerator*/ let en = this.list.GetEnumerator();
                /*Hashtable*/ let newTable;
                if (this.caseInsensitive)
                {
                    newTable = new $.$$.System.Collections.Hashtable().$ctor$11(13/*InitialHashtableSize*/, $.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                else 
                {
                    newTable = new $.$$.System.Collections.Hashtable().$ctor$16(13/*InitialHashtableSize*/);
                }
                while(en.System$Collections$IEnumerator$MoveNext())
                {
                    newTable.Add(en.System$Collections$IDictionaryEnumerator$Key, en.System$Collections$IDictionaryEnumerator$Value);
                }
                this.hashtable = newTable;
                this.list = null;
            }
            /*int */ get Count()
            {
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.Count;
                }
                else if (cachedList !== null)
                {
                    return cachedList.Count;
                }
                else 
                {
                    return 0;
                }
            }
            /*ICollection */ get Keys$1()
            {
                if (this.hashtable !== null)
                {
                    return this.hashtable.Keys;
                }
                else 
                {
                    return this.List.Keys$1;
                }
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*bool */ get IsFixedSize()
            {
                return false;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*ICollection */ get Values()
            {
                if (this.hashtable !== null)
                {
                    return this.hashtable.Values;
                }
                else 
                {
                    return this.List.Values;
                }
            }
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                if (this.hashtable !== null)
                {
                    this.hashtable.Add(key, value);
                }
                else 
                {
                    if (this.list === null)
                    {
                        this.list = new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                        this.list.Add(key, value);
                    }
                    else if (((this.list.Count + 1) | 0) >= 9/*CutoverPoint*/)
                    {
                        this.ChangeOver();
                        $.$$.System.Diagnostics.Debug.Assert$2(this.hashtable !== null, "hashtable != null");
                        this.hashtable.Add(key, value);
                    }
                    else 
                    {
                        this.list.Add(key, value);
                    }
                }
            }
            /*void */ Clear()
            {
                if (this.hashtable !== null)
                {
                    /*Hashtable*/ let cachedHashtable = this.hashtable;
                    this.hashtable = null;
                    cachedHashtable.Clear();
                }
                if (this.list !== null)
                {
                    /*ListDictionary*/ let cachedList = this.list;
                    this.list = null;
                    cachedList.Clear();
                }
            }
            /*bool */ Contains(/*object*/ key)
            {
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.Contains(key);
                }
                else if (cachedList !== null)
                {
                    return cachedList.Contains(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
                return false;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                if (this.hashtable !== null)
                {
                    this.hashtable.CopyTo(array, index);
                }
                else 
                {
                    this.List.CopyTo(array, index);
                }
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                if (this.hashtable !== null)
                {
                    return this.hashtable.GetEnumerator();
                }
                this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                return this.list.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                if (this.hashtable !== null)
                {
                    return this.hashtable.GetEnumerator();
                }
                this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                return this.list.GetEnumerator();
            }
            /*void */ Remove(/*object*/ key)
            {
                if (this.hashtable !== null)
                {
                    this.hashtable.Remove(key);
                }
                else if (this.list !== null)
                {
                    this.list.Remove(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 262180;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":51539869732,"f":50331649},"s":{"r":0,"d":0,"h":55834837028,"f":83886081},"n":"Item","o":"@$2","d":262180,"h":47244902436,"f":2097153},{"p":393252,"g":{"r":0,"d":0,"h":64424771620,"f":50331650},"n":"List","d":262180,"h":60129804324,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":77309673508,"f":50331649},"n":"Count","d":262180,"h":73014706212,"f":2097153},{"p":31457281,"g":{"r":0,"d":0,"h":85899608100,"f":50331649},"n":"Keys","o":"@$1","d":262180,"h":81604640804,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94489542692,"f":50331649},"n":"IsReadOnly","d":262180,"h":90194575396,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":103079477284,"f":50331649},"n":"IsFixedSize","d":262180,"h":98784509988,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":111669411876,"f":50331649},"n":"IsSynchronized","d":262180,"h":107374444580,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":120259346468,"f":50331649},"n":"SyncRoot","d":262180,"h":115964379172,"f":2097153},{"p":31457281,"g":{"r":0,"d":0,"h":128849281060,"f":50331649},"n":"Values","d":262180,"h":124554313764,"f":2097153}],"m":[{"r":65537,"n":"ChangeOver","d":262180,"h":68719738916,"f":16777218},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Add","d":262180,"h":133144248356,"f":16777217},{"r":65537,"n":"Clear","d":262180,"h":137439215652,"f":16777217},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":262180,"h":141734182948,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":262180,"h":146029150244,"f":16777217},{"r":31653889,"n":"GetEnumerator","d":262180,"h":150324117540,"f":16777217},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":262180,"h":158914052132,"f":16777217}],"l":[{"t":655361,"n":"CutoverPoint","d":262180,"h":4295229476,"f":4194338},{"t":655361,"n":"InitialHashtableSize","d":262180,"h":8590196772,"f":4194338},{"t":655361,"n":"FixedSizeCutoverPoint","d":262180,"h":12885164068,"f":4194338},{"t":393252,"n":"list","d":262180,"h":17180131364,"f":4194306},{"t":31064065,"n":"hashtable","d":262180,"h":21475098660,"f":4194306},{"t":262145,"n":"caseInsensitive","d":262180,"h":25770065956,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":262180,"h":30065033252,"f":16777217},{"p":[{"n":"initialSize","p":655361}],"n":".ctor","o":"$ctor$4","d":262180,"h":34360000548,"f":16777217},{"p":[{"n":"caseInsensitive","p":262145}],"n":".ctor","o":"$ctor$2","d":262180,"h":38654967844,"f":16777217},{"p":[{"n":"initialSize","p":655361},{"n":"caseInsensitive","p":262145}],"n":".ctor","o":"$ctor$3","d":262180,"h":42949935140,"f":16777217}],"i":[31588353,31457281,31719425],"h":262180,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.HybridDictionary`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.ListDictionary", ($self) => class ListDictionary extends $.$$.System.Object
        {
            /*DictionaryNode?*/ head = null;
            /*int*/ version = 0;
            /*int*/ count = 0;
            /*IComparer?*/ comparer = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    this.comparer = comparer;
                }
                return this;
            }
            /*object?*/ get_Item(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*DictionaryNode?*/ let node = this.head;
                if (this.comparer === null)
                {
                    while(node !== null)
                    {
                        /*object*/ let oldKey = node.key;
                        if ($.$$.System.Object.Equals$1.call(oldKey, key))
                        {
                            return node.value;
                        }
                        node = node.next;
                    }
                }
                else 
                {
                    while(node !== null)
                    {
                        /*object*/ let oldKey = node.key;
                        if (this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                        {
                            return node.value;
                        }
                        node = node.next;
                    }
                }
                return null;
            }
            /*void*/ set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                /*DictionaryNode?*/ let node;
                for(node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        break;
                    }
                    last = node;
                }
                if (node !== null)
                {
                    node.value = value;
                    return;
                }
                /*DictionaryNode*/ let newNode = new $.$scs.System.Collections.Specialized.ListDictionary.DictionaryNode().$ctor$1();
                newNode.key = key;
                newNode.value = value;
                if (last !== null)
                {
                    last.next = newNode;
                }
                else 
                {
                    this.head = newNode;
                }
                this.count++;
            }
            /*int */ get Count()
            {
                return this.count;
            }
            /*ICollection */ get Keys$1()
            {
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection().$ctor$1(this, true);
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*bool */ get IsFixedSize()
            {
                return false;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*ICollection */ get Values()
            {
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection().$ctor$1(this, false);
            }
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Format$6($.$scs.System.SR.Argument_AddingDuplicate, key));
                    }
                    last = node;
                }
                /*DictionaryNode*/ let newNode = new $.$scs.System.Collections.Specialized.ListDictionary.DictionaryNode().$ctor$1();
                newNode.key = key;
                newNode.value = value;
                if (last !== null)
                {
                    last.next = newNode;
                }
                else 
                {
                    this.head = newNode;
                }
                this.count++;
            }
            /*void */ Clear()
            {
                this.count = 0;
                this.head = null;
                this.version++;
            }
            /*bool */ Contains(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        return true;
                    }
                }
                return false;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    array.SetValue$2(new $.$$.System.Collections.DictionaryEntry().$ctor$3(node.key, node.value), index);
                    index++;
                }
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator().$ctor$1(this);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator().$ctor$1(this);
            }
            /*void */ Remove(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                /*DictionaryNode?*/ let node;
                for(node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        break;
                    }
                    last = node;
                }
                if (node === null)
                {
                    return;
                }
                if (node === this.head)
                {
                    this.head = node.next;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(last !== null, "last != null");
                    last.next = node.next;
                }
                this.count--;
            }
            static $_NodeEnumerator;
            static get NodeEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_NodeEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator", ($self) => class NodeEnumerator extends $.$$.System.Object
                {
                    /*ListDictionary*/ _list = null;
                    /*DictionaryNode?*/ _current = null;
                    /*int*/ _version = 0;
                    /*bool*/ _start = false;
                    $ctor$1(/*ListDictionary*/ list)
                    {
                        super.$ctor();
                        {
                            this._list = list;
                            this._version = list.version;
                            this._start = true;
                            this._current = null;
                        }
                        return this;
                    }
                    /*object */ get Current()
                    {
                        return this.Entry;
                    }
                    /*DictionaryEntry */ get Entry()
                    {
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3(this._current.key, this._current.value);
                    }
                    /*object */ get Key()
                    {
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._current.key;
                    }
                    /*object? */ get Value()
                    {
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._current.value;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._start)
                        {
                            this._current = this._list.head;
                            this._start = false;
                        }
                        else if (this._current !== null)
                        {
                            this._current = this._current.next;
                        }
                        return (this._current !== null);
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._start = true;
                        this._current = null;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return this.Key;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return this.Value;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return this.Entry;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 524324;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":30065295396,"f":50331649},"n":"Current","d":524324,"h":25770328100,"f":2097153},{"p":25821185,"g":{"r":0,"d":0,"h":38655229988,"f":50331649},"n":"Entry","d":524324,"h":34360262692,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":47245164580,"f":50331649},"n":"Key","d":524324,"h":42950197284,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":55835099172,"f":50331649},"n":"Value","d":524324,"h":51540131876,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":524324,"h":60130066468,"f":16777217},{"r":65537,"n":"Reset","d":524324,"h":64425033764,"f":16777217}],"l":[{"t":393252,"n":"_list","d":524324,"h":4295491620,"f":4194306},{"t":458788,"n":"_current","d":524324,"h":8590458916,"f":4194306},{"t":655361,"n":"_version","d":524324,"h":12885426212,"f":4194306},{"t":262145,"n":"_start","d":524324,"h":17180393508,"f":4194306}],"c":[{"p":[{"n":"list","p":393252}],"n":".ctor","o":"$ctor$1","d":524324,"h":21475360804,"f":16777217}],"i":[31653889,31850497],"d":393252,"h":524324}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeEnumerator`; }
                }, $cls, ($v) => $cls.$_NodeEnumerator = $v);
            }
            static $_NodeKeyValueCollection;
            static get NodeKeyValueCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_NodeKeyValueCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection", ($self) => class NodeKeyValueCollection extends $.$$.System.Object
                {
                    /*ListDictionary*/ _list = null;
                    /*bool*/ _isKeys = false;
                    $ctor$1(/*ListDictionary*/ list, /*bool*/ isKeys)
                    {
                        super.$ctor();
                        {
                            this._list = list;
                            this._isKeys = isKeys;
                        }
                        return this;
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        for(/*DictionaryNode?*/ let node = this._list.head; node !== null; node = node.next)
                        {
                            array.SetValue$2(this._isKeys ? node.key : node.value, index);
                            index++;
                        }
                    }
                    /*int */ get System$Collections$ICollection$Count()
                    {
                        /*int*/ let count = 0;
                        for(/*DictionaryNode?*/ let node = this._list.head; node !== null; node = node.next)
                        {
                            count++;
                        }
                        return count;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return this._list.SyncRoot;
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator().$ctor$1(this._list, this._isKeys);
                    }
                    static $_NodeKeyValueEnumerator;
                    static get NodeKeyValueEnumerator()
                    {
                        let $cls = $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection;
                        return $cls.$_NodeKeyValueEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator", ($self) => class NodeKeyValueEnumerator extends $.$$.System.Object
                        {
                            /*ListDictionary*/ _list = null;
                            /*DictionaryNode?*/ _current = null;
                            /*int*/ _version = 0;
                            /*bool*/ _isKeys = false;
                            /*bool*/ _start = false;
                            $ctor$1(/*ListDictionary*/ list, /*bool*/ isKeys)
                            {
                                super.$ctor();
                                {
                                    this._list = list;
                                    this._isKeys = isKeys;
                                    this._version = list.version;
                                    this._start = true;
                                    this._current = null;
                                }
                                return this;
                            }
                            /*object? */ get Current()
                            {
                                if (this._current === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return this._isKeys ? this._current.key : this._current.value;
                            }
                            /*bool */ MoveNext()
                            {
                                if (this._version !== this._list.version)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                                }
                                if (this._start)
                                {
                                    this._current = this._list.head;
                                    this._start = false;
                                }
                                else if (this._current !== null)
                                {
                                    this._current = this._current.next;
                                }
                                return (this._current !== null);
                            }
                            /*void */ Reset()
                            {
                                if (this._version !== this._list.version)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                                }
                                this._start = true;
                                this._current = null;
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                            get System$Collections$IEnumerator$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                            System$Collections$IEnumerator$Reset()
                            {
                                return this.Reset(...arguments);
                            }
                            static $h = 655396;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":34360393764,"f":50331649},"n":"Current","d":655396,"h":30065426468,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":655396,"h":38655361060,"f":16777217},{"r":65537,"n":"Reset","d":655396,"h":42950328356,"f":16777217}],"l":[{"t":393252,"n":"_list","d":655396,"h":4295622692,"f":4194306},{"t":458788,"n":"_current","d":655396,"h":8590589988,"f":4194306},{"t":655361,"n":"_version","d":655396,"h":12885557284,"f":4194306},{"t":262145,"n":"_isKeys","d":655396,"h":17180524580,"f":4194306},{"t":262145,"n":"_start","d":655396,"h":21475491876,"f":4194306}],"c":[{"p":[{"n":"list","p":393252},{"n":"isKeys","p":262145}],"n":".ctor","o":"$ctor$1","d":655396,"h":25770459172,"f":16777217}],"i":[31850497],"d":589860,"h":655396}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator`; }
                        }, $cls, ($v) => $cls.$_NodeKeyValueEnumerator = $v);
                    }
                    static $h = 589860;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25770393636,"f":50331650},"n":"{31457281}.Count","o":"System$Collections$ICollection$Count","d":589860,"h":21475426340,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":34360328228,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":589860,"h":30065360932,"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":42950262820,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":589860,"h":38655295524,"f":2097154}],"l":[{"t":393252,"n":"_list","d":589860,"h":4295557156,"f":4194306},{"t":262145,"n":"_isKeys","d":589860,"h":8590524452,"f":4194306}],"c":[{"p":[{"n":"list","p":393252},{"n":"isKeys","p":262145}],"n":".ctor","o":"$ctor$1","d":589860,"h":12885491748,"f":16777217}],"i":[31457281,31719425],"j":[655396],"d":393252,"h":589860}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeKeyValueCollection`; }
                }, $cls, ($v) => $cls.$_NodeKeyValueCollection = $v);
            }
            static $_DictionaryNode;
            static get DictionaryNode()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_DictionaryNode ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.DictionaryNode", ($self) => class DictionaryNode extends $.$$.System.Object
                {
                    /*object*/ key = null;
                    /*object?*/ value = null;
                    /*DictionaryNode?*/ next = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.key = null;
                    }
                    static $h = 458788;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":131073,"n":"key","d":458788,"h":4295426084,"f":4194305},{"t":131073,"n":"value","d":458788,"h":8590393380,"f":4194305},{"t":458788,"n":"next","d":458788,"h":12885360676,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$1","d":458788,"h":17180327972,"f":16777217}],"d":393252,"h":458788,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.DictionaryNode`; }
                }, $cls, ($v) => $cls.$_DictionaryNode = $v);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                return this.IsFixedSize;
            }
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            static $h = 393252;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":34360131620,"f":50331649},"s":{"r":0,"d":0,"h":38655098916,"f":83886081},"n":"Item","o":"@$2","d":393252,"h":30065164324,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47245033508,"f":50331649},"n":"Count","d":393252,"h":42950066212,"f":2097153},{"p":31457281,"g":{"r":0,"d":0,"h":55834968100,"f":50331649},"n":"Keys","o":"@$1","d":393252,"h":51540000804,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64424902692,"f":50331649},"n":"IsReadOnly","d":393252,"h":60129935396,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":73014837284,"f":50331649},"n":"IsFixedSize","d":393252,"h":68719869988,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81604771876,"f":50331649},"n":"IsSynchronized","d":393252,"h":77309804580,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":90194706468,"f":50331649},"n":"SyncRoot","d":393252,"h":85899739172,"f":2097153},{"p":31457281,"g":{"r":0,"d":0,"h":98784641060,"f":50331649},"n":"Values","d":393252,"h":94489673764,"f":2097153}],"m":[{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Add","d":393252,"h":103079608356,"f":16777217},{"r":65537,"n":"Clear","d":393252,"h":107374575652,"f":16777217},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":393252,"h":111669542948,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":393252,"h":115964510244,"f":16777217},{"r":31653889,"n":"GetEnumerator","d":393252,"h":120259477540,"f":16777217},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":393252,"h":128849412132,"f":16777217}],"l":[{"t":458788,"n":"head","d":393252,"h":4295360548,"f":4194306},{"t":655361,"n":"version","d":393252,"h":8590327844,"f":4194306},{"t":655361,"n":"count","d":393252,"h":12885295140,"f":4194306},{"t":31522817,"n":"comparer","d":393252,"h":17180262436,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":393252,"h":21475229732,"f":16777217},{"p":[{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$2","d":393252,"h":25770197028,"f":16777217}],"i":[31588353,31457281,31719425],"j":[524324,589860,458788],"h":393252,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.ListDictionary`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.OrderedDictionary", ($self) => class OrderedDictionary extends $.$$.System.Object
        {
            /*ArrayList?*/ _objectsArray = null;
            /*Hashtable?*/ _objectsTable = null;
            /*int*/ _initialCapacity = 0;
            /*IEqualityComparer?*/ _comparer = null;
            /*bool*/ _readOnly = false;
            /*SerializationInfo?*/ _siInfo = null;
            /*string*/ static KeyComparerName = null;
            /*string*/ static ArrayListName = null;
            /*string*/ static ReadOnlyName = null;
            /*string*/ static InitCapacityName = null;
            $ctor$1()
            {
                this.$ctor$4(0);
                {
                }
                return this;
            }
            $ctor$4(/*int*/ capacity)
            {
                this.$ctor$3(capacity, null);
                {
                }
                return this;
            }
            $ctor$2(/*IEqualityComparer?*/ comparer)
            {
                this.$ctor$3(0, comparer);
                {
                }
                return this;
            }
            $ctor$3(/*int*/ capacity, /*IEqualityComparer?*/ comparer)
            {
                super.$ctor();
                {
                    this._initialCapacity = capacity;
                    this._comparer = comparer;
                }
                return this;
            }
            $ctor$6(/*OrderedDictionary*/ dictionary)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(dictionary !== null, "dictionary != null");
                    this._readOnly = true;
                    this._objectsArray = dictionary._objectsArray;
                    this._objectsTable = dictionary._objectsTable;
                    this._comparer = dictionary._comparer;
                    this._initialCapacity = dictionary._initialCapacity;
                }
                return this;
            }
            $ctor$5(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._siInfo = info;
                }
                return this;
            }
            /*int */ get Count()
            {
                if (this._objectsArray === null)
                {
                    return 0;
                }
                return this._objectsArray.Count;
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return this._readOnly;
            }
            /*bool */ get IsReadOnly()
            {
                return this._readOnly;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*ICollection */ get Keys$1()
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection().$ctor$1(objectsArray, objectsTable, this._comparer);
            }
            /*ArrayList */ EnsureObjectsArray()
            {
                return this._objectsArray ??= new $.$$.System.Collections.ArrayList().$ctor$3(this._initialCapacity);
            }
            /*Hashtable */ EnsureObjectsTable()
            {
                return this._objectsTable ??= new $.$$.System.Collections.Hashtable().$ctor$11(this._initialCapacity, this._comparer);
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*object?*/ get_Item(/*int*/ index)
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Value;
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                if (this._objectsArray === null || index < 0 || index >= this._objectsArray.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                }
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*object*/ let key = ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Key;
                objectsArray.set_Item(index, new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
                objectsTable.set_Item(key, value);
            }
            /*object?*/ get_Item$1(/*object*/ key)
            {
                if (this._objectsTable === null)
                {
                    return null;
                }
                return this._objectsTable.get_Item(key);
            }
            /*void*/ set_Item$1(/*object*/ key, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                if (objectsTable.Contains(key))
                {
                    objectsTable.set_Item(key, value);
                    /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                    objectsArray.set_Item(this.IndexOfKey(key), new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
                }
                else 
                {
                    this.Add(key, value);
                }
            }
            /*ICollection */ get Values()
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection().$ctor$2(objectsArray);
            }
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Add(key, value);
                objectsArray.Add(new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
            }
            /*void */ Clear()
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                this._objectsTable?.Clear();
                this._objectsArray?.Clear();
            }
            /*OrderedDictionary */ AsReadOnly()
            {
                return new $.$scs.System.Collections.Specialized.OrderedDictionary().$ctor$6(this);
            }
            /*bool */ Contains(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (this._objectsTable === null)
                {
                    return false;
                }
                return this._objectsTable.Contains(key);
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                objectsTable.CopyTo(array, index);
            }
            /*int */ IndexOfKey(/*object*/ key)
            {
                if (this._objectsArray === null)
                {
                    return -1;
                }
                for(/*int*/ let i = 0; i < this._objectsArray.Count; i++)
                {
                    /*object*/ let o = ($.$cast(this._objectsArray.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Key;
                    if (this._comparer !== null)
                    {
                        if (this._comparer.System$Collections$IEqualityComparer$Equals(o, key))
                        {
                            return i;
                        }
                    }
                    else 
                    {
                        if ($.$$.System.Object.Equals$1.call(o, key))
                        {
                            return i;
                        }
                    }
                }
                return -1;
            }
            /*void */ Insert(/*int*/ index, /*object*/ key, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, index, this.Count, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Add(key, value);
                objectsArray.Insert(index, new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$$.System.Int32, index, this.Count, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*object*/ let key = ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Key;
                objectsArray.RemoveAt(index);
                objectsTable.Remove(key);
            }
            /*void */ Remove(/*object*/ key)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*int*/ let index = this.IndexOfKey(key);
                if (index < 0)
                {
                    return;
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Remove(key);
                objectsArray.RemoveAt(index);
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(objectsArray, 3/*OrderedDictionaryEnumerator.DictionaryEntry*/);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(objectsArray, 3/*OrderedDictionaryEnumerator.DictionaryEntry*/);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$9("KeyComparer"/*KeyComparerName*/, this._comparer, $.$$.System.Collections.IEqualityComparer.$type);
                info.AddValue("ReadOnly"/*ReadOnlyName*/, this._readOnly);
                info.AddValue$7("InitialCapacity"/*InitCapacityName*/, this._initialCapacity);
                /*object[]*/ let serArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this.Count], null);
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsArray.CopyTo$1(serArray);
                info.AddValue$10("ArrayList"/*ArrayListName*/, serArray);
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
                this.OnDeserialization(sender);
            }
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                if (this._siInfo === null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$scs.System.SR.Serialization_InvalidOnDeser);
                }
                this._comparer = $.$cast(this._siInfo.GetValue("KeyComparer"/*KeyComparerName*/, $.$$.System.Collections.IEqualityComparer.$type), $.$$.System.Collections.IEqualityComparer);
                this._readOnly = this._siInfo.GetBoolean("ReadOnly"/*ReadOnlyName*/);
                this._initialCapacity = this._siInfo.GetInt32("InitialCapacity"/*InitCapacityName*/);
                /*object[]?*/ let serArray = $.$cast(this._siInfo.GetValue("ArrayList"/*ArrayListName*/, $.$typeArray($.$$.System.Object).$type), $.$typeArray($.$$.System.Object));
                if (serArray !== null)
                {
                    /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                    /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                    let $i1 = 0;
                    let $arr1 = serArray;
                    while ($i1 < $arr1.length)
                    {
                        let o = $arr1[$i1++];
                        /*DictionaryEntry*/ let entry;
                        try
                        {
                            entry = $.$cast(o, $.$$.System.Collections.DictionaryEntry);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$scs.System.SR.OrderedDictionary_SerializationMismatch);
                        }
                        objectsArray.Add(entry.Clone());
                        objectsTable.Add(entry.Key, entry.Value);
                    }
                }
            }
            static $_OrderedDictionaryEnumerator;
            static get OrderedDictionaryEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.OrderedDictionary;
                return $cls.$_OrderedDictionaryEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator", ($self) => class OrderedDictionaryEnumerator extends $.$$.System.Object
                {
                    /*int*/ _objectReturnType = 0;
                    /*int*/ static Keys$1 = 1;
                    /*int*/ static Values = 2;
                    /*int*/ static DictionaryEntry = 3;
                    /*IEnumerator*/ _arrayEnumerator = null;
                    $ctor$1(/*ArrayList*/ array, /*int*/ objectReturnType)
                    {
                        super.$ctor();
                        {
                            this._arrayEnumerator = array.GetEnumerator();
                            this._objectReturnType = objectReturnType;
                        }
                        return this;
                    }
                    /*object? */ get Current()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        if (this._objectReturnType === 1/*Keys*/)
                        {
                            return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key;
                        }
                        if (this._objectReturnType === 2/*Values*/)
                        {
                            return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value;
                        }
                        return this.Entry;
                    }
                    /*DictionaryEntry */ get Entry()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3(($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key, ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value);
                    }
                    /*object */ get Key()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key;
                    }
                    /*object? */ get Value()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value;
                    }
                    /*bool */ MoveNext()
                    {
                        return this._arrayEnumerator.System$Collections$IEnumerator$MoveNext();
                    }
                    /*void */ Reset()
                    {
                        this._arrayEnumerator.System$Collections$IEnumerator$Reset();
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return this.Key;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return this.Value;
                    }
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return this.Entry;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 1114148;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":34360852516,"f":50331649},"n":"Current","d":1114148,"h":30065885220,"f":2097153},{"p":25821185,"g":{"r":0,"d":0,"h":42950787108,"f":50331649},"n":"Entry","d":1114148,"h":38655819812,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":51540721700,"f":50331649},"n":"Key","d":1114148,"h":47245754404,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":60130656292,"f":50331649},"n":"Value","d":1114148,"h":55835688996,"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":1114148,"h":64425623588,"f":16777217},{"r":65537,"n":"Reset","d":1114148,"h":68720590884,"f":16777217}],"l":[{"t":655361,"n":"_objectReturnType","d":1114148,"h":4296081444,"f":4194306},{"t":655361,"n":"Keys","o":"@$1","d":1114148,"h":8591048740,"f":4194344},{"t":655361,"n":"Values","d":1114148,"h":12886016036,"f":4194344},{"t":655361,"n":"DictionaryEntry","d":1114148,"h":17180983332,"f":4194344},{"t":31850497,"n":"_arrayEnumerator","d":1114148,"h":21475950628,"f":4194306}],"c":[{"p":[{"n":"array","p":23724033},{"n":"objectReturnType","p":655361}],"n":".ctor","o":"$ctor$1","d":1114148,"h":25770917924,"f":16777224}],"i":[31653889,31850497],"d":1048612,"h":1114148}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator`; }
                }, $cls, ($v) => $cls.$_OrderedDictionaryEnumerator = $v);
            }
            static $_OrderedDictionaryKeyValueCollection;
            static get OrderedDictionaryKeyValueCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.OrderedDictionary;
                return $cls.$_OrderedDictionaryKeyValueCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection", ($self) => class OrderedDictionaryKeyValueCollection extends $.$$.System.Object
                {
                    /*ArrayList*/ _objects = null;
                    /*Hashtable?*/ _objectsTable = null;
                    /*IEqualityComparer?*/ _comparer = null;
                    $ctor$1(/*ArrayList*/ array, /*Hashtable*/ objectsTable, /*IEqualityComparer?*/ comparer)
                    {
                        super.$ctor();
                        {
                            this._objects = array;
                            this._objectsTable = objectsTable;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    $ctor$2(/*ArrayList*/ array)
                    {
                        super.$ctor();
                        {
                            this._objects = array;
                        }
                        return this;
                    }
                    /*bool */ get IsKeys()
                    {
                        return !(this._objectsTable === null);
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        var $en4 = this._objects.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var o = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(o !== null, "o != null");
                                array.SetValue$2(this.IsKeys ? ($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Key : ($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Value, index);
                                index++;
                            }
                        }
                    }
                    /*int */ get System$Collections$ICollection$Count()
                    {
                        return this._objects.Count;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return this._objects.SyncRoot;
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(this._objects, this.IsKeys ? 1/*OrderedDictionaryEnumerator.Keys*/ : 2/*OrderedDictionaryEnumerator.Values*/);
                    }
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        if (this.IsKeys)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(this._objectsTable === null), "_objectsTable is not null");
                            return value !== null && this._objectsTable.ContainsKey(value);
                        }
                        var $en4 = this._objects.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var o = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(o !== null, "o != null");
                                if ($.$$.System.Object.Equals(($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Value, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        for(/*int*/ let i = 0; i < this._objects.Count; i++)
                        {
                            if (this.IsKeys)
                            {
                                /*object*/ let entryKey = ($.$cast(this._objects.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Key;
                                if (this._comparer !== null)
                                {
                                    if (this._comparer.System$Collections$IEqualityComparer$Equals(entryKey, value))
                                    {
                                        return i;
                                    }
                                }
                                else if ($.$$.System.Object.Equals$1.call(entryKey, value))
                                {
                                    return i;
                                }
                            }
                            else if ($.$$.System.Object.Equals(($.$cast(this._objects.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Value, value))
                            {
                                return i;
                            }
                        }
                        return -1;
                    }
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        /*DictionaryEntry*/ let entry = $.$cast(this._objects.get_Item(index), $.$$.System.Collections.DictionaryEntry);
                        return this.IsKeys ? entry.Key : entry.Value;
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*void */ System$Collections$IList$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    /*string */ GetNotSupportedErrorMessage()
                    {
                        return this.IsKeys ? $.$scs.System.SR.NotSupported_KeyCollectionSet : $.$scs.System.SR.NotSupported_ValueCollectionSet;
                    }
                    static $h = 1179684;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065950756,"f":50331650},"n":"IsKeys","d":1179684,"h":25770983460,"f":2097154},{"p":655361,"g":{"r":0,"d":0,"h":42950852644,"f":50331650},"n":"{31457281}.Count","o":"System$Collections$ICollection$Count","d":1179684,"h":38655885348,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":51540787236,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":1179684,"h":47245819940,"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":60130721828,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":1179684,"h":55835754532,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":81605558308,"f":50331650},"n":"{32047105}.IsFixedSize","o":"System$Collections$IList$IsFixedSize","d":1179684,"h":77310591012,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":90195492900,"f":50331650},"n":"{32047105}.IsReadOnly","o":"System$Collections$IList$IsReadOnly","d":1179684,"h":85900525604,"f":2097154},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":98785427492,"f":50331650},"s":{"r":0,"d":0,"h":103080394788,"f":83886082},"n":"{32047105}.this[]","o":"System$Collections$IList$Item","d":1179684,"h":94490460196,"f":2097154}],"m":[{"r":1310721,"n":"GetNotSupportedErrorMessage","d":1179684,"h":128850198564,"f":16777218}],"l":[{"t":23724033,"n":"_objects","d":1179684,"h":4296146980,"f":4194306},{"t":31064065,"n":"_objectsTable","d":1179684,"h":8591114276,"f":4194306},{"t":31916033,"n":"_comparer","d":1179684,"h":12886081572,"f":4194306}],"c":[{"p":[{"n":"array","p":23724033},{"n":"objectsTable","p":31064065},{"n":"comparer","p":31916033}],"n":".ctor","o":"$ctor$1","d":1179684,"h":17181048868,"f":16777217},{"p":[{"n":"array","p":23724033}],"n":".ctor","o":"$ctor$2","d":1179684,"h":21476016164,"f":16777217}],"i":[32047105,31457281,31719425],"d":1048612,"h":1179684}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection`; }
                }, $cls, ($v) => $cls.$_OrderedDictionaryKeyValueCollection = $v);
            }
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.this[int].get
            System$Collections$Specialized$IOrderedDictionary$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.this[int].set
            System$Collections$Specialized$IOrderedDictionary$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.GetEnumerator()
            System$Collections$Specialized$IOrderedDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.Insert(int, object, object?)
            System$Collections$Specialized$IOrderedDictionary$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.RemoveAt(int)
            System$Collections$Specialized$IOrderedDictionary$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                return this.get_Item$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                return this.set_Item$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.KeyComparerName = "KeyComparer";
                }
                {
                    this.ArrayListName = "ArrayList";
                }
                {
                    this.ReadOnlyName = "ReadOnly";
                }
                {
                    this.InitCapacityName = "InitialCapacity";
                }
            }
            static $h = 1048612;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":77310459940,"f":50331649},"n":"Count","d":1048612,"h":73015492644,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":85900394532,"f":50331650},"n":"{31588353}.IsFixedSize","o":"System$Collections$IDictionary$IsFixedSize","d":1048612,"h":81605427236,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":94490329124,"f":50331649},"n":"IsReadOnly","d":1048612,"h":90195361828,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":103080263716,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":1048612,"h":98785296420,"f":2097154},{"p":31457281,"g":{"r":0,"d":0,"h":111670198308,"f":50331649},"n":"Keys","o":"@$1","d":1048612,"h":107375231012,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":128850067492,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":1048612,"h":124555100196,"f":2097154},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":137440002084,"f":50331649},"s":{"r":0,"d":0,"h":141734969380,"f":83886081},"n":"Item","o":"@$2","d":1048612,"h":133145034788,"f":2097153},{"p":131073,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":150324903972,"f":50331649},"s":{"r":0,"d":0,"h":154619871268,"f":83886081},"n":"Item","o":"@$3","d":1048612,"h":146029936676,"f":2097153},{"p":31457281,"g":{"r":0,"d":0,"h":163209805860,"f":50331649},"n":"Values","d":1048612,"h":158914838564,"f":2097153}],"m":[{"r":23724033,"n":"EnsureObjectsArray","d":1048612,"h":115965165604,"f":16777218},{"r":31064065,"n":"EnsureObjectsTable","d":1048612,"h":120260132900,"f":16777218},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Add","d":1048612,"h":167504773156,"f":16777217},{"r":65537,"n":"Clear","d":1048612,"h":171799740452,"f":16777217},{"r":1048612,"n":"AsReadOnly","d":1048612,"h":176094707748,"f":16777217},{"r":262145,"p":[{"n":"key","p":131073}],"n":"Contains","d":1048612,"h":180389675044,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":1048612,"h":184684642340,"f":16777217},{"r":655361,"p":[{"n":"key","p":131073}],"n":"IndexOfKey","d":1048612,"h":188979609636,"f":16777218},{"r":65537,"p":[{"n":"index","p":655361},{"n":"key","p":131073},{"n":"value","p":131073}],"n":"Insert","d":1048612,"h":193274576932,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":1048612,"h":197569544228,"f":16777217},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":1048612,"h":201864511524,"f":16777217},{"r":31653889,"n":"GetEnumerator","d":1048612,"h":206159478820,"f":16777345},{"r":65537,"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":"GetObjectData","d":1048612,"h":214749413412,"f":16777345,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":65537,"p":[{"n":"sender","p":131073}],"n":"OnDeserialization","d":1048612,"h":223339348004,"f":16777348}],"l":[{"t":23724033,"n":"_objectsArray","d":1048612,"h":4296015908,"f":4194306},{"t":31064065,"n":"_objectsTable","d":1048612,"h":8590983204,"f":4194306},{"t":655361,"n":"_initialCapacity","d":1048612,"h":12885950500,"f":4194306},{"t":31916033,"n":"_comparer","d":1048612,"h":17180917796,"f":4194306},{"t":262145,"n":"_readOnly","d":1048612,"h":21475885092,"f":4194306},{"t":113836033,"n":"_siInfo","d":1048612,"h":25770852388,"f":4194306},{"t":1310721,"n":"KeyComparerName","d":1048612,"h":30065819684,"f":4194338},{"t":1310721,"n":"ArrayListName","d":1048612,"h":34360786980,"f":4194338},{"t":1310721,"n":"ReadOnlyName","d":1048612,"h":38655754276,"f":4194338},{"t":1310721,"n":"InitCapacityName","d":1048612,"h":42950721572,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":1048612,"h":47245688868,"f":16777217},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$4","d":1048612,"h":51540656164,"f":16777217},{"p":[{"n":"comparer","p":31916033}],"n":".ctor","o":"$ctor$2","d":1048612,"h":55835623460,"f":16777217},{"p":[{"n":"capacity","p":655361},{"n":"comparer","p":31916033}],"n":".ctor","o":"$ctor$3","d":1048612,"h":60130590756,"f":16777217},{"p":[{"n":"dictionary","p":1048612}],"n":".ctor","o":"$ctor$6","d":1048612,"h":64425558052,"f":16777218},{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$5","d":1048612,"h":68720525348,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"i":[327716,31588353,31457281,31719425,113246209,112984065],"j":[1114148,1179684],"h":1048612,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scs.System.Collections.Specialized.IOrderedDictionary, $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.OrderedDictionary`; }
        });
        
        $asm.$str("$scs.System.Collections.Specialized.BitVector32", ($self) => class BitVector32 extends $.$$.System.ValueType
        {
            /*uint*/  get _data() { return this.$getField(0, $.$$.System.UInt32); }
            /*uint*/  set _data(value) { this.$setField(0, $.$$.System.UInt32, value); }
            $ctor$3(/*int*/ data)
            {
                super.$ctor$1();
                {
                    this._data = (data >>> 0);
                }
                return this;
            }
            $ctor$4(/*BitVector32*/ value)
            {
                super.$ctor$1();
                {
                    this._data = value._data;
                }
                return this;
            }
            /*bool*/ get_Item(/*int*/ bit)
            {
                return (BigInt(this._data) & BigInt(bit)) === BigInt((bit >>> 0));
            }
            /*void*/ set_Item(/*int*/ bit, /*bool*/ value)
            {
                //unchecked
                {
                    if (value)
                    {
                        this._data |= (bit >>> 0);
                    }
                    else 
                    {
                        this._data &= ~(bit >>> 0);
                    }
                }
            }
            /*int*/ get_Item$1(/*Section*/ section)
            {
                //unchecked
                {
                    return (((this._data & ((section.Mask << section.Offset) >>> 0)) >>> section.Offset) | 0);
                }
            }
            /*void*/ set_Item$1(/*Section*/ section, /*int*/ value)
            {
                value <<= section.Offset;
                /*int*/ let offsetMask = (65535 & section.Mask) << section.Offset;
                this._data = (this._data & ~(offsetMask >>> 0)) | ((value >>> 0) & (offsetMask >>> 0));
            }
            /*int */ get Data()
            {
                return (this._data | 0);
            }
            static /*int */ CreateMask()
            {
                return $.$scs.System.Collections.Specialized.BitVector32.CreateMask$1(0);
            }
            static /*int */ CreateMask$1(/*int*/ previous)
            {
                if (previous === 0)
                {
                    return 1;
                }
                if (previous === (2147483648 | 0))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.BitVectorFull);
                }
                return previous << 1;
            }
            static /*Section */ CreateSection$1(/*short*/ maxValue)
            {
                return $.$scs.System.Collections.Specialized.BitVector32.CreateSectionHelper(maxValue, 0, 0);
            }
            static /*Section */ CreateSection(/*short*/ maxValue, /*Section*/ previous)
            {
                return $.$scs.System.Collections.Specialized.BitVector32.CreateSectionHelper(maxValue, previous.Mask, previous.Offset);
            }
            static /*Section */ CreateSectionHelper(/*short*/ maxValue, /*short*/ priorMask, /*short*/ priorOffset)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int16, maxValue, "maxValue");
                /*short*/ let offset = $.$cast((((priorOffset + $.$$.System.Numerics.BitOperations.PopCount($.$cast(priorMask, $.$$.System.UInt16))) | 0)), $.$$.System.Int16);
                if (offset >= 32)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.BitVectorFull);
                }
                /*short*/ let mask = $.$cast(((($.$$.System.Numerics.BitOperations.RoundUpToPowerOf2((($.$cast(maxValue, $.$$.System.UInt16) + 1) >>> 0)) - 1) >>> 0)), $.$$.System.Int16);
                return new $.$scs.System.Collections.Specialized.BitVector32.Section().$ctor$3(mask, offset);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
            {
                let other;
                return $.$is(o, $.$scs.System.Collections.Specialized.BitVector32, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scs.System.Collections.Specialized.BitVector32.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*BitVector32*/ other)
            {
                return this._data === other._data;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.UInt32.GetHashCode.call(this._data);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scs.System.Collections.Specialized.BitVector32.GetHashCode.apply(this, arguments); }
            static /*string */ ToString$1(/*BitVector32*/ value)
            {
                return $.$$.System.String.Create$10($.$scs.System.Collections.Specialized.BitVector32, ((((12 + 32) | 0) + 1) | 0), value.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$scs.System.Collections.Specialized.BitVector32))().$ctor(this,  (/**/ dst, /**/ v) =>
                {
                    /*ReadOnlySpan<char>*/ let prefix = $.$$.System.String.op_Implicit("BitVector32{");
                    prefix.CopyTo(dst);
                    dst.get_Item(((dst.Length - 1) | 0)).$v = /*}*/ 125;
                    /*int*/ let locdata = (v._data | 0);
                    dst = dst.Slice(prefix.Length, 32);
                    for(/*int*/ let i = 0; i < dst.Length; i++)
                    {
                        dst.get_Item(i).$v = (BigInt(locdata) & 2147483648n) !== 0n ? /*1*/ 49 : /*0*/ 48;
                        locdata <<= 1;
                    }
                }, {"r":65537,"p":[{"n":"dst","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"v","p":131108}],"n":"","d":131108,"h":0,"f":17825794}));
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$scs.System.Collections.Specialized.BitVector32.ToString$1(this);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scs.System.Collections.Specialized.BitVector32.ToString.apply(this, arguments); }
            static $_Section;
            static get Section()
            {
                let $cls = $.$scs.System.Collections.Specialized.BitVector32;
                return $cls.$_Section ??= $asm.$nstr("$scs.System.Collections.Specialized.BitVector32.Section", ($self) => class Section extends $.$$.System.ValueType
                {
                    /*short*/  get _mask() { return this.$getField(0, $.$$.System.Int16); }
                    /*short*/  set _mask(value) { this.$setField(0, $.$$.System.Int16, value); }
                    /*short*/  get _offset() { return this.$getField(2, $.$$.System.Int16); }
                    /*short*/  set _offset(value) { this.$setField(2, $.$$.System.Int16, value); }
                    $ctor$3(/*short*/ mask, /*short*/ offset)
                    {
                        super.$ctor$1();
                        {
                            this._mask = mask;
                            this._offset = offset;
                        }
                        return this;
                    }
                    /*short */ get Mask()
                    {
                        return this._mask;
                    }
                    /*short */ get Offset()
                    {
                        return this._offset;
                    }
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
                    {
                        let other;
                        return $.$is(o, $.$scs.System.Collections.Specialized.BitVector32.Section, { set $v(v){ other = v; } }) && this.Equals$2(other);
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$scs.System.Collections.Specialized.BitVector32.Section.Equals$1.apply(this, arguments); }
                    /*bool */ Equals$2(/*Section*/ obj)
                    {
                        return obj._mask === this._mask && obj._offset === this._offset;
                    }
                    static /*bool */ op_Equality(/*Section*/ a, /*Section*/ b)
                    {
                        return a.Equals$2(b);
                    }
                    static /*bool */ op_Inequality(/*Section*/ a, /*Section*/ b)
                    {
                        return !($.$scs.System.Collections.Specialized.BitVector32.Section.op_Equality(a, b));
                    }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$$.System.HashCode.Combine$6($.$$.System.Int16, $.$$.System.Int16, this._mask, this._offset);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$scs.System.Collections.Specialized.BitVector32.Section.GetHashCode.apply(this, arguments); }
                    static /*string */ ToString$1(/*Section*/ value)
                    {
                        return (() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(3, 2);
                            $handler.AppendLiteral("Section{{0x");
                            $handler.AppendFormatted($.$box(value.Mask, $.$$.System.Int16), null, "x");
                            $handler.AppendLiteral(", 0x");
                            $handler.AppendFormatted($.$box(value.Offset, $.$$.System.Int16), null, "x");
                            $handler.AppendLiteral("}}");
                            return $handler.ToStringAndClear                    ();
                        })();
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return $.$scs.System.Collections.Specialized.BitVector32.Section.ToString$1(this);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$scs.System.Collections.Specialized.BitVector32.Section.ToString.apply(this, arguments); }
                    //Generated interface implemetation for System.IEquatable<System.Collections.Specialized.BitVector32.Section>.Equals(System.Collections.Specialized.BitVector32.Section)
                    System$IEquatable$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._mask = this._mask;
                        copy._offset = this._offset;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._mask = 0;
                        this._offset = 0;
                    }
                    static $h = 196644;
                    static $z = 4;
                    static $f = 0b10000010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":524289,"g":{"r":0,"d":0,"h":21475033124,"f":50331649},"n":"Mask","d":196644,"h":17180065828,"f":2097153},{"p":524289,"g":{"r":0,"d":0,"h":30064967716,"f":50331649},"n":"Offset","d":196644,"h":25770000420,"f":2097153}],"m":[{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":196644,"h":34359935012,"f":16809985},{"r":262145,"p":[{"n":"obj","p":196644}],"n":"Equals","o":"@$2","d":196644,"h":38654902308,"f":16777217},{"r":655361,"n":"GetHashCode","d":196644,"h":51539804196,"f":16809985},{"r":1310721,"p":[{"n":"value","p":196644}],"n":"ToString","o":"@$1","d":196644,"h":55834771492,"f":16777249},{"r":1310721,"n":"ToString","d":196644,"h":60129738788,"f":16809985}],"l":[{"t":524289,"n":"_mask","d":196644,"h":4295163940,"f":4194306},{"t":524289,"n":"_offset","d":196644,"h":8590131236,"f":4194306}],"c":[{"p":[{"n":"mask","p":524289},{"n":"offset","p":524289}],"n":".ctor","o":"$ctor$3","d":196644,"h":12885098532,"f":16777224},{"n":".ctor","o":"$ctor$2","d":196644,"h":64424706084,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32.Section).$h],"d":131108,"h":196644}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32.Section) ]; }
                    static get $fullName() { return `System.Collections.Specialized.BitVector32.Section`; }
                }, $cls, ($v) => $cls.$_Section = $v);
            }
            //Generated interface implemetation for System.IEquatable<System.Collections.Specialized.BitVector32>.Equals(System.Collections.Specialized.BitVector32)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._data = this._data;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._data = 0;
            }
            static $h = 131108;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"i":[{"n":"bit","p":655361}],"g":{"r":0,"d":0,"h":21474967588,"f":50331649},"s":{"r":0,"d":0,"h":25769934884,"f":83886081},"n":"Item","o":"@$2","d":131108,"h":17180000292,"f":2097153},{"p":655361,"i":[{"n":"section","p":196644}],"g":{"r":0,"d":0,"h":34359869476,"f":50331649},"s":{"r":0,"d":0,"h":38654836772,"f":83886081},"n":"Item","o":"@$3","d":131108,"h":30064902180,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47244771364,"f":50331649},"n":"Data","d":131108,"h":42949804068,"f":2097153}],"m":[{"r":655361,"n":"CreateMask","d":131108,"h":51539738660,"f":16777249},{"r":655361,"p":[{"n":"previous","p":655361}],"n":"CreateMask","o":"@$1","d":131108,"h":55834705956,"f":16777249},{"r":196644,"p":[{"n":"maxValue","p":524289}],"n":"CreateSection","o":"@$1","d":131108,"h":60129673252,"f":16777249},{"r":196644,"p":[{"n":"maxValue","p":524289},{"n":"previous","p":196644}],"n":"CreateSection","d":131108,"h":64424640548,"f":16777249},{"r":196644,"p":[{"n":"maxValue","p":524289},{"n":"priorMask","p":524289},{"n":"priorOffset","p":524289}],"n":"CreateSectionHelper","d":131108,"h":68719607844,"f":16777250},{"r":262145,"p":[{"n":"o","p":131073}],"n":"Equals","o":"@$1","d":131108,"h":73014575140,"f":16809985},{"r":262145,"p":[{"n":"other","p":131108}],"n":"Equals","o":"@$2","d":131108,"h":77309542436,"f":16777217},{"r":655361,"n":"GetHashCode","d":131108,"h":81604509732,"f":16809985},{"r":1310721,"p":[{"n":"value","p":131108}],"n":"ToString","o":"@$1","d":131108,"h":85899477028,"f":16777249},{"r":1310721,"n":"ToString","d":131108,"h":90194444324,"f":16809985}],"l":[{"t":720897,"n":"_data","d":131108,"h":4295098404,"f":4194306}],"c":[{"p":[{"n":"data","p":655361}],"n":".ctor","o":"$ctor$3","d":131108,"h":8590065700,"f":16777217},{"p":[{"n":"value","p":131108}],"n":".ctor","o":"$ctor$4","d":131108,"h":12885032996,"f":16777217},{"n":".ctor","o":"$ctor$2","d":131108,"h":98784378916,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32).$h],"j":[196644],"h":131108}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32) ]; }
            static get $fullName() { return `System.Collections.Specialized.BitVector32`; }
        });
        
        $asm.$cls("$scs.System.Collections.Specialized.NameValueCollection", ($self) => class NameValueCollection extends $.$scs.System.Collections.Specialized.NameObjectCollectionBase
        {
            /*string?[]?*/ _all = null;
            /*string?[]?*/ _allKeys = null;
            $ctor$8()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$16(/*NameValueCollection*/ col)
            {
                super.$ctor$2((col?.Comparer ?? null));
                {
                    this.Add$1(col);
                }
                return this;
            }
            $ctor$10(/*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor$3(hashProvider, comparer);
                {
                }
                return this;
            }
            $ctor$14(/*int*/ capacity)
            {
                super.$ctor$6(capacity);
                {
                }
                return this;
            }
            $ctor$9(/*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor$2(equalityComparer);
                {
                }
                return this;
            }
            $ctor$11(/*int*/ capacity, /*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor$4(capacity, equalityComparer);
                {
                }
                return this;
            }
            $ctor$13(/*int*/ capacity, /*NameValueCollection*/ col)
            {
                super.$ctor$4(capacity, col !== null ? col.Comparer : (() =>
                {
        throw new $.$$.System.ArgumentNullException().$ctor$19("col")        })());
                {
                    this.Comparer = col.Comparer;
                    this.Add$1(col);
                }
                return this;
            }
            $ctor$12(/*int*/ capacity, /*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor$5(capacity, hashProvider, comparer);
                {
                }
                return this;
            }
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$7(info, context);
                {
                }
                return this;
            }
            /*void */ InvalidateCachedArrays()
            {
                this._all = null;
                this._allKeys = null;
            }
            static /*string? */ GetAsOneString(/*ArrayList?*/ list)
            {
                /*int*/ let n = (list !== null) ? list.Count : 0;
                if (n === 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                    return $.$cast(list.get_Item(0), $.$$.System.String);
                }
                else if (n > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                    /*StringBuilder*/ let s = new $.$$.System.Text.StringBuilder().$ctor$8($.$cast(list.get_Item(0), $.$$.System.String));
                    for(/*int*/ let i = 1; i < n; i++)
                    {
                        s.Append$3(/*,*/ 44);
                        s.Append$19($.$cast(list.get_Item(i), $.$$.System.String));
                    }
                    return $.$$.System.Text.StringBuilder.ToString.call(s);
                }
                else 
                {
                    return null;
                }
            }
            static /*string[]? */ GetAsStringArray(/*ArrayList?*/ list)
            {
                /*int*/ let n = (list !== null) ? list.Count : 0;
                if (n === 0)
                {
                    return null;
                }
                /*string[]*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                list.CopyTo$2(0, array, 0, n);
                return array;
            }
            /*void */ Add$1(/*NameValueCollection*/ c)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(c, "c");
                this.InvalidateCachedArrays();
                /*int*/ let n = c.Count;
                for(/*int*/ let i = 0; i < n; i++)
                {
                    /*string?*/ let key = c.GetKey(i);
                    /*string[]?*/ let values = c.GetValues(i);
                    if (values !== null)
                    {
                        for(/*int*/ let j = 0; j < values.length; j++)
                        {
                            this.Add(key, $.$$.System.Array.$ReadT1.call(values, j));
                        }
                    }
                    else 
                    {
                        this.Add(key, null);
                    }
                }
            }
            /*void */ Clear()
            {
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                this.BaseClear();
            }
            /*void */ CopyTo(/*Array*/ dest, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(dest, "dest");
                if ($.$$.System.Array.Rank$get.call(dest) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "dest");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((dest.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                /*int*/ let n = this.Count;
                if (this._all === null)
                {
                    /*string?[]*/ let all = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                    for(/*int*/ let i = 0; i < n; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(all, this.Get(i), i);
                        dest.SetValue$2($.$$.System.Array.$ReadT1.call(all, i), ((i + index) | 0));
                    }
                    this._all = all;
                }
                else 
                {
                    for(/*int*/ let i = 0; i < n; i++)
                    {
                        dest.SetValue$2($.$$.System.Array.$ReadT1.call(this._all, i), ((i + index) | 0));
                    }
                }
            }
            /*bool */ HasKeys()
            {
                return this.InternalHasKeys();
            }
            /*bool */ InternalHasKeys()
            {
                return this.BaseHasKeys();
            }
            /*void */ Add(/*string?*/ name, /*string?*/ value)
            {
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                if (values === null)
                {
                    values = new $.$$.System.Collections.ArrayList().$ctor$3(1);
                    if ($.$$.System.String.op_Inequality(value, null))
                    {
                        values.Add(value);
                    }
                    this.BaseAdd(name, values);
                }
                else 
                {
                    if ($.$$.System.String.op_Inequality(value, null))
                    {
                        values.Add(value);
                    }
                }
            }
            /*string? */ Get$1(/*string?*/ name)
            {
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsOneString(values);
            }
            /*string[]? */ GetValues$1(/*string?*/ name)
            {
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsStringArray(values);
            }
            /*void */ Set(/*string?*/ name, /*string?*/ value)
            {
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                /*ArrayList*/ let values = new $.$$.System.Collections.ArrayList().$ctor$3(1);
                values.Add(value);
                this.BaseSet$1(name, values);
            }
            /*void */ Remove(/*string?*/ name)
            {
                this.InvalidateCachedArrays();
                this.BaseRemove(name);
            }
            /*string?*/ get_Item$1(/*string?*/ name)
            {
                return this.Get$1(name);
            }
            /*void*/ set_Item(/*string?*/ name, /*string?*/ value)
            {
                this.Set(name, value);
            }
            /*string? */ Get(/*int*/ index)
            {
                /*ArrayList?*/ let values = $.$cast(this.BaseGet(index), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsOneString(values);
            }
            /*string[]? */ GetValues(/*int*/ index)
            {
                /*ArrayList?*/ let values = $.$cast(this.BaseGet(index), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsStringArray(values);
            }
            /*string? */ GetKey(/*int*/ index)
            {
                return this.BaseGetKey(index);
            }
            /*string?*/ get_Item(/*int*/ index)
            {
                return this.Get(index);
            }
            /*string?[] */ get AllKeys()
            {
                return this._allKeys ??= this.BaseGetAllKeys();
            }
            static $h = 983076;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":720932,"p":[{"p":1310721,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":111670132772,"f":50331649},"s":{"r":0,"d":0,"h":115965100068,"f":83886081},"n":"Item","o":"@$3","d":983076,"h":107375165476,"f":2097153},{"p":1310721,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":137439936548,"f":50331649},"n":"Item","o":"@$2","d":983076,"h":133144969252,"f":2097153},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":146029871140,"f":50331777},"n":"AllKeys","d":983076,"h":141734903844,"f":2097281}],"m":[{"r":65537,"n":"InvalidateCachedArrays","d":983076,"h":51540590628,"f":16777220},{"r":1310721,"p":[{"n":"list","p":23724033}],"n":"GetAsOneString","d":983076,"h":55835557924,"f":16777250},{"r":$.$typeArray($.$$.System.String).$h,"p":[{"n":"list","p":23724033}],"n":"GetAsStringArray","d":983076,"h":60130525220,"f":16777250},{"r":65537,"p":[{"n":"c","p":983076}],"n":"Add","o":"@$1","d":983076,"h":64425492516,"f":16777217},{"r":65537,"n":"Clear","d":983076,"h":68720459812,"f":16777345},{"r":65537,"p":[{"n":"dest","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":983076,"h":73015427108,"f":16777217},{"r":262145,"n":"HasKeys","d":983076,"h":77310394404,"f":16777217},{"r":262145,"n":"InternalHasKeys","d":983076,"h":81605361700,"f":16777352},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"Add","d":983076,"h":85900328996,"f":16777345},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"Get","o":"@$1","d":983076,"h":90195296292,"f":16777345},{"r":$.$typeArray($.$$.System.String).$h,"p":[{"n":"name","p":1310721}],"n":"GetValues","o":"@$1","d":983076,"h":94490263588,"f":16777345},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":"Set","d":983076,"h":98785230884,"f":16777345},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Remove","d":983076,"h":103080198180,"f":16777345},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"Get","d":983076,"h":120260067364,"f":16777345},{"r":$.$typeArray($.$$.System.String).$h,"p":[{"n":"index","p":655361}],"n":"GetValues","d":983076,"h":124555034660,"f":16777345},{"r":1310721,"p":[{"n":"index","p":655361}],"n":"GetKey","d":983076,"h":128850001956,"f":16777345}],"l":[{"t":$.$typeArray($.$$.System.String).$h,"n":"_all","d":983076,"h":4295950372,"f":4194306},{"t":$.$typeArray($.$$.System.String).$h,"n":"_allKeys","d":983076,"h":8590917668,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$8","d":983076,"h":12885884964,"f":16777217},{"p":[{"n":"col","p":983076}],"n":".ctor","o":"$ctor$16","d":983076,"h":17180852260,"f":16777217},{"p":[{"n":"hashProvider","p":31981569},{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$10","d":983076,"h":21475819556,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use NameValueCollection(IEqualityComparer) instead.","t":1310721}]}]},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$14","d":983076,"h":25770786852,"f":16777217},{"p":[{"n":"equalityComparer","p":31916033}],"n":".ctor","o":"$ctor$9","d":983076,"h":30065754148,"f":16777217},{"p":[{"n":"capacity","p":655361},{"n":"equalityComparer","p":31916033}],"n":".ctor","o":"$ctor$11","d":983076,"h":34360721444,"f":16777217},{"p":[{"n":"capacity","p":655361},{"n":"col","p":983076}],"n":".ctor","o":"$ctor$13","d":983076,"h":38655688740,"f":16777217},{"p":[{"n":"capacity","p":655361},{"n":"hashProvider","p":31981569},{"n":"comparer","p":31522817}],"n":".ctor","o":"$ctor$12","d":983076,"h":42950656036,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use NameValueCollection(Int32, IEqualityComparer) instead.","t":1310721}]}]},{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$15","d":983076,"h":47245623332,"f":16777220,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"i":[31457281,31719425,113246209,112984065],"h":983076}; }
            static get $b() { return $.$scs.System.Collections.Specialized.NameObjectCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.NameValueCollection`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives"))