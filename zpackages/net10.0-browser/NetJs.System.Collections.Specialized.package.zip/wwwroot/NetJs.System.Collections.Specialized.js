
//--TRIMMABLE-BOUNDARY-START(17)
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections.Specialized", 
    {
  "h": 17,
  "f": "System.Collections.Specialized",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Collections.Specialized",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Collections.Specialized",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327697)
        $asm.$cls("$scs.System.Collections.Specialized.IOrderedDictionary", ($self) => class IOrderedDictionary
        {
            //--TRIMMABLE-BOUNDARY-START(34360066065)
            //--TRIMMABLE-BOUNDARY-END(34360066065)
            
            static $h = 327697;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360066065),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590262289,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065098769,
        "f": 83886337
      },
      "n": "Item",
      "o": "System$Collections$Specialized$IOrderedDictionary$Item",
      "d": 327697,
      "h": 34360066065,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360066065)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229585),
    {
      "r": 62455809,
      "n": "GetEnumerator",
      "o": "System$Collections$Specialized$IOrderedDictionary$GetEnumerator",
      "d": 327697,
      "h": 12885229585,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885229585),
//--TRIMMABLE-BOUNDARY-START(17180196881),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "o": "System$Collections$Specialized$IOrderedDictionary$Insert",
      "d": 327697,
      "h": 17180196881,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180196881),
//--TRIMMABLE-BOUNDARY-START(21475164177),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "o": "System$Collections$Specialized$IOrderedDictionary$RemoveAt",
      "d": 327697,
      "h": 21475164177,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475164177)
  ],
  "i": [62390273,62259201,62521345
  ],
  "h": 327697
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.IOrderedDictionary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327697)
        
        
        //--TRIMMABLE-BOUNDARY-START(720913)
        $asm.$cls("$scs.System.Collections.Specialized.NameObjectCollectionBase", ($self) => class NameObjectCollectionBase extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25770524689)
            /*bool*/ _readOnly = false;
            //--TRIMMABLE-BOUNDARY-END(25770524689)
            
            //--TRIMMABLE-BOUNDARY-START(4295688209)
            /*ArrayList*/ _entriesArray = null;
            //--TRIMMABLE-BOUNDARY-END(4295688209)
            
            //--TRIMMABLE-BOUNDARY-START(12885622801)
            /*IEqualityComparer*/ _keyComparer = null;
            //--TRIMMABLE-BOUNDARY-END(12885622801)
            
            //--TRIMMABLE-BOUNDARY-START(8590655505)
            /*Hashtable*/ _entriesTable = null;
            //--TRIMMABLE-BOUNDARY-END(8590655505)
            
            //--TRIMMABLE-BOUNDARY-START(21475557393)
            /*NameObjectEntry?*/ _nullKeyEntry = null;
            //--TRIMMABLE-BOUNDARY-END(21475557393)
            
            //--TRIMMABLE-BOUNDARY-START(17180590097)
            /*KeysCollection?*/ _keys = null;
            //--TRIMMABLE-BOUNDARY-END(17180590097)
            
            //--TRIMMABLE-BOUNDARY-START(30065491985)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(30065491985)
            
            //--TRIMMABLE-BOUNDARY-START(214749085713)
            /*StringComparer*/ static s_defaultComparer = null;
            //--TRIMMABLE-BOUNDARY-END(214749085713)
            
            //--TRIMMABLE-BOUNDARY-START(38655426577)
            $ctor$1()
            {
                this.$ctor$2($.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426577)
            
            //--TRIMMABLE-BOUNDARY-START(42950393873)
            $ctor$2(/*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._keyComparer = equalityComparer ?? $.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer;
                    this.Reset();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950393873)
            
            //--TRIMMABLE-BOUNDARY-START(47245361169)
            $ctor$4(/*int*/ capacity, /*IEqualityComparer?*/ equalityComparer)
            {
                this.$ctor$2(equalityComparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245361169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Reset$1(capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245361169)
            
            //--TRIMMABLE-BOUNDARY-START(51540328465)
            $ctor$3(/*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540328465);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._keyComparer = new $.$scs.System.Collections.CompatibleComparer().$ctor$1(hashProvider, comparer);
                    this.Reset();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540328465)
            
            //--TRIMMABLE-BOUNDARY-START(55835295761)
            $ctor$5(/*int*/ capacity, /*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835295761);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._keyComparer = new $.$scs.System.Collections.CompatibleComparer().$ctor$1(hashProvider, comparer);
                    this.Reset$1(capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295761)
            
            //--TRIMMABLE-BOUNDARY-START(60130263057)
            $ctor$6(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263057);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._keyComparer = $.$scs.System.Collections.Specialized.NameObjectCollectionBase.s_defaultComparer;
                    this.Reset$1(capacity);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130263057)
            
            //--TRIMMABLE-BOUNDARY-START(64425230353)
            $ctor$7(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425230353)
            
            //--TRIMMABLE-BOUNDARY-START(176094380049)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176094380049)
            
            //--TRIMMABLE-BOUNDARY-START(201864183825)
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864183825)
            
            //--TRIMMABLE-BOUNDARY-START(206159151121)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159151121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._entriesArray = new $.$$.System.Collections.ArrayList().$ctor$1();
                this._entriesTable = new $.$$.System.Collections.Hashtable().$ctor$9(this._keyComparer);
                this._nullKeyEntry = null;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(206159151121)
            
            //--TRIMMABLE-BOUNDARY-START(210454118417)
            /*void */ Reset$1(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454118417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._entriesArray = new $.$$.System.Collections.ArrayList().$ctor$3(capacity);
                this._entriesTable = new $.$$.System.Collections.Hashtable().$ctor$11(capacity, this._keyComparer);
                this._nullKeyEntry = null;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(210454118417)
            
            //--TRIMMABLE-BOUNDARY-START(133144707089)
            /*NameObjectEntry? */ FindEntry(/*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(key, null))
                {
                    return $.$cast(this._entriesTable.get_Item(key), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                }
                else 
                {
                    return this._nullKeyEntry;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144707089)
            
            //--TRIMMABLE-BOUNDARY-START(124554772497)
            /*IEqualityComparer */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keyComparer;
            }
            /*IEqualityComparer */ set Comparer(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339020305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._keyComparer = value;
            }
            //--TRIMMABLE-BOUNDARY-END(124554772497)
            
            //--TRIMMABLE-BOUNDARY-START(180389347345)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._readOnly;
            }
            /*bool */ set IsReadOnly(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928954897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._readOnly = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180389347345)
            
            //--TRIMMABLE-BOUNDARY-START(103079936017)
            /*bool */ BaseHasKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._entriesTable.Count > 0);
            }
            //--TRIMMABLE-BOUNDARY-END(103079936017)
            
            //--TRIMMABLE-BOUNDARY-START(68720197649)
            /*void */ BaseAdd(/*string?*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry*/ let entry = new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry().$ctor$1(name, value);
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    if (this._entriesTable.get_Item(name) === null)
                    {
                        this._entriesTable.Add(name, entry);
                    }
                }
                else 
                {
                    this._nullKeyEntry ??= entry;
                }
                this._entriesArray.Add(entry);
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197649)
            
            //--TRIMMABLE-BOUNDARY-START(107374903313)
            /*void */ BaseRemove(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    this._entriesTable.Remove(name);
                    for(/*int*/ let i = ((this._entriesArray.Count - 1) | 0); i >= 0; i--)
                    {
                        if (this._keyComparer.System$Collections$IEqualityComparer$Equals(name, this.BaseGetKey(i)))
                        {
                            this._entriesArray.RemoveAt(i);
                        }
                    }
                }
                else 
                {
                    this._nullKeyEntry = null;
                    for(/*int*/ let i = ((this._entriesArray.Count - 1) | 0); i >= 0; i--)
                    {
                        if ($.$$.System.String.op_Equality(this.BaseGetKey(i), null))
                        {
                            this._entriesArray.RemoveAt(i);
                        }
                    }
                }
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(107374903313)
            
            //--TRIMMABLE-BOUNDARY-START(111669870609)
            /*void */ BaseRemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*string?*/ let key = this.BaseGetKey(index);
                if ($.$$.System.String.op_Inequality(key, null))
                {
                    this._entriesTable.Remove(key);
                }
                else 
                {
                    this._nullKeyEntry = null;
                }
                this._entriesArray.RemoveAt(index);
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(111669870609)
            
            //--TRIMMABLE-BOUNDARY-START(73015164945)
            /*void */ BaseClear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.Reset();
            }
            //--TRIMMABLE-BOUNDARY-END(73015164945)
            
            //--TRIMMABLE-BOUNDARY-START(77310132241)
            /*object? */ BaseGet$1(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310132241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NameObjectEntry?*/ let e = this.FindEntry(name);
                return e?.Value ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132241)
            
            //--TRIMMABLE-BOUNDARY-START(115964837905)
            /*void */ BaseSet$1(/*string?*/ name, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry?*/ let entry = this.FindEntry(name);
                if (entry !== null)
                {
                    entry.Value = value;
                    this._version++;
                }
                else 
                {
                    this.BaseAdd(name, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964837905)
            
            //--TRIMMABLE-BOUNDARY-START(81605099537)
            /*object? */ BaseGet(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                return entry.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(81605099537)
            
            //--TRIMMABLE-BOUNDARY-START(98784968721)
            /*string? */ BaseGetKey(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                return entry.Key;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968721)
            
            //--TRIMMABLE-BOUNDARY-START(120259805201)
            /*void */ BaseSet(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259805201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                /*NameObjectEntry*/ let entry = $.$cast(this._entriesArray.get_Item(index), $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry);
                entry.Value = value;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(120259805201)
            
            //--TRIMMABLE-BOUNDARY-START(171799412753)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799412753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(171799412753)
            
            //--TRIMMABLE-BOUNDARY-START(128849739793)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._entriesArray.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(128849739793)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 236223922193, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223922193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._entriesArray.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                for(/*IEnumerator*/ let e = this.GetEnumerator(); e.System$Collections$IEnumerator$MoveNext(); )
                {
                    array.SetValue$2(e.System$Collections$IEnumerator$Current, index++);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 236223922193, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 261993725969, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 261993725969, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 257698758673, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813856785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 257698758673, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(85900066833)
            /*string?[] */ BaseGetAllKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let n = this._entriesArray.Count;
                /*string?[]*/ let allKeys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allKeys, this.BaseGetKey(i), i);
                }
                return allKeys;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066833)
            
            //--TRIMMABLE-BOUNDARY-START(90195034129)
            /*object?[] */ BaseGetAllValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let n = this._entriesArray.Count;
                /*object?[]*/ let allValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [n], null);
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allValues, this.BaseGet(i), i);
                }
                return allValues;
            }
            //--TRIMMABLE-BOUNDARY-END(90195034129)
            
            //--TRIMMABLE-BOUNDARY-START(94490001425)
            /*object?[] */ BaseGetAllValues$1(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                /*int*/ let n = this._entriesArray.Count;
                /*object?[]*/ let allValues = $.$cast($.$$.System.Array.CreateInstance$2(type, n), $.$typeArray($.$$.System.Object));
                for(/*int*/ let i = 0; i < n; i++)
                {
                    $.$$.System.Array.$WriteT1.call(allValues, this.BaseGet(i), i);
                }
                return allValues;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001425)
            
            //--TRIMMABLE-BOUNDARY-START(184684314641)
            /*KeysCollection */ get Keys$1()
            {
                return this._keys ??= new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.KeysCollection().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(184684314641)
            
            //--TRIMMABLE-BOUNDARY-START(851985)
            static $_NameObjectEntry;
            static get NameObjectEntry()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_NameObjectEntry ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry", ($self) => class NameObjectEntry extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819281)
                    $ctor$1(/*string?*/ name, /*object?*/ value)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4295819281);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Key = name;
                            this.Value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295819281)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590786577)
                    /*string?*/ Key = null;
                    //--TRIMMABLE-BOUNDARY-END(8590786577)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885753873)
                    /*object?*/ Value = null;
                    //--TRIMMABLE-BOUNDARY-END(12885753873)
                    
                    static $h = 851985;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786577),
    {
      "t": 1310721,
      "n": "Key",
      "d": 851985,
      "h": 8590786577,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590786577),
//--TRIMMABLE-BOUNDARY-START(12885753873),
    {
      "t": 131073,
      "n": "Value",
      "d": 851985,
      "h": 12885753873,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885753873)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819281),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 851985,
      "h": 4295819281,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295819281)
  ],
  "d": 720913,
  "h": 851985
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.NameObjectEntry`; }
                }, $cls, ($v) => $cls.$_NameObjectEntry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(851985)
            
            //--TRIMMABLE-BOUNDARY-START(917521)
            static $_NameObjectKeysEnumerator;
            static get NameObjectKeysEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_NameObjectKeysEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator", ($self) => class NameObjectKeysEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590852113)
                    /*int*/ _pos = 0;
                    //--TRIMMABLE-BOUNDARY-END(8590852113)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884817)
                    /*NameObjectCollectionBase*/ _coll = null;
                    //--TRIMMABLE-BOUNDARY-END(4295884817)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819409)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(12885819409)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180786705)
                    $ctor$1(/*NameObjectCollectionBase*/ coll)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180786705);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._coll = coll;
                            this._version = this._coll._version;
                            this._pos = -1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180786705)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360655889)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360655889);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._coll._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._pos < ((this._coll.Count - 1) | 0))
                        {
                            this._pos++;
                            return true;
                        }
                        else 
                        {
                            this._pos = this._coll.Count;
                            return false;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360655889)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655623185)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655623185);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._coll._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._pos = -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655623185)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475754001)
                    /*object? */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065688593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._pos >= 0 && this._pos < this._coll.Count)
                        {
                            return this._coll.BaseGetKey(this._pos);
                        }
                        else 
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475754001)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947554305)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947554305)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 917521;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475754001),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065688593,
        "f": 50331649
      },
      "n": "Current",
      "d": 917521,
      "h": 21475754001,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475754001)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360655889),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 917521,
      "h": 34360655889,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655889),
//--TRIMMABLE-BOUNDARY-START(38655623185),
    {
      "r": 65537,
      "n": "Reset",
      "d": 917521,
      "h": 38655623185,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655623185)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852113),
    {
      "t": 655361,
      "n": "_pos",
      "d": 917521,
      "h": 8590852113,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852113),
//--TRIMMABLE-BOUNDARY-START(4295884817),
    {
      "t": 720913,
      "n": "_coll",
      "d": 917521,
      "h": 4295884817,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884817),
//--TRIMMABLE-BOUNDARY-START(12885819409),
    {
      "t": 655361,
      "n": "_version",
      "d": 917521,
      "h": 12885819409,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819409)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786705),
    {
      "p": [
        {
          "n": "coll",
          "p": 720913
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917521,
      "h": 17180786705,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180786705)
  ],
  "i": [62652417
  ],
  "d": 720913,
  "h": 917521
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator`; }
                }, $cls, ($v) => $cls.$_NameObjectKeysEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917521)
            
            //--TRIMMABLE-BOUNDARY-START(786449)
            static $_KeysCollection;
            static get KeysCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.NameObjectCollectionBase;
                return $cls.$_KeysCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.NameObjectCollectionBase.KeysCollection", ($self) => class KeysCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295753745)
                    /*NameObjectCollectionBase*/ _coll = null;
                    //--TRIMMABLE-BOUNDARY-END(4295753745)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721041)
                    $ctor$1(/*NameObjectCollectionBase*/ coll)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590721041);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._coll = coll;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721041)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180655633)
                    /*string? */ Get(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180655633);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._coll.BaseGetKey(index);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180655633)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015230481)
                    /*string?*/ get_Item(/*int*/ index)
                    {
                        return this.Get(index);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015230481)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655492113)
                    /*IEnumerator */ GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655492113);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scs.System.Collections.Specialized.NameObjectCollectionBase.NameObjectKeysEnumerator().$ctor$1(this._coll);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655492113)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885688337)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770590225);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._coll.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885688337)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 42950459409, 4357226497)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950459409);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._coll.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                        }
                        for(/*IEnumerator*/ let e = this.GetEnumerator(); e.System$Collections$IEnumerator$MoveNext(); )
                        {
                            array.SetValue$2(e.System$Collections$IEnumerator$Current, index++);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 42950459409, 4357226497)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 68720263185, 43011932161)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130328593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this._coll).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 68720263185, 43011932161)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 64425295889, 38716964865)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540394001);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 64425295889, 38716964865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242128385)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652193793);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242128385)
                    
                    //--TRIMMABLE-BOUNDARY-START(4357488641)
                    //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
                    System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357488641);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4357488641)
                    
                    static $h = 786449;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73015230481),
    {
      "p": 1310721,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360524817,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 786449,
      "h": 73015230481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015230481),
//--TRIMMABLE-BOUNDARY-START(12885688337),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770590225,
        "f": 50331649
      },
      "n": "Count",
      "d": 786449,
      "h": 12885688337,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885688337),
//--TRIMMABLE-BOUNDARY-START(ALL, 68720263185, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130328593,
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 786449,
      "h": 68720263185,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68720263185, 43011932161),
//--TRIMMABLE-BOUNDARY-START(ALL, 64425295889, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540394001,
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 786449,
      "h": 64425295889,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64425295889, 38716964865)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180655633),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "Get",
      "d": 786449,
      "h": 17180655633,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180655633),
//--TRIMMABLE-BOUNDARY-START(38655492113),
    {
      "r": 62652417,
      "n": "GetEnumerator",
      "d": 786449,
      "h": 38655492113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492113)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753745),
    {
      "t": 720913,
      "n": "_coll",
      "d": 786449,
      "h": 4295753745,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753745)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721041),
    {
      "p": [
        {
          "n": "coll",
          "p": 720913
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786449,
      "h": 8590721041,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590721041)
  ],
  "i": [62259201,62521345
  ],
  "d": 720913,
  "h": 786449
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase.KeysCollection`; }
                }, $cls, ($v) => $cls.$_KeysCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786449)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(4357488641)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357488641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(4452319233)
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4452319233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetObjectData(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4452319233)
            
            //--TRIMMABLE-BOUNDARY-START(4452057089)
            //Generated interface implemetation for System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object?)
            System$Runtime$Serialization$IDeserializationCallback$OnDeserialization()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4452057089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDeserialization(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4452057089)
            
            //--TRIMMABLE-BOUNDARY-START(34360459281)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(214749085713)
                    this.s_defaultComparer = $.$$.System.Globalization.GlobalizationExtensions.GetStringComparer($.$$.System.Globalization.CultureInfo.InvariantCulture.CompareInfo, 1/*CompareOptions.IgnoreCase*/);
                    //--TRIMMABLE-BOUNDARY-END(214749085713)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360459281)
            
            static $h = 720913;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(124554772497),
    {
      "p": 62717953,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734641681,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339020305,
        "f": 83886088
      },
      "n": "Comparer",
      "d": 720913,
      "h": 124554772497,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(124554772497),
//--TRIMMABLE-BOUNDARY-START(180389347345),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914510865,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928954897,
        "f": 83886084
      },
      "n": "IsReadOnly",
      "d": 720913,
      "h": 180389347345,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(180389347345),
//--TRIMMABLE-BOUNDARY-START(128849739793),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324576273,
        "f": 50331777
      },
      "n": "Count",
      "d": 720913,
      "h": 128849739793,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(128849739793),
//--TRIMMABLE-BOUNDARY-START(ALL, 261993725969, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403791377,
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 720913,
      "h": 261993725969,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 261993725969, 43011932161),
//--TRIMMABLE-BOUNDARY-START(ALL, 257698758673, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813856785,
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 720913,
      "h": 257698758673,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 257698758673, 38716964865),
//--TRIMMABLE-BOUNDARY-START(184684314641),
    {
      "p": 786449,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504445457,
        "f": 50331777
      },
      "n": "Keys",
      "o": "@$1",
      "d": 720913,
      "h": 184684314641,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(184684314641)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(176094380049),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 157941761
        },
        {
          "n": "context",
          "p": 158072833
        }
      ],
      "n": "GetObjectData",
      "d": 720913,
      "h": 176094380049,
      "f": 16777345,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176094380049),
//--TRIMMABLE-BOUNDARY-START(201864183825),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        }
      ],
      "n": "OnDeserialization",
      "d": 720913,
      "h": 201864183825,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(201864183825),
//--TRIMMABLE-BOUNDARY-START(206159151121),
    {
      "r": 65537,
      "n": "Reset",
      "d": 720913,
      "h": 206159151121,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159151121),
//--TRIMMABLE-BOUNDARY-START(210454118417),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "Reset",
      "o": "@$1",
      "d": 720913,
      "h": 210454118417,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210454118417),
//--TRIMMABLE-BOUNDARY-START(133144707089),
    {
      "r": 851985,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "FindEntry",
      "d": 720913,
      "h": 133144707089,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133144707089),
//--TRIMMABLE-BOUNDARY-START(103079936017),
    {
      "r": 262145,
      "n": "BaseHasKeys",
      "d": 720913,
      "h": 103079936017,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(103079936017),
//--TRIMMABLE-BOUNDARY-START(68720197649),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "BaseAdd",
      "d": 720913,
      "h": 68720197649,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(68720197649),
//--TRIMMABLE-BOUNDARY-START(107374903313),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "BaseRemove",
      "d": 720913,
      "h": 107374903313,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(107374903313),
//--TRIMMABLE-BOUNDARY-START(111669870609),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "BaseRemoveAt",
      "d": 720913,
      "h": 111669870609,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(111669870609),
//--TRIMMABLE-BOUNDARY-START(73015164945),
    {
      "r": 65537,
      "n": "BaseClear",
      "d": 720913,
      "h": 73015164945,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(73015164945),
//--TRIMMABLE-BOUNDARY-START(77310132241),
    {
      "r": 131073,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "BaseGet",
      "o": "@$1",
      "d": 720913,
      "h": 77310132241,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(77310132241),
//--TRIMMABLE-BOUNDARY-START(115964837905),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "BaseSet",
      "o": "@$1",
      "d": 720913,
      "h": 115964837905,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(115964837905),
//--TRIMMABLE-BOUNDARY-START(81605099537),
    {
      "r": 131073,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "BaseGet",
      "d": 720913,
      "h": 81605099537,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(81605099537),
//--TRIMMABLE-BOUNDARY-START(98784968721),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "BaseGetKey",
      "d": 720913,
      "h": 98784968721,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(98784968721),
//--TRIMMABLE-BOUNDARY-START(120259805201),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "BaseSet",
      "d": 720913,
      "h": 120259805201,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(120259805201),
//--TRIMMABLE-BOUNDARY-START(171799412753),
    {
      "r": 62652417,
      "n": "GetEnumerator",
      "d": 720913,
      "h": 171799412753,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171799412753),
//--TRIMMABLE-BOUNDARY-START(85900066833),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "n": "BaseGetAllKeys",
      "d": 720913,
      "h": 85900066833,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(85900066833),
//--TRIMMABLE-BOUNDARY-START(90195034129),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "n": "BaseGetAllValues",
      "d": 720913,
      "h": 90195034129,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(90195034129),
//--TRIMMABLE-BOUNDARY-START(94490001425),
    {
      "r": $.$typeArray($.$$.System.Object).$h,
      "p": [
        {
          "n": "type",
          "p": 187629569
        }
      ],
      "n": "BaseGetAllValues",
      "o": "@$1",
      "d": 720913,
      "h": 94490001425,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(94490001425)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770524689),
    {
      "t": 262145,
      "n": "_readOnly",
      "d": 720913,
      "h": 25770524689,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524689),
//--TRIMMABLE-BOUNDARY-START(4295688209),
    {
      "t": 54329345,
      "n": "_entriesArray",
      "d": 720913,
      "h": 4295688209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688209),
//--TRIMMABLE-BOUNDARY-START(12885622801),
    {
      "t": 62717953,
      "n": "_keyComparer",
      "d": 720913,
      "h": 12885622801,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622801),
//--TRIMMABLE-BOUNDARY-START(8590655505),
    {
      "t": 61800449,
      "n": "_entriesTable",
      "d": 720913,
      "h": 8590655505,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655505),
//--TRIMMABLE-BOUNDARY-START(21475557393),
    {
      "t": 851985,
      "n": "_nullKeyEntry",
      "d": 720913,
      "h": 21475557393,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557393),
//--TRIMMABLE-BOUNDARY-START(17180590097),
    {
      "t": 786449,
      "n": "_keys",
      "d": 720913,
      "h": 17180590097,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590097),
//--TRIMMABLE-BOUNDARY-START(30065491985),
    {
      "t": 655361,
      "n": "_version",
      "d": 720913,
      "h": 30065491985,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065491985),
//--TRIMMABLE-BOUNDARY-START(214749085713),
    {
      "t": 163381249,
      "n": "s_defaultComparer",
      "d": 720913,
      "h": 214749085713,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(214749085713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426577),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720913,
      "h": 38655426577,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38655426577),
//--TRIMMABLE-BOUNDARY-START(42950393873),
    {
      "p": [
        {
          "n": "equalityComparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720913,
      "h": 42950393873,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42950393873),
//--TRIMMABLE-BOUNDARY-START(47245361169),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "equalityComparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720913,
      "h": 47245361169,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47245361169),
//--TRIMMABLE-BOUNDARY-START(51540328465),
    {
      "p": [
        {
          "n": "hashProvider",
          "p": 62783489
        },
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720913,
      "h": 51540328465,
      "f": 16777220,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This constructor has been deprecated. Use NameObjectCollectionBase(IEqualityComparer) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540328465),
//--TRIMMABLE-BOUNDARY-START(55835295761),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "hashProvider",
          "p": 62783489
        },
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720913,
      "h": 55835295761,
      "f": 16777220,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This constructor has been deprecated. Use NameObjectCollectionBase(Int32, IEqualityComparer) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835295761),
//--TRIMMABLE-BOUNDARY-START(60130263057),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 720913,
      "h": 60130263057,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(60130263057),
//--TRIMMABLE-BOUNDARY-START(64425230353),
    {
      "p": [
        {
          "n": "info",
          "p": 157941761
        },
        {
          "n": "context",
          "p": 158072833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 720913,
      "h": 64425230353,
      "f": 16777220,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425230353)
  ],
  "i": [62259201,62521345,157351937,157089793
  ],
  "j": [851985,917521,786449
  ],
  "h": 720913
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.NameObjectCollectionBase`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720913)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507345)
        $asm.$cls("$scs.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(253404577809)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(253404577809)
            
            //--TRIMMABLE-BOUNDARY-START(244814643217)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(244814643217)
            
            //--TRIMMABLE-BOUNDARY-START(249109610513)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275035665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$scs.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections.Specialized", $.$scs.System.SR.$type.Assembly);
                    $.$scs.System.SR.s_resourceManager = temp;
                }
                return $.$scs.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(249109610513)
            
            //--TRIMMABLE-BOUNDARY-START(34361245713)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145493521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scs.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584446993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scs.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34361245713)
            
            //--TRIMMABLE-BOUNDARY-START(17181376529)
            static /*string */ get Argument_AddingDuplicate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An item with the same key has already been added. Key: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(17181376529)
            
            //--TRIMMABLE-BOUNDARY-START(73015951377)
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(73015951377)
            
            //--TRIMMABLE-BOUNDARY-START(219044839441)
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735428113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Collection was modified after the enumerator was instantiated.";
            }
            //--TRIMMABLE-BOUNDARY-END(219044839441)
            
            //--TRIMMABLE-BOUNDARY-START(223339806737)
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325362705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has either not started or has already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(223339806737)
            
            //--TRIMMABLE-BOUNDARY-START(12886409233)
            static /*string */ get Arg_MultiRank()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Multi dimension array is not supported on this operation.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886409233)
            
            //--TRIMMABLE-BOUNDARY-START(8591441937)
            static /*string */ get Arg_InsufficientSpace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605885969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Insufficient space in the target location to copy the information.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591441937)
            
            //--TRIMMABLE-BOUNDARY-START(30066278417)
            static /*string */ get CollectionReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555558929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Collection is read-only.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066278417)
            
            //--TRIMMABLE-BOUNDARY-START(25771311121)
            static /*string */ get BitVectorFull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Bit vector is full.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771311121)
            
            //--TRIMMABLE-BOUNDARY-START(236224708625)
            static /*string */ get OrderedDictionary_ReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095166481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The OrderedDictionary is read-only and cannot be modified.";
            }
            //--TRIMMABLE-BOUNDARY-END(236224708625)
            
            //--TRIMMABLE-BOUNDARY-START(21476343825)
            static /*string */ get Argument_ImplementIComparable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "At least one object must implement IComparable.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476343825)
            
            //--TRIMMABLE-BOUNDARY-START(240519675921)
            static /*string */ get OrderedDictionary_SerializationMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685101073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There was an error deserializing the OrderedDictionary.  The ArrayList does not contain DictionaryEntries.";
            }
            //--TRIMMABLE-BOUNDARY-END(240519675921)
            
            //--TRIMMABLE-BOUNDARY-START(261994512401)
            static /*string */ get Serialization_InvalidOnDeser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864970257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "OnDeserialization method was called while the object was not being deserialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(261994512401)
            
            //--TRIMMABLE-BOUNDARY-START(227634774033)
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915297297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(227634774033)
            
            //--TRIMMABLE-BOUNDARY-START(231929741329)
            static /*string */ get NotSupported_ValueCollectionSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505231889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mutating a value collection derived from a dictionary is not allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(231929741329)
            
            //--TRIMMABLE-BOUNDARY-START(257699545105)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(257699545105)
            
            //--TRIMMABLE-BOUNDARY-START(214749872145)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749872145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749872145)
            
            //--TRIMMABLE-BOUNDARY-START(274879414289)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274879414289);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scs.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274879414289)
            
            //--TRIMMABLE-BOUNDARY-START(206159937553)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159937553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scs.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(206159937553)
            
            //--TRIMMABLE-BOUNDARY-START(210454904849)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454904849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scs.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(210454904849)
            
            //--TRIMMABLE-BOUNDARY-START(38656213009)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656213009)
            
            //--TRIMMABLE-BOUNDARY-START(42951180305)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(42951180305)
            
            //--TRIMMABLE-BOUNDARY-START(47246147601)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246147601)
            
            //--TRIMMABLE-BOUNDARY-START(51541114897)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scs.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(51541114897)
            
            //--TRIMMABLE-BOUNDARY-START(55836082193)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(55836082193)
            
            //--TRIMMABLE-BOUNDARY-START(60131049489)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(60131049489)
            
            //--TRIMMABLE-BOUNDARY-START(64426016785)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scs.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(64426016785)
            
            //--TRIMMABLE-BOUNDARY-START(68720984081)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scs.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(68720984081)
            
            //--TRIMMABLE-BOUNDARY-START(4296474641)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(257699545105)
                    this.s_usingResourceKeys = $.$scs.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(257699545105)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296474641)
            
            static $h = 1507345;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1507345
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507345)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441809)
        $asm.$cls("$scs.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382253531153)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382253531153)
            
            //--TRIMMABLE-BOUNDARY-START(433793138705)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433793138705)
            
            //--TRIMMABLE-BOUNDARY-START(429498171409)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429498171409)
            
            //--TRIMMABLE-BOUNDARY-START(266289414161)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266289414161)
            
            //--TRIMMABLE-BOUNDARY-START(261994446865)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261994446865)
            
            //--TRIMMABLE-BOUNDARY-START(77310853137)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77310853137)
            
            //--TRIMMABLE-BOUNDARY-START(73015885841)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73015885841)
            
            //--TRIMMABLE-BOUNDARY-START(94490722321)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94490722321)
            
            //--TRIMMABLE-BOUNDARY-START(90195755025)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90195755025)
            
            //--TRIMMABLE-BOUNDARY-START(214749806609)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214749806609)
            
            //--TRIMMABLE-BOUNDARY-START(210454839313)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210454839313)
            
            //--TRIMMABLE-BOUNDARY-START(442383073297)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442383073297)
            
            //--TRIMMABLE-BOUNDARY-START(446678040593)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446678040593)
            
            //--TRIMMABLE-BOUNDARY-START(438088106001)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438088106001)
            
            //--TRIMMABLE-BOUNDARY-START(146030329873)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146030329873)
            
            //--TRIMMABLE-BOUNDARY-START(141735362577)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141735362577)
            
            //--TRIMMABLE-BOUNDARY-START(120260526097)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120260526097)
            
            //--TRIMMABLE-BOUNDARY-START(115965558801)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115965558801)
            
            //--TRIMMABLE-BOUNDARY-START(51541049361)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51541049361)
            
            //--TRIMMABLE-BOUNDARY-START(47246082065)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47246082065)
            
            //--TRIMMABLE-BOUNDARY-START(326418956305)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326418956305)
            
            //--TRIMMABLE-BOUNDARY-START(322123989009)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322123989009)
            
            //--TRIMMABLE-BOUNDARY-START(60130983953)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60130983953)
            
            //--TRIMMABLE-BOUNDARY-START(55836016657)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55836016657)
            
            //--TRIMMABLE-BOUNDARY-START(85900787729)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85900787729)
            
            //--TRIMMABLE-BOUNDARY-START(81605820433)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81605820433)
            
            //--TRIMMABLE-BOUNDARY-START(197569937425)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569937425)
            
            //--TRIMMABLE-BOUNDARY-START(193274970129)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193274970129)
            
            //--TRIMMABLE-BOUNDARY-START(489627713553)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489627713553)
            
            //--TRIMMABLE-BOUNDARY-START(485332746257)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485332746257)
            
            //--TRIMMABLE-BOUNDARY-START(163210199057)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210199057)
            
            //--TRIMMABLE-BOUNDARY-START(158915231761)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158915231761)
            
            //--TRIMMABLE-BOUNDARY-START(206159872017)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206159872017)
            
            //--TRIMMABLE-BOUNDARY-START(201864904721)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201864904721)
            
            //--TRIMMABLE-BOUNDARY-START(399433400337)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399433400337)
            
            //--TRIMMABLE-BOUNDARY-START(395138433041)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395138433041)
            
            //--TRIMMABLE-BOUNDARY-START(300649152529)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300649152529)
            
            //--TRIMMABLE-BOUNDARY-START(296354185233)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296354185233)
            
            //--TRIMMABLE-BOUNDARY-START(377958563857)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377958563857)
            
            //--TRIMMABLE-BOUNDARY-START(373663596561)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373663596561)
            
            //--TRIMMABLE-BOUNDARY-START(231929675793)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231929675793)
            
            //--TRIMMABLE-BOUNDARY-START(227634708497)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227634708497)
            
            //--TRIMMABLE-BOUNDARY-START(154620264465)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620264465)
            
            //--TRIMMABLE-BOUNDARY-START(150325297169)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150325297169)
            
            //--TRIMMABLE-BOUNDARY-START(352188760081)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352188760081)
            
            //--TRIMMABLE-BOUNDARY-START(347893792785)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347893792785)
            
            //--TRIMMABLE-BOUNDARY-START(360778694673)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360778694673)
            
            //--TRIMMABLE-BOUNDARY-START(356483727377)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356483727377)
            
            //--TRIMMABLE-BOUNDARY-START(17181310993)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17181310993)
            
            //--TRIMMABLE-BOUNDARY-START(12886343697)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12886343697)
            
            //--TRIMMABLE-BOUNDARY-START(408023334929)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408023334929)
            
            //--TRIMMABLE-BOUNDARY-START(403728367633)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403728367633)
            
            //--TRIMMABLE-BOUNDARY-START(498217648145)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498217648145)
            
            //--TRIMMABLE-BOUNDARY-START(493922680849)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493922680849)
            
            //--TRIMMABLE-BOUNDARY-START(283469283345)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283469283345)
            
            //--TRIMMABLE-BOUNDARY-START(279174316049)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279174316049)
            
            //--TRIMMABLE-BOUNDARY-START(506807582737)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506807582737)
            
            //--TRIMMABLE-BOUNDARY-START(502512615441)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502512615441)
            
            //--TRIMMABLE-BOUNDARY-START(274879348753)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274879348753)
            
            //--TRIMMABLE-BOUNDARY-START(270584381457)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270584381457)
            
            //--TRIMMABLE-BOUNDARY-START(481037778961)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481037778961)
            
            //--TRIMMABLE-BOUNDARY-START(476742811665)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476742811665)
            
            //--TRIMMABLE-BOUNDARY-START(128850460689)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128850460689)
            
            //--TRIMMABLE-BOUNDARY-START(124555493393)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124555493393)
            
            //--TRIMMABLE-BOUNDARY-START(111670591505)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111670591505)
            
            //--TRIMMABLE-BOUNDARY-START(107375624209)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107375624209)
            
            //--TRIMMABLE-BOUNDARY-START(335008890897)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335008890897)
            
            //--TRIMMABLE-BOUNDARY-START(330713923601)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330713923601)
            
            //--TRIMMABLE-BOUNDARY-START(68720918545)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68720918545)
            
            //--TRIMMABLE-BOUNDARY-START(64425951249)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64425951249)
            
            //--TRIMMABLE-BOUNDARY-START(390843465745)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390843465745)
            
            //--TRIMMABLE-BOUNDARY-START(386548498449)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386548498449)
            
            //--TRIMMABLE-BOUNDARY-START(309239087121)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309239087121)
            
            //--TRIMMABLE-BOUNDARY-START(304944119825)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304944119825)
            
            //--TRIMMABLE-BOUNDARY-START(42951114769)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951114769)
            
            //--TRIMMABLE-BOUNDARY-START(38656147473)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38656147473)
            
            //--TRIMMABLE-BOUNDARY-START(416613269521)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416613269521)
            
            //--TRIMMABLE-BOUNDARY-START(412318302225)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412318302225)
            
            //--TRIMMABLE-BOUNDARY-START(472447844369)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472447844369)
            
            //--TRIMMABLE-BOUNDARY-START(468152877073)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468152877073)
            
            //--TRIMMABLE-BOUNDARY-START(188980002833)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188980002833)
            
            //--TRIMMABLE-BOUNDARY-START(184685035537)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184685035537)
            
            //--TRIMMABLE-BOUNDARY-START(171800133649)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171800133649)
            
            //--TRIMMABLE-BOUNDARY-START(167505166353)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167505166353)
            
            //--TRIMMABLE-BOUNDARY-START(180390068241)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180390068241)
            
            //--TRIMMABLE-BOUNDARY-START(176095100945)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176095100945)
            
            //--TRIMMABLE-BOUNDARY-START(34361180177)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34361180177)
            
            //--TRIMMABLE-BOUNDARY-START(30066212881)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30066212881)
            
            //--TRIMMABLE-BOUNDARY-START(137440395281)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137440395281)
            
            //--TRIMMABLE-BOUNDARY-START(133145427985)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133145427985)
            
            //--TRIMMABLE-BOUNDARY-START(103080656913)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103080656913)
            
            //--TRIMMABLE-BOUNDARY-START(98785689617)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98785689617)
            
            //--TRIMMABLE-BOUNDARY-START(523987451921)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523987451921)
            
            //--TRIMMABLE-BOUNDARY-START(519692484625)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519692484625)
            
            //--TRIMMABLE-BOUNDARY-START(369368629265)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369368629265)
            
            //--TRIMMABLE-BOUNDARY-START(365073661969)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365073661969)
            
            //--TRIMMABLE-BOUNDARY-START(223339741201)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223339741201)
            
            //--TRIMMABLE-BOUNDARY-START(219044773905)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219044773905)
            
            //--TRIMMABLE-BOUNDARY-START(249109544977)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249109544977)
            
            //--TRIMMABLE-BOUNDARY-START(236224643089)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236224643089)
            
            //--TRIMMABLE-BOUNDARY-START(244814577681)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244814577681)
            
            //--TRIMMABLE-BOUNDARY-START(240519610385)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240519610385)
            
            //--TRIMMABLE-BOUNDARY-START(317829021713)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317829021713)
            
            //--TRIMMABLE-BOUNDARY-START(313534054417)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313534054417)
            
            //--TRIMMABLE-BOUNDARY-START(8591376401)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8591376401)
            
            //--TRIMMABLE-BOUNDARY-START(4296409105)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4296409105)
            
            //--TRIMMABLE-BOUNDARY-START(455267975185)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455267975185)
            
            //--TRIMMABLE-BOUNDARY-START(450973007889)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450973007889)
            
            //--TRIMMABLE-BOUNDARY-START(25771245585)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25771245585)
            
            //--TRIMMABLE-BOUNDARY-START(21476278289)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21476278289)
            
            //--TRIMMABLE-BOUNDARY-START(257699479569)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257699479569)
            
            //--TRIMMABLE-BOUNDARY-START(253404512273)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253404512273)
            
            //--TRIMMABLE-BOUNDARY-START(515397517329)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515397517329)
            
            //--TRIMMABLE-BOUNDARY-START(511102550033)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511102550033)
            
            //--TRIMMABLE-BOUNDARY-START(463857909777)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463857909777)
            
            //--TRIMMABLE-BOUNDARY-START(459562942481)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459562942481)
            
            //--TRIMMABLE-BOUNDARY-START(425203204113)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425203204113)
            
            //--TRIMMABLE-BOUNDARY-START(420908236817)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420908236817)
            
            //--TRIMMABLE-BOUNDARY-START(343598825489)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343598825489)
            
            //--TRIMMABLE-BOUNDARY-START(339303858193)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339303858193)
            
            //--TRIMMABLE-BOUNDARY-START(292059217937)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292059217937)
            
            //--TRIMMABLE-BOUNDARY-START(287764250641)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287764250641)
            
            //--TRIMMABLE-BOUNDARY-START(532577386513)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532577386513)
            
            //--TRIMMABLE-BOUNDARY-START(528282419217)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528282419217)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382253531153)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382253531153)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433793138705)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433793138705)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429498171409)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429498171409)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266289414161)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266289414161)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261994446865)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261994446865)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310853137)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77310853137)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015885841)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73015885841)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490722321)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94490722321)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195755025)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90195755025)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749806609)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214749806609)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454839313)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210454839313)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442383073297)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442383073297)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446678040593)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446678040593)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438088106001)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438088106001)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146030329873)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146030329873)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141735362577)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141735362577)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120260526097)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120260526097)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115965558801)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115965558801)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541049361)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51541049361)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246082065)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47246082065)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418956305)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326418956305)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123989009)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322123989009)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130983953)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60130983953)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836016657)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55836016657)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900787729)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85900787729)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605820433)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81605820433)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569937425)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197569937425)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274970129)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193274970129)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489627713553)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489627713553)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485332746257)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485332746257)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163210199057)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163210199057)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915231761)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158915231761)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159872017)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206159872017)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864904721)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201864904721)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399433400337)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399433400337)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395138433041)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395138433041)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649152529)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300649152529)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354185233)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296354185233)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377958563857)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377958563857)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373663596561)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373663596561)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231929675793)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231929675793)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227634708497)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227634708497)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620264465)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154620264465)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150325297169)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150325297169)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352188760081)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352188760081)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893792785)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347893792785)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360778694673)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360778694673)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356483727377)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356483727377)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181310993)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17181310993)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886343697)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12886343697)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408023334929)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408023334929)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403728367633)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403728367633)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498217648145)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498217648145)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493922680849)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493922680849)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469283345)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283469283345)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174316049)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279174316049)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506807582737)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506807582737)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502512615441)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502512615441)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274879348753)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274879348753)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270584381457)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270584381457)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481037778961)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481037778961)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476742811665)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476742811665)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128850460689)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128850460689)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124555493393)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124555493393)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111670591505)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111670591505)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107375624209)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107375624209)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008890897)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335008890897)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713923601)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330713923601)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720918545)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68720918545)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425951249)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64425951249)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390843465745)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390843465745)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386548498449)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386548498449)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309239087121)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309239087121)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304944119825)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304944119825)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951114769)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42951114769)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656147473)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38656147473)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613269521)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416613269521)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412318302225)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412318302225)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472447844369)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472447844369)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468152877073)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468152877073)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188980002833)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188980002833)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184685035537)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184685035537)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171800133649)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171800133649)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167505166353)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167505166353)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180390068241)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180390068241)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176095100945)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176095100945)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361180177)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34361180177)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066212881)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30066212881)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137440395281)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137440395281)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133145427985)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133145427985)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103080656913)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103080656913)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98785689617)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98785689617)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523987451921)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523987451921)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519692484625)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519692484625)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369368629265)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369368629265)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365073661969)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365073661969)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223339741201)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223339741201)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219044773905)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219044773905)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249109544977)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249109544977)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236224643089)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236224643089)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244814577681)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244814577681)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240519610385)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240519610385)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317829021713)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317829021713)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313534054417)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313534054417)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8591376401)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8591376401)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4296409105)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4296409105)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455267975185)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455267975185)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450973007889)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450973007889)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771245585)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25771245585)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476278289)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21476278289)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257699479569)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257699479569)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253404512273)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253404512273)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515397517329)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515397517329)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511102550033)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511102550033)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463857909777)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463857909777)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459562942481)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459562942481)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425203204113)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425203204113)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908236817)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420908236817)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598825489)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343598825489)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303858193)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339303858193)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292059217937)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292059217937)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764250641)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287764250641)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532577386513)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532577386513)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528282419217)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528282419217)
                    
                }
            }
            static $h = 1441809;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382253531153),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 1441809,
      "h": 382253531153,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382253531153),
//--TRIMMABLE-BOUNDARY-START(433793138705),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 1441809,
      "h": 433793138705,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433793138705),
//--TRIMMABLE-BOUNDARY-START(429498171409),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 1441809,
      "h": 429498171409,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429498171409),
//--TRIMMABLE-BOUNDARY-START(266289414161),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 1441809,
      "h": 266289414161,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266289414161),
//--TRIMMABLE-BOUNDARY-START(261994446865),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 1441809,
      "h": 261994446865,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261994446865),
//--TRIMMABLE-BOUNDARY-START(77310853137),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 1441809,
      "h": 77310853137,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310853137),
//--TRIMMABLE-BOUNDARY-START(73015885841),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 1441809,
      "h": 73015885841,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015885841),
//--TRIMMABLE-BOUNDARY-START(94490722321),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 1441809,
      "h": 94490722321,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490722321),
//--TRIMMABLE-BOUNDARY-START(90195755025),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 1441809,
      "h": 90195755025,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195755025),
//--TRIMMABLE-BOUNDARY-START(214749806609),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 1441809,
      "h": 214749806609,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214749806609),
//--TRIMMABLE-BOUNDARY-START(210454839313),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 1441809,
      "h": 210454839313,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210454839313),
//--TRIMMABLE-BOUNDARY-START(442383073297),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 1441809,
      "h": 442383073297,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442383073297),
//--TRIMMABLE-BOUNDARY-START(446678040593),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 1441809,
      "h": 446678040593,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446678040593),
//--TRIMMABLE-BOUNDARY-START(438088106001),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 1441809,
      "h": 438088106001,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438088106001),
//--TRIMMABLE-BOUNDARY-START(146030329873),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 1441809,
      "h": 146030329873,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030329873),
//--TRIMMABLE-BOUNDARY-START(141735362577),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 1441809,
      "h": 141735362577,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141735362577),
//--TRIMMABLE-BOUNDARY-START(120260526097),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 1441809,
      "h": 120260526097,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120260526097),
//--TRIMMABLE-BOUNDARY-START(115965558801),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 1441809,
      "h": 115965558801,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115965558801),
//--TRIMMABLE-BOUNDARY-START(51541049361),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 1441809,
      "h": 51541049361,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51541049361),
//--TRIMMABLE-BOUNDARY-START(47246082065),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 1441809,
      "h": 47246082065,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47246082065),
//--TRIMMABLE-BOUNDARY-START(326418956305),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 1441809,
      "h": 326418956305,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326418956305),
//--TRIMMABLE-BOUNDARY-START(322123989009),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 1441809,
      "h": 322123989009,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322123989009),
//--TRIMMABLE-BOUNDARY-START(60130983953),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 1441809,
      "h": 60130983953,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130983953),
//--TRIMMABLE-BOUNDARY-START(55836016657),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 1441809,
      "h": 55836016657,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836016657),
//--TRIMMABLE-BOUNDARY-START(85900787729),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 1441809,
      "h": 85900787729,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900787729),
//--TRIMMABLE-BOUNDARY-START(81605820433),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 1441809,
      "h": 81605820433,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605820433),
//--TRIMMABLE-BOUNDARY-START(197569937425),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 1441809,
      "h": 197569937425,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197569937425),
//--TRIMMABLE-BOUNDARY-START(193274970129),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 1441809,
      "h": 193274970129,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193274970129),
//--TRIMMABLE-BOUNDARY-START(489627713553),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 1441809,
      "h": 489627713553,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489627713553),
//--TRIMMABLE-BOUNDARY-START(485332746257),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 1441809,
      "h": 485332746257,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485332746257),
//--TRIMMABLE-BOUNDARY-START(163210199057),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 1441809,
      "h": 163210199057,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210199057),
//--TRIMMABLE-BOUNDARY-START(158915231761),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 1441809,
      "h": 158915231761,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915231761),
//--TRIMMABLE-BOUNDARY-START(206159872017),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 1441809,
      "h": 206159872017,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206159872017),
//--TRIMMABLE-BOUNDARY-START(201864904721),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 1441809,
      "h": 201864904721,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201864904721),
//--TRIMMABLE-BOUNDARY-START(399433400337),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 1441809,
      "h": 399433400337,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399433400337),
//--TRIMMABLE-BOUNDARY-START(395138433041),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 1441809,
      "h": 395138433041,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395138433041),
//--TRIMMABLE-BOUNDARY-START(300649152529),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 1441809,
      "h": 300649152529,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300649152529),
//--TRIMMABLE-BOUNDARY-START(296354185233),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 1441809,
      "h": 296354185233,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296354185233),
//--TRIMMABLE-BOUNDARY-START(377958563857),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 1441809,
      "h": 377958563857,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377958563857),
//--TRIMMABLE-BOUNDARY-START(373663596561),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 1441809,
      "h": 373663596561,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373663596561),
//--TRIMMABLE-BOUNDARY-START(231929675793),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 1441809,
      "h": 231929675793,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231929675793),
//--TRIMMABLE-BOUNDARY-START(227634708497),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 1441809,
      "h": 227634708497,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227634708497),
//--TRIMMABLE-BOUNDARY-START(154620264465),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 1441809,
      "h": 154620264465,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154620264465),
//--TRIMMABLE-BOUNDARY-START(150325297169),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 1441809,
      "h": 150325297169,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150325297169),
//--TRIMMABLE-BOUNDARY-START(352188760081),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 1441809,
      "h": 352188760081,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352188760081),
//--TRIMMABLE-BOUNDARY-START(347893792785),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 1441809,
      "h": 347893792785,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893792785),
//--TRIMMABLE-BOUNDARY-START(360778694673),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 1441809,
      "h": 360778694673,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360778694673),
//--TRIMMABLE-BOUNDARY-START(356483727377),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 1441809,
      "h": 356483727377,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356483727377),
//--TRIMMABLE-BOUNDARY-START(17181310993),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 1441809,
      "h": 17181310993,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181310993),
//--TRIMMABLE-BOUNDARY-START(12886343697),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 1441809,
      "h": 12886343697,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886343697),
//--TRIMMABLE-BOUNDARY-START(408023334929),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 1441809,
      "h": 408023334929,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408023334929),
//--TRIMMABLE-BOUNDARY-START(403728367633),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 1441809,
      "h": 403728367633,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403728367633),
//--TRIMMABLE-BOUNDARY-START(498217648145),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 1441809,
      "h": 498217648145,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498217648145),
//--TRIMMABLE-BOUNDARY-START(493922680849),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 1441809,
      "h": 493922680849,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493922680849),
//--TRIMMABLE-BOUNDARY-START(283469283345),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 1441809,
      "h": 283469283345,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283469283345),
//--TRIMMABLE-BOUNDARY-START(279174316049),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 1441809,
      "h": 279174316049,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279174316049),
//--TRIMMABLE-BOUNDARY-START(506807582737),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 1441809,
      "h": 506807582737,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506807582737),
//--TRIMMABLE-BOUNDARY-START(502512615441),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 1441809,
      "h": 502512615441,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502512615441),
//--TRIMMABLE-BOUNDARY-START(274879348753),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 1441809,
      "h": 274879348753,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274879348753),
//--TRIMMABLE-BOUNDARY-START(270584381457),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 1441809,
      "h": 270584381457,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270584381457),
//--TRIMMABLE-BOUNDARY-START(481037778961),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 1441809,
      "h": 481037778961,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481037778961),
//--TRIMMABLE-BOUNDARY-START(476742811665),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 1441809,
      "h": 476742811665,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476742811665),
//--TRIMMABLE-BOUNDARY-START(128850460689),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 1441809,
      "h": 128850460689,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128850460689),
//--TRIMMABLE-BOUNDARY-START(124555493393),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 1441809,
      "h": 124555493393,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124555493393),
//--TRIMMABLE-BOUNDARY-START(111670591505),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 1441809,
      "h": 111670591505,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111670591505),
//--TRIMMABLE-BOUNDARY-START(107375624209),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 1441809,
      "h": 107375624209,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107375624209),
//--TRIMMABLE-BOUNDARY-START(335008890897),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 1441809,
      "h": 335008890897,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335008890897),
//--TRIMMABLE-BOUNDARY-START(330713923601),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 1441809,
      "h": 330713923601,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330713923601),
//--TRIMMABLE-BOUNDARY-START(68720918545),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 1441809,
      "h": 68720918545,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720918545),
//--TRIMMABLE-BOUNDARY-START(64425951249),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 1441809,
      "h": 64425951249,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425951249),
//--TRIMMABLE-BOUNDARY-START(390843465745),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 1441809,
      "h": 390843465745,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390843465745),
//--TRIMMABLE-BOUNDARY-START(386548498449),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 1441809,
      "h": 386548498449,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386548498449),
//--TRIMMABLE-BOUNDARY-START(309239087121),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 1441809,
      "h": 309239087121,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309239087121),
//--TRIMMABLE-BOUNDARY-START(304944119825),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 1441809,
      "h": 304944119825,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304944119825),
//--TRIMMABLE-BOUNDARY-START(42951114769),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 1441809,
      "h": 42951114769,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42951114769),
//--TRIMMABLE-BOUNDARY-START(38656147473),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 1441809,
      "h": 38656147473,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656147473),
//--TRIMMABLE-BOUNDARY-START(416613269521),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 1441809,
      "h": 416613269521,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416613269521),
//--TRIMMABLE-BOUNDARY-START(412318302225),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 1441809,
      "h": 412318302225,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412318302225),
//--TRIMMABLE-BOUNDARY-START(472447844369),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 1441809,
      "h": 472447844369,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447844369),
//--TRIMMABLE-BOUNDARY-START(468152877073),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 1441809,
      "h": 468152877073,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468152877073),
//--TRIMMABLE-BOUNDARY-START(188980002833),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 1441809,
      "h": 188980002833,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188980002833),
//--TRIMMABLE-BOUNDARY-START(184685035537),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 1441809,
      "h": 184685035537,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184685035537),
//--TRIMMABLE-BOUNDARY-START(171800133649),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 1441809,
      "h": 171800133649,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171800133649),
//--TRIMMABLE-BOUNDARY-START(167505166353),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 1441809,
      "h": 167505166353,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167505166353),
//--TRIMMABLE-BOUNDARY-START(180390068241),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 1441809,
      "h": 180390068241,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180390068241),
//--TRIMMABLE-BOUNDARY-START(176095100945),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 1441809,
      "h": 176095100945,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176095100945),
//--TRIMMABLE-BOUNDARY-START(34361180177),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 1441809,
      "h": 34361180177,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361180177),
//--TRIMMABLE-BOUNDARY-START(30066212881),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 1441809,
      "h": 30066212881,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066212881),
//--TRIMMABLE-BOUNDARY-START(137440395281),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 1441809,
      "h": 137440395281,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137440395281),
//--TRIMMABLE-BOUNDARY-START(133145427985),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 1441809,
      "h": 133145427985,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133145427985),
//--TRIMMABLE-BOUNDARY-START(103080656913),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 1441809,
      "h": 103080656913,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103080656913),
//--TRIMMABLE-BOUNDARY-START(98785689617),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 1441809,
      "h": 98785689617,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98785689617),
//--TRIMMABLE-BOUNDARY-START(523987451921),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 1441809,
      "h": 523987451921,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523987451921),
//--TRIMMABLE-BOUNDARY-START(519692484625),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 1441809,
      "h": 519692484625,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519692484625),
//--TRIMMABLE-BOUNDARY-START(369368629265),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 1441809,
      "h": 369368629265,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369368629265),
//--TRIMMABLE-BOUNDARY-START(365073661969),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 1441809,
      "h": 365073661969,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365073661969),
//--TRIMMABLE-BOUNDARY-START(223339741201),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 1441809,
      "h": 223339741201,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223339741201),
//--TRIMMABLE-BOUNDARY-START(219044773905),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 1441809,
      "h": 219044773905,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219044773905),
//--TRIMMABLE-BOUNDARY-START(249109544977),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 1441809,
      "h": 249109544977,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249109544977),
//--TRIMMABLE-BOUNDARY-START(236224643089),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 1441809,
      "h": 236224643089,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236224643089),
//--TRIMMABLE-BOUNDARY-START(244814577681),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 1441809,
      "h": 244814577681,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244814577681),
//--TRIMMABLE-BOUNDARY-START(240519610385),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 1441809,
      "h": 240519610385,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240519610385),
//--TRIMMABLE-BOUNDARY-START(317829021713),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 1441809,
      "h": 317829021713,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317829021713),
//--TRIMMABLE-BOUNDARY-START(313534054417),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 1441809,
      "h": 313534054417,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313534054417),
//--TRIMMABLE-BOUNDARY-START(8591376401),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 1441809,
      "h": 8591376401,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8591376401),
//--TRIMMABLE-BOUNDARY-START(4296409105),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 1441809,
      "h": 4296409105,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4296409105),
//--TRIMMABLE-BOUNDARY-START(455267975185),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 1441809,
      "h": 455267975185,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455267975185),
//--TRIMMABLE-BOUNDARY-START(450973007889),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 1441809,
      "h": 450973007889,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450973007889),
//--TRIMMABLE-BOUNDARY-START(25771245585),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 1441809,
      "h": 25771245585,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25771245585),
//--TRIMMABLE-BOUNDARY-START(21476278289),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 1441809,
      "h": 21476278289,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21476278289),
//--TRIMMABLE-BOUNDARY-START(257699479569),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 1441809,
      "h": 257699479569,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257699479569),
//--TRIMMABLE-BOUNDARY-START(253404512273),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 1441809,
      "h": 253404512273,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253404512273),
//--TRIMMABLE-BOUNDARY-START(515397517329),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 1441809,
      "h": 515397517329,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515397517329),
//--TRIMMABLE-BOUNDARY-START(511102550033),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 1441809,
      "h": 511102550033,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511102550033),
//--TRIMMABLE-BOUNDARY-START(463857909777),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 1441809,
      "h": 463857909777,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463857909777),
//--TRIMMABLE-BOUNDARY-START(459562942481),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 1441809,
      "h": 459562942481,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459562942481),
//--TRIMMABLE-BOUNDARY-START(425203204113),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 1441809,
      "h": 425203204113,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425203204113),
//--TRIMMABLE-BOUNDARY-START(420908236817),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 1441809,
      "h": 420908236817,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420908236817),
//--TRIMMABLE-BOUNDARY-START(343598825489),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 1441809,
      "h": 343598825489,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598825489),
//--TRIMMABLE-BOUNDARY-START(339303858193),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 1441809,
      "h": 339303858193,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339303858193),
//--TRIMMABLE-BOUNDARY-START(292059217937),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 1441809,
      "h": 292059217937,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292059217937),
//--TRIMMABLE-BOUNDARY-START(287764250641),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 1441809,
      "h": 287764250641,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287764250641),
//--TRIMMABLE-BOUNDARY-START(532577386513),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 1441809,
      "h": 532577386513,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532577386513),
//--TRIMMABLE-BOUNDARY-START(528282419217),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 1441809,
      "h": 528282419217,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528282419217)
  ],
  "h": 1441809
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441809)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376273)
        $asm.$cls("$scs.System.Collections.Specialized.StringEnumerator", ($self) => class StringEnumerator extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343569)
            /*System.Collections.IEnumerator*/ _baseEnumerator = null;
            //--TRIMMABLE-BOUNDARY-END(4296343569)
            
            //--TRIMMABLE-BOUNDARY-START(8591310865)
            $ctor$1(/*StringCollection*/ mappings)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591310865);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._baseEnumerator = (mappings).System$Collections$IEnumerable$GetEnumerator();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310865)
            
            //--TRIMMABLE-BOUNDARY-START(12886278161)
            /*string? */ get Current()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast((this._baseEnumerator.System$Collections$IEnumerator$Current), $.$$.System.String);
            }
            //--TRIMMABLE-BOUNDARY-END(12886278161)
            
            //--TRIMMABLE-BOUNDARY-START(25771180049)
            /*bool */ MoveNext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._baseEnumerator.System$Collections$IEnumerator$MoveNext();
            }
            //--TRIMMABLE-BOUNDARY-END(25771180049)
            
            //--TRIMMABLE-BOUNDARY-START(30066147345)
            /*void */ Reset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._baseEnumerator.System$Collections$IEnumerator$Reset();
            }
            //--TRIMMABLE-BOUNDARY-END(30066147345)
            
            static $h = 1376273;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886278161),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476212753,
        "f": 50331649
      },
      "n": "Current",
      "d": 1376273,
      "h": 12886278161,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886278161)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180049),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1376273,
      "h": 25771180049,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180049),
//--TRIMMABLE-BOUNDARY-START(30066147345),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1376273,
      "h": 30066147345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066147345)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343569),
    {
      "t": 62652417,
      "n": "_baseEnumerator",
      "d": 1376273,
      "h": 4296343569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343569)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310865),
    {
      "p": [
        {
          "n": "mappings",
          "p": 1245201
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376273,
      "h": 8591310865,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591310865)
  ],
  "h": 1376273
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Specialized.StringEnumerator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376273)
        
        
        //--TRIMMABLE-BOUNDARY-START(65553)
        $asm.$cls("$scs.System.Collections.CompatibleComparer", ($self) => class CompatibleComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590000145)
            /*IHashCodeProvider?*/ _hcp = null;
            //--TRIMMABLE-BOUNDARY-END(8590000145)
            
            //--TRIMMABLE-BOUNDARY-START(4295032849)
            /*IComparer?*/ _comparer = null;
            //--TRIMMABLE-BOUNDARY-END(4295032849)
            
            //--TRIMMABLE-BOUNDARY-START(12884967441)
            $ctor$1(/*IHashCodeProvider?*/ hashCodeProvider, /*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967441);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._hcp = hashCodeProvider;
                    this._comparer = comparer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967441)
            
            //--TRIMMABLE-BOUNDARY-START(51539673105)
            /*IHashCodeProvider? */ get HashCodeProvider()
            {
                return this._hcp;
            }
            //--TRIMMABLE-BOUNDARY-END(51539673105)
            
            //--TRIMMABLE-BOUNDARY-START(21474902033)
            /*IComparer? */ get Comparer()
            {
                return this._comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902033)
            
            //--TRIMMABLE-BOUNDARY-START(25769869329)
            /*bool */ Equals$2(/*object?*/ a, /*object?*/ b)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869329);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Compare(a, b) === 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869329)
            
            //--TRIMMABLE-BOUNDARY-START(17179934737)
            /*int */ Compare(/*object?*/ a, /*object?*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (a === b)
                {
                    return 0;
                }
                if (a === null)
                {
                    return -1;
                }
                if (b === null)
                {
                    return 1;
                }
                if (this._comparer !== null)
                {
                    return this._comparer.System$Collections$IComparer$Compare(a, b);
                }
                let ia;
                if ($.$is(a, $.$$.System.IComparable, { set $v(v){ ia = v; } }))
                {
                    return ia.System$IComparable$CompareTo(b);
                }
                throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Argument_ImplementIComparable);
            }
            //--TRIMMABLE-BOUNDARY-END(17179934737)
            
            //--TRIMMABLE-BOUNDARY-START(47244705809)
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(obj, "obj");
                return this._hcp !== null ? this._hcp.System$Collections$IHashCodeProvider$GetHashCode(obj) : $.$$.System.Object.GetHashCode.call(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705809)
            
            //--TRIMMABLE-BOUNDARY-START(4357685249)
            //Generated interface implemetation for System.Collections.IEqualityComparer.Equals(object?, object?)
            System$Collections$IEqualityComparer$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357685249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357685249)
            
            //--TRIMMABLE-BOUNDARY-START(8652652545)
            //Generated interface implemetation for System.Collections.IEqualityComparer.GetHashCode(object)
            System$Collections$IEqualityComparer$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652652545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652652545)
            
            static $h = 65553;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539673105),
    {
      "p": 62783489,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949738513,
        "f": 50331656
      },
      "n": "HashCodeProvider",
      "d": 65553,
      "h": 51539673105,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51539673105),
//--TRIMMABLE-BOUNDARY-START(21474902033),
    {
      "p": 62324737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359803921,
        "f": 50331656
      },
      "n": "Comparer",
      "d": 65553,
      "h": 21474902033,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21474902033)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869329),
    {
      "r": 262145,
      "p": [
        {
          "n": "a",
          "p": 131073
        },
        {
          "n": "b",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65553,
      "h": 25769869329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25769869329),
//--TRIMMABLE-BOUNDARY-START(17179934737),
    {
      "r": 655361,
      "p": [
        {
          "n": "a",
          "p": 131073
        },
        {
          "n": "b",
          "p": 131073
        }
      ],
      "n": "Compare",
      "d": 65553,
      "h": 17179934737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934737),
//--TRIMMABLE-BOUNDARY-START(47244705809),
    {
      "r": 655361,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "GetHashCode",
      "o": "@$1",
      "d": 65553,
      "h": 47244705809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244705809)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590000145),
    {
      "t": 62783489,
      "n": "_hcp",
      "d": 65553,
      "h": 8590000145,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000145),
//--TRIMMABLE-BOUNDARY-START(4295032849),
    {
      "t": 62324737,
      "n": "_comparer",
      "d": 65553,
      "h": 4295032849,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032849)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967441),
    {
      "p": [
        {
          "n": "hashCodeProvider",
          "p": 62783489
        },
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65553,
      "h": 12884967441,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12884967441)
  ],
  "i": [62717953
  ],
  "h": 65553
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer ]; }
            static get $fullName() { return `System.Collections.CompatibleComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65553)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310737)
        $asm.$cls("$scs.System.Collections.Specialized.StringDictionary", ($self) => class StringDictionary extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25771114513)
            /*Hashtable*/ contents = null;
            //--TRIMMABLE-BOUNDARY-END(25771114513)
            
            //--TRIMMABLE-BOUNDARY-START(4296278033)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278033)
            
            //--TRIMMABLE-BOUNDARY-START(34361049105)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983697);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049105)
            
            //--TRIMMABLE-BOUNDARY-START(94490591249)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(94490591249)
            
            //--TRIMMABLE-BOUNDARY-START(120260395025)
            /*string?*/ get_Item(/*string*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return $.$cast(this.contents.get_Item($.$$.System.String.ToLowerInvariant.call(key)), $.$$.System.String);
            }
            /*void*/ set_Item(/*string*/ key, /*string?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.set_Item($.$$.System.String.ToLowerInvariant.call(key), value);
            }
            //--TRIMMABLE-BOUNDARY-END(120260395025)
            
            //--TRIMMABLE-BOUNDARY-START(98785558545)
            /*ICollection */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.Keys;
            }
            //--TRIMMABLE-BOUNDARY-END(98785558545)
            
            //--TRIMMABLE-BOUNDARY-START(115965427729)
            /*object */ get SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310722065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(115965427729)
            
            //--TRIMMABLE-BOUNDARY-START(124555362321)
            /*ICollection */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(124555362321)
            
            //--TRIMMABLE-BOUNDARY-START(8591245329)
            /*void */ Add(/*string*/ key, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.Add($.$$.System.String.ToLowerInvariant.call(key), value);
            }
            //--TRIMMABLE-BOUNDARY-END(8591245329)
            
            //--TRIMMABLE-BOUNDARY-START(12886212625)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.contents.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(12886212625)
            
            //--TRIMMABLE-BOUNDARY-START(17181179921)
            /*bool */ ContainsKey(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return this.contents.ContainsKey($.$$.System.String.ToLowerInvariant.call(key));
            }
            //--TRIMMABLE-BOUNDARY-END(17181179921)
            
            //--TRIMMABLE-BOUNDARY-START(21476147217)
            /*bool */ ContainsValue(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.ContainsValue(value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476147217)
            
            //--TRIMMABLE-BOUNDARY-START(30066081809)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.contents.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(30066081809)
            
            //--TRIMMABLE-BOUNDARY-START(90195623953)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195623953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.contents.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(90195623953)
            
            //--TRIMMABLE-BOUNDARY-START(103080525841)
            /*void */ Remove(/*string*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.contents.Remove($.$$.System.String.ToLowerInvariant.call(key));
            }
            //--TRIMMABLE-BOUNDARY-END(103080525841)
            
            //--TRIMMABLE-BOUNDARY-START(4357488641)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357488641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357488641)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(25771114513)
                this.contents = new $.$$.System.Collections.Hashtable().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(25771114513)
                
            }
            static $h = 1310737;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049105),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950983697,
        "f": 50331777
      },
      "n": "Count",
      "d": 1310737,
      "h": 34361049105,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(34361049105),
//--TRIMMABLE-BOUNDARY-START(94490591249),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540918289,
        "f": 50331777
      },
      "n": "IsSynchronized",
      "d": 1310737,
      "h": 94490591249,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(94490591249),
//--TRIMMABLE-BOUNDARY-START(120260395025),
    {
      "p": 1310721,
      "i": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130852881,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111670460433,
        "f": 83886209
      },
      "n": "Item",
      "o": "@$2",
      "d": 1310737,
      "h": 120260395025,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(120260395025),
//--TRIMMABLE-BOUNDARY-START(98785558545),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720787473,
        "f": 50331777
      },
      "n": "Keys",
      "o": "@$1",
      "d": 1310737,
      "h": 98785558545,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(98785558545),
//--TRIMMABLE-BOUNDARY-START(115965427729),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310722065,
        "f": 50331777
      },
      "n": "SyncRoot",
      "d": 1310737,
      "h": 115965427729,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115965427729),
//--TRIMMABLE-BOUNDARY-START(124555362321),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900656657,
        "f": 50331777
      },
      "n": "Values",
      "d": 1310737,
      "h": 124555362321,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124555362321)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591245329),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "d": 1310737,
      "h": 8591245329,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591245329),
//--TRIMMABLE-BOUNDARY-START(12886212625),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1310737,
      "h": 12886212625,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886212625),
//--TRIMMABLE-BOUNDARY-START(17181179921),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "ContainsKey",
      "d": 1310737,
      "h": 17181179921,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181179921),
//--TRIMMABLE-BOUNDARY-START(21476147217),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "ContainsValue",
      "d": 1310737,
      "h": 21476147217,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476147217),
//--TRIMMABLE-BOUNDARY-START(30066081809),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1310737,
      "h": 30066081809,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066081809),
//--TRIMMABLE-BOUNDARY-START(90195623953),
    {
      "r": 62652417,
      "n": "GetEnumerator",
      "d": 1310737,
      "h": 90195623953,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90195623953),
//--TRIMMABLE-BOUNDARY-START(103080525841),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "d": 1310737,
      "h": 103080525841,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080525841)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771114513),
    {
      "t": 61800449,
      "n": "contents",
      "d": 1310737,
      "h": 25771114513,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771114513)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278033),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310737,
      "h": 4296278033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278033)
  ],
  "i": [62521345
  ],
  "h": 1310737,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    },
    {
      "t": 393256,
      "c": 17180262440,
      "a": [
        {
          "v": "System.Diagnostics.Design.StringDictionaryCodeDomSerializer, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        },
        {
          "v": "System.ComponentModel.Design.Serialization.CodeDomSerializer, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.StringDictionary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310737)
        
        
        //--TRIMMABLE-BOUNDARY-START(262161)
        $asm.$cls("$scs.System.Collections.Specialized.HybridDictionary", ($self) => class HybridDictionary extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(51539869713)
            /*int*/ static CutoverPoint = 9;
            //--TRIMMABLE-BOUNDARY-END(51539869713)
            
            //--TRIMMABLE-BOUNDARY-START(146029150225)
            /*int*/ static InitialHashtableSize = 13;
            //--TRIMMABLE-BOUNDARY-END(146029150225)
            
            //--TRIMMABLE-BOUNDARY-START(55834837009)
            /*int*/ static FixedSizeCutoverPoint = 6;
            //--TRIMMABLE-BOUNDARY-END(55834837009)
            
            //--TRIMMABLE-BOUNDARY-START(167503986705)
            /*ListDictionary?*/ list = null;
            //--TRIMMABLE-BOUNDARY-END(167503986705)
            
            //--TRIMMABLE-BOUNDARY-START(141734182929)
            /*Hashtable?*/ hashtable = null;
            //--TRIMMABLE-BOUNDARY-END(141734182929)
            
            //--TRIMMABLE-BOUNDARY-START(25770065937)
            /*bool*/ caseInsensitive = false;
            //--TRIMMABLE-BOUNDARY-END(25770065937)
            
            //--TRIMMABLE-BOUNDARY-START(4295229457)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229457)
            
            //--TRIMMABLE-BOUNDARY-START(8590196753)
            $ctor$4(/*int*/ initialSize)
            {
                this.$ctor$3(initialSize, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196753)
            
            //--TRIMMABLE-BOUNDARY-START(12885164049)
            $ctor$2(/*bool*/ caseInsensitive)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164049);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.caseInsensitive = caseInsensitive;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164049)
            
            //--TRIMMABLE-BOUNDARY-START(17180131345)
            $ctor$3(/*int*/ initialSize, /*bool*/ caseInsensitive)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.caseInsensitive = caseInsensitive;
                    if (initialSize >= 6/*FixedSizeCutoverPoint*/)
                    {
                        if (caseInsensitive)
                        {
                            this.hashtable = new $.$$.System.Collections.Hashtable().$ctor$11(initialSize, $.$$.System.StringComparer.OrdinalIgnoreCase);
                        }
                        else 
                        {
                            this.hashtable = new $.$$.System.Collections.Hashtable().$ctor$16(initialSize);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131345)
            
            //--TRIMMABLE-BOUNDARY-START(197568757777)
            /*object?*/ get_Item(/*object*/ key)
            {
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.get_Item(key);
                }
                else if (cachedList !== null)
                {
                    return cachedList.get_Item(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
                return null;
            }
            /*void*/ set_Item(/*object*/ key, /*object?*/ value)
            {
                if (this.hashtable !== null)
                {
                    this.hashtable.set_Item(key, value);
                }
                else if (this.list !== null)
                {
                    if (this.list.Count >= ((9/*CutoverPoint*/ - 1) | 0))
                    {
                        this.ChangeOver();
                        $.$$.System.Diagnostics.Debug.Assert$2(this.hashtable !== null, "hashtable != null");
                        this.hashtable.set_Item(key, value);
                    }
                    else 
                    {
                        this.list.set_Item(key, value);
                    }
                }
                else 
                {
                    this.list = new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                    this.list.set_Item(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197568757777)
            
            //--TRIMMABLE-BOUNDARY-START(171798954001)
            /*ListDictionary */ get List()
            {
                return this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
            }
            //--TRIMMABLE-BOUNDARY-END(171798954001)
            
            //--TRIMMABLE-BOUNDARY-START(30065033233)
            /*void */ ChangeOver()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this.list !== null, "list != null");
                /*IDictionaryEnumerator*/ let en = this.list.GetEnumerator();
                /*Hashtable*/ let newTable;
                if (this.caseInsensitive)
                {
                    newTable = new $.$$.System.Collections.Hashtable().$ctor$11(13/*InitialHashtableSize*/, $.$$.System.StringComparer.OrdinalIgnoreCase);
                }
                else 
                {
                    newTable = new $.$$.System.Collections.Hashtable().$ctor$16(13/*InitialHashtableSize*/);
                }
                while(en.System$Collections$IEnumerator$MoveNext())
                {
                    newTable.Add(en.System$Collections$IDictionaryEnumerator$Key, en.System$Collections$IDictionaryEnumerator$Value);
                }
                this.hashtable = newTable;
                this.list = null;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033233)
            
            //--TRIMMABLE-BOUNDARY-START(47244902417)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.Count;
                }
                else if (cachedList !== null)
                {
                    return cachedList.Count;
                }
                else 
                {
                    return 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244902417)
            
            //--TRIMMABLE-BOUNDARY-START(163209019409)
            /*ICollection */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    return this.hashtable.Keys;
                }
                else 
                {
                    return this.List.Keys$1;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209019409)
            
            //--TRIMMABLE-BOUNDARY-START(154619084817)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154619084817)
            
            //--TRIMMABLE-BOUNDARY-START(150324117521)
            /*bool */ get IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(150324117521)
            
            //--TRIMMABLE-BOUNDARY-START(158914052113)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(158914052113)
            
            //--TRIMMABLE-BOUNDARY-START(188978823185)
            /*object */ get SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(188978823185)
            
            //--TRIMMABLE-BOUNDARY-START(201863725073)
            /*ICollection */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    return this.hashtable.Values;
                }
                else 
                {
                    return this.List.Values;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201863725073)
            
            //--TRIMMABLE-BOUNDARY-START(21475098641)
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    this.hashtable.Add(key, value);
                }
                else 
                {
                    if (this.list === null)
                    {
                        this.list = new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                        this.list.Add(key, value);
                    }
                    else if (((this.list.Count + 1) | 0) >= 9/*CutoverPoint*/)
                    {
                        this.ChangeOver();
                        $.$$.System.Diagnostics.Debug.Assert$2(this.hashtable !== null, "hashtable != null");
                        this.hashtable.Add(key, value);
                    }
                    else 
                    {
                        this.list.Add(key, value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475098641)
            
            //--TRIMMABLE-BOUNDARY-START(34360000529)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    /*Hashtable*/ let cachedHashtable = this.hashtable;
                    this.hashtable = null;
                    cachedHashtable.Clear();
                }
                if (this.list !== null)
                {
                    /*ListDictionary*/ let cachedList = this.list;
                    this.list = null;
                    cachedList.Clear();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360000529)
            
            //--TRIMMABLE-BOUNDARY-START(38654967825)
            /*bool */ Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ListDictionary?*/ let cachedList = this.list;
                if (this.hashtable !== null)
                {
                    return this.hashtable.Contains(key);
                }
                else if (cachedList !== null)
                {
                    return cachedList.Contains(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38654967825)
            
            //--TRIMMABLE-BOUNDARY-START(42949935121)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949935121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    this.hashtable.CopyTo(array, index);
                }
                else 
                {
                    this.List.CopyTo(array, index);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949935121)
            
            //--TRIMMABLE-BOUNDARY-START(137439215633)
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439215633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    return this.hashtable.GetEnumerator();
                }
                this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                return this.list.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(137439215633)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 193273790481, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    return this.hashtable.GetEnumerator();
                }
                this.list ??= new $.$scs.System.Collections.Specialized.ListDictionary().$ctor$2(this.caseInsensitive ? $.$$.System.StringComparer.OrdinalIgnoreCase : null);
                return this.list.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 193273790481, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(176093921297)
            /*void */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.hashtable !== null)
                {
                    this.hashtable.Remove(key);
                }
                else if (this.list !== null)
                {
                    this.list.Remove(key);
                }
                else 
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176093921297)
            
            //--TRIMMABLE-BOUNDARY-START(38717095937)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38717095937)
            
            //--TRIMMABLE-BOUNDARY-START(85961736193)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85961736193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85961736193)
            
            //--TRIMMABLE-BOUNDARY-START(47307030529)
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73076834305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(47307030529)
            
            //--TRIMMABLE-BOUNDARY-START(55896965121)
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94551670785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(55896965121)
            
            //--TRIMMABLE-BOUNDARY-START(12947292161)
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12947292161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12947292161)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(8652324865)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652324865)
            
            //--TRIMMABLE-BOUNDARY-START(30127161345)
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68781867009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30127161345)
            
            //--TRIMMABLE-BOUNDARY-START(21537226753)
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64486899713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(21537226753)
            
            //--TRIMMABLE-BOUNDARY-START(60191932417)
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60191932417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60191932417)
            
            //--TRIMMABLE-BOUNDARY-START(77371801601)
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77371801601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(77371801601)
            
            //--TRIMMABLE-BOUNDARY-START(4357226497)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357226497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(34421997569)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43011932161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34421997569)
            
            //--TRIMMABLE-BOUNDARY-START(25832062977)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38716964865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832062977)
            
            static $h = 262161;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(197568757777),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784509969,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184683855889,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 262161,
      "h": 197568757777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568757777),
//--TRIMMABLE-BOUNDARY-START(171798954001),
    {
      "p": 393233,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379153,
        "f": 50331650
      },
      "n": "List",
      "d": 262161,
      "h": 171798954001,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(171798954001),
//--TRIMMABLE-BOUNDARY-START(47244902417),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771601,
        "f": 50331649
      },
      "n": "Count",
      "d": 262161,
      "h": 47244902417,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244902417),
//--TRIMMABLE-BOUNDARY-START(163209019409),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444561,
        "f": 50331649
      },
      "n": "Keys",
      "o": "@$1",
      "d": 262161,
      "h": 163209019409,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209019409),
//--TRIMMABLE-BOUNDARY-START(154619084817),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640785,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 262161,
      "h": 154619084817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619084817),
//--TRIMMABLE-BOUNDARY-START(150324117521),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706193,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 262161,
      "h": 150324117521,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324117521),
//--TRIMMABLE-BOUNDARY-START(158914052113),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194575377,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 262161,
      "h": 158914052113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914052113),
//--TRIMMABLE-BOUNDARY-START(188978823185),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554313745,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 262161,
      "h": 188978823185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188978823185),
//--TRIMMABLE-BOUNDARY-START(201863725073),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144248337,
        "f": 50331649
      },
      "n": "Values",
      "d": 262161,
      "h": 201863725073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201863725073)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065033233),
    {
      "r": 65537,
      "n": "ChangeOver",
      "d": 262161,
      "h": 30065033233,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(30065033233),
//--TRIMMABLE-BOUNDARY-START(21475098641),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 262161,
      "h": 21475098641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475098641),
//--TRIMMABLE-BOUNDARY-START(34360000529),
    {
      "r": 65537,
      "n": "Clear",
      "d": 262161,
      "h": 34360000529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360000529),
//--TRIMMABLE-BOUNDARY-START(38654967825),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 262161,
      "h": 38654967825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654967825),
//--TRIMMABLE-BOUNDARY-START(42949935121),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 262161,
      "h": 42949935121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949935121),
//--TRIMMABLE-BOUNDARY-START(137439215633),
    {
      "r": 62455809,
      "n": "GetEnumerator",
      "d": 262161,
      "h": 137439215633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439215633),
//--TRIMMABLE-BOUNDARY-START(176093921297),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 262161,
      "h": 176093921297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176093921297)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539869713),
    {
      "t": 655361,
      "n": "CutoverPoint",
      "d": 262161,
      "h": 51539869713,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(51539869713),
//--TRIMMABLE-BOUNDARY-START(146029150225),
    {
      "t": 655361,
      "n": "InitialHashtableSize",
      "d": 262161,
      "h": 146029150225,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146029150225),
//--TRIMMABLE-BOUNDARY-START(55834837009),
    {
      "t": 655361,
      "n": "FixedSizeCutoverPoint",
      "d": 262161,
      "h": 55834837009,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55834837009),
//--TRIMMABLE-BOUNDARY-START(167503986705),
    {
      "t": 393233,
      "n": "list",
      "d": 262161,
      "h": 167503986705,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167503986705),
//--TRIMMABLE-BOUNDARY-START(141734182929),
    {
      "t": 61800449,
      "n": "hashtable",
      "d": 262161,
      "h": 141734182929,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141734182929),
//--TRIMMABLE-BOUNDARY-START(25770065937),
    {
      "t": 262145,
      "n": "caseInsensitive",
      "d": 262161,
      "h": 25770065937,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770065937)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229457),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262161,
      "h": 4295229457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229457),
//--TRIMMABLE-BOUNDARY-START(8590196753),
    {
      "p": [
        {
          "n": "initialSize",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262161,
      "h": 8590196753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196753),
//--TRIMMABLE-BOUNDARY-START(12885164049),
    {
      "p": [
        {
          "n": "caseInsensitive",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262161,
      "h": 12885164049,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164049),
//--TRIMMABLE-BOUNDARY-START(17180131345),
    {
      "p": [
        {
          "n": "initialSize",
          "p": 655361
        },
        {
          "n": "caseInsensitive",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262161,
      "h": 17180131345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131345)
  ],
  "i": [62390273,62259201,62521345
  ],
  "h": 262161,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.HybridDictionary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262161)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245201)
        $asm.$cls("$scs.System.Collections.Specialized.StringCollection", ($self) => class StringCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(34360983569)
            /*ArrayList*/ data = null;
            //--TRIMMABLE-BOUNDARY-END(34360983569)
            
            //--TRIMMABLE-BOUNDARY-START(201864708113)
            /*string?*/ get_Item(/*int*/ index)
            {
                return ($.$cast(this.data.get_Item(index), $.$$.System.String));
            }
            /*void*/ set_Item(/*int*/ index, /*string?*/ value)
            {
                this.data.set_Item(index, value);
            }
            //--TRIMMABLE-BOUNDARY-END(201864708113)
            
            //--TRIMMABLE-BOUNDARY-START(30066016273)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30066016273)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 180389871633, 55897423873)
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 180389871633, 55897423873)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 176094904337, 51602456577)
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030133265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 176094904337, 51602456577)
            
            //--TRIMMABLE-BOUNDARY-START(8591179793)
            /*int */ Add(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.Add(value);
            }
            //--TRIMMABLE-BOUNDARY-END(8591179793)
            
            //--TRIMMABLE-BOUNDARY-START(12886147089)
            /*void */ AddRange(/*string?[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886147089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this.data.AddRange(value);
            }
            //--TRIMMABLE-BOUNDARY-END(12886147089)
            
            //--TRIMMABLE-BOUNDARY-START(17181114385)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(17181114385)
            
            //--TRIMMABLE-BOUNDARY-START(21476081681)
            /*bool */ Contains(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.Contains(value);
            }
            //--TRIMMABLE-BOUNDARY-END(21476081681)
            
            //--TRIMMABLE-BOUNDARY-START(25771048977)
            /*void */ CopyTo(/*string?[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771048977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(25771048977)
            
            //--TRIMMABLE-BOUNDARY-START(81605623825)
            /*StringEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.StringEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(81605623825)
            
            //--TRIMMABLE-BOUNDARY-START(85900591121)
            /*int */ IndexOf(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.IndexOf$2(value);
            }
            //--TRIMMABLE-BOUNDARY-END(85900591121)
            
            //--TRIMMABLE-BOUNDARY-START(90195558417)
            /*void */ Insert(/*int*/ index, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195558417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.Insert(index, value);
            }
            //--TRIMMABLE-BOUNDARY-END(90195558417)
            
            //--TRIMMABLE-BOUNDARY-START(94490525713)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(94490525713)
            
            //--TRIMMABLE-BOUNDARY-START(98785493009)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(98785493009)
            
            //--TRIMMABLE-BOUNDARY-START(103080460305)
            /*void */ Remove(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.Remove(value);
            }
            //--TRIMMABLE-BOUNDARY-END(103080460305)
            
            //--TRIMMABLE-BOUNDARY-START(107375427601)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375427601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.RemoveAt(index);
            }
            //--TRIMMABLE-BOUNDARY-END(107375427601)
            
            //--TRIMMABLE-BOUNDARY-START(120260329489)
            /*object */ get SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(120260329489)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 197569740817, 77372260353)
            //--TRIMMABLE-BOUNDARY-START(77372260353)
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                this.set_Item(index, $.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(77372260353)
            
            //--TRIMMABLE-BOUNDARY-END(ALL, 197569740817, 77372260353)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 133145231377, 4357816321)
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145231377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add($.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 133145231377, 4357816321)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 137440198673, 12947750913)
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains($.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 137440198673, 12947750913)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 167504969745, 43012521985)
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504969745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOf($.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 167504969745, 43012521985)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 171799937041, 47307489281)
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Insert(index, $.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 171799937041, 47307489281)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 184684838929, 60192391169)
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684838929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Remove($.$cast(value, $.$$.System.String));
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 184684838929, 60192391169)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124555296785, 4357226497)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555296785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.data.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124555296785, 4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 128850264081, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.data.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 128850264081, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(8652783617)
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652783617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652783617)
            
            //--TRIMMABLE-BOUNDARY-START(64487358465)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64487358465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64487358465)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(34421997569)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43011932161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34421997569)
            
            //--TRIMMABLE-BOUNDARY-START(25832062977)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38716964865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832062977)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(34360983569)
                this.data = new $.$$.System.Collections.ArrayList().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(34360983569)
                
            }
            static $h = 1245201;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(201864708113),
    {
      "p": 1310721,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720721937,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965362193,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 1245201,
      "h": 201864708113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864708113),
//--TRIMMABLE-BOUNDARY-START(30066016273),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950918161,
        "f": 50331649
      },
      "n": "Count",
      "d": 1245201,
      "h": 30066016273,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066016273),
//--TRIMMABLE-BOUNDARY-START(ALL, 180389871633, 55897423873),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620067857,
        "f": 50331650
      },
      "n": "{62849025}.IsReadOnly",
      "o": "System$Collections$IList$IsReadOnly",
      "d": 1245201,
      "h": 180389871633,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 180389871633, 55897423873),
//--TRIMMABLE-BOUNDARY-START(ALL, 176094904337, 51602456577),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030133265,
        "f": 50331650
      },
      "n": "{62849025}.IsFixedSize",
      "o": "System$Collections$IList$IsFixedSize",
      "d": 1245201,
      "h": 176094904337,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 176094904337, 51602456577),
//--TRIMMABLE-BOUNDARY-START(94490525713),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540852753,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1245201,
      "h": 94490525713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490525713),
//--TRIMMABLE-BOUNDARY-START(98785493009),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130787345,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 1245201,
      "h": 98785493009,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785493009),
//--TRIMMABLE-BOUNDARY-START(120260329489),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310656529,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 1245201,
      "h": 120260329489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260329489),
//--TRIMMABLE-BOUNDARY-START(ALL, 197569740817, 77372260353),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210002449,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274773521,
        "f": 83886082
      },
      "n": "{62849025}.this[]",
      "o": "System$Collections$IList$Item",
      "d": 1245201,
      "h": 197569740817,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 197569740817, 77372260353)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591179793),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "d": 1245201,
      "h": 8591179793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179793),
//--TRIMMABLE-BOUNDARY-START(12886147089),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": "AddRange",
      "d": 1245201,
      "h": 12886147089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147089),
//--TRIMMABLE-BOUNDARY-START(17181114385),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1245201,
      "h": 17181114385,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114385),
//--TRIMMABLE-BOUNDARY-START(21476081681),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Contains",
      "d": 1245201,
      "h": 21476081681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476081681),
//--TRIMMABLE-BOUNDARY-START(25771048977),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$$.System.String).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1245201,
      "h": 25771048977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771048977),
//--TRIMMABLE-BOUNDARY-START(81605623825),
    {
      "r": 1376273,
      "n": "GetEnumerator",
      "d": 1245201,
      "h": 81605623825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605623825),
//--TRIMMABLE-BOUNDARY-START(85900591121),
    {
      "r": 655361,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "IndexOf",
      "d": 1245201,
      "h": 85900591121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900591121),
//--TRIMMABLE-BOUNDARY-START(90195558417),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "d": 1245201,
      "h": 90195558417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195558417),
//--TRIMMABLE-BOUNDARY-START(103080460305),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "d": 1245201,
      "h": 103080460305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103080460305),
//--TRIMMABLE-BOUNDARY-START(107375427601),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1245201,
      "h": 107375427601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107375427601)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360983569),
    {
      "t": 54329345,
      "n": "data",
      "d": 1245201,
      "h": 34360983569,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360983569)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212497),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245201,
      "h": 4296212497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212497)
  ],
  "i": [62849025,62259201,62521345
  ],
  "h": 1245201,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.StringCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245201)
        
        
        //--TRIMMABLE-BOUNDARY-START(393233)
        $asm.$cls("$scs.System.Collections.Specialized.ListDictionary", ($self) => class ListDictionary extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(120259477521)
            /*DictionaryNode?*/ head = null;
            //--TRIMMABLE-BOUNDARY-END(120259477521)
            
            //--TRIMMABLE-BOUNDARY-START(180389019665)
            /*int*/ version = 0;
            //--TRIMMABLE-BOUNDARY-END(180389019665)
            
            //--TRIMMABLE-BOUNDARY-START(34360131601)
            /*int*/ count = 0;
            //--TRIMMABLE-BOUNDARY-END(34360131601)
            
            //--TRIMMABLE-BOUNDARY-START(21475229713)
            /*IComparer?*/ comparer = null;
            //--TRIMMABLE-BOUNDARY-END(21475229713)
            
            //--TRIMMABLE-BOUNDARY-START(4295360529)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360529);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360529)
            
            //--TRIMMABLE-BOUNDARY-START(8590327825)
            $ctor$2(/*IComparer?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327825);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.comparer = comparer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327825)
            
            //--TRIMMABLE-BOUNDARY-START(171799085073)
            /*object?*/ get_Item(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*DictionaryNode?*/ let node = this.head;
                if (this.comparer === null)
                {
                    while(node !== null)
                    {
                        /*object*/ let oldKey = node.key;
                        if ($.$$.System.Object.Equals$1.call(oldKey, key))
                        {
                            return node.value;
                        }
                        node = node.next;
                    }
                }
                else 
                {
                    while(node !== null)
                    {
                        /*object*/ let oldKey = node.key;
                        if (this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                        {
                            return node.value;
                        }
                        node = node.next;
                    }
                }
                return null;
            }
            /*void*/ set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                /*DictionaryNode?*/ let node;
                for(node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        break;
                    }
                    last = node;
                }
                if (node !== null)
                {
                    node.value = value;
                    return;
                }
                /*DictionaryNode*/ let newNode = new $.$scs.System.Collections.Specialized.ListDictionary.DictionaryNode().$ctor$1();
                newNode.key = key;
                newNode.value = value;
                if (last !== null)
                {
                    last.next = newNode;
                }
                else 
                {
                    this.head = newNode;
                }
                this.count++;
            }
            //--TRIMMABLE-BOUNDARY-END(171799085073)
            
            //--TRIMMABLE-BOUNDARY-START(38655098897)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.count;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098897)
            
            //--TRIMMABLE-BOUNDARY-START(137439346705)
            /*ICollection */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection().$ctor$1(this, true);
            }
            //--TRIMMABLE-BOUNDARY-END(137439346705)
            
            //--TRIMMABLE-BOUNDARY-START(128849412113)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719869969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(128849412113)
            
            //--TRIMMABLE-BOUNDARY-START(124554444817)
            /*bool */ get IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(124554444817)
            
            //--TRIMMABLE-BOUNDARY-START(133144379409)
            /*bool */ get IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(133144379409)
            
            //--TRIMMABLE-BOUNDARY-START(163209150481)
            /*object */ get SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(163209150481)
            
            //--TRIMMABLE-BOUNDARY-START(176094052369)
            /*ICollection */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669542929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection().$ctor$1(this, false);
            }
            //--TRIMMABLE-BOUNDARY-END(176094052369)
            
            //--TRIMMABLE-BOUNDARY-START(12885295121)
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Format$6($.$scs.System.SR.Argument_AddingDuplicate, key));
                    }
                    last = node;
                }
                /*DictionaryNode*/ let newNode = new $.$scs.System.Collections.Specialized.ListDictionary.DictionaryNode().$ctor$1();
                newNode.key = key;
                newNode.value = value;
                if (last !== null)
                {
                    last.next = newNode;
                }
                else 
                {
                    this.head = newNode;
                }
                this.count++;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295121)
            
            //--TRIMMABLE-BOUNDARY-START(17180262417)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.count = 0;
                this.head = null;
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262417)
            
            //--TRIMMABLE-BOUNDARY-START(25770197009)
            /*bool */ Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(25770197009)
            
            //--TRIMMABLE-BOUNDARY-START(30065164305)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                for(/*DictionaryNode?*/ let node = this.head; node !== null; node = node.next)
                {
                    array.SetValue$2(new $.$$.System.Collections.DictionaryEntry().$ctor$3(node.key, node.value), index);
                    index++;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065164305)
            
            //--TRIMMABLE-BOUNDARY-START(115964510225)
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(115964510225)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 167504117777, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504117777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 167504117777, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(150324248593)
            /*void */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                this.version++;
                /*DictionaryNode?*/ let last = null;
                /*DictionaryNode?*/ let node;
                for(node = this.head; node !== null; node = node.next)
                {
                    /*object*/ let oldKey = node.key;
                    if ((this.comparer === null) ? $.$$.System.Object.Equals$1.call(oldKey, key) : this.comparer.System$Collections$IComparer$Compare(oldKey, key) === 0)
                    {
                        break;
                    }
                    last = node;
                }
                if (node === null)
                {
                    return;
                }
                if (node === this.head)
                {
                    this.head = node.next;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(last !== null, "last != null");
                    last.next = node.next;
                }
                this.count--;
            }
            //--TRIMMABLE-BOUNDARY-END(150324248593)
            
            //--TRIMMABLE-BOUNDARY-START(524305)
            static $_NodeEnumerator;
            static get NodeEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_NodeEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeEnumerator", ($self) => class NodeEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590458897)
                    /*ListDictionary*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(8590458897)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295491601)
                    /*DictionaryNode?*/ _current = null;
                    //--TRIMMABLE-BOUNDARY-END(4295491601)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180393489)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(17180393489)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885426193)
                    /*bool*/ _start = false;
                    //--TRIMMABLE-BOUNDARY-END(12885426193)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475360785)
                    $ctor$1(/*ListDictionary*/ list)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475360785);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._list = list;
                            this._version = list.version;
                            this._start = true;
                            this._current = null;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475360785)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770328081)
                    /*object */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655229969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770328081)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065295377)
                    /*DictionaryEntry */ get Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245164561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3(this._current.key, this._current.value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065295377)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720001041)
                    /*object */ get Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55835099153);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._current.key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720001041)
                    
                    //--TRIMMABLE-BOUNDARY-START(81604902929)
                    /*object? */ get Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425033745);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return this._current.value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81604902929)
                    
                    //--TRIMMABLE-BOUNDARY-START(73014968337)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014968337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._start)
                        {
                            this._current = this._list.head;
                            this._start = false;
                        }
                        else if (this._current !== null)
                        {
                            this._current = this._current.next;
                        }
                        return (this._current !== null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(73014968337)
                    
                    //--TRIMMABLE-BOUNDARY-START(77309935633)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77309935633);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._start = true;
                        this._current = null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(77309935633)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537292289)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34422194177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537292289)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127226881)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717161473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127226881)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947357697)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357423105);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947357697)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947554305)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947554305)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 524305;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770328081),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655229969,
        "f": 50331649
      },
      "n": "Current",
      "d": 524305,
      "h": 25770328081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770328081),
//--TRIMMABLE-BOUNDARY-START(30065295377),
    {
      "p": 56557569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164561,
        "f": 50331649
      },
      "n": "Entry",
      "d": 524305,
      "h": 30065295377,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065295377),
//--TRIMMABLE-BOUNDARY-START(68720001041),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099153,
        "f": 50331649
      },
      "n": "Key",
      "d": 524305,
      "h": 68720001041,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001041),
//--TRIMMABLE-BOUNDARY-START(81604902929),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425033745,
        "f": 50331649
      },
      "n": "Value",
      "d": 524305,
      "h": 81604902929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604902929)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73014968337),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 524305,
      "h": 73014968337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014968337),
//--TRIMMABLE-BOUNDARY-START(77309935633),
    {
      "r": 65537,
      "n": "Reset",
      "d": 524305,
      "h": 77309935633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309935633)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590458897),
    {
      "t": 393233,
      "n": "_list",
      "d": 524305,
      "h": 8590458897,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458897),
//--TRIMMABLE-BOUNDARY-START(4295491601),
    {
      "t": 458769,
      "n": "_current",
      "d": 524305,
      "h": 4295491601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491601),
//--TRIMMABLE-BOUNDARY-START(17180393489),
    {
      "t": 655361,
      "n": "_version",
      "d": 524305,
      "h": 17180393489,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393489),
//--TRIMMABLE-BOUNDARY-START(12885426193),
    {
      "t": 262145,
      "n": "_start",
      "d": 524305,
      "h": 12885426193,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426193)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475360785),
    {
      "p": [
        {
          "n": "list",
          "p": 393233
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524305,
      "h": 21475360785,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360785)
  ],
  "i": [62455809,62652417
  ],
  "d": 393233,
  "h": 524305
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeEnumerator`; }
                }, $cls, ($v) => $cls.$_NodeEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(524305)
            
            //--TRIMMABLE-BOUNDARY-START(589841)
            static $_NodeKeyValueCollection;
            static get NodeKeyValueCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_NodeKeyValueCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection", ($self) => class NodeKeyValueCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590524433)
                    /*ListDictionary*/ _list = null;
                    //--TRIMMABLE-BOUNDARY-END(8590524433)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557137)
                    /*bool*/ _isKeys = false;
                    //--TRIMMABLE-BOUNDARY-END(4295557137)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885491729)
                    $ctor$1(/*ListDictionary*/ list, /*bool*/ isKeys)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885491729);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._list = list;
                            this._isKeys = isKeys;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885491729)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 21475426321, 4357226497)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475426321);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        for(/*DictionaryNode?*/ let node = this._list.head; node !== null; node = node.next)
                        {
                            array.SetValue$2(this._isKeys ? node.key : node.value, index);
                            index++;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 21475426321, 4357226497)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 25770393617, 8652193793)
                    /*int */ get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360328209);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let count = 0;
                        for(/*DictionaryNode?*/ let node = this._list.head; node !== null; node = node.next)
                        {
                            count++;
                        }
                        return count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 25770393617, 8652193793)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 55835164689, 38716964865)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950262801);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 55835164689, 38716964865)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 60130131985, 43011932161)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540197393);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._list.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 60130131985, 43011932161)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 64425099281, 4357488641)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425099281);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator().$ctor$1(this._list, this._isKeys);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 64425099281, 4357488641)
                    
                    //--TRIMMABLE-BOUNDARY-START(655377)
                    static $_NodeKeyValueEnumerator;
                    static get NodeKeyValueEnumerator()
                    {
                        let $cls = $.$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection;
                        return $cls.$_NodeKeyValueEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator", ($self) => class NodeKeyValueEnumerator extends $.$$.System.Object
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885557265)
                            /*ListDictionary*/ _list = null;
                            //--TRIMMABLE-BOUNDARY-END(12885557265)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295622673)
                            /*DictionaryNode?*/ _current = null;
                            //--TRIMMABLE-BOUNDARY-END(4295622673)
                            
                            //--TRIMMABLE-BOUNDARY-START(21475491857)
                            /*int*/ _version = 0;
                            //--TRIMMABLE-BOUNDARY-END(21475491857)
                            
                            //--TRIMMABLE-BOUNDARY-START(8590589969)
                            /*bool*/ _isKeys = false;
                            //--TRIMMABLE-BOUNDARY-END(8590589969)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180524561)
                            /*bool*/ _start = false;
                            //--TRIMMABLE-BOUNDARY-END(17180524561)
                            
                            //--TRIMMABLE-BOUNDARY-START(25770459153)
                            $ctor$1(/*ListDictionary*/ list, /*bool*/ isKeys)
                            {
                                super.$ctor();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(25770459153);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._list = list;
                                    this._isKeys = isKeys;
                                    this._version = list.version;
                                    this._start = true;
                                    this._current = null;
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(25770459153)
                            
                            //--TRIMMABLE-BOUNDARY-START(30065426449)
                            /*object? */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(38655361041);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._current === null)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return this._isKeys ? this._current.key : this._current.value;
                            }
                            //--TRIMMABLE-BOUNDARY-END(30065426449)
                            
                            //--TRIMMABLE-BOUNDARY-START(42950328337)
                            /*bool */ MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(42950328337);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._version !== this._list.version)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                                }
                                if (this._start)
                                {
                                    this._current = this._list.head;
                                    this._start = false;
                                }
                                else if (this._current !== null)
                                {
                                    this._current = this._current.next;
                                }
                                return (this._current !== null);
                            }
                            //--TRIMMABLE-BOUNDARY-END(42950328337)
                            
                            //--TRIMMABLE-BOUNDARY-START(47245295633)
                            /*void */ Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47245295633);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._version !== this._list.version)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.InvalidOperation_EnumFailedVersion);
                                }
                                this._start = true;
                                this._current = null;
                            }
                            //--TRIMMABLE-BOUNDARY-END(47245295633)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242521601)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242521601);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242521601)
                            
                            //--TRIMMABLE-BOUNDARY-START(12947554305)
                            //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                            get System$Collections$IEnumerator$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4357619713);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12947554305)
                            
                            //--TRIMMABLE-BOUNDARY-START(21537488897)
                            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                            System$Collections$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21537488897);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Reset(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(21537488897)
                            
                            static $h = 655377;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065426449),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361041,
        "f": 50331649
      },
      "n": "Current",
      "d": 655377,
      "h": 30065426449,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065426449)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950328337),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 655377,
      "h": 42950328337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950328337),
//--TRIMMABLE-BOUNDARY-START(47245295633),
    {
      "r": 65537,
      "n": "Reset",
      "d": 655377,
      "h": 47245295633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295633)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885557265),
    {
      "t": 393233,
      "n": "_list",
      "d": 655377,
      "h": 12885557265,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885557265),
//--TRIMMABLE-BOUNDARY-START(4295622673),
    {
      "t": 458769,
      "n": "_current",
      "d": 655377,
      "h": 4295622673,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622673),
//--TRIMMABLE-BOUNDARY-START(21475491857),
    {
      "t": 655361,
      "n": "_version",
      "d": 655377,
      "h": 21475491857,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475491857),
//--TRIMMABLE-BOUNDARY-START(8590589969),
    {
      "t": 262145,
      "n": "_isKeys",
      "d": 655377,
      "h": 8590589969,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590589969),
//--TRIMMABLE-BOUNDARY-START(17180524561),
    {
      "t": 262145,
      "n": "_start",
      "d": 655377,
      "h": 17180524561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180524561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770459153),
    {
      "p": [
        {
          "n": "list",
          "p": 393233
        },
        {
          "n": "isKeys",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655377,
      "h": 25770459153,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459153)
  ],
  "i": [62652417
  ],
  "d": 589841,
  "h": 655377
}; }
                            static get $b() { return $.$$.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeKeyValueCollection.NodeKeyValueEnumerator`; }
                        }, $cls, ($v) => $cls.$_NodeKeyValueEnumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(655377)
                    
                    static $h = 589841;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25770393617, 8652193793),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328209,
        "f": 50331650
      },
      "n": "{62259201}.Count",
      "o": "System$Collections$ICollection$Count",
      "d": 589841,
      "h": 25770393617,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770393617, 8652193793),
//--TRIMMABLE-BOUNDARY-START(ALL, 55835164689, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262801,
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 589841,
      "h": 55835164689,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 55835164689, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 60130131985, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197393,
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 589841,
      "h": 60130131985,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60130131985, 43011932161)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524433),
    {
      "t": 393233,
      "n": "_list",
      "d": 589841,
      "h": 8590524433,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524433),
//--TRIMMABLE-BOUNDARY-START(4295557137),
    {
      "t": 262145,
      "n": "_isKeys",
      "d": 589841,
      "h": 4295557137,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557137)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491729),
    {
      "p": [
        {
          "n": "list",
          "p": 393233
        },
        {
          "n": "isKeys",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589841,
      "h": 12885491729,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491729)
  ],
  "i": [62259201,62521345
  ],
  "j": [655377
  ],
  "d": 393233,
  "h": 589841
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.NodeKeyValueCollection`; }
                }, $cls, ($v) => $cls.$_NodeKeyValueCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589841)
            
            //--TRIMMABLE-BOUNDARY-START(458769)
            static $_DictionaryNode;
            static get DictionaryNode()
            {
                let $cls = $.$scs.System.Collections.Specialized.ListDictionary;
                return $cls.$_DictionaryNode ??= $asm.$ncls("$scs.System.Collections.Specialized.ListDictionary.DictionaryNode", ($self) => class DictionaryNode extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8590393361)
                    /*object*/ key = null;
                    //--TRIMMABLE-BOUNDARY-END(8590393361)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180327953)
                    /*object?*/ value = null;
                    //--TRIMMABLE-BOUNDARY-END(17180327953)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885360657)
                    /*DictionaryNode?*/ next = null;
                    //--TRIMMABLE-BOUNDARY-END(12885360657)
                    
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8590393361)
                        this.key = null;
                        //--TRIMMABLE-BOUNDARY-END(8590393361)
                        
                    }
                    static $h = 458769;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590393361),
    {
      "t": 131073,
      "n": "key",
      "d": 458769,
      "h": 8590393361,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(8590393361),
//--TRIMMABLE-BOUNDARY-START(17180327953),
    {
      "t": 131073,
      "n": "value",
      "d": 458769,
      "h": 17180327953,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(17180327953),
//--TRIMMABLE-BOUNDARY-START(12885360657),
    {
      "t": 458769,
      "n": "next",
      "d": 458769,
      "h": 12885360657,
      "f": 4194305
    },
//--TRIMMABLE-BOUNDARY-END(12885360657)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426065),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458769,
      "h": 4295426065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426065)
  ],
  "d": 393233,
  "h": 458769,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Specialized.ListDictionary.DictionaryNode`; }
                }, $cls, ($v) => $cls.$_DictionaryNode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(458769)
            
            //--TRIMMABLE-BOUNDARY-START(38717095937)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38717095937)
            
            //--TRIMMABLE-BOUNDARY-START(85961736193)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85961736193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85961736193)
            
            //--TRIMMABLE-BOUNDARY-START(47307030529)
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73076834305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(47307030529)
            
            //--TRIMMABLE-BOUNDARY-START(55896965121)
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94551670785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(55896965121)
            
            //--TRIMMABLE-BOUNDARY-START(12947292161)
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12947292161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12947292161)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(8652324865)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652324865)
            
            //--TRIMMABLE-BOUNDARY-START(30127161345)
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68781867009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30127161345)
            
            //--TRIMMABLE-BOUNDARY-START(21537226753)
            //Generated interface implemetation for System.Collections.IDictionary.IsFixedSize.get
            get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64486899713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsFixedSize;
            }
            //--TRIMMABLE-BOUNDARY-END(21537226753)
            
            //--TRIMMABLE-BOUNDARY-START(60191932417)
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60191932417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60191932417)
            
            //--TRIMMABLE-BOUNDARY-START(77371801601)
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77371801601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(77371801601)
            
            //--TRIMMABLE-BOUNDARY-START(4357226497)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357226497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(34421997569)
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43011932161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(34421997569)
            
            //--TRIMMABLE-BOUNDARY-START(25832062977)
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38716964865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSynchronized;
            }
            //--TRIMMABLE-BOUNDARY-END(25832062977)
            
            static $h = 393233;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(171799085073),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899739153,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914183185,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 393233,
      "h": 171799085073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799085073),
//--TRIMMABLE-BOUNDARY-START(38655098897),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000785,
        "f": 50331649
      },
      "n": "Count",
      "d": 393233,
      "h": 38655098897,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655098897),
//--TRIMMABLE-BOUNDARY-START(137439346705),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489673745,
        "f": 50331649
      },
      "n": "Keys",
      "o": "@$1",
      "d": 393233,
      "h": 137439346705,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439346705),
//--TRIMMABLE-BOUNDARY-START(128849412113),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719869969,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 393233,
      "h": 128849412113,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849412113),
//--TRIMMABLE-BOUNDARY-START(124554444817),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129935377,
        "f": 50331649
      },
      "n": "IsFixedSize",
      "d": 393233,
      "h": 124554444817,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554444817),
//--TRIMMABLE-BOUNDARY-START(133144379409),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309804561,
        "f": 50331649
      },
      "n": "IsSynchronized",
      "d": 393233,
      "h": 133144379409,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144379409),
//--TRIMMABLE-BOUNDARY-START(163209150481),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079608337,
        "f": 50331649
      },
      "n": "SyncRoot",
      "d": 393233,
      "h": 163209150481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209150481),
//--TRIMMABLE-BOUNDARY-START(176094052369),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669542929,
        "f": 50331649
      },
      "n": "Values",
      "d": 393233,
      "h": 176094052369,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094052369)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295121),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 393233,
      "h": 12885295121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295121),
//--TRIMMABLE-BOUNDARY-START(17180262417),
    {
      "r": 65537,
      "n": "Clear",
      "d": 393233,
      "h": 17180262417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262417),
//--TRIMMABLE-BOUNDARY-START(25770197009),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 393233,
      "h": 25770197009,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770197009),
//--TRIMMABLE-BOUNDARY-START(30065164305),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 393233,
      "h": 30065164305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065164305),
//--TRIMMABLE-BOUNDARY-START(115964510225),
    {
      "r": 62455809,
      "n": "GetEnumerator",
      "d": 393233,
      "h": 115964510225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(115964510225),
//--TRIMMABLE-BOUNDARY-START(150324248593),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 393233,
      "h": 150324248593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324248593)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(120259477521),
    {
      "t": 458769,
      "n": "head",
      "d": 393233,
      "h": 120259477521,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(120259477521),
//--TRIMMABLE-BOUNDARY-START(180389019665),
    {
      "t": 655361,
      "n": "version",
      "d": 393233,
      "h": 180389019665,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(180389019665),
//--TRIMMABLE-BOUNDARY-START(34360131601),
    {
      "t": 655361,
      "n": "count",
      "d": 393233,
      "h": 34360131601,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360131601),
//--TRIMMABLE-BOUNDARY-START(21475229713),
    {
      "t": 62324737,
      "n": "comparer",
      "d": 393233,
      "h": 21475229713,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475229713)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360529),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393233,
      "h": 4295360529,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360529),
//--TRIMMABLE-BOUNDARY-START(8590327825),
    {
      "p": [
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393233,
      "h": 8590327825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327825)
  ],
  "i": [62390273,62259201,62521345
  ],
  "j": [524305,589841,458769
  ],
  "h": 393233,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Specialized.ListDictionary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393233)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048593)
        $asm.$cls("$scs.System.Collections.Specialized.OrderedDictionary", ($self) => class OrderedDictionary extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885950481)
            /*ArrayList?*/ _objectsArray = null;
            //--TRIMMABLE-BOUNDARY-END(12885950481)
            
            //--TRIMMABLE-BOUNDARY-START(17180917777)
            /*Hashtable?*/ _objectsTable = null;
            //--TRIMMABLE-BOUNDARY-END(17180917777)
            
            //--TRIMMABLE-BOUNDARY-START(8590983185)
            /*int*/ _initialCapacity = 0;
            //--TRIMMABLE-BOUNDARY-END(8590983185)
            
            //--TRIMMABLE-BOUNDARY-START(4296015889)
            /*IEqualityComparer?*/ _comparer = null;
            //--TRIMMABLE-BOUNDARY-END(4296015889)
            
            //--TRIMMABLE-BOUNDARY-START(21475885073)
            /*bool*/ _readOnly = false;
            //--TRIMMABLE-BOUNDARY-END(21475885073)
            
            //--TRIMMABLE-BOUNDARY-START(25770852369)
            /*SerializationInfo?*/ _siInfo = null;
            //--TRIMMABLE-BOUNDARY-END(25770852369)
            
            //--TRIMMABLE-BOUNDARY-START(171799740433)
            /*string*/ static KeyComparerName = null;
            //--TRIMMABLE-BOUNDARY-END(171799740433)
            
            //--TRIMMABLE-BOUNDARY-START(60130590737)
            /*string*/ static ArrayListName = null;
            //--TRIMMABLE-BOUNDARY-END(60130590737)
            
            //--TRIMMABLE-BOUNDARY-START(193274576913)
            /*string*/ static ReadOnlyName = null;
            //--TRIMMABLE-BOUNDARY-END(193274576913)
            
            //--TRIMMABLE-BOUNDARY-START(158914838545)
            /*string*/ static InitCapacityName = null;
            //--TRIMMABLE-BOUNDARY-END(158914838545)
            
            //--TRIMMABLE-BOUNDARY-START(30065819665)
            $ctor$1()
            {
                this.$ctor$4(0);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065819665);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065819665)
            
            //--TRIMMABLE-BOUNDARY-START(34360786961)
            $ctor$4(/*int*/ capacity)
            {
                this.$ctor$3(capacity, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360786961);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360786961)
            
            //--TRIMMABLE-BOUNDARY-START(38655754257)
            $ctor$2(/*IEqualityComparer?*/ comparer)
            {
                this.$ctor$3(0, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655754257);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754257)
            
            //--TRIMMABLE-BOUNDARY-START(42950721553)
            $ctor$3(/*int*/ capacity, /*IEqualityComparer?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950721553);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._initialCapacity = capacity;
                    this._comparer = comparer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950721553)
            
            //--TRIMMABLE-BOUNDARY-START(47245688849)
            $ctor$6(/*OrderedDictionary*/ dictionary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245688849);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(dictionary !== null, "dictionary != null");
                    this._readOnly = true;
                    this._objectsArray = dictionary._objectsArray;
                    this._objectsTable = dictionary._objectsTable;
                    this._comparer = dictionary._comparer;
                    this._initialCapacity = dictionary._initialCapacity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245688849)
            
            //--TRIMMABLE-BOUNDARY-START(51540656145)
            $ctor$5(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540656145);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._siInfo = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540656145)
            
            //--TRIMMABLE-BOUNDARY-START(81605427217)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._objectsArray === null)
                {
                    return 0;
                }
                return this._objectsArray.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(81605427217)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 257699086353, 64486899713)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404119057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._readOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 257699086353, 64486899713)
            
            //--TRIMMABLE-BOUNDARY-START(167504773137)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375230993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._readOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(167504773137)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 240519217169, 38716964865)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634315281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 240519217169, 38716964865)
            
            //--TRIMMABLE-BOUNDARY-START(176094707729)
            /*ICollection */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145034769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection().$ctor$1(objectsArray, objectsTable, this._comparer);
            }
            //--TRIMMABLE-BOUNDARY-END(176094707729)
            
            //--TRIMMABLE-BOUNDARY-START(85900394513)
            /*ArrayList */ EnsureObjectsArray()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900394513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._objectsArray ??= new $.$$.System.Collections.ArrayList().$ctor$3(this._initialCapacity);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900394513)
            
            //--TRIMMABLE-BOUNDARY-START(90195361809)
            /*Hashtable */ EnsureObjectsTable()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195361809);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._objectsTable ??= new $.$$.System.Collections.Hashtable().$ctor$11(this._initialCapacity, this._comparer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195361809)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 244814184465, 43011932161)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 244814184465, 43011932161)
            
            //--TRIMMABLE-BOUNDARY-START(270583988241)
            /*object?*/ get_Item(/*int*/ index)
            {
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Value;
            }
            /*void*/ set_Item(/*int*/ index, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                if (this._objectsArray === null || index < 0 || index >= this._objectsArray.Count)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                }
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*object*/ let key = ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Key;
                objectsArray.set_Item(index, new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
                objectsTable.set_Item(key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(270583988241)
            
            //--TRIMMABLE-BOUNDARY-START(274878955537)
            /*object?*/ get_Item$1(/*object*/ key)
            {
                if (this._objectsTable === null)
                {
                    return null;
                }
                return this._objectsTable.get_Item(key);
            }
            /*void*/ set_Item$1(/*object*/ key, /*object?*/ value)
            {
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                if (objectsTable.Contains(key))
                {
                    objectsTable.set_Item(key, value);
                    /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                    objectsArray.set_Item(this.IndexOfKey(key), new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
                }
                else 
                {
                    this.Add(key, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274878955537)
            
            //--TRIMMABLE-BOUNDARY-START(279173922833)
            /*ICollection */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734969361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection().$ctor$2(objectsArray);
            }
            //--TRIMMABLE-BOUNDARY-END(279173922833)
            
            //--TRIMMABLE-BOUNDARY-START(55835623441)
            /*void */ Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Add(key, value);
                objectsArray.Add(new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
            }
            //--TRIMMABLE-BOUNDARY-END(55835623441)
            
            //--TRIMMABLE-BOUNDARY-START(68720525329)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720525329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                this._objectsTable?.Clear();
                this._objectsArray?.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(68720525329)
            
            //--TRIMMABLE-BOUNDARY-START(64425558033)
            /*OrderedDictionary */ AsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scs.System.Collections.Specialized.OrderedDictionary().$ctor$6(this);
            }
            //--TRIMMABLE-BOUNDARY-END(64425558033)
            
            //--TRIMMABLE-BOUNDARY-START(73015492625)
            /*bool */ Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015492625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (this._objectsTable === null)
                {
                    return false;
                }
                return this._objectsTable.Contains(key);
            }
            //--TRIMMABLE-BOUNDARY-END(73015492625)
            
            //--TRIMMABLE-BOUNDARY-START(77310459921)
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310459921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                objectsTable.CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(77310459921)
            
            //--TRIMMABLE-BOUNDARY-START(154619871249)
            /*int */ IndexOfKey(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619871249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._objectsArray === null)
                {
                    return -1;
                }
                for(/*int*/ let i = 0; i < this._objectsArray.Count; i++)
                {
                    /*object*/ let o = ($.$cast(this._objectsArray.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Key;
                    if (this._comparer !== null)
                    {
                        if (this._comparer.System$Collections$IEqualityComparer$Equals(o, key))
                        {
                            return i;
                        }
                    }
                    else 
                    {
                        if ($.$$.System.Object.Equals$1.call(o, key))
                        {
                            return i;
                        }
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(154619871249)
            
            //--TRIMMABLE-BOUNDARY-START(163209805841)
            /*void */ Insert(/*int*/ index, /*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209805841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, index, this.Count, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Add(key, value);
                objectsArray.Insert(index, new $.$$.System.Collections.DictionaryEntry().$ctor$3(key, value));
            }
            //--TRIMMABLE-BOUNDARY-END(163209805841)
            
            //--TRIMMABLE-BOUNDARY-START(201864511505)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864511505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$$.System.Int32, index, this.Count, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                /*object*/ let key = ($.$cast(objectsArray.get_Item(index), $.$$.System.Collections.DictionaryEntry)).Key;
                objectsArray.RemoveAt(index);
                objectsTable.Remove(key);
            }
            //--TRIMMABLE-BOUNDARY-END(201864511505)
            
            //--TRIMMABLE-BOUNDARY-START(197569544209)
            /*void */ Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569544209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._readOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.OrderedDictionary_ReadOnly);
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                /*int*/ let index = this.IndexOfKey(key);
                if (index < 0)
                {
                    return;
                }
                /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsTable.Remove(key);
                objectsArray.RemoveAt(index);
            }
            //--TRIMMABLE-BOUNDARY-END(197569544209)
            
            //--TRIMMABLE-BOUNDARY-START(146029936657)
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029936657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(objectsArray, 3/*OrderedDictionaryEnumerator.DictionaryEntry*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146029936657)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 261994053649, 4357488641)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994053649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(objectsArray, 3/*OrderedDictionaryEnumerator.DictionaryEntry*/);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 261994053649, 4357488641)
            
            //--TRIMMABLE-BOUNDARY-START(150324903953)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324903953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$9("KeyComparer"/*KeyComparerName*/, this._comparer, $.$$.System.Collections.IEqualityComparer.$type);
                info.AddValue("ReadOnly"/*ReadOnlyName*/, this._readOnly);
                info.AddValue$7("InitialCapacity"/*InitCapacityName*/, this._initialCapacity);
                /*object[]*/ let serArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [this.Count], null);
                /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                objectsArray.CopyTo$1(serArray);
                info.AddValue$10("ArrayList"/*ArrayListName*/, serArray);
            }
            //--TRIMMABLE-BOUNDARY-END(150324903953)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 266289020945, 4452057089)
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289020945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.OnDeserialization(sender);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 266289020945, 4452057089)
            
            //--TRIMMABLE-BOUNDARY-START(180389675025)
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389675025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._siInfo === null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$scs.System.SR.Serialization_InvalidOnDeser);
                }
                this._comparer = $.$cast(this._siInfo.GetValue("KeyComparer"/*KeyComparerName*/, $.$$.System.Collections.IEqualityComparer.$type), $.$$.System.Collections.IEqualityComparer);
                this._readOnly = this._siInfo.GetBoolean("ReadOnly"/*ReadOnlyName*/);
                this._initialCapacity = this._siInfo.GetInt32("InitialCapacity"/*InitCapacityName*/);
                /*object[]?*/ let serArray = $.$cast(this._siInfo.GetValue("ArrayList"/*ArrayListName*/, $.$typeArray($.$$.System.Object).$type), $.$typeArray($.$$.System.Object));
                if (serArray !== null)
                {
                    /*Hashtable*/ let objectsTable = this.EnsureObjectsTable();
                    /*ArrayList*/ let objectsArray = this.EnsureObjectsArray();
                    let $i1 = 0;
                    let $arr1 = serArray;
                    while ($i1 < $arr1.length)
                    {
                        let o = $arr1[$i1++];
                        /*DictionaryEntry*/ let entry;
                        try
                        {
                            entry = $.$cast(o, $.$$.System.Collections.DictionaryEntry);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$scs.System.SR.OrderedDictionary_SerializationMismatch);
                        }
                        objectsArray.Add(entry.Clone());
                        objectsTable.Add(entry.Key, entry.Value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389675025)
            
            //--TRIMMABLE-BOUNDARY-START(1114129)
            static $_OrderedDictionaryEnumerator;
            static get OrderedDictionaryEnumerator()
            {
                let $cls = $.$scs.System.Collections.Specialized.OrderedDictionary;
                return $cls.$_OrderedDictionaryEnumerator ??= $asm.$ncls("$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator", ($self) => class OrderedDictionaryEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591048721)
                    /*int*/ _objectReturnType = 0;
                    //--TRIMMABLE-BOUNDARY-END(8591048721)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720590865)
                    /*int*/ static Keys$1 = 1;
                    //--TRIMMABLE-BOUNDARY-END(68720590865)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900460049)
                    /*int*/ static Values = 2;
                    //--TRIMMABLE-BOUNDARY-END(85900460049)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475950609)
                    /*int*/ static DictionaryEntry = 3;
                    //--TRIMMABLE-BOUNDARY-END(21475950609)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296081425)
                    /*IEnumerator*/ _arrayEnumerator = null;
                    //--TRIMMABLE-BOUNDARY-END(4296081425)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886016017)
                    $ctor$1(/*ArrayList*/ array, /*int*/ objectReturnType)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886016017);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._arrayEnumerator = array.GetEnumerator();
                            this._objectReturnType = objectReturnType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886016017)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180983313)
                    /*object? */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360852497);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        if (this._objectReturnType === 1/*Keys*/)
                        {
                            return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key;
                        }
                        if (this._objectReturnType === 2/*Values*/)
                        {
                            return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value;
                        }
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180983313)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770917905)
                    /*DictionaryEntry */ get Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950787089);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3(($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key, ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770917905)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425623569)
                    /*object */ get Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540721681);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425623569)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605492753)
                    /*object? */ get Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60130656273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._arrayEnumerator.System$Collections$IEnumerator$Current !== null, "_arrayEnumerator.Current != null");
                        return ($.$cast(this._arrayEnumerator.System$Collections$IEnumerator$Current, $.$$.System.Collections.DictionaryEntry)).Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605492753)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015558161)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015558161);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._arrayEnumerator.System$Collections$IEnumerator$MoveNext();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015558161)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310525457)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310525457);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._arrayEnumerator.System$Collections$IEnumerator$Reset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310525457)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537292289)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Key.get
                    get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34422194177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Key;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537292289)
                    
                    //--TRIMMABLE-BOUNDARY-START(30127226881)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Value.get
                    get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38717161473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30127226881)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947357697)
                    //Generated interface implemetation for System.Collections.IDictionaryEnumerator.Entry.get
                    get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357423105);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Entry;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947357697)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242521601)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242521601);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242521601)
                    
                    //--TRIMMABLE-BOUNDARY-START(12947554305)
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4357619713);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12947554305)
                    
                    //--TRIMMABLE-BOUNDARY-START(21537488897)
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21537488897);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Reset(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21537488897)
                    
                    static $h = 1114129;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180983313),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360852497,
        "f": 50331649
      },
      "n": "Current",
      "d": 1114129,
      "h": 17180983313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180983313),
//--TRIMMABLE-BOUNDARY-START(25770917905),
    {
      "p": 56557569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787089,
        "f": 50331649
      },
      "n": "Entry",
      "d": 1114129,
      "h": 25770917905,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770917905),
//--TRIMMABLE-BOUNDARY-START(64425623569),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721681,
        "f": 50331649
      },
      "n": "Key",
      "d": 1114129,
      "h": 64425623569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425623569),
//--TRIMMABLE-BOUNDARY-START(81605492753),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130656273,
        "f": 50331649
      },
      "n": "Value",
      "d": 1114129,
      "h": 81605492753,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605492753)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(73015558161),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 1114129,
      "h": 73015558161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015558161),
//--TRIMMABLE-BOUNDARY-START(77310525457),
    {
      "r": 65537,
      "n": "Reset",
      "d": 1114129,
      "h": 77310525457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310525457)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591048721),
    {
      "t": 655361,
      "n": "_objectReturnType",
      "d": 1114129,
      "h": 8591048721,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048721),
//--TRIMMABLE-BOUNDARY-START(68720590865),
    {
      "t": 655361,
      "n": "Keys",
      "o": "@$1",
      "d": 1114129,
      "h": 68720590865,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720590865),
//--TRIMMABLE-BOUNDARY-START(85900460049),
    {
      "t": 655361,
      "n": "Values",
      "d": 1114129,
      "h": 85900460049,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900460049),
//--TRIMMABLE-BOUNDARY-START(21475950609),
    {
      "t": 655361,
      "n": "DictionaryEntry",
      "d": 1114129,
      "h": 21475950609,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475950609),
//--TRIMMABLE-BOUNDARY-START(4296081425),
    {
      "t": 62652417,
      "n": "_arrayEnumerator",
      "d": 1114129,
      "h": 4296081425,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081425)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886016017),
    {
      "p": [
        {
          "n": "array",
          "p": 54329345
        },
        {
          "n": "objectReturnType",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114129,
      "h": 12886016017,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886016017)
  ],
  "i": [62455809,62652417
  ],
  "d": 1048593,
  "h": 1114129
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator`; }
                }, $cls, ($v) => $cls.$_OrderedDictionaryEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1114129)
            
            //--TRIMMABLE-BOUNDARY-START(1179665)
            static $_OrderedDictionaryKeyValueCollection;
            static get OrderedDictionaryKeyValueCollection()
            {
                let $cls = $.$scs.System.Collections.Specialized.OrderedDictionary;
                return $cls.$_OrderedDictionaryKeyValueCollection ??= $asm.$ncls("$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection", ($self) => class OrderedDictionaryKeyValueCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8591114257)
                    /*ArrayList*/ _objects = null;
                    //--TRIMMABLE-BOUNDARY-END(8591114257)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886081553)
                    /*Hashtable?*/ _objectsTable = null;
                    //--TRIMMABLE-BOUNDARY-END(12886081553)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296146961)
                    /*IEqualityComparer?*/ _comparer = null;
                    //--TRIMMABLE-BOUNDARY-END(4296146961)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181048849)
                    $ctor$1(/*ArrayList*/ array, /*Hashtable*/ objectsTable, /*IEqualityComparer?*/ comparer)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181048849);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._objects = array;
                            this._objectsTable = objectsTable;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181048849)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476016145)
                    $ctor$2(/*ArrayList*/ array)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21476016145);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._objects = array;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476016145)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655885329)
                    /*bool */ get IsKeys()
                    {
                        return !(this._objectsTable === null);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655885329)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 42950852625, 4357226497)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950852625);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        var $en4 = this._objects.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var o = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(o !== null, "o != null");
                                array.SetValue$2(this.IsKeys ? ($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Key : ($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Value, index);
                                index++;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 42950852625, 4357226497)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 47245819921, 8652193793)
                    /*int */ get System$Collections$ICollection$Count()
                    {
                        return this._objects.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 47245819921, 8652193793)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 77310590993, 38716964865)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 77310590993, 38716964865)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 81605558289, 43011932161)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return this._objects.SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 81605558289, 43011932161)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 85900525585, 4357488641)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900525585);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scs.System.Collections.Specialized.OrderedDictionary.OrderedDictionaryEnumerator().$ctor$1(this._objects, this.IsKeys ? 1/*OrderedDictionaryEnumerator.Keys*/ : 2/*OrderedDictionaryEnumerator.Values*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 85900525585, 4357488641)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 98785427473, 12947750913)
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98785427473);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.IsKeys)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(this._objectsTable === null), "_objectsTable is not null");
                            return value !== null && this._objectsTable.ContainsKey(value);
                        }
                        var $en4 = this._objects.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var o = $en4.System$Collections$IEnumerator$Current;
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(o !== null, "o != null");
                                if ($.$$.System.Object.Equals(($.$cast(o, $.$$.System.Collections.DictionaryEntry)).Value, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 98785427473, 12947750913)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 128850198545, 43012521985)
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128850198545);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*int*/ let i = 0; i < this._objects.Count; i++)
                        {
                            if (this.IsKeys)
                            {
                                /*object*/ let entryKey = ($.$cast(this._objects.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Key;
                                if (this._comparer !== null)
                                {
                                    if (this._comparer.System$Collections$IEqualityComparer$Equals(entryKey, value))
                                    {
                                        return i;
                                    }
                                }
                                else if ($.$$.System.Object.Equals$1.call(entryKey, value))
                                {
                                    return i;
                                }
                            }
                            else if ($.$$.System.Object.Equals(($.$cast(this._objects.get_Item(i), $.$$.System.Collections.DictionaryEntry)).Value, value))
                            {
                                return i;
                            }
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 128850198545, 43012521985)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 137440133137, 51602456577)
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 137440133137, 51602456577)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 141735100433, 55897423873)
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 141735100433, 55897423873)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 163209936913, 77372260353)
                    //--TRIMMABLE-BOUNDARY-START(77372260353)
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        /*DictionaryEntry*/ let entry = $.$cast(this._objects.get_Item(index), $.$$.System.Collections.DictionaryEntry);
                        return this.IsKeys ? entry.Key : entry.Value;
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(77372260353)
                    
                    //--TRIMMABLE-BOUNDARY-END(ALL, 163209936913, 77372260353)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 133145165841, 47307489281)
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133145165841);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 133145165841, 47307489281)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 146030067729, 60192391169)
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(146030067729);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 146030067729, 60192391169)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 150325035025, 64487358465)
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(150325035025);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 150325035025, 64487358465)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 90195492881, 4357816321)
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90195492881);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 90195492881, 4357816321)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 94490460177, 8652783617)
                    /*void */ System$Collections$IList$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94490460177);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12(this.GetNotSupportedErrorMessage());
                    }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 94490460177, 8652783617)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360918033)
                    /*string */ GetNotSupportedErrorMessage()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360918033);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsKeys ? $.$scs.System.SR.NotSupported_KeyCollectionSet : $.$scs.System.SR.NotSupported_ValueCollectionSet;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360918033)
                    
                    static $h = 1179665;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655885329),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950737,
        "f": 50331650
      },
      "n": "IsKeys",
      "d": 1179665,
      "h": 38655885329,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(38655885329),
//--TRIMMABLE-BOUNDARY-START(ALL, 47245819921, 8652193793),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835754513,
        "f": 50331650
      },
      "n": "{62259201}.Count",
      "o": "System$Collections$ICollection$Count",
      "d": 1179665,
      "h": 47245819921,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47245819921, 8652193793),
//--TRIMMABLE-BOUNDARY-START(ALL, 77310590993, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425689105,
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 1179665,
      "h": 77310590993,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 77310590993, 38716964865),
//--TRIMMABLE-BOUNDARY-START(ALL, 81605558289, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015623697,
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 1179665,
      "h": 81605558289,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81605558289, 43011932161),
//--TRIMMABLE-BOUNDARY-START(ALL, 137440133137, 51602456577),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375362065,
        "f": 50331650
      },
      "n": "{62849025}.IsFixedSize",
      "o": "System$Collections$IList$IsFixedSize",
      "d": 1179665,
      "h": 137440133137,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 137440133137, 51602456577),
//--TRIMMABLE-BOUNDARY-START(ALL, 141735100433, 55897423873),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965296657,
        "f": 50331650
      },
      "n": "{62849025}.IsReadOnly",
      "o": "System$Collections$IList$IsReadOnly",
      "d": 1179665,
      "h": 141735100433,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 141735100433, 55897423873),
//--TRIMMABLE-BOUNDARY-START(ALL, 163209936913, 77372260353),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555231249,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914969617,
        "f": 83886082
      },
      "n": "{62849025}.this[]",
      "o": "System$Collections$IList$Item",
      "d": 1179665,
      "h": 163209936913,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 163209936913, 77372260353)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360918033),
    {
      "r": 1310721,
      "n": "GetNotSupportedErrorMessage",
      "d": 1179665,
      "h": 34360918033,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360918033)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591114257),
    {
      "t": 54329345,
      "n": "_objects",
      "d": 1179665,
      "h": 8591114257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114257),
//--TRIMMABLE-BOUNDARY-START(12886081553),
    {
      "t": 61800449,
      "n": "_objectsTable",
      "d": 1179665,
      "h": 12886081553,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886081553),
//--TRIMMABLE-BOUNDARY-START(4296146961),
    {
      "t": 62717953,
      "n": "_comparer",
      "d": 1179665,
      "h": 4296146961,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146961)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048849),
    {
      "p": [
        {
          "n": "array",
          "p": 54329345
        },
        {
          "n": "objectsTable",
          "p": 61800449
        },
        {
          "n": "comparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179665,
      "h": 17181048849,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048849),
//--TRIMMABLE-BOUNDARY-START(21476016145),
    {
      "p": [
        {
          "n": "array",
          "p": 54329345
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179665,
      "h": 21476016145,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016145)
  ],
  "i": [62849025,62259201,62521345
  ],
  "d": 1048593,
  "h": 1179665
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Specialized.OrderedDictionary.OrderedDictionaryKeyValueCollection`; }
                }, $cls, ($v) => $cls.$_OrderedDictionaryKeyValueCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179665)
            
            //--TRIMMABLE-BOUNDARY-START(8590262289)
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.this[int].get
            System$Collections$Specialized$IOrderedDictionary$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262289);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262289)
            
            //--TRIMMABLE-BOUNDARY-START(30065098769)
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.this[int].set
            System$Collections$Specialized$IOrderedDictionary$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065098769)
            
            //--TRIMMABLE-BOUNDARY-START(12885229585)
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.GetEnumerator()
            System$Collections$Specialized$IOrderedDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229585)
            
            //--TRIMMABLE-BOUNDARY-START(17180196881)
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.Insert(int, object, object?)
            System$Collections$Specialized$IOrderedDictionary$Insert()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Insert(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17180196881)
            
            //--TRIMMABLE-BOUNDARY-START(21475164177)
            //Generated interface implemetation for System.Collections.Specialized.IOrderedDictionary.RemoveAt(int)
            System$Collections$Specialized$IOrderedDictionary$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21475164177)
            
            //--TRIMMABLE-BOUNDARY-START(38717095937)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].get
            System$Collections$IDictionary$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38717095937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38717095937)
            
            //--TRIMMABLE-BOUNDARY-START(85961736193)
            //Generated interface implemetation for System.Collections.IDictionary.this[object].set
            System$Collections$IDictionary$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85961736193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(85961736193)
            
            //--TRIMMABLE-BOUNDARY-START(47307030529)
            //Generated interface implemetation for System.Collections.IDictionary.Keys.get
            get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73076834305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(47307030529)
            
            //--TRIMMABLE-BOUNDARY-START(55896965121)
            //Generated interface implemetation for System.Collections.IDictionary.Values.get
            get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94551670785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(55896965121)
            
            //--TRIMMABLE-BOUNDARY-START(12947292161)
            //Generated interface implemetation for System.Collections.IDictionary.Contains(object)
            System$Collections$IDictionary$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12947292161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12947292161)
            
            //--TRIMMABLE-BOUNDARY-START(4357357569)
            //Generated interface implemetation for System.Collections.IDictionary.Add(object, object?)
            System$Collections$IDictionary$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357357569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357357569)
            
            //--TRIMMABLE-BOUNDARY-START(8652324865)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652324865)
            
            //--TRIMMABLE-BOUNDARY-START(30127161345)
            //Generated interface implemetation for System.Collections.IDictionary.IsReadOnly.get
            get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68781867009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(30127161345)
            
            //--TRIMMABLE-BOUNDARY-START(60191932417)
            //Generated interface implemetation for System.Collections.IDictionary.GetEnumerator()
            System$Collections$IDictionary$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60191932417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60191932417)
            
            //--TRIMMABLE-BOUNDARY-START(77371801601)
            //Generated interface implemetation for System.Collections.IDictionary.Remove(object)
            System$Collections$IDictionary$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77371801601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(77371801601)
            
            //--TRIMMABLE-BOUNDARY-START(4357226497)
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357226497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357226497)
            
            //--TRIMMABLE-BOUNDARY-START(17242128385)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652193793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242128385)
            
            //--TRIMMABLE-BOUNDARY-START(4452319233)
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4452319233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetObjectData(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4452319233)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(171799740433)
                    this.KeyComparerName = "KeyComparer";
                    //--TRIMMABLE-BOUNDARY-END(171799740433)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130590737)
                    this.ArrayListName = "ArrayList";
                    //--TRIMMABLE-BOUNDARY-END(60130590737)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274576913)
                    this.ReadOnlyName = "ReadOnly";
                    //--TRIMMABLE-BOUNDARY-END(193274576913)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914838545)
                    this.InitCapacityName = "InitialCapacity";
                    //--TRIMMABLE-BOUNDARY-END(158914838545)
                    
                }
            }
            static $h = 1048593;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(81605427217),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785296401,
        "f": 50331649
      },
      "n": "Count",
      "d": 1048593,
      "h": 81605427217,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605427217),
//--TRIMMABLE-BOUNDARY-START(ALL, 257699086353, 64486899713),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253404119057,
        "f": 50331650
      },
      "n": "{62390273}.IsFixedSize",
      "o": "System$Collections$IDictionary$IsFixedSize",
      "d": 1048593,
      "h": 257699086353,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 257699086353, 64486899713),
//--TRIMMABLE-BOUNDARY-START(167504773137),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375230993,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1048593,
      "h": 167504773137,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504773137),
//--TRIMMABLE-BOUNDARY-START(ALL, 240519217169, 38716964865),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634315281,
        "f": 50331650
      },
      "n": "{62259201}.IsSynchronized",
      "o": "System$Collections$ICollection$IsSynchronized",
      "d": 1048593,
      "h": 240519217169,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 240519217169, 38716964865),
//--TRIMMABLE-BOUNDARY-START(176094707729),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145034769,
        "f": 50331649
      },
      "n": "Keys",
      "o": "@$1",
      "d": 1048593,
      "h": 176094707729,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094707729),
//--TRIMMABLE-BOUNDARY-START(ALL, 244814184465, 43011932161),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224249873,
        "f": 50331650
      },
      "n": "{62259201}.SyncRoot",
      "o": "System$Collections$ICollection$SyncRoot",
      "d": 1048593,
      "h": 244814184465,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 244814184465, 43011932161),
//--TRIMMABLE-BOUNDARY-START(270583988241),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965165585,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454446097,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 1048593,
      "h": 270583988241,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583988241),
//--TRIMMABLE-BOUNDARY-START(274878955537),
    {
      "p": 131073,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555100177,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044380689,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$3",
      "d": 1048593,
      "h": 274878955537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878955537),
//--TRIMMABLE-BOUNDARY-START(279173922833),
    {
      "p": 62259201,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734969361,
        "f": 50331649
      },
      "n": "Values",
      "d": 1048593,
      "h": 279173922833,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173922833)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900394513),
    {
      "r": 54329345,
      "n": "EnsureObjectsArray",
      "d": 1048593,
      "h": 85900394513,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85900394513),
//--TRIMMABLE-BOUNDARY-START(90195361809),
    {
      "r": 61800449,
      "n": "EnsureObjectsTable",
      "d": 1048593,
      "h": 90195361809,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90195361809),
//--TRIMMABLE-BOUNDARY-START(55835623441),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Add",
      "d": 1048593,
      "h": 55835623441,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835623441),
//--TRIMMABLE-BOUNDARY-START(68720525329),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1048593,
      "h": 68720525329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720525329),
//--TRIMMABLE-BOUNDARY-START(64425558033),
    {
      "r": 1048593,
      "n": "AsReadOnly",
      "d": 1048593,
      "h": 64425558033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425558033),
//--TRIMMABLE-BOUNDARY-START(73015492625),
    {
      "r": 262145,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 1048593,
      "h": 73015492625,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015492625),
//--TRIMMABLE-BOUNDARY-START(77310459921),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1048593,
      "h": 77310459921,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310459921),
//--TRIMMABLE-BOUNDARY-START(154619871249),
    {
      "r": 655361,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "IndexOfKey",
      "d": 1048593,
      "h": 154619871249,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619871249),
//--TRIMMABLE-BOUNDARY-START(163209805841),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Insert",
      "d": 1048593,
      "h": 163209805841,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209805841),
//--TRIMMABLE-BOUNDARY-START(201864511505),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1048593,
      "h": 201864511505,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864511505),
//--TRIMMABLE-BOUNDARY-START(197569544209),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Remove",
      "d": 1048593,
      "h": 197569544209,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569544209),
//--TRIMMABLE-BOUNDARY-START(146029936657),
    {
      "r": 62455809,
      "n": "GetEnumerator",
      "d": 1048593,
      "h": 146029936657,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029936657),
//--TRIMMABLE-BOUNDARY-START(150324903953),
    {
      "r": 65537,
      "p": [
        {
          "n": "info",
          "p": 157941761
        },
        {
          "n": "context",
          "p": 158072833
        }
      ],
      "n": "GetObjectData",
      "d": 1048593,
      "h": 150324903953,
      "f": 16777345,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(150324903953),
//--TRIMMABLE-BOUNDARY-START(180389675025),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        }
      ],
      "n": "OnDeserialization",
      "d": 1048593,
      "h": 180389675025,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(180389675025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950481),
    {
      "t": 54329345,
      "n": "_objectsArray",
      "d": 1048593,
      "h": 12885950481,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885950481),
//--TRIMMABLE-BOUNDARY-START(17180917777),
    {
      "t": 61800449,
      "n": "_objectsTable",
      "d": 1048593,
      "h": 17180917777,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180917777),
//--TRIMMABLE-BOUNDARY-START(8590983185),
    {
      "t": 655361,
      "n": "_initialCapacity",
      "d": 1048593,
      "h": 8590983185,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590983185),
//--TRIMMABLE-BOUNDARY-START(4296015889),
    {
      "t": 62717953,
      "n": "_comparer",
      "d": 1048593,
      "h": 4296015889,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296015889),
//--TRIMMABLE-BOUNDARY-START(21475885073),
    {
      "t": 262145,
      "n": "_readOnly",
      "d": 1048593,
      "h": 21475885073,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475885073),
//--TRIMMABLE-BOUNDARY-START(25770852369),
    {
      "t": 157941761,
      "n": "_siInfo",
      "d": 1048593,
      "h": 25770852369,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770852369),
//--TRIMMABLE-BOUNDARY-START(171799740433),
    {
      "t": 1310721,
      "n": "KeyComparerName",
      "d": 1048593,
      "h": 171799740433,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(171799740433),
//--TRIMMABLE-BOUNDARY-START(60130590737),
    {
      "t": 1310721,
      "n": "ArrayListName",
      "d": 1048593,
      "h": 60130590737,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(60130590737),
//--TRIMMABLE-BOUNDARY-START(193274576913),
    {
      "t": 1310721,
      "n": "ReadOnlyName",
      "d": 1048593,
      "h": 193274576913,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(193274576913),
//--TRIMMABLE-BOUNDARY-START(158914838545),
    {
      "t": 1310721,
      "n": "InitCapacityName",
      "d": 1048593,
      "h": 158914838545,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(158914838545)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065819665),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048593,
      "h": 30065819665,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065819665),
//--TRIMMABLE-BOUNDARY-START(34360786961),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1048593,
      "h": 34360786961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360786961),
//--TRIMMABLE-BOUNDARY-START(38655754257),
    {
      "p": [
        {
          "n": "comparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048593,
      "h": 38655754257,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655754257),
//--TRIMMABLE-BOUNDARY-START(42950721553),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "comparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048593,
      "h": 42950721553,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950721553),
//--TRIMMABLE-BOUNDARY-START(47245688849),
    {
      "p": [
        {
          "n": "dictionary",
          "p": 1048593
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1048593,
      "h": 47245688849,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245688849),
//--TRIMMABLE-BOUNDARY-START(51540656145),
    {
      "p": [
        {
          "n": "info",
          "p": 157941761
        },
        {
          "n": "context",
          "p": 158072833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1048593,
      "h": 51540656145,
      "f": 16777220,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540656145)
  ],
  "i": [327697,62390273,62259201,62521345,157351937,157089793
  ],
  "j": [1114129,1179665
  ],
  "h": 1048593,
  "a": [
    {
      "t": 162201601,
      "c": 4457168897
    },
    {
      "t": 133627905,
      "c": 4428595201,
      "a": [
        {
          "v": "System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scs.System.Collections.Specialized.IOrderedDictionary, $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.OrderedDictionary`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048593)
        
        
        //--TRIMMABLE-BOUNDARY-START(131089)
        $asm.$str("$scs.System.Collections.Specialized.BitVector32", ($self) => class BitVector32 extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295098385)
            /*uint*/  get _data() { return this.$getField(0, $.$$.System.UInt32); }
            /*uint*/  set _data(value) { this.$setField(0, $.$$.System.UInt32, value); }
            //--TRIMMABLE-BOUNDARY-END(4295098385)
            
            //--TRIMMABLE-BOUNDARY-START(8590065681)
            $ctor$3(/*int*/ data)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._data = (data >>> 0);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065681)
            
            //--TRIMMABLE-BOUNDARY-START(12885032977)
            $ctor$4(/*BitVector32*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885032977);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._data = value._data;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032977)
            
            //--TRIMMABLE-BOUNDARY-START(107374313489)
            /*bool*/ get_Item(/*int*/ bit)
            {
                return (BigInt(this._data) & BigInt(bit)) === BigInt((bit >>> 0));
            }
            /*void*/ set_Item(/*int*/ bit, /*bool*/ value)
            {
                //unchecked
                {
                    if (value)
                    {
                        this._data |= (bit >>> 0);
                    }
                    else 
                    {
                        this._data &= ~(bit >>> 0);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374313489)
            
            //--TRIMMABLE-BOUNDARY-START(111669280785)
            /*int*/ get_Item$1(/*Section*/ section)
            {
                //unchecked
                {
                    return (((this._data & ((section.Mask << section.Offset) >>> 0)) >>> section.Offset) | 0);
                }
            }
            /*void*/ set_Item$1(/*Section*/ section, /*int*/ value)
            {
                value <<= section.Offset;
                /*int*/ let offsetMask = (65535 & section.Mask) << section.Offset;
                this._data = (this._data & ~(offsetMask >>> 0)) | ((value >>> 0) & (offsetMask >>> 0));
            }
            //--TRIMMABLE-BOUNDARY-END(111669280785)
            
            //--TRIMMABLE-BOUNDARY-START(42949804049)
            /*int */ get Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._data | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42949804049)
            
            //--TRIMMABLE-BOUNDARY-START(21474967569)
            static /*int */ CreateMask()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scs.System.Collections.Specialized.BitVector32.CreateMask$1(0);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967569)
            
            //--TRIMMABLE-BOUNDARY-START(25769934865)
            static /*int */ CreateMask$1(/*int*/ previous)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (previous === 0)
                {
                    return 1;
                }
                if (previous === (2147483648 | 0))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.BitVectorFull);
                }
                return previous << 1;
            }
            //--TRIMMABLE-BOUNDARY-END(25769934865)
            
            //--TRIMMABLE-BOUNDARY-START(30064902161)
            static /*Section */ CreateSection$1(/*short*/ maxValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scs.System.Collections.Specialized.BitVector32.CreateSectionHelper(maxValue, 0, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902161)
            
            //--TRIMMABLE-BOUNDARY-START(34359869457)
            static /*Section */ CreateSection(/*short*/ maxValue, /*Section*/ previous)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scs.System.Collections.Specialized.BitVector32.CreateSectionHelper(maxValue, previous.Mask, previous.Offset);
            }
            //--TRIMMABLE-BOUNDARY-END(34359869457)
            
            //--TRIMMABLE-BOUNDARY-START(38654836753)
            static /*Section */ CreateSectionHelper(/*short*/ maxValue, /*short*/ priorMask, /*short*/ priorOffset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int16, maxValue, "maxValue");
                /*short*/ let offset = $.$cast((((priorOffset + $.$$.System.Numerics.BitOperations.PopCount($.$cast(priorMask, $.$$.System.UInt16))) | 0)), $.$$.System.Int16);
                if (offset >= 32)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scs.System.SR.BitVectorFull);
                }
                /*short*/ let mask = $.$cast(((($.$$.System.Numerics.BitOperations.RoundUpToPowerOf2((($.$cast(maxValue, $.$$.System.UInt16) + 1) >>> 0)) - 1) >>> 0)), $.$$.System.Int16);
                return new $.$scs.System.Collections.Specialized.BitVector32.Section().$ctor$3(mask, offset);
            }
            //--TRIMMABLE-BOUNDARY-END(38654836753)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 47244771345, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244771345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(o, $.$scs.System.Collections.Specialized.BitVector32, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scs.System.Collections.Specialized.BitVector32.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 47244771345, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(51539738641)
            /*bool */ Equals$2(/*BitVector32*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539738641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._data === other._data;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539738641)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604509713, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604509713);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.UInt32.GetHashCode.call(this._data);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scs.System.Collections.Specialized.BitVector32.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604509713, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(115964248081)
            static /*string */ ToString$1(/*BitVector32*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964248081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Create$10($.$scs.System.Collections.Specialized.BitVector32, ((((12 + 32) | 0) + 1) | 0), value.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$scs.System.Collections.Specialized.BitVector32))().$ctor(this,  (/**/ dst, /*v*/ v) =>
                {
                    /*ReadOnlySpan<char>*/ let prefix = $.$$.System.String.op_Implicit("BitVector32{");
                    prefix.CopyTo(dst);
                    dst.get_Item(((dst.Length - 1) | 0)).$v = /*}*/ 125;
                    /*int*/ let locdata = (v._data | 0);
                    dst = dst.Slice(prefix.Length, 32);
                    for(/*int*/ let i = 0; i < dst.Length; i++)
                    {
                        dst.get_Item(i).$v = (BigInt(locdata) & 2147483648n) !== 0n ? /*1*/ 49 : /*0*/ 48;
                        locdata <<= 1;
                    }
                }, {
  "r": 65537,
  "p": [
    {
      "n": "dst",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "v",
      "p": 131089
    }
  ],
  "n": "",
  "d": 131089,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(115964248081)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 120259215377, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259215377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scs.System.Collections.Specialized.BitVector32.ToString$1(this);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scs.System.Collections.Specialized.BitVector32.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 120259215377, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(196625)
            static $_Section;
            static get Section()
            {
                let $cls = $.$scs.System.Collections.Specialized.BitVector32;
                return $cls.$_Section ??= $asm.$nstr("$scs.System.Collections.Specialized.BitVector32.Section", ($self) => class Section extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163921)
                    /*short*/  get _mask() { return this.$getField(0, $.$$.System.Int16); }
                    /*short*/  set _mask(value) { this.$setField(0, $.$$.System.Int16, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295163921)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131217)
                    /*short*/  get _offset() { return this.$getField(2, $.$$.System.Int16); }
                    /*short*/  set _offset(value) { this.$setField(2, $.$$.System.Int16, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590131217)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098513)
                    $ctor$3(/*short*/ mask, /*short*/ offset)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098513);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._mask = mask;
                            this._offset = offset;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098513)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804177)
                    /*short */ get Mask()
                    {
                        return this._mask;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804177)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834771473)
                    /*short */ get Offset()
                    {
                        return this._offset;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834771473)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 21475033105, 34359869441)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ o)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475033105);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let other;
                            return $.$is(o, $.$scs.System.Collections.Specialized.BitVector32.Section, { set $v(v){ other = v; } }) && this.Equals$2(other);
                        }
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$scs.System.Collections.Specialized.BitVector32.Section.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 21475033105, 34359869441)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000401)
                    /*bool */ Equals$2(/*Section*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770000401);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return obj._mask === this._mask && obj._offset === this._offset;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000401)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738769)
                    static /*bool */ op_Equality(/*Section*/ a, /*Section*/ b)
                    {
                        return a.Equals$2(b);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738769)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424706065)
                    static /*bool */ op_Inequality(/*Section*/ a, /*Section*/ b)
                    {
                        return !($.$scs.System.Collections.Specialized.BitVector32.Section.op_Equality(a, b));
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424706065)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 47244836881, 184683724801)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47244836881);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$$.System.HashCode.Combine$6($.$$.System.Int16, $.$$.System.Int16, this._mask, this._offset);
                        }
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$scs.System.Collections.Specialized.BitVector32.Section.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 47244836881, 184683724801)
                    
                    //--TRIMMABLE-BOUNDARY-START(68719673361)
                    static /*string */ ToString$1(/*Section*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68719673361);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (() =>
                        {
                            var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(3, 2);
                            $handler.AppendLiteral("Section{{0x");
                            $handler.AppendFormatted($.$box(value.Mask, $.$$.System.Int16), null, "x");
                            $handler.AppendLiteral(", 0x");
                            $handler.AppendFormatted($.$box(value.Offset, $.$$.System.Int16), null, "x");
                            $handler.AppendLiteral("}}");
                            return $handler.ToStringAndClear                    ();
                        })();
                    }
                    //--TRIMMABLE-BOUNDARY-END(68719673361)
                    
                    //--TRIMMABLE-BOUNDARY-START(ALL, 73014640657, 330712612865)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73014640657);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$scs.System.Collections.Specialized.BitVector32.Section.ToString$1(this);
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$scs.System.Collections.Specialized.BitVector32.Section.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(ALL, 73014640657, 330712612865)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385210369)
                    //Generated interface implemetation for System.IEquatable<System.Collections.Specialized.BitVector32.Section>.Equals(System.Collections.Specialized.BitVector32.Section)
                    System$IEquatable$$$Equals()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385210369);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Equals$2(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385210369)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._mask = this._mask;
                        copy._offset = this._offset;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295163921)
                        this._mask = 0;
                        //--TRIMMABLE-BOUNDARY-END(4295163921)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590131217)
                        this._offset = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590131217)
                        
                    }
                    static $h = 196625;
                    static $z = 4;
                    static $f = 0b10000010000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51539804177),
    {
      "p": 524289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359934993,
        "f": 50331649
      },
      "n": "Mask",
      "d": 196625,
      "h": 51539804177,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51539804177),
//--TRIMMABLE-BOUNDARY-START(55834771473),
    {
      "p": 524289,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869585,
        "f": 50331649
      },
      "n": "Offset",
      "d": 196625,
      "h": 55834771473,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834771473)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21475033105, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 196625,
      "h": 21475033105,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475033105, 34359869441),
//--TRIMMABLE-BOUNDARY-START(25770000401),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 196625
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 196625,
      "h": 25770000401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000401),
//--TRIMMABLE-BOUNDARY-START(ALL, 47244836881, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 196625,
      "h": 47244836881,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47244836881, 184683724801),
//--TRIMMABLE-BOUNDARY-START(68719673361),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 196625
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 196625,
      "h": 68719673361,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719673361),
//--TRIMMABLE-BOUNDARY-START(ALL, 73014640657, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196625,
      "h": 73014640657,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 73014640657, 330712612865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163921),
    {
      "t": 524289,
      "n": "_mask",
      "d": 196625,
      "h": 4295163921,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163921),
//--TRIMMABLE-BOUNDARY-START(8590131217),
    {
      "t": 524289,
      "n": "_offset",
      "d": 196625,
      "h": 8590131217,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131217)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885098513),
    {
      "p": [
        {
          "n": "mask",
          "p": 524289
        },
        {
          "n": "offset",
          "p": 524289
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196625,
      "h": 12885098513,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885098513),
//--TRIMMABLE-BOUNDARY-START(17180065809),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196625,
      "h": 17180065809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065809)
  ],
  "i": [$.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32.Section).$h
  ],
  "d": 131089,
  "h": 196625
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32.Section) ]; }
                    static get $fullName() { return `System.Collections.Specialized.BitVector32.Section`; }
                }, $cls, ($v) => $cls.$_Section = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196625)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<System.Collections.Specialized.BitVector32>.Equals(System.Collections.Specialized.BitVector32)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._data = this._data;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098385)
                this._data = 0;
                //--TRIMMABLE-BOUNDARY-END(4295098385)
                
            }
            static $h = 131089;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(107374313489),
    {
      "p": 262145,
      "i": [
        {
          "n": "bit",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719607825,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489411601,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$2",
      "d": 131089,
      "h": 107374313489,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374313489),
//--TRIMMABLE-BOUNDARY-START(111669280785),
    {
      "p": 655361,
      "i": [
        {
          "n": "section",
          "p": 196625
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309542417,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079346193,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$3",
      "d": 131089,
      "h": 111669280785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669280785),
//--TRIMMABLE-BOUNDARY-START(42949804049),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129673233,
        "f": 50331649
      },
      "n": "Data",
      "d": 131089,
      "h": 42949804049,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949804049)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474967569),
    {
      "r": 655361,
      "n": "CreateMask",
      "d": 131089,
      "h": 21474967569,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21474967569),
//--TRIMMABLE-BOUNDARY-START(25769934865),
    {
      "r": 655361,
      "p": [
        {
          "n": "previous",
          "p": 655361
        }
      ],
      "n": "CreateMask",
      "o": "@$1",
      "d": 131089,
      "h": 25769934865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769934865),
//--TRIMMABLE-BOUNDARY-START(30064902161),
    {
      "r": 196625,
      "p": [
        {
          "n": "maxValue",
          "p": 524289
        }
      ],
      "n": "CreateSection",
      "o": "@$1",
      "d": 131089,
      "h": 30064902161,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064902161),
//--TRIMMABLE-BOUNDARY-START(34359869457),
    {
      "r": 196625,
      "p": [
        {
          "n": "maxValue",
          "p": 524289
        },
        {
          "n": "previous",
          "p": 196625
        }
      ],
      "n": "CreateSection",
      "d": 131089,
      "h": 34359869457,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359869457),
//--TRIMMABLE-BOUNDARY-START(38654836753),
    {
      "r": 196625,
      "p": [
        {
          "n": "maxValue",
          "p": 524289
        },
        {
          "n": "priorMask",
          "p": 524289
        },
        {
          "n": "priorOffset",
          "p": 524289
        }
      ],
      "n": "CreateSectionHelper",
      "d": 131089,
      "h": 38654836753,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654836753),
//--TRIMMABLE-BOUNDARY-START(ALL, 47244771345, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 131089,
      "h": 47244771345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 47244771345, 34359869441),
//--TRIMMABLE-BOUNDARY-START(51539738641),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 131089
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 131089,
      "h": 51539738641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539738641),
//--TRIMMABLE-BOUNDARY-START(ALL, 81604509713, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 131089,
      "h": 81604509713,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81604509713, 184683724801),
//--TRIMMABLE-BOUNDARY-START(115964248081),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 131089
        }
      ],
      "n": "ToString",
      "o": "@$1",
      "d": 131089,
      "h": 115964248081,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(115964248081),
//--TRIMMABLE-BOUNDARY-START(ALL, 120259215377, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 131089,
      "h": 120259215377,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 120259215377, 330712612865)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098385),
    {
      "t": 720897,
      "n": "_data",
      "d": 131089,
      "h": 4295098385,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098385)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065681),
    {
      "p": [
        {
          "n": "data",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131089,
      "h": 8590065681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065681),
//--TRIMMABLE-BOUNDARY-START(12885032977),
    {
      "p": [
        {
          "n": "value",
          "p": 131089
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 131089,
      "h": 12885032977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885032977),
//--TRIMMABLE-BOUNDARY-START(17180000273),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131089,
      "h": 17180000273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180000273)
  ],
  "i": [$.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32).$h
  ],
  "j": [196625
  ],
  "h": 131089
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$scs.System.Collections.Specialized.BitVector32) ]; }
            static get $fullName() { return `System.Collections.Specialized.BitVector32`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131089)
        
        
        //--TRIMMABLE-BOUNDARY-START(983057)
        $asm.$cls("$scs.System.Collections.Specialized.NameValueCollection", ($self) => class NameValueCollection extends $.$scs.System.Collections.Specialized.NameObjectCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295950353)
            /*string?[]?*/ _all = null;
            //--TRIMMABLE-BOUNDARY-END(4295950353)
            
            //--TRIMMABLE-BOUNDARY-START(8590917649)
            /*string?[]?*/ _allKeys = null;
            //--TRIMMABLE-BOUNDARY-END(8590917649)
            
            //--TRIMMABLE-BOUNDARY-START(12885884945)
            $ctor$8()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885884945)
            
            //--TRIMMABLE-BOUNDARY-START(17180852241)
            $ctor$16(/*NameValueCollection*/ col)
            {
                super.$ctor$2((col?.Comparer ?? null));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180852241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Add$1(col);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180852241)
            
            //--TRIMMABLE-BOUNDARY-START(21475819537)
            $ctor$10(/*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor$3(hashProvider, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475819537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475819537)
            
            //--TRIMMABLE-BOUNDARY-START(25770786833)
            $ctor$14(/*int*/ capacity)
            {
                super.$ctor$6(capacity);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770786833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770786833)
            
            //--TRIMMABLE-BOUNDARY-START(30065754129)
            $ctor$9(/*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor$2(equalityComparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065754129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065754129)
            
            //--TRIMMABLE-BOUNDARY-START(34360721425)
            $ctor$11(/*int*/ capacity, /*IEqualityComparer?*/ equalityComparer)
            {
                super.$ctor$4(capacity, equalityComparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360721425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721425)
            
            //--TRIMMABLE-BOUNDARY-START(38655688721)
            $ctor$13(/*int*/ capacity, /*NameValueCollection*/ col)
            {
                super.$ctor$4(capacity, col !== null ? col.Comparer : (() =>
                {
        throw new $.$$.System.ArgumentNullException().$ctor$19("col")        })());
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655688721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Comparer = col.Comparer;
                    this.Add$1(col);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688721)
            
            //--TRIMMABLE-BOUNDARY-START(42950656017)
            $ctor$12(/*int*/ capacity, /*IHashCodeProvider?*/ hashProvider, /*IComparer?*/ comparer)
            {
                super.$ctor$5(capacity, hashProvider, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950656017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656017)
            
            //--TRIMMABLE-BOUNDARY-START(47245623313)
            $ctor$15(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$7(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245623313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623313)
            
            //--TRIMMABLE-BOUNDARY-START(137439936529)
            /*void */ InvalidateCachedArrays()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439936529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._all = null;
                this._allKeys = null;
            }
            //--TRIMMABLE-BOUNDARY-END(137439936529)
            
            //--TRIMMABLE-BOUNDARY-START(107375165457)
            static /*string? */ GetAsOneString(/*ArrayList?*/ list)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let n = (list !== null) ? list.Count : 0;
                if (n === 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                    return $.$cast(list.get_Item(0), $.$$.System.String);
                }
                else if (n > 1)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(list !== null, "list != null");
                    /*StringBuilder*/ let s = new $.$$.System.Text.StringBuilder().$ctor$8($.$cast(list.get_Item(0), $.$$.System.String));
                    for(/*int*/ let i = 1; i < n; i++)
                    {
                        s.Append$3(/*,*/ 44);
                        s.Append$19($.$cast(list.get_Item(i), $.$$.System.String));
                    }
                    return $.$$.System.Text.StringBuilder.ToString.call(s);
                }
                else 
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375165457)
            
            //--TRIMMABLE-BOUNDARY-START(111670132753)
            static /*string[]? */ GetAsStringArray(/*ArrayList?*/ list)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670132753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let n = (list !== null) ? list.Count : 0;
                if (n === 0)
                {
                    return null;
                }
                /*string[]*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                list.CopyTo$2(0, array, 0, n);
                return array;
            }
            //--TRIMMABLE-BOUNDARY-END(111670132753)
            
            //--TRIMMABLE-BOUNDARY-START(51540590609)
            /*void */ Add$1(/*NameValueCollection*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540590609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(c, "c");
                this.InvalidateCachedArrays();
                /*int*/ let n = c.Count;
                for(/*int*/ let i = 0; i < n; i++)
                {
                    /*string?*/ let key = c.GetKey(i);
                    /*string[]?*/ let values = c.GetValues(i);
                    if (values !== null)
                    {
                        for(/*int*/ let j = 0; j < values.length; j++)
                        {
                            this.Add(key, $.$$.System.Array.$ReadT1.call(values, j));
                        }
                    }
                    else 
                    {
                        this.Add(key, null);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540590609)
            
            //--TRIMMABLE-BOUNDARY-START(64425492497)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                this.BaseClear();
            }
            //--TRIMMABLE-BOUNDARY-END(64425492497)
            
            //--TRIMMABLE-BOUNDARY-START(68720459793)
            /*void */ CopyTo(/*Array*/ dest, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720459793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(dest, "dest");
                if ($.$$.System.Array.Rank$get.call(dest) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$scs.System.SR.Arg_MultiRank, "dest");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((dest.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scs.System.SR.Arg_InsufficientSpace);
                }
                /*int*/ let n = this.Count;
                if (this._all === null)
                {
                    /*string?[]*/ let all = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [n], null);
                    for(/*int*/ let i = 0; i < n; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(all, this.Get(i), i);
                        dest.SetValue$2($.$$.System.Array.$ReadT1.call(all, i), ((i + index) | 0));
                    }
                    this._all = all;
                }
                else 
                {
                    for(/*int*/ let i = 0; i < n; i++)
                    {
                        dest.SetValue$2($.$$.System.Array.$ReadT1.call(this._all, i), ((i + index) | 0));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720459793)
            
            //--TRIMMABLE-BOUNDARY-START(128850001937)
            /*bool */ HasKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850001937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.InternalHasKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(128850001937)
            
            //--TRIMMABLE-BOUNDARY-START(133144969233)
            /*bool */ InternalHasKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BaseHasKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(133144969233)
            
            //--TRIMMABLE-BOUNDARY-START(55835557905)
            /*void */ Add(/*string?*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                if (values === null)
                {
                    values = new $.$$.System.Collections.ArrayList().$ctor$3(1);
                    if ($.$$.System.String.op_Inequality(value, null))
                    {
                        values.Add(value);
                    }
                    this.BaseAdd(name, values);
                }
                else 
                {
                    if ($.$$.System.String.op_Inequality(value, null))
                    {
                        values.Add(value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835557905)
            
            //--TRIMMABLE-BOUNDARY-START(73015427089)
            /*string? */ Get$1(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsOneString(values);
            }
            //--TRIMMABLE-BOUNDARY-END(73015427089)
            
            //--TRIMMABLE-BOUNDARY-START(120260067345)
            /*string[]? */ GetValues$1(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260067345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList?*/ let values = $.$cast(this.BaseGet$1(name), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsStringArray(values);
            }
            //--TRIMMABLE-BOUNDARY-END(120260067345)
            
            //--TRIMMABLE-BOUNDARY-START(146029871121)
            /*void */ Set(/*string?*/ name, /*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029871121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.IsReadOnly)
                {
                    throw new $.$$.System.NotSupportedException().$ctor$12($.$scs.System.SR.CollectionReadOnly);
                }
                this.InvalidateCachedArrays();
                /*ArrayList*/ let values = new $.$$.System.Collections.ArrayList().$ctor$3(1);
                values.Add(value);
                this.BaseSet$1(name, values);
            }
            //--TRIMMABLE-BOUNDARY-END(146029871121)
            
            //--TRIMMABLE-BOUNDARY-START(141734903825)
            /*void */ Remove(/*string?*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InvalidateCachedArrays();
                this.BaseRemove(name);
            }
            //--TRIMMABLE-BOUNDARY-END(141734903825)
            
            //--TRIMMABLE-BOUNDARY-START(158914773009)
            /*string?*/ get_Item$1(/*string?*/ name)
            {
                return this.Get$1(name);
            }
            /*void*/ set_Item(/*string?*/ name, /*string?*/ value)
            {
                this.Set(name, value);
            }
            //--TRIMMABLE-BOUNDARY-END(158914773009)
            
            //--TRIMMABLE-BOUNDARY-START(77310394385)
            /*string? */ Get(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310394385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList?*/ let values = $.$cast(this.BaseGet(index), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsOneString(values);
            }
            //--TRIMMABLE-BOUNDARY-END(77310394385)
            
            //--TRIMMABLE-BOUNDARY-START(124555034641)
            /*string[]? */ GetValues(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ArrayList?*/ let values = $.$cast(this.BaseGet(index), $.$$.System.Collections.ArrayList);
                return $.$scs.System.Collections.Specialized.NameValueCollection.GetAsStringArray(values);
            }
            //--TRIMMABLE-BOUNDARY-END(124555034641)
            
            //--TRIMMABLE-BOUNDARY-START(115965100049)
            /*string? */ GetKey(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.BaseGetKey(index);
            }
            //--TRIMMABLE-BOUNDARY-END(115965100049)
            
            //--TRIMMABLE-BOUNDARY-START(163209740305)
            /*string?*/ get_Item(/*int*/ index)
            {
                return this.Get(index);
            }
            //--TRIMMABLE-BOUNDARY-END(163209740305)
            
            //--TRIMMABLE-BOUNDARY-START(60130525201)
            /*string?[] */ get AllKeys()
            {
                return this._allKeys ??= this.BaseGetAllKeys();
            }
            //--TRIMMABLE-BOUNDARY-END(60130525201)
            
            static $h = 983057;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 720913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158914773009),
    {
      "p": 1310721,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490263569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619805713,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$3",
      "d": 983057,
      "h": 158914773009,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914773009),
//--TRIMMABLE-BOUNDARY-START(163209740305),
    {
      "p": 1310721,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080198161,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 983057,
      "h": 163209740305,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163209740305),
//--TRIMMABLE-BOUNDARY-START(60130525201),
    {
      "p": $.$typeArray($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900328977,
        "f": 50331777
      },
      "n": "AllKeys",
      "d": 983057,
      "h": 60130525201,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130525201)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439936529),
    {
      "r": 65537,
      "n": "InvalidateCachedArrays",
      "d": 983057,
      "h": 137439936529,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(137439936529),
//--TRIMMABLE-BOUNDARY-START(107375165457),
    {
      "r": 1310721,
      "p": [
        {
          "n": "list",
          "p": 54329345
        }
      ],
      "n": "GetAsOneString",
      "d": 983057,
      "h": 107375165457,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107375165457),
//--TRIMMABLE-BOUNDARY-START(111670132753),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "p": [
        {
          "n": "list",
          "p": 54329345
        }
      ],
      "n": "GetAsStringArray",
      "d": 983057,
      "h": 111670132753,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111670132753),
//--TRIMMABLE-BOUNDARY-START(51540590609),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 983057
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 983057,
      "h": 51540590609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540590609),
//--TRIMMABLE-BOUNDARY-START(64425492497),
    {
      "r": 65537,
      "n": "Clear",
      "d": 983057,
      "h": 64425492497,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425492497),
//--TRIMMABLE-BOUNDARY-START(68720459793),
    {
      "r": 65537,
      "p": [
        {
          "n": "dest",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 983057,
      "h": 68720459793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720459793),
//--TRIMMABLE-BOUNDARY-START(128850001937),
    {
      "r": 262145,
      "n": "HasKeys",
      "d": 983057,
      "h": 128850001937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850001937),
//--TRIMMABLE-BOUNDARY-START(133144969233),
    {
      "r": 262145,
      "n": "InternalHasKeys",
      "d": 983057,
      "h": 133144969233,
      "f": 16777352
    },
//--TRIMMABLE-BOUNDARY-END(133144969233),
//--TRIMMABLE-BOUNDARY-START(55835557905),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Add",
      "d": 983057,
      "h": 55835557905,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835557905),
//--TRIMMABLE-BOUNDARY-START(73015427089),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Get",
      "o": "@$1",
      "d": 983057,
      "h": 73015427089,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73015427089),
//--TRIMMABLE-BOUNDARY-START(120260067345),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetValues",
      "o": "@$1",
      "d": 983057,
      "h": 120260067345,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120260067345),
//--TRIMMABLE-BOUNDARY-START(146029871121),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Set",
      "d": 983057,
      "h": 146029871121,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(146029871121),
//--TRIMMABLE-BOUNDARY-START(141734903825),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "d": 983057,
      "h": 141734903825,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(141734903825),
//--TRIMMABLE-BOUNDARY-START(77310394385),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "Get",
      "d": 983057,
      "h": 77310394385,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77310394385),
//--TRIMMABLE-BOUNDARY-START(124555034641),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetValues",
      "d": 983057,
      "h": 124555034641,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124555034641),
//--TRIMMABLE-BOUNDARY-START(115965100049),
    {
      "r": 1310721,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "GetKey",
      "d": 983057,
      "h": 115965100049,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115965100049)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950353),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "_all",
      "d": 983057,
      "h": 4295950353,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950353),
//--TRIMMABLE-BOUNDARY-START(8590917649),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "_allKeys",
      "d": 983057,
      "h": 8590917649,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885884945),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 983057,
      "h": 12885884945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885884945),
//--TRIMMABLE-BOUNDARY-START(17180852241),
    {
      "p": [
        {
          "n": "col",
          "p": 983057
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 983057,
      "h": 17180852241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852241),
//--TRIMMABLE-BOUNDARY-START(21475819537),
    {
      "p": [
        {
          "n": "hashProvider",
          "p": 62783489
        },
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 983057,
      "h": 21475819537,
      "f": 16777217,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This constructor has been deprecated. Use NameValueCollection(IEqualityComparer) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475819537),
//--TRIMMABLE-BOUNDARY-START(25770786833),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 983057,
      "h": 25770786833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770786833),
//--TRIMMABLE-BOUNDARY-START(30065754129),
    {
      "p": [
        {
          "n": "equalityComparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$9",
      "d": 983057,
      "h": 30065754129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065754129),
//--TRIMMABLE-BOUNDARY-START(34360721425),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "equalityComparer",
          "p": 62717953
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 983057,
      "h": 34360721425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360721425),
//--TRIMMABLE-BOUNDARY-START(38655688721),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "col",
          "p": 983057
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 983057,
      "h": 38655688721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655688721),
//--TRIMMABLE-BOUNDARY-START(42950656017),
    {
      "p": [
        {
          "n": "capacity",
          "p": 655361
        },
        {
          "n": "hashProvider",
          "p": 62783489
        },
        {
          "n": "comparer",
          "p": 62324737
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 983057,
      "h": 42950656017,
      "f": 16777217,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This constructor has been deprecated. Use NameValueCollection(Int32, IEqualityComparer) instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950656017),
//--TRIMMABLE-BOUNDARY-START(47245623313),
    {
      "p": [
        {
          "n": "info",
          "p": 157941761
        },
        {
          "n": "context",
          "p": 158072833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 983057,
      "h": 47245623313,
      "f": 16777220,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245623313)
  ],
  "i": [62259201,62521345,157351937,157089793
  ],
  "h": 983057
}; }
            static get $b() { return $.$scs.System.Collections.Specialized.NameObjectCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Specialized.NameValueCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983057)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives"))
//--TRIMMABLE-BOUNDARY-END(17)
