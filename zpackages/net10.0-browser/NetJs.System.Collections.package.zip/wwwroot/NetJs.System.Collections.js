
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections", 
    {"h":5,"f":"System.Collections","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Collections","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Collections","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sc.System.Collections.Generic.ICollectionDebugView<>", (T) => $asm.$gt("$sc.System.Collections.Generic.ICollectionDebugView<>", [T], ($self) => class ICollectionDebugView$$ extends $.$$.System.Object
        {
            /*ICollection<T>*/ _collection = null;
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                /*T[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [T]);
                return items;
            }
            static $h = 393221;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.ICollectionDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowKeyNotFound(TKey, /*TKey*/ key)
            {
                throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$box(key, TKey)));
            }
            static /*void */ ThrowDuplicateKey(TKey, /*TKey*/ key)
            {
                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
            }
            static /*void */ ThrowConcurrentOperation()
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_ConcurrentOperationsNotSupported);
            }
            static /*void */ ThrowIndexArgumentOutOfRange()
            {
                throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
            }
            static /*void */ ThrowVersionCheckFailed()
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
            }
            static $h = 3538949;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3538949}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.ThrowHelper`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.IDictionaryDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.IDictionaryDebugView<,>", [TKey, TValue], ($self) => class IDictionaryDebugView$$$ extends $.$$.System.Object
        {
            /*IDictionary<TKey, TValue>*/ _dict = null;
            $ctor$1(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                super.$ctor();
                {
                    this._dict = $.$firstOf(dictionary, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("dictionary") });
                }
                return this;
            }
            /*DebugViewDictionaryItem<TKey, TValue>[] */ get Items()
            {
                /*var*/ let keyValuePairs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [this._dict.System$Collections$Generic$ICollection$$$Count], null);
                this._dict.System$Collections$Generic$ICollection$$$CopyTo(keyValuePairs, 0, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                /*var*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)), null, [keyValuePairs.length], null);
                for(/*int*/ let i = 0; i < items.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(items, new ($.$sc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(keyValuePairs, i)), i);
                }
                return items;
            }
            static $h = 458757;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.IDictionaryDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.ObjectModel.CollectionHelpers", ($self) => class CollectionHelpers
        {
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            static /*void */ CopyTo(T, /*ICollection<T>*/ collection, /*Array*/ array, /*int*/ index)
            {
                $.$sc.System.Collections.ObjectModel.CollectionHelpers.ValidateCopyToArguments(collection.System$Collections$Generic$ICollection$$$Count, array, index);
                let nonGenericCollection;
                let items;
                if ($.$is(collection, $.$$.System.Collections.ICollection, { set $v(v){ nonGenericCollection = v; } }))
                {
                    nonGenericCollection.System$Collections$ICollection$CopyTo(array, index);
                }
                else if ($.$is(array, $.$typeArray(T), { set $v(v){ items = v; } }))
                {
                    collection.System$Collections$Generic$ICollection$$$CopyTo(items, index, [T]);
                }
                else 
                {
                    let objects;
                    if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        var $en4 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                $.$$.System.Array.$WriteT1.call(objects, $.$box(item, T), index++);
                            }
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            static $h = 3276805;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3276805}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.ObjectModel.CollectionHelpers`; }
        });
        
        $asm.$cls("$sc.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections", $.$sc.System.SR.$type.Assembly);
                    $.$sc.System.SR.s_resourceManager = temp;
                }
                return $.$sc.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sc.System.SR.resourceCulture = value;
            }
            static /*string */ get Arg_NonZeroLowerBound()
            {
                return "The lower bound of target array must be zero.";
            }
            static /*string */ get Arg_WrongType()
            {
                return "The value '{0}' is not of type '{1}' and cannot be used in this generic collection.";
            }
            static /*string */ FormatArg_WrongType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The value '{0}' is not of type '{1}' and cannot be used in this generic collection.", arg1, arg2);
            }
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            static /*string */ get ArgumentOutOfRange_SmallCapacity()
            {
                return "capacity was less than the current size.";
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get Argument_AddingDuplicate()
            {
                return "An item with the same key has already been added. Key: {0}";
            }
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            static /*string */ get InvalidOperation_ConcurrentOperationsNotSupported()
            {
                return "Operations that change non-concurrent collections must have exclusive access. A concurrent update was performed on this collection and corrupted its state. The collection's state is no longer correct.";
            }
            static /*string */ get InvalidOperation_EmptyQueue()
            {
                return "Queue empty.";
            }
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                return "Collection was modified after the enumerator was instantiated.";
            }
            static /*string */ get InvalidOperation_EmptyStack()
            {
                return "Stack empty.";
            }
            static /*string */ get InvalidOperation_EnumNotStarted()
            {
                return "Enumeration has not started. Call MoveNext.";
            }
            static /*string */ get InvalidOperation_EnumEnded()
            {
                return "Enumeration already finished.";
            }
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            static /*string */ get NotSupported_ValueCollectionSet()
            {
                return "Mutating a value collection derived from a dictionary is not allowed.";
            }
            static /*string */ get Arg_HTCapacityOverflow()
            {
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            static /*string */ get Arg_InsufficientSpace()
            {
                return "Insufficient space in the target location to copy the information.";
            }
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                return "Only single dimensional arrays are supported for the requested action.";
            }
            static /*string */ get Argument_IncompatibleArrayType()
            {
                return "Target array type is not compatible with the type of items in the collection.";
            }
            static /*string */ get ArgumentOutOfRange_BiggerThanCollection()
            {
                return "Must be less than or equal to the size of the collection.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            static /*string */ get ExternalLinkedListNode()
            {
                return "The LinkedList node does not belong to current LinkedList.";
            }
            static /*string */ get LinkedListEmpty()
            {
                return "The LinkedList is empty.";
            }
            static /*string */ get LinkedListNodeIsAttached()
            {
                return "The LinkedList node already belongs to a LinkedList.";
            }
            static /*string */ get NotSupported_SortedListNestedWrite()
            {
                return "This operation is not supported on SortedList nested types because they require modifying the original SortedList.";
            }
            static /*string */ get SortedSet_LowerValueGreaterThanUpperValue()
            {
                return "Must be less than or equal to upperValue.";
            }
            static /*string */ get Serialization_InvalidOnDeser()
            {
                return "OnDeserialization method was called while the object was not being deserialized.";
            }
            static /*string */ get Serialization_MismatchedCount()
            {
                return "The serialized Count information doesn't match the number of items.";
            }
            static /*string */ get Serialization_MissingKeys()
            {
                return "The keys for this dictionary are missing.";
            }
            static /*string */ get Serialization_MissingValues()
            {
                return "The values for this dictionary are missing.";
            }
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                return "The given key '{0}' was not present in the dictionary.";
            }
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sc.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sc.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3670021;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3670021}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sc.System.Collections.StructuralComparisons", ($self) => class StructuralComparisons
        {
            static /*IComparer */ get StructuralComparer()
            {
                return $.$sc.System.Collections.StructuralComparer.s_instance;
            }
            static /*IEqualityComparer */ get StructuralEqualityComparer()
            {
                return $.$sc.System.Collections.StructuralEqualityComparer.s_instance;
            }
            static $h = 3407877;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3407877}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.StructuralComparisons`; }
        });
        
        $asm.$cls("$sc.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            /*uint*/ static HashCollisionThreshold = 100;
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            /*int*/ static HashPrime = 101;
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            static /*int */ GetPrime(/*int*/ min)
            {
                if (min < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$sc.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$sc.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(2147483587/*MaxPrimeArrayLength*/ === $.$sc.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$sc.System.Collections.HashHelpers.GetPrime(newSize);
            }
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                return 18446744073709551615n / BigInt(divisor) + 1n;
            }
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$$.System.UInt32);
                $.$$.System.Diagnostics.Debug.Assert$2(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            static $h = 3211269;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3211269}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
            }
            static /*IEnumerator<T> */ GetEmptyEnumerator(T)
            {
                return ($.$$.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$$.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$$.System.Array.Empty(T);
            }
            static $h = 327685;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":327685}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.StackDebugView<>", (T) => $asm.$gt("$sc.System.Collections.Generic.StackDebugView<>", [T], ($self) => class StackDebugView$$ extends $.$$.System.Object
        {
            /*Stack<T>*/ _stack = null;
            $ctor$1(/*Stack<T>*/ stack)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stack, "stack");
                    this._stack = stack;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                return this._stack.ToArray();
            }
            static $h = 2949125;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.StackDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 3604485;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3604485}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.PriorityQueueDebugView<,>", (TElement, TPriority) => $asm.$gt("$sc.System.Collections.Generic.PriorityQueueDebugView<,>", [TElement, TPriority], ($self) => class PriorityQueueDebugView$$$ extends $.$$.System.Object
        {
            /*PriorityQueue<TElement, TPriority>*/ _queue = null;
            /*bool*/ _sort = false;
            $ctor$2(/*PriorityQueue<TElement, TPriority>*/ queue)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(queue, "queue");
                    this._queue = queue;
                    this._sort = true;
                }
                return this;
            }
            $ctor$1(/*PriorityQueue<TElement, TPriority>.UnorderedItemsCollection*/ collection)
            {
                super.$ctor();
                {
                    this._queue = $.$firstOf((collection?._queue ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            /*(TElement Element, TPriority Priority)[] */ get Items()
            {
                /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$(TElement, TPriority)))().$ctor$2(this._queue.UnorderedItems);
                if (this._sort)
                {
                    list.Sort$2(new ($.$$.System.Comparison$$($.$$.System.ValueTuple$$$(TElement, TPriority)))().$ctor(this,  (/**/ i1, /*i2*/ i2) =>
                    {
                        return this._queue.Comparer.System$Collections$Generic$IComparer$$$Compare(i1.Item2, i2.Item2, [TPriority]);
                    }, {"r":655361,"p":[{"n":"i1","p":$.$$.System.ValueTuple$$$(TElement, TPriority).$h},{"n":"i2","p":$.$$.System.ValueTuple$$$(TElement, TPriority).$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                }
                return list.ToArray();
            }
            static $h = 1507333;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.PriorityQueueDebugView<${TElement?.$fullName},${TPriority?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.PriorityQueue<,>", (TElement, TPriority) => $asm.$gt("$sc.System.Collections.Generic.PriorityQueue<,>", [TElement, TPriority], ($self) => class PriorityQueue$$$ extends $.$$.System.Object
        {
            /*(TElement Element, TPriority Priority)[]*/ _nodes = null;
            /*IComparer<TPriority>?*/ _comparer = null;
            /*int*/ _size = 0;
            /*int*/ _version = 0;
            /*int*/ static Arity = 4;
            /*int*/ static Log2Arity = 2;
            /*Static constructor*/ static $cctor()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(2/*Log2Arity*/ > 0 && Math.pow(2, 2/*Log2Arity*/) === 4/*Arity*/, "Log2Arity > 0 && Math.Pow(2, Log2Arity) == Arity");
            }
            $ctor$1()
            {
                super.$ctor();
                {
                    this._nodes = $.$$.System.Array.Empty($.$$.System.ValueTuple$$$(TElement, TPriority));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(null);
                }
                return this;
            }
            $ctor$6(/*int*/ initialCapacity)
            {
                this.$ctor$5(initialCapacity, null);
                {
                }
                return this;
            }
            $ctor$2(/*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    this._nodes = $.$$.System.Array.Empty($.$$.System.ValueTuple$$$(TElement, TPriority));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                }
                return this;
            }
            $ctor$5(/*int*/ initialCapacity, /*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCapacity, "initialCapacity");
                    this._nodes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.ValueTuple$$$(TElement, TPriority)), null, [initialCapacity], null);
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                }
                return this;
            }
            $ctor$4(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items)
            {
                this.$ctor$3(items, null);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items, /*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                    this._nodes = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray($.$$.System.ValueTuple$$$(TElement, TPriority), items, $.$ref(() => this._size, ($v) => this._size = $v, $.$$.System.Int32));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                    if (this._size > 1)
                    {
                        this.Heapify();
                    }
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*int */ get Capacity()
            {
                return this._nodes.length;
            }
            /*IComparer<TPriority> */ get Comparer()
            {
                return this._comparer ?? $.$$.System.Collections.Generic.Comparer$$(TPriority).Default;
            }
            /*UnorderedItemsCollection*/ UnorderedItems$ = null;
            /*UnorderedItemsCollection */ get UnorderedItems()
            {
                return this.UnorderedItems$ ??= new ($.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection)().$ctor$1(this);
            }
            /*void */ Enqueue(/*TElement*/ element, /*TPriority*/ priority)
            {
                /*int*/ let currentSize = this._size;
                this._version++;
                if (this._nodes.length === currentSize)
                {
                    this.Grow(((currentSize + 1) | 0));
                }
                this._size = ((currentSize + 1) | 0);
                if (this._comparer === null)
                {
                    this.MoveUpDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), currentSize);
                }
                else 
                {
                    this.MoveUpCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), currentSize);
                }
            }
            /*TElement */ Peek()
            {
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                return $.$$.System.Array.$ReadT1.call(this._nodes, 0).Item1;
            }
            /*TElement */ Dequeue()
            {
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                /*TElement*/ let element = $.$$.System.Array.$ReadT1.call(this._nodes, 0).Item1;
                this.RemoveRootNode();
                return element;
            }
            /*TElement */ DequeueEnqueue(/*TElement*/ element, /*TPriority*/ priority)
            {
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                /*(TElement Element, TPriority Priority)*/ let root = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                if (this._comparer === null)
                {
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(priority, root.Item2) > 0)
                    {
                        this.MoveDownDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                    }
                    else 
                    {
                        $.$$.System.Array.$WriteT1.call(this._nodes, { Item1: element, Item2: priority }, 0);
                    }
                }
                else 
                {
                    if (this._comparer.System$Collections$Generic$IComparer$$$Compare(priority, root.Item2, [TPriority]) > 0)
                    {
                        this.MoveDownCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                    }
                    else 
                    {
                        $.$$.System.Array.$WriteT1.call(this._nodes, { Item1: element, Item2: priority }, 0);
                    }
                }
                this._version++;
                return root.Item1;
            }
            /*bool */ TryDequeue(/*out TElement*/ element, /*out TPriority*/ priority)
            {
                if (this._size !== 0)
                {
                    $.$tupleUnpack(($tp) =>
                    {
                        element.$v = $tp.Item1;
                        priority.$v = $tp.Item2;
                    }).$v = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    this.RemoveRootNode();
                    return true;
                }
                element.$v = $.$default(TElement);
                priority.$v = $.$default(TPriority);
                return false;
            }
            /*bool */ TryPeek(/*out TElement*/ element, /*out TPriority*/ priority)
            {
                if (this._size !== 0)
                {
                    $.$tupleUnpack(($tp) =>
                    {
                        element.$v = $tp.Item1;
                        priority.$v = $tp.Item2;
                    }).$v = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    return true;
                }
                element.$v = $.$default(TElement);
                priority.$v = $.$default(TPriority);
                return false;
            }
            /*TElement */ EnqueueDequeue(/*TElement*/ element, /*TPriority*/ priority)
            {
                if (this._size !== 0)
                {
                    /*(TElement Element, TPriority Priority)*/ let root = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    if (this._comparer === null)
                    {
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(priority, root.Item2) > 0)
                        {
                            this.MoveDownDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                            this._version++;
                            return root.Item1;
                        }
                    }
                    else 
                    {
                        if (this._comparer.System$Collections$Generic$IComparer$$$Compare(priority, root.Item2, [TPriority]) > 0)
                        {
                            this.MoveDownCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                            this._version++;
                            return root.Item1;
                        }
                    }
                }
                return element;
            }
            /*void */ EnqueueRange(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                /*int*/ let count = 0;
                /*var*/ let collection = $.$as(items, $.$$.System.Collections.Generic.ICollection$$($.$$.System.ValueTuple$$$(TElement, TPriority)));
                if (!(collection === null) && (count = collection.System$Collections$Generic$ICollection$$$Count) > ((this._nodes.length - this._size) | 0))
                {
                    this.Grow($.$checked(this._size + count, 1));
                }
                if (this._size === 0)
                {
                    if (!(collection === null))
                    {
                        collection.System$Collections$Generic$ICollection$$$CopyTo(this._nodes, 0, [$.$$.System.ValueTuple$$$(TElement, TPriority)]);
                        this._size = count;
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        /*(TElement, TPriority)[]*/ let nodes = this._nodes;
                        var $en4 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var $t1 = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            /*TElement*/ let element = $t1.Item1;
                            /*TPriority*/ let priority = $t1.Item2;
                            {
                                if (nodes.length === i)
                                {
                                    this.Grow(((i + 1) | 0));
                                    nodes = this._nodes;
                                }
                                $.$$.System.Array.$WriteT1.call(nodes, { Item1: element, Item2: priority }, i++);
                            }
                        }
                        this._size = i;
                    }
                    this._version++;
                    if (this._size > 1)
                    {
                        this.Heapify();
                    }
                }
                else 
                {
                    var $en3 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var $t1 = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        /*TElement*/ let element = $t1.Item1;
                        /*TPriority*/ let priority = $t1.Item2;
                        {
                            this.Enqueue(element, priority);
                        }
                    }
                }
            }
            /*void */ EnqueueRange$1(/*IEnumerable<TElement>*/ elements, /*TPriority*/ priority)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elements, "elements");
                /*int*/ let count;
                let collection;
                if ($.$is(elements, $.$$.System.Collections.Generic.ICollection$$(TElement), { set $v(v){ collection = v; } }) && (count = collection.System$Collections$Generic$ICollection$$$Count) > ((this._nodes.length - this._size) | 0))
                {
                    this.Grow($.$checked(this._size + count, 1));
                }
                if (this._size === 0)
                {
                    /*int*/ let i = 0;
                    /*(TElement, TPriority)[]*/ let nodes = this._nodes;
                    var $en3 = elements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (nodes.length === i)
                            {
                                this.Grow(((i + 1) | 0));
                                nodes = this._nodes;
                            }
                            $.$$.System.Array.$WriteT1.call(nodes, { Item1: element, Item2: priority }, i++);
                        }
                    }
                    this._size = i;
                    this._version++;
                }
                else 
                {
                    var $en3 = elements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Enqueue(element, priority);
                        }
                    }
                }
            }
            /*bool */ Remove(/*TElement*/ element, /*out TElement*/ removedElement, /*out TPriority*/ priority, /*IEqualityComparer<TElement>?*/ equalityComparer)
            {
                /*int*/ let index = this.FindIndex(element, equalityComparer);
                if (index < 0)
                {
                    removedElement.$v = $.$default(TElement);
                    priority.$v = $.$default(TPriority);
                    return false;
                }
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                $.$tupleUnpack(($tp) =>
                {
                    removedElement.$v = $tp.Item1;
                    priority.$v = $tp.Item2;
                }).$v = $.$$.System.Array.$ReadT1.call(nodes, index);
                /*int*/ let newSize = --this._size;
                if (index < newSize)
                {
                    /*(TElement Element, TPriority Priority)*/ let lastNode = $.$$.System.Array.$ReadT1.call(nodes, newSize);
                    if (this._comparer === null)
                    {
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(lastNode.Item2, priority.$v) < 0)
                        {
                            this.MoveUpDefaultComparer(lastNode.Clone(), index);
                        }
                        else 
                        {
                            this.MoveDownDefaultComparer(lastNode.Clone(), index);
                        }
                    }
                    else 
                    {
                        if (this._comparer.System$Collections$Generic$IComparer$$$Compare(lastNode.Item2, priority.$v, [TPriority]) < 0)
                        {
                            this.MoveUpCustomComparer(lastNode.Clone(), index);
                        }
                        else 
                        {
                            this.MoveDownCustomComparer(lastNode.Clone(), index);
                        }
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, new ($.$$.System.ValueTuple$$$(TElement, TPriority))(), newSize);
                this._version++;
                return true;
            }
            /*void */ Clear()
            {
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<(TElement, TPriority)>()) { ... }
                this._size = 0;
                this._version++;
            }
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this._nodes.length < capacity)
                {
                    this.Grow(capacity);
                    this._version++;
                }
                return this._nodes.length;
            }
            /*void */ TrimExcess()
            {
                /*int*/ let threshold = $.$cast((this._nodes.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    $.$$.System.Array.Resize($.$$.System.ValueTuple$$$(TElement, TPriority), $.$ref(() => this._nodes, ($v) => this._nodes = $v, $.$typeArray($.$$.System.ValueTuple$$$(TElement, TPriority))), this._size);
                    this._version++;
                }
            }
            /*void */ Grow(/*int*/ minCapacity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._nodes.length < minCapacity, "_nodes.Length < minCapacity");
                /*int*/ let GrowFactor = 2;
                /*int*/ let MinimumGrow = 4;
                /*int*/ let newcapacity = ((GrowFactor * this._nodes.length) | 0);
                if (BigInt((newcapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newcapacity = $.$$.System.Array.MaxLength;
                }
                newcapacity = $.$$.System.Math.Max$4(newcapacity, ((this._nodes.length + MinimumGrow) | 0));
                if (newcapacity < minCapacity)
                {
                    newcapacity = minCapacity;
                }
                $.$$.System.Array.Resize($.$$.System.ValueTuple$$$(TElement, TPriority), $.$ref(() => this._nodes, ($v) => this._nodes = $v, $.$typeArray($.$$.System.ValueTuple$$$(TElement, TPriority))), newcapacity);
            }
            /*void */ RemoveRootNode()
            {
                /*int*/ let lastNodeIndex = --this._size;
                this._version++;
                if (lastNodeIndex > 0)
                {
                    /*(TElement Element, TPriority Priority)*/ let lastNode = $.$$.System.Array.$ReadT1.call(this._nodes, lastNodeIndex);
                    if (this._comparer === null)
                    {
                        this.MoveDownDefaultComparer(lastNode.Clone(), 0);
                    }
                    else 
                    {
                        this.MoveDownCustomComparer(lastNode.Clone(), 0);
                    }
                }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<(TElement, TPriority)>()) { ... }
            }
            static /*int */ GetParentIndex(/*int*/ index)
            {
                return (((index - 1) | 0)) >> 2/*Log2Arity*/;
            }
            static /*int */ GetFirstChildIndex(/*int*/ index)
            {
                return (((index << 2/*Log2Arity*/) + 1) | 0);
            }
            /*void */ Heapify()
            {
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let lastParentWithChildren = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(((this._size - 1) | 0));
                if (this._comparer === null)
                {
                    for(/*int*/ let index = lastParentWithChildren; index >= 0; --index)
                    {
                        this.MoveDownDefaultComparer($.$$.System.Array.$ReadT1.call(nodes, index), index);
                    }
                }
                else 
                {
                    for(/*int*/ let index = lastParentWithChildren; index >= 0; --index)
                    {
                        this.MoveDownCustomComparer($.$$.System.Array.$ReadT1.call(nodes, index), index);
                    }
                }
            }
            /*void */ MoveUpDefaultComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._comparer === null, "_comparer is null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                while(nodeIndex > 0)
                {
                    /*int*/ let parentIndex = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(nodeIndex);
                    /*(TElement Element, TPriority Priority)*/ let parent = $.$$.System.Array.$ReadT1.call(nodes, parentIndex);
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(node.Item2, parent.Item2) < 0)
                    {
                        $.$$.System.Array.$WriteT1.call(nodes, parent, nodeIndex);
                        nodeIndex = parentIndex;
                    }
                    else 
                    {
                        break;
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            /*void */ MoveUpCustomComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*IComparer<TPriority>*/ let comparer = this._comparer;
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                while(nodeIndex > 0)
                {
                    /*int*/ let parentIndex = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(nodeIndex);
                    /*(TElement Element, TPriority Priority)*/ let parent = $.$$.System.Array.$ReadT1.call(nodes, parentIndex);
                    if (comparer.System$Collections$Generic$IComparer$$$Compare(node.Item2, parent.Item2, [TPriority]) < 0)
                    {
                        $.$$.System.Array.$WriteT1.call(nodes, parent, nodeIndex);
                        nodeIndex = parentIndex;
                    }
                    else 
                    {
                        break;
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            /*void */ MoveDownDefaultComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._comparer === null, "_comparer is null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let size = this._size;
                /*int*/ let i;
                while((i = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetFirstChildIndex(nodeIndex)) < size)
                {
                    /*(TElement Element, TPriority Priority)*/ let minChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                    /*int*/ let minChildIndex = i;
                    /*int*/ let childIndexUpperBound = $.$$.System.Math.Min$4(((i + 4/*Arity*/) | 0), size);
                    while(++i < childIndexUpperBound)
                    {
                        /*(TElement Element, TPriority Priority)*/ let nextChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(nextChild.Item2, minChild.Item2) < 0)
                        {
                            minChild = nextChild.Clone();
                            minChildIndex = i;
                        }
                    }
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(node.Item2, minChild.Item2) <= 0)
                    {
                        break;
                    }
                    $.$$.System.Array.$WriteT1.call(nodes, minChild, nodeIndex);
                    nodeIndex = minChildIndex;
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            /*void */ MoveDownCustomComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*IComparer<TPriority>*/ let comparer = this._comparer;
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let size = this._size;
                /*int*/ let i;
                while((i = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetFirstChildIndex(nodeIndex)) < size)
                {
                    /*(TElement Element, TPriority Priority)*/ let minChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                    /*int*/ let minChildIndex = i;
                    /*int*/ let childIndexUpperBound = $.$$.System.Math.Min$4(((i + 4/*Arity*/) | 0), size);
                    while(++i < childIndexUpperBound)
                    {
                        /*(TElement Element, TPriority Priority)*/ let nextChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextChild.Item2, minChild.Item2, [TPriority]) < 0)
                        {
                            minChild = nextChild.Clone();
                            minChildIndex = i;
                        }
                    }
                    if (comparer.System$Collections$Generic$IComparer$$$Compare(node.Item2, minChild.Item2, [TPriority]) <= 0)
                    {
                        break;
                    }
                    $.$$.System.Array.$WriteT1.call(nodes, minChild, nodeIndex);
                    nodeIndex = minChildIndex;
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            /*int */ FindIndex(/*TElement*/ element, /*IEqualityComparer<TElement>?*/ equalityComparer)
            {
                equalityComparer ??= $.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default;
                /*ReadOnlySpan<(TElement Element, TPriority Priority)>*/ let nodes = $.$$.System.Span$$($.$$.System.ValueTuple$$$(TElement, TPriority)).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.ValueTuple$$$(TElement, TPriority), this._nodes, 0, this._size));
                if (TElement.$type.IsValueType && equalityComparer === $.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default)
                {
                    for(/*int*/ let i = 0; i < nodes.Length; i++)
                    {
                        if ($.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default.Equals$2(element, nodes.get_Item(i).$v.Item1))
                        {
                            return i;
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < nodes.Length; i++)
                    {
                        if (equalityComparer.System$Collections$Generic$IEqualityComparer$$$Equals(element, nodes.get_Item(i).$v.Item1, [TElement]))
                        {
                            return i;
                        }
                    }
                }
                return -1;
            }
            static /*IComparer<TPriority>? */ InitializeComparer(/*IComparer<TPriority>?*/ comparer)
            {
                if (TPriority.$type.IsValueType)
                {
                    if (comparer === $.$$.System.Collections.Generic.Comparer$$(TPriority).Default)
                    {
                        return null;
                    }
                    return comparer;
                }
                else 
                {
                    return comparer ?? $.$$.System.Collections.Generic.Comparer$$(TPriority).Default;
                }
            }
            static $_UnorderedItemsCollection;
            static get UnorderedItemsCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority);
                return $cls.$_UnorderedItemsCollection ??= $asm.$ncls("$sc.System.Collections.Generic.PriorityQueue$$$.UnorderedItemsCollection", ($self) => class UnorderedItemsCollection extends $.$$.System.Object
                {
                    /*PriorityQueue<TElement, TPriority>*/ _queue = null;
                    $ctor$1(/*PriorityQueue<TElement, TPriority>*/ queue)
                    {
                        super.$ctor();
                        this._queue = queue;
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this._queue._size;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return this;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        if (index < 0 || index > array.length)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                        }
                        if (((array.length - index) | 0) < this._queue._size)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._queue._nodes, 0, array, index, this._queue._size);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.PriorityQueue$$$.UnorderedItemsCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            /*PriorityQueue<TElement, TPriority>*/  get _queue() { return this.$getField(0, 4); }
                            /*PriorityQueue<TElement, TPriority>*/  set _queue(value) { this.$setField(0, 4, value); }
                            /*int*/  get _version() { return this.$getField(4, 4); }
                            /*int*/  set _version(value) { this.$setField(4, 4, value); }
                            /*int*/  get _index() { return this.$getField(8, 4); }
                            /*int*/  set _index(value) { this.$setField(8, 4, value); }
                            /*(TElement, TPriority)*/  get _current() { return this.$getField(12, 8); }
                            /*(TElement, TPriority)*/  set _current(value) { this.$setField(12, 8, value); }
                            $ctor$3(/*PriorityQueue<TElement, TPriority>*/ queue)
                            {
                                super.$ctor$1();
                                {
                                    this._queue = queue;
                                    this._index = 0;
                                    this._version = queue._version;
                                    this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                                }
                                return this;
                            }
                            /*void */ Dispose()
                            {
                            }
                            /*bool */ MoveNext()
                            {
                                /*PriorityQueue<TElement, TPriority>*/ let localQueue = this._queue;
                                if (this._version !== localQueue._version)
                                {
                                    $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                                }
                                if ((this._index >>> 0) < (localQueue._size >>> 0))
                                {
                                    this._current = $.$$.System.Array.$ReadT1.call(localQueue._nodes, this._index);
                                    this._index++;
                                    return true;
                                }
                                this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                                this._index = -1;
                                return false;
                            }
                            /*(TElement Element, TPriority Priority) */ get Current()
                            {
                                return this._current;
                            }
                            /*object */ get System$Collections$IEnumerator$Current()
                            {
                                return this._current;
                            }
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                if (this._version !== this._queue._version)
                                {
                                    $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                                }
                                this._index = 0;
                                this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<(TElement Element, TPriority Priority)>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._queue = this._queue;
                                copy._version = this._version;
                                copy._index = this._index;
                                copy._current = this._current.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._queue = null;
                                this._version = 0;
                                this._index = 0;
                                this._current = $.$default($.$$.System.ValueTuple$$$(TElement, TPriority));
                            }
                            static $h = 1441797;
                            static $z = 20;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>.UnorderedItemsCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    /*Enumerator */ GetEnumerator()
                    {
                        return new ($.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection.Enumerator)().$ctor$3(this._queue);
                    }
                    /*IEnumerator<(TElement Element, TPriority Priority)> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this._queue.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.ValueTuple$$$(TElement, TPriority)) : this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.ValueTuple$$$(TElement, TPriority)]);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<(TElement Element, TPriority Priority)>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    static $h = 1376261;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>.UnorderedItemsCollection`; }
                }, $cls, ($v) => $cls.$_UnorderedItemsCollection = $v);
            }
            static $h = 1310725;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.DictionaryKeyCollectionDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DictionaryKeyCollectionDebugView<,>", [TKey, TValue], ($self) => class DictionaryKeyCollectionDebugView$$$ extends $.$$.System.Object
        {
            /*ICollection<TKey>*/ _collection = null;
            $ctor$1(/*ICollection<TKey>*/ collection)
            {
                super.$ctor();
                {
                    this._collection = $.$firstOf(collection, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            /*TKey[] */ get Items()
            {
                /*TKey[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [TKey]);
                return items;
            }
            static $h = 196613;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.DictionaryKeyCollectionDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.DictionaryValueCollectionDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DictionaryValueCollectionDebugView<,>", [TKey, TValue], ($self) => class DictionaryValueCollectionDebugView$$$ extends $.$$.System.Object
        {
            /*ICollection<TValue>*/ _collection = null;
            $ctor$1(/*ICollection<TValue>*/ collection)
            {
                super.$ctor();
                {
                    this._collection = $.$firstOf(collection, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            /*TValue[] */ get Items()
            {
                /*TValue[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [TValue]);
                return items;
            }
            static $h = 262149;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.DictionaryValueCollectionDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.LinkedListNode<>", (T) => $asm.$gt("$sc.System.Collections.Generic.LinkedListNode<>", [T], ($self) => class LinkedListNode$$ extends $.$$.System.Object
        {
            /*LinkedList<T>?*/ list = null;
            /*LinkedListNode<T>?*/ next = null;
            /*LinkedListNode<T>?*/ prev = null;
            /*T*/ item = $.$default(T);
            $ctor$2(/*T*/ value)
            {
                super.$ctor();
                {
                    this.item = value;
                }
                return this;
            }
            $ctor$1(/*LinkedList<T>*/ list, /*T*/ value)
            {
                super.$ctor();
                {
                    this.list = list;
                    this.item = value;
                }
                return this;
            }
            /*LinkedList<T>? */ get List()
            {
                return this.list;
            }
            /*LinkedListNode<T>? */ get Next()
            {
                return this.next === null || this.next === this.list.head ? null : this.next;
            }
            /*LinkedListNode<T>? */ get Previous()
            {
                return this.prev === null || this === this.list.head ? null : this.prev;
            }
            /*T */ get Value()
            {
                return this.item;
            }
            /*T */ set Value(value)
            {
                this.item = value;
            }
            /*ref T */ get ValueRef()
            {
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT(T, () => this.item, ($v) => this.item = $v, null);
            }
            /*void */ Invalidate()
            {
                this.list = null;
                this.next = null;
                this.prev = null;
            }
            static $h = 720901;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.LinkedListNode<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.StructuralEqualityComparer", ($self) => class StructuralEqualityComparer extends $.$$.System.Object
        {
            /*StructuralEqualityComparer*/ static s_instance = null;
            /*bool */ Equals$2(/*object?*/ x, /*object?*/ y)
            {
                if (x !== null)
                {
                    /*IStructuralEquatable?*/ let seObj = $.$as(x, $.$$.System.Collections.IStructuralEquatable);
                    if (seObj !== null)
                    {
                        return seObj.System$Collections$IStructuralEquatable$Equals(y, this);
                    }
                    if (y !== null)
                    {
                        return $.$$.System.Object.Equals$1.call(x, y);
                    }
                    else 
                    {
                        return false;
                    }
                }
                if (y !== null)
                {
                    return false;
                }
                return true;
            }
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                if (obj === null)
                {
                    return 0;
                }
                /*IStructuralEquatable?*/ let seObj = $.$as(obj, $.$$.System.Collections.IStructuralEquatable);
                if (seObj !== null)
                {
                    return seObj.System$Collections$IStructuralEquatable$GetHashCode(this);
                }
                return $.$$.System.Object.GetHashCode.call(obj);
            }
            //Generated interface implemetation for System.Collections.IEqualityComparer.Equals(object?, object?)
            System$Collections$IEqualityComparer$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEqualityComparer.GetHashCode(object)
            System$Collections$IEqualityComparer$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_instance = new $.$sc.System.Collections.StructuralEqualityComparer().$ctor$1();
                }
            }
            static $h = 3473413;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3473413}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer ]; }
            static get $fullName() { return `System.Collections.StructuralEqualityComparer`; }
        });
        
        $asm.$cls("$sc.System.Collections.StructuralComparer", ($self) => class StructuralComparer extends $.$$.System.Object
        {
            /*StructuralComparer*/ static s_instance = null;
            /*int */ Compare(/*object?*/ x, /*object?*/ y)
            {
                if (x === null)
                {
                    return y === null ? 0 : -1;
                }
                if (y === null)
                {
                    return 1;
                }
                /*IStructuralComparable?*/ let scX = $.$as(x, $.$$.System.Collections.IStructuralComparable);
                if (scX !== null)
                {
                    return scX.System$Collections$IStructuralComparable$CompareTo(y, this);
                }
                return $.$$.System.Collections.Generic.Comparer$$($.$$.System.Object).Default.Compare(x, y);
            }
            //Generated interface implemetation for System.Collections.IComparer.Compare(object?, object?)
            System$Collections$IComparer$Compare()
            {
                return this.Compare(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_instance = new $.$sc.System.Collections.StructuralComparer().$ctor$1();
                }
            }
            static $h = 3342341;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3342341}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer ]; }
            static get $fullName() { return `System.Collections.StructuralComparer`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.Stack<>", (T) => $asm.$gt("$sc.System.Collections.Generic.Stack<>", [T], ($self) => class Stack$$ extends $.$$.System.Object
        {
            /*T[]*/ _array = null;
            /*int*/ _size = 0;
            /*int*/ _version = 0;
            /*int*/ static DefaultCapacity = 4;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._array = $.$$.System.Array.Empty(T);
                }
                return this;
            }
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [capacity], null);
                }
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._array = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, collection, $.$ref(() => this._size, ($v) => this._size = $v, $.$$.System.Int32));
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*int */ get Capacity()
            {
                return this._array.length;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*void */ Clear()
            {
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                this._size = 0;
                this._version++;
            }
            /*bool */ Contains(/*T*/ item)
            {
                return this._size !== 0 && $.$$.System.Array.LastIndexOf$4(T, this._array, item, ((this._size - 1) | 0)) !== -1;
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ arrayIndex)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(array !== this._array, "array != _array");
                /*int*/ let srcIndex = 0;
                /*int*/ let dstIndex = ((arrayIndex + this._size) | 0);
                while(srcIndex < this._size)
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(this._array, srcIndex++), --dstIndex);
                }
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ arrayIndex)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                }
                try
                {
                    $.$$.System.Array.Copy$2(this._array, 0, array, arrayIndex, this._size);
                    $.$$.System.Array.Reverse(array, arrayIndex, this._size);
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                }
            }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.Stack$$(T).Enumerator)().$ctor$3(this);
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(T) : this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            /*void */ TrimExcess()
            {
                /*int*/ let threshold = $.$cast((this._array.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), this._size);
                }
            }
            /*void */ TrimExcess$1(/*int*/ capacity)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, capacity, this._size, "capacity");
                if (capacity === this._array.length)
                {
                    return;
                }
                $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), capacity);
            }
            /*T */ Peek()
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    this.ThrowForEmptyStack();
                }
                return $.$$.System.Array.$ReadT1.call(array, size);
            }
            /*bool */ TryPeek(/*out T*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$$.System.Array.$ReadT1.call(array, size);
                return true;
            }
            /*T */ Pop()
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    this.ThrowForEmptyStack();
                }
                this._version++;
                this._size = size;
                /*T*/ let item = $.$$.System.Array.$ReadT1.call(array, size);
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                return item;
            }
            /*bool */ TryPop(/*out T*/ result)
            {
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = $.$default(T);
                    return false;
                }
                this._version++;
                this._size = size;
                result.$v = $.$$.System.Array.$ReadT1.call(array, size);
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                return true;
            }
            /*void */ Push(/*T*/ item)
            {
                /*int*/ let size = this._size;
                /*T[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$$.System.Array.$WriteT1.call(array, item, size);
                    this._version++;
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            /*void */ PushWithResize(/*T*/ item)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._size === this._array.length, "_size == _array.Length");
                this.Grow(((this._size + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._array, item, this._size);
                this._version++;
                this._size++;
            }
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this._array.length < capacity)
                {
                    this.Grow(capacity);
                }
                return this._array.length;
            }
            /*void */ Grow(/*int*/ capacity)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._array.length < capacity, "_array.Length < capacity");
                /*int*/ let newcapacity = this._array.length === 0 ? 4/*DefaultCapacity*/ : ((2 * this._array.length) | 0);
                if (BigInt((newcapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newcapacity = $.$$.System.Array.MaxLength;
                }
                if (newcapacity < capacity)
                {
                    newcapacity = capacity;
                }
                $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), newcapacity);
            }
            /*T[] */ ToArray()
            {
                if (this._size === 0)
                {
                    return $.$$.System.Array.Empty(T);
                }
                /*T[]*/ let objArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._size], null);
                /*int*/ let i = 0;
                while(i < this._size)
                {
                    $.$$.System.Array.$WriteT1.call(objArray, $.$$.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), i);
                    i++;
                }
                return objArray;
            }
            /*void */ ThrowForEmptyStack()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._size === 0, "_size == 0");
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyStack);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.Stack$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.Stack$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*Stack<T>*/  get _stack() { return this.$getField(0, 4); }
                    /*Stack<T>*/  set _stack(value) { this.$setField(0, 4, value); }
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    /*int*/  get _index() { return this.$getField(8, 4); }
                    /*int*/  set _index(value) { this.$setField(8, 4, value); }
                    /*T?*/  get _currentElement() { return this.$getField(12, 4); }
                    /*T?*/  set _currentElement(value) { this.$setField(12, 4, value); }
                    $ctor$3(/*Stack<T>*/ stack)
                    {
                        super.$ctor$1();
                        {
                            this._stack = stack;
                            this._version = stack._version;
                            this._index = stack.Count;
                            this._currentElement = $.$default(T);
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        return this._index = -1;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._stack._version)
                        {
                            $.$sc.System.Collections.Generic.Stack$$(T).Enumerator.ThrowInvalidVersion();
                        }
                        /*T[]*/ let array = this._stack._array;
                        /*int*/ let index = ((this._index - 1) | 0);
                        if ((index >>> 0) < (array.length >>> 0))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(index < this._stack.Count, "index < _stack.Count");
                            this._currentElement = $.$$.System.Array.$ReadT1.call(array, index);
                            this._index = index;
                            return true;
                        }
                        this._currentElement = $.$default(T);
                        this._index = -1;
                        return false;
                    }
                    /*T */ get Current()
                    {
                        return this._currentElement;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return $.$box(this.Current, T);
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._stack._version)
                        {
                            $.$sc.System.Collections.Generic.Stack$$(T).Enumerator.ThrowInvalidVersion();
                        }
                        this._index = this._stack.Count;
                        this._currentElement = $.$default(T);
                    }
                    static /*void */ ThrowInvalidVersion()
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._stack = this._stack;
                        copy._version = this._version;
                        copy._index = this._index;
                        copy._currentElement = this._currentElement;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._stack = null;
                        this._version = 0;
                        this._index = 0;
                        this._currentElement = null;
                    }
                    static $h = 2883589;
                    static $z = 16;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.Stack$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.Stack<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            static $h = 2818053;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.Stack<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.LinkedList<>", (T) => $asm.$gt("$sc.System.Collections.Generic.LinkedList<>", [T], ($self) => class LinkedList$$ extends $.$$.System.Object
        {
            /*LinkedListNode<T>?*/ head = null;
            /*int*/ count = 0;
            /*int*/ version = 0;
            /*SerializationInfo?*/ _siInfo = null;
            /*string*/ static VersionName = null;
            /*string*/ static CountName = null;
            /*string*/ static ValuesName = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddLast$1(item);
                        }
                    }
                }
                return this;
            }
            $ctor$3(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    this._siInfo = info;
                }
                return this;
            }
            /*int */ get Count()
            {
                return this.count;
            }
            /*LinkedListNode<T>? */ get First()
            {
                return this.head;
            }
            /*LinkedListNode<T>? */ get Last()
            {
                return this.head?.prev ?? null;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*T*/ value)
            {
                this.AddLast$1(value);
            }
            /*LinkedListNode<T> */ AddAfter$1(/*LinkedListNode<T>*/ node, /*T*/ value)
            {
                this.ValidateNode(node);
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(node.list, value);
                this.InternalInsertNodeBefore(node.next, result);
                return result;
            }
            /*void */ AddAfter(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                this.ValidateNode(node);
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(newNode);
                this.InternalInsertNodeBefore(node.next, newNode);
                newNode.list = this;
            }
            /*LinkedListNode<T> */ AddBefore$1(/*LinkedListNode<T>*/ node, /*T*/ value)
            {
                this.ValidateNode(node);
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(node.list, value);
                this.InternalInsertNodeBefore(node, result);
                if (node === this.head)
                {
                    this.head = result;
                }
                return result;
            }
            /*void */ AddBefore(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                this.ValidateNode(node);
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(newNode);
                this.InternalInsertNodeBefore(node, newNode);
                newNode.list = this;
                if (node === this.head)
                {
                    this.head = newNode;
                }
            }
            /*LinkedListNode<T> */ AddFirst$1(/*T*/ value)
            {
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(this, value);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(result);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, result);
                    this.head = result;
                }
                return result;
            }
            /*void */ AddFirst(/*LinkedListNode<T>*/ node)
            {
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(node);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(node);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, node);
                    this.head = node;
                }
                node.list = this;
            }
            /*LinkedListNode<T> */ AddLast$1(/*T*/ value)
            {
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(this, value);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(result);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, result);
                }
                return result;
            }
            /*void */ AddLast(/*LinkedListNode<T>*/ node)
            {
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(node);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(node);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, node);
                }
                node.list = this;
            }
            /*void */ Clear()
            {
                /*LinkedListNode<T>?*/ let current = this.head;
                while(current !== null)
                {
                    /*LinkedListNode<T>*/ let temp = current;
                    current = current.Next;
                    temp.Invalidate();
                }
                this.head = null;
                this.count = 0;
                this.version++;
            }
            /*bool */ Contains(/*T*/ value)
            {
                return this.Find(value) !== null;
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (index > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_BiggerThanCollection);
                }
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_InsufficientSpace);
                }
                /*LinkedListNode<T>?*/ let node = this.head;
                if (node !== null)
                {
                    do
                    {
                        $.$$.System.Array.$WriteT1.call(array, node.item, index++);
                        node = node.next;
                    }
                    while(node !== this.head);
                }
            }
            /*LinkedListNode<T>? */ Find(/*T*/ value)
            {
                /*LinkedListNode<T>?*/ let node = this.head;
                /*EqualityComparer<T>*/ let c = $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                if (node !== null)
                {
                    if ($.$box(value, T) !== null)
                    {
                        do
                        {
                            if (c.Equals$2(node.item, value))
                            {
                                return node;
                            }
                            node = node.next;
                        }
                        while(node !== this.head);
                    }
                    else 
                    {
                        do
                        {
                            if ($.$box(node.item, T) === null)
                            {
                                return node;
                            }
                            node = node.next;
                        }
                        while(node !== this.head);
                    }
                }
                return null;
            }
            /*LinkedListNode<T>? */ FindLast(/*T*/ value)
            {
                if (this.head === null)
                {
                    return null;
                }
                /*LinkedListNode<T>?*/ let last = this.head.prev;
                /*LinkedListNode<T>?*/ let node = last;
                /*EqualityComparer<T>*/ let c = $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                if (node !== null)
                {
                    if ($.$box(value, T) !== null)
                    {
                        do
                        {
                            if (c.Equals$2(node.item, value))
                            {
                                return node;
                            }
                            node = node.prev;
                        }
                        while(node !== last);
                    }
                    else 
                    {
                        do
                        {
                            if ($.$box(node.item, T) === null)
                            {
                                return node;
                            }
                            node = node.prev;
                        }
                        while(node !== last);
                    }
                }
                return null;
            }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.LinkedList$$(T).Enumerator)().$ctor$3(this);
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(T) : this.GetEnumerator();
            }
            /*bool */ Remove$1(/*T*/ value)
            {
                /*LinkedListNode<T>?*/ let node = this.Find(value);
                if (node !== null)
                {
                    this.InternalRemoveNode(node);
                    return true;
                }
                return false;
            }
            /*void */ Remove(/*LinkedListNode<T>*/ node)
            {
                this.ValidateNode(node);
                this.InternalRemoveNode(node);
            }
            /*void */ RemoveFirst()
            {
                if (this.head === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListEmpty);
                }
                this.InternalRemoveNode(this.head);
            }
            /*void */ RemoveLast()
            {
                if (this.head === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListEmpty);
                }
                this.InternalRemoveNode(this.head.prev);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$7("Version"/*VersionName*/, this.version);
                info.AddValue$7("Count"/*CountName*/, this.count);
                if (this.count !== 0)
                {
                    /*T[]*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.count], null);
                    this.CopyTo(array, 0);
                    info.AddValue$9("Data"/*ValuesName*/, array, $.$typeArray(T).$type);
                }
            }
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                if (this._siInfo === null)
                {
                    return;
                }
                /*int*/ let realVersion = this._siInfo.GetInt32("Version"/*VersionName*/);
                /*int*/ let count = this._siInfo.GetInt32("Count"/*CountName*/);
                if (count !== 0)
                {
                    /*T[]?*/ let array = $.$cast(this._siInfo.GetValue("Data"/*ValuesName*/, $.$typeArray(T).$type), $.$typeArray(T));
                    if (array === null)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MissingValues);
                    }
                    for(/*int*/ let i = 0; i < array.length; i++)
                    {
                        this.AddLast$1($.$$.System.Array.$ReadT1.call(array, i));
                    }
                }
                else 
                {
                    this.head = null;
                }
                this.version = realVersion;
                this._siInfo = null;
            }
            /*void */ InternalInsertNodeBefore(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                newNode.next = node;
                newNode.prev = node.prev;
                node.prev.next = newNode;
                node.prev = newNode;
                this.version++;
                this.count++;
            }
            /*void */ InternalInsertNodeToEmptyList(/*LinkedListNode<T>*/ newNode)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.head === null && this.count === 0, "LinkedList must be empty when this method is called!");
                newNode.next = newNode;
                newNode.prev = newNode;
                this.head = newNode;
                this.version++;
                this.count++;
            }
            /*void */ InternalRemoveNode(/*LinkedListNode<T>*/ node)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(node.list === this, "Deleting the node from another list!");
                $.$$.System.Diagnostics.Debug.Assert$2(this.head !== null, "This method shouldn't be called on empty list!");
                if (node.next === node)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.count === 1 && this.head === node, "this should only be true for a list with only one node");
                    this.head = null;
                }
                else 
                {
                    node.next.prev = node.prev;
                    node.prev.next = node.next;
                    if (this.head === node)
                    {
                        this.head = node.next;
                    }
                }
                node.Invalidate();
                this.count--;
                this.version++;
            }
            static /*void */ ValidateNewNode(/*LinkedListNode<T>*/ node)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if (node.list !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListNodeIsAttached);
                }
            }
            /*void */ ValidateNode(/*LinkedListNode<T>*/ node)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if (node.list !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.ExternalLinkedListNode);
                }
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_InsufficientSpace);
                }
                /*T[]?*/ let tArray = $.$as(array, $.$typeArray(T));
                if (tArray !== null)
                {
                    this.CopyTo(tArray, index);
                }
                else 
                {
                    /*object?[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    /*LinkedListNode<T>?*/ let node = this.head;
                    try
                    {
                        if (node !== null)
                        {
                            do
                            {
                                $.$$.System.Array.$WriteT1.call(objects, $.$box(node.item, T), index++);
                                node = node.next;
                            }
                            while(node !== this.head);
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.LinkedList$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.LinkedList$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*LinkedList<T>*/  get _list() { return this.$getField(0, 4); }
                    /*LinkedList<T>*/  set _list(value) { this.$setField(0, 4, value); }
                    /*LinkedListNode<T>?*/  get _node() { return this.$getField(4, 4); }
                    /*LinkedListNode<T>?*/  set _node(value) { this.$setField(4, 4, value); }
                    /*int*/  get _version() { return this.$getField(8, 4); }
                    /*int*/  set _version(value) { this.$setField(8, 4, value); }
                    /*T?*/  get _current() { return this.$getField(12, 4); }
                    /*T?*/  set _current(value) { this.$setField(12, 4, value); }
                    /*int*/  get _index() { return this.$getField(16, 4); }
                    /*int*/  set _index(value) { this.$setField(16, 4, value); }
                    $ctor$3(/*LinkedList<T>*/ list)
                    {
                        super.$ctor$1();
                        {
                            this._list = list;
                            this._version = list.version;
                            this._node = list.head;
                            this._current = $.$default(T);
                            this._index = 0;
                        }
                        return this;
                    }
                    /*T */ get Current()
                    {
                        return this._current;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this._index === 0 || (this._index === ((this._list.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current, T);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._node === null)
                        {
                            this._index = ((this._list.Count + 1) | 0);
                            return false;
                        }
                        ++this._index;
                        this._current = this._node.item;
                        this._node = this._node.next;
                        if (this._node === this._list.head)
                        {
                            this._node = null;
                        }
                        return true;
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._current = $.$default(T);
                        this._node = this._list.head;
                        this._index = 0;
                    }
                    /*void */ Dispose()
                    {
                    }
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._list = this._list;
                        copy._node = this._node;
                        copy._version = this._version;
                        copy._current = this._current;
                        copy._index = this._index;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._list = null;
                        this._node = null;
                        this._version = 0;
                        this._current = null;
                        this._index = 0;
                    }
                    static $h = 655365;
                    static $z = 20;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.LinkedList$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.LinkedList<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Contains(T)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.CopyTo(T[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Remove(T)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                return this.GetObjectData(...arguments);
            }
            //Generated interface implemetation for System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object?)
            System$Runtime$Serialization$IDeserializationCallback$OnDeserialization()
            {
                return this.OnDeserialization(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.VersionName = "Version";
                }
                {
                    this.CountName = "Count";
                }
                {
                    this.ValuesName = "Data";
                }
            }
            static $h = 589829;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.LinkedList<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.SortedSet<>", (T) => $asm.$gt("$sc.System.Collections.Generic.SortedSet<>", [T], ($self) => class SortedSet$$ extends $.$$.System.Object
        {
            static $_TreeSubSet;
            static get TreeSubSet()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_TreeSubSet ??= $asm.$ncls("$sc.System.Collections.Generic.SortedSet$$.TreeSubSet", ($self) => class TreeSubSet extends $.$sc.System.Collections.Generic.SortedSet$$(T)
                {
                    /*SortedSet<T>*/ _underlying = null;
                    /*T?*/ _min = null;
                    /*T?*/ _max = null;
                    /*int*/ _countVersion = 0;
                    /*bool*/ _lBoundActive = false;
                    /*bool*/ _uBoundActive = false;
                    /*bool */ versionUpToDate()
                    {
                        return (this.version === this._underlying.version);
                    }
                    $ctor$6(/*SortedSet<T>*/ Underlying, /*T?*/ Min, /*T?*/ Max, /*bool*/ lowerBoundActive, /*bool*/ upperBoundActive)
                    {
                        super.$ctor$2(Underlying.Comparer);
                        {
                            this._underlying = Underlying;
                            this._min = Min;
                            this._max = Max;
                            this._lBoundActive = lowerBoundActive;
                            this._uBoundActive = upperBoundActive;
                            this.root = this._underlying.FindRange(this._min, this._max, this._lBoundActive, this._uBoundActive);
                            this.count = 0;
                            this.version = -1;
                            this._countVersion = -1;
                        }
                        return this;
                    }
                    /*bool */ AddIfNotPresent(/*T*/ item)
                    {
                        if (!this.IsWithinRange(item))
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("item");
                        }
                        /*bool*/ let ret = this._underlying.AddIfNotPresent(item);
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return ret;
                    }
                    /*bool */ Contains(/*T*/ item)
                    {
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return super.Contains(item);
                    }
                    /*bool */ DoRemove(/*T*/ item)
                    {
                        if (!this.IsWithinRange(item))
                        {
                            return false;
                        }
                        /*bool*/ let ret = this._underlying.Remove(item);
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return ret;
                    }
                    /*void */ Clear()
                    {
                        if (this.Count === 0)
                        {
                            return;
                        }
                        /*List<T>*/ let toRemove = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                        this.BreadthFirstTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                        {
                            toRemove.Add(n.Item$2);
                            return true;
                        }, {"r":262145,"p":[{"n":"n","p":$.$sc.System.Collections.Generic.SortedSet$$(T).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                        while(toRemove.Count !== 0)
                        {
                            this._underlying.Remove(toRemove.get_Item(toRemove.Count - 1));
                            toRemove.RemoveAt(((toRemove.Count - 1) | 0));
                        }
                        this.root = null;
                        this.count = 0;
                        this.version = this._underlying.version;
                    }
                    /*bool */ IsWithinRange(/*T*/ item)
                    {
                        /*int*/ let comp = this._lBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, item, [T]) : -1;
                        if (comp > 0)
                        {
                            return false;
                        }
                        comp = this._uBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, item, [T]) : 1;
                        return comp >= 0;
                    }
                    /*T */ get MinInternal()
                    {
                        this.VersionCheck(false);
                        /*Node?*/ let current = this.root;
                        /*T?*/ let result = $.$default(T);
                        while(current !== null)
                        {
                            /*int*/ let comp = this._lBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$2, [T]) : -1;
                            if (comp > 0)
                            {
                                current = current.Right;
                            }
                            else 
                            {
                                result = current.Item$2;
                                if (comp === 0)
                                {
                                    break;
                                }
                                current = current.Left;
                            }
                        }
                        return result;
                    }
                    /*T */ get MaxInternal()
                    {
                        this.VersionCheck(false);
                        /*Node?*/ let current = this.root;
                        /*T?*/ let result = $.$default(T);
                        while(current !== null)
                        {
                            /*int*/ let comp = this._uBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, current.Item$2, [T]) : 1;
                            if (comp < 0)
                            {
                                current = current.Left;
                            }
                            else 
                            {
                                result = current.Item$2;
                                if (comp === 0)
                                {
                                    break;
                                }
                                current = current.Right;
                            }
                        }
                        return result;
                    }
                    /*bool */ InOrderTreeWalk(/*TreeWalkPredicate<T>*/ action)
                    {
                        this.VersionCheck(false);
                        if (this.root === null)
                        {
                            return true;
                        }
                        /*Stack<Node>*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((this.count + 1) | 0))) | 0));
                        /*Node?*/ let current = this.root;
                        while(current !== null)
                        {
                            if (this.IsWithinRange(current.Item$2))
                            {
                                stack.Push(current);
                                current = current.Left;
                            }
                            else if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$2, [T]) > 0)
                            {
                                current = current.Right;
                            }
                            else 
                            {
                                current = current.Left;
                            }
                        }
                        while(stack.Count !== 0)
                        {
                            current = stack.Pop();
                            if (!action.Invoke(current))
                            {
                                return false;
                            }
                            /*Node?*/ let node = current.Right;
                            while(node !== null)
                            {
                                if (this.IsWithinRange(node.Item$2))
                                {
                                    stack.Push(node);
                                    node = node.Left;
                                }
                                else if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, node.Item$2, [T]) > 0)
                                {
                                    node = node.Right;
                                }
                                else 
                                {
                                    node = node.Left;
                                }
                            }
                        }
                        return true;
                    }
                    /*bool */ BreadthFirstTreeWalk(/*TreeWalkPredicate<T>*/ action)
                    {
                        this.VersionCheck(false);
                        if (this.root === null)
                        {
                            return true;
                        }
                        /*Queue<Node>*/ let processQueue = new ($.$$.System.Collections.Generic.Queue$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$1();
                        processQueue.Enqueue(this.root);
                        /*Node*/ let current;
                        while(processQueue.Count !== 0)
                        {
                            current = processQueue.Dequeue();
                            if (this.IsWithinRange(current.Item$2) && !action.Invoke(current))
                            {
                                return false;
                            }
                            if (current.Left !== null && (!this._lBoundActive || this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$2, [T]) < 0))
                            {
                                processQueue.Enqueue(current.Left);
                            }
                            if (current.Right !== null && (!this._uBoundActive || this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, current.Item$2, [T]) > 0))
                            {
                                processQueue.Enqueue(current.Right);
                            }
                        }
                        return true;
                    }
                    /*SortedSet<T>.Node? */ FindNode(/*T*/ item)
                    {
                        if (!this.IsWithinRange(item))
                        {
                            return null;
                        }
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return super.FindNode(item);
                    }
                    /*int */ InternalIndexOf(/*T*/ item)
                    {
                        /*int*/ let count = -1;
                        var $en4 = this.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var i = $en4.Current;
                            {
                                count++;
                                if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(item, i, [T]) === 0)
                                {
                                    return count;
                                }
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return -1;
                    }
                    /*void */ VersionCheck(/*bool*/ updateCount)
                    {
                        return this.VersionCheckImpl(updateCount);
                    }
                    /*void */ VersionCheckImpl(/*bool*/ updateCount)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._underlying !== null, "_underlying != null");
                        if (this.version !== this._underlying.version)
                        {
                            this.root = this._underlying.FindRange(this._min, this._max, this._lBoundActive, this._uBoundActive);
                            this.version = this._underlying.version;
                        }
                        if (updateCount && this._countVersion !== this._underlying.version)
                        {
                            this.count = 0;
                            this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                            {
                                this.count++;
                                return true;
                            }, {"r":262145,"p":[{"n":"n","p":$.$sc.System.Collections.Generic.SortedSet$$(T).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                            this._countVersion = this._underlying.version;
                        }
                    }
                    /*int */ TotalCount()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this._underlying !== null, "_underlying != null");
                        return this._underlying.Count;
                    }
                    /*SortedSet<T> */ GetViewBetween(/*T?*/ lowerValue, /*T?*/ upperValue)
                    {
                        if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, lowerValue, [T]) > 0)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("lowerValue");
                        }
                        if (this._uBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, upperValue, [T]) < 0)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("upperValue");
                        }
                        return $.$cast(this._underlying.GetViewBetween(lowerValue, upperValue), $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                    }
                    /*void */ IntersectWithEnumerable(/*IEnumerable<T>*/ other)
                    {
                        super.IntersectWithEnumerable(other);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                    }
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        return this.GetObjectData(info, context);
                    }
                    /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    /*void */ OnDeserialization(/*object?*/ sender)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    static $h = 2686981;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"d":$.$sc.System.Collections.Generic.SortedSet$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$sc.System.Collections.Generic.SortedSet$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.TreeSubSet`; }
                }, $cls, ($v) => $cls.$_TreeSubSet = $v);
            }
            /*Node?*/ root = null;
            /*IComparer<T>*/ comparer = null;
            /*int*/ count = 0;
            /*int*/ version = 0;
            /*SerializationInfo?*/ siInfo = null;
            /*string*/ static ComparerName = null;
            /*string*/ static CountName = null;
            /*string*/ static ItemsName = null;
            /*string*/ static VersionName = null;
            /*int*/ static StackAllocThreshold = 100;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(T).Default;
                }
                return this;
            }
            $ctor$2(/*IComparer<T>?*/ comparer)
            {
                super.$ctor();
                {
                    this.comparer = comparer ?? $.$$.System.Collections.Generic.Comparer$$(T).Default;
                }
                return this;
            }
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                this.$ctor$3(collection, $.$$.System.Collections.Generic.Comparer$$(T).Default);
                {
                }
                return this;
            }
            $ctor$3(/*IEnumerable<T>*/ collection, /*IComparer<T>?*/ comparer)
            {
                this.$ctor$2(comparer);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    /*SortedSet<T>?*/ let sortedSet = $.$as(collection, $.$sc.System.Collections.Generic.SortedSet$$(T));
                    if (sortedSet !== null && !($.$is(sortedSet, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet)) && this.HasEqualComparer(sortedSet))
                    {
                        if (sortedSet.Count > 0)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(sortedSet.root !== null, "sortedSet.root != null");
                            this.count = sortedSet.count;
                            this.root = sortedSet.root.DeepClone(this.count);
                        }
                        return this;
                    }
                    /*int*/ let count;
                    /*T[]*/ let elements = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, collection, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    if (count > 0)
                    {
                        comparer = this.comparer;
                        $.$$.System.Array.Sort$10(T, elements, 0, count, comparer);
                        /*int*/ let index = 1;
                        for(/*int*/ let i = 1; i < count; i++)
                        {
                            if (comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(elements, i), $.$$.System.Array.$ReadT1.call(elements, ((i - 1) | 0)), [T]) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(elements, $.$$.System.Array.$ReadT1.call(elements, i), index++);
                            }
                        }
                        count = index;
                        this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(elements, 0, ((count - 1) | 0), null);
                        this.count = count;
                    }
                }
                return this;
            }
            $ctor$5(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                this.siInfo = info;
                return this;
            }
            /*void */ AddAllElements(/*IEnumerable<T>*/ collection)
            {
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!this.Contains(item))
                        {
                            this.Add(item);
                        }
                    }
                }
            }
            /*void */ RemoveAllElements(/*IEnumerable<T>*/ collection)
            {
                /*T?*/ let min = this.Min;
                /*T?*/ let max = this.Max;
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!(this.comparer.System$Collections$Generic$IComparer$$$Compare(item, min, [T]) < 0 || this.comparer.System$Collections$Generic$IComparer$$$Compare(item, max, [T]) > 0) && this.Contains(item))
                        {
                            this.Remove(item);
                        }
                    }
                }
            }
            /*bool */ ContainsAllElements(/*IEnumerable<T>*/ collection)
            {
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!this.Contains(item))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            /*bool */ InOrderTreeWalk(/*TreeWalkPredicate<T>*/ action)
            {
                if (this.root === null)
                {
                    return true;
                }
                /*var*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((this.Count + 1) | 0))) | 0));
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    stack.Push(current);
                    current = current.Left;
                }
                while(stack.Count !== 0)
                {
                    current = stack.Pop();
                    if (!action.Invoke(current))
                    {
                        return false;
                    }
                    /*Node?*/ let node = current.Right;
                    while(node !== null)
                    {
                        stack.Push(node);
                        node = node.Left;
                    }
                }
                return true;
            }
            /*bool */ BreadthFirstTreeWalk(/*TreeWalkPredicate<T>*/ action)
            {
                if (this.root === null)
                {
                    return true;
                }
                /*var*/ let processQueue = new ($.$$.System.Collections.Generic.Queue$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$1();
                processQueue.Enqueue(this.root);
                /*Node*/ let current;
                while(processQueue.Count !== 0)
                {
                    current = processQueue.Dequeue();
                    if (!action.Invoke(current))
                    {
                        return false;
                    }
                    if (current.Left !== null)
                    {
                        processQueue.Enqueue(current.Left);
                    }
                    if (current.Right !== null)
                    {
                        processQueue.Enqueue(current.Right);
                    }
                }
                return true;
            }
            /*int */ get Count()
            {
                this.VersionCheck(true);
                return this.count;
            }
            /*IComparer<T> */ get Comparer()
            {
                return this.comparer;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*void */ VersionCheck(/*bool*/ updateCount)
            {
            }
            /*int */ TotalCount()
            {
                return this.Count;
            }
            /*bool */ IsWithinRange(/*T*/ item)
            {
                return true;
            }
            /*bool */ Add(/*T*/ item)
            {
                return this.AddIfNotPresent(item);
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*T*/ item)
            {
                return this.Add(item);
            }
            /*bool */ AddIfNotPresent(/*T*/ item)
            {
                if (this.root === null)
                {
                    this.root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(item, 0/*NodeColor.Black*/);
                    this.count = 1;
                    this.version++;
                    return true;
                }
                /*Node?*/ let current = this.root;
                /*Node?*/ let parent = null;
                /*Node?*/ let grandParent = null;
                /*Node?*/ let greatGrandParent = null;
                this.version++;
                /*int*/ let order = 0;
                while(current !== null)
                {
                    order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$2, [T]);
                    if (order === 0)
                    {
                        this.root.ColorBlack();
                        return false;
                    }
                    if (current.Is4Node)
                    {
                        current.Split4Node();
                        if ($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(parent))
                        {
                            this.InsertionBalance(current, $.$ref(() => parent, ($v) => parent = $v, $.$sc.System.Collections.Generic.SortedSet$$(T).Node), grandParent, greatGrandParent);
                        }
                    }
                    greatGrandParent = grandParent;
                    grandParent = parent;
                    parent = current;
                    current = (order < 0) ? current.Left : current.Right;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(parent !== null, "parent != null");
                /*Node*/ let node = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(item, 1/*NodeColor.Red*/);
                if (order > 0)
                {
                    parent.Right = node;
                }
                else 
                {
                    parent.Left = node;
                }
                if (parent.IsRed)
                {
                    this.InsertionBalance(node, $.$ref(() => parent, ($v) => parent = $v, $.$sc.System.Collections.Generic.SortedSet$$(T).Node), grandParent, greatGrandParent);
                }
                this.root.ColorBlack();
                ++this.count;
                return true;
            }
            /*bool */ Remove(/*T*/ item)
            {
                return this.DoRemove(item);
            }
            /*bool */ DoRemove(/*T*/ item)
            {
                if (this.root === null)
                {
                    return false;
                }
                this.version++;
                /*Node?*/ let current = this.root;
                /*Node?*/ let parent = null;
                /*Node?*/ let grandParent = null;
                /*Node?*/ let match = null;
                /*Node?*/ let parentOfMatch = null;
                /*bool*/ let foundMatch = false;
                while(current !== null)
                {
                    if (current.Is2Node)
                    {
                        if (parent === null)
                        {
                            current.ColorRed();
                        }
                        else 
                        {
                            /*Node*/ let sibling = parent.GetSibling(current);
                            if (sibling.IsRed)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(parent.IsBlack, "parent.IsBlack");
                                if (parent.Right === sibling)
                                {
                                    parent.RotateLeft();
                                }
                                else 
                                {
                                    parent.RotateRight();
                                }
                                parent.ColorRed();
                                sibling.ColorBlack();
                                this.ReplaceChildOrRoot(grandParent, parent, sibling);
                                grandParent = sibling;
                                if (parent === match)
                                {
                                    parentOfMatch = sibling;
                                }
                                sibling = parent.GetSibling(current);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullBlack(sibling), "Node.IsNonNullBlack(sibling)");
                            if (sibling.Is2Node)
                            {
                                parent.Merge2Nodes();
                            }
                            else 
                            {
                                /*Node*/ let newGrandParent = parent.Rotate(parent.GetRotation(current, sibling));
                                newGrandParent.Color = parent.Color;
                                parent.ColorBlack();
                                current.ColorRed();
                                this.ReplaceChildOrRoot(grandParent, parent, newGrandParent);
                                if (parent === match)
                                {
                                    parentOfMatch = newGrandParent;
                                }
                            }
                        }
                    }
                    /*int*/ let order = foundMatch ? -1 : this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$2, [T]);
                    if (order === 0)
                    {
                        foundMatch = true;
                        match = current;
                        parentOfMatch = parent;
                    }
                    grandParent = parent;
                    parent = current;
                    current = order < 0 ? current.Left : current.Right;
                }
                if (match !== null)
                {
                    this.ReplaceNode(match, parentOfMatch, parent, grandParent);
                    --this.count;
                }
                this.root?.ColorBlack();
                return foundMatch;
            }
            /*void */ Clear()
            {
                this.root = null;
                this.count = 0;
                ++this.version;
            }
            /*bool */ Contains(/*T*/ item)
            {
                return this.FindNode(item) !== null;
            }
            /*void */ CopyTo$2(/*T[]*/ array)
            {
                return this.CopyTo(array, 0, this.Count);
            }
            /*void */ CopyTo$1(/*T[]*/ array, /*int*/ index)
            {
                return this.CopyTo(array, index, this.Count);
            }
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                if (count > ((array.length - index) | 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                count += index;
                this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*node*/ node) =>
                {
                    if (index >= count)
                    {
                        return false;
                    }
                    $.$$.System.Array.$WriteT1.call(array, node.Item$2, index++);
                    return true;
                }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$(T).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                /*T[]?*/ let tarray = $.$as(array, $.$typeArray(T));
                if (tarray !== null)
                {
                    this.CopyTo$1(tarray, index);
                }
                else 
                {
                    /*object?[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$2, T), index++);
                            return true;
                        }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$(T).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.SortedSet$$(T).Enumerator)().$ctor$4(this);
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            /*void */ InsertionBalance(/*Node*/ current, /*ref Node*/ parent, /*Node*/ grandParent, /*Node*/ greatGrandParent)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(parent.$v !== null, "parent != null");
                $.$$.System.Diagnostics.Debug.Assert$2(grandParent !== null, "grandParent != null");
                /*bool*/ let parentIsOnRight = grandParent.Right === parent.$v;
                /*bool*/ let currentIsOnRight = parent.$v.Right === current;
                /*Node*/ let newChildOfGreatGrandParent;
                if (parentIsOnRight === currentIsOnRight)
                {
                    newChildOfGreatGrandParent = currentIsOnRight ? grandParent.RotateLeft() : grandParent.RotateRight();
                }
                else 
                {
                    newChildOfGreatGrandParent = currentIsOnRight ? grandParent.RotateLeftRight() : grandParent.RotateRightLeft();
                    parent.$v = greatGrandParent;
                }
                grandParent.ColorRed();
                newChildOfGreatGrandParent.ColorBlack();
                this.ReplaceChildOrRoot(greatGrandParent, grandParent, newChildOfGreatGrandParent);
            }
            /*void */ ReplaceChildOrRoot(/*Node?*/ parent, /*Node*/ child, /*Node*/ newChild)
            {
                if (parent !== null)
                {
                    parent.ReplaceChild(child, newChild);
                }
                else 
                {
                    this.root = newChild;
                }
            }
            /*void */ ReplaceNode(/*Node*/ match, /*Node*/ parentOfMatch, /*Node*/ successor, /*Node*/ parentOfSuccessor)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(match !== null, "match != null");
                if (successor === match)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(match.Right === null, "match.Right == null");
                    successor = match.Left;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(parentOfSuccessor !== null, "parentOfSuccessor != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(successor.Left === null, "successor.Left == null");
                    $.$$.System.Diagnostics.Debug.Assert$2((successor.Right === null && successor.IsRed) || (successor.Right.IsRed && successor.IsBlack), "(successor.Right == null && successor.IsRed) || (successor.Right!.IsRed && successor.IsBlack)");
                    successor.Right?.ColorBlack();
                    if (parentOfSuccessor !== match)
                    {
                        parentOfSuccessor.Left = successor.Right;
                        successor.Right = match.Right;
                    }
                    successor.Left = match.Left;
                }
                if (successor !== null)
                {
                    successor.Color = match.Color;
                }
                this.ReplaceChildOrRoot(parentOfMatch, match, successor);
            }
            /*Node? */ FindNode(/*T*/ item)
            {
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    /*int*/ let order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$2, [T]);
                    if (order === 0)
                    {
                        return current;
                    }
                    current = order < 0 ? current.Left : current.Right;
                }
                return null;
            }
            /*int */ InternalIndexOf(/*T*/ item)
            {
                /*Node?*/ let current = this.root;
                /*int*/ let count = 0;
                while(current !== null)
                {
                    /*int*/ let order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$2, [T]);
                    if (order === 0)
                    {
                        return count;
                    }
                    current = order < 0 ? current.Left : current.Right;
                    count = order < 0 ? (((((2 * count) | 0) + 1) | 0)) : (((((2 * count) | 0) + 2) | 0));
                }
                return -1;
            }
            /*Node? */ FindRange$1(/*T?*/ $from, /*T?*/ to)
            {
                return this.FindRange($from, to, true, true);
            }
            /*Node? */ FindRange(/*T?*/ $from, /*T?*/ to, /*bool*/ lowerBoundActive, /*bool*/ upperBoundActive)
            {
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    if (lowerBoundActive && this.comparer.System$Collections$Generic$IComparer$$$Compare($from, current.Item$2, [T]) > 0)
                    {
                        current = current.Right;
                    }
                    else 
                    {
                        if (upperBoundActive && this.comparer.System$Collections$Generic$IComparer$$$Compare(to, current.Item$2, [T]) < 0)
                        {
                            current = current.Left;
                        }
                        else 
                        {
                            return current;
                        }
                    }
                }
                return null;
            }
            /*void */ UpdateVersion()
            {
                return ++this.version;
            }
            static /*IEqualityComparer<SortedSet<T>> */ CreateSetComparer()
            {
                return $.$sc.System.Collections.Generic.SortedSet$$(T).CreateSetComparer$1(null);
            }
            static /*IEqualityComparer<SortedSet<T>> */ CreateSetComparer$1(/*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                return new ($.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T))().$ctor$2(memberEqualityComparer);
            }
            static /*bool */ SortedSetEquals(/*SortedSet<T>?*/ set1, /*SortedSet<T>?*/ set2, /*IComparer<T>*/ comparer)
            {
                if (set1 === null)
                {
                    return set2 === null;
                }
                if (set2 === null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(set1 !== null, "set1 != null");
                    return false;
                }
                if (set1.HasEqualComparer(set2))
                {
                    return set1.Count === set2.Count && set1.SetEquals(set2);
                }
                /*bool*/ let found;
                var $en2 = set1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item1 = $en2.Current;
                    {
                        found = false;
                        var $en4 = set2.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item2 = $en4.Current;
                            {
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(item1, item2, [T]) === 0)
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                        if (!found)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            /*bool */ HasEqualComparer(/*SortedSet<T>*/ other)
            {
                return this.Comparer === other.Comparer || $.$$.System.Object.Equals$1.call(this.Comparer, other.Comparer);
            }
            /*void */ UnionWith(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                /*TreeSubSet?*/ let treeSubset = $.$as(this, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                if (treeSubset !== null)
                {
                    this.VersionCheck(false);
                }
                if (asSorted !== null && treeSubset === null && this.Count === 0)
                {
                    /*SortedSet<T>*/ let dummy = new ($.$sc.System.Collections.Generic.SortedSet$$(T))().$ctor$3(asSorted, this.comparer);
                    this.root = dummy.root;
                    this.count = dummy.count;
                    this.version++;
                    return;
                }
                if (asSorted !== null && treeSubset === null && this.HasEqualComparer(asSorted) && (asSorted.Count > $.trunc(this.Count / 2)))
                {
                    /*T[]*/ let merged = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((asSorted.Count + this.Count) | 0)], null);
                    /*int*/ let c = 0;
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext(), theirsEnded = !theirs.MoveNext();
                    while(!mineEnded && !theirsEnded)
                    {
                        /*int*/ let comp = this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]);
                        if (comp < 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, mine.Current, c++);
                            mineEnded = !mine.MoveNext();
                        }
                        else if (comp === 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            mineEnded = !mine.MoveNext();
                            theirsEnded = !theirs.MoveNext();
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            theirsEnded = !theirs.MoveNext();
                        }
                    }
                    if (!mineEnded || !theirsEnded)
                    {
                        /*Enumerator*/ let remaining = (mineEnded ? theirs : mine);
                        do
                        {
                            $.$$.System.Array.$WriteT1.call(merged, remaining.Current, c++);
                        }
                        while(remaining.MoveNext());
                    }
                    this.root = null;
                    this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(merged, 0, ((c - 1) | 0), null);
                    this.count = c;
                    this.version++;
                }
                else 
                {
                    this.AddAllElements(other);
                }
            }
            static /*Node? */ ConstructRootFromSortedArray(/*T[]*/ arr, /*int*/ startIndex, /*int*/ endIndex, /*Node?*/ redNode)
            {
                /*int*/ let size = ((((endIndex - startIndex) | 0) + 1) | 0);
                /*Node*/ let root;
                switch(size)
                {
                    case 0:
                    return null;
                    case 1:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    if (redNode !== null)
                    {
                        root.Left = redNode;
                    }
                    break;
                    case 2:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    root.Right = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, endIndex), 0/*NodeColor.Black*/);
                    root.Right.ColorRed();
                    if (redNode !== null)
                    {
                        root.Left = redNode;
                    }
                    break;
                    case 3:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, ((startIndex + 1) | 0)), 0/*NodeColor.Black*/);
                    root.Left = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    root.Right = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, endIndex), 0/*NodeColor.Black*/);
                    if (redNode !== null)
                    {
                        root.Left.Left = redNode;
                    }
                    break;
                    default:
                    /*int*/ let midpt = ($.trunc((((startIndex + endIndex) | 0)) / 2));
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, midpt), 0/*NodeColor.Black*/);
                    root.Left = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, startIndex, ((midpt - 1) | 0), redNode);
                    root.Right = size % 2 === 0 ? $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, ((midpt + 2) | 0), endIndex, new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, ((midpt + 1) | 0)), 1/*NodeColor.Red*/)) : $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, ((midpt + 1) | 0), endIndex, null);
                    break;
                }
                return root;
            }
            /*void */ IntersectWith(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return;
                }
                if (other === this)
                {
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                /*TreeSubSet?*/ let treeSubset = $.$as(this, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                if (treeSubset !== null)
                {
                    this.VersionCheck(false);
                }
                if (asSorted !== null && treeSubset === null && this.HasEqualComparer(asSorted))
                {
                    /*T[]*/ let merged = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.Count], null);
                    /*int*/ let c = 0;
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext(), theirsEnded = !theirs.MoveNext();
                    /*T?*/ let max = this.Max;
                    while(!mineEnded && !theirsEnded && this.Comparer.System$Collections$Generic$IComparer$$$Compare(theirs.Current, max, [T]) <= 0)
                    {
                        /*int*/ let comp = this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]);
                        if (comp < 0)
                        {
                            mineEnded = !mine.MoveNext();
                        }
                        else if (comp === 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            mineEnded = !mine.MoveNext();
                            theirsEnded = !theirs.MoveNext();
                        }
                        else 
                        {
                            theirsEnded = !theirs.MoveNext();
                        }
                    }
                    this.root = null;
                    this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(merged, 0, ((c - 1) | 0), null);
                    this.count = c;
                    this.version++;
                }
                else 
                {
                    this.IntersectWithEnumerable(other);
                }
            }
            /*void */ IntersectWithEnumerable(/*IEnumerable<T>*/ other)
            {
                /*List<T>*/ let toSave = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$3(this.Count);
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this.Contains(item))
                        {
                            toSave.Add(item);
                        }
                    }
                }
                this.Clear();
                var $en2 = toSave.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        this.Add(item);
                    }
                }
            }
            /*void */ ExceptWith(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.count === 0)
                {
                    return;
                }
                if (other === this)
                {
                    this.Clear();
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.comparer.System$Collections$Generic$IComparer$$$Compare(asSorted.Max, this.Min, [T]) >= 0 && this.comparer.System$Collections$Generic$IComparer$$$Compare(asSorted.Min, this.Max, [T]) <= 0)
                    {
                        /*T?*/ let min = this.Min;
                        /*T?*/ let max = this.Max;
                        var $en4 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this.comparer.System$Collections$Generic$IComparer$$$Compare(item, min, [T]) < 0)
                                {
                                    continue;
                                }
                                if (this.comparer.System$Collections$Generic$IComparer$$$Compare(item, max, [T]) > 0)
                                {
                                    break;
                                }
                                this.Remove(item);
                            }
                        }
                    }
                }
                else 
                {
                    this.RemoveAllElements(other);
                }
            }
            /*void */ SymmetricExceptWith(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    this.UnionWith(other);
                    return;
                }
                if (other === this)
                {
                    this.Clear();
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    this.SymmetricExceptWithSameComparer$1(asSorted);
                }
                else 
                {
                    /*int*/ let length;
                    /*T[]*/ let elements = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, other, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32));
                    $.$$.System.Array.Sort$10(T, elements, 0, length, this.Comparer);
                    this.SymmetricExceptWithSameComparer(elements, length);
                }
            }
            /*void */ SymmetricExceptWithSameComparer$1(/*SortedSet<T>*/ other)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(other !== null, "other != null");
                $.$$.System.Diagnostics.Debug.Assert$2(this.HasEqualComparer(other), "HasEqualComparer(other)");
                var $en2 = other.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*bool*/ let result = this.Contains(item) ? this.Remove(item) : this.Add(item);
                        $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                    }
                }
            }
            /*void */ SymmetricExceptWithSameComparer(/*T[]*/ other, /*int*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(other !== null, "other != null");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && count <= other.length, "count >= 0 && count <= other.Length");
                if (count === 0)
                {
                    return;
                }
                /*T*/ let previous = $.$$.System.Array.$ReadT1.call(other, 0);
                for(/*int*/ let i = 0; i < count; i++)
                {
                    while(i < count && i !== 0 && this.comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(other, i), previous, [T]) === 0)
                    {
                        i++;
                    }
                    if (i >= count)
                    {
                        break;
                    }
                    /*T*/ let current = $.$$.System.Array.$ReadT1.call(other, i);
                    /*bool*/ let result = this.Contains(current) ? this.Remove(current) : this.Add(current);
                    $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                    previous = current;
                }
            }
            /*bool */ IsSubsetOf(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count > asSorted.Count)
                    {
                        return false;
                    }
                    return this.IsSubsetOfSortedSetWithSameComparer(asSorted);
                }
                else 
                {
                    /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, false);
                    return result.UniqueCount === this.Count && result.UnfoundCount >= 0;
                }
            }
            /*bool */ IsSubsetOfSortedSetWithSameComparer(/*SortedSet<T>*/ asSorted)
            {
                /*SortedSet<T>*/ let prunedOther = asSorted.GetViewBetween(this.Min, this.Max);
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        if (!prunedOther.Contains(item))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            /*bool */ IsProperSubsetOf(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }))
                {
                    if (this.Count === 0)
                    {
                        return c.System$Collections$ICollection$Count > 0;
                    }
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count >= asSorted.Count)
                    {
                        return false;
                    }
                    return this.IsSubsetOfSortedSetWithSameComparer(asSorted);
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, false);
                return result.UniqueCount === this.Count && result.UnfoundCount > 0;
            }
            /*bool */ IsSupersetOf(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }) && c.System$Collections$ICollection$Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count < asSorted.Count)
                    {
                        return false;
                    }
                    /*SortedSet<T>*/ let pruned = this.GetViewBetween(asSorted.Min, asSorted.Max);
                    var $en3 = asSorted.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            if (!pruned.Contains(item))
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                }
                return this.ContainsAllElements(other);
            }
            /*bool */ IsProperSupersetOf(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return false;
                }
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }) && c.System$Collections$ICollection$Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (asSorted.Count >= this.Count)
                    {
                        return false;
                    }
                    /*SortedSet<T>*/ let pruned = this.GetViewBetween(asSorted.Min, asSorted.Max);
                    var $en3 = asSorted.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            if (!pruned.Contains(item))
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, true);
                return result.UniqueCount < this.Count && result.UnfoundCount === 0;
            }
            /*bool */ SetEquals(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext();
                    /*bool*/ let theirsEnded = !theirs.MoveNext();
                    while(!mineEnded && !theirsEnded)
                    {
                        if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]) !== 0)
                        {
                            return false;
                        }
                        mineEnded = !mine.MoveNext();
                        theirsEnded = !theirs.MoveNext();
                    }
                    return mineEnded && theirsEnded;
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, true);
                return result.UniqueCount === this.Count && result.UnfoundCount === 0;
            }
            /*bool */ Overlaps(/*IEnumerable<T>*/ other)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return false;
                }
                let c;
                if ($.$is(other, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ c = v; } }) && c.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return false;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted) && (this.comparer.System$Collections$Generic$IComparer$$$Compare(this.Min, asSorted.Max, [T]) > 0 || this.comparer.System$Collections$Generic$IComparer$$$Compare(this.Max, asSorted.Min, [T]) < 0))
                {
                    return false;
                }
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this.Contains(item))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*ElementCount */ CheckUniqueAndUnfoundElements(/*IEnumerable<T>*/ other, /*bool*/ returnIfUnfound)
            {
                /*ElementCount*/ let result;
                if (this.Count === 0)
                {
                    /*int*/ let numElementsInOther = 0;
                    var $en3 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            numElementsInOther++;
                            break;
                        }
                    }
                    result.UniqueCount = 0;
                    result.UnfoundCount = numElementsInOther;
                    return result;
                }
                /*int*/ let originalLastIndex = this.Count;
                /*int*/ let intArrayLength = $.$sc.System.Collections.Generic.BitHelper.ToIntArrayLength(originalLastIndex);
                /*Span<int>*/ let span = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Int32, 100/*StackAllocThreshold*/, null);
                /*BitHelper*/ let bitHelper = (intArrayLength >>> 0) <= 100/*StackAllocThreshold*/ ? new $.$sc.System.Collections.Generic.BitHelper().$ctor$3(span.Slice(0, intArrayLength), true) : new $.$sc.System.Collections.Generic.BitHelper().$ctor$3($.$$.System.Span$$($.$$.System.Int32).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [intArrayLength], null)), false);
                /*int*/ let UnfoundCount = 0;
                /*int*/ let uniqueFoundCount = 0;
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*int*/ let index = this.InternalIndexOf(item);
                        if (index >= 0)
                        {
                            if (!bitHelper.IsMarked(index))
                            {
                                bitHelper.MarkBit(index);
                                uniqueFoundCount++;
                            }
                        }
                        else 
                        {
                            UnfoundCount++;
                            if (returnIfUnfound)
                            {
                                break;
                            }
                        }
                    }
                }
                result.UniqueCount = uniqueFoundCount;
                result.UnfoundCount = UnfoundCount;
                return result;
            }
            /*int */ RemoveWhere(/*Predicate<T>*/ match)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                /*List<T>*/ let matches = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$3(this.Count);
                this.BreadthFirstTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                {
                    if (match.Invoke(n.Item$2))
                    {
                        matches.Add(n.Item$2);
                    }
                    return true;
                }, {"r":262145,"p":[{"n":"n","p":$.$sc.System.Collections.Generic.SortedSet$$(T).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                /*int*/ let actuallyRemoved = 0;
                for(/*int*/ let i = ((matches.Count - 1) | 0); i >= 0; i--)
                {
                    if (this.Remove(matches.get_Item(i)))
                    {
                        actuallyRemoved++;
                    }
                }
                return actuallyRemoved;
            }
            /*T? */ get Min()
            {
                return this.MinInternal;
            }
            /*T? */ get MinInternal()
            {
                if (this.root === null)
                {
                    return $.$default(T);
                }
                /*Node*/ let current = this.root;
                while(current.Left !== null)
                {
                    current = current.Left;
                }
                return current.Item$2;
            }
            /*T? */ get Max()
            {
                return this.MaxInternal;
            }
            /*T? */ get MaxInternal()
            {
                if (this.root === null)
                {
                    return $.$default(T);
                }
                /*Node*/ let current = this.root;
                while(current.Right !== null)
                {
                    current = current.Right;
                }
                return current.Item$2;
            }
            /*IEnumerable<T> */ Reverse()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*Enumerator*/ let e = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Enumerator)().$ctor$3(this, true);
                    while(e.MoveNext())
                    {
                        yield e.Current;
                    }
                }.bind(this));
            }
            /*SortedSet<T> */ GetViewBetween(/*T?*/ lowerValue, /*T?*/ upperValue)
            {
                if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(lowerValue, upperValue, [T]) > 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.SortedSet_LowerValueGreaterThanUpperValue, "lowerValue");
                }
                return new ($.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet)().$ctor$6(this, lowerValue, upperValue, true, true);
            }
            /*bool */ versionUpToDate()
            {
                return true;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                return this.GetObjectData(info, context);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$7("Count"/*CountName*/, this.count);
                info.AddValue$9("Comparer"/*ComparerName*/, this.comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type);
                info.AddValue$7("Version"/*VersionName*/, this.version);
                if (this.root !== null)
                {
                    /*T[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.Count], null);
                    this.CopyTo$1(items, 0);
                    info.AddValue$9("Items"/*ItemsName*/, items, $.$typeArray(T).$type);
                }
            }
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
                return this.OnDeserialization(sender);
            }
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                if (this.comparer !== null)
                {
                    return;
                }
                if (this.siInfo === null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_InvalidOnDeser);
                }
                this.comparer = $.$cast(this.siInfo.GetValue("Comparer"/*ComparerName*/, $.$$.System.Collections.Generic.IComparer$$(T).$type), $.$$.System.Collections.Generic.IComparer$$(T));
                /*int*/ let savedCount = this.siInfo.GetInt32("Count"/*CountName*/);
                if (savedCount !== 0)
                {
                    /*T[]?*/ let items = $.$cast(this.siInfo.GetValue("Items"/*ItemsName*/, $.$typeArray(T).$type), $.$typeArray(T));
                    if (items === null)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MissingValues);
                    }
                    for(/*int*/ let i = 0; i < items.length; i++)
                    {
                        this.Add($.$$.System.Array.$ReadT1.call(items, i));
                    }
                }
                this.version = this.siInfo.GetInt32("Version"/*VersionName*/);
                if (this.count !== savedCount)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MismatchedCount);
                }
                this.siInfo = null;
            }
            static $_Node;
            static get Node()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_Node ??= $asm.$ncls("$sc.System.Collections.Generic.SortedSet$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    $ctor$1(/*T*/ item, /*NodeColor*/ color)
                    {
                        super.$ctor();
                        {
                            this.Item$2 = item;
                            this.Color = color;
                        }
                        return this;
                    }
                    static /*bool */ IsNonNullBlack(/*Node?*/ node)
                    {
                        return node !== null && node.IsBlack;
                    }
                    static /*bool */ IsNonNullRed(/*Node?*/ node)
                    {
                        return node !== null && node.IsRed;
                    }
                    static /*bool */ IsNullOrBlack(/*Node?*/ node)
                    {
                        return node === null || node.IsBlack;
                    }
                    /*T*/ Item$2 = $.$default(T);
                    /*Node?*/ Left = null;
                    /*Node?*/ Right = null;
                    /*NodeColor*/ Color = 0;
                    /*bool */ get IsBlack()
                    {
                        return this.Color === 0/*NodeColor.Black*/;
                    }
                    /*bool */ get IsRed()
                    {
                        return this.Color === 1/*NodeColor.Red*/;
                    }
                    /*bool */ get Is2Node()
                    {
                        return this.IsBlack && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNullOrBlack(this.Left) && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNullOrBlack(this.Right);
                    }
                    /*bool */ get Is4Node()
                    {
                        return $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(this.Left) && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(this.Right);
                    }
                    /*void */ ColorBlack()
                    {
                        return this.Color = 0/*NodeColor.Black*/;
                    }
                    /*void */ ColorRed()
                    {
                        return this.Color = 1/*NodeColor.Red*/;
                    }
                    /*Node */ DeepClone(/*int*/ count)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(count === this.GetCount(), "count == GetCount()");
                        /*Node*/ let newRoot = this.ShallowClone();
                        /*var*/ let pendingNodes = new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node)))().$ctor$3(((((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(count)) | 0) + 2) | 0));
                        pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(this, newRoot));
                        /*var*/ let next;
                        while(pendingNodes.TryPop($.$ref(() => next, ($v) => next = $v, $.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))))
                        {
                            /*Node*/ let clonedNode;
                            let left;
                            if ($.$is(next.Item1.Left, $.$sc.System.Collections.Generic.SortedSet$$(T).Node, { set $v(v){ left = v; } }))
                            {
                                clonedNode = left.ShallowClone();
                                next.Item2.Left = clonedNode;
                                pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(left, clonedNode));
                            }
                            let right;
                            if ($.$is(next.Item1.Right, $.$sc.System.Collections.Generic.SortedSet$$(T).Node, { set $v(v){ right = v; } }))
                            {
                                clonedNode = right.ShallowClone();
                                next.Item2.Right = clonedNode;
                                pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(right, clonedNode));
                            }
                        }
                        return newRoot;
                    }
                    /*TreeRotation */ GetRotation(/*Node*/ current, /*Node*/ sibling)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Left) || $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Right), "IsNonNullRed(sibling.Left) || IsNonNullRed(sibling.Right)");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.HasChildren(current, sibling), "HasChildren(current, sibling)");
                        /*bool*/ let currentIsLeftChild = this.Left === current;
                        return $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Left) ? (currentIsLeftChild ? 3/*TreeRotation.RightLeft*/ : 2/*TreeRotation.Right*/) : (currentIsLeftChild ? 0/*TreeRotation.Left*/ : 1/*TreeRotation.LeftRight*/);
                    }
                    /*Node */ GetSibling(/*Node*/ node)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(node !== null, "node != null");
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Boolean.op_ExclusiveOr(node === this.Left, node === this.Right), "node == Left ^ node == Right");
                        return node === this.Left ? this.Right : this.Left;
                    }
                    /*Node */ ShallowClone()
                    {
                        return new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(this.Item$2, this.Color);
                    }
                    /*void */ Split4Node()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Left !== null, "Left != null");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Right !== null, "Right != null");
                        this.ColorRed();
                        this.Left.ColorBlack();
                        this.Right.ColorBlack();
                    }
                    /*Node? */ Rotate(/*TreeRotation*/ rotation)
                    {
                        /*Node*/ let removeRed;
                        switch(rotation)
                        {
                            case 2/*TreeRotation.Right*/:
                            removeRed = this.Left.Left;
                            $.$$.System.Diagnostics.Debug.Assert$2(removeRed.IsRed, "removeRed.IsRed");
                            removeRed.ColorBlack();
                            return this.RotateRight();
                            case 0/*TreeRotation.Left*/:
                            removeRed = this.Right.Right;
                            $.$$.System.Diagnostics.Debug.Assert$2(removeRed.IsRed, "removeRed.IsRed");
                            removeRed.ColorBlack();
                            return this.RotateLeft();
                            case 3/*TreeRotation.RightLeft*/:
                            $.$$.System.Diagnostics.Debug.Assert$2(this.Right.Left.IsRed, "Right!.Left!.IsRed");
                            return this.RotateRightLeft();
                            case 1/*TreeRotation.LeftRight*/:
                            $.$$.System.Diagnostics.Debug.Assert$2(this.Left.Right.IsRed, "Left!.Right!.IsRed");
                            return this.RotateLeftRight();
                            default:
                            $.$$.System.Diagnostics.Debug.Fail$1(`${"rotation"}: ${rotation} is not a defined ${"TreeRotation"} value.`);
                            return null;
                        }
                    }
                    /*Node */ RotateLeft()
                    {
                        /*Node*/ let child = this.Right;
                        this.Right = child.Left;
                        child.Left = this;
                        return child;
                    }
                    /*Node */ RotateLeftRight()
                    {
                        /*Node*/ let child = this.Left;
                        /*Node*/ let grandChild = child.Right;
                        this.Left = grandChild.Right;
                        grandChild.Right = this;
                        child.Right = grandChild.Left;
                        grandChild.Left = child;
                        return grandChild;
                    }
                    /*Node */ RotateRight()
                    {
                        /*Node*/ let child = this.Left;
                        this.Left = child.Right;
                        child.Right = this;
                        return child;
                    }
                    /*Node */ RotateRightLeft()
                    {
                        /*Node*/ let child = this.Right;
                        /*Node*/ let grandChild = child.Left;
                        this.Right = grandChild.Left;
                        grandChild.Left = this;
                        child.Left = grandChild.Right;
                        grandChild.Right = child;
                        return grandChild;
                    }
                    /*void */ Merge2Nodes()
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this.IsRed, "IsRed");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Left.Is2Node, "Left!.Is2Node");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Right.Is2Node, "Right!.Is2Node");
                        this.ColorBlack();
                        this.Left.ColorRed();
                        this.Right.ColorRed();
                    }
                    /*void */ ReplaceChild(/*Node*/ child, /*Node*/ newChild)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(this.HasChild(child), "HasChild(child)");
                        if (this.Left === child)
                        {
                            this.Left = newChild;
                        }
                        else 
                        {
                            this.Right = newChild;
                        }
                    }
                    /*int */ GetCount()
                    {
                        return ((((1 + ((this.Left?.GetCount() ?? null) ?? 0)) | 0) + ((this.Right?.GetCount() ?? null) ?? 0)) | 0);
                    }
                    /*bool */ HasChild(/*Node*/ child)
                    {
                        return child === this.Left || child === this.Right;
                    }
                    /*bool */ HasChildren(/*Node*/ child1, /*Node*/ child2)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(child1 !== child2, "child1 != child2");
                        return (this.Left === child1 && this.Right === child2) || (this.Left === child2 && this.Right === child1);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Color = 0;
                    }
                    static $h = 2621445;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedSet$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedSet$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*SortedSet<T>*/  get _tree() { return this.$getField(0, 4); }
                    /*SortedSet<T>*/  set _tree(value) { this.$setField(0, 4, value); }
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    /*Stack<Node>*/  get _stack() { return this.$getField(8, 4); }
                    /*Stack<Node>*/  set _stack(value) { this.$setField(8, 4, value); }
                    /*Node?*/  get _current() { return this.$getField(12, 4); }
                    /*Node?*/  set _current(value) { this.$setField(12, 4, value); }
                    /*bool*/  get _reverse() { return this.$getField(16, 1); }
                    /*bool*/  set _reverse(value) { this.$setField(16, 1, value); }
                    $ctor$4(/*SortedSet<T>*/ set)
                    {
                        this.$ctor$3(set, false);
                        {
                        }
                        return this;
                    }
                    $ctor$3(/*SortedSet<T>*/ set, /*bool*/ reverse)
                    {
                        super.$ctor$1();
                        {
                            this._tree = set;
                            set.VersionCheck(false);
                            this._version = set.version;
                            this._stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((set.TotalCount() + 1) | 0))) | 0));
                            this._current = null;
                            this._reverse = reverse;
                            this.Initialize();
                        }
                        return this;
                    }
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    /*void */ Initialize()
                    {
                        this._current = null;
                        /*Node?*/ let node = this._tree.root;
                        /*Node?*/ let next, other;
                        while(node !== null)
                        {
                            next = (this._reverse ? node.Right : node.Left);
                            other = (this._reverse ? node.Left : node.Right);
                            if (this._tree.IsWithinRange(node.Item$2))
                            {
                                this._stack.Push(node);
                                node = next;
                            }
                            else if (next === null || !this._tree.IsWithinRange(next.Item$2))
                            {
                                node = other;
                            }
                            else 
                            {
                                node = next;
                            }
                        }
                    }
                    /*bool */ MoveNext()
                    {
                        this._tree.VersionCheck(false);
                        if (this._version !== this._tree.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._stack.Count === 0)
                        {
                            this._current = null;
                            return false;
                        }
                        this._current = this._stack.Pop();
                        /*Node?*/ let node = (this._reverse ? this._current.Left : this._current.Right);
                        /*Node?*/ let next, other;
                        while(node !== null)
                        {
                            next = (this._reverse ? node.Right : node.Left);
                            other = (this._reverse ? node.Left : node.Right);
                            if (this._tree.IsWithinRange(node.Item$2))
                            {
                                this._stack.Push(node);
                                node = next;
                            }
                            else if (other === null || !this._tree.IsWithinRange(other.Item$2))
                            {
                                node = next;
                            }
                            else 
                            {
                                node = other;
                            }
                        }
                        return true;
                    }
                    /*void */ Dispose()
                    {
                    }
                    /*T */ get Current()
                    {
                        if (this._current !== null)
                        {
                            return this._current.Item$2;
                        }
                        return $.$default(T);
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._current.Item$2, T);
                    }
                    /*bool */ get NotStartedOrEnded()
                    {
                        return this._current === null;
                    }
                    /*void */ Reset()
                    {
                        if (this._version !== this._tree.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._stack.Clear();
                        this.Initialize();
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._tree = this._tree;
                        copy._version = this._version;
                        copy._stack = this._stack;
                        copy._current = this._current;
                        copy._reverse = this._reverse;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._tree = null;
                        this._version = 0;
                        this._stack = null;
                        this._current = null;
                        this._reverse = false;
                    }
                    static $h = 2555909;
                    static $z = 17;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedSet$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            static $_ElementCount;
            static get ElementCount()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_ElementCount ??= $asm.$nstr("$sc.System.Collections.Generic.SortedSet$$.ElementCount", ($self) => class ElementCount extends $.$$.System.ValueType
                {
                    /*int*/  get UniqueCount() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set UniqueCount(value) { this.$setField(0, $.$$.System.Int32, value); }
                    /*int*/  get UnfoundCount() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set UnfoundCount(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.UniqueCount = this.UniqueCount;
                        copy.UnfoundCount = this.UnfoundCount;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.UniqueCount = 0;
                        this.UnfoundCount = 0;
                    }
                    static $h = 2490373;
                    static $z = 8;
                    static $f = 0b10000010000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedSet$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.ElementCount`; }
                }, $cls, ($v) => $cls.$_ElementCount = $v);
            }
            /*bool */ TryGetValue(/*T*/ equalValue, /*out T*/ actualValue)
            {
                /*Node?*/ let node = this.FindNode(equalValue);
                if (node !== null)
                {
                    actualValue.$v = node.Item$2;
                    return true;
                }
                actualValue.$v = $.$default(T);
                return false;
            }
            static /*int */ Log2(/*int*/ value)
            {
                return $.$$.System.Numerics.BitOperations.Log2((value >>> 0));
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.Add(T)
            System$Collections$Generic$ISet$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.UnionWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$UnionWith()
            {
                return this.UnionWith(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IntersectWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IntersectWith()
            {
                return this.IntersectWith(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.ExceptWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$ExceptWith()
            {
                return this.ExceptWith(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.SymmetricExceptWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$SymmetricExceptWith()
            {
                return this.SymmetricExceptWith(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsSubsetOf()
            {
                return this.IsSubsetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsSupersetOf()
            {
                return this.IsSupersetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsProperSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsProperSupersetOf()
            {
                return this.IsProperSupersetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsProperSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsProperSubsetOf()
            {
                return this.IsProperSubsetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.Overlaps(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$Overlaps()
            {
                return this.Overlaps(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.SetEquals(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$SetEquals()
            {
                return this.SetEquals(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Contains(T)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.CopyTo(T[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Remove(T)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.Contains(T)
            System$Collections$Generic$IReadOnlySet$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsProperSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsProperSubsetOf()
            {
                return this.IsProperSubsetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsProperSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsProperSupersetOf()
            {
                return this.IsProperSupersetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsSubsetOf()
            {
                return this.IsSubsetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsSupersetOf()
            {
                return this.IsSupersetOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.Overlaps(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$Overlaps()
            {
                return this.Overlaps(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.SetEquals(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$SetEquals()
            {
                return this.SetEquals(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //default member initializer
            constructor()
            {
                super();
                this.comparer = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.ComparerName = "Comparer";
                }
                {
                    this.CountName = "Count";
                }
                {
                    this.ItemsName = "Items";
                }
                {
                    this.VersionName = "Version";
                }
            }
            static $h = 2424837;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sc.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.System.ValueType
        {
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            /*TKey*/ Key = $.$default(TKey);
            /*TValue*/ Value = $.$default(TValue);
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 131077;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$str("$sc.System.Collections.Generic.BitHelper", ($self) => class BitHelper extends $.$$.System.ValueType
        {
            /*int*/ static IntSize = 32;
            /*Span<int>*/  get _span() { return this.$getField(0, 8); }
            /*Span<int>*/  set _span(value) { this.$setField(0, 8, value); }
            $ctor$3(/*Span<int>*/ span, /*bool*/ clear)
            {
                super.$ctor$1();
                {
                    if (clear)
                    {
                        span.Clear();
                    }
                    this._span = span;
                }
                return this;
            }
            /*void */ MarkBit(/*int*/ bitPosition)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(bitPosition >= 0, "bitPosition >= 0");
                /*uint*/ let bitArrayIndex = $.trunc((bitPosition >>> 0) / 32/*IntSize*/);
                /*Span<int>*/ let span = this._span;
                if (bitArrayIndex < (span.Length >>> 0))
                {
                    span.get_Item((bitArrayIndex | 0)).$v |= (1 << (((bitPosition >>> 0) % 32/*IntSize*/) | 0));
                }
            }
            /*bool */ IsMarked(/*int*/ bitPosition)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(bitPosition >= 0, "bitPosition >= 0");
                /*uint*/ let bitArrayIndex = $.trunc((bitPosition >>> 0) / 32/*IntSize*/);
                /*ReadOnlySpan<int>*/ let span = $.$$.System.Span$$($.$$.System.Int32).op_Implicit(this._span);
                return bitArrayIndex < (span.Length >>> 0) && (span.get_Item((bitArrayIndex | 0)).$v & (1 << ((((bitPosition >>> 0) % 32/*IntSize*/) | 0)))) !== 0;
            }
            static /*int */ ToIntArrayLength(/*int*/ n)
            {
                return n > 0 ? ((($.trunc((((n - 1) | 0)) / 32/*IntSize*/) + 1) | 0)) : 0;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._span = $.$default($.$$.System.Span$$($.$$.System.Int32));
            }
            static $h = 65541;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":65541}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.BitHelper`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.TreeWalkPredicate<>", (T) => $asm.$gt("$sc.System.Collections.Generic.TreeWalkPredicate<>", [T], ($self) => class TreeWalkPredicate$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/**/ node)
            {
                return this.$nativeFunction.call(this.$target, node);
            }
            static $h = 3145733;
            static $g = 1;
            static $f = 0b11000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Collections.Generic.TreeWalkPredicate<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sc.System.Collections.Generic.NodeColor", ($self) => class NodeColor extends $.$$.System.Enum
        {
            static Black = 0;
            static Red = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Black": 0n,
                    "Red": 1n
                };
            }
            static $h = 786437;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"h":786437}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.NodeColor`; }
        });
        
        $asm.$str("$sc.System.Collections.Generic.TreeRotation", ($self) => class TreeRotation extends $.$$.System.Enum
        {
            static Left = 0;
            static LeftRight = 1;
            static Right = 2;
            static RightLeft = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Left": 0n,
                    "LeftRight": 1n,
                    "Right": 2n,
                    "RightLeft": 3n
                };
            }
            static $h = 3014661;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"h":3014661}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.TreeRotation`; }
        });
        
        $asm.$str("$sc.System.Collections.Generic.InsertionBehavior", ($self) => class InsertionBehavior extends $.$$.System.Enum
        {
            static IgnoreInsertion = 0;
            static OverwriteExisting = 1;
            static ThrowOnExisting = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IgnoreInsertion": 0n,
                    "OverwriteExisting": 1n,
                    "ThrowOnExisting": 2n
                };
            }
            static $h = 524293;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":524293}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.InsertionBehavior`; }
        });
        
        $asm.$cls("$sc.System.Collections.Generic.SortedSetEqualityComparer<>", (T) => $asm.$gt("$sc.System.Collections.Generic.SortedSetEqualityComparer<>", [T], ($self) => class SortedSetEqualityComparer$$ extends $.$$.System.Object
        {
            /*IComparer<T>*/ _comparer = null;
            /*IEqualityComparer<T>*/ _memberEqualityComparer = null;
            $ctor$2(/*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                this.$ctor$1(null, memberEqualityComparer);
                {
                }
                return this;
            }
            $ctor$1(/*IComparer<T>?*/ comparer, /*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                super.$ctor();
                {
                    this._comparer = comparer ?? $.$$.System.Collections.Generic.Comparer$$(T).Default;
                    this._memberEqualityComparer = memberEqualityComparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                }
                return this;
            }
            /*bool */ Equals$2(/*SortedSet<T>?*/ x, /*SortedSet<T>?*/ y)
            {
                return $.$sc.System.Collections.Generic.SortedSet$$(T).SortedSetEquals(x, y, this._comparer);
            }
            /*int */ GetHashCode$1(/*SortedSet<T>*/ obj)
            {
                /*int*/ let hashCode = 0;
                if (obj !== null)
                {
                    var $en3 = obj.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var t = $en3.Current;
                        {
                            if ($.$box(t, T) !== null)
                            {
                                hashCode ^= (this._memberEqualityComparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(t, [T]) & 2147483647);
                            }
                        }
                    }
                }
                return hashCode;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                /*SortedSetEqualityComparer<T>?*/ let comparer = $.$as(obj, $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T));
                return comparer !== null && this._comparer === comparer._comparer;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T).Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Object.GetHashCode.call(this._comparer) ^ $.$$.System.Object.GetHashCode.call(this._memberEqualityComparer);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T).GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Collections.Generic.SortedSet<T>>.Equals(System.Collections.Generic.SortedSet<T>?, System.Collections.Generic.SortedSet<T>?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Collections.Generic.SortedSet<T>>.GetHashCode(System.Collections.Generic.SortedSet<T>)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                return this.GetHashCode$1(...arguments);
            }
            static $h = 2752517;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEqualityComparer$$($.$sc.System.Collections.Generic.SortedSet$$(T)) ]; }
            static get $fullName() { return `System.Collections.Generic.SortedSetEqualityComparer<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.SortedDictionary<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.SortedDictionary<,>", [TKey, TValue], ($self) => class SortedDictionary$$$ extends $.$$.System.Object
        {
            /*KeyCollection?*/ _keys = null;
            /*ValueCollection?*/ _values = null;
            /*TreeSet<KeyValuePair<TKey, TValue>>*/ _set = null;
            $ctor$1()
            {
                this.$ctor$2(null);
                {
                }
                return this;
            }
            $ctor$4(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$3(dictionary, null);
                {
                }
                return this;
            }
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary, /*IComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                    /*var*/ let keyValuePairComparer = new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)().$ctor$2(comparer);
                    let sortedDictionary;
                    let kv;
                    if ($.$is(dictionary, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue), { set $v(v){ sortedDictionary = v; } }) && $.$is(sortedDictionary._set.Comparer, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer, { set $v(v){ kv = v; } }) && $.$$.System.Object.Equals$1.call(kv.keyComparer, keyValuePairComparer.keyComparer))
                    {
                        this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$9(sortedDictionary._set, keyValuePairComparer);
                    }
                    else 
                    {
                        this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$7(keyValuePairComparer);
                        var $en4 = dictionary.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var pair = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                this._set.Add(pair);
                            }
                        }
                    }
                }
                return this;
            }
            $ctor$2(/*IComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$7(new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)().$ctor$2(comparer));
                }
                return this;
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                this._set.Add(keyValuePair);
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(keyValuePair);
                if (node === null)
                {
                    return false;
                }
                if ($.$box(keyValuePair.Value, TValue) === null)
                {
                    return $.$box(node.Item$2.Value, TValue) === null;
                }
                else 
                {
                    return $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(node.Item$2.Value, keyValuePair.Value);
                }
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(keyValuePair);
                if (node === null)
                {
                    return false;
                }
                if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(node.Item$2.Value, keyValuePair.Value))
                {
                    this._set.Remove(keyValuePair);
                    return true;
                }
                return false;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*TValue*/ get_Item(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
                }
                return node.Item$2.Value;
            }
            /*void*/ set_Item(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    this._set.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, value));
                }
                else 
                {
                    node.Item$2 = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(node.Item$2.Key, value);
                    this._set.UpdateVersion();
                }
            }
            /*int */ get Count()
            {
                return this._set.Count;
            }
            /*IComparer<TKey> */ get Comparer()
            {
                return ($.$cast(this._set.Comparer, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)).keyComparer;
            }
            /*KeyCollection */ get Keys$1()
            {
                return this._keys ??= new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection)().$ctor$1(this);
            }
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            /*ValueCollection */ get Values()
            {
                return this._values ??= new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection)().$ctor$1(this);
            }
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.Values;
            }
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.Values;
            }
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this._set.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, value));
            }
            /*void */ Clear()
            {
                this._set.Clear();
            }
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this._set.Contains(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
            }
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                /*bool*/ let found = false;
                if ($.$box(value, TValue) === null)
                {
                    this._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                    {
                        if ($.$box(node.Item$2.Value, TValue) === null)
                        {
                            found = true;
                            return false;
                        }
                        return true;
                    }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                }
                else 
                {
                    /*EqualityComparer<TValue>*/ let valueComparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                    this._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                    {
                        if (valueComparer.Equals$2(node.Item$2.Value, value))
                        {
                            found = true;
                            return false;
                        }
                        return true;
                    }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                }
                return found;
            }
            /*void */ CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                this._set.CopyTo$1(array, index);
            }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, 1/*Enumerator.KeyValuePair*/);
            }
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this._set.GetEnumerator();
            }
            /*bool */ Remove(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this._set.Remove(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    value.$v = $.$default(TValue);
                    return false;
                }
                value.$v = node.Item$2.Value;
                return true;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                (this._set).System$Collections$ICollection$CopyTo(array, index);
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    /*TValue?*/ let value;
                    if (this.TryGetValue($.$cast(key, TKey), $.$ref(() => value, ($v) => value = $v, TValue)))
                    {
                        return $.$box(value, TValue);
                    }
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                try
                {
                    /*TKey*/ let tempKey = $.$cast(key, TKey);
                    try
                    {
                        this.set_Item(tempKey, $.$cast(value, TValue));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
            }
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                try
                {
                    /*TKey*/ let tempKey = $.$cast(key, TKey);
                    try
                    {
                        this.Add(tempKey, $.$cast(value, TValue));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
            }
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    return this.ContainsKey($.$cast(key, TKey));
                }
                return false;
            }
            static /*bool */ IsCompatibleKey(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return ($.$is(key, TKey));
            }
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, 2/*Enumerator.DictEntry*/);
            }
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    this.Remove($.$cast(key, TKey));
                }
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return (this._set).System$Collections$ICollection$SyncRoot;
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*TreeSet<KeyValuePair<TKey, TValue>>.Enumerator*/  get _treeEnum() { return this.$getField(0, 17); }
                    /*TreeSet<KeyValuePair<TKey, TValue>>.Enumerator*/  set _treeEnum(value) { this.$setField(0, 17, value); }
                    /*int*/  get _getEnumeratorRetType() { return this.$getField(17, 4); }
                    /*int*/  set _getEnumeratorRetType(value) { this.$setField(17, 4, value); }
                    /*int*/ static KeyValuePair = 1;
                    /*int*/ static DictEntry = 2;
                    $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary, /*int*/ getEnumeratorRetType)
                    {
                        super.$ctor$1();
                        {
                            this._treeEnum = dictionary._set.GetEnumerator();
                            this._getEnumeratorRetType = getEnumeratorRetType;
                        }
                        return this;
                    }
                    /*bool */ MoveNext()
                    {
                        return this._treeEnum.MoveNext();
                    }
                    /*void */ Dispose()
                    {
                        this._treeEnum.Dispose();
                    }
                    /*KeyValuePair<TKey, TValue> */ get Current()
                    {
                        return this._treeEnum.Current;
                    }
                    /*bool */ get NotStartedOrEnded()
                    {
                        return this._treeEnum.NotStartedOrEnded;
                    }
                    /*void */ Reset()
                    {
                        this._treeEnum.Reset();
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        this._treeEnum.Reset();
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getEnumeratorRetType === 2/*DictEntry*/)
                        {
                            return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                        }
                        return this.Current;
                    }
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current.Key, TKey);
                    }
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current.Value, TValue);
                    }
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._treeEnum = this._treeEnum.Clone();
                        copy._getEnumeratorRetType = this._getEnumeratorRetType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._treeEnum = $.$default($.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Enumerator);
                        this._getEnumeratorRetType = 0;
                    }
                    static $h = 1638405;
                    static $z = 21;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            static $_KeyCollection;
            static get KeyCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_KeyCollection ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.KeyCollection", ($self) => class KeyCollection extends $.$$.System.Object
                {
                    /*SortedDictionary<TKey, TValue>*/ _dictionary = null;
                    $ctor$1(/*SortedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    /*Enumerator */ GetEnumerator()
                    {
                        return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection.Enumerator)().$ctor$3(this._dictionary);
                    }
                    /*IEnumerator<TKey> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TKey]);
                    }
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(array, node.Item$2.Key, index++);
                            return true;
                        }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let keys;
                        if ($.$is(array, $.$typeArray(TKey), { set $v(v){ keys = v; } }))
                        {
                            this.CopyTo(keys, index);
                        }
                        else 
                        {
                            try
                            {
                                /*object[]*/ let objects = $.$cast(array, $.$typeArray($.$$.System.Object));
                                this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                                {
                                    $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$2.Key, TKey), index++);
                                    return true;
                                }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TKey*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    /*bool */ Contains(/*TKey*/ item)
                    {
                        return this._dictionary.ContainsKey(item);
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TKey*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.KeyCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  get _dictEnum() { return this.$getField(0, 21); }
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  set _dictEnum(value) { this.$setField(0, 21, value); }
                            $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    this._dictEnum = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            /*void */ Dispose()
                            {
                                this._dictEnum.Dispose();
                            }
                            /*bool */ MoveNext()
                            {
                                return this._dictEnum.MoveNext();
                            }
                            /*TKey */ get Current()
                            {
                                return this._dictEnum.Current.Key;
                            }
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                if (this._dictEnum.NotStartedOrEnded)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return $.$box(this.Current, TKey);
                            }
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                this._dictEnum.Reset();
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._dictEnum = this._dictEnum.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._dictEnum = $.$default($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator);
                            }
                            static $h = 1769477;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TKey>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    static $h = 1703941;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection`; }
                }, $cls, ($v) => $cls.$_KeyCollection = $v);
            }
            static $_ValueCollection;
            static get ValueCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_ValueCollection ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.ValueCollection", ($self) => class ValueCollection extends $.$$.System.Object
                {
                    /*SortedDictionary<TKey, TValue>*/ _dictionary = null;
                    $ctor$1(/*SortedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    /*Enumerator */ GetEnumerator()
                    {
                        return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection.Enumerator)().$ctor$3(this._dictionary);
                    }
                    /*IEnumerator<TValue> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TValue]);
                    }
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(array, node.Item$2.Value, index++);
                            return true;
                        }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let values;
                        if ($.$is(array, $.$typeArray(TValue), { set $v(v){ values = v; } }))
                        {
                            this.CopyTo(values, index);
                        }
                        else 
                        {
                            try
                            {
                                /*object?[]*/ let objects = $.$cast(array, $.$typeArray($.$$.System.Object));
                                this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                                {
                                    $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$2.Value, TValue), index++);
                                    return true;
                                }, {"r":262145,"p":[{"n":"node","p":$.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TValue*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Contains(/*TValue*/ item)
                    {
                        return this._dictionary.ContainsValue(item);
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TValue*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.ValueCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  get _dictEnum() { return this.$getField(0, 21); }
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  set _dictEnum(value) { this.$setField(0, 21, value); }
                            $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    this._dictEnum = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            /*void */ Dispose()
                            {
                                this._dictEnum.Dispose();
                            }
                            /*bool */ MoveNext()
                            {
                                return this._dictEnum.MoveNext();
                            }
                            /*TValue */ get Current()
                            {
                                return this._dictEnum.Current.Value;
                            }
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                if (this._dictEnum.NotStartedOrEnded)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return $.$box(this.Current, TValue);
                            }
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                this._dictEnum.Reset();
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._dictEnum = this._dictEnum.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._dictEnum = $.$default($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator);
                            }
                            static $h = 1966085;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TValue>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    static $h = 1900549;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection`; }
                }, $cls, ($v) => $cls.$_ValueCollection = $v);
            }
            static $_KeyValuePairComparer;
            static get KeyValuePairComparer()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_KeyValuePairComparer ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.KeyValuePairComparer", ($self) => class KeyValuePairComparer extends $.$$.System.Collections.Generic.Comparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))
                {
                    /*IComparer<TKey>*/ keyComparer = null;
                    $ctor$2(/*IComparer<TKey>?*/ keyComparer)
                    {
                        super.$ctor$1();
                        {
                            this.keyComparer = keyComparer ?? $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                        }
                        return this;
                    }
                    /*int */ Compare(/*KeyValuePair<TKey, TValue>*/ x, /*KeyValuePair<TKey, TValue>*/ y)
                    {
                        return this.keyComparer.System$Collections$Generic$IComparer$$$Compare(x.Key, y.Key, [TKey]);
                    }
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        let other;
                        if ($.$is(obj, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer, { set $v(v){ other = v; } }))
                        {
                            return this.keyComparer === other.keyComparer || $.$$.System.Object.Equals$1.call(this.keyComparer, other.keyComparer);
                        }
                        return false;
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer.Equals$1.apply(this, arguments); }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        return $.$$.System.Object.GetHashCode.call(this.keyComparer);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer.GetHashCode.apply(this, arguments); }
                    static $h = 1835013;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"d":$.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Collections.Generic.Comparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer, $.$$.System.Collections.Generic.IComparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyValuePairComparer`; }
                }, $cls, ($v) => $cls.$_KeyValuePairComparer = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.CopyTo(System.Collections.Generic.KeyValuePair<TKey, TValue>[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            static $h = 1572869;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.SortedList<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.SortedList<,>", [TKey, TValue], ($self) => class SortedList$$$ extends $.$$.System.Object
        {
            /*TKey[]*/ keys = null;
            /*TValue[]*/ values = null;
            /*int*/ _size = 0;
            /*int*/ version = 0;
            /*IComparer<TKey>*/ comparer = null;
            /*KeyList?*/ keyList = null;
            /*ValueList?*/ valueList = null;
            /*int*/ static DefaultCapacity = 4;
            $ctor$1()
            {
                super.$ctor();
                {
                    this.keys = $.$$.System.Array.Empty(TKey);
                    this.values = $.$$.System.Array.Empty(TValue);
                    this._size = 0;
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                }
                return this;
            }
            $ctor$6(/*int*/ capacity)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    this.keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [capacity], null);
                    this.values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [capacity], null);
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                }
                return this;
            }
            $ctor$2(/*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$1();
                {
                    if (comparer !== null)
                    {
                        this.comparer = comparer;
                    }
                }
                return this;
            }
            $ctor$5(/*int*/ capacity, /*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$2(comparer);
                {
                    this.Capacity = capacity;
                }
                return this;
            }
            $ctor$4(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$3(dictionary, null);
                {
                }
                return this;
            }
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary, /*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$5($.$firstOf((dictionary?.System$Collections$Generic$ICollection$$$Count ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("dictionary") }), comparer);
                {
                    /*int*/ let count = dictionary.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*TKey[]*/ let keys = this.keys;
                        dictionary.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$ICollection$$$CopyTo(keys, 0, [TKey]);
                        dictionary.System$Collections$Generic$IDictionary$$$$Values.System$Collections$Generic$ICollection$$$CopyTo(this.values, 0, [TValue]);
                        $.$$.System.Diagnostics.Debug.Assert$2(count === this.keys.length, "count == this.keys.Length");
                        if (count > 1)
                        {
                            comparer = this.Comparer;
                            $.$$.System.Array.Sort$13(TKey, TValue, keys, this.values, comparer);
                            for(/*int*/ let i = 1; i < keys.length; ++i)
                            {
                                if (comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(keys, ((i - 1) | 0)), $.$$.System.Array.$ReadT1.call(keys, i), [TKey]) === 0)
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box($.$$.System.Array.$ReadT1.call(keys, i), TKey)));
                                }
                            }
                        }
                    }
                    this._size = count;
                }
                return this;
            }
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                }
                this.Insert(~i, key, value);
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                this.Add(keyValuePair.Key, keyValuePair.Value);
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                /*int*/ let index = this.IndexOfKey(keyValuePair.Key);
                if (index >= 0 && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2($.$$.System.Array.$ReadT1.call(this.values, index), keyValuePair.Value))
                {
                    return true;
                }
                return false;
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                /*int*/ let index = this.IndexOfKey(keyValuePair.Key);
                if (index >= 0 && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2($.$$.System.Array.$ReadT1.call(this.values, index), keyValuePair.Value))
                {
                    this.RemoveAt(index);
                    return true;
                }
                return false;
            }
            /*int */ get Capacity()
            {
                return this.keys.length;
            }
            /*int */ set Capacity(value)
            {
                if (value !== this.keys.length)
                {
                    if (value < this._size)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_SmallCapacity);
                    }
                    if (value > 0)
                    {
                        /*TKey[]*/ let newKeys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [value], null);
                        /*TValue[]*/ let newValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [value], null);
                        if (this._size > 0)
                        {
                            $.$$.System.Array.Copy(this.keys, newKeys, this._size);
                            $.$$.System.Array.Copy(this.values, newValues, this._size);
                        }
                        this.keys = newKeys;
                        this.values = newValues;
                    }
                    else 
                    {
                        this.keys = $.$$.System.Array.Empty(TKey);
                        this.values = $.$$.System.Array.Empty(TValue);
                    }
                }
            }
            /*IComparer<TKey> */ get Comparer()
            {
                return this.comparer;
            }
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                if (!($.$is(value, TValue)) && value !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                }
                this.Add($.$cast(key, TKey), $.$cast(value, TValue));
            }
            /*int */ get Count()
            {
                return this._size;
            }
            /*IList<TKey> */ get Keys$1()
            {
                return this.GetKeyListHelper();
            }
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.GetKeyListHelper();
            }
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.GetKeyListHelper();
            }
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.GetKeyListHelper();
            }
            /*IList<TValue> */ get Values()
            {
                return this.GetValueListHelper();
            }
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.GetValueListHelper();
            }
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.GetValueListHelper();
            }
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.GetValueListHelper();
            }
            /*KeyList */ GetKeyListHelper()
            {
                return this.keyList ??= new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).KeyList)().$ctor$1(this);
            }
            /*ValueList */ GetValueListHelper()
            {
                return this.valueList ??= new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).ValueList)().$ctor$1(this);
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*void */ Clear()
            {
                this.version++;
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TKey>()) { ... }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TValue>()) { ... }
                this._size = 0;
            }
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    return this.ContainsKey($.$cast(key, TKey));
                }
                return false;
            }
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                return this.IndexOfKey(key) >= 0;
            }
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                return this.IndexOfValue(value) >= 0;
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ arrayIndex)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    /*KeyValuePair<TKey, TValue>*/ let entry = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i));
                    $.$$.System.Array.$WriteT1.call(array, entry, ((arrayIndex + i) | 0));
                }
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                if (index < 0 || index > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                let keyValuePairArray;
                if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ keyValuePairArray = v; } }))
                {
                    for(/*int*/ let i = 0; i < this.Count; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(keyValuePairArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i)), ((i + index) | 0));
                    }
                }
                else 
                {
                    /*object[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        for(/*int*/ let i = 0; i < this.Count; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(objects, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i)), ((i + index) | 0));
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            /*void */ EnsureCapacity(/*int*/ min)
            {
                /*int*/ let newCapacity = this.keys.length === 0 ? 4/*DefaultCapacity*/ : ((this.keys.length * 2) | 0);
                if (BigInt((newCapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newCapacity = $.$$.System.Array.MaxLength;
                }
                if (newCapacity < min)
                {
                    newCapacity = min;
                }
                this.Capacity = newCapacity;
            }
            /*TValue */ GetValueAtIndex(/*int*/ index)
            {
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.values, index);
            }
            /*void */ SetValueAtIndex(/*int*/ index, /*TValue*/ value)
            {
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this.version++;
            }
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).Enumerator)().$ctor$3(this, 1/*Enumerator.KeyValuePair*/);
            }
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this.GetEnumerator();
            }
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).Enumerator)().$ctor$3(this, 2/*Enumerator.DictEntry*/);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
            }
            /*TKey */ GetKeyAtIndex(/*int*/ index)
            {
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.keys, index);
            }
            /*TValue*/ get_Item(/*TKey*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    return $.$$.System.Array.$ReadT1.call(this.values, i);
                }
                throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
            }
            /*void*/ set_Item(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    $.$$.System.Array.$WriteT1.call(this.values, value, i);
                    this.version++;
                    return;
                }
                this.Insert(~i, key, value);
            }
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    /*int*/ let i = this.IndexOfKey($.$cast(key, TKey));
                    if (i >= 0)
                    {
                        return $.$box($.$$.System.Array.$ReadT1.call(this.values, i), TValue);
                    }
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                if (!$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("key");
                }
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                /*TKey*/ let tempKey = $.$cast(key, TKey);
                try
                {
                    this.set_Item(tempKey, $.$cast(value, TValue));
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                }
            }
            /*int */ IndexOfKey(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let ret = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                return ret >= 0 ? ret : -1;
            }
            /*int */ IndexOfValue(/*TValue*/ value)
            {
                return $.$$.System.Array.IndexOf$3(TValue, this.values, value, 0, this._size);
            }
            /*void */ Insert(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                if (this._size === this.keys.length)
                {
                    this.EnsureCapacity(((this._size + 1) | 0));
                }
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, index, this.keys, ((index + 1) | 0), ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, index, this.values, ((index + 1) | 0), ((this._size - index) | 0));
                }
                $.$$.System.Array.$WriteT1.call(this.keys, key, index);
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this._size++;
                this.version++;
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    value.$v = $.$$.System.Array.$ReadT1.call(this.values, i);
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this._size--;
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, ((index + 1) | 0), this.keys, index, ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, ((index + 1) | 0), this.values, index, ((this._size - index) | 0));
                }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TKey>()) { ... }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TValue>()) { ... }
                this.version++;
            }
            /*bool */ Remove(/*TKey*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    this.RemoveAt(i);
                }
                return i >= 0;
            }
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    this.Remove($.$cast(key, TKey));
                }
            }
            /*void */ TrimExcess()
            {
                /*int*/ let threshold = $.$cast((this.keys.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    this.Capacity = this._size;
                }
            }
            static /*bool */ IsCompatibleKey(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return ($.$is(key, TKey));
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedList$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*SortedList<TKey, TValue>*/  get _sortedList() { return this.$getField(0, 4); }
                    /*SortedList<TKey, TValue>*/  set _sortedList(value) { this.$setField(0, 4, value); }
                    /*TKey?*/  get _key() { return this.$getField(4, 4); }
                    /*TKey?*/  set _key(value) { this.$setField(4, 4, value); }
                    /*TValue?*/  get _value() { return this.$getField(8, 4); }
                    /*TValue?*/  set _value(value) { this.$setField(8, 4, value); }
                    /*int*/  get _index() { return this.$getField(12, 4); }
                    /*int*/  set _index(value) { this.$setField(12, 4, value); }
                    /*int*/  get _version() { return this.$getField(16, 4); }
                    /*int*/  set _version(value) { this.$setField(16, 4, value); }
                    /*int*/  get _getEnumeratorRetType() { return this.$getField(20, 4); }
                    /*int*/  set _getEnumeratorRetType(value) { this.$setField(20, 4, value); }
                    /*int*/ static KeyValuePair = 1;
                    /*int*/ static DictEntry = 2;
                    $ctor$3(/*SortedList<TKey, TValue>*/ sortedList, /*int*/ getEnumeratorRetType)
                    {
                        super.$ctor$1();
                        {
                            this._sortedList = sortedList;
                            this._index = 0;
                            this._version = this._sortedList.version;
                            this._getEnumeratorRetType = getEnumeratorRetType;
                            this._key = $.$default(TKey);
                            this._value = $.$default(TValue);
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        this._index = 0;
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                    }
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box($.$box(this._key, TKey), TKey);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._key = $.$$.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._value = $.$$.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                        return false;
                    }
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box($.$box(this._key, TKey), TKey), $.$box(this._value, TValue));
                    }
                    /*KeyValuePair<TKey, TValue> */ get Current()
                    {
                        return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(this._key, this._value);
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getEnumeratorRetType === 2/*DictEntry*/)
                        {
                            return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box($.$box(this._key, TKey), TKey), $.$box(this._value, TValue));
                        }
                        else 
                        {
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(this._key, this._value);
                        }
                    }
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._value, TValue);
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._sortedList = this._sortedList;
                        copy._key = this._key;
                        copy._value = this._value;
                        copy._index = this._index;
                        copy._version = this._version;
                        copy._getEnumeratorRetType = this._getEnumeratorRetType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._sortedList = null;
                        this._key = null;
                        this._value = null;
                        this._index = 0;
                        this._version = 0;
                        this._getEnumeratorRetType = 0;
                    }
                    static $h = 2097157;
                    static $z = 24;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            static $_SortedListKeyEnumerator;
            static get SortedListKeyEnumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_SortedListKeyEnumerator ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.SortedListKeyEnumerator", ($self) => class SortedListKeyEnumerator extends $.$$.System.Object
                {
                    /*SortedList<TKey, TValue>*/ _sortedList = null;
                    /*int*/ _index = 0;
                    /*int*/ _version = 0;
                    /*TKey?*/ _currentKey = null;
                    $ctor$1(/*SortedList<TKey, TValue>*/ sortedList)
                    {
                        super.$ctor();
                        {
                            this._sortedList = sortedList;
                            this._version = sortedList.version;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        this._index = 0;
                        this._currentKey = $.$default(TKey);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._currentKey = $.$$.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._currentKey = $.$default(TKey);
                        return false;
                    }
                    /*TKey */ get Current()
                    {
                        return this._currentKey;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._currentKey, TKey);
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._currentKey = $.$default(TKey);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    static $h = 2228229;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.SortedListKeyEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListKeyEnumerator = $v);
            }
            static $_SortedListValueEnumerator;
            static get SortedListValueEnumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_SortedListValueEnumerator ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.SortedListValueEnumerator", ($self) => class SortedListValueEnumerator extends $.$$.System.Object
                {
                    /*SortedList<TKey, TValue>*/ _sortedList = null;
                    /*int*/ _index = 0;
                    /*int*/ _version = 0;
                    /*TValue?*/ _currentValue = null;
                    $ctor$1(/*SortedList<TKey, TValue>*/ sortedList)
                    {
                        super.$ctor();
                        {
                            this._sortedList = sortedList;
                            this._version = sortedList.version;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        this._index = 0;
                        this._currentValue = $.$default(TValue);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._currentValue = $.$$.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._currentValue = $.$default(TValue);
                        return false;
                    }
                    /*TValue */ get Current()
                    {
                        return this._currentValue;
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._currentValue, TValue);
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._currentValue = $.$default(TValue);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    static $h = 2293765;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.SortedListValueEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListValueEnumerator = $v);
            }
            static $_KeyList;
            static get KeyList()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_KeyList ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.KeyList", ($self) => class KeyList extends $.$$.System.Object
                {
                    /*SortedList<TKey, TValue>*/ _dict = null;
                    $ctor$1(/*SortedList<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            this._dict = dictionary;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this._dict._size;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dict).System$Collections$ICollection$SyncRoot;
                    }
                    /*void */ Add(/*TKey*/ key)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*bool */ Contains(/*TKey*/ key)
                    {
                        return this._dict.ContainsKey(key);
                    }
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ arrayIndex)
                    {
                        $.$$.System.Array.Copy$2(this._dict.keys, 0, array, arrayIndex, this._dict.Count);
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._dict.keys, 0, array, arrayIndex, this._dict.Count);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    /*void */ Insert(/*int*/ index, /*TKey*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*TKey*/ get_Item(/*int*/ index)
                    {
                        return this._dict.GetKeyAtIndex(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*TKey*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    /*IEnumerator<TKey> */ GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).SortedListKeyEnumerator)().$ctor$1(this._dict);
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*int */ IndexOf(/*TKey*/ key)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                        /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this._dict.keys, 0, this._dict.Count, key, this._dict.comparer);
                        if (i >= 0)
                        {
                            return i;
                        }
                        return -1;
                    }
                    /*bool */ Remove(/*TKey*/ key)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.IndexOf(TKey)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.Insert(int, TKey)
                    System$Collections$Generic$IList$$$Insert()
                    {
                        return this.Insert(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.RemoveAt(int)
                    System$Collections$Generic$IList$$$RemoveAt()
                    {
                        return this.RemoveAt(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Add(TKey)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Remove(TKey)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TKey>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    static $h = 2162693;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TKey), $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.KeyList`; }
                }, $cls, ($v) => $cls.$_KeyList = $v);
            }
            static $_ValueList;
            static get ValueList()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_ValueList ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.ValueList", ($self) => class ValueList extends $.$$.System.Object
                {
                    /*SortedList<TKey, TValue>*/ _dict = null;
                    $ctor$1(/*SortedList<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            this._dict = dictionary;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this._dict._size;
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dict).System$Collections$ICollection$SyncRoot;
                    }
                    /*void */ Add(/*TValue*/ key)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*bool */ Contains(/*TValue*/ value)
                    {
                        return this._dict.ContainsValue(value);
                    }
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ arrayIndex)
                    {
                        $.$$.System.Array.Copy$2(this._dict.values, 0, array, arrayIndex, this._dict.Count);
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._dict.values, 0, array, index, this._dict.Count);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    /*void */ Insert(/*int*/ index, /*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*TValue*/ get_Item(/*int*/ index)
                    {
                        return this._dict.GetValueAtIndex(index);
                    }
                    /*void*/ set_Item(/*int*/ index, /*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*IEnumerator<TValue> */ GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).SortedListValueEnumerator)().$ctor$1(this._dict);
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*int */ IndexOf(/*TValue*/ value)
                    {
                        return $.$$.System.Array.IndexOf$3(TValue, this._dict.values, value, 0, this._dict.Count);
                    }
                    /*bool */ Remove(/*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.IndexOf(TValue)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.Insert(int, TValue)
                    System$Collections$Generic$IList$$$Insert()
                    {
                        return this.Insert(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.RemoveAt(int)
                    System$Collections$Generic$IList$$$RemoveAt()
                    {
                        return this.RemoveAt(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Add(TValue)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        return this.Add(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        return this.Clear(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Contains(TValue)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Remove(TValue)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        return this.Remove(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TValue>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    static $h = 2359301;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TValue), $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.ValueList`; }
                }, $cls, ($v) => $cls.$_ValueList = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            static $h = 2031621;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.OrderedDictionary<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.OrderedDictionary<,>", [TKey, TValue], ($self) => class OrderedDictionary$$$ extends $.$$.System.Object
        {
            /*IEqualityComparer<TKey>?*/ _comparer = null;
            /*int[]?*/ _buckets = null;
            /*Entry[]?*/ _entries = null;
            /*int*/ _count = 0;
            /*int*/ _version = 0;
            /*ulong*/ _fastModMultiplier = 0n;
            $ctor$1()
            {
                this.$ctor$7(0, null);
                {
                }
                return this;
            }
            $ctor$8(/*int*/ capacity)
            {
                this.$ctor$7(capacity, null);
                {
                }
                return this;
            }
            $ctor$6(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7(0, comparer);
                {
                }
                return this;
            }
            $ctor$7(/*int*/ capacity, /*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    if (capacity > 0)
                    {
                        this.EnsureBucketsAndEntriesInitialized(capacity);
                    }
                    if (!TKey.$type.IsValueType)
                    {
                        this._comparer = comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                        let stringComparer;
                        if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is($.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer.GetStringComparer(this._comparer), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ stringComparer = v; } }))
                        {
                            this._comparer = $.$cast(stringComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                        }
                    }
                    else if (!(comparer === null) && comparer !== $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default)
                    {
                        this._comparer = comparer;
                    }
                }
                return this;
            }
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$2(dictionary, null);
                {
                }
                return this;
            }
            $ctor$2(/*IDictionary<TKey, TValue>*/ dictionary, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7((dictionary?.System$Collections$Generic$ICollection$$$Count ?? null) ?? 0, comparer);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                    this.AddRange(dictionary);
                }
                return this;
            }
            $ctor$5(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                this.$ctor$4(collection, null);
                {
                }
                return this;
            }
            $ctor$4(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7((($.$as(collection, $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))))?.System$Collections$Generic$ICollection$$$Count ?? null) ?? 0, comparer);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.AddRange(collection);
                }
                return this;
            }
            /*void */ EnsureBucketsAndEntriesInitialized(/*int*/ capacity)
            {
                this.Resize($.$sc.System.Collections.HashHelpers.GetPrime(capacity), false);
            }
            /*int */ get Capacity()
            {
                const $t1 = this._entries;
                return $.$ifnn($t1, ($t) => $t.length) ?? 0;
            }
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                /*IEqualityComparer<TKey>?*/ let comparer = this._comparer;
                let ec;
                if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is((($.$as(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))?.GetUnderlyingEqualityComparer() ?? null), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), { set $v(v){ ec = v; } }))
                {
                    return ec;
                }
                return comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return false;
            }
            /*KeyCollection*/ Keys$1$ = null;
            /*KeyCollection */ get Keys$1()
            {
                return this.Keys$ ??= new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection)().$ctor$1(this);
            }
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            /*ValueCollection*/ Values$ = null;
            /*ValueCollection */ get Values()
            {
                return this.Values$ ??= new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection)().$ctor$1(this);
            }
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.Values;
            }
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.Values;
            }
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                let tpair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ tpair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.SetAt(index, tpair.Key, tpair.Value);
            }
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                /*TValue?*/ let value;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.TryGetValue$1(tkey, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    return $.$box(value, TValue);
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                let tkey;
                if (!$.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                /*TValue*/ let tvalue = $.$default(TValue);
                if (!(value === null))
                {
                    let temp;
                    if (!$.$is(value, TValue, { set $v(v){ temp = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                    tvalue = temp;
                }
                this.set_Item(tkey, tvalue);
            }
            /*KeyValuePair<TKey, TValue>*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
            }
            /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*KeyValuePair<TKey, TValue>*/ value)
            {
                this.SetAt(index, value.Key, value.Value);
            }
            /*KeyValuePair<TKey, TValue>*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
        ;
            }
            /*TValue*/ get_Item(/*TKey*/ key)
            {
                /*TValue?*/ let value;
                if (!this.TryGetValue$1(key, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowKeyNotFound(TKey, key);
                }
                return value;
            }
            /*void*/ set_Item(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*bool*/ let modified = this.TryInsert(-1, key, value, 1/*InsertionBehavior.OverwriteExisting*/, $.$discardRef());
                $.$$.System.Diagnostics.Debug.Assert$2(modified, "modified");
            }
            /*bool */ TryInsert(/*int*/ index, /*TKey*/ key, /*TValue*/ value, /*InsertionBehavior*/ behavior, /*out int*/ keyIndex)
            {
                /*uint*/ let hashCode = 0, collisionCount = 0;
                /*int*/ let i = this.IndexOf(key, $.$ref(() => hashCode, ($v) => hashCode = $v, $.$$.System.UInt32), $.$ref(() => collisionCount, ($v) => collisionCount = $v, $.$$.System.UInt32));
                if (i >= 0)
                {
                    keyIndex.$v = i;
                    $.$$.System.Diagnostics.Debug.Assert$2(0 <= keyIndex.$v && keyIndex.$v < this._count, "0 <= keyIndex && keyIndex < _count");
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    switch(behavior)
                    {
                        case 1/*InsertionBehavior.OverwriteExisting*/:
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 0, "Expected index to be unspecied when overwriting an existing key.");
                        $.$$.System.Array.$ReadT1.call(this._entries, i).Value = value;
                        return true;
                        case 2/*InsertionBehavior.ThrowOnExisting*/:
                        $.$sc.System.Collections.ThrowHelper.ThrowDuplicateKey(TKey, key);
                        break;
                        default:
                        $.$$.System.Diagnostics.Debug.Assert$4(behavior === 0, `Unknown behavior: ${behavior}`);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 0, "Expected index to be unspecied when ignoring a duplicate key.");
                        return false;
                    }
                }
                if (index < 0)
                {
                    index = this._count;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(index <= this._count, "index <= _count");
                if (this._buckets === null)
                {
                    this.EnsureBucketsAndEntriesInitialized(0);
                }
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                if (entries.length === this._count)
                {
                    this.Resize($.$sc.System.Collections.HashHelpers.ExpandPrime(entries.length), false);
                    entries = this._entries;
                }
                for(i = ((this._count - 1) | 0); i >= index; --i)
                {
                    $.$$.System.Array.$WriteT1.call(entries, $.$$.System.Array.$ReadT1.call(entries, i), ((i + 1) | 0));
                    this.UpdateBucketIndex(i, 1);
                }
                /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, index, false, true);
                entry.$v.HashCode = hashCode;
                entry.$v.Key = key;
                entry.$v.Value = value;
                this.PushEntryIntoBucket(entry, index);
                this._count++;
                this._version++;
                this.RehashIfNecessary(collisionCount, entries);
                keyIndex.$v = index;
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= keyIndex.$v && keyIndex.$v < this._count, "0 <= keyIndex && keyIndex < _count");
                return true;
            }
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this.TryInsert(-1, key, value, 2/*InsertionBehavior.ThrowOnExisting*/, $.$discardRef());
            }
            /*bool */ TryAdd$1(/*TKey*/ key, /*TValue*/ value)
            {
                return this.TryAdd(key, value, $.$discardRef());
            }
            /*bool */ TryAdd(/*TKey*/ key, /*TValue*/ value, /*out int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this.TryInsert(-1, key, value, 0/*InsertionBehavior.IgnoreInsertion*/, index);
            }
            /*void */ AddRange(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(collection === null), "collection is not null");
                let array;
                if ($.$is(collection, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ array = v; } }))
                {
                    let $i1 = 0;
                    let $arr1 = array;
                    while ($i1 < $arr1.length)
                    {
                        let pair = $arr1[$i1++];
                        this.Add(pair.Key, pair.Value);
                    }
                }
                else 
                {
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pair = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Add(pair.Key, pair.Value);
                        }
                    }
                }
            }
            /*void */ Clear()
            {
                if (!(this._buckets === null) && this._count !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    $.$$.System.Array.Clear(this._buckets, 0, this._buckets.length);
                    $.$$.System.Array.Clear(this._entries, 0, this._count);
                    this._count = 0;
                    this._version++;
                }
            }
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                return this.IndexOf$1(key) >= 0;
            }
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                /*int*/ let count = this._count;
                /*Entry[]?*/ let entries = this._entries;
                if (entries === null)
                {
                    return false;
                }
                if (TValue.$type.IsValueType)
                {
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                        {
                            return true;
                        }
                    }
                }
                else 
                {
                    /*EqualityComparer<TValue>*/ let comparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        if (comparer.Equals$2(value, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            /*KeyValuePair<TKey, TValue> */ GetAt(/*int*/ index)
            {
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "count must be positive, which means we must have entries");
                /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, index, false, true);
                return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(e.$v.Key, e.$v.Value);
            }
            /*int */ IndexOf$1(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*uint*/ let _ = 0;
                return this.IndexOf(key, $.$discardRef(), $.$discardRef());
            }
            /*int */ IndexOf(/*TKey*/ key, /*ref uint*/ outHashCode, /*ref uint*/ outCollisionCount)
            {
                /*uint*/ let hashCode;
                /*uint*/ let collisionCount;
                /*IEqualityComparer<TKey>?*/ let comparer;
                /*int*/ let i;
                /*ref Entry*/ let entry;
                /*Entry[]?*/ let entries;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(key === null), "Key nullness should have been validated by caller.");
                            collisionCount = 0;
                            comparer = this._comparer;
                            if (this._buckets === null)
                            {
                                hashCode = (((comparer?.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]) ?? null) ?? $.$$.System.Object.GetHashCodeT(TKey, key)) >>> 0);
                                collisionCount = 0;
                                $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                continue $gotoJumpStart1;
                            }
                            i = -1;
                            entry = $.$$.System.Runtime.CompilerServices.Unsafe.NullRef($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry);
                            entries = this._entries;
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "expected entries to be is not null");
                            if (TKey.$type.IsValueType && comparer === null)
                            {
                                hashCode = ($.$$.System.Object.GetHashCodeT(TKey, key) >>> 0);
                                i = ((this.GetBucket(hashCode).$v - 1) | 0);
                                do
                                {
                                    if ((i >>> 0) >= (entries.length >>> 0))
                                    {
                                        $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                        continue $gotoJumpStart1;
                                    }
                                    entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                                    if (entry.$v.HashCode === hashCode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(entry.$v.Key, key))
                                    {
                                        $gotoJumpState1 = 3; /*goto Return*/
                                        continue $gotoJumpStart1;
                                    }
                                    i = entry.$v.Next;
                                    collisionCount++;
                                }
                                while(collisionCount <= (entries.length >>> 0));
                                $gotoJumpState1 = 2; /*goto ConcurrentOperation*/
                                continue $gotoJumpStart1;
                            }
                            else 
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                                hashCode = (comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]) >>> 0);
                                i = ((this.GetBucket(hashCode).$v - 1) | 0);
                                do
                                {
                                    if ((i >>> 0) >= (entries.length >>> 0))
                                    {
                                        $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                        continue $gotoJumpStart1;
                                    }
                                    entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                                    if (entry.$v.HashCode === hashCode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(entry.$v.Key, key, [TKey]))
                                    {
                                        $gotoJumpState1 = 3; /*goto Return*/
                                        continue $gotoJumpStart1;
                                    }
                                    i = entry.$v.Next;
                                    collisionCount++;
                                }
                                while(collisionCount <= (entries.length >>> 0));
                                $gotoJumpState1 = 2; /*goto ConcurrentOperation*/
                                continue $gotoJumpStart1;
                            }
                        }
                        case 1: /*ReturnNotFound*/
                        i = -1;
                        outCollisionCount.$v = collisionCount;
                        $gotoJumpState1 = 3; /*goto Return*/
                        continue $gotoJumpStart1;
                        case 2: /*ConcurrentOperation*/
                        $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        case 3: /*Return*/
                        outHashCode.$v = hashCode;
                        return i;
                    }
                    break;
                }
            }
            /*void */ Insert(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                if ((index >>> 0) > (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this.TryInsert(index, key, value, 2/*InsertionBehavior.ThrowOnExisting*/, $.$discardRef());
            }
            /*bool */ Remove$1(/*TKey*/ key)
            {
                return this.Remove(key, $.$discardRef());
            }
            /*bool */ Remove(/*TKey*/ key, /*out TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let index = this.IndexOf$1(key);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    value.$v = $.$$.System.Array.$ReadT1.call(this._entries, index).Value;
                    this.RemoveAt(index);
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                /*int*/ let count = this._count;
                if ((index >>> 0) >= (count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                this.RemoveEntryFromBucket(index);
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                for(/*int*/ let i = ((index + 1) | 0); i < count; i++)
                {
                    $.$$.System.Array.$WriteT1.call(entries, $.$$.System.Array.$ReadT1.call(entries, i), ((i - 1) | 0));
                    this.UpdateBucketIndex(i, -1);
                }
                $.$$.System.Array.$WriteT1.call(entries, new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry)(), --this._count);
                this._version++;
            }
            /*void */ SetAt$1(/*int*/ index, /*TValue*/ value)
            {
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                $.$$.System.Array.$ReadT1.call(this._entries, index).Value = value;
            }
            /*void */ SetAt(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, index, false, true);
                if (TKey.$type.IsValueType && this._comparer === null)
                {
                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(key, e.$v.Key))
                    {
                        e.$v.Value = value;
                        return;
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                    if (this._comparer.System$Collections$Generic$IEqualityComparer$$$Equals(key, e.$v.Key, [TKey]))
                    {
                        e.$v.Value = value;
                        return;
                    }
                }
                /*uint*/ let hashCode = 0, collisionCount = 0;
                if (this.IndexOf(key, $.$ref(() => hashCode, ($v) => hashCode = $v, $.$$.System.UInt32), $.$ref(() => collisionCount, ($v) => collisionCount = $v, $.$$.System.UInt32)) >= 0)
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowDuplicateKey(TKey, key);
                }
                this.RemoveEntryFromBucket(index);
                e.$v.HashCode = hashCode;
                e.$v.Key = key;
                e.$v.Value = value;
                this.PushEntryIntoBucket(e, index);
                this._version++;
                this.RehashIfNecessary(collisionCount, this._entries);
            }
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this.Capacity < capacity)
                {
                    if (this._buckets === null)
                    {
                        this.EnsureBucketsAndEntriesInitialized(capacity);
                    }
                    else 
                    {
                        this.Resize($.$sc.System.Collections.HashHelpers.GetPrime(capacity), false);
                    }
                    this._version++;
                }
                return this.Capacity;
            }
            /*void */ TrimExcess()
            {
                return this.TrimExcess$1(this._count);
            }
            /*void */ TrimExcess$1(/*int*/ capacity)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, capacity, this.Count, "capacity");
                const $t1 = this._entries;
                /*int*/ let currentCapacity = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                capacity = $.$sc.System.Collections.HashHelpers.GetPrime(capacity);
                if (capacity < currentCapacity)
                {
                    this.Resize(capacity, false);
                }
            }
            /*bool */ TryGetValue$1(/*TKey*/ key, /*out TValue*/ value)
            {
                return this.TryGetValue(key, value, $.$discardRef());
            }
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value, /*out int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                index.$v = this.IndexOf$1(key);
                if (index.$v >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    value.$v = $.$$.System.Array.$ReadT1.call(this._entries, index.$v).Value;
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            /*void */ PushEntryIntoBucket(/*ref Entry*/ entry, /*int*/ entryIndex)
            {
                /*ref int*/ let bucket = this.GetBucket(entry.$v.HashCode);
                entry.$v.Next = ((bucket.$v - 1) | 0);
                bucket.$v = ((entryIndex + 1) | 0);
            }
            /*void */ RemoveEntryFromBucket(/*int*/ entryIndex)
            {
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                /*Entry*/ let entry = $.$$.System.Array.$ReadT1.call(entries, entryIndex);
                /*ref int*/ let bucket = this.GetBucket(entry.HashCode);
                if (bucket.$v === ((entryIndex + 1) | 0))
                {
                    bucket.$v = ((entry.Next + 1) | 0);
                }
                else 
                {
                    /*int*/ let i = ((bucket.$v - 1) | 0);
                    /*int*/ let collisionCount = 0;
                    while(true)
                    {
                        /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                        if (e.$v.Next === entryIndex)
                        {
                            e.$v.Next = entry.Next;
                            return;
                        }
                        i = e.$v.Next;
                        if (++collisionCount > entries.length)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        }
                    }
                }
            }
            /*void */ UpdateBucketIndex(/*int*/ entryIndex, /*int*/ shiftAmount)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((shiftAmount === 1) || (shiftAmount === -1), "shiftAmount is 1 or -1");
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                /*Entry*/ let entry = $.$$.System.Array.$ReadT1.call(entries, entryIndex);
                /*ref int*/ let bucket = this.GetBucket(entry.HashCode);
                if (bucket.$v === ((entryIndex + 1) | 0))
                {
                    bucket.$v += shiftAmount;
                }
                else 
                {
                    /*int*/ let i = ((bucket.$v - 1) | 0);
                    /*int*/ let collisionCount = 0;
                    while(true)
                    {
                        /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                        if (e.$v.Next === entryIndex)
                        {
                            e.$v.Next += shiftAmount;
                            return;
                        }
                        i = e.$v.Next;
                        if (++collisionCount > entries.length)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        }
                    }
                }
            }
            /*void */ RehashIfNecessary(/*uint*/ collisionCount, /*Entry[]*/ entries)
            {
                if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                {
                    this.Resize(entries.length, true);
                }
            }
            /*void */ Resize(/*int*/ newSize, /*bool*/ forceNewHashCodes)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!forceNewHashCodes || !TKey.$type.IsValueType, "Value types never rehash.");
                $.$$.System.Diagnostics.Debug.Assert$2(newSize >= this._count, "The requested size must accomodate all of the current elements.");
                /*int[]*/ let newBuckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [newSize], null);
                /*Entry[]*/ let newEntries = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry), null, [newSize], null);
                //if (IntPtr.Size == 8) { ... }
                /*int*/ let count = this._count;
                if (!(this._entries === null))
                {
                    $.$$.System.Array.Copy(this._entries, newEntries, count);
                }
                if (!TKey.$type.IsValueType && forceNewHashCodes)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer), "_comparer is NonRandomizedStringEqualityComparer");
                    /*IEqualityComparer<TKey>*/ let comparer = this._comparer = $.$cast(($.$cast(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer)).GetUnderlyingEqualityComparer(), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer !== null && ($.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))), "_comparer is not NonRandomizedStringEqualityComparer");
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(newEntries, i).HashCode = (comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode($.$$.System.Array.$ReadT1.call(newEntries, i).Key, [TKey]) >>> 0);
                    }
                }
                this._buckets = newBuckets;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    this.PushEntryIntoBucket($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, newEntries, i, false, true), i);
                }
                this._entries = newEntries;
            }
            /*ref int */ GetBucket(/*uint*/ hashCode)
            {
                /*int[]?*/ let buckets = this._buckets;
                $.$$.System.Diagnostics.Debug.Assert$2(!(buckets === null), "buckets is not null");
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, buckets, hashCode % buckets.length, false, true);
                }
            }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, false);
            }
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
            }
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, true);
            }
            /*int */ System$Collections$Generic$IList$$$IndexOf(/*KeyValuePair<TKey, TValue>*/ item)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(item.Key, TKey), "item");
                /*int*/ let index = this.IndexOf$1(item.Key);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(item.Value, $.$$.System.Array.$ReadT1.call(this._entries, index).Value))
                    {
                        return index;
                    }
                }
                return -1;
            }
            /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*KeyValuePair<TKey, TValue>*/ item)
            {
                return this.Insert(index, item.Key, item.Value);
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ item)
            {
                return this.Add(item.Key, item.Value);
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ item)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(item.Key, TKey), "item");
                /*TValue?*/ let value;
                return this.TryGetValue$1(item.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, item.Value);
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ arrayIndex)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                if (((array.length - arrayIndex) | 0) < this._count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this._count; i++)
                {
                    /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, i, false, true);
                    $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(entry.$v.Key, entry.$v.Value), arrayIndex++);
                }
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ item)
            {
                /*TValue?*/ let value;
                return this.TryGetValue$1(item.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, item.Value) && this.Remove$1(item.Key);
            }
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                let tkey;
                if (!$.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                /*TValue*/ let tvalue = $.$default(TValue);
                if (!(value === null))
                {
                    let temp;
                    if (!$.$is(value, TValue, { set $v(v){ temp = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                    tvalue = temp;
                }
                this.Add(tkey, tvalue);
            }
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                return $.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.ContainsKey(tkey);
            }
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    this.Remove$1(tkey);
                }
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                let tarray;
                if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ tarray = v; } }))
                {
                    (this).System$Collections$Generic$ICollection$$$CopyTo(tarray, index, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
                else 
                {
                    try
                    {
                        let objects;
                        if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                        var $en4 = this.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var pair = $en4.Current;
                            {
                                $.$$.System.Array.$WriteT1.call(objects, pair, index++);
                            }
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                let pair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.Add(pair.Key, pair.Value);
                return ((this.Count - 1) | 0);
            }
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                let pair;
                /*TValue?*/ let v;
                return $.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }) && this.TryGetValue$1(pair.Key, $.$ref(() => v, ($v) => v = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(v, pair.Value);
            }
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                let pair;
                if ($.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    return (this).System$Collections$Generic$IList$$$IndexOf(pair, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
                return -1;
            }
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                let pair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.Insert(index, pair.Key, pair.Value);
            }
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                let pair;
                if ($.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    (this).System$Collections$Generic$ICollection$$$Remove(pair, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
            }
            static $_Entry;
            static get Entry()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_Entry ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.Entry", ($self) => class Entry extends $.$$.System.ValueType
                {
                    /*int*/  get Next() { return this.$getField(0, 4); }
                    /*int*/  set Next(value) { this.$setField(0, 4, value); }
                    /*uint*/  get HashCode() { return this.$getField(4, 4); }
                    /*uint*/  set HashCode(value) { this.$setField(4, 4, value); }
                    /*TKey*/  get Key() { return this.$getField(8, 4); }
                    /*TKey*/  set Key(value) { this.$setField(8, 4, value); }
                    /*TValue*/  get Value() { return this.$getField(12, 4); }
                    /*TValue*/  set Value(value) { this.$setField(12, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Next = this.Next;
                        copy.HashCode = this.HashCode;
                        copy.Key = this.Key;
                        copy.Value = this.Value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Next = 0;
                        this.HashCode = 0;
                        this.Key = $.$default(TKey);
                        this.Value = $.$default(TValue);
                    }
                    static $h = 917509;
                    static $z = 16;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Entry`; }
                }, $cls, ($v) => $cls.$_Entry = $v);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*OrderedDictionary<TKey, TValue>*/  get _dictionary() { return this.$getField(0, 4); }
                    /*OrderedDictionary<TKey, TValue>*/  set _dictionary(value) { this.$setField(0, 4, value); }
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    /*bool*/  get _useDictionaryEntry() { return this.$getField(8, 1); }
                    /*bool*/  set _useDictionaryEntry(value) { this.$setField(8, 1, value); }
                    /*int*/  get _index() { return this.$getField(9, 4); }
                    /*int*/  set _index(value) { this.$setField(9, 4, value); }
                    $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary, /*bool*/ useDictionaryEntry)
                    {
                        super.$ctor$1();
                        {
                            this._dictionary = dictionary;
                            this._version = this._dictionary._version;
                            this._useDictionaryEntry = useDictionaryEntry;
                        }
                        return this;
                    }
                    /*KeyValuePair<TKey, TValue>*/  get Current() { return this.$getField(13, 8); }
                    /*KeyValuePair<TKey, TValue>*/  set Current(value) { this.$setField(13, 8, value); }
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this._useDictionaryEntry ? new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue)) : this.Current;
                    }
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                    }
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return $.$box(this.Current.Key, TKey);
                    }
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return $.$box(this.Current.Value, TValue);
                    }
                    /*bool */ MoveNext()
                    {
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        if (this._version !== dictionary._version)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                        }
                        if (this._index < dictionary._count)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(dictionary._entries === null), "dictionary._entries is not null");
                            /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, dictionary._entries, this._index, false, true);
                            this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(entry.$v.Key, entry.$v.Value);
                            this._index++;
                            return true;
                        }
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                        return false;
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        if (this._version !== this._dictionary._version)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                        }
                        this._index = 0;
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                    }
                    /*void */ System$IDisposable$Dispose()
                    {
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._dictionary = this._dictionary;
                        copy._version = this._version;
                        copy._useDictionaryEntry = this._useDictionaryEntry;
                        copy._index = this._index;
                        copy.Current = this.Current.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._dictionary = null;
                        this._version = 0;
                        this._useDictionaryEntry = false;
                        this._index = 0;
                        this.Current = $.$default($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    static $h = 983045;
                    static $z = 21;
                    static $f = 0b100010000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            static $_KeyCollection;
            static get KeyCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_KeyCollection ??= $asm.$ncls("$sc.System.Collections.Generic.OrderedDictionary$$$.KeyCollection", ($self) => class KeyCollection extends $.$$.System.Object
                {
                    /*OrderedDictionary<TKey, TValue>*/ _dictionary = null;
                    $ctor$1(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        this._dictionary = dictionary;
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return false;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    /*bool */ Contains(/*TKey*/ key)
                    {
                        return this._dictionary.ContainsKey(key);
                    }
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        let key;
                        return $.$is(value, TKey, { set $v(v){ key = v; } }) && this.Contains(key);
                    }
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ arrayIndex)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        /*int*/ let count = dictionary._count;
                        if (((array.length - arrayIndex) | 0) < count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_ArrayPlusOffTooSmall, "array");
                        }
                        /*Entry[]?*/ let entries = dictionary._entries;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(entries, i).Key, arrayIndex++);
                        }
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let keys;
                        if ($.$is(array, $.$typeArray(TKey), { set $v(v){ keys = v; } }))
                        {
                            this.CopyTo(keys, index);
                        }
                        else 
                        {
                            try
                            {
                                let objects;
                                if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                                }
                                var $en6 = this.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var key = $en6.Current;
                                    {
                                        $.$$.System.Array.$WriteT1.call(objects, $.$box(key, TKey), index++);
                                    }
                                }
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    /*TKey*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Key;
                    }
                    /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*TKey*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        return $.$box(this._dictionary.GetAt(index).Key, TKey);
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*TKey*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Key;
        ;
                    }
                    /*Enumerator */ GetEnumerator()
                    {
                        return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection.Enumerator)().$ctor$3(this._dictionary);
                    }
                    /*IEnumerator<TKey> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TKey]);
                    }
                    /*int */ System$Collections$Generic$IList$$$IndexOf(/*TKey*/ item)
                    {
                        return this._dictionary.IndexOf$1(item);
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TKey*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TKey*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TKey*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        let key;
                        return $.$is(value, TKey, { set $v(v){ key = v; } }) ? this._dictionary.IndexOf$1(key) : -1;
                    }
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.KeyCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  get _enumerator() { return this.$getField(0, 21); }
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  set _enumerator(value) { this.$setField(0, 21, value); }
                            $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                this._enumerator = dictionary.GetEnumerator();
                                return this;
                            }
                            /*TKey */ get Current()
                            {
                                return this._enumerator.Current.Key;
                            }
                            /*object */ get System$Collections$IEnumerator$Current()
                            {
                                return $.$box(this.Current, TKey);
                            }
                            /*bool */ MoveNext()
                            {
                                return this._enumerator.MoveNext();
                            }
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                return $.$sc.System.Collections.Generic.EnumerableHelpers.Reset($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                            }
                            /*void */ System$IDisposable$Dispose()
                            {
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = $.$default($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator);
                            }
                            static $h = 1114117;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TKey>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    static $h = 1048581;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TKey), $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.Generic.IReadOnlyList$$(TKey), $.$$.System.Collections.Generic.IReadOnlyCollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection`; }
                }, $cls, ($v) => $cls.$_KeyCollection = $v);
            }
            static $_ValueCollection;
            static get ValueCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_ValueCollection ??= $asm.$ncls("$sc.System.Collections.Generic.OrderedDictionary$$$.ValueCollection", ($self) => class ValueCollection extends $.$$.System.Object
                {
                    /*OrderedDictionary<TKey, TValue>*/ _dictionary = null;
                    $ctor$1(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        this._dictionary = dictionary;
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return false;
                    }
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ arrayIndex)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        /*int*/ let count = dictionary._count;
                        if (((array.length - arrayIndex) | 0) < count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_ArrayPlusOffTooSmall, "array");
                        }
                        /*Entry[]?*/ let entries = dictionary._entries;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(entries, i).Value, arrayIndex++);
                        }
                    }
                    /*Enumerator */ GetEnumerator()
                    {
                        return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection.Enumerator)().$ctor$3(this._dictionary);
                    }
                    /*TValue*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Value;
                    }
                    /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*TValue*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Value;
        ;
                    }
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        return $.$box(this._dictionary.GetAt(index).Value, TValue);
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Contains(/*TValue*/ item)
                    {
                        return this._dictionary.ContainsValue(item);
                    }
                    /*IEnumerator<TValue> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TValue]);
                    }
                    /*int */ System$Collections$Generic$IList$$$IndexOf(/*TValue*/ item)
                    {
                        /*Entry[]?*/ let entries = this._dictionary._entries;
                        if (!(entries === null))
                        {
                            /*int*/ let count = this._dictionary._count;
                            for(/*int*/ let i = 0; i < count; i++)
                            {
                                if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(item, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                                {
                                    return i;
                                }
                            }
                        }
                        return -1;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TValue*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TValue*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TValue*/ item)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$Clear()
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        let tvalue;
                        return value === null && $.$default(TValue) === null ? this._dictionary.ContainsValue($.$default(TValue)) : $.$is(value, TValue, { set $v(v){ tvalue = v; } }) && this._dictionary.ContainsValue(tvalue);
                    }
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        /*Entry[]?*/ let entries = this._dictionary._entries;
                        if (!(entries === null))
                        {
                            /*int*/ let count = this._dictionary._count;
                            let tvalue;
                            if (value === null && $.$default(TValue) === null)
                            {
                                for(/*int*/ let i = 0; i < count; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(entries, i).Value === null)
                                    {
                                        return i;
                                    }
                                }
                            }
                            else if ($.$is(value, TValue, { set $v(v){ tvalue = v; } }))
                            {
                                for(/*int*/ let i = 0; i < count; i++)
                                {
                                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(tvalue, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                                    {
                                        return i;
                                    }
                                }
                            }
                        }
                        return -1;
                    }
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let values;
                        if ($.$is(array, $.$typeArray(TValue), { set $v(v){ values = v; } }))
                        {
                            this.CopyTo(values, index);
                        }
                        else 
                        {
                            try
                            {
                                let objects;
                                if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                                }
                                var $en6 = this.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var value = $en6.Current;
                                    {
                                        $.$$.System.Array.$WriteT1.call(objects, $.$box(value, TValue), index++);
                                    }
                                }
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.ValueCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  get _enumerator() { return this.$getField(0, 21); }
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  set _enumerator(value) { this.$setField(0, 21, value); }
                            $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                this._enumerator = dictionary.GetEnumerator();
                                return this;
                            }
                            /*TValue */ get Current()
                            {
                                return this._enumerator.Current.Value;
                            }
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                return $.$box(this.Current, TValue);
                            }
                            /*bool */ MoveNext()
                            {
                                return this._enumerator.MoveNext();
                            }
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                return $.$sc.System.Collections.Generic.EnumerableHelpers.Reset($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                            }
                            /*void */ System$IDisposable$Dispose()
                            {
                            }
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                return this.Current;
                            }
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                return this.MoveNext(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = $.$default($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator);
                            }
                            static $h = 1245189;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection.$h,"h":this.$h}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TValue>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        return this.Count;
                    }
                    static $h = 1179653;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":$.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TValue), $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.Generic.IReadOnlyList$$(TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection`; }
                }, $cls, ($v) => $cls.$_ValueCollection = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                return this.Remove$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                return this.TryGetValue$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                return this.TryGetValue$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<TKey, TValue>>.RemoveAt(int)
            System$Collections$Generic$IList$$$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            static $h = 851973;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.IDictionary, $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        
        $asm.$cls("$sc.System.Collections.Generic.TreeSet<>", (T) => $asm.$gt("$sc.System.Collections.Generic.TreeSet<>", [T], ($self) => class TreeSet$$ extends $.$sc.System.Collections.Generic.SortedSet$$(T)
        {
            $ctor$6()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$7(/*IComparer<T>?*/ comparer)
            {
                super.$ctor$2(comparer);
                {
                }
                return this;
            }
            $ctor$9(/*TreeSet<T>*/ set, /*IComparer<T>?*/ comparer)
            {
                super.$ctor$3(set, comparer);
                {
                }
                return this;
            }
            $ctor$8(/*SerializationInfo*/ siInfo, /*StreamingContext*/ context)
            {
                super.$ctor$5(siInfo, context);
                {
                }
                return this;
            }
            /*bool */ AddIfNotPresent(/*T*/ item)
            {
                /*bool*/ let ret = super.AddIfNotPresent(item);
                if (!ret)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(item, T)));
                }
                return ret;
            }
            static $h = 3080197;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sc.System.Collections.Generic.SortedSet$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.TreeSet<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))