
//--TRIMMABLE-BOUNDARY-START(13)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Collections", 
    {
  "h": 13,
  "f": "System.Collections",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Collections",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Collections",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(3276813)
        $asm.$cls("$sc.System.Collections.ObjectModel.CollectionHelpers", ($self) => class CollectionHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(8593211405)
            static /*void */ ValidateCopyToArguments(/*int*/ sourceCount, /*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593211405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, index, array.length, "index");
                if (((array.length - index) | 0) < sourceCount)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593211405)
            
            //--TRIMMABLE-BOUNDARY-START(4298244109)
            static /*void */ CopyTo(T, /*ICollection<T>*/ collection, /*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298244109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sc.System.Collections.ObjectModel.CollectionHelpers.ValidateCopyToArguments(collection.System$Collections$Generic$ICollection$$$Count, array, index);
                let nonGenericCollection;
                let items;
                if ($.$is(collection, $.$$.System.Collections.ICollection, { set $v(v){ nonGenericCollection = v; } }))
                {
                    nonGenericCollection.System$Collections$ICollection$CopyTo(array, index);
                }
                else if ($.$is(array, $.$typeArray(T), { set $v(v){ items = v; } }))
                {
                    collection.System$Collections$Generic$ICollection$$$CopyTo(items, index, [T]);
                }
                else 
                {
                    let objects;
                    if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        var $en4 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                $.$$.System.Array.$WriteT1.call(objects, $.$box(item, T), index++);
                            }
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298244109)
            
            static $h = 3276813;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3276813
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.ObjectModel.CollectionHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276813)
        
        
        //--TRIMMABLE-BOUNDARY-START(393229)
        $asm.$cls("$sc.System.Collections.Generic.ICollectionDebugView<>", (T) => $asm.$gt("$sc.System.Collections.Generic.ICollectionDebugView<>", [T], ($self) => class ICollectionDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360525)
            /*ICollection<T>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4295360525)
            
            //--TRIMMABLE-BOUNDARY-START(8590327821)
            $ctor$1(/*ICollection<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327821);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._collection = collection;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327821)
            
            //--TRIMMABLE-BOUNDARY-START(21475229709)
            /*T[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [T]);
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229709)
            
            static $h = 393229;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.ICollectionDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393229)
        
        
        //--TRIMMABLE-BOUNDARY-START(458765)
        $asm.$cls("$sc.System.Collections.Generic.IDictionaryDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.IDictionaryDebugView<,>", [TKey, TValue], ($self) => class IDictionaryDebugView$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426061)
            /*IDictionary<TKey, TValue>*/ _dict = null;
            //--TRIMMABLE-BOUNDARY-END(4295426061)
            
            //--TRIMMABLE-BOUNDARY-START(8590393357)
            $ctor$1(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393357);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._dict = $.$firstOf(dictionary, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("dictionary") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393357)
            
            //--TRIMMABLE-BOUNDARY-START(21475295245)
            /*DebugViewDictionaryItem<TKey, TValue>[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180327949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let keyValuePairs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), null, [this._dict.System$Collections$Generic$ICollection$$$Count], null);
                this._dict.System$Collections$Generic$ICollection$$$CopyTo(keyValuePairs, 0, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                /*var*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue)), null, [keyValuePairs.length], null);
                for(/*int*/ let i = 0; i < items.length; i++)
                {
                    $.$$.System.Array.$WriteT1.call(items, new ($.$sc.System.Collections.Generic.DebugViewDictionaryItem$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(keyValuePairs, i)), i);
                }
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295245)
            
            static $h = 458765;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.IDictionaryDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(458765)
        
        
        //--TRIMMABLE-BOUNDARY-START(3538957)
        $asm.$cls("$sc.System.Collections.ThrowHelper", ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(17183408141)
            static /*void */ ThrowKeyNotFound(TKey, /*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183408141);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$box(key, TKey)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17183408141)
            
            //--TRIMMABLE-BOUNDARY-START(8593473549)
            static /*void */ ThrowDuplicateKey(TKey, /*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593473549);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593473549)
            
            //--TRIMMABLE-BOUNDARY-START(4298506253)
            static /*void */ ThrowConcurrentOperation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298506253);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_ConcurrentOperationsNotSupported);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298506253)
            
            //--TRIMMABLE-BOUNDARY-START(12888440845)
            static /*void */ ThrowIndexArgumentOutOfRange()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888440845);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("index");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888440845)
            
            //--TRIMMABLE-BOUNDARY-START(21478375437)
            static /*void */ ThrowVersionCheckFailed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478375437);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478375437)
            
            static $h = 3538957;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3538957
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3538957)
        
        
        //--TRIMMABLE-BOUNDARY-START(3670029)
        $asm.$cls("$sc.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(489629941773)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(489629941773)
            
            //--TRIMMABLE-BOUNDARY-START(481040007181)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(481040007181)
            
            //--TRIMMABLE-BOUNDARY-START(485334974477)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369370857485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sc.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Collections", $.$sc.System.SR.$type.Assembly);
                    $.$sc.System.SR.s_resourceManager = temp;
                }
                return $.$sc.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(485334974477)
            
            //--TRIMMABLE-BOUNDARY-START(68723146765)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249111773197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sc.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519694712845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sc.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68723146765)
            
            //--TRIMMABLE-BOUNDARY-START(25773473805)
            static /*string */ get Arg_NonZeroLowerBound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212427277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The lower bound of target array must be zero.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773473805)
            
            //--TRIMMABLE-BOUNDARY-START(34363408397)
            static /*string */ get Arg_WrongType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180392296461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value '{0}' is not of type '{1}' and cannot be used in this generic collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(34363408397)
            
            //--TRIMMABLE-BOUNDARY-START(115967787021)
            static /*string */ FormatArg_WrongType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115967787021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The value '{0}' is not of type '{1}' and cannot be used in this generic collection.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(115967787021)
            
            //--TRIMMABLE-BOUNDARY-START(8593604621)
            static /*string */ get Arg_ArrayPlusOffTooSmall()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852688909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination array is not long enough to copy all the items in the collection. Check array index and length.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593604621)
            
            //--TRIMMABLE-BOUNDARY-START(64428179469)
            static /*string */ get ArgumentOutOfRange_SmallCapacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240521838605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "capacity was less than the current size.";
            }
            //--TRIMMABLE-BOUNDARY-END(64428179469)
            
            //--TRIMMABLE-BOUNDARY-START(47248310285)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206162100237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(47248310285)
            
            //--TRIMMABLE-BOUNDARY-START(38658375693)
            static /*string */ get Argument_AddingDuplicate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188982231053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An item with the same key has already been added. Key: {0}";
            }
            //--TRIMMABLE-BOUNDARY-END(38658375693)
            
            //--TRIMMABLE-BOUNDARY-START(120262754317)
            static /*string */ FormatArgument_AddingDuplicate(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262754317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("An item with the same key has already been added. Key: {0}", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(120262754317)
            
            //--TRIMMABLE-BOUNDARY-START(429500399629)
            static /*string */ get InvalidOperation_ConcurrentOperationsNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291642381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Operations that change non-concurrent collections must have exclusive access. A concurrent update was performed on this collection and corrupted its state. The collection's state is no longer correct.";
            }
            //--TRIMMABLE-BOUNDARY-END(429500399629)
            
            //--TRIMMABLE-BOUNDARY-START(433795366925)
            static /*string */ get InvalidOperation_EmptyQueue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881576973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Queue empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(433795366925)
            
            //--TRIMMABLE-BOUNDARY-START(455270203405)
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317831249933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has either not started or has already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(455270203405)
            
            //--TRIMMABLE-BOUNDARY-START(446680268813)
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300651380749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Collection was modified after the enumerator was instantiated.";
            }
            //--TRIMMABLE-BOUNDARY-END(446680268813)
            
            //--TRIMMABLE-BOUNDARY-START(438090334221)
            static /*string */ get InvalidOperation_EmptyStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283471511565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stack empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(438090334221)
            
            //--TRIMMABLE-BOUNDARY-START(450975236109)
            static /*string */ get InvalidOperation_EnumNotStarted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309241315341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration has not started. Call MoveNext.";
            }
            //--TRIMMABLE-BOUNDARY-END(450975236109)
            
            //--TRIMMABLE-BOUNDARY-START(442385301517)
            static /*string */ get InvalidOperation_EnumEnded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292061446157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Enumeration already finished.";
            }
            //--TRIMMABLE-BOUNDARY-END(442385301517)
            
            //--TRIMMABLE-BOUNDARY-START(468155105293)
            static /*string */ get NotSupported_KeyCollectionSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343601053709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mutating a key collection derived from a dictionary is not allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(468155105293)
            
            //--TRIMMABLE-BOUNDARY-START(476745039885)
            static /*string */ get NotSupported_ValueCollectionSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360780922893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mutating a value collection derived from a dictionary is not allowed.";
            }
            //--TRIMMABLE-BOUNDARY-END(476745039885)
            
            //--TRIMMABLE-BOUNDARY-START(12888571917)
            static /*string */ get Arg_HTCapacityOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442623501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Hashtable's capacity overflowed and went negative. Check load factor, capacity and the current size of the table.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888571917)
            
            //--TRIMMABLE-BOUNDARY-START(17183539213)
            static /*string */ get Arg_InsufficientSpace()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032558093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Insufficient space in the target location to copy the information.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183539213)
            
            //--TRIMMABLE-BOUNDARY-START(30068441101)
            static /*string */ get Arg_RankMultiDimNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171802361869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only single dimensional arrays are supported for the requested action.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068441101)
            
            //--TRIMMABLE-BOUNDARY-START(42953342989)
            static /*string */ get Argument_IncompatibleArrayType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197572165645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Target array type is not compatible with the type of items in the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(42953342989)
            
            //--TRIMMABLE-BOUNDARY-START(51543277581)
            static /*string */ get ArgumentOutOfRange_BiggerThanCollection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214752034829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Must be less than or equal to the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(51543277581)
            
            //--TRIMMABLE-BOUNDARY-START(55838244877)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341969421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(55838244877)
            
            //--TRIMMABLE-BOUNDARY-START(60133212173)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231931904013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(60133212173)
            
            //--TRIMMABLE-BOUNDARY-START(73018114061)
            static /*string */ get ExternalLinkedListNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257701707789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The LinkedList node does not belong to current LinkedList.";
            }
            //--TRIMMABLE-BOUNDARY-END(73018114061)
            
            //--TRIMMABLE-BOUNDARY-START(459565170701)
            static /*string */ get LinkedListEmpty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326421184525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The LinkedList is empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(459565170701)
            
            //--TRIMMABLE-BOUNDARY-START(463860137997)
            static /*string */ get LinkedListNodeIsAttached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335011119117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The LinkedList node already belongs to a LinkedList.";
            }
            //--TRIMMABLE-BOUNDARY-END(463860137997)
            
            //--TRIMMABLE-BOUNDARY-START(472450072589)
            static /*string */ get NotSupported_SortedListNestedWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352190988301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "This operation is not supported on SortedList nested types because they require modifying the original SortedList.";
            }
            //--TRIMMABLE-BOUNDARY-END(472450072589)
            
            //--TRIMMABLE-BOUNDARY-START(523989680141)
            static /*string */ get SortedSet_LowerValueGreaterThanUpperValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320530445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Must be less than or equal to upperValue.";
            }
            //--TRIMMABLE-BOUNDARY-END(523989680141)
            
            //--TRIMMABLE-BOUNDARY-START(498219876365)
            static /*string */ get Serialization_InvalidOnDeser()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377960792077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "OnDeserialization method was called while the object was not being deserialized.";
            }
            //--TRIMMABLE-BOUNDARY-END(498219876365)
            
            //--TRIMMABLE-BOUNDARY-START(502514843661)
            static /*string */ get Serialization_MismatchedCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386550726669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The serialized Count information doesn't match the number of items.";
            }
            //--TRIMMABLE-BOUNDARY-END(502514843661)
            
            //--TRIMMABLE-BOUNDARY-START(506809810957)
            static /*string */ get Serialization_MissingKeys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140661261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The keys for this dictionary are missing.";
            }
            //--TRIMMABLE-BOUNDARY-END(506809810957)
            
            //--TRIMMABLE-BOUNDARY-START(511104778253)
            static /*string */ get Serialization_MissingValues()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730595853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The values for this dictionary are missing.";
            }
            //--TRIMMABLE-BOUNDARY-END(511104778253)
            
            //--TRIMMABLE-BOUNDARY-START(21478506509)
            static /*string */ get Arg_KeyNotFoundWithKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622492685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The given key '{0}' was not present in the dictionary.";
            }
            //--TRIMMABLE-BOUNDARY-END(21478506509)
            
            //--TRIMMABLE-BOUNDARY-START(111672819725)
            static /*string */ FormatArg_KeyNotFoundWithKey(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672819725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The given key '{0}' was not present in the dictionary.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(111672819725)
            
            //--TRIMMABLE-BOUNDARY-START(493924909069)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(493924909069)
            
            //--TRIMMABLE-BOUNDARY-START(425205432333)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(425205432333);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(425205432333)
            
            //--TRIMMABLE-BOUNDARY-START(528284647437)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(528284647437);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sc.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(528284647437)
            
            //--TRIMMABLE-BOUNDARY-START(420910465037)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910465037);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sc.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(420910465037)
            
            //--TRIMMABLE-BOUNDARY-START(416615497741)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416615497741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sc.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(416615497741)
            
            //--TRIMMABLE-BOUNDARY-START(103082885133)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082885133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(103082885133)
            
            //--TRIMMABLE-BOUNDARY-START(98787917837)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787917837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(98787917837)
            
            //--TRIMMABLE-BOUNDARY-START(94492950541)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492950541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(94492950541)
            
            //--TRIMMABLE-BOUNDARY-START(107377852429)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107377852429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(107377852429)
            
            //--TRIMMABLE-BOUNDARY-START(85903015949)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85903015949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(85903015949)
            
            //--TRIMMABLE-BOUNDARY-START(81608048653)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608048653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(81608048653)
            
            //--TRIMMABLE-BOUNDARY-START(77313081357)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77313081357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(77313081357)
            
            //--TRIMMABLE-BOUNDARY-START(90197983245)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197983245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sc.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(90197983245)
            
            //--TRIMMABLE-BOUNDARY-START(4298637325)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(493924909069)
                    this.s_usingResourceKeys = $.$sc.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(493924909069)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298637325)
            
            static $h = 3670029;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3670029
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3670029)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949133)
        $asm.$cls("$sc.System.Collections.Generic.StackDebugView<>", (T) => $asm.$gt("$sc.System.Collections.Generic.StackDebugView<>", [T], ($self) => class StackDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297916429)
            /*Stack<T>*/ _stack = null;
            //--TRIMMABLE-BOUNDARY-END(4297916429)
            
            //--TRIMMABLE-BOUNDARY-START(8592883725)
            $ctor$1(/*Stack<T>*/ stack)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592883725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(stack, "stack");
                    this._stack = stack;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592883725)
            
            //--TRIMMABLE-BOUNDARY-START(21477785613)
            /*T[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182818317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._stack.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(21477785613)
            
            static $h = 2949133;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.StackDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2949133)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310733)
        $asm.$cls("$sc.System.Collections.Generic.PriorityQueue<,>", (TElement, TPriority) => $asm.$gt("$sc.System.Collections.Generic.PriorityQueue<,>", [TElement, TPriority], ($self) => class PriorityQueue$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591245325)
            /*(TElement Element, TPriority Priority)[]*/ _nodes = null;
            //--TRIMMABLE-BOUNDARY-END(8591245325)
            
            //--TRIMMABLE-BOUNDARY-START(4296278029)
            /*IComparer<TPriority>?*/ _comparer = null;
            //--TRIMMABLE-BOUNDARY-END(4296278029)
            
            //--TRIMMABLE-BOUNDARY-START(12886212621)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(12886212621)
            
            //--TRIMMABLE-BOUNDARY-START(17181179917)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(17181179917)
            
            //--TRIMMABLE-BOUNDARY-START(60130852877)
            /*int*/ static Arity = 4;
            //--TRIMMABLE-BOUNDARY-END(60130852877)
            
            //--TRIMMABLE-BOUNDARY-START(171800002573)
            /*int*/ static Log2Arity = 2;
            //--TRIMMABLE-BOUNDARY-END(171800002573)
            
            //--TRIMMABLE-BOUNDARY-START(30066081805)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(2/*Log2Arity*/ > 0 && Math.pow(2, 2/*Log2Arity*/) === 4/*Arity*/, "Log2Arity > 0 && Math.Pow(2, Log2Arity) == Arity");
            }
            //--TRIMMABLE-BOUNDARY-END(30066081805)
            
            //--TRIMMABLE-BOUNDARY-START(34361049101)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361049101);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._nodes = $.$$.System.Array.Empty($.$$.System.ValueTuple$$$(TElement, TPriority));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361049101)
            
            //--TRIMMABLE-BOUNDARY-START(55835885581)
            $ctor$6(/*int*/ initialCapacity)
            {
                this.$ctor$5(initialCapacity, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835885581);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835885581)
            
            //--TRIMMABLE-BOUNDARY-START(38656016397)
            $ctor$2(/*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656016397);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._nodes = $.$$.System.Array.Empty($.$$.System.ValueTuple$$$(TElement, TPriority));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656016397)
            
            //--TRIMMABLE-BOUNDARY-START(51540918285)
            $ctor$5(/*int*/ initialCapacity, /*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540918285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, initialCapacity, "initialCapacity");
                    this._nodes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.ValueTuple$$$(TElement, TPriority)), null, [initialCapacity], null);
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540918285)
            
            //--TRIMMABLE-BOUNDARY-START(47245950989)
            $ctor$4(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items)
            {
                this.$ctor$3(items, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245950989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245950989)
            
            //--TRIMMABLE-BOUNDARY-START(42950983693)
            $ctor$3(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items, /*IComparer<TPriority>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950983693);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                    this._nodes = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray($.$$.System.ValueTuple$$$(TElement, TPriority), items, $.$ref(() => this._size, ($v) => this._size = $v, $.$$.System.Int32));
                    this._comparer = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).InitializeComparer(comparer);
                    if (this._size > 1)
                    {
                        this.Heapify();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950983693)
            
            //--TRIMMABLE-BOUNDARY-START(77310722061)
            /*int */ get Count()
            {
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(77310722061)
            
            //--TRIMMABLE-BOUNDARY-START(64425820173)
            /*int */ get Capacity()
            {
                return this._nodes.length;
            }
            //--TRIMMABLE-BOUNDARY-END(64425820173)
            
            //--TRIMMABLE-BOUNDARY-START(73015754765)
            /*IComparer<TPriority> */ get Comparer()
            {
                return this._comparer ?? $.$$.System.Collections.Generic.Comparer$$(TPriority).Default;
            }
            //--TRIMMABLE-BOUNDARY-END(73015754765)
            
            //--TRIMMABLE-BOUNDARY-START(219044642829)
            /*UnorderedItemsCollection*/ UnorderedItems$ = null;
            /*UnorderedItemsCollection */ get UnorderedItems()
            {
                return this.UnorderedItems$ ??= new ($.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection)().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(219044642829)
            
            //--TRIMMABLE-BOUNDARY-START(90195623949)
            /*void */ Enqueue(/*TElement*/ element, /*TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195623949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let currentSize = this._size;
                this._version++;
                if (this._nodes.length === currentSize)
                {
                    this.Grow(((currentSize + 1) | 0));
                }
                this._size = ((currentSize + 1) | 0);
                if (this._comparer === null)
                {
                    this.MoveUpDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), currentSize);
                }
                else 
                {
                    this.MoveUpCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), currentSize);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195623949)
            
            //--TRIMMABLE-BOUNDARY-START(193274839053)
            /*TElement */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274839053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                return $.$$.System.Array.$ReadT1.call(this._nodes, 0).Item1;
            }
            //--TRIMMABLE-BOUNDARY-END(193274839053)
            
            //--TRIMMABLE-BOUNDARY-START(81605689357)
            /*TElement */ Dequeue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605689357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                /*TElement*/ let element = $.$$.System.Array.$ReadT1.call(this._nodes, 0).Item1;
                this.RemoveRootNode();
                return element;
            }
            //--TRIMMABLE-BOUNDARY-END(81605689357)
            
            //--TRIMMABLE-BOUNDARY-START(85900656653)
            /*TElement */ DequeueEnqueue(/*TElement*/ element, /*TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyQueue);
                }
                /*(TElement Element, TPriority Priority)*/ let root = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                if (this._comparer === null)
                {
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(priority, root.Item2) > 0)
                    {
                        this.MoveDownDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                    }
                    else 
                    {
                        $.$$.System.Array.$WriteT1.call(this._nodes, { Item1: element, Item2: priority }, 0);
                    }
                }
                else 
                {
                    if (this._comparer.System$Collections$Generic$IComparer$$$Compare(priority, root.Item2, [TPriority]) > 0)
                    {
                        this.MoveDownCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                    }
                    else 
                    {
                        $.$$.System.Array.$WriteT1.call(this._nodes, { Item1: element, Item2: priority }, 0);
                    }
                }
                this._version++;
                return root.Item1;
            }
            //--TRIMMABLE-BOUNDARY-END(85900656653)
            
            //--TRIMMABLE-BOUNDARY-START(210454708237)
            /*bool */ TryDequeue(/*out TElement*/ element, /*out TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454708237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size !== 0)
                {
                    $.$tupleUnpack(($tp) =>
                    {
                        element.$v = $tp.Item1;
                        priority.$v = $tp.Item2;
                    }).$v = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    this.RemoveRootNode();
                    return true;
                }
                element.$v = $.$default(TElement);
                priority.$v = $.$default(TPriority);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(210454708237)
            
            //--TRIMMABLE-BOUNDARY-START(214749675533)
            /*bool */ TryPeek(/*out TElement*/ element, /*out TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749675533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size !== 0)
                {
                    $.$tupleUnpack(($tp) =>
                    {
                        element.$v = $tp.Item1;
                        priority.$v = $tp.Item2;
                    }).$v = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    return true;
                }
                element.$v = $.$default(TElement);
                priority.$v = $.$default(TPriority);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(214749675533)
            
            //--TRIMMABLE-BOUNDARY-START(94490591245)
            /*TElement */ EnqueueDequeue(/*TElement*/ element, /*TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size !== 0)
                {
                    /*(TElement Element, TPriority Priority)*/ let root = $.$$.System.Array.$ReadT1.call(this._nodes, 0);
                    if (this._comparer === null)
                    {
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(priority, root.Item2) > 0)
                        {
                            this.MoveDownDefaultComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                            this._version++;
                            return root.Item1;
                        }
                    }
                    else 
                    {
                        if (this._comparer.System$Collections$Generic$IComparer$$$Compare(priority, root.Item2, [TPriority]) > 0)
                        {
                            this.MoveDownCustomComparer(new ($.$$.System.ValueTuple$$$(TElement, TPriority))().$ctor$3(element, priority), 0);
                            this._version++;
                            return root.Item1;
                        }
                    }
                }
                return element;
            }
            //--TRIMMABLE-BOUNDARY-END(94490591245)
            
            //--TRIMMABLE-BOUNDARY-START(98785558541)
            /*void */ EnqueueRange(/*IEnumerable<(TElement Element, TPriority Priority)>*/ items)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785558541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(items, "items");
                /*int*/ let count = 0;
                /*var*/ let collection = $.$as(items, $.$$.System.Collections.Generic.ICollection$$($.$$.System.ValueTuple$$$(TElement, TPriority)));
                if (!(collection === null) && (count = collection.System$Collections$Generic$ICollection$$$Count) > ((this._nodes.length - this._size) | 0))
                {
                    this.Grow($.$checked(this._size + count, 1));
                }
                if (this._size === 0)
                {
                    if (!(collection === null))
                    {
                        collection.System$Collections$Generic$ICollection$$$CopyTo(this._nodes, 0, [$.$$.System.ValueTuple$$$(TElement, TPriority)]);
                        this._size = count;
                    }
                    else 
                    {
                        /*int*/ let i = 0;
                        /*(TElement, TPriority)[]*/ let nodes = this._nodes;
                        var $en4 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var $t1 = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            /*TElement*/ let element = $t1.Item1;
                            /*TPriority*/ let priority = $t1.Item2;
                            {
                                if (nodes.length === i)
                                {
                                    this.Grow(((i + 1) | 0));
                                    nodes = this._nodes;
                                }
                                $.$$.System.Array.$WriteT1.call(nodes, { Item1: element, Item2: priority }, i++);
                            }
                        }
                        this._size = i;
                    }
                    this._version++;
                    if (this._size > 1)
                    {
                        this.Heapify();
                    }
                }
                else 
                {
                    var $en3 = items.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var $t1 = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        /*TElement*/ let element = $t1.Item1;
                        /*TPriority*/ let priority = $t1.Item2;
                        {
                            this.Enqueue(element, priority);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785558541)
            
            //--TRIMMABLE-BOUNDARY-START(103080525837)
            /*void */ EnqueueRange$1(/*IEnumerable<TElement>*/ elements, /*TPriority*/ priority)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elements, "elements");
                /*int*/ let count;
                let collection;
                if ($.$is(elements, $.$$.System.Collections.Generic.ICollection$$(TElement), { set $v(v){ collection = v; } }) && (count = collection.System$Collections$Generic$ICollection$$$Count) > ((this._nodes.length - this._size) | 0))
                {
                    this.Grow($.$checked(this._size + count, 1));
                }
                if (this._size === 0)
                {
                    /*int*/ let i = 0;
                    /*(TElement, TPriority)[]*/ let nodes = this._nodes;
                    var $en3 = elements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (nodes.length === i)
                            {
                                this.Grow(((i + 1) | 0));
                                nodes = this._nodes;
                            }
                            $.$$.System.Array.$WriteT1.call(nodes, { Item1: element, Item2: priority }, i++);
                        }
                    }
                    this._size = i;
                    this._version++;
                }
                else 
                {
                    var $en3 = elements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Enqueue(element, priority);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080525837)
            
            //--TRIMMABLE-BOUNDARY-START(197569806349)
            /*bool */ Remove(/*TElement*/ element, /*out TElement*/ removedElement, /*out TPriority*/ priority, /*IEqualityComparer<TElement>?*/ equalityComparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569806349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = this.FindIndex(element, equalityComparer);
                if (index < 0)
                {
                    removedElement.$v = $.$default(TElement);
                    priority.$v = $.$default(TPriority);
                    return false;
                }
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                $.$tupleUnpack(($tp) =>
                {
                    removedElement.$v = $tp.Item1;
                    priority.$v = $tp.Item2;
                }).$v = $.$$.System.Array.$ReadT1.call(nodes, index);
                /*int*/ let newSize = --this._size;
                if (index < newSize)
                {
                    /*(TElement Element, TPriority Priority)*/ let lastNode = $.$$.System.Array.$ReadT1.call(nodes, newSize);
                    if (this._comparer === null)
                    {
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(lastNode.Item2, priority.$v) < 0)
                        {
                            this.MoveUpDefaultComparer(lastNode.Clone(), index);
                        }
                        else 
                        {
                            this.MoveDownDefaultComparer(lastNode.Clone(), index);
                        }
                    }
                    else 
                    {
                        if (this._comparer.System$Collections$Generic$IComparer$$$Compare(lastNode.Item2, priority.$v, [TPriority]) < 0)
                        {
                            this.MoveUpCustomComparer(lastNode.Clone(), index);
                        }
                        else 
                        {
                            this.MoveDownCustomComparer(lastNode.Clone(), index);
                        }
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, new ($.$$.System.ValueTuple$$$(TElement, TPriority))(), newSize);
                this._version++;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(197569806349)
            
            //--TRIMMABLE-BOUNDARY-START(68720787469)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<(TElement, TPriority)>()) { ... }
                this._size = 0;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(68720787469)
            
            //--TRIMMABLE-BOUNDARY-START(107375493133)
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this._nodes.length < capacity)
                {
                    this.Grow(capacity);
                    this._version++;
                }
                return this._nodes.length;
            }
            //--TRIMMABLE-BOUNDARY-END(107375493133)
            
            //--TRIMMABLE-BOUNDARY-START(206159740941)
            /*void */ TrimExcess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159740941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threshold = $.$cast((this._nodes.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    $.$$.System.Array.Resize($.$$.System.ValueTuple$$$(TElement, TPriority), $.$ref(() => this._nodes, ($v) => this._nodes = $v, $.$typeArray($.$$.System.ValueTuple$$$(TElement, TPriority))), this._size);
                    this._version++;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159740941)
            
            //--TRIMMABLE-BOUNDARY-START(158915100685)
            /*void */ Grow(/*int*/ minCapacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._nodes.length < minCapacity, "_nodes.Length < minCapacity");
                /*int*/ let GrowFactor = 2;
                /*int*/ let MinimumGrow = 4;
                /*int*/ let newcapacity = ((GrowFactor * this._nodes.length) | 0);
                if (BigInt((newcapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newcapacity = $.$$.System.Array.MaxLength;
                }
                newcapacity = $.$$.System.Math.Max$4(newcapacity, ((this._nodes.length + MinimumGrow) | 0));
                if (newcapacity < minCapacity)
                {
                    newcapacity = minCapacity;
                }
                $.$$.System.Array.Resize($.$$.System.ValueTuple$$$(TElement, TPriority), $.$ref(() => this._nodes, ($v) => this._nodes = $v, $.$typeArray($.$$.System.ValueTuple$$$(TElement, TPriority))), newcapacity);
            }
            //--TRIMMABLE-BOUNDARY-END(158915100685)
            
            //--TRIMMABLE-BOUNDARY-START(201864773645)
            /*void */ RemoveRootNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864773645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let lastNodeIndex = --this._size;
                this._version++;
                if (lastNodeIndex > 0)
                {
                    /*(TElement Element, TPriority Priority)*/ let lastNode = $.$$.System.Array.$ReadT1.call(this._nodes, lastNodeIndex);
                    if (this._comparer === null)
                    {
                        this.MoveDownDefaultComparer(lastNode.Clone(), 0);
                    }
                    else 
                    {
                        this.MoveDownCustomComparer(lastNode.Clone(), 0);
                    }
                }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<(TElement, TPriority)>()) { ... }
            }
            //--TRIMMABLE-BOUNDARY-END(201864773645)
            
            //--TRIMMABLE-BOUNDARY-START(154620133389)
            static /*int */ GetParentIndex(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154620133389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (((index - 1) | 0)) >> 2/*Log2Arity*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620133389)
            
            //--TRIMMABLE-BOUNDARY-START(150325166093)
            static /*int */ GetFirstChildIndex(/*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325166093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (((index << 2/*Log2Arity*/) + 1) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325166093)
            
            //--TRIMMABLE-BOUNDARY-START(163210067981)
            /*void */ Heapify()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210067981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let lastParentWithChildren = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(((this._size - 1) | 0));
                if (this._comparer === null)
                {
                    for(/*int*/ let index = lastParentWithChildren; index >= 0; --index)
                    {
                        this.MoveDownDefaultComparer($.$$.System.Array.$ReadT1.call(nodes, index), index);
                    }
                }
                else 
                {
                    for(/*int*/ let index = lastParentWithChildren; index >= 0; --index)
                    {
                        this.MoveDownCustomComparer($.$$.System.Array.$ReadT1.call(nodes, index), index);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163210067981)
            
            //--TRIMMABLE-BOUNDARY-START(188979871757)
            /*void */ MoveUpDefaultComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979871757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._comparer === null, "_comparer is null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                while(nodeIndex > 0)
                {
                    /*int*/ let parentIndex = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(nodeIndex);
                    /*(TElement Element, TPriority Priority)*/ let parent = $.$$.System.Array.$ReadT1.call(nodes, parentIndex);
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(node.Item2, parent.Item2) < 0)
                    {
                        $.$$.System.Array.$WriteT1.call(nodes, parent, nodeIndex);
                        nodeIndex = parentIndex;
                    }
                    else 
                    {
                        break;
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(188979871757)
            
            //--TRIMMABLE-BOUNDARY-START(184684904461)
            /*void */ MoveUpCustomComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684904461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*IComparer<TPriority>*/ let comparer = this._comparer;
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                while(nodeIndex > 0)
                {
                    /*int*/ let parentIndex = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetParentIndex(nodeIndex);
                    /*(TElement Element, TPriority Priority)*/ let parent = $.$$.System.Array.$ReadT1.call(nodes, parentIndex);
                    if (comparer.System$Collections$Generic$IComparer$$$Compare(node.Item2, parent.Item2, [TPriority]) < 0)
                    {
                        $.$$.System.Array.$WriteT1.call(nodes, parent, nodeIndex);
                        nodeIndex = parentIndex;
                    }
                    else 
                    {
                        break;
                    }
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(184684904461)
            
            //--TRIMMABLE-BOUNDARY-START(180389937165)
            /*void */ MoveDownDefaultComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389937165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._comparer === null, "_comparer is null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let size = this._size;
                /*int*/ let i;
                while((i = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetFirstChildIndex(nodeIndex)) < size)
                {
                    /*(TElement Element, TPriority Priority)*/ let minChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                    /*int*/ let minChildIndex = i;
                    /*int*/ let childIndexUpperBound = $.$$.System.Math.Min$4(((i + 4/*Arity*/) | 0), size);
                    while(++i < childIndexUpperBound)
                    {
                        /*(TElement Element, TPriority Priority)*/ let nextChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                        if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(nextChild.Item2, minChild.Item2) < 0)
                        {
                            minChild = nextChild.Clone();
                            minChildIndex = i;
                        }
                    }
                    if ($.$$.System.Collections.Generic.Comparer$$(TPriority).Default.Compare(node.Item2, minChild.Item2) <= 0)
                    {
                        break;
                    }
                    $.$$.System.Array.$WriteT1.call(nodes, minChild, nodeIndex);
                    nodeIndex = minChildIndex;
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(180389937165)
            
            //--TRIMMABLE-BOUNDARY-START(176094969869)
            /*void */ MoveDownCustomComparer(/*(TElement Element, TPriority Priority)*/ node, /*int*/ nodeIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= nodeIndex && nodeIndex < this._size, "0 <= nodeIndex && nodeIndex < _size");
                /*IComparer<TPriority>*/ let comparer = this._comparer;
                /*(TElement Element, TPriority Priority)[]*/ let nodes = this._nodes;
                /*int*/ let size = this._size;
                /*int*/ let i;
                while((i = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).GetFirstChildIndex(nodeIndex)) < size)
                {
                    /*(TElement Element, TPriority Priority)*/ let minChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                    /*int*/ let minChildIndex = i;
                    /*int*/ let childIndexUpperBound = $.$$.System.Math.Min$4(((i + 4/*Arity*/) | 0), size);
                    while(++i < childIndexUpperBound)
                    {
                        /*(TElement Element, TPriority Priority)*/ let nextChild = $.$$.System.Array.$ReadT1.call(nodes, i);
                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextChild.Item2, minChild.Item2, [TPriority]) < 0)
                        {
                            minChild = nextChild.Clone();
                            minChildIndex = i;
                        }
                    }
                    if (comparer.System$Collections$Generic$IComparer$$$Compare(node.Item2, minChild.Item2, [TPriority]) <= 0)
                    {
                        break;
                    }
                    $.$$.System.Array.$WriteT1.call(nodes, minChild, nodeIndex);
                    nodeIndex = minChildIndex;
                }
                $.$$.System.Array.$WriteT1.call(nodes, node, nodeIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(176094969869)
            
            //--TRIMMABLE-BOUNDARY-START(111670460429)
            /*int */ FindIndex(/*TElement*/ element, /*IEqualityComparer<TElement>?*/ equalityComparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670460429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                equalityComparer ??= $.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default;
                /*ReadOnlySpan<(TElement Element, TPriority Priority)>*/ let nodes = $.$$.System.Span$$($.$$.System.ValueTuple$$$(TElement, TPriority)).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.ValueTuple$$$(TElement, TPriority), this._nodes, 0, this._size));
                if (TElement.$type.IsValueType && equalityComparer === $.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default)
                {
                    for(/*int*/ let i = 0; i < nodes.Length; i++)
                    {
                        if ($.$$.System.Collections.Generic.EqualityComparer$$(TElement).Default.Equals$2(element, nodes.get_Item(i).$v.Item1))
                        {
                            return i;
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < nodes.Length; i++)
                    {
                        if (equalityComparer.System$Collections$Generic$IEqualityComparer$$$Equals(element, nodes.get_Item(i).$v.Item1, [TElement]))
                        {
                            return i;
                        }
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(111670460429)
            
            //--TRIMMABLE-BOUNDARY-START(167505035277)
            static /*IComparer<TPriority>? */ InitializeComparer(/*IComparer<TPriority>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (TPriority.$type.IsValueType)
                {
                    if (comparer === $.$$.System.Collections.Generic.Comparer$$(TPriority).Default)
                    {
                        return null;
                    }
                    return comparer;
                }
                else 
                {
                    return comparer ?? $.$$.System.Collections.Generic.Comparer$$(TPriority).Default;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505035277)
            
            //--TRIMMABLE-BOUNDARY-START(1376269)
            static $_UnorderedItemsCollection;
            static get UnorderedItemsCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority);
                return $cls.$_UnorderedItemsCollection ??= $asm.$ncls("$sc.System.Collections.Generic.PriorityQueue$$$.UnorderedItemsCollection", ($self) => class UnorderedItemsCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296343565)
                    /*PriorityQueue<TElement, TPriority>*/ _queue = null;
                    //--TRIMMABLE-BOUNDARY-END(4296343565)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278157)
                    $ctor$1(/*PriorityQueue<TElement, TPriority>*/ queue)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886278157);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._queue = queue;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886278157)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245453)
                    /*int */ get Count()
                    {
                        return this._queue._size;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181245453)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425885709)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425885709)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130918413)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130918413)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656081933)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656081933);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        if (index < 0 || index > array.length)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                        }
                        if (((array.length - index) | 0) < this._queue._size)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._queue._nodes, 0, array, index, this._queue._size);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656081933)
                    
                    //--TRIMMABLE-BOUNDARY-START(1441805)
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.PriorityQueue$$$.UnorderedItemsCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(12886343693)
                            /*PriorityQueue<TElement, TPriority>*/  get _queue() { return this.$getField(0, 4); }
                            /*PriorityQueue<TElement, TPriority>*/  set _queue(value) { this.$setField(0, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(12886343693)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181310989)
                            /*int*/  get _version() { return this.$getField(4, 4); }
                            /*int*/  set _version(value) { this.$setField(4, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(17181310989)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591376397)
                            /*int*/  get _index() { return this.$getField(8, 4); }
                            /*int*/  set _index(value) { this.$setField(8, 4, value); }
                            //--TRIMMABLE-BOUNDARY-END(8591376397)
                            
                            //--TRIMMABLE-BOUNDARY-START(4296409101)
                            /*(TElement, TPriority)*/  get _current() { return this.$getField(12, 8); }
                            /*(TElement, TPriority)*/  set _current(value) { this.$setField(12, 8, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296409101)
                            
                            //--TRIMMABLE-BOUNDARY-START(25771245581)
                            $ctor$3(/*PriorityQueue<TElement, TPriority>*/ queue)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(25771245581);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._queue = queue;
                                    this._index = 0;
                                    this._version = queue._version;
                                    this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(25771245581)
                            
                            //--TRIMMABLE-BOUNDARY-START(34361180173)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(34361180173);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                            }
                            //--TRIMMABLE-BOUNDARY-END(34361180173)
                            
                            //--TRIMMABLE-BOUNDARY-START(47246082061)
                            /*bool */ MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47246082061);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                /*PriorityQueue<TElement, TPriority>*/ let localQueue = this._queue;
                                if (this._version !== localQueue._version)
                                {
                                    $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                                }
                                if ((this._index >>> 0) < (localQueue._size >>> 0))
                                {
                                    this._current = $.$$.System.Array.$ReadT1.call(localQueue._nodes, this._index);
                                    this._index++;
                                    return true;
                                }
                                this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                                this._index = -1;
                                return false;
                            }
                            //--TRIMMABLE-BOUNDARY-END(47246082061)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066212877)
                            /*(TElement Element, TPriority Priority) */ get Current()
                            {
                                return this._current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(30066212877)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541049357)
                            /*object */ get System$Collections$IEnumerator$Current()
                            {
                                return this._current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(51541049357)
                            
                            //--TRIMMABLE-BOUNDARY-START(64425951245)
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(64425951245);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._version !== this._queue._version)
                                {
                                    $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                                }
                                this._index = 0;
                                this._current = new ($.$$.System.ValueTuple$$$(TElement, TPriority))();
                            }
                            //--TRIMMABLE-BOUNDARY-END(64425951245)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944605185)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<(TElement Element, TPriority Priority)>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354670593);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944605185)
                            
                            //--TRIMMABLE-BOUNDARY-START(4385275905)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4385275905);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4385275905)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242652673)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242652673);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242652673)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476278285)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476278285)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._queue = this._queue;
                                copy._version = this._version;
                                copy._index = this._index;
                                copy._current = this._current.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(12886343693)
                                this._queue = null;
                                //--TRIMMABLE-BOUNDARY-END(12886343693)
                                
                                //--TRIMMABLE-BOUNDARY-START(17181310989)
                                this._version = 0;
                                //--TRIMMABLE-BOUNDARY-END(17181310989)
                                
                                //--TRIMMABLE-BOUNDARY-START(8591376397)
                                this._index = 0;
                                //--TRIMMABLE-BOUNDARY-END(8591376397)
                                
                                //--TRIMMABLE-BOUNDARY-START(4296409101)
                                this._current = $.$default($.$$.System.ValueTuple$$$(TElement, TPriority));
                                //--TRIMMABLE-BOUNDARY-END(4296409101)
                                
                            }
                            static $h = 1441805;
                            static $z = 20;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 1376269,
  "h": 1441805
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>.UnorderedItemsCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1441805)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066147341)
                    /*Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30066147341);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).UnorderedItemsCollection.Enumerator)().$ctor$3(this._queue);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066147341)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361114637)
                    /*IEnumerator<(TElement Element, TPriority Priority)> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361114637);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._queue.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.ValueTuple$$$(TElement, TPriority)) : this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361114637)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720853005)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68720853005);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.ValueTuple$$$(TElement, TPriority)]);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720853005)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<(TElement Element, TPriority Priority)>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    static $h = 1376269;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.PriorityQueue$$$(TElement, TPriority).$h,
  "h": 1376269
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.ValueTuple$$$(TElement, TPriority)), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>.UnorderedItemsCollection`; }
                }, $cls, ($v) => $cls.$_UnorderedItemsCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376269)
            
            static $h = 1310733;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.PriorityQueue<${TElement?.$fullName},${TPriority?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1310733)
        
        
        //--TRIMMABLE-BOUNDARY-START(196621)
        $asm.$cls("$sc.System.Collections.Generic.DictionaryKeyCollectionDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DictionaryKeyCollectionDebugView<,>", [TKey, TValue], ($self) => class DictionaryKeyCollectionDebugView$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163917)
            /*ICollection<TKey>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4295163917)
            
            //--TRIMMABLE-BOUNDARY-START(8590131213)
            $ctor$1(/*ICollection<TKey>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._collection = $.$firstOf(collection, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131213)
            
            //--TRIMMABLE-BOUNDARY-START(21475033101)
            /*TKey[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TKey[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [TKey]);
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033101)
            
            static $h = 196621;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.DictionaryKeyCollectionDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(196621)
        
        
        //--TRIMMABLE-BOUNDARY-START(327693)
        $asm.$cls("$sc.System.Collections.Generic.EnumerableHelpers", ($self) => class EnumerableHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(8590262285)
            static /*void */ Reset(T, /*ref T*/ enumerator)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262285);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$dsp(enumerator.$v, T, ($t) => $t.System$Collections$IEnumerator$Reset,);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262285)
            
            //--TRIMMABLE-BOUNDARY-START(4295294989)
            static /*IEnumerator<T> */ GetEmptyEnumerator(T)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295294989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$$.System.Array.Empty(T)).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295294989)
            
            //--TRIMMABLE-BOUNDARY-START(12885229581)
            static /*T[] */ ToArray(T, /*IEnumerable<T>*/ source, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let ArrayMaxLength = 2147483591;
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Array.MaxLength === ArrayMaxLength, "Array.MaxLength == ArrayMaxLength");
                let ic;
                if ($.$is(source, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ ic = v; } }))
                {
                    /*int*/ let count = ic.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [count], null);
                        ic.System$Collections$Generic$ICollection$$$CopyTo(arr, 0, [T]);
                        length.$v = count;
                        return arr;
                    }
                }
                else 
                {
                    let en = null;
                    try
                    {
                        en = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                        if (en.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let DefaultCapacity = 4;
                            /*T[]*/ let arr = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [DefaultCapacity], null);
                            $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, 0);
                            /*int*/ let count = 1;
                            while(en.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count === arr.length)
                                {
                                    /*int*/ let newLength = count << 1;
                                    if ((newLength >>> 0) > ArrayMaxLength)
                                    {
                                        newLength = ArrayMaxLength <= count ? ((count + 1) | 0) : ArrayMaxLength;
                                    }
                                    $.$$.System.Array.Resize(T, $.$ref(() => arr, ($v) => arr = $v, $.$typeArray(T)), newLength);
                                }
                                $.$$.System.Array.$WriteT1.call(arr, en.System$Collections$Generic$IEnumerator$$$Current, count++);
                            }
                            length.$v = count;
                            return arr;
                        }
                    }
                    finally
                    {
                        en?.System$IDisposable$Dispose();
                    }
                }
                length.$v = 0;
                return $.$$.System.Array.Empty(T);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229581)
            
            static $h = 327693;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 327693
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.EnumerableHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327693)
        
        
        //--TRIMMABLE-BOUNDARY-START(3604493)
        $asm.$cls("$sc.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382255693837)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382255693837)
            
            //--TRIMMABLE-BOUNDARY-START(433795301389)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433795301389)
            
            //--TRIMMABLE-BOUNDARY-START(429500334093)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429500334093)
            
            //--TRIMMABLE-BOUNDARY-START(266291576845)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266291576845)
            
            //--TRIMMABLE-BOUNDARY-START(261996609549)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261996609549)
            
            //--TRIMMABLE-BOUNDARY-START(77313015821)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77313015821)
            
            //--TRIMMABLE-BOUNDARY-START(73018048525)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73018048525)
            
            //--TRIMMABLE-BOUNDARY-START(94492885005)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94492885005)
            
            //--TRIMMABLE-BOUNDARY-START(90197917709)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90197917709)
            
            //--TRIMMABLE-BOUNDARY-START(214751969293)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214751969293)
            
            //--TRIMMABLE-BOUNDARY-START(210457001997)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210457001997)
            
            //--TRIMMABLE-BOUNDARY-START(442385235981)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442385235981)
            
            //--TRIMMABLE-BOUNDARY-START(446680203277)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446680203277)
            
            //--TRIMMABLE-BOUNDARY-START(438090268685)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438090268685)
            
            //--TRIMMABLE-BOUNDARY-START(146032492557)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146032492557)
            
            //--TRIMMABLE-BOUNDARY-START(141737525261)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141737525261)
            
            //--TRIMMABLE-BOUNDARY-START(120262688781)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120262688781)
            
            //--TRIMMABLE-BOUNDARY-START(115967721485)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115967721485)
            
            //--TRIMMABLE-BOUNDARY-START(51543212045)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51543212045)
            
            //--TRIMMABLE-BOUNDARY-START(47248244749)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47248244749)
            
            //--TRIMMABLE-BOUNDARY-START(326421118989)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326421118989)
            
            //--TRIMMABLE-BOUNDARY-START(322126151693)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322126151693)
            
            //--TRIMMABLE-BOUNDARY-START(60133146637)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60133146637)
            
            //--TRIMMABLE-BOUNDARY-START(55838179341)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55838179341)
            
            //--TRIMMABLE-BOUNDARY-START(85902950413)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85902950413)
            
            //--TRIMMABLE-BOUNDARY-START(81607983117)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81607983117)
            
            //--TRIMMABLE-BOUNDARY-START(197572100109)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197572100109)
            
            //--TRIMMABLE-BOUNDARY-START(193277132813)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193277132813)
            
            //--TRIMMABLE-BOUNDARY-START(489629876237)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489629876237)
            
            //--TRIMMABLE-BOUNDARY-START(485334908941)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485334908941)
            
            //--TRIMMABLE-BOUNDARY-START(163212361741)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163212361741)
            
            //--TRIMMABLE-BOUNDARY-START(158917394445)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158917394445)
            
            //--TRIMMABLE-BOUNDARY-START(206162034701)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206162034701)
            
            //--TRIMMABLE-BOUNDARY-START(201867067405)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201867067405)
            
            //--TRIMMABLE-BOUNDARY-START(399435563021)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399435563021)
            
            //--TRIMMABLE-BOUNDARY-START(395140595725)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395140595725)
            
            //--TRIMMABLE-BOUNDARY-START(300651315213)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300651315213)
            
            //--TRIMMABLE-BOUNDARY-START(296356347917)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296356347917)
            
            //--TRIMMABLE-BOUNDARY-START(377960726541)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377960726541)
            
            //--TRIMMABLE-BOUNDARY-START(373665759245)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373665759245)
            
            //--TRIMMABLE-BOUNDARY-START(231931838477)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231931838477)
            
            //--TRIMMABLE-BOUNDARY-START(227636871181)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227636871181)
            
            //--TRIMMABLE-BOUNDARY-START(154622427149)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154622427149)
            
            //--TRIMMABLE-BOUNDARY-START(150327459853)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150327459853)
            
            //--TRIMMABLE-BOUNDARY-START(352190922765)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352190922765)
            
            //--TRIMMABLE-BOUNDARY-START(347895955469)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347895955469)
            
            //--TRIMMABLE-BOUNDARY-START(360780857357)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360780857357)
            
            //--TRIMMABLE-BOUNDARY-START(356485890061)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356485890061)
            
            //--TRIMMABLE-BOUNDARY-START(17183473677)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17183473677)
            
            //--TRIMMABLE-BOUNDARY-START(12888506381)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12888506381)
            
            //--TRIMMABLE-BOUNDARY-START(408025497613)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408025497613)
            
            //--TRIMMABLE-BOUNDARY-START(403730530317)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403730530317)
            
            //--TRIMMABLE-BOUNDARY-START(498219810829)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498219810829)
            
            //--TRIMMABLE-BOUNDARY-START(493924843533)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493924843533)
            
            //--TRIMMABLE-BOUNDARY-START(283471446029)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283471446029)
            
            //--TRIMMABLE-BOUNDARY-START(279176478733)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279176478733)
            
            //--TRIMMABLE-BOUNDARY-START(506809745421)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506809745421)
            
            //--TRIMMABLE-BOUNDARY-START(502514778125)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502514778125)
            
            //--TRIMMABLE-BOUNDARY-START(274881511437)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274881511437)
            
            //--TRIMMABLE-BOUNDARY-START(270586544141)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270586544141)
            
            //--TRIMMABLE-BOUNDARY-START(481039941645)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481039941645)
            
            //--TRIMMABLE-BOUNDARY-START(476744974349)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476744974349)
            
            //--TRIMMABLE-BOUNDARY-START(128852623373)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128852623373)
            
            //--TRIMMABLE-BOUNDARY-START(124557656077)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124557656077)
            
            //--TRIMMABLE-BOUNDARY-START(111672754189)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111672754189)
            
            //--TRIMMABLE-BOUNDARY-START(107377786893)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107377786893)
            
            //--TRIMMABLE-BOUNDARY-START(335011053581)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335011053581)
            
            //--TRIMMABLE-BOUNDARY-START(330716086285)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330716086285)
            
            //--TRIMMABLE-BOUNDARY-START(68723081229)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68723081229)
            
            //--TRIMMABLE-BOUNDARY-START(64428113933)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64428113933)
            
            //--TRIMMABLE-BOUNDARY-START(390845628429)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390845628429)
            
            //--TRIMMABLE-BOUNDARY-START(386550661133)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386550661133)
            
            //--TRIMMABLE-BOUNDARY-START(309241249805)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309241249805)
            
            //--TRIMMABLE-BOUNDARY-START(304946282509)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304946282509)
            
            //--TRIMMABLE-BOUNDARY-START(42953277453)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42953277453)
            
            //--TRIMMABLE-BOUNDARY-START(38658310157)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38658310157)
            
            //--TRIMMABLE-BOUNDARY-START(416615432205)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416615432205)
            
            //--TRIMMABLE-BOUNDARY-START(412320464909)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412320464909)
            
            //--TRIMMABLE-BOUNDARY-START(472450007053)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472450007053)
            
            //--TRIMMABLE-BOUNDARY-START(468155039757)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468155039757)
            
            //--TRIMMABLE-BOUNDARY-START(188982165517)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188982165517)
            
            //--TRIMMABLE-BOUNDARY-START(184687198221)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184687198221)
            
            //--TRIMMABLE-BOUNDARY-START(171802296333)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171802296333)
            
            //--TRIMMABLE-BOUNDARY-START(167507329037)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167507329037)
            
            //--TRIMMABLE-BOUNDARY-START(180392230925)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180392230925)
            
            //--TRIMMABLE-BOUNDARY-START(176097263629)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176097263629)
            
            //--TRIMMABLE-BOUNDARY-START(34363342861)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34363342861)
            
            //--TRIMMABLE-BOUNDARY-START(30068375565)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30068375565)
            
            //--TRIMMABLE-BOUNDARY-START(137442557965)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137442557965)
            
            //--TRIMMABLE-BOUNDARY-START(133147590669)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133147590669)
            
            //--TRIMMABLE-BOUNDARY-START(103082819597)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103082819597)
            
            //--TRIMMABLE-BOUNDARY-START(98787852301)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98787852301)
            
            //--TRIMMABLE-BOUNDARY-START(523989614605)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523989614605)
            
            //--TRIMMABLE-BOUNDARY-START(519694647309)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519694647309)
            
            //--TRIMMABLE-BOUNDARY-START(369370791949)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369370791949)
            
            //--TRIMMABLE-BOUNDARY-START(365075824653)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365075824653)
            
            //--TRIMMABLE-BOUNDARY-START(223341903885)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223341903885)
            
            //--TRIMMABLE-BOUNDARY-START(219046936589)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219046936589)
            
            //--TRIMMABLE-BOUNDARY-START(249111707661)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249111707661)
            
            //--TRIMMABLE-BOUNDARY-START(236226805773)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236226805773)
            
            //--TRIMMABLE-BOUNDARY-START(244816740365)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244816740365)
            
            //--TRIMMABLE-BOUNDARY-START(240521773069)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240521773069)
            
            //--TRIMMABLE-BOUNDARY-START(317831184397)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317831184397)
            
            //--TRIMMABLE-BOUNDARY-START(313536217101)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313536217101)
            
            //--TRIMMABLE-BOUNDARY-START(8593539085)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8593539085)
            
            //--TRIMMABLE-BOUNDARY-START(4298571789)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4298571789)
            
            //--TRIMMABLE-BOUNDARY-START(455270137869)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455270137869)
            
            //--TRIMMABLE-BOUNDARY-START(450975170573)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450975170573)
            
            //--TRIMMABLE-BOUNDARY-START(25773408269)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25773408269)
            
            //--TRIMMABLE-BOUNDARY-START(21478440973)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21478440973)
            
            //--TRIMMABLE-BOUNDARY-START(257701642253)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257701642253)
            
            //--TRIMMABLE-BOUNDARY-START(253406674957)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253406674957)
            
            //--TRIMMABLE-BOUNDARY-START(515399680013)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515399680013)
            
            //--TRIMMABLE-BOUNDARY-START(511104712717)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511104712717)
            
            //--TRIMMABLE-BOUNDARY-START(463860072461)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463860072461)
            
            //--TRIMMABLE-BOUNDARY-START(459565105165)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459565105165)
            
            //--TRIMMABLE-BOUNDARY-START(425205366797)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425205366797)
            
            //--TRIMMABLE-BOUNDARY-START(420910399501)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420910399501)
            
            //--TRIMMABLE-BOUNDARY-START(343600988173)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343600988173)
            
            //--TRIMMABLE-BOUNDARY-START(339306020877)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339306020877)
            
            //--TRIMMABLE-BOUNDARY-START(292061380621)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292061380621)
            
            //--TRIMMABLE-BOUNDARY-START(287766413325)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287766413325)
            
            //--TRIMMABLE-BOUNDARY-START(532579549197)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532579549197)
            
            //--TRIMMABLE-BOUNDARY-START(528284581901)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528284581901)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382255693837)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382255693837)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433795301389)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433795301389)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429500334093)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429500334093)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266291576845)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266291576845)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261996609549)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261996609549)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77313015821)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77313015821)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73018048525)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73018048525)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94492885005)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94492885005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90197917709)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90197917709)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214751969293)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214751969293)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210457001997)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210457001997)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442385235981)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442385235981)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446680203277)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446680203277)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438090268685)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438090268685)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146032492557)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146032492557)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141737525261)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141737525261)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120262688781)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120262688781)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115967721485)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115967721485)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51543212045)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51543212045)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47248244749)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47248244749)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326421118989)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326421118989)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322126151693)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322126151693)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60133146637)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60133146637)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55838179341)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55838179341)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85902950413)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85902950413)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81607983117)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81607983117)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197572100109)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197572100109)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193277132813)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193277132813)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489629876237)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489629876237)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485334908941)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485334908941)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163212361741)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163212361741)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158917394445)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158917394445)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206162034701)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206162034701)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201867067405)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201867067405)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399435563021)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399435563021)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395140595725)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395140595725)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300651315213)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300651315213)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296356347917)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296356347917)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377960726541)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377960726541)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373665759245)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373665759245)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231931838477)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231931838477)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227636871181)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227636871181)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154622427149)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154622427149)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150327459853)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150327459853)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352190922765)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352190922765)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347895955469)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347895955469)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360780857357)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360780857357)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356485890061)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356485890061)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17183473677)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17183473677)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12888506381)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12888506381)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408025497613)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408025497613)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403730530317)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403730530317)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498219810829)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498219810829)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493924843533)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493924843533)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283471446029)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283471446029)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279176478733)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279176478733)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506809745421)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506809745421)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502514778125)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502514778125)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274881511437)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274881511437)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270586544141)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270586544141)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481039941645)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481039941645)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476744974349)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476744974349)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128852623373)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128852623373)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124557656077)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124557656077)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111672754189)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111672754189)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107377786893)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107377786893)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335011053581)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335011053581)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330716086285)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330716086285)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68723081229)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68723081229)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64428113933)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64428113933)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390845628429)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390845628429)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386550661133)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386550661133)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309241249805)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309241249805)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304946282509)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304946282509)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42953277453)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42953277453)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38658310157)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38658310157)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416615432205)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416615432205)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412320464909)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412320464909)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472450007053)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472450007053)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468155039757)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468155039757)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188982165517)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188982165517)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184687198221)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184687198221)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171802296333)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171802296333)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167507329037)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167507329037)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180392230925)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180392230925)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176097263629)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176097263629)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34363342861)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34363342861)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30068375565)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30068375565)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137442557965)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137442557965)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133147590669)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133147590669)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103082819597)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103082819597)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98787852301)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98787852301)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523989614605)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523989614605)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519694647309)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519694647309)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369370791949)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369370791949)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365075824653)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365075824653)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223341903885)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223341903885)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219046936589)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219046936589)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249111707661)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249111707661)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236226805773)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236226805773)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244816740365)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244816740365)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240521773069)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240521773069)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317831184397)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317831184397)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313536217101)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313536217101)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8593539085)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8593539085)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4298571789)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4298571789)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455270137869)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455270137869)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450975170573)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450975170573)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25773408269)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25773408269)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21478440973)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21478440973)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257701642253)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257701642253)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253406674957)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253406674957)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515399680013)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515399680013)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511104712717)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511104712717)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463860072461)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463860072461)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459565105165)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459565105165)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425205366797)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425205366797)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420910399501)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420910399501)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343600988173)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343600988173)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339306020877)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339306020877)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292061380621)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292061380621)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287766413325)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287766413325)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532579549197)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532579549197)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528284581901)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528284581901)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3604493;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3604493
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3604493)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211277)
        $asm.$cls("$sc.System.Collections.HashHelpers", ($self) => class HashHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(30067982349)
            /*uint*/ static HashCollisionThreshold = 100;
            //--TRIMMABLE-BOUNDARY-END(30067982349)
            
            //--TRIMMABLE-BOUNDARY-START(42952884237)
            /*int*/ static MaxPrimeArrayLength = 2147483587;
            //--TRIMMABLE-BOUNDARY-END(42952884237)
            
            //--TRIMMABLE-BOUNDARY-START(34362949645)
            /*int*/ static HashPrime = 101;
            //--TRIMMABLE-BOUNDARY-END(34362949645)
            
            //--TRIMMABLE-BOUNDARY-START(47247851533)
            static /*ReadOnlySpan<int> */ get Primes()
            {
                return this.$cachePrimes ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Int32))().$ctor$4([ 3, 7, 11, 17, 23, 29, 37, 47, 59, 71, 89, 107, 131, 163, 197, 239, 293, 353, 431, 521, 631, 761, 919, 1103, 1327, 1597, 1931, 2333, 2801, 3371, 4049, 4861, 5839, 7013, 8419, 10103, 12143, 14591, 17519, 21023, 25229, 30293, 36353, 43627, 52361, 62851, 75431, 90523, 108631, 130363, 156437, 187751, 225307, 270371, 324449, 389357, 467237, 560689, 672827, 807403, 968897, 1162687, 1395263, 1674319, 2009191, 2411033, 2893249, 3471899, 4166287, 4999559, 5999471, 7199369 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(47247851533)
            
            //--TRIMMABLE-BOUNDARY-START(38657916941)
            static /*bool */ IsPrime(/*int*/ candidate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657916941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((candidate & 1) !== 0)
                {
                    /*int*/ let limit = $.$cast(Math.sqrt(candidate), $.$$.System.Int32);
                    for(/*int*/ let divisor = 3; divisor <= limit; divisor += 2)
                    {
                        if ((candidate % divisor) === 0)
                        {
                            return false;
                        }
                    }
                    return true;
                }
                return candidate === 2;
            }
            //--TRIMMABLE-BOUNDARY-END(38657916941)
            
            //--TRIMMABLE-BOUNDARY-START(25773015053)
            static /*int */ GetPrime(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773015053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (min < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_HTCapacityOverflow);
                }
                var $en2 = $.$sc.System.Collections.HashHelpers.Primes.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var prime = $en2.Current.$v;
                    {
                        if (prime >= min)
                        {
                            return prime;
                        }
                    }
                }
                for(/*int*/ let i = (min | 1); i < 2147483647/*int.MaxValue*/; i += 2)
                {
                    if ($.$sc.System.Collections.HashHelpers.IsPrime(i) && ((((i - 1) | 0)) % 101/*HashPrime*/ !== 0))
                    {
                        return i;
                    }
                }
                return min;
            }
            //--TRIMMABLE-BOUNDARY-END(25773015053)
            
            //--TRIMMABLE-BOUNDARY-START(4298178573)
            static /*int */ ExpandPrime(/*int*/ oldSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4298178573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newSize = ((2 * oldSize) | 0);
                if ((newSize >>> 0) > 2147483587/*MaxPrimeArrayLength*/ && 2147483587/*MaxPrimeArrayLength*/ > oldSize)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(2147483587/*MaxPrimeArrayLength*/ === $.$sc.System.Collections.HashHelpers.GetPrime(2147483587/*MaxPrimeArrayLength*/), "Invalid MaxPrimeArrayLength");
                    return 2147483587/*MaxPrimeArrayLength*/;
                }
                return $.$sc.System.Collections.HashHelpers.GetPrime(newSize);
            }
            //--TRIMMABLE-BOUNDARY-END(4298178573)
            
            //--TRIMMABLE-BOUNDARY-START(21478047757)
            static /*ulong */ GetFastModMultiplier(/*uint*/ divisor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478047757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return 18446744073709551615n / BigInt(divisor) + 1n;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21478047757)
            
            //--TRIMMABLE-BOUNDARY-START(8593145869)
            static /*uint */ FastMod(/*uint*/ value, /*uint*/ divisor, /*ulong*/ multiplier)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593145869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(divisor <= 2147483647/*int.MaxValue*/, "divisor <= int.MaxValue");
                /*uint*/ let highbits = $.$cast((((((multiplier * BigInt(value)) >> 32n) + 1n) * BigInt(divisor)) >> 32n), $.$$.System.UInt32);
                $.$$.System.Diagnostics.Debug.Assert$2(highbits === value % divisor, "highbits == value % divisor");
                return highbits;
            }
            //--TRIMMABLE-BOUNDARY-END(8593145869)
            
            static $h = 3211277;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3211277
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.HashHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211277)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507341)
        $asm.$cls("$sc.System.Collections.Generic.PriorityQueueDebugView<,>", (TElement, TPriority) => $asm.$gt("$sc.System.Collections.Generic.PriorityQueueDebugView<,>", [TElement, TPriority], ($self) => class PriorityQueueDebugView$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474637)
            /*PriorityQueue<TElement, TPriority>*/ _queue = null;
            //--TRIMMABLE-BOUNDARY-END(4296474637)
            
            //--TRIMMABLE-BOUNDARY-START(8591441933)
            /*bool*/ _sort = false;
            //--TRIMMABLE-BOUNDARY-END(8591441933)
            
            //--TRIMMABLE-BOUNDARY-START(17181376525)
            $ctor$2(/*PriorityQueue<TElement, TPriority>*/ queue)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376525);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(queue, "queue");
                    this._queue = queue;
                    this._sort = true;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376525)
            
            //--TRIMMABLE-BOUNDARY-START(12886409229)
            $ctor$1(/*PriorityQueue<TElement, TPriority>.UnorderedItemsCollection*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409229);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._queue = $.$firstOf((collection?._queue ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409229)
            
            //--TRIMMABLE-BOUNDARY-START(30066278413)
            /*(TElement Element, TPriority Priority)[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let list = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$(TElement, TPriority)))().$ctor$2(this._queue.UnorderedItems);
                if (this._sort)
                {
                    list.Sort$2(new ($.$$.System.Comparison$$($.$$.System.ValueTuple$$$(TElement, TPriority)))().$ctor(this,  (/*i1*/ i1, /**/ i2) =>
                    {
                        return this._queue.Comparer.System$Collections$Generic$IComparer$$$Compare(i1.Item2, i2.Item2, [TPriority]);
                    }, {
  "r": 655361,
  "p": [
    {
      "n": "i1",
      "p": $.$$.System.ValueTuple$$$(TElement, TPriority).$h
    },
    {
      "n": "i2",
      "p": $.$$.System.ValueTuple$$$(TElement, TPriority).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }
                return list.ToArray();
            }
            //--TRIMMABLE-BOUNDARY-END(30066278413)
            
            static $h = 1507341;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.PriorityQueueDebugView<${TElement?.$fullName},${TPriority?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1507341)
        
        
        //--TRIMMABLE-BOUNDARY-START(3407885)
        $asm.$cls("$sc.System.Collections.StructuralComparisons", ($self) => class StructuralComparisons
        {
            //--TRIMMABLE-BOUNDARY-START(21478244365)
            static /*IComparer */ get StructuralComparer()
            {
                return $.$sc.System.Collections.StructuralComparer.s_instance;
            }
            //--TRIMMABLE-BOUNDARY-END(21478244365)
            
            //--TRIMMABLE-BOUNDARY-START(25773211661)
            static /*IEqualityComparer */ get StructuralEqualityComparer()
            {
                return $.$sc.System.Collections.StructuralEqualityComparer.s_instance;
            }
            //--TRIMMABLE-BOUNDARY-END(25773211661)
            
            static $h = 3407885;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3407885
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.StructuralComparisons`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3407885)
        
        
        //--TRIMMABLE-BOUNDARY-START(262157)
        $asm.$cls("$sc.System.Collections.Generic.DictionaryValueCollectionDebugView<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DictionaryValueCollectionDebugView<,>", [TKey, TValue], ($self) => class DictionaryValueCollectionDebugView$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229453)
            /*ICollection<TValue>*/ _collection = null;
            //--TRIMMABLE-BOUNDARY-END(4295229453)
            
            //--TRIMMABLE-BOUNDARY-START(8590196749)
            $ctor$1(/*ICollection<TValue>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196749);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._collection = $.$firstOf(collection, () => { throw new $.$$.System.ArgumentNullException().$ctor$19("collection") });
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196749)
            
            //--TRIMMABLE-BOUNDARY-START(21475098637)
            /*TValue[] */ get Items()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TValue[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [this._collection.System$Collections$Generic$ICollection$$$Count], null);
                this._collection.System$Collections$Generic$ICollection$$$CopyTo(items, 0, [TValue]);
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098637)
            
            static $h = 262157;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.DictionaryValueCollectionDebugView<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262157)
        
        
        //--TRIMMABLE-BOUNDARY-START(720909)
        $asm.$cls("$sc.System.Collections.Generic.LinkedListNode<>", (T) => $asm.$gt("$sc.System.Collections.Generic.LinkedListNode<>", [T], ($self) => class LinkedListNode$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(64425230349)
            /*LinkedList<T>?*/ list = null;
            //--TRIMMABLE-BOUNDARY-END(64425230349)
            
            //--TRIMMABLE-BOUNDARY-START(73015164941)
            /*LinkedListNode<T>?*/ next = null;
            //--TRIMMABLE-BOUNDARY-END(73015164941)
            
            //--TRIMMABLE-BOUNDARY-START(81605099533)
            /*LinkedListNode<T>?*/ prev = null;
            //--TRIMMABLE-BOUNDARY-END(81605099533)
            
            //--TRIMMABLE-BOUNDARY-START(60130263053)
            /*T*/ item = $.$default(T);
            //--TRIMMABLE-BOUNDARY-END(60130263053)
            
            //--TRIMMABLE-BOUNDARY-START(8590655501)
            $ctor$2(/*T*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655501);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.item = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655501)
            
            //--TRIMMABLE-BOUNDARY-START(4295688205)
            $ctor$1(/*LinkedList<T>*/ list, /*T*/ value)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688205);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.list = list;
                    this.item = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688205)
            
            //--TRIMMABLE-BOUNDARY-START(68720197645)
            /*LinkedList<T>? */ get List()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.list;
            }
            //--TRIMMABLE-BOUNDARY-END(68720197645)
            
            //--TRIMMABLE-BOUNDARY-START(77310132237)
            /*LinkedListNode<T>? */ get Next()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.next === null || this.next === this.list.head ? null : this.next;
            }
            //--TRIMMABLE-BOUNDARY-END(77310132237)
            
            //--TRIMMABLE-BOUNDARY-START(85900066829)
            /*LinkedListNode<T>? */ get Previous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.prev === null || this === this.list.head ? null : this.prev;
            }
            //--TRIMMABLE-BOUNDARY-END(85900066829)
            
            //--TRIMMABLE-BOUNDARY-START(98784968717)
            /*T */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.item;
            }
            /*T */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490001421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.item = value;
            }
            //--TRIMMABLE-BOUNDARY-END(98784968717)
            
            //--TRIMMABLE-BOUNDARY-START(103079936013)
            /*ref T */ get ValueRef()
            {
                return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT(T, () => this.item, ($v) => this.item = $v, null);
            }
            //--TRIMMABLE-BOUNDARY-END(103079936013)
            
            //--TRIMMABLE-BOUNDARY-START(55835295757)
            /*void */ Invalidate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.list = null;
                this.next = null;
                this.prev = null;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295757)
            
            static $h = 720909;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Collections.Generic.LinkedListNode<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(720909)
        
        
        //--TRIMMABLE-BOUNDARY-START(3473421)
        $asm.$cls("$sc.System.Collections.StructuralEqualityComparer", ($self) => class StructuralEqualityComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21478309901)
            /*StructuralEqualityComparer*/ static s_instance = null;
            //--TRIMMABLE-BOUNDARY-END(21478309901)
            
            //--TRIMMABLE-BOUNDARY-START(12888375309)
            /*bool */ Equals$2(/*object?*/ x, /*object?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888375309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (x !== null)
                {
                    /*IStructuralEquatable?*/ let seObj = $.$as(x, $.$$.System.Collections.IStructuralEquatable);
                    if (seObj !== null)
                    {
                        return seObj.System$Collections$IStructuralEquatable$Equals(y, this);
                    }
                    if (y !== null)
                    {
                        return $.$$.System.Object.Equals$1.call(x, y);
                    }
                    else 
                    {
                        return false;
                    }
                }
                if (y !== null)
                {
                    return false;
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(12888375309)
            
            //--TRIMMABLE-BOUNDARY-START(17183342605)
            /*int */ GetHashCode$1(/*object*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183342605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === null)
                {
                    return 0;
                }
                /*IStructuralEquatable?*/ let seObj = $.$as(obj, $.$$.System.Collections.IStructuralEquatable);
                if (seObj !== null)
                {
                    return seObj.System$Collections$IStructuralEquatable$GetHashCode(this);
                }
                return $.$$.System.Object.GetHashCode.call(obj);
            }
            //--TRIMMABLE-BOUNDARY-END(17183342605)
            
            //--TRIMMABLE-BOUNDARY-START(4357816321)
            //Generated interface implemetation for System.Collections.IEqualityComparer.Equals(object?, object?)
            System$Collections$IEqualityComparer$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357816321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357816321)
            
            //--TRIMMABLE-BOUNDARY-START(8652783617)
            //Generated interface implemetation for System.Collections.IEqualityComparer.GetHashCode(object)
            System$Collections$IEqualityComparer$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652783617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652783617)
            
            //--TRIMMABLE-BOUNDARY-START(8593408013)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593408013)
            
            //--TRIMMABLE-BOUNDARY-START(4298440717)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21478309901)
                    this.s_instance = new $.$sc.System.Collections.StructuralEqualityComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(21478309901)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298440717)
            
            static $h = 3473421;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3473421
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEqualityComparer ]; }
            static get $fullName() { return `System.Collections.StructuralEqualityComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3473421)
        
        
        //--TRIMMABLE-BOUNDARY-START(3342349)
        $asm.$cls("$sc.System.Collections.StructuralComparer", ($self) => class StructuralComparer extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17183211533)
            /*StructuralComparer*/ static s_instance = null;
            //--TRIMMABLE-BOUNDARY-END(17183211533)
            
            //--TRIMMABLE-BOUNDARY-START(12888244237)
            /*int */ Compare(/*object?*/ x, /*object?*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12888244237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (x === null)
                {
                    return y === null ? 0 : -1;
                }
                if (y === null)
                {
                    return 1;
                }
                /*IStructuralComparable?*/ let scX = $.$as(x, $.$$.System.Collections.IStructuralComparable);
                if (scX !== null)
                {
                    return scX.System$Collections$IStructuralComparable$CompareTo(y, this);
                }
                return $.$$.System.Collections.Generic.Comparer$$($.$$.System.Object).Default.Compare(x, y);
            }
            //--TRIMMABLE-BOUNDARY-END(12888244237)
            
            //--TRIMMABLE-BOUNDARY-START(4357423105)
            //Generated interface implemetation for System.Collections.IComparer.Compare(object?, object?)
            System$Collections$IComparer$Compare()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4357423105);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Compare(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4357423105)
            
            //--TRIMMABLE-BOUNDARY-START(8593276941)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593276941)
            
            //--TRIMMABLE-BOUNDARY-START(4298309645)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17183211533)
                    this.s_instance = new $.$sc.System.Collections.StructuralComparer().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(17183211533)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298309645)
            
            static $h = 3342349;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3342349
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer ]; }
            static get $fullName() { return `System.Collections.StructuralComparer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3342349)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818061)
        $asm.$cls("$sc.System.Collections.Generic.Stack<>", (T) => $asm.$gt("$sc.System.Collections.Generic.Stack<>", [T], ($self) => class Stack$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297785357)
            /*T[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4297785357)
            
            //--TRIMMABLE-BOUNDARY-START(8592752653)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(8592752653)
            
            //--TRIMMABLE-BOUNDARY-START(12887719949)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(12887719949)
            
            //--TRIMMABLE-BOUNDARY-START(55837392909)
            /*int*/ static DefaultCapacity = 4;
            //--TRIMMABLE-BOUNDARY-END(55837392909)
            
            //--TRIMMABLE-BOUNDARY-START(21477654541)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477654541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._array = $.$$.System.Array.Empty(T);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477654541)
            
            //--TRIMMABLE-BOUNDARY-START(30067589133)
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067589133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    this._array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [capacity], null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067589133)
            
            //--TRIMMABLE-BOUNDARY-START(25772621837)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772621837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this._array = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, collection, $.$ref(() => this._size, ($v) => this._size = $v, $.$$.System.Int32));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772621837)
            
            //--TRIMMABLE-BOUNDARY-START(51542425613)
            /*int */ get Count()
            {
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(51542425613)
            
            //--TRIMMABLE-BOUNDARY-START(34362556429)
            /*int */ get Capacity()
            {
                return this._array.length;
            }
            //--TRIMMABLE-BOUNDARY-END(34362556429)
            
            //--TRIMMABLE-BOUNDARY-START(133146804237)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(133146804237)
            
            //--TRIMMABLE-BOUNDARY-START(137441771533)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(137441771533)
            
            //--TRIMMABLE-BOUNDARY-START(38657523725)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657523725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                this._size = 0;
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(38657523725)
            
            //--TRIMMABLE-BOUNDARY-START(42952491021)
            /*bool */ Contains(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952491021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size !== 0 && $.$$.System.Array.LastIndexOf$4(T, this._array, item, ((this._size - 1) | 0)) !== -1;
            }
            //--TRIMMABLE-BOUNDARY-END(42952491021)
            
            //--TRIMMABLE-BOUNDARY-START(47247458317)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(array !== this._array, "array != _array");
                /*int*/ let srcIndex = 0;
                /*int*/ let dstIndex = ((arrayIndex + this._size) | 0);
                while(srcIndex < this._size)
                {
                    $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(this._array, srcIndex++), --dstIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247458317)
            
            //--TRIMMABLE-BOUNDARY-START(111671967757)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671967757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this._size)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Argument_InvalidOffLen);
                }
                try
                {
                    $.$$.System.Array.Copy$2(this._array, 0, array, arrayIndex, this._size);
                    $.$$.System.Array.Reverse(array, arrayIndex, this._size);
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111671967757)
            
            //--TRIMMABLE-BOUNDARY-START(81607196685)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81607196685);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.Stack$$(T).Enumerator)().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81607196685)
            
            //--TRIMMABLE-BOUNDARY-START(107377000461)
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107377000461);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(T) : this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107377000461)
            
            //--TRIMMABLE-BOUNDARY-START(141736738829)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141736738829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141736738829)
            
            //--TRIMMABLE-BOUNDARY-START(154621640717)
            /*void */ TrimExcess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154621640717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threshold = $.$cast((this._array.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), this._size);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154621640717)
            
            //--TRIMMABLE-BOUNDARY-START(158916608013)
            /*void */ TrimExcess$1(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158916608013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, capacity, this._size, "capacity");
                if (capacity === this._array.length)
                {
                    return;
                }
                $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), capacity);
            }
            //--TRIMMABLE-BOUNDARY-END(158916608013)
            
            //--TRIMMABLE-BOUNDARY-START(90197131277)
            /*T */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197131277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    this.ThrowForEmptyStack();
                }
                return $.$$.System.Array.$ReadT1.call(array, size);
            }
            //--TRIMMABLE-BOUNDARY-END(90197131277)
            
            //--TRIMMABLE-BOUNDARY-START(163211575309)
            /*bool */ TryPeek(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211575309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = $.$default(T);
                    return false;
                }
                result.$v = $.$$.System.Array.$ReadT1.call(array, size);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(163211575309)
            
            //--TRIMMABLE-BOUNDARY-START(94492098573)
            /*T */ Pop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94492098573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    this.ThrowForEmptyStack();
                }
                this._version++;
                this._size = size;
                /*T*/ let item = $.$$.System.Array.$ReadT1.call(array, size);
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                return item;
            }
            //--TRIMMABLE-BOUNDARY-END(94492098573)
            
            //--TRIMMABLE-BOUNDARY-START(167506542605)
            /*bool */ TryPop(/*out T*/ result)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167506542605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((this._size - 1) | 0);
                /*T[]*/ let array = this._array;
                if ((size >>> 0) >= (array.length >>> 0))
                {
                    result.$v = $.$default(T);
                    return false;
                }
                this._version++;
                this._size = size;
                result.$v = $.$$.System.Array.$ReadT1.call(array, size);
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(167506542605)
            
            //--TRIMMABLE-BOUNDARY-START(98787065869)
            /*void */ Push(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787065869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = this._size;
                /*T[]*/ let array = this._array;
                if ((size >>> 0) < (array.length >>> 0))
                {
                    $.$$.System.Array.$WriteT1.call(array, item, size);
                    this._version++;
                    this._size = ((size + 1) | 0);
                }
                else 
                {
                    this.PushWithResize(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98787065869)
            
            //--TRIMMABLE-BOUNDARY-START(103082033165)
            /*void */ PushWithResize(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082033165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._size === this._array.length, "_size == _array.Length");
                this.Grow(((this._size + 1) | 0));
                $.$$.System.Array.$WriteT1.call(this._array, item, this._size);
                this._version++;
                this._size++;
            }
            //--TRIMMABLE-BOUNDARY-END(103082033165)
            
            //--TRIMMABLE-BOUNDARY-START(60132360205)
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132360205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this._array.length < capacity)
                {
                    this.Grow(capacity);
                }
                return this._array.length;
            }
            //--TRIMMABLE-BOUNDARY-END(60132360205)
            
            //--TRIMMABLE-BOUNDARY-START(85902163981)
            /*void */ Grow(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85902163981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._array.length < capacity, "_array.Length < capacity");
                /*int*/ let newcapacity = this._array.length === 0 ? 4/*DefaultCapacity*/ : ((2 * this._array.length) | 0);
                if (BigInt((newcapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newcapacity = $.$$.System.Array.MaxLength;
                }
                if (newcapacity < capacity)
                {
                    newcapacity = capacity;
                }
                $.$$.System.Array.Resize(T, $.$ref(() => this._array, ($v) => this._array = $v, $.$typeArray(T)), newcapacity);
            }
            //--TRIMMABLE-BOUNDARY-END(85902163981)
            
            //--TRIMMABLE-BOUNDARY-START(150326673421)
            /*T[] */ ToArray()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326673421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === 0)
                {
                    return $.$$.System.Array.Empty(T);
                }
                /*T[]*/ let objArray = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this._size], null);
                /*int*/ let i = 0;
                while(i < this._size)
                {
                    $.$$.System.Array.$WriteT1.call(objArray, $.$$.System.Array.$ReadT1.call(this._array, ((((this._size - i) | 0) - 1) | 0)), i);
                    i++;
                }
                return objArray;
            }
            //--TRIMMABLE-BOUNDARY-END(150326673421)
            
            //--TRIMMABLE-BOUNDARY-START(146031706125)
            /*void */ ThrowForEmptyStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146031706125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._size === 0, "_size == 0");
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EmptyStack);
            }
            //--TRIMMABLE-BOUNDARY-END(146031706125)
            
            //--TRIMMABLE-BOUNDARY-START(2883597)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.Stack$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.Stack$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12887785485)
                    /*Stack<T>*/  get _stack() { return this.$getField(0, 4); }
                    /*Stack<T>*/  set _stack(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12887785485)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182752781)
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17182752781)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592818189)
                    /*int*/  get _index() { return this.$getField(8, 4); }
                    /*int*/  set _index(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592818189)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297850893)
                    /*T?*/  get _currentElement() { return this.$getField(12, 4); }
                    /*T?*/  set _currentElement(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297850893)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772687373)
                    $ctor$3(/*Stack<T>*/ stack)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(25772687373);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._stack = stack;
                            this._version = stack._version;
                            this._index = stack.Count;
                            this._currentElement = $.$default(T);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772687373)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362621965)
                    /*void */ Dispose()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34362621965);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._index = -1;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362621965)
                    
                    //--TRIMMABLE-BOUNDARY-START(47247523853)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47247523853);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._stack._version)
                        {
                            $.$sc.System.Collections.Generic.Stack$$(T).Enumerator.ThrowInvalidVersion();
                        }
                        /*T[]*/ let array = this._stack._array;
                        /*int*/ let index = ((this._index - 1) | 0);
                        if ((index >>> 0) < (array.length >>> 0))
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(index < this._stack.Count, "index < _stack.Count");
                            this._currentElement = $.$$.System.Array.$ReadT1.call(array, index);
                            this._index = index;
                            return true;
                        }
                        this._currentElement = $.$default(T);
                        this._index = -1;
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47247523853)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067654669)
                    /*T */ get Current()
                    {
                        return this._currentElement;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067654669)
                    
                    //--TRIMMABLE-BOUNDARY-START(51542491149)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return $.$box(this.Current, T);
                    }
                    //--TRIMMABLE-BOUNDARY-END(51542491149)
                    
                    //--TRIMMABLE-BOUNDARY-START(64427393037)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64427393037);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._stack._version)
                        {
                            $.$sc.System.Collections.Generic.Stack$$(T).Enumerator.ThrowInvalidVersion();
                        }
                        this._index = this._stack.Count;
                        this._currentElement = $.$default(T);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64427393037)
                    
                    //--TRIMMABLE-BOUNDARY-START(68722360333)
                    static /*void */ ThrowInvalidVersion()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68722360333);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68722360333)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477720077)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477720077)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._stack = this._stack;
                        copy._version = this._version;
                        copy._index = this._index;
                        copy._currentElement = this._currentElement;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12887785485)
                        this._stack = null;
                        //--TRIMMABLE-BOUNDARY-END(12887785485)
                        
                        //--TRIMMABLE-BOUNDARY-START(17182752781)
                        this._version = 0;
                        //--TRIMMABLE-BOUNDARY-END(17182752781)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592818189)
                        this._index = 0;
                        //--TRIMMABLE-BOUNDARY-END(8592818189)
                        
                        //--TRIMMABLE-BOUNDARY-START(4297850893)
                        this._currentElement = null;
                        //--TRIMMABLE-BOUNDARY-END(4297850893)
                        
                    }
                    static $h = 2883597;
                    static $z = 16;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.Stack$$(T).$h,
  "h": 2883597
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.Stack<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2883597)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            static $h = 2818061;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.Stack<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2818061)
        
        
        //--TRIMMABLE-BOUNDARY-START(589837)
        $asm.$cls("$sc.System.Collections.Generic.LinkedList<>", (T) => $asm.$gt("$sc.System.Collections.Generic.LinkedList<>", [T], ($self) => class LinkedList$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(133144576013)
            /*LinkedListNode<T>?*/ head = null;
            //--TRIMMABLE-BOUNDARY-END(133144576013)
            
            //--TRIMMABLE-BOUNDARY-START(73015033869)
            /*int*/ count = 0;
            //--TRIMMABLE-BOUNDARY-END(73015033869)
            
            //--TRIMMABLE-BOUNDARY-START(244813725709)
            /*int*/ version = 0;
            //--TRIMMABLE-BOUNDARY-END(244813725709)
            
            //--TRIMMABLE-BOUNDARY-START(4295557133)
            /*SerializationInfo?*/ _siInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295557133)
            
            //--TRIMMABLE-BOUNDARY-START(249108693005)
            /*string*/ static VersionName = null;
            //--TRIMMABLE-BOUNDARY-END(249108693005)
            
            //--TRIMMABLE-BOUNDARY-START(81604968461)
            /*string*/ static CountName = null;
            //--TRIMMABLE-BOUNDARY-END(81604968461)
            
            //--TRIMMABLE-BOUNDARY-START(240518758413)
            /*string*/ static ValuesName = null;
            //--TRIMMABLE-BOUNDARY-END(240518758413)
            
            //--TRIMMABLE-BOUNDARY-START(12885491725)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491725);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491725)
            
            //--TRIMMABLE-BOUNDARY-START(17180459021)
            $ctor$2(/*IEnumerable<T>*/ collection)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459021);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.AddLast$1(item);
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459021)
            
            //--TRIMMABLE-BOUNDARY-START(21475426317)
            $ctor$3(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426317);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._siInfo = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426317)
            
            //--TRIMMABLE-BOUNDARY-START(77310001165)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079804941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.count;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001165)
            
            //--TRIMMABLE-BOUNDARY-START(94489870349)
            /*LinkedListNode<T>? */ get First()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.head;
            }
            //--TRIMMABLE-BOUNDARY-END(94489870349)
            
            //--TRIMMABLE-BOUNDARY-START(150324445197)
            /*LinkedListNode<T>? */ get Last()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.head?.prev ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(150324445197)
            
            //--TRIMMABLE-BOUNDARY-START(188979150861)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(188979150861)
            
            //--TRIMMABLE-BOUNDARY-START(176094248973)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094248973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddLast$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(176094248973)
            
            //--TRIMMABLE-BOUNDARY-START(30065360909)
            /*LinkedListNode<T> */ AddAfter$1(/*LinkedListNode<T>*/ node, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(node);
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(node.list, value);
                this.InternalInsertNodeBefore(node.next, result);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(30065360909)
            
            //--TRIMMABLE-BOUNDARY-START(25770393613)
            /*void */ AddAfter(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(node);
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(newNode);
                this.InternalInsertNodeBefore(node.next, newNode);
                newNode.list = this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770393613)
            
            //--TRIMMABLE-BOUNDARY-START(38655295501)
            /*LinkedListNode<T> */ AddBefore$1(/*LinkedListNode<T>*/ node, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(node);
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(node.list, value);
                this.InternalInsertNodeBefore(node, result);
                if (node === this.head)
                {
                    this.head = result;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(38655295501)
            
            //--TRIMMABLE-BOUNDARY-START(34360328205)
            /*void */ AddBefore(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(node);
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(newNode);
                this.InternalInsertNodeBefore(node, newNode);
                newNode.list = this;
                if (node === this.head)
                {
                    this.head = newNode;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360328205)
            
            //--TRIMMABLE-BOUNDARY-START(47245230093)
            /*LinkedListNode<T> */ AddFirst$1(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(this, value);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(result);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, result);
                    this.head = result;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230093)
            
            //--TRIMMABLE-BOUNDARY-START(42950262797)
            /*void */ AddFirst(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(node);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(node);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, node);
                    this.head = node;
                }
                node.list = this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950262797)
            
            //--TRIMMABLE-BOUNDARY-START(55835164685)
            /*LinkedListNode<T> */ AddLast$1(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LinkedListNode<T>*/ let result = new ($.$sc.System.Collections.Generic.LinkedListNode$$(T))().$ctor$1(this, value);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(result);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, result);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(55835164685)
            
            //--TRIMMABLE-BOUNDARY-START(51540197389)
            /*void */ AddLast(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sc.System.Collections.Generic.LinkedList$$(T).ValidateNewNode(node);
                if (this.head === null)
                {
                    this.InternalInsertNodeToEmptyList(node);
                }
                else 
                {
                    this.InternalInsertNodeBefore(this.head, node);
                }
                node.list = this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540197389)
            
            //--TRIMMABLE-BOUNDARY-START(60130131981)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130131981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LinkedListNode<T>?*/ let current = this.head;
                while(current !== null)
                {
                    /*LinkedListNode<T>*/ let temp = current;
                    current = current.Next;
                    temp.Invalidate();
                }
                this.head = null;
                this.count = 0;
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(60130131981)
            
            //--TRIMMABLE-BOUNDARY-START(64425099277)
            /*bool */ Contains(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Find(value) !== null;
            }
            //--TRIMMABLE-BOUNDARY-END(64425099277)
            
            //--TRIMMABLE-BOUNDARY-START(68720066573)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (index > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_BiggerThanCollection);
                }
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_InsufficientSpace);
                }
                /*LinkedListNode<T>?*/ let node = this.head;
                if (node !== null)
                {
                    do
                    {
                        $.$$.System.Array.$WriteT1.call(array, node.item, index++);
                        node = node.next;
                    }
                    while(node !== this.head);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720066573)
            
            //--TRIMMABLE-BOUNDARY-START(85899935757)
            /*LinkedListNode<T>? */ Find(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LinkedListNode<T>?*/ let node = this.head;
                /*EqualityComparer<T>*/ let c = $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                if (node !== null)
                {
                    if ($.$box(value, T) !== null)
                    {
                        do
                        {
                            if (c.Equals$2(node.item, value))
                            {
                                return node;
                            }
                            node = node.next;
                        }
                        while(node !== this.head);
                    }
                    else 
                    {
                        do
                        {
                            if ($.$box(node.item, T) === null)
                            {
                                return node;
                            }
                            node = node.next;
                        }
                        while(node !== this.head);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935757)
            
            //--TRIMMABLE-BOUNDARY-START(90194903053)
            /*LinkedListNode<T>? */ FindLast(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.head === null)
                {
                    return null;
                }
                /*LinkedListNode<T>?*/ let last = this.head.prev;
                /*LinkedListNode<T>?*/ let node = last;
                /*EqualityComparer<T>*/ let c = $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                if (node !== null)
                {
                    if ($.$box(value, T) !== null)
                    {
                        do
                        {
                            if (c.Equals$2(node.item, value))
                            {
                                return node;
                            }
                            node = node.prev;
                        }
                        while(node !== last);
                    }
                    else 
                    {
                        do
                        {
                            if ($.$box(node.item, T) === null)
                            {
                                return node;
                            }
                            node = node.prev;
                        }
                        while(node !== last);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(90194903053)
            
            //--TRIMMABLE-BOUNDARY-START(124554641421)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554641421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.LinkedList$$(T).Enumerator)().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554641421)
            
            //--TRIMMABLE-BOUNDARY-START(193274118157)
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274118157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(T) : this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274118157)
            
            //--TRIMMABLE-BOUNDARY-START(163209347085)
            /*bool */ Remove$1(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LinkedListNode<T>?*/ let node = this.Find(value);
                if (node !== null)
                {
                    this.InternalRemoveNode(node);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(163209347085)
            
            //--TRIMMABLE-BOUNDARY-START(158914379789)
            /*void */ Remove(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateNode(node);
                this.InternalRemoveNode(node);
            }
            //--TRIMMABLE-BOUNDARY-END(158914379789)
            
            //--TRIMMABLE-BOUNDARY-START(167504314381)
            /*void */ RemoveFirst()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.head === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListEmpty);
                }
                this.InternalRemoveNode(this.head);
            }
            //--TRIMMABLE-BOUNDARY-END(167504314381)
            
            //--TRIMMABLE-BOUNDARY-START(171799281677)
            /*void */ RemoveLast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.head === null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListEmpty);
                }
                this.InternalRemoveNode(this.head.prev);
            }
            //--TRIMMABLE-BOUNDARY-END(171799281677)
            
            //--TRIMMABLE-BOUNDARY-START(128849608717)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$7("Version"/*VersionName*/, this.version);
                info.AddValue$7("Count"/*CountName*/, this.count);
                if (this.count !== 0)
                {
                    /*T[]*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.count], null);
                    this.CopyTo(array, 0);
                    info.AddValue$9("Data"/*ValuesName*/, array, $.$typeArray(T).$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849608717)
            
            //--TRIMMABLE-BOUNDARY-START(154619412493)
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._siInfo === null)
                {
                    return;
                }
                /*int*/ let realVersion = this._siInfo.GetInt32("Version"/*VersionName*/);
                /*int*/ let count = this._siInfo.GetInt32("Count"/*CountName*/);
                if (count !== 0)
                {
                    /*T[]?*/ let array = $.$cast(this._siInfo.GetValue("Data"/*ValuesName*/, $.$typeArray(T).$type), $.$typeArray(T));
                    if (array === null)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MissingValues);
                    }
                    for(/*int*/ let i = 0; i < array.length; i++)
                    {
                        this.AddLast$1($.$$.System.Array.$ReadT1.call(array, i));
                    }
                }
                else 
                {
                    this.head = null;
                }
                this.version = realVersion;
                this._siInfo = null;
            }
            //--TRIMMABLE-BOUNDARY-END(154619412493)
            
            //--TRIMMABLE-BOUNDARY-START(137439543309)
            /*void */ InternalInsertNodeBefore(/*LinkedListNode<T>*/ node, /*LinkedListNode<T>*/ newNode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                newNode.next = node;
                newNode.prev = node.prev;
                node.prev.next = newNode;
                node.prev = newNode;
                this.version++;
                this.count++;
            }
            //--TRIMMABLE-BOUNDARY-END(137439543309)
            
            //--TRIMMABLE-BOUNDARY-START(141734510605)
            /*void */ InternalInsertNodeToEmptyList(/*LinkedListNode<T>*/ newNode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734510605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this.head === null && this.count === 0, "LinkedList must be empty when this method is called!");
                newNode.next = newNode;
                newNode.prev = newNode;
                this.head = newNode;
                this.version++;
                this.count++;
            }
            //--TRIMMABLE-BOUNDARY-END(141734510605)
            
            //--TRIMMABLE-BOUNDARY-START(146029477901)
            /*void */ InternalRemoveNode(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(node.list === this, "Deleting the node from another list!");
                $.$$.System.Diagnostics.Debug.Assert$2(this.head !== null, "This method shouldn't be called on empty list!");
                if (node.next === node)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this.count === 1 && this.head === node, "this should only be true for a list with only one node");
                    this.head = null;
                }
                else 
                {
                    node.next.prev = node.prev;
                    node.prev.next = node.next;
                    if (this.head === node)
                    {
                        this.head = node.next;
                    }
                }
                node.Invalidate();
                this.count--;
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(146029477901)
            
            //--TRIMMABLE-BOUNDARY-START(231928823821)
            static /*void */ ValidateNewNode(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928823821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if (node.list !== null)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.LinkedListNodeIsAttached);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928823821)
            
            //--TRIMMABLE-BOUNDARY-START(236223791117)
            /*void */ ValidateNode(/*LinkedListNode<T>*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223791117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(node, "node");
                if (node.list !== this)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.ExternalLinkedListNode);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223791117)
            
            //--TRIMMABLE-BOUNDARY-START(219043921933)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(219043921933)
            
            //--TRIMMABLE-BOUNDARY-START(223338889229)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(223338889229)
            
            //--TRIMMABLE-BOUNDARY-START(197569085453)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_InsufficientSpace);
                }
                /*T[]?*/ let tArray = $.$as(array, $.$typeArray(T));
                if (tArray !== null)
                {
                    this.CopyTo(tArray, index);
                }
                else 
                {
                    /*object?[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    /*LinkedListNode<T>?*/ let node = this.head;
                    try
                    {
                        if (node !== null)
                        {
                            do
                            {
                                $.$$.System.Array.$WriteT1.call(objects, $.$box(node.item, T), index++);
                                node = node.next;
                            }
                            while(node !== this.head);
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569085453)
            
            //--TRIMMABLE-BOUNDARY-START(227633856525)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227633856525);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633856525)
            
            //--TRIMMABLE-BOUNDARY-START(655373)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.LinkedList$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.LinkedList$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885557261)
                    /*LinkedList<T>*/  get _list() { return this.$getField(0, 4); }
                    /*LinkedList<T>*/  set _list(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885557261)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180524557)
                    /*LinkedListNode<T>?*/  get _node() { return this.$getField(4, 4); }
                    /*LinkedListNode<T>?*/  set _node(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180524557)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475491853)
                    /*int*/  get _version() { return this.$getField(8, 4); }
                    /*int*/  set _version(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475491853)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622669)
                    /*T?*/  get _current() { return this.$getField(12, 4); }
                    /*T?*/  set _current(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295622669)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590589965)
                    /*int*/  get _index() { return this.$getField(16, 4); }
                    /*int*/  set _index(value) { this.$setField(16, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590589965)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065426445)
                    $ctor$3(/*LinkedList<T>*/ list)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065426445);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._list = list;
                            this._version = list.version;
                            this._node = list.head;
                            this._current = $.$default(T);
                            this._index = 0;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065426445)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360393741)
                    /*T */ get Current()
                    {
                        return this._current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360393741)
                    
                    //--TRIMMABLE-BOUNDARY-START(55835230221)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64425164813);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._list.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current, T);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55835230221)
                    
                    //--TRIMMABLE-BOUNDARY-START(51540262925)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51540262925);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._node === null)
                        {
                            this._index = ((this._list.Count + 1) | 0);
                            return false;
                        }
                        ++this._index;
                        this._current = this._node.item;
                        this._node = this._node.next;
                        if (this._node === this._list.head)
                        {
                            this._node = null;
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51540262925)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720132109)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68720132109);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._list.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._current = $.$default(T);
                        this._node = this._list.head;
                        this._index = 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720132109)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655361037)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655361037);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655361037)
                    
                    //--TRIMMABLE-BOUNDARY-START(77310066701)
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77310066701);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77310066701)
                    
                    //--TRIMMABLE-BOUNDARY-START(73015099405)
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73015099405);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(73015099405)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770459149)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770459149)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._list = this._list;
                        copy._node = this._node;
                        copy._version = this._version;
                        copy._current = this._current;
                        copy._index = this._index;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885557261)
                        this._list = null;
                        //--TRIMMABLE-BOUNDARY-END(12885557261)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180524557)
                        this._node = null;
                        //--TRIMMABLE-BOUNDARY-END(17180524557)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475491853)
                        this._version = 0;
                        //--TRIMMABLE-BOUNDARY-END(21475491853)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295622669)
                        this._current = null;
                        //--TRIMMABLE-BOUNDARY-END(4295622669)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590589965)
                        this._index = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590589965)
                        
                    }
                    static $h = 655373;
                    static $z = 20;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.LinkedList$$(T).$h,
  "h": 655373
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.LinkedList<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655373)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Contains(T)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.CopyTo(T[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Remove(T)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //--TRIMMABLE-BOUNDARY-START(4452450305)
            //Generated interface implemetation for System.Runtime.Serialization.ISerializable.GetObjectData(System.Runtime.Serialization.SerializationInfo, System.Runtime.Serialization.StreamingContext)
            System$Runtime$Serialization$ISerializable$GetObjectData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4452450305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetObjectData(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4452450305)
            
            //--TRIMMABLE-BOUNDARY-START(4452188161)
            //Generated interface implemetation for System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object?)
            System$Runtime$Serialization$IDeserializationCallback$OnDeserialization()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4452188161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.OnDeserialization(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4452188161)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(249108693005)
                    this.VersionName = "Version";
                    //--TRIMMABLE-BOUNDARY-END(249108693005)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604968461)
                    this.CountName = "Count";
                    //--TRIMMABLE-BOUNDARY-END(81604968461)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518758413)
                    this.ValuesName = "Data";
                    //--TRIMMABLE-BOUNDARY-END(240518758413)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 589837;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.LinkedList<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(589837)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424845)
        $asm.$cls("$sc.System.Collections.Generic.SortedSet<>", (T) => $asm.$gt("$sc.System.Collections.Generic.SortedSet<>", [T], ($self) => class SortedSet$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(2686989)
            static $_TreeSubSet;
            static get TreeSubSet()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_TreeSubSet ??= $asm.$ncls("$sc.System.Collections.Generic.SortedSet$$.TreeSubSet", ($self) => class TreeSubSet extends $.$sc.System.Collections.Generic.SortedSet$$(T)
                {
                    //--TRIMMABLE-BOUNDARY-START(25772490765)
                    /*SortedSet<T>*/ _underlying = null;
                    //--TRIMMABLE-BOUNDARY-END(25772490765)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182556173)
                    /*T?*/ _min = null;
                    //--TRIMMABLE-BOUNDARY-END(17182556173)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887588877)
                    /*T?*/ _max = null;
                    //--TRIMMABLE-BOUNDARY-END(12887588877)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297654285)
                    /*int*/ _countVersion = 0;
                    //--TRIMMABLE-BOUNDARY-END(4297654285)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592621581)
                    /*bool*/ _lBoundActive = false;
                    //--TRIMMABLE-BOUNDARY-END(8592621581)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477523469)
                    /*bool*/ _uBoundActive = false;
                    //--TRIMMABLE-BOUNDARY-END(21477523469)
                    
                    //--TRIMMABLE-BOUNDARY-START(137441640461)
                    /*bool */ versionUpToDate()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(137441640461);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this.version === this._underlying.version);
                    }
                    //--TRIMMABLE-BOUNDARY-END(137441640461)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067458061)
                    $ctor$6(/*SortedSet<T>*/ Underlying, /*T?*/ Min, /*T?*/ Max, /*bool*/ lowerBoundActive, /*bool*/ upperBoundActive)
                    {
                        super.$ctor$2(Underlying.Comparer);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067458061);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._underlying = Underlying;
                            this._min = Min;
                            this._max = Max;
                            this._lBoundActive = lowerBoundActive;
                            this._uBoundActive = upperBoundActive;
                            this.root = this._underlying.FindRange(this._min, this._max, this._lBoundActive, this._uBoundActive);
                            this.count = 0;
                            this.version = -1;
                            this._countVersion = -1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067458061)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362425357)
                    /*bool */ AddIfNotPresent(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362425357);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this.IsWithinRange(item))
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("item");
                        }
                        /*bool*/ let ret = this._underlying.AddIfNotPresent(item);
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return ret;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362425357)
                    
                    //--TRIMMABLE-BOUNDARY-START(47247327245)
                    /*bool */ Contains(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47247327245);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return super.Contains(item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47247327245)
                    
                    //--TRIMMABLE-BOUNDARY-START(51542294541)
                    /*bool */ DoRemove(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51542294541);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this.IsWithinRange(item))
                        {
                            return false;
                        }
                        /*bool*/ let ret = this._underlying.Remove(item);
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return ret;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51542294541)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952359949)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952359949);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.Count === 0)
                        {
                            return;
                        }
                        /*List<T>*/ let toRemove = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$1();
                        this.BreadthFirstTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                        {
                            toRemove.Add(n.Item$1);
                            return true;
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "n",
      "p": 2621453
    }
  ],
  "n": "",
  "d": 2686989,
  "h": 0,
  "f": 17825794
}));
                        while(toRemove.Count !== 0)
                        {
                            this._underlying.Remove(toRemove.get_Item(toRemove.Count - 1));
                            toRemove.RemoveAt(((toRemove.Count - 1) | 0));
                        }
                        this.root = null;
                        this.count = 0;
                        this.version = this._underlying.version;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952359949)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786934797)
                    /*bool */ IsWithinRange(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98786934797);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let comp = this._lBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, item, [T]) : -1;
                        if (comp > 0)
                        {
                            return false;
                        }
                        comp = this._uBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, item, [T]) : 1;
                        return comp >= 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786934797)
                    
                    //--TRIMMABLE-BOUNDARY-START(107376869389)
                    /*T */ get MinInternal()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73017131021);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.VersionCheck(false);
                        /*Node?*/ let current = this.root;
                        /*T?*/ let result = $.$default(T);
                        while(current !== null)
                        {
                            /*int*/ let comp = this._lBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$1, [T]) : -1;
                            if (comp > 0)
                            {
                                current = current.Right;
                            }
                            else 
                            {
                                result = current.Item$1;
                                if (comp === 0)
                                {
                                    break;
                                }
                                current = current.Left;
                            }
                        }
                        return result;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107376869389)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081902093)
                    /*T */ get MaxInternal()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64427196429);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.VersionCheck(false);
                        /*Node?*/ let current = this.root;
                        /*T?*/ let result = $.$default(T);
                        while(current !== null)
                        {
                            /*int*/ let comp = this._uBoundActive ? this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, current.Item$1, [T]) : 1;
                            if (comp < 0)
                            {
                                current = current.Left;
                            }
                            else 
                            {
                                result = current.Item$1;
                                if (comp === 0)
                                {
                                    break;
                                }
                                current = current.Right;
                            }
                        }
                        return result;
                    }
                    //--TRIMMABLE-BOUNDARY-END(103081902093)
                    
                    //--TRIMMABLE-BOUNDARY-START(85902032909)
                    /*bool */ InOrderTreeWalk(/*TreeWalkPredicate<T>*/ action)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85902032909);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.VersionCheck(false);
                        if (this.root === null)
                        {
                            return true;
                        }
                        /*Stack<Node>*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((this.count + 1) | 0))) | 0));
                        /*Node?*/ let current = this.root;
                        while(current !== null)
                        {
                            if (this.IsWithinRange(current.Item$1))
                            {
                                stack.Push(current);
                                current = current.Left;
                            }
                            else if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$1, [T]) > 0)
                            {
                                current = current.Right;
                            }
                            else 
                            {
                                current = current.Left;
                            }
                        }
                        while(stack.Count !== 0)
                        {
                            current = stack.Pop();
                            if (!action.Invoke(current))
                            {
                                return false;
                            }
                            /*Node?*/ let node = current.Right;
                            while(node !== null)
                            {
                                if (this.IsWithinRange(node.Item$1))
                                {
                                    stack.Push(node);
                                    node = node.Left;
                                }
                                else if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, node.Item$1, [T]) > 0)
                                {
                                    node = node.Right;
                                }
                                else 
                                {
                                    node = node.Left;
                                }
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(85902032909)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657392653)
                    /*bool */ BreadthFirstTreeWalk(/*TreeWalkPredicate<T>*/ action)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657392653);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this.VersionCheck(false);
                        if (this.root === null)
                        {
                            return true;
                        }
                        /*Queue<Node>*/ let processQueue = new ($.$$.System.Collections.Generic.Queue$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$1();
                        processQueue.Enqueue(this.root);
                        /*Node*/ let current;
                        while(processQueue.Count !== 0)
                        {
                            current = processQueue.Dequeue();
                            if (this.IsWithinRange(current.Item$1) && !action.Invoke(current))
                            {
                                return false;
                            }
                            if (current.Left !== null && (!this._lBoundActive || this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, current.Item$1, [T]) < 0))
                            {
                                processQueue.Enqueue(current.Left);
                            }
                            if (current.Right !== null && (!this._uBoundActive || this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, current.Item$1, [T]) > 0))
                            {
                                processQueue.Enqueue(current.Right);
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657392653)
                    
                    //--TRIMMABLE-BOUNDARY-START(55837261837)
                    /*SortedSet<T>.Node? */ FindNode(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55837261837);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (!this.IsWithinRange(item))
                        {
                            return null;
                        }
                        this.VersionCheck(false);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return super.FindNode(item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(55837261837)
                    
                    //--TRIMMABLE-BOUNDARY-START(90197000205)
                    /*int */ InternalIndexOf(/*T*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90197000205);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let count = -1;
                        var $en4 = this.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var i = $en4.Current;
                            {
                                count++;
                                if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(item, i, [T]) === 0)
                                {
                                    return count;
                                }
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "this.versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(90197000205)
                    
                    //--TRIMMABLE-BOUNDARY-START(128851705869)
                    /*void */ VersionCheck(/*bool*/ updateCount)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(128851705869);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.VersionCheckImpl(updateCount);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(128851705869)
                    
                    //--TRIMMABLE-BOUNDARY-START(133146673165)
                    /*void */ VersionCheckImpl(/*bool*/ updateCount)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(133146673165);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._underlying !== null, "_underlying != null");
                        if (this.version !== this._underlying.version)
                        {
                            this.root = this._underlying.FindRange(this._min, this._max, this._lBoundActive, this._uBoundActive);
                            this.version = this._underlying.version;
                        }
                        if (updateCount && this._countVersion !== this._underlying.version)
                        {
                            this.count = 0;
                            this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                            {
                                this.count++;
                                return true;
                            }, {
  "r": 262145,
  "p": [
    {
      "n": "n",
      "p": 2621453
    }
  ],
  "n": "",
  "d": 2686989,
  "h": 0,
  "f": 17825794
}));
                            this._countVersion = this._underlying.version;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(133146673165)
                    
                    //--TRIMMABLE-BOUNDARY-START(124556738573)
                    /*int */ TotalCount()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(124556738573);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this._underlying !== null, "_underlying != null");
                        return this._underlying.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(124556738573)
                    
                    //--TRIMMABLE-BOUNDARY-START(81607065613)
                    /*SortedSet<T> */ GetViewBetween(/*T?*/ lowerValue, /*T?*/ upperValue)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81607065613);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._lBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._min, lowerValue, [T]) > 0)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("lowerValue");
                        }
                        if (this._uBoundActive && this.Comparer.System$Collections$Generic$IComparer$$$Compare(this._max, upperValue, [T]) < 0)
                        {
                            throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("upperValue");
                        }
                        return $.$cast(this._underlying.GetViewBetween(lowerValue, upperValue), $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81607065613)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491967501)
                    /*void */ IntersectWithEnumerable(/*IEnumerable<T>*/ other)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491967501);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        super.IntersectWithEnumerable(other);
                        $.$$.System.Diagnostics.Debug.Assert$2(this.versionUpToDate() && this.root === this._underlying.FindRange$1(this._min, this._max), "versionUpToDate() && root == _underlying.FindRange(_min, _max)");
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491967501)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261771277)
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(120261771277);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.GetObjectData(info, context);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(120261771277)
                    
                    //--TRIMMABLE-BOUNDARY-START(77312098317)
                    /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77312098317);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77312098317)
                    
                    //--TRIMMABLE-BOUNDARY-START(115966803981)
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115966803981);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(115966803981)
                    
                    //--TRIMMABLE-BOUNDARY-START(111671836685)
                    /*void */ OnDeserialization(/*object?*/ sender)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(111671836685);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(111671836685)
                    
                    static $h = 2686989;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "d": $.$sc.System.Collections.Generic.SortedSet$$(T).$h,
  "h": 2686989
}; }
                    static get $b() { return $.$sc.System.Collections.Generic.SortedSet$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.TreeSubSet`; }
                }, $cls, ($v) => $cls.$_TreeSubSet = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2686989)
            
            //--TRIMMABLE-BOUNDARY-START(326419939341)
            /*Node?*/ root = null;
            //--TRIMMABLE-BOUNDARY-END(326419939341)
            
            //--TRIMMABLE-BOUNDARY-START(68721901581)
            /*IComparer<T>*/ comparer = null;
            //--TRIMMABLE-BOUNDARY-END(68721901581)
            
            //--TRIMMABLE-BOUNDARY-START(107376607245)
            /*int*/ count = 0;
            //--TRIMMABLE-BOUNDARY-END(107376607245)
            
            //--TRIMMABLE-BOUNDARY-START(442384056333)
            /*int*/ version = 0;
            //--TRIMMABLE-BOUNDARY-END(442384056333)
            
            //--TRIMMABLE-BOUNDARY-START(335009873933)
            /*SerializationInfo?*/ siInfo = null;
            //--TRIMMABLE-BOUNDARY-END(335009873933)
            
            //--TRIMMABLE-BOUNDARY-START(77311836173)
            /*string*/ static ComparerName = null;
            //--TRIMMABLE-BOUNDARY-END(77311836173)
            
            //--TRIMMABLE-BOUNDARY-START(115966541837)
            /*string*/ static CountName = null;
            //--TRIMMABLE-BOUNDARY-END(115966541837)
            
            //--TRIMMABLE-BOUNDARY-START(266290397197)
            /*string*/ static ItemsName = null;
            //--TRIMMABLE-BOUNDARY-END(266290397197)
            
            //--TRIMMABLE-BOUNDARY-START(450973990925)
            /*string*/ static VersionName = null;
            //--TRIMMABLE-BOUNDARY-END(450973990925)
            
            //--TRIMMABLE-BOUNDARY-START(343599808525)
            /*int*/ static StackAllocThreshold = 100;
            //--TRIMMABLE-BOUNDARY-END(343599808525)
            
            //--TRIMMABLE-BOUNDARY-START(21477261325)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477261325);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(T).Default;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477261325)
            
            //--TRIMMABLE-BOUNDARY-START(25772228621)
            $ctor$2(/*IComparer<T>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772228621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.comparer = comparer ?? $.$$.System.Collections.Generic.Comparer$$(T).Default;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25772228621)
            
            //--TRIMMABLE-BOUNDARY-START(34362163213)
            $ctor$4(/*IEnumerable<T>*/ collection)
            {
                this.$ctor$3(collection, $.$$.System.Collections.Generic.Comparer$$(T).Default);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362163213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362163213)
            
            //--TRIMMABLE-BOUNDARY-START(30067195917)
            $ctor$3(/*IEnumerable<T>*/ collection, /*IComparer<T>?*/ comparer)
            {
                this.$ctor$2(comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067195917);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    /*SortedSet<T>?*/ let sortedSet = $.$as(collection, $.$sc.System.Collections.Generic.SortedSet$$(T));
                    if (sortedSet !== null && !($.$is(sortedSet, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet)) && this.HasEqualComparer(sortedSet))
                    {
                        if (sortedSet.Count > 0)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(sortedSet.root !== null, "sortedSet.root != null");
                            this.count = sortedSet.count;
                            this.root = sortedSet.root.DeepClone(this.count);
                        }
                        return this;
                    }
                    /*int*/ let count;
                    /*T[]*/ let elements = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, collection, $.$ref(() => count, ($v) => count = $v, $.$$.System.Int32));
                    if (count > 0)
                    {
                        comparer = this.comparer;
                        $.$$.System.Array.Sort$10(T, elements, 0, count, comparer);
                        /*int*/ let index = 1;
                        for(/*int*/ let i = 1; i < count; i++)
                        {
                            if (comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(elements, i), $.$$.System.Array.$ReadT1.call(elements, ((i - 1) | 0)), [T]) !== 0)
                            {
                                $.$$.System.Array.$WriteT1.call(elements, $.$$.System.Array.$ReadT1.call(elements, i), index++);
                            }
                        }
                        count = index;
                        this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(elements, 0, ((count - 1) | 0), null);
                        this.count = count;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30067195917)
            
            //--TRIMMABLE-BOUNDARY-START(38657130509)
            $ctor$5(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657130509);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.siInfo = info;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657130509)
            
            //--TRIMMABLE-BOUNDARY-START(47247065101)
            /*void */ AddAllElements(/*IEnumerable<T>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247065101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!this.Contains(item))
                        {
                            this.Add(item);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47247065101)
            
            //--TRIMMABLE-BOUNDARY-START(304945102861)
            /*void */ RemoveAllElements(/*IEnumerable<T>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304945102861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*T?*/ let min = this.Min;
                /*T?*/ let max = this.Max;
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!(this.comparer.System$Collections$Generic$IComparer$$$Compare(item, min, [T]) < 0 || this.comparer.System$Collections$Generic$IComparer$$$Compare(item, max, [T]) > 0) && this.Contains(item))
                        {
                            this.Remove(item);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(304945102861)
            
            //--TRIMMABLE-BOUNDARY-START(90196738061)
            /*bool */ ContainsAllElements(/*IEnumerable<T>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196738061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!this.Contains(item))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(90196738061)
            
            //--TRIMMABLE-BOUNDARY-START(219045756941)
            /*bool */ InOrderTreeWalk(/*TreeWalkPredicate<T>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045756941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    return true;
                }
                /*var*/ let stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((this.Count + 1) | 0))) | 0));
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    stack.Push(current);
                    current = current.Left;
                }
                while(stack.Count !== 0)
                {
                    current = stack.Pop();
                    if (!action.Invoke(current))
                    {
                        return false;
                    }
                    /*Node?*/ let node = current.Right;
                    while(node !== null)
                    {
                        stack.Push(node);
                        node = node.Left;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(219045756941)
            
            //--TRIMMABLE-BOUNDARY-START(55836999693)
            /*bool */ BreadthFirstTreeWalk(/*TreeWalkPredicate<T>*/ action)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836999693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    return true;
                }
                /*var*/ let processQueue = new ($.$$.System.Collections.Generic.Queue$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$1();
                processQueue.Enqueue(this.root);
                /*Node*/ let current;
                while(processQueue.Count !== 0)
                {
                    current = processQueue.Dequeue();
                    if (!action.Invoke(current))
                    {
                        return false;
                    }
                    if (current.Left !== null)
                    {
                        processQueue.Enqueue(current.Left);
                    }
                    if (current.Right !== null)
                    {
                        processQueue.Enqueue(current.Right);
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55836999693)
            
            //--TRIMMABLE-BOUNDARY-START(111671574541)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163211182093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.VersionCheck(true);
                return this.count;
            }
            //--TRIMMABLE-BOUNDARY-END(111671574541)
            
            //--TRIMMABLE-BOUNDARY-START(73016868877)
            /*IComparer<T> */ get Comparer()
            {
                return this.comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(73016868877)
            
            //--TRIMMABLE-BOUNDARY-START(373664579597)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(373664579597)
            
            //--TRIMMABLE-BOUNDARY-START(403729350669)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(403729350669)
            
            //--TRIMMABLE-BOUNDARY-START(408024317965)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(408024317965)
            
            //--TRIMMABLE-BOUNDARY-START(446679023629)
            /*void */ VersionCheck(/*bool*/ updateCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446679023629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(446679023629)
            
            //--TRIMMABLE-BOUNDARY-START(425204187149)
            /*int */ TotalCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425204187149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(425204187149)
            
            //--TRIMMABLE-BOUNDARY-START(261995429901)
            /*bool */ IsWithinRange(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261995429901);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261995429901)
            
            //--TRIMMABLE-BOUNDARY-START(42952097805)
            /*bool */ Add(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952097805);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.AddIfNotPresent(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42952097805)
            
            //--TRIMMABLE-BOUNDARY-START(360779677709)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(360779677709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(360779677709)
            
            //--TRIMMABLE-BOUNDARY-START(51542032397)
            /*bool */ AddIfNotPresent(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542032397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    this.root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(item, 0/*NodeColor.Black*/);
                    this.count = 1;
                    this.version++;
                    return true;
                }
                /*Node?*/ let current = this.root;
                /*Node?*/ let parent = null;
                /*Node?*/ let grandParent = null;
                /*Node?*/ let greatGrandParent = null;
                this.version++;
                /*int*/ let order = 0;
                while(current !== null)
                {
                    order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$1, [T]);
                    if (order === 0)
                    {
                        this.root.ColorBlack();
                        return false;
                    }
                    if (current.Is4Node)
                    {
                        current.Split4Node();
                        if ($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(parent))
                        {
                            this.InsertionBalance(current, $.$ref(() => parent, ($v) => parent = $v, $.$sc.System.Collections.Generic.SortedSet$$(T).Node), grandParent, greatGrandParent);
                        }
                    }
                    greatGrandParent = grandParent;
                    grandParent = parent;
                    parent = current;
                    current = (order < 0) ? current.Left : current.Right;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(parent !== null, "parent != null");
                /*Node*/ let node = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(item, 1/*NodeColor.Red*/);
                if (order > 0)
                {
                    parent.Right = node;
                }
                else 
                {
                    parent.Left = node;
                }
                if (parent.IsRed)
                {
                    this.InsertionBalance(node, $.$ref(() => parent, ($v) => parent = $v, $.$sc.System.Collections.Generic.SortedSet$$(T).Node), grandParent, greatGrandParent);
                }
                this.root.ColorBlack();
                ++this.count;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(51542032397)
            
            //--TRIMMABLE-BOUNDARY-START(300650135565)
            /*bool */ Remove(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300650135565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.DoRemove(item);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300650135565)
            
            //--TRIMMABLE-BOUNDARY-START(128851443725)
            /*bool */ DoRemove(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128851443725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    return false;
                }
                this.version++;
                /*Node?*/ let current = this.root;
                /*Node?*/ let parent = null;
                /*Node?*/ let grandParent = null;
                /*Node?*/ let match = null;
                /*Node?*/ let parentOfMatch = null;
                /*bool*/ let foundMatch = false;
                while(current !== null)
                {
                    if (current.Is2Node)
                    {
                        if (parent === null)
                        {
                            current.ColorRed();
                        }
                        else 
                        {
                            /*Node*/ let sibling = parent.GetSibling(current);
                            if (sibling.IsRed)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(parent.IsBlack, "parent.IsBlack");
                                if (parent.Right === sibling)
                                {
                                    parent.RotateLeft();
                                }
                                else 
                                {
                                    parent.RotateRight();
                                }
                                parent.ColorRed();
                                sibling.ColorBlack();
                                this.ReplaceChildOrRoot(grandParent, parent, sibling);
                                grandParent = sibling;
                                if (parent === match)
                                {
                                    parentOfMatch = sibling;
                                }
                                sibling = parent.GetSibling(current);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullBlack(sibling), "Node.IsNonNullBlack(sibling)");
                            if (sibling.Is2Node)
                            {
                                parent.Merge2Nodes();
                            }
                            else 
                            {
                                /*Node*/ let newGrandParent = parent.Rotate(parent.GetRotation(current, sibling));
                                newGrandParent.Color = parent.Color;
                                parent.ColorBlack();
                                current.ColorRed();
                                this.ReplaceChildOrRoot(grandParent, parent, newGrandParent);
                                if (parent === match)
                                {
                                    parentOfMatch = newGrandParent;
                                }
                            }
                        }
                    }
                    /*int*/ let order = foundMatch ? -1 : this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$1, [T]);
                    if (order === 0)
                    {
                        foundMatch = true;
                        match = current;
                        parentOfMatch = parent;
                    }
                    grandParent = parent;
                    parent = current;
                    current = order < 0 ? current.Left : current.Right;
                }
                if (match !== null)
                {
                    this.ReplaceNode(match, parentOfMatch, parent, grandParent);
                    --this.count;
                }
                this.root?.ColorBlack();
                return foundMatch;
            }
            //--TRIMMABLE-BOUNDARY-END(128851443725)
            
            //--TRIMMABLE-BOUNDARY-START(64426934285)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426934285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.root = null;
                this.count = 0;
                ++this.version;
            }
            //--TRIMMABLE-BOUNDARY-END(64426934285)
            
            //--TRIMMABLE-BOUNDARY-START(85901770765)
            /*bool */ Contains(/*T*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85901770765);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.FindNode(item) !== null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85901770765)
            
            //--TRIMMABLE-BOUNDARY-START(103081639949)
            /*void */ CopyTo$2(/*T[]*/ array)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103081639949);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CopyTo(array, 0, this.Count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103081639949)
            
            //--TRIMMABLE-BOUNDARY-START(98786672653)
            /*void */ CopyTo$1(/*T[]*/ array, /*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98786672653);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CopyTo(array, index, this.Count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786672653)
            
            //--TRIMMABLE-BOUNDARY-START(94491705357)
            /*void */ CopyTo(/*T[]*/ array, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491705357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                if (count > ((array.length - index) | 0))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                count += index;
                this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*node*/ node) =>
                {
                    if (index >= count)
                    {
                        return false;
                    }
                    $.$$.System.Array.$WriteT1.call(array, node.Item$1, index++);
                    return true;
                }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": 2621453
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(94491705357)
            
            //--TRIMMABLE-BOUNDARY-START(382254514189)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382254514189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                /*T[]?*/ let tarray = $.$as(array, $.$typeArray(T));
                if (tarray !== null)
                {
                    this.CopyTo$1(tarray, index);
                }
                else 
                {
                    /*object?[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        this.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$1, T), index++);
                            return true;
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": 2621453
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(382254514189)
            
            //--TRIMMABLE-BOUNDARY-START(201865887757)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865887757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.SortedSet$$(T).Enumerator)().$ctor$4(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201865887757)
            
            //--TRIMMABLE-BOUNDARY-START(377959546893)
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(377959546893);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(377959546893)
            
            //--TRIMMABLE-BOUNDARY-START(412319285261)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(412319285261);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(412319285261)
            
            //--TRIMMABLE-BOUNDARY-START(223340724237)
            /*void */ InsertionBalance(/*Node*/ current, /*ref Node*/ parent, /*Node*/ grandParent, /*Node*/ greatGrandParent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223340724237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(parent.$v !== null, "parent != null");
                $.$$.System.Diagnostics.Debug.Assert$2(grandParent !== null, "grandParent != null");
                /*bool*/ let parentIsOnRight = grandParent.Right === parent.$v;
                /*bool*/ let currentIsOnRight = parent.$v.Right === current;
                /*Node*/ let newChildOfGreatGrandParent;
                if (parentIsOnRight === currentIsOnRight)
                {
                    newChildOfGreatGrandParent = currentIsOnRight ? grandParent.RotateLeft() : grandParent.RotateRight();
                }
                else 
                {
                    newChildOfGreatGrandParent = currentIsOnRight ? grandParent.RotateLeftRight() : grandParent.RotateRightLeft();
                    parent.$v = greatGrandParent;
                }
                grandParent.ColorRed();
                newChildOfGreatGrandParent.ColorBlack();
                this.ReplaceChildOrRoot(greatGrandParent, grandParent, newChildOfGreatGrandParent);
            }
            //--TRIMMABLE-BOUNDARY-END(223340724237)
            
            //--TRIMMABLE-BOUNDARY-START(313535037453)
            /*void */ ReplaceChildOrRoot(/*Node?*/ parent, /*Node*/ child, /*Node*/ newChild)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313535037453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (parent !== null)
                {
                    parent.ReplaceChild(child, newChild);
                }
                else 
                {
                    this.root = newChild;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313535037453)
            
            //--TRIMMABLE-BOUNDARY-START(317830004749)
            /*void */ ReplaceNode(/*Node*/ match, /*Node*/ parentOfMatch, /*Node*/ successor, /*Node*/ parentOfSuccessor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317830004749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(match !== null, "match != null");
                if (successor === match)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(match.Right === null, "match.Right == null");
                    successor = match.Left;
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(parentOfSuccessor !== null, "parentOfSuccessor != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(successor.Left === null, "successor.Left == null");
                    $.$$.System.Diagnostics.Debug.Assert$2((successor.Right === null && successor.IsRed) || (successor.Right.IsRed && successor.IsBlack), "(successor.Right == null && successor.IsRed) || (successor.Right!.IsRed && successor.IsBlack)");
                    successor.Right?.ColorBlack();
                    if (parentOfSuccessor !== match)
                    {
                        parentOfSuccessor.Left = successor.Right;
                        successor.Right = match.Right;
                    }
                    successor.Left = match.Left;
                }
                if (successor !== null)
                {
                    successor.Color = match.Color;
                }
                this.ReplaceChildOrRoot(parentOfMatch, match, successor);
            }
            //--TRIMMABLE-BOUNDARY-END(317830004749)
            
            //--TRIMMABLE-BOUNDARY-START(137441378317)
            /*Node? */ FindNode(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441378317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    /*int*/ let order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$1, [T]);
                    if (order === 0)
                    {
                        return current;
                    }
                    current = order < 0 ? current.Left : current.Right;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(137441378317)
            
            //--TRIMMABLE-BOUNDARY-START(227635691533)
            /*int */ InternalIndexOf(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635691533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let current = this.root;
                /*int*/ let count = 0;
                while(current !== null)
                {
                    /*int*/ let order = this.comparer.System$Collections$Generic$IComparer$$$Compare(item, current.Item$1, [T]);
                    if (order === 0)
                    {
                        return count;
                    }
                    current = order < 0 ? current.Left : current.Right;
                    count = order < 0 ? (((((2 * count) | 0) + 1) | 0)) : (((((2 * count) | 0) + 2) | 0));
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(227635691533)
            
            //--TRIMMABLE-BOUNDARY-START(146031312909)
            /*Node? */ FindRange$1(/*T?*/ $from, /*T?*/ to)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146031312909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.FindRange($from, to, true, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146031312909)
            
            //--TRIMMABLE-BOUNDARY-START(141736345613)
            /*Node? */ FindRange(/*T?*/ $from, /*T?*/ to, /*bool*/ lowerBoundActive, /*bool*/ upperBoundActive)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736345613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let current = this.root;
                while(current !== null)
                {
                    if (lowerBoundActive && this.comparer.System$Collections$Generic$IComparer$$$Compare($from, current.Item$1, [T]) > 0)
                    {
                        current = current.Right;
                    }
                    else 
                    {
                        if (upperBoundActive && this.comparer.System$Collections$Generic$IComparer$$$Compare(to, current.Item$1, [T]) < 0)
                        {
                            current = current.Left;
                        }
                        else 
                        {
                            return current;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(141736345613)
            
            //--TRIMMABLE-BOUNDARY-START(438089089037)
            /*void */ UpdateVersion()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(438089089037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ++this.version;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438089089037)
            
            //--TRIMMABLE-BOUNDARY-START(120261509133)
            static /*IEqualityComparer<SortedSet<T>> */ CreateSetComparer()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120261509133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sc.System.Collections.Generic.SortedSet$$(T).CreateSetComparer$1(null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120261509133)
            
            //--TRIMMABLE-BOUNDARY-START(124556476429)
            static /*IEqualityComparer<SortedSet<T>> */ CreateSetComparer$1(/*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556476429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T))().$ctor$2(memberEqualityComparer);
            }
            //--TRIMMABLE-BOUNDARY-END(124556476429)
            
            //--TRIMMABLE-BOUNDARY-START(339304841229)
            static /*bool */ SortedSetEquals(/*SortedSet<T>?*/ set1, /*SortedSet<T>?*/ set2, /*IComparer<T>*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304841229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (set1 === null)
                {
                    return set2 === null;
                }
                if (set2 === null)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(set1 !== null, "set1 != null");
                    return false;
                }
                if (set1.HasEqualComparer(set2))
                {
                    return set1.Count === set2.Count && set1.SetEquals(set2);
                }
                /*bool*/ let found;
                var $en2 = set1.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item1 = $en2.Current;
                    {
                        found = false;
                        var $en4 = set2.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item2 = $en4.Current;
                            {
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(item1, item2, [T]) === 0)
                                {
                                    found = true;
                                    break;
                                }
                            }
                        }
                        if (!found)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(339304841229)
            
            //--TRIMMABLE-BOUNDARY-START(214750789645)
            /*bool */ HasEqualComparer(/*SortedSet<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750789645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Comparer === other.Comparer || $.$$.System.Object.Equals$1.call(this.Comparer, other.Comparer);
            }
            //--TRIMMABLE-BOUNDARY-END(214750789645)
            
            //--TRIMMABLE-BOUNDARY-START(433794121741)
            /*void */ UnionWith(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433794121741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                /*TreeSubSet?*/ let treeSubset = $.$as(this, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                if (treeSubset !== null)
                {
                    this.VersionCheck(false);
                }
                if (asSorted !== null && treeSubset === null && this.Count === 0)
                {
                    /*SortedSet<T>*/ let dummy = new ($.$sc.System.Collections.Generic.SortedSet$$(T))().$ctor$3(asSorted, this.comparer);
                    this.root = dummy.root;
                    this.count = dummy.count;
                    this.version++;
                    return;
                }
                if (asSorted !== null && treeSubset === null && this.HasEqualComparer(asSorted) && (asSorted.Count > $.trunc(this.Count / 2)))
                {
                    /*T[]*/ let merged = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((asSorted.Count + this.Count) | 0)], null);
                    /*int*/ let c = 0;
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext(), theirsEnded = !theirs.MoveNext();
                    while(!mineEnded && !theirsEnded)
                    {
                        /*int*/ let comp = this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]);
                        if (comp < 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, mine.Current, c++);
                            mineEnded = !mine.MoveNext();
                        }
                        else if (comp === 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            mineEnded = !mine.MoveNext();
                            theirsEnded = !theirs.MoveNext();
                        }
                        else 
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            theirsEnded = !theirs.MoveNext();
                        }
                    }
                    if (!mineEnded || !theirsEnded)
                    {
                        /*Enumerator*/ let remaining = (mineEnded ? theirs : mine);
                        do
                        {
                            $.$$.System.Array.$WriteT1.call(merged, remaining.Current, c++);
                        }
                        while(remaining.MoveNext());
                    }
                    this.root = null;
                    this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(merged, 0, ((c - 1) | 0), null);
                    this.count = c;
                    this.version++;
                }
                else 
                {
                    this.AddAllElements(other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(433794121741)
            
            //--TRIMMABLE-BOUNDARY-START(81606803469)
            static /*Node? */ ConstructRootFromSortedArray(/*T[]*/ arr, /*int*/ startIndex, /*int*/ endIndex, /*Node?*/ redNode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606803469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let size = ((((endIndex - startIndex) | 0) + 1) | 0);
                /*Node*/ let root;
                switch(size)
                {
                    case 0:
                    return null;
                    case 1:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    if (redNode !== null)
                    {
                        root.Left = redNode;
                    }
                    break;
                    case 2:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    root.Right = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, endIndex), 0/*NodeColor.Black*/);
                    root.Right.ColorRed();
                    if (redNode !== null)
                    {
                        root.Left = redNode;
                    }
                    break;
                    case 3:
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, ((startIndex + 1) | 0)), 0/*NodeColor.Black*/);
                    root.Left = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, startIndex), 0/*NodeColor.Black*/);
                    root.Right = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, endIndex), 0/*NodeColor.Black*/);
                    if (redNode !== null)
                    {
                        root.Left.Left = redNode;
                    }
                    break;
                    default:
                    /*int*/ let midpt = ($.trunc((((startIndex + endIndex) | 0)) / 2));
                    root = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, midpt), 0/*NodeColor.Black*/);
                    root.Left = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, startIndex, ((midpt - 1) | 0), redNode);
                    root.Right = size % 2 === 0 ? $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, ((midpt + 2) | 0), endIndex, new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1($.$$.System.Array.$ReadT1.call(arr, ((midpt + 1) | 0)), 1/*NodeColor.Red*/)) : $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(arr, ((midpt + 1) | 0), endIndex, null);
                    break;
                }
                return root;
            }
            //--TRIMMABLE-BOUNDARY-END(81606803469)
            
            //--TRIMMABLE-BOUNDARY-START(231930658829)
            /*void */ IntersectWith(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930658829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return;
                }
                if (other === this)
                {
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                /*TreeSubSet?*/ let treeSubset = $.$as(this, $.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet);
                if (treeSubset !== null)
                {
                    this.VersionCheck(false);
                }
                if (asSorted !== null && treeSubset === null && this.HasEqualComparer(asSorted))
                {
                    /*T[]*/ let merged = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.Count], null);
                    /*int*/ let c = 0;
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext(), theirsEnded = !theirs.MoveNext();
                    /*T?*/ let max = this.Max;
                    while(!mineEnded && !theirsEnded && this.Comparer.System$Collections$Generic$IComparer$$$Compare(theirs.Current, max, [T]) <= 0)
                    {
                        /*int*/ let comp = this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]);
                        if (comp < 0)
                        {
                            mineEnded = !mine.MoveNext();
                        }
                        else if (comp === 0)
                        {
                            $.$$.System.Array.$WriteT1.call(merged, theirs.Current, c++);
                            mineEnded = !mine.MoveNext();
                            theirsEnded = !theirs.MoveNext();
                        }
                        else 
                        {
                            theirsEnded = !theirs.MoveNext();
                        }
                    }
                    this.root = null;
                    this.root = $.$sc.System.Collections.Generic.SortedSet$$(T).ConstructRootFromSortedArray(merged, 0, ((c - 1) | 0), null);
                    this.count = c;
                    this.version++;
                }
                else 
                {
                    this.IntersectWithEnumerable(other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231930658829)
            
            //--TRIMMABLE-BOUNDARY-START(236225626125)
            /*void */ IntersectWithEnumerable(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225626125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<T>*/ let toSave = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$3(this.Count);
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this.Contains(item))
                        {
                            toSave.Add(item);
                        }
                    }
                }
                this.Clear();
                var $en2 = toSave.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        this.Add(item);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236225626125)
            
            //--TRIMMABLE-BOUNDARY-START(133146411021)
            /*void */ ExceptWith(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146411021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.count === 0)
                {
                    return;
                }
                if (other === this)
                {
                    this.Clear();
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.comparer.System$Collections$Generic$IComparer$$$Compare(asSorted.Max, this.Min, [T]) >= 0 && this.comparer.System$Collections$Generic$IComparer$$$Compare(asSorted.Min, this.Max, [T]) <= 0)
                    {
                        /*T?*/ let min = this.Min;
                        /*T?*/ let max = this.Max;
                        var $en4 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this.comparer.System$Collections$Generic$IComparer$$$Compare(item, min, [T]) < 0)
                                {
                                    continue;
                                }
                                if (this.comparer.System$Collections$Generic$IComparer$$$Compare(item, max, [T]) > 0)
                                {
                                    break;
                                }
                                this.Remove(item);
                            }
                        }
                    }
                }
                else 
                {
                    this.RemoveAllElements(other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146411021)
            
            //--TRIMMABLE-BOUNDARY-START(347894775821)
            /*void */ SymmetricExceptWith(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894775821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    this.UnionWith(other);
                    return;
                }
                if (other === this)
                {
                    this.Clear();
                    return;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    this.SymmetricExceptWithSameComparer$1(asSorted);
                }
                else 
                {
                    /*int*/ let length;
                    /*T[]*/ let elements = $.$sc.System.Collections.Generic.EnumerableHelpers.ToArray(T, other, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32));
                    $.$$.System.Array.Sort$10(T, elements, 0, length, this.Comparer);
                    this.SymmetricExceptWithSameComparer(elements, length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347894775821)
            
            //--TRIMMABLE-BOUNDARY-START(356484710413)
            /*void */ SymmetricExceptWithSameComparer$1(/*SortedSet<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356484710413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(other !== null, "other != null");
                $.$$.System.Diagnostics.Debug.Assert$2(this.HasEqualComparer(other), "HasEqualComparer(other)");
                var $en2 = other.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        /*bool*/ let result = this.Contains(item) ? this.Remove(item) : this.Add(item);
                        $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356484710413)
            
            //--TRIMMABLE-BOUNDARY-START(352189743117)
            /*void */ SymmetricExceptWithSameComparer(/*T[]*/ other, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189743117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(other !== null, "other != null");
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0 && count <= other.length, "count >= 0 && count <= other.Length");
                if (count === 0)
                {
                    return;
                }
                /*T*/ let previous = $.$$.System.Array.$ReadT1.call(other, 0);
                for(/*int*/ let i = 0; i < count; i++)
                {
                    while(i < count && i !== 0 && this.comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(other, i), previous, [T]) === 0)
                    {
                        i++;
                    }
                    if (i >= count)
                    {
                        break;
                    }
                    /*T*/ let current = $.$$.System.Array.$ReadT1.call(other, i);
                    /*bool*/ let result = this.Contains(current) ? this.Remove(current) : this.Add(current);
                    $.$$.System.Diagnostics.Debug.Assert$2(result, "result");
                    previous = current;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352189743117)
            
            //--TRIMMABLE-BOUNDARY-START(249110528013)
            /*bool */ IsSubsetOf(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110528013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count > asSorted.Count)
                    {
                        return false;
                    }
                    return this.IsSubsetOfSortedSetWithSameComparer(asSorted);
                }
                else 
                {
                    /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, false);
                    return result.UniqueCount === this.Count && result.UnfoundCount >= 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249110528013)
            
            //--TRIMMABLE-BOUNDARY-START(253405495309)
            /*bool */ IsSubsetOfSortedSetWithSameComparer(/*SortedSet<T>*/ asSorted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405495309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SortedSet<T>*/ let prunedOther = asSorted.GetViewBetween(this.Min, this.Max);
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var item = $en2.Current;
                    {
                        if (!prunedOther.Contains(item))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(253405495309)
            
            //--TRIMMABLE-BOUNDARY-START(240520593421)
            /*bool */ IsProperSubsetOf(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520593421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }))
                {
                    if (this.Count === 0)
                    {
                        return c.System$Collections$ICollection$Count > 0;
                    }
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count >= asSorted.Count)
                    {
                        return false;
                    }
                    return this.IsSubsetOfSortedSetWithSameComparer(asSorted);
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, false);
                return result.UniqueCount === this.Count && result.UnfoundCount > 0;
            }
            //--TRIMMABLE-BOUNDARY-END(240520593421)
            
            //--TRIMMABLE-BOUNDARY-START(257700462605)
            /*bool */ IsSupersetOf(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700462605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }) && c.System$Collections$ICollection$Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (this.Count < asSorted.Count)
                    {
                        return false;
                    }
                    /*SortedSet<T>*/ let pruned = this.GetViewBetween(asSorted.Min, asSorted.Max);
                    var $en3 = asSorted.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            if (!pruned.Contains(item))
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                }
                return this.ContainsAllElements(other);
            }
            //--TRIMMABLE-BOUNDARY-END(257700462605)
            
            //--TRIMMABLE-BOUNDARY-START(244815560717)
            /*bool */ IsProperSupersetOf(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815560717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return false;
                }
                let c;
                if ($.$is(other, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }) && c.System$Collections$ICollection$Count === 0)
                {
                    return true;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    if (asSorted.Count >= this.Count)
                    {
                        return false;
                    }
                    /*SortedSet<T>*/ let pruned = this.GetViewBetween(asSorted.Min, asSorted.Max);
                    var $en3 = asSorted.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var item = $en3.Current;
                        {
                            if (!pruned.Contains(item))
                            {
                                return false;
                            }
                        }
                    }
                    return true;
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, true);
                return result.UniqueCount < this.Count && result.UnfoundCount === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(244815560717)
            
            //--TRIMMABLE-BOUNDARY-START(330714906637)
            /*bool */ SetEquals(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714906637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted))
                {
                    /*Enumerator*/ let mine = this.GetEnumerator();
                    /*Enumerator*/ let theirs = asSorted.GetEnumerator();
                    /*bool*/ let mineEnded = !mine.MoveNext();
                    /*bool*/ let theirsEnded = !theirs.MoveNext();
                    while(!mineEnded && !theirsEnded)
                    {
                        if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(mine.Current, theirs.Current, [T]) !== 0)
                        {
                            return false;
                        }
                        mineEnded = !mine.MoveNext();
                        theirsEnded = !theirs.MoveNext();
                    }
                    return mineEnded && theirsEnded;
                }
                /*ElementCount*/ let result = this.CheckUniqueAndUnfoundElements(other, true);
                return result.UniqueCount === this.Count && result.UnfoundCount === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(330714906637)
            
            //--TRIMMABLE-BOUNDARY-START(296355168269)
            /*bool */ Overlaps(/*IEnumerable<T>*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296355168269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(other, "other");
                if (this.Count === 0)
                {
                    return false;
                }
                let c;
                if ($.$is(other, $.$$.System.Collections.Generic.ICollection$$(T), { set $v(v){ c = v; } }) && c.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    return false;
                }
                /*SortedSet<T>?*/ let asSorted = $.$as(other, $.$sc.System.Collections.Generic.SortedSet$$(T));
                if (asSorted !== null && this.HasEqualComparer(asSorted) && (this.comparer.System$Collections$Generic$IComparer$$$Compare(this.Min, asSorted.Max, [T]) > 0 || this.comparer.System$Collections$Generic$IComparer$$$Compare(this.Max, asSorted.Min, [T]) < 0))
                {
                    return false;
                }
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this.Contains(item))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(296355168269)
            
            //--TRIMMABLE-BOUNDARY-START(60131966989)
            /*ElementCount */ CheckUniqueAndUnfoundElements(/*IEnumerable<T>*/ other, /*bool*/ returnIfUnfound)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131966989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ElementCount*/ let result;
                if (this.Count === 0)
                {
                    /*int*/ let numElementsInOther = 0;
                    var $en3 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            numElementsInOther++;
                            break;
                        }
                    }
                    result.UniqueCount = 0;
                    result.UnfoundCount = numElementsInOther;
                    return result;
                }
                /*int*/ let originalLastIndex = this.Count;
                /*int*/ let intArrayLength = $.$sc.System.Collections.Generic.BitHelper.ToIntArrayLength(originalLastIndex);
                /*Span<int>*/ let span = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Int32, 100/*StackAllocThreshold*/, null);
                /*BitHelper*/ let bitHelper = (intArrayLength >>> 0) <= 100/*StackAllocThreshold*/ ? new $.$sc.System.Collections.Generic.BitHelper().$ctor$3(span.Slice(0, intArrayLength), true) : new $.$sc.System.Collections.Generic.BitHelper().$ctor$3($.$$.System.Span$$($.$$.System.Int32).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [intArrayLength], null)), false);
                /*int*/ let UnfoundCount = 0;
                /*int*/ let uniqueFoundCount = 0;
                var $en2 = other.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*int*/ let index = this.InternalIndexOf(item);
                        if (index >= 0)
                        {
                            if (!bitHelper.IsMarked(index))
                            {
                                bitHelper.MarkBit(index);
                                uniqueFoundCount++;
                            }
                        }
                        else 
                        {
                            UnfoundCount++;
                            if (returnIfUnfound)
                            {
                                break;
                            }
                        }
                    }
                }
                result.UniqueCount = uniqueFoundCount;
                result.UnfoundCount = UnfoundCount;
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(60131966989)
            
            //--TRIMMABLE-BOUNDARY-START(309240070157)
            /*int */ RemoveWhere(/*Predicate<T>*/ match)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309240070157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(match, "match");
                /*List<T>*/ let matches = new ($.$$.System.Collections.Generic.List$$(T))().$ctor$3(this.Count);
                this.BreadthFirstTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$(T))().$ctor(this,  (/*n*/ n) =>
                {
                    if (match.Invoke(n.Item$1))
                    {
                        matches.Add(n.Item$1);
                    }
                    return true;
                }, {
  "r": 262145,
  "p": [
    {
      "n": "n",
      "p": 2621453
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                /*int*/ let actuallyRemoved = 0;
                for(/*int*/ let i = ((matches.Count - 1) | 0); i >= 0; i--)
                {
                    if (this.Remove(matches.get_Item(i)))
                    {
                        actuallyRemoved++;
                    }
                }
                return actuallyRemoved;
            }
            //--TRIMMABLE-BOUNDARY-END(309240070157)
            
            //--TRIMMABLE-BOUNDARY-START(283470266381)
            /*T? */ get Min()
            {
                return this.MinInternal;
            }
            //--TRIMMABLE-BOUNDARY-END(283470266381)
            
            //--TRIMMABLE-BOUNDARY-START(287765233677)
            /*T? */ get MinInternal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570920461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    return $.$default(T);
                }
                /*Node*/ let current = this.root;
                while(current.Left !== null)
                {
                    current = current.Left;
                }
                return current.Item$1;
            }
            //--TRIMMABLE-BOUNDARY-END(287765233677)
            
            //--TRIMMABLE-BOUNDARY-START(274880331789)
            /*T? */ get Max()
            {
                return this.MaxInternal;
            }
            //--TRIMMABLE-BOUNDARY-END(274880331789)
            
            //--TRIMMABLE-BOUNDARY-START(279175299085)
            /*T? */ get MaxInternal()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391051277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.root === null)
                {
                    return $.$default(T);
                }
                /*Node*/ let current = this.root;
                while(current.Right !== null)
                {
                    current = current.Right;
                }
                return current.Item$1;
            }
            //--TRIMMABLE-BOUNDARY-END(279175299085)
            
            //--TRIMMABLE-BOUNDARY-START(322124972045)
            /*IEnumerable<T> */ Reverse()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    /*Enumerator*/ let e = new ($.$sc.System.Collections.Generic.SortedSet$$(T).Enumerator)().$ctor$3(this, true);
                    while(e.MoveNext())
                    {
                        yield e.Current;
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(322124972045)
            
            //--TRIMMABLE-BOUNDARY-START(210455822349)
            /*SortedSet<T> */ GetViewBetween(/*T?*/ lowerValue, /*T?*/ upperValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455822349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Comparer.System$Collections$Generic$IComparer$$$Compare(lowerValue, upperValue, [T]) > 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.SortedSet_LowerValueGreaterThanUpperValue, "lowerValue");
                }
                return new ($.$sc.System.Collections.Generic.SortedSet$$(T).TreeSubSet)().$ctor$6(this, lowerValue, upperValue, true, true);
            }
            //--TRIMMABLE-BOUNDARY-END(210455822349)
            
            //--TRIMMABLE-BOUNDARY-START(455268958221)
            /*bool */ versionUpToDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455268958221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(455268958221)
            
            //--TRIMMABLE-BOUNDARY-START(420909219853)
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(420909219853);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetObjectData(info, context);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420909219853)
            
            //--TRIMMABLE-BOUNDARY-START(206160855053)
            /*void */ GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160855053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(info, "info");
                info.AddValue$7("Count"/*CountName*/, this.count);
                info.AddValue$9("Comparer"/*ComparerName*/, this.comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type);
                info.AddValue$7("Version"/*VersionName*/, this.version);
                if (this.root !== null)
                {
                    /*T[]*/ let items = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.Count], null);
                    this.CopyTo$1(items, 0);
                    info.AddValue$9("Items"/*ItemsName*/, items, $.$typeArray(T).$type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206160855053)
            
            //--TRIMMABLE-BOUNDARY-START(416614252557)
            /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(416614252557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.OnDeserialization(sender);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416614252557)
            
            //--TRIMMABLE-BOUNDARY-START(292060200973)
            /*void */ OnDeserialization(/*object?*/ sender)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292060200973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.comparer !== null)
                {
                    return;
                }
                if (this.siInfo === null)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_InvalidOnDeser);
                }
                this.comparer = $.$cast(this.siInfo.GetValue("Comparer"/*ComparerName*/, $.$$.System.Collections.Generic.IComparer$$(T).$type), $.$$.System.Collections.Generic.IComparer$$(T));
                /*int*/ let savedCount = this.siInfo.GetInt32("Count"/*CountName*/);
                if (savedCount !== 0)
                {
                    /*T[]?*/ let items = $.$cast(this.siInfo.GetValue("Items"/*ItemsName*/, $.$typeArray(T).$type), $.$typeArray(T));
                    if (items === null)
                    {
                        throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MissingValues);
                    }
                    for(/*int*/ let i = 0; i < items.length; i++)
                    {
                        this.Add($.$$.System.Array.$ReadT1.call(items, i));
                    }
                }
                this.version = this.siInfo.GetInt32("Version"/*VersionName*/);
                if (this.count !== savedCount)
                {
                    throw new $.$$.System.Runtime.Serialization.SerializationException().$ctor$12($.$sc.System.SR.Serialization_MismatchedCount);
                }
                this.siInfo = null;
            }
            //--TRIMMABLE-BOUNDARY-END(292060200973)
            
            //--TRIMMABLE-BOUNDARY-START(2621453)
            static $_Node;
            static get Node()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_Node ??= $asm.$ncls("$sc.System.Collections.Generic.SortedSet$$.Node", ($self) => class Node extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(21477457933)
                    $ctor$1(/*T*/ item, /*NodeColor*/ color)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477457933);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Item$1 = item;
                            this.Color = color;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477457933)
                    
                    //--TRIMMABLE-BOUNDARY-START(146031509517)
                    static /*bool */ IsNonNullBlack(/*Node?*/ node)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(146031509517);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return node !== null && node.IsBlack;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(146031509517)
                    
                    //--TRIMMABLE-BOUNDARY-START(150326476813)
                    static /*bool */ IsNonNullRed(/*Node?*/ node)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(150326476813);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return node !== null && node.IsRed;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(150326476813)
                    
                    //--TRIMMABLE-BOUNDARY-START(154621444109)
                    static /*bool */ IsNullOrBlack(/*Node?*/ node)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(154621444109);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return node === null || node.IsBlack;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(154621444109)
                    
                    //--TRIMMABLE-BOUNDARY-START(163211378701)
                    /*T*/ Item$1 = $.$default(T);
                    //--TRIMMABLE-BOUNDARY-END(163211378701)
                    
                    //--TRIMMABLE-BOUNDARY-START(167506345997)
                    /*Node?*/ Left = null;
                    //--TRIMMABLE-BOUNDARY-END(167506345997)
                    
                    //--TRIMMABLE-BOUNDARY-START(180391247885)
                    /*Node?*/ Right = null;
                    //--TRIMMABLE-BOUNDARY-END(180391247885)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772425229)
                    /*NodeColor*/ Color = 0;
                    //--TRIMMABLE-BOUNDARY-END(25772425229)
                    
                    //--TRIMMABLE-BOUNDARY-START(141736542221)
                    /*bool */ get IsBlack()
                    {
                        return this.Color === 0/*NodeColor.Black*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(141736542221)
                    
                    //--TRIMMABLE-BOUNDARY-START(158916411405)
                    /*bool */ get IsRed()
                    {
                        return this.Color === 1/*NodeColor.Red*/;
                    }
                    //--TRIMMABLE-BOUNDARY-END(158916411405)
                    
                    //--TRIMMABLE-BOUNDARY-START(133146607629)
                    /*bool */ get Is2Node()
                    {
                        return this.IsBlack && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNullOrBlack(this.Left) && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNullOrBlack(this.Right);
                    }
                    //--TRIMMABLE-BOUNDARY-END(133146607629)
                    
                    //--TRIMMABLE-BOUNDARY-START(137441574925)
                    /*bool */ get Is4Node()
                    {
                        return $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(this.Left) && $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(this.Right);
                    }
                    //--TRIMMABLE-BOUNDARY-END(137441574925)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067392525)
                    /*void */ ColorBlack()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067392525);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Color = 0/*NodeColor.Black*/;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067392525)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362359821)
                    /*void */ ColorRed()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34362359821);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Color = 1/*NodeColor.Red*/;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362359821)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657327117)
                    /*Node */ DeepClone(/*int*/ count)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657327117);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(count === this.GetCount(), "count == GetCount()");
                        /*Node*/ let newRoot = this.ShallowClone();
                        /*var*/ let pendingNodes = new ($.$sc.System.Collections.Generic.Stack$$($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node)))().$ctor$3(((((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(count)) | 0) + 2) | 0));
                        pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(this, newRoot));
                        /*var*/ let next;
                        while(pendingNodes.TryPop($.$ref(() => next, ($v) => next = $v, $.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))))
                        {
                            /*Node*/ let clonedNode;
                            let left;
                            if ($.$is(next.Item1.Left, $.$sc.System.Collections.Generic.SortedSet$$(T).Node, { set $v(v){ left = v; } }))
                            {
                                clonedNode = left.ShallowClone();
                                next.Item2.Left = clonedNode;
                                pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(left, clonedNode));
                            }
                            let right;
                            if ($.$is(next.Item1.Right, $.$sc.System.Collections.Generic.SortedSet$$(T).Node, { set $v(v){ right = v; } }))
                            {
                                clonedNode = right.ShallowClone();
                                next.Item2.Right = clonedNode;
                                pendingNodes.Push(new ($.$$.System.ValueTuple$$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node, $.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(right, clonedNode));
                            }
                        }
                        return newRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657327117)
                    
                    //--TRIMMABLE-BOUNDARY-START(115966738445)
                    /*TreeRotation */ GetRotation(/*Node*/ current, /*Node*/ sibling)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115966738445);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2($.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Left) || $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Right), "IsNonNullRed(sibling.Left) || IsNonNullRed(sibling.Right)");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.HasChildren(current, sibling), "HasChildren(current, sibling)");
                        /*bool*/ let currentIsLeftChild = this.Left === current;
                        return $.$sc.System.Collections.Generic.SortedSet$$(T).Node.IsNonNullRed(sibling.Left) ? (currentIsLeftChild ? 3/*TreeRotation.RightLeft*/ : 2/*TreeRotation.Right*/) : (currentIsLeftChild ? 0/*TreeRotation.Left*/ : 1/*TreeRotation.LeftRight*/);
                    }
                    //--TRIMMABLE-BOUNDARY-END(115966738445)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261705741)
                    /*Node */ GetSibling(/*Node*/ node)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120261705741);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(node !== null, "node != null");
                        $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Boolean.op_ExclusiveOr(node === this.Left, node === this.Right), "node == Left ^ node == Right");
                        return node === this.Left ? this.Right : this.Left;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120261705741)
                    
                    //--TRIMMABLE-BOUNDARY-START(240520790029)
                    /*Node */ ShallowClone()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(240520790029);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.SortedSet$$(T).Node)().$ctor$1(this.Item$1, this.Color);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(240520790029)
                    
                    //--TRIMMABLE-BOUNDARY-START(244815757325)
                    /*void */ Split4Node()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(244815757325);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Left !== null, "Left != null");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Right !== null, "Right != null");
                        this.ColorRed();
                        this.Left.ColorBlack();
                        this.Right.ColorBlack();
                    }
                    //--TRIMMABLE-BOUNDARY-END(244815757325)
                    
                    //--TRIMMABLE-BOUNDARY-START(184686215181)
                    /*Node? */ Rotate(/*TreeRotation*/ rotation)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(184686215181);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Node*/ let removeRed;
                        switch(rotation)
                        {
                            case 2/*TreeRotation.Right*/:
                            removeRed = this.Left.Left;
                            $.$$.System.Diagnostics.Debug.Assert$2(removeRed.IsRed, "removeRed.IsRed");
                            removeRed.ColorBlack();
                            return this.RotateRight();
                            case 0/*TreeRotation.Left*/:
                            removeRed = this.Right.Right;
                            $.$$.System.Diagnostics.Debug.Assert$2(removeRed.IsRed, "removeRed.IsRed");
                            removeRed.ColorBlack();
                            return this.RotateLeft();
                            case 3/*TreeRotation.RightLeft*/:
                            $.$$.System.Diagnostics.Debug.Assert$2(this.Right.Left.IsRed, "Right!.Left!.IsRed");
                            return this.RotateRightLeft();
                            case 1/*TreeRotation.LeftRight*/:
                            $.$$.System.Diagnostics.Debug.Assert$2(this.Left.Right.IsRed, "Left!.Right!.IsRed");
                            return this.RotateLeftRight();
                            default:
                            $.$$.System.Diagnostics.Debug.Fail$1(`${"rotation"}: ${rotation} is not a defined ${"TreeRotation"} value.`);
                            return null;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(184686215181)
                    
                    //--TRIMMABLE-BOUNDARY-START(188981182477)
                    /*Node */ RotateLeft()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(188981182477);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Node*/ let child = this.Right;
                        this.Right = child.Left;
                        child.Left = this;
                        return child;
                    }
                    //--TRIMMABLE-BOUNDARY-END(188981182477)
                    
                    //--TRIMMABLE-BOUNDARY-START(193276149773)
                    /*Node */ RotateLeftRight()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(193276149773);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Node*/ let child = this.Left;
                        /*Node*/ let grandChild = child.Right;
                        this.Left = grandChild.Right;
                        grandChild.Right = this;
                        child.Right = grandChild.Left;
                        grandChild.Left = child;
                        return grandChild;
                    }
                    //--TRIMMABLE-BOUNDARY-END(193276149773)
                    
                    //--TRIMMABLE-BOUNDARY-START(197571117069)
                    /*Node */ RotateRight()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(197571117069);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Node*/ let child = this.Left;
                        this.Left = child.Right;
                        child.Right = this;
                        return child;
                    }
                    //--TRIMMABLE-BOUNDARY-END(197571117069)
                    
                    //--TRIMMABLE-BOUNDARY-START(201866084365)
                    /*Node */ RotateRightLeft()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(201866084365);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Node*/ let child = this.Right;
                        /*Node*/ let grandChild = child.Left;
                        this.Right = grandChild.Left;
                        grandChild.Left = this;
                        child.Left = grandChild.Right;
                        grandChild.Right = child;
                        return grandChild;
                    }
                    //--TRIMMABLE-BOUNDARY-END(201866084365)
                    
                    //--TRIMMABLE-BOUNDARY-START(171801313293)
                    /*void */ Merge2Nodes()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(171801313293);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this.IsRed, "IsRed");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Left.Is2Node, "Left!.Is2Node");
                        $.$$.System.Diagnostics.Debug.Assert$2(this.Right.Is2Node, "Right!.Is2Node");
                        this.ColorBlack();
                        this.Left.ColorRed();
                        this.Right.ColorRed();
                    }
                    //--TRIMMABLE-BOUNDARY-END(171801313293)
                    
                    //--TRIMMABLE-BOUNDARY-START(176096280589)
                    /*void */ ReplaceChild(/*Node*/ child, /*Node*/ newChild)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(176096280589);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(this.HasChild(child), "HasChild(child)");
                        if (this.Left === child)
                        {
                            this.Left = newChild;
                        }
                        else 
                        {
                            this.Right = newChild;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(176096280589)
                    
                    //--TRIMMABLE-BOUNDARY-START(111671771149)
                    /*int */ GetCount()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(111671771149);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return ((((1 + ((this.Left?.GetCount() ?? null) ?? 0)) | 0) + ((this.Right?.GetCount() ?? null) ?? 0)) | 0);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(111671771149)
                    
                    //--TRIMMABLE-BOUNDARY-START(124556673037)
                    /*bool */ HasChild(/*Node*/ child)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(124556673037);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return child === this.Left || child === this.Right;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(124556673037)
                    
                    //--TRIMMABLE-BOUNDARY-START(128851640333)
                    /*bool */ HasChildren(/*Node*/ child1, /*Node*/ child2)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(128851640333);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Diagnostics.Debug.Assert$2(child1 !== child2, "child1 != child2");
                        return (this.Left === child1 && this.Right === child2) || (this.Left === child2 && this.Right === child1);
                    }
                    //--TRIMMABLE-BOUNDARY-END(128851640333)
                    
                    static $h = 2621453;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedSet$$(T).$h,
  "h": 2621453
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.Node`; }
                }, $cls, ($v) => $cls.$_Node = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2621453)
            
            //--TRIMMABLE-BOUNDARY-START(2555917)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedSet$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17182425101)
                    /*SortedSet<T>*/  get _tree() { return this.$getField(0, 4); }
                    /*SortedSet<T>*/  set _tree(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17182425101)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477392397)
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21477392397)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887457805)
                    /*Stack<Node>*/  get _stack() { return this.$getField(8, 4); }
                    /*Stack<Node>*/  set _stack(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12887457805)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297523213)
                    /*Node?*/  get _current() { return this.$getField(12, 4); }
                    /*Node?*/  set _current(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297523213)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592490509)
                    /*bool*/  get _reverse() { return this.$getField(16, 1); }
                    /*bool*/  set _reverse(value) { this.$setField(16, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592490509)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362294285)
                    $ctor$4(/*SortedSet<T>*/ set)
                    {
                        this.$ctor$3(set, false);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34362294285);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34362294285)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067326989)
                    $ctor$3(/*SortedSet<T>*/ set, /*bool*/ reverse)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30067326989);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._tree = set;
                            set.VersionCheck(false);
                            this._version = set.version;
                            this._stack = new ($.$sc.System.Collections.Generic.Stack$$($.$sc.System.Collections.Generic.SortedSet$$(T).Node))().$ctor$3(((2 * $.$sc.System.Collections.Generic.SortedSet$$(T).Log2(((set.TotalCount() + 1) | 0))) | 0));
                            this._current = null;
                            this._reverse = reverse;
                            this.Initialize();
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067326989)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081771021)
                    /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ info, /*StreamingContext*/ context)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103081771021);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(103081771021)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786803725)
                    /*void */ System$Runtime$Serialization$IDeserializationCallback$OnDeserialization(/*object?*/ sender)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(98786803725);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786803725)
                    
                    //--TRIMMABLE-BOUNDARY-START(64427065357)
                    /*void */ Initialize()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64427065357);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._current = null;
                        /*Node?*/ let node = this._tree.root;
                        /*Node?*/ let next, other;
                        while(node !== null)
                        {
                            next = (this._reverse ? node.Right : node.Left);
                            other = (this._reverse ? node.Left : node.Right);
                            if (this._tree.IsWithinRange(node.Item$1))
                            {
                                this._stack.Push(node);
                                node = next;
                            }
                            else if (next === null || !this._tree.IsWithinRange(next.Item$1))
                            {
                                node = other;
                            }
                            else 
                            {
                                node = next;
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64427065357)
                    
                    //--TRIMMABLE-BOUNDARY-START(68722032653)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68722032653);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._tree.VersionCheck(false);
                        if (this._version !== this._tree.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if (this._stack.Count === 0)
                        {
                            this._current = null;
                            return false;
                        }
                        this._current = this._stack.Pop();
                        /*Node?*/ let node = (this._reverse ? this._current.Left : this._current.Right);
                        /*Node?*/ let next, other;
                        while(node !== null)
                        {
                            next = (this._reverse ? node.Right : node.Left);
                            other = (this._reverse ? node.Left : node.Right);
                            if (this._tree.IsWithinRange(node.Item$1))
                            {
                                this._stack.Push(node);
                                node = next;
                            }
                            else if (other === null || !this._tree.IsWithinRange(other.Item$1))
                            {
                                node = next;
                            }
                            else 
                            {
                                node = other;
                            }
                        }
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(68722032653)
                    
                    //--TRIMMABLE-BOUNDARY-START(42952228877)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42952228877);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(42952228877)
                    
                    //--TRIMMABLE-BOUNDARY-START(38657261581)
                    /*T */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(51542163469);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current !== null)
                        {
                            return this._current.Item$1;
                        }
                        return $.$default(T);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38657261581)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606934541)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90196869133);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._current === null)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._current.Item$1, T);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606934541)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016999949)
                    /*bool */ get NotStartedOrEnded()
                    {
                        return this._current === null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016999949)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311967245)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311967245);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._tree.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._stack.Clear();
                        this.Initialize();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311967245)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491836429)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(94491836429);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Reset();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491836429)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772359693)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772359693)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._tree = this._tree;
                        copy._version = this._version;
                        copy._stack = this._stack;
                        copy._current = this._current;
                        copy._reverse = this._reverse;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17182425101)
                        this._tree = null;
                        //--TRIMMABLE-BOUNDARY-END(17182425101)
                        
                        //--TRIMMABLE-BOUNDARY-START(21477392397)
                        this._version = 0;
                        //--TRIMMABLE-BOUNDARY-END(21477392397)
                        
                        //--TRIMMABLE-BOUNDARY-START(12887457805)
                        this._stack = null;
                        //--TRIMMABLE-BOUNDARY-END(12887457805)
                        
                        //--TRIMMABLE-BOUNDARY-START(4297523213)
                        this._current = null;
                        //--TRIMMABLE-BOUNDARY-END(4297523213)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592490509)
                        this._reverse = false;
                        //--TRIMMABLE-BOUNDARY-END(8592490509)
                        
                    }
                    static $h = 2555917;
                    static $z = 17;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.SortedSet$$(T).$h,
  "h": 2555917
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(T), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2555917)
            
            //--TRIMMABLE-BOUNDARY-START(2490381)
            static $_ElementCount;
            static get ElementCount()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedSet$$(T);
                return $cls.$_ElementCount ??= $asm.$nstr("$sc.System.Collections.Generic.SortedSet$$.ElementCount", ($self) => class ElementCount extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12887392269)
                    /*int*/  get UniqueCount() { return this.$getField(0, $.$$.System.Int32); }
                    /*int*/  set UniqueCount(value) { this.$setField(0, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(12887392269)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592424973)
                    /*int*/  get UnfoundCount() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set UnfoundCount(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592424973)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297457677)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4297457677)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.UniqueCount = this.UniqueCount;
                        copy.UnfoundCount = this.UnfoundCount;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12887392269)
                        this.UniqueCount = 0;
                        //--TRIMMABLE-BOUNDARY-END(12887392269)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592424973)
                        this.UnfoundCount = 0;
                        //--TRIMMABLE-BOUNDARY-END(8592424973)
                        
                    }
                    static $h = 2490381;
                    static $z = 8;
                    static $f = 0b10000010000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.SortedSet$$(T).$h,
  "h": 2490381
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>.ElementCount`; }
                }, $cls, ($v) => $cls.$_ElementCount = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2490381)
            
            //--TRIMMABLE-BOUNDARY-START(429499154445)
            /*bool */ TryGetValue(/*T*/ equalValue, /*out T*/ actualValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429499154445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Node?*/ let node = this.FindNode(equalValue);
                if (node !== null)
                {
                    actualValue.$v = node.Item$1;
                    return true;
                }
                actualValue.$v = $.$default(T);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(429499154445)
            
            //--TRIMMABLE-BOUNDARY-START(270585364493)
            static /*int */ Log2(/*int*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270585364493);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Numerics.BitOperations.Log2((value >>> 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270585364493)
            
            //--TRIMMABLE-BOUNDARY-START(4355260417)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.Add(T)
            System$Collections$Generic$ISet$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355260417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355260417)
            
            //--TRIMMABLE-BOUNDARY-START(47304933377)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.UnionWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$UnionWith()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47304933377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.UnionWith(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47304933377)
            
            //--TRIMMABLE-BOUNDARY-START(12945195009)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IntersectWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IntersectWith()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945195009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IntersectWith(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12945195009)
            
            //--TRIMMABLE-BOUNDARY-START(8650227713)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.ExceptWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$ExceptWith()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650227713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ExceptWith(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650227713)
            
            //--TRIMMABLE-BOUNDARY-START(43009966081)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.SymmetricExceptWith(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$SymmetricExceptWith()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009966081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SymmetricExceptWith(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009966081)
            
            //--TRIMMABLE-BOUNDARY-START(25830096897)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsSubsetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25830096897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSubsetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25830096897)
            
            //--TRIMMABLE-BOUNDARY-START(30125064193)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsSupersetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30125064193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSupersetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30125064193)
            
            //--TRIMMABLE-BOUNDARY-START(21535129601)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsProperSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsProperSupersetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21535129601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsProperSupersetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21535129601)
            
            //--TRIMMABLE-BOUNDARY-START(17240162305)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.IsProperSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$IsProperSubsetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17240162305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsProperSubsetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17240162305)
            
            //--TRIMMABLE-BOUNDARY-START(34420031489)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.Overlaps(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$Overlaps()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34420031489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Overlaps(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(34420031489)
            
            //--TRIMMABLE-BOUNDARY-START(38714998785)
            //Generated interface implemetation for System.Collections.Generic.ISet<T>.SetEquals(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$ISet$$$SetEquals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38714998785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetEquals(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(38714998785)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Contains(T)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.CopyTo(T[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Remove(T)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(4355194881)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.Contains(T)
            System$Collections$Generic$IReadOnlySet$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355194881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355194881)
            
            //--TRIMMABLE-BOUNDARY-START(8650162177)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsProperSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsProperSubsetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8650162177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsProperSubsetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8650162177)
            
            //--TRIMMABLE-BOUNDARY-START(12945129473)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsProperSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsProperSupersetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12945129473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsProperSupersetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12945129473)
            
            //--TRIMMABLE-BOUNDARY-START(17240096769)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsSubsetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsSubsetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17240096769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSubsetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17240096769)
            
            //--TRIMMABLE-BOUNDARY-START(21535064065)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.IsSupersetOf(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$IsSupersetOf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21535064065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsSupersetOf(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21535064065)
            
            //--TRIMMABLE-BOUNDARY-START(25830031361)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.Overlaps(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$Overlaps()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25830031361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Overlaps(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(25830031361)
            
            //--TRIMMABLE-BOUNDARY-START(30124998657)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlySet<T>.SetEquals(System.Collections.Generic.IEnumerable<T>)
            System$Collections$Generic$IReadOnlySet$$$SetEquals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30124998657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.SetEquals(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30124998657)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(68721901581)
                this.comparer = null;
                //--TRIMMABLE-BOUNDARY-END(68721901581)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(77311836173)
                    this.ComparerName = "Comparer";
                    //--TRIMMABLE-BOUNDARY-END(77311836173)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115966541837)
                    this.CountName = "Count";
                    //--TRIMMABLE-BOUNDARY-END(115966541837)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266290397197)
                    this.ItemsName = "Items";
                    //--TRIMMABLE-BOUNDARY-END(266290397197)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450973990925)
                    this.VersionName = "Version";
                    //--TRIMMABLE-BOUNDARY-END(450973990925)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2424845;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.SortedSet<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2424845)
        
        
        //--TRIMMABLE-BOUNDARY-START(131085)
        $asm.$str("$sc.System.Collections.Generic.DebugViewDictionaryItem<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.DebugViewDictionaryItem<,>", [TKey, TValue], ($self) => class DebugViewDictionaryItem$$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(21474967565)
            $ctor$4(/*TKey*/ key, /*TValue*/ value)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474967565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = key;
                    this.Value = value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967565)
            
            //--TRIMMABLE-BOUNDARY-START(17180000269)
            $ctor$3(/*KeyValuePair<TKey, TValue>*/ keyValue)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Key = keyValue.Key;
                    this.Value = keyValue.Value;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000269)
            
            //--TRIMMABLE-BOUNDARY-START(42949804045)
            /*TKey*/ Key = $.$default(TKey);
            //--TRIMMABLE-BOUNDARY-END(42949804045)
            
            //--TRIMMABLE-BOUNDARY-START(47244771341)
            /*TValue*/ Value = $.$default(TValue);
            //--TRIMMABLE-BOUNDARY-END(47244771341)
            
            //--TRIMMABLE-BOUNDARY-START(12885032973)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032973)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Key = this.Key;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 131085;
            static $g = 2;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.DebugViewDictionaryItem<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131085)
        
        
        //--TRIMMABLE-BOUNDARY-START(65549)
        $asm.$str("$sc.System.Collections.Generic.BitHelper", ($self) => class BitHelper extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17179934733)
            /*int*/ static IntSize = 32;
            //--TRIMMABLE-BOUNDARY-END(17179934733)
            
            //--TRIMMABLE-BOUNDARY-START(4295032845)
            /*Span<int>*/  get _span() { return this.$getField(0, 8); }
            /*Span<int>*/  set _span(value) { this.$setField(0, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(4295032845)
            
            //--TRIMMABLE-BOUNDARY-START(12884967437)
            $ctor$3(/*Span<int>*/ span, /*bool*/ clear)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967437);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (clear)
                    {
                        span.Clear();
                    }
                    this._span = span;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967437)
            
            //--TRIMMABLE-BOUNDARY-START(25769869325)
            /*void */ MarkBit(/*int*/ bitPosition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(bitPosition >= 0, "bitPosition >= 0");
                /*uint*/ let bitArrayIndex = $.trunc((bitPosition >>> 0) / 32/*IntSize*/);
                /*Span<int>*/ let span = this._span;
                if (bitArrayIndex < (span.Length >>> 0))
                {
                    span.get_Item((bitArrayIndex | 0)).$v |= (1 << (((bitPosition >>> 0) % 32/*IntSize*/) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869325)
            
            //--TRIMMABLE-BOUNDARY-START(21474902029)
            /*bool */ IsMarked(/*int*/ bitPosition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(bitPosition >= 0, "bitPosition >= 0");
                /*uint*/ let bitArrayIndex = $.trunc((bitPosition >>> 0) / 32/*IntSize*/);
                /*ReadOnlySpan<int>*/ let span = $.$$.System.Span$$($.$$.System.Int32).op_Implicit(this._span);
                return bitArrayIndex < (span.Length >>> 0) && (span.get_Item((bitArrayIndex | 0)).$v & (1 << ((((bitPosition >>> 0) % 32/*IntSize*/) | 0)))) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902029)
            
            //--TRIMMABLE-BOUNDARY-START(30064836621)
            static /*int */ ToIntArrayLength(/*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064836621);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return n > 0 ? ((($.trunc((((n - 1) | 0)) / 32/*IntSize*/) + 1) | 0)) : 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836621)
            
            //--TRIMMABLE-BOUNDARY-START(8590000141)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000141)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._span = this._span.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295032845)
                this._span = $.$default($.$$.System.Span$$($.$$.System.Int32));
                //--TRIMMABLE-BOUNDARY-END(4295032845)
                
            }
            static $h = 65549;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "h": 65549
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.BitHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65549)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145741)
        $asm.$cls("$sc.System.Collections.Generic.TreeWalkPredicate<>", (T) => $asm.$gt("$sc.System.Collections.Generic.TreeWalkPredicate<>", [T], ($self) => class TreeWalkPredicate$$ extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/**/ node)
            {
                return this.$nativeFunction.call(this.$target, node);
            }
            static $h = 3145741;
            static $g = 1;
            static $f = 0b11000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Collections.Generic.TreeWalkPredicate<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3145741)
        
        
        //--TRIMMABLE-BOUNDARY-START(786445)
        $asm.$str("$sc.System.Collections.Generic.NodeColor", ($self) => class NodeColor extends $.$$.System.Enum
        {
            static Black = 0;
            static Red = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Black": 0n,
                    "Red": 1n
                };
            }
            static $h = 786445;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 393217,
  "h": 786445
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.NodeColor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786445)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014669)
        $asm.$str("$sc.System.Collections.Generic.TreeRotation", ($self) => class TreeRotation extends $.$$.System.Enum
        {
            static Left = 0;
            static LeftRight = 1;
            static Right = 2;
            static RightLeft = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(3014669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Left": 0n,
                    "LeftRight": 1n,
                    "Right": 2n,
                    "RightLeft": 3n
                };
            }
            static $h = 3014669;
            static $z = 1;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Byte; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 393217,
  "h": 3014669
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.TreeRotation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014669)
        
        
        //--TRIMMABLE-BOUNDARY-START(524301)
        $asm.$str("$sc.System.Collections.Generic.InsertionBehavior", ($self) => class InsertionBehavior extends $.$$.System.Enum
        {
            static IgnoreInsertion = 0;
            static OverwriteExisting = 1;
            static ThrowOnExisting = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "IgnoreInsertion": 0n,
                    "OverwriteExisting": 1n,
                    "ThrowOnExisting": 2n
                };
            }
            static $h = 524301;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "h": 524301
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Collections.Generic.InsertionBehavior`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524301)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752525)
        $asm.$cls("$sc.System.Collections.Generic.SortedSetEqualityComparer<>", (T) => $asm.$gt("$sc.System.Collections.Generic.SortedSetEqualityComparer<>", [T], ($self) => class SortedSetEqualityComparer$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297719821)
            /*IComparer<T>*/ _comparer = null;
            //--TRIMMABLE-BOUNDARY-END(4297719821)
            
            //--TRIMMABLE-BOUNDARY-START(8592687117)
            /*IEqualityComparer<T>*/ _memberEqualityComparer = null;
            //--TRIMMABLE-BOUNDARY-END(8592687117)
            
            //--TRIMMABLE-BOUNDARY-START(17182621709)
            $ctor$2(/*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                this.$ctor$1(null, memberEqualityComparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182621709);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182621709)
            
            //--TRIMMABLE-BOUNDARY-START(12887654413)
            $ctor$1(/*IComparer<T>?*/ comparer, /*IEqualityComparer<T>?*/ memberEqualityComparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887654413);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._comparer = comparer ?? $.$$.System.Collections.Generic.Comparer$$(T).Default;
                    this._memberEqualityComparer = memberEqualityComparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(T).Default;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887654413)
            
            //--TRIMMABLE-BOUNDARY-START(25772556301)
            /*bool */ Equals$2(/*SortedSet<T>?*/ x, /*SortedSet<T>?*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25772556301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sc.System.Collections.Generic.SortedSet$$(T).SortedSetEquals(x, y, this._comparer);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25772556301)
            
            //--TRIMMABLE-BOUNDARY-START(34362490893)
            /*int */ GetHashCode$1(/*SortedSet<T>*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362490893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let hashCode = 0;
                if (obj !== null)
                {
                    var $en3 = obj.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var t = $en3.Current;
                        {
                            if ($.$box(t, T) !== null)
                            {
                                hashCode ^= (this._memberEqualityComparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(t, [T]) & 2147483647);
                            }
                        }
                    }
                }
                return hashCode;
            }
            //--TRIMMABLE-BOUNDARY-END(34362490893)
            
            //--TRIMMABLE-BOUNDARY-START(21477589005)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477589005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SortedSetEqualityComparer<T>?*/ let comparer = $.$as(obj, $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T));
                return comparer !== null && this._comparer === comparer._comparer;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T).Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21477589005)
            
            //--TRIMMABLE-BOUNDARY-START(30067523597)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067523597);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Object.GetHashCode.call(this._comparer) ^ $.$$.System.Object.GetHashCode.call(this._memberEqualityComparer);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sc.System.Collections.Generic.SortedSetEqualityComparer$$(T).GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30067523597)
            
            //--TRIMMABLE-BOUNDARY-START(4354736129)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Collections.Generic.SortedSet<T>>.Equals(System.Collections.Generic.SortedSet<T>?, System.Collections.Generic.SortedSet<T>?)
            System$Collections$Generic$IEqualityComparer$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354736129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354736129)
            
            //--TRIMMABLE-BOUNDARY-START(8649703425)
            //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Collections.Generic.SortedSet<T>>.GetHashCode(System.Collections.Generic.SortedSet<T>)
            System$Collections$Generic$IEqualityComparer$$$GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649703425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetHashCode$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649703425)
            
            static $h = 2752525;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEqualityComparer$$($.$sc.System.Collections.Generic.SortedSet$$(T)) ]; }
            static get $fullName() { return `System.Collections.Generic.SortedSetEqualityComparer<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2752525)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031629)
        $asm.$cls("$sc.System.Collections.Generic.SortedList<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.SortedList<,>", [TKey, TValue], ($self) => class SortedList$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(193275559949)
            /*TKey[]*/ keys = null;
            //--TRIMMABLE-BOUNDARY-END(193275559949)
            
            //--TRIMMABLE-BOUNDARY-START(459563532301)
            /*TValue[]*/ values = null;
            //--TRIMMABLE-BOUNDARY-END(459563532301)
            
            //--TRIMMABLE-BOUNDARY-START(4296998925)
            /*int*/ _size = 0;
            //--TRIMMABLE-BOUNDARY-END(4296998925)
            
            //--TRIMMABLE-BOUNDARY-START(468153466893)
            /*int*/ version = 0;
            //--TRIMMABLE-BOUNDARY-END(468153466893)
            
            //--TRIMMABLE-BOUNDARY-START(68721508365)
            /*IComparer<TKey>*/ comparer = null;
            //--TRIMMABLE-BOUNDARY-END(68721508365)
            
            //--TRIMMABLE-BOUNDARY-START(188980592653)
            /*KeyList?*/ keyList = null;
            //--TRIMMABLE-BOUNDARY-END(188980592653)
            
            //--TRIMMABLE-BOUNDARY-START(455268565005)
            /*ValueList?*/ valueList = null;
            //--TRIMMABLE-BOUNDARY-END(455268565005)
            
            //--TRIMMABLE-BOUNDARY-START(90196344845)
            /*int*/ static DefaultCapacity = 4;
            //--TRIMMABLE-BOUNDARY-END(90196344845)
            
            //--TRIMMABLE-BOUNDARY-START(30066802701)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066802701);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.keys = $.$$.System.Array.Empty(TKey);
                    this.values = $.$$.System.Array.Empty(TValue);
                    this._size = 0;
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30066802701)
            
            //--TRIMMABLE-BOUNDARY-START(51541639181)
            $ctor$6(/*int*/ capacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51541639181);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    this.keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [capacity], null);
                    this.values = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [capacity], null);
                    this.comparer = $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51541639181)
            
            //--TRIMMABLE-BOUNDARY-START(34361769997)
            $ctor$2(/*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361769997);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (comparer !== null)
                    {
                        this.comparer = comparer;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361769997)
            
            //--TRIMMABLE-BOUNDARY-START(47246671885)
            $ctor$5(/*int*/ capacity, /*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$2(comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246671885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Capacity = capacity;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246671885)
            
            //--TRIMMABLE-BOUNDARY-START(42951704589)
            $ctor$4(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$3(dictionary, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951704589);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951704589)
            
            //--TRIMMABLE-BOUNDARY-START(38656737293)
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary, /*IComparer<TKey>?*/ comparer)
            {
                this.$ctor$5($.$firstOf((dictionary?.System$Collections$Generic$ICollection$$$Count ?? null), () => { throw new $.$$.System.ArgumentNullException().$ctor$19("dictionary") }), comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656737293);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*int*/ let count = dictionary.System$Collections$Generic$ICollection$$$Count;
                    if (count !== 0)
                    {
                        /*TKey[]*/ let keys = this.keys;
                        dictionary.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$ICollection$$$CopyTo(keys, 0, [TKey]);
                        dictionary.System$Collections$Generic$IDictionary$$$$Values.System$Collections$Generic$ICollection$$$CopyTo(this.values, 0, [TValue]);
                        $.$$.System.Diagnostics.Debug.Assert$2(count === this.keys.length, "count == this.keys.Length");
                        if (count > 1)
                        {
                            comparer = this.Comparer;
                            $.$$.System.Array.Sort$13(TKey, TValue, keys, this.values, comparer);
                            for(/*int*/ let i = 1; i < keys.length; ++i)
                            {
                                if (comparer.System$Collections$Generic$IComparer$$$Compare($.$$.System.Array.$ReadT1.call(keys, ((i - 1) | 0)), $.$$.System.Array.$ReadT1.call(keys, i), [TKey]) === 0)
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box($.$$.System.Array.$ReadT1.call(keys, i), TKey)));
                                }
                            }
                        }
                    }
                    this._size = count;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656737293)
            
            //--TRIMMABLE-BOUNDARY-START(55836606477)
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836606477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(key, TKey)), "key");
                }
                this.Insert(~i, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(55836606477)
            
            //--TRIMMABLE-BOUNDARY-START(231930265613)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231930265613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Add(keyValuePair.Key, keyValuePair.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(231930265613)
            
            //--TRIMMABLE-BOUNDARY-START(236225232909)
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225232909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = this.IndexOfKey(keyValuePair.Key);
                if (index >= 0 && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2($.$$.System.Array.$ReadT1.call(this.values, index), keyValuePair.Value))
                {
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(236225232909)
            
            //--TRIMMABLE-BOUNDARY-START(257700069389)
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700069389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = this.IndexOfKey(keyValuePair.Key);
                if (index >= 0 && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2($.$$.System.Array.$ReadT1.call(this.values, index), keyValuePair.Value))
                {
                    this.RemoveAt(index);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(257700069389)
            
            //--TRIMMABLE-BOUNDARY-START(60131573773)
            /*int */ get Capacity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103081246733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.keys.length;
            }
            /*int */ set Capacity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750396429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value !== this.keys.length)
                {
                    if (value < this._size)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("value", $.$box(value, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_SmallCapacity);
                    }
                    if (value > 0)
                    {
                        /*TKey[]*/ let newKeys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [value], null);
                        /*TValue[]*/ let newValues = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TValue), null, [value], null);
                        if (this._size > 0)
                        {
                            $.$$.System.Array.Copy(this.keys, newKeys, this._size);
                            $.$$.System.Array.Copy(this.values, newValues, this._size);
                        }
                        this.keys = newKeys;
                        this.values = newValues;
                    }
                    else 
                    {
                        this.keys = $.$$.System.Array.Empty(TKey);
                        this.values = $.$$.System.Array.Empty(TValue);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131573773)
            
            //--TRIMMABLE-BOUNDARY-START(73016475661)
            /*IComparer<TKey> */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111671181325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.comparer;
            }
            //--TRIMMABLE-BOUNDARY-END(73016475661)
            
            //--TRIMMABLE-BOUNDARY-START(347894382605)
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347894382605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                if (!($.$is(key, TKey)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                if (!($.$is(value, TValue)) && value !== null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                }
                this.Add($.$cast(key, TKey), $.$cast(value, TValue));
            }
            //--TRIMMABLE-BOUNDARY-END(347894382605)
            
            //--TRIMMABLE-BOUNDARY-START(85901377549)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120261115917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._size;
            }
            //--TRIMMABLE-BOUNDARY-END(85901377549)
            
            //--TRIMMABLE-BOUNDARY-START(197570527245)
            /*IList<TKey> */ get Keys$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440985101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(197570527245)
            
            //--TRIMMABLE-BOUNDARY-START(279174905869)
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266290003981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(279174905869)
            
            //--TRIMMABLE-BOUNDARY-START(412318892045)
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549088269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(412318892045)
            
            //--TRIMMABLE-BOUNDARY-START(309239676941)
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354775053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetKeyListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(309239676941)
            
            //--TRIMMABLE-BOUNDARY-START(463858499597)
            /*IList<TValue> */ get Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030919693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(463858499597)
            
            //--TRIMMABLE-BOUNDARY-START(283469873165)
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879938573);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(283469873165)
            
            //--TRIMMABLE-BOUNDARY-START(433793728525)
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395139022861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(433793728525)
            
            //--TRIMMABLE-BOUNDARY-START(313534644237)
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944709645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetValueListHelper();
            }
            //--TRIMMABLE-BOUNDARY-END(313534644237)
            
            //--TRIMMABLE-BOUNDARY-START(158915821581)
            /*KeyList */ GetKeyListHelper()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158915821581);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.keyList ??= new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).KeyList)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158915821581)
            
            //--TRIMMABLE-BOUNDARY-START(167505756173)
            /*ValueList */ GetValueListHelper()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167505756173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.valueList ??= new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).ValueList)().$ctor$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167505756173)
            
            //--TRIMMABLE-BOUNDARY-START(253405102093)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249110134797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(253405102093)
            
            //--TRIMMABLE-BOUNDARY-START(408023924749)
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369369219085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(408023924749)
            
            //--TRIMMABLE-BOUNDARY-START(403728957453)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360779284493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(403728957453)
            
            //--TRIMMABLE-BOUNDARY-START(339304448013)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326419546125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(339304448013)
            
            //--TRIMMABLE-BOUNDARY-START(343599415309)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(343599415309)
            
            //--TRIMMABLE-BOUNDARY-START(64426541069)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426541069);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.version++;
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TKey>()) { ... }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TValue>()) { ... }
                this._size = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(64426541069)
            
            //--TRIMMABLE-BOUNDARY-START(352189349901)
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352189349901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    return this.ContainsKey($.$cast(key, TKey));
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(352189349901)
            
            //--TRIMMABLE-BOUNDARY-START(77311442957)
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311442957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfKey(key) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77311442957)
            
            //--TRIMMABLE-BOUNDARY-START(81606410253)
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606410253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IndexOfValue(value) >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(81606410253)
            
            //--TRIMMABLE-BOUNDARY-START(240520200205)
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240520200205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if (arrayIndex < 0 || arrayIndex > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("arrayIndex", $.$box(arrayIndex, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - arrayIndex) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this.Count; i++)
                {
                    /*KeyValuePair<TKey, TValue>*/ let entry = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i));
                    $.$$.System.Array.$WriteT1.call(array, entry, ((arrayIndex + i) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240520200205)
            
            //--TRIMMABLE-BOUNDARY-START(317829611533)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317829611533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                if (index < 0 || index > array.length)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLessOrEqual);
                }
                if (((array.length - index) | 0) < this.Count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                let keyValuePairArray;
                if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ keyValuePairArray = v; } }))
                {
                    for(/*int*/ let i = 0; i < this.Count; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(keyValuePairArray, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i)), ((i + index) | 0));
                    }
                }
                else 
                {
                    /*object[]?*/ let objects = $.$as(array, $.$typeArray($.$$.System.Object));
                    if (objects === null)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                    try
                    {
                        for(/*int*/ let i = 0; i < this.Count; i++)
                        {
                            $.$$.System.Array.$WriteT1.call(objects, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3($.$$.System.Array.$ReadT1.call(this.keys, i), $.$$.System.Array.$ReadT1.call(this.values, i)), ((i + index) | 0));
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317829611533)
            
            //--TRIMMABLE-BOUNDARY-START(94491312141)
            /*void */ EnsureCapacity(/*int*/ min)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491312141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let newCapacity = this.keys.length === 0 ? 4/*DefaultCapacity*/ : ((this.keys.length * 2) | 0);
                if (BigInt((newCapacity >>> 0)) > BigInt($.$$.System.Array.MaxLength))
                {
                    newCapacity = $.$$.System.Array.MaxLength;
                }
                if (newCapacity < min)
                {
                    newCapacity = min;
                }
                this.Capacity = newCapacity;
            }
            //--TRIMMABLE-BOUNDARY-END(94491312141)
            
            //--TRIMMABLE-BOUNDARY-START(163210788877)
            /*TValue */ GetValueAtIndex(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210788877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.values, index);
            }
            //--TRIMMABLE-BOUNDARY-END(163210788877)
            
            //--TRIMMABLE-BOUNDARY-START(227635298317)
            /*void */ SetValueAtIndex(/*int*/ index, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635298317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(227635298317)
            
            //--TRIMMABLE-BOUNDARY-START(150325886989)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150325886989);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).Enumerator)().$ctor$3(this, 1/*Enumerator.KeyValuePair*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325886989)
            
            //--TRIMMABLE-BOUNDARY-START(287764840461)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287764840461);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287764840461)
            
            //--TRIMMABLE-BOUNDARY-START(399433990157)
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399433990157);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).Enumerator)().$ctor$3(this, 2/*Enumerator.DictEntry*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(399433990157)
            
            //--TRIMMABLE-BOUNDARY-START(438088695821)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(438088695821);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438088695821)
            
            //--TRIMMABLE-BOUNDARY-START(154620854285)
            /*TKey */ GetKeyAtIndex(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620854285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                return $.$$.System.Array.$ReadT1.call(this.keys, index);
            }
            //--TRIMMABLE-BOUNDARY-END(154620854285)
            
            //--TRIMMABLE-BOUNDARY-START(442383663117)
            /*TValue*/ get_Item$1(/*TKey*/ key)
            {
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    return $.$$.System.Array.$ReadT1.call(this.values, i);
                }
                throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
            }
            /*void*/ set_Item$1(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                if (i >= 0)
                {
                    $.$$.System.Array.$WriteT1.call(this.values, value, i);
                    this.version++;
                    return;
                }
                this.Insert(~i, key, value);
            }
            //--TRIMMABLE-BOUNDARY-END(442383663117)
            
            //--TRIMMABLE-BOUNDARY-START(429498761229)
            //--TRIMMABLE-BOUNDARY-START(90256834561)
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    /*int*/ let i = this.IndexOfKey($.$cast(key, TKey));
                    if (i >= 0)
                    {
                        return $.$box($.$$.System.Array.$ReadT1.call(this.values, i), TValue);
                    }
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                if (!$.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("key");
                }
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                /*TKey*/ let tempKey = $.$cast(key, TKey);
                try
                {
                    this.set_Item$1(tempKey, $.$cast(value, TValue));
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90256834561)
            
            //--TRIMMABLE-BOUNDARY-END(429498761229)
            
            //--TRIMMABLE-BOUNDARY-START(171800723469)
            /*int */ IndexOfKey(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800723469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let ret = $.$$.System.Array.BinarySearch$4(TKey, this.keys, 0, this._size, key, this.comparer);
                return ret >= 0 ? ret : -1;
            }
            //--TRIMMABLE-BOUNDARY-END(171800723469)
            
            //--TRIMMABLE-BOUNDARY-START(176095690765)
            /*int */ IndexOfValue(/*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095690765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.IndexOf$3(TValue, this.values, value, 0, this._size);
            }
            //--TRIMMABLE-BOUNDARY-END(176095690765)
            
            //--TRIMMABLE-BOUNDARY-START(180390658061)
            /*void */ Insert(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390658061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._size === this.keys.length)
                {
                    this.EnsureCapacity(((this._size + 1) | 0));
                }
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, index, this.keys, ((index + 1) | 0), ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, index, this.values, ((index + 1) | 0), ((this._size - index) | 0));
                }
                $.$$.System.Array.$WriteT1.call(this.keys, key, index);
                $.$$.System.Array.$WriteT1.call(this.values, value, index);
                this._size++;
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(180390658061)
            
            //--TRIMMABLE-BOUNDARY-START(450973597709)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450973597709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    value.$v = $.$$.System.Array.$ReadT1.call(this.values, i);
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(450973597709)
            
            //--TRIMMABLE-BOUNDARY-START(206160461837)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160461837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (index < 0 || index >= this._size)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("index", $.$box(index, $.$$.System.Int32), $.$sc.System.SR.ArgumentOutOfRange_IndexMustBeLess);
                }
                this._size--;
                if (index < this._size)
                {
                    $.$$.System.Array.Copy$2(this.keys, ((index + 1) | 0), this.keys, index, ((this._size - index) | 0));
                    $.$$.System.Array.Copy$2(this.values, ((index + 1) | 0), this.values, index, ((this._size - index) | 0));
                }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TKey>()) { ... }
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<TValue>()) { ... }
                this.version++;
            }
            //--TRIMMABLE-BOUNDARY-END(206160461837)
            
            //--TRIMMABLE-BOUNDARY-START(201865494541)
            /*bool */ Remove(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865494541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let i = this.IndexOfKey(key);
                if (i >= 0)
                {
                    this.RemoveAt(i);
                }
                return i >= 0;
            }
            //--TRIMMABLE-BOUNDARY-END(201865494541)
            
            //--TRIMMABLE-BOUNDARY-START(416613859341)
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416613859341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    this.Remove($.$cast(key, TKey));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416613859341)
            
            //--TRIMMABLE-BOUNDARY-START(446678630413)
            /*void */ TrimExcess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446678630413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let threshold = $.$cast((this.keys.length * 0.9), $.$$.System.Int32);
                if (this._size < threshold)
                {
                    this.Capacity = this._size;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(446678630413)
            
            //--TRIMMABLE-BOUNDARY-START(184685625357)
            static /*bool */ IsCompatibleKey(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685625357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return ($.$is(key, TKey));
            }
            //--TRIMMABLE-BOUNDARY-END(184685625357)
            
            //--TRIMMABLE-BOUNDARY-START(2097165)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedList$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17181966349)
                    /*SortedList<TKey, TValue>*/  get _sortedList() { return this.$getField(0, 4); }
                    /*SortedList<TKey, TValue>*/  set _sortedList(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17181966349)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886999053)
                    /*TKey?*/  get _key() { return this.$getField(4, 4); }
                    /*TKey?*/  set _key(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12886999053)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476933645)
                    /*TValue?*/  get _value() { return this.$getField(8, 4); }
                    /*TValue?*/  set _value(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21476933645)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592031757)
                    /*int*/  get _index() { return this.$getField(12, 4); }
                    /*int*/  set _index(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8592031757)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771900941)
                    /*int*/  get _version() { return this.$getField(16, 4); }
                    /*int*/  set _version(value) { this.$setField(16, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(25771900941)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297064461)
                    /*int*/  get _getEnumeratorRetType() { return this.$getField(20, 4); }
                    /*int*/  set _getEnumeratorRetType(value) { this.$setField(20, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4297064461)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131639309)
                    /*int*/ static KeyValuePair = 1;
                    //--TRIMMABLE-BOUNDARY-END(60131639309)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951770125)
                    /*int*/ static DictEntry = 2;
                    //--TRIMMABLE-BOUNDARY-END(42951770125)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361835533)
                    $ctor$3(/*SortedList<TKey, TValue>*/ sortedList, /*int*/ getEnumeratorRetType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361835533);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sortedList = sortedList;
                            this._index = 0;
                            this._version = this._sortedList.version;
                            this._getEnumeratorRetType = getEnumeratorRetType;
                            this._key = $.$default(TKey);
                            this._value = $.$default(TValue);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361835533)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246737421)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246737421);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._index = 0;
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246737421)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786344973)
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85901443085);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box($.$box(this._key, TKey), TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786344973)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426606605)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426606605);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._key = $.$$.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._value = $.$$.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426606605)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721573901)
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311508493);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box($.$box(this._key, TKey), TKey), $.$box(this._value, TValue));
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721573901)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656802829)
                    /*KeyValuePair<TKey, TValue> */ get Current()
                    {
                        return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(this._key, this._value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656802829)
                    
                    //--TRIMMABLE-BOUNDARY-START(107376279565)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115966214157);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getEnumeratorRetType === 2/*DictEntry*/)
                        {
                            return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box($.$box(this._key, TKey), TKey), $.$box(this._value, TValue));
                        }
                        else 
                        {
                            return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(this._key, this._value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(107376279565)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081312269)
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491377677);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._value, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(103081312269)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261181453)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120261181453);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._key = $.$default(TKey);
                        this._value = $.$default(TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(120261181453)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066868237)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066868237)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._sortedList = this._sortedList;
                        copy._key = this._key;
                        copy._value = this._value;
                        copy._index = this._index;
                        copy._version = this._version;
                        copy._getEnumeratorRetType = this._getEnumeratorRetType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17181966349)
                        this._sortedList = null;
                        //--TRIMMABLE-BOUNDARY-END(17181966349)
                        
                        //--TRIMMABLE-BOUNDARY-START(12886999053)
                        this._key = null;
                        //--TRIMMABLE-BOUNDARY-END(12886999053)
                        
                        //--TRIMMABLE-BOUNDARY-START(21476933645)
                        this._value = null;
                        //--TRIMMABLE-BOUNDARY-END(21476933645)
                        
                        //--TRIMMABLE-BOUNDARY-START(8592031757)
                        this._index = 0;
                        //--TRIMMABLE-BOUNDARY-END(8592031757)
                        
                        //--TRIMMABLE-BOUNDARY-START(25771900941)
                        this._version = 0;
                        //--TRIMMABLE-BOUNDARY-END(25771900941)
                        
                        //--TRIMMABLE-BOUNDARY-START(4297064461)
                        this._getEnumeratorRetType = 0;
                        //--TRIMMABLE-BOUNDARY-END(4297064461)
                        
                    }
                    static $h = 2097165;
                    static $z = 24;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,
  "h": 2097165
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2097165)
            
            //--TRIMMABLE-BOUNDARY-START(2228237)
            static $_SortedListKeyEnumerator;
            static get SortedListKeyEnumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_SortedListKeyEnumerator ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.SortedListKeyEnumerator", ($self) => class SortedListKeyEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12887130125)
                    /*SortedList<TKey, TValue>*/ _sortedList = null;
                    //--TRIMMABLE-BOUNDARY-END(12887130125)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592162829)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592162829)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182097421)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(17182097421)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297195533)
                    /*TKey?*/ _currentKey = null;
                    //--TRIMMABLE-BOUNDARY-END(4297195533)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477064717)
                    $ctor$1(/*SortedList<TKey, TValue>*/ sortedList)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477064717);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sortedList = sortedList;
                            this._version = sortedList.version;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477064717)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066999309)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066999309);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._index = 0;
                        this._currentKey = $.$default(TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066999309)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951901197)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951901197);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._currentKey = $.$$.System.Array.$ReadT1.call(this._sortedList.keys, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._currentKey = $.$default(TKey);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951901197)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772032013)
                    /*TKey */ get Current()
                    {
                        return this._currentKey;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772032013)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246868493)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836803085);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._currentKey, TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246868493)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131770381)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60131770381);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._currentKey = $.$default(TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131770381)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    static $h = 2228237;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,
  "h": 2228237
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.SortedListKeyEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListKeyEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2228237)
            
            //--TRIMMABLE-BOUNDARY-START(2293773)
            static $_SortedListValueEnumerator;
            static get SortedListValueEnumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_SortedListValueEnumerator ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.SortedListValueEnumerator", ($self) => class SortedListValueEnumerator extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12887195661)
                    /*SortedList<TKey, TValue>*/ _sortedList = null;
                    //--TRIMMABLE-BOUNDARY-END(12887195661)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592228365)
                    /*int*/ _index = 0;
                    //--TRIMMABLE-BOUNDARY-END(8592228365)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182162957)
                    /*int*/ _version = 0;
                    //--TRIMMABLE-BOUNDARY-END(17182162957)
                    
                    //--TRIMMABLE-BOUNDARY-START(4297261069)
                    /*TValue?*/ _currentValue = null;
                    //--TRIMMABLE-BOUNDARY-END(4297261069)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477130253)
                    $ctor$1(/*SortedList<TKey, TValue>*/ sortedList)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477130253);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._sortedList = sortedList;
                            this._version = sortedList.version;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477130253)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067064845)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30067064845);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._index = 0;
                        this._currentValue = $.$default(TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067064845)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951966733)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951966733);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        if ((this._index >>> 0) < (this._sortedList.Count >>> 0))
                        {
                            this._currentValue = $.$$.System.Array.$ReadT1.call(this._sortedList.values, this._index);
                            this._index++;
                            return true;
                        }
                        this._index = ((this._sortedList.Count + 1) | 0);
                        this._currentValue = $.$default(TValue);
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951966733)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772097549)
                    /*TValue */ get Current()
                    {
                        return this._currentValue;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772097549)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246934029)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836868621);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._index === 0 || (this._index === ((this._sortedList.Count + 1) | 0)))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this._currentValue, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246934029)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131835917)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60131835917);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._sortedList.version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        this._index = 0;
                        this._currentValue = $.$default(TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131835917)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    static $h = 2293773;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,
  "h": 2293773
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.SortedListValueEnumerator`; }
                }, $cls, ($v) => $cls.$_SortedListValueEnumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2293773)
            
            //--TRIMMABLE-BOUNDARY-START(2162701)
            static $_KeyList;
            static get KeyList()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_KeyList ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.KeyList", ($self) => class KeyList extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4297129997)
                    /*SortedList<TKey, TValue>*/ _dict = null;
                    //--TRIMMABLE-BOUNDARY-END(4297129997)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592097293)
                    $ctor$1(/*SortedList<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592097293);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._dict = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592097293)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066933773)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656868365);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dict._size;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066933773)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016606733)
                    /*bool */ get IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246802957);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016606733)
                    
                    //--TRIMMABLE-BOUNDARY-START(115966279693)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103081377805);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115966279693)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261246989)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111671312397);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this._dict).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120261246989)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887064589)
                    /*void */ Add(/*TKey*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887064589);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887064589)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182031885)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182031885);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182031885)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476999181)
                    /*bool */ Contains(/*TKey*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476999181);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dict.ContainsKey(key);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476999181)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771966477)
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771966477);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Array.Copy$2(this._dict.keys, 0, array, arrayIndex, this._dict.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771966477)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491443213)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491443213);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._dict.keys, 0, array, arrayIndex, this._dict.Count);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491443213)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721639437)
                    /*void */ Insert(/*int*/ index, /*TKey*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68721639437);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721639437)
                    
                    //--TRIMMABLE-BOUNDARY-START(128851181581)
                    /*TKey*/ get_Item$1(/*int*/ index)
                    {
                        return this._dict.GetKeyAtIndex(index);
                    }
                    /*void*/ set_Item$1(/*int*/ index, /*TKey*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(128851181581)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131704845)
                    /*IEnumerator<TKey> */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60131704845);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).SortedListKeyEnumerator)().$ctor$1(this._dict);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131704845)
                    
                    //--TRIMMABLE-BOUNDARY-START(124556214285)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(124556214285);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(124556214285)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426672141)
                    /*int */ IndexOf(/*TKey*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426672141);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                        /*int*/ let i = $.$$.System.Array.BinarySearch$4(TKey, this._dict.keys, 0, this._dict.Count, key, this._dict.comparer);
                        if (i >= 0)
                        {
                            return i;
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426672141)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311574029)
                    /*bool */ Remove(/*TKey*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311574029);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311574029)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606541325)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81606541325);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606541325)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649834497)
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649834497);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649834497)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124670977)
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30124670977);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124670977)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944801793)
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.IndexOf(TKey)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944801793);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IndexOf(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944801793)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239769089)
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.Insert(int, TKey)
                    System$Collections$Generic$IList$$$Insert()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239769089);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Insert(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239769089)
                    
                    //--TRIMMABLE-BOUNDARY-START(21534736385)
                    //Generated interface implemetation for System.Collections.Generic.IList<TKey>.RemoveAt(int)
                    System$Collections$Generic$IList$$$RemoveAt()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534736385);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveAt(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21534736385)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(38714015745)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43008983041);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38714015745)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354277377)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Add(TKey)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354277377);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354277377)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649244673)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649244673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649244673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944211969)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944211969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944211969)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(47303950337)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Remove(TKey)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47303950337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47303950337)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TKey>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    static $h = 2162701;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,
  "h": 2162701
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TKey), $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.KeyList`; }
                }, $cls, ($v) => $cls.$_KeyList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2162701)
            
            //--TRIMMABLE-BOUNDARY-START(2359309)
            static $_ValueList;
            static get ValueList()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue);
                return $cls.$_ValueList ??= $asm.$ncls("$sc.System.Collections.Generic.SortedList$$$.ValueList", ($self) => class ValueList extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4297326605)
                    /*SortedList<TKey, TValue>*/ _dict = null;
                    //--TRIMMABLE-BOUNDARY-END(4297326605)
                    
                    //--TRIMMABLE-BOUNDARY-START(8592293901)
                    $ctor$1(/*SortedList<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8592293901);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._dict = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8592293901)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067130381)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38657064973);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dict._size;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067130381)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016803341)
                    /*bool */ get IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246999565);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016803341)
                    
                    //--TRIMMABLE-BOUNDARY-START(115966476301)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(103081574413);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(115966476301)
                    
                    //--TRIMMABLE-BOUNDARY-START(120261443597)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111671509005);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this._dict).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(120261443597)
                    
                    //--TRIMMABLE-BOUNDARY-START(12887261197)
                    /*void */ Add(/*TValue*/ key)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12887261197);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12887261197)
                    
                    //--TRIMMABLE-BOUNDARY-START(17182228493)
                    /*void */ Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17182228493);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17182228493)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477195789)
                    /*bool */ Contains(/*TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21477195789);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dict.ContainsValue(value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477195789)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772163085)
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772163085);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.Array.Copy$2(this._dict.values, 0, array, arrayIndex, this._dict.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772163085)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491639821)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94491639821);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (array !== null && $.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        try
                        {
                            $.$$.System.Array.Copy$2(this._dict.values, 0, array, index, this._dict.Count);
                        }
                        catch($e)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491639821)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721836045)
                    /*void */ Insert(/*int*/ index, /*TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(68721836045);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721836045)
                    
                    //--TRIMMABLE-BOUNDARY-START(128851378189)
                    /*TValue*/ get_Item$1(/*int*/ index)
                    {
                        return this._dict.GetValueAtIndex(index);
                    }
                    /*void*/ set_Item$1(/*int*/ index, /*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(128851378189)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131901453)
                    /*IEnumerator<TValue> */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(60131901453);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : new ($.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).SortedListValueEnumerator)().$ctor$1(this._dict);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131901453)
                    
                    //--TRIMMABLE-BOUNDARY-START(124556410893)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(124556410893);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(124556410893)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426868749)
                    /*int */ IndexOf(/*TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426868749);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.Array.IndexOf$3(TValue, this._dict.values, value, 0, this._dict.Count);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426868749)
                    
                    //--TRIMMABLE-BOUNDARY-START(77311770637)
                    /*bool */ Remove(/*TValue*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311770637);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(77311770637)
                    
                    //--TRIMMABLE-BOUNDARY-START(81606737933)
                    /*void */ RemoveAt(/*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81606737933);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_SortedListNestedWrite);
                    }
                    //--TRIMMABLE-BOUNDARY-END(81606737933)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649834497)
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649834497);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.get_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649834497)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124670977)
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30124670977);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.set_Item$1(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124670977)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944801793)
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.IndexOf(TValue)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944801793);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IndexOf(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944801793)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239769089)
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.Insert(int, TValue)
                    System$Collections$Generic$IList$$$Insert()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239769089);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Insert(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239769089)
                    
                    //--TRIMMABLE-BOUNDARY-START(21534736385)
                    //Generated interface implemetation for System.Collections.Generic.IList<TValue>.RemoveAt(int)
                    System$Collections$Generic$IList$$$RemoveAt()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534736385);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.RemoveAt(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21534736385)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(38714015745)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(43008983041);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.IsReadOnly;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38714015745)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354277377)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Add(TValue)
                    System$Collections$Generic$ICollection$$$Add()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354277377);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Add(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354277377)
                    
                    //--TRIMMABLE-BOUNDARY-START(8649244673)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Clear()
                    System$Collections$Generic$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8649244673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Clear(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8649244673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944211969)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Contains(TValue)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944211969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944211969)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(47303950337)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Remove(TValue)
                    System$Collections$Generic$ICollection$$$Remove()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47303950337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Remove(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47303950337)
                    
                    //--TRIMMABLE-BOUNDARY-START(4354605057)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerable<TValue>.GetEnumerator()
                    System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354605057);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.GetEnumerator(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4354605057)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    static $h = 2359309;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedList$$$(TKey, TValue).$h,
  "h": 2359309
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TValue), $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>.ValueList`; }
                }, $cls, ($v) => $cls.$_ValueList = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(2359309)
            
            //--TRIMMABLE-BOUNDARY-START(17239375873)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239375873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239375873)
            
            //--TRIMMABLE-BOUNDARY-START(51599114241)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51599114241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51599114241)
            
            //--TRIMMABLE-BOUNDARY-START(8649441281)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649441281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649441281)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            //--TRIMMABLE-BOUNDARY-START(43009179649)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009179649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009179649)
            
            //--TRIMMABLE-BOUNDARY-START(60189048833)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60189048833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60189048833)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(8652455937)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652455937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652455937)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(4355063809)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355063809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355063809)
            
            //--TRIMMABLE-BOUNDARY-START(43009769473)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009769473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009769473)
            
            //--TRIMMABLE-BOUNDARY-START(12944998401)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944998401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944998401)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            static $h = 2031629;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.SortedList<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(2031629)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572877)
        $asm.$cls("$sc.System.Collections.Generic.SortedDictionary<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.SortedDictionary<,>", [TKey, TValue], ($self) => class SortedDictionary$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296540173)
            /*KeyCollection?*/ _keys = null;
            //--TRIMMABLE-BOUNDARY-END(4296540173)
            
            //--TRIMMABLE-BOUNDARY-START(12886474765)
            /*ValueCollection?*/ _values = null;
            //--TRIMMABLE-BOUNDARY-END(12886474765)
            
            //--TRIMMABLE-BOUNDARY-START(8591507469)
            /*TreeSet<KeyValuePair<TKey, TValue>>*/ _set = null;
            //--TRIMMABLE-BOUNDARY-END(8591507469)
            
            //--TRIMMABLE-BOUNDARY-START(34361311245)
            $ctor$1()
            {
                this.$ctor$2(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361311245);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361311245)
            
            //--TRIMMABLE-BOUNDARY-START(47246213133)
            $ctor$4(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$3(dictionary, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246213133);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246213133)
            
            //--TRIMMABLE-BOUNDARY-START(42951245837)
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary, /*IComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951245837);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                    /*var*/ let keyValuePairComparer = new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)().$ctor$2(comparer);
                    let sortedDictionary;
                    let kv;
                    if ($.$is(dictionary, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue), { set $v(v){ sortedDictionary = v; } }) && $.$is(sortedDictionary._set.Comparer, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer, { set $v(v){ kv = v; } }) && $.$$.System.Object.Equals$1.call(kv.keyComparer, keyValuePairComparer.keyComparer))
                    {
                        this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$9(sortedDictionary._set, keyValuePairComparer);
                    }
                    else 
                    {
                        this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$7(keyValuePairComparer);
                        var $en4 = dictionary.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var pair = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                this._set.Add(pair);
                            }
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951245837)
            
            //--TRIMMABLE-BOUNDARY-START(38656278541)
            $ctor$2(/*IComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656278541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._set = new ($.$sc.System.Collections.Generic.TreeSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor$7(new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)().$ctor$2(comparer));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656278541)
            
            //--TRIMMABLE-BOUNDARY-START(150325428237)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325428237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._set.Add(keyValuePair);
            }
            //--TRIMMABLE-BOUNDARY-END(150325428237)
            
            //--TRIMMABLE-BOUNDARY-START(154620395533)
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620395533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(keyValuePair);
                if (node === null)
                {
                    return false;
                }
                if ($.$box(keyValuePair.Value, TValue) === null)
                {
                    return $.$box(node.Item$1.Value, TValue) === null;
                }
                else 
                {
                    return $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(node.Item$1.Value, keyValuePair.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154620395533)
            
            //--TRIMMABLE-BOUNDARY-START(171800264717)
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ keyValuePair)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800264717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(keyValuePair);
                if (node === null)
                {
                    return false;
                }
                if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(node.Item$1.Value, keyValuePair.Value))
                {
                    this._set.Remove(keyValuePair);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(171800264717)
            
            //--TRIMMABLE-BOUNDARY-START(167505297421)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210330125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(167505297421)
            
            //--TRIMMABLE-BOUNDARY-START(356483858445)
            /*TValue*/ get_Item$1(/*TKey*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    throw new $.$$.System.Collections.Generic.KeyNotFoundException().$ctor$12($.$sc.System.SR.Format$6($.$sc.System.SR.Arg_KeyNotFoundWithKey, $.$$.System.Object.ToString.call(key)));
                }
                return node.Item$1.Value;
            }
            /*void*/ set_Item$1(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    this._set.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, value));
                }
                else 
                {
                    node.Item$1 = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(node.Item$1.Key, value);
                    this._set.UpdateVersion();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(356483858445)
            
            //--TRIMMABLE-BOUNDARY-START(77310984205)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490853389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._set.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(77310984205)
            
            //--TRIMMABLE-BOUNDARY-START(60131115021)
            /*IComparer<TKey> */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900918797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return ($.$cast(this._set.Comparer, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer)).keyComparer;
            }
            //--TRIMMABLE-BOUNDARY-END(60131115021)
            
            //--TRIMMABLE-BOUNDARY-START(133145559053)
            /*KeyCollection */ get Keys$1()
            {
                return this._keys ??= new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection)().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(133145559053)
            
            //--TRIMMABLE-BOUNDARY-START(193275101197)
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390199309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(193275101197)
            
            //--TRIMMABLE-BOUNDARY-START(223339872269)
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454970381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(223339872269)
            
            //--TRIMMABLE-BOUNDARY-START(365073793037)
            /*ValueCollection */ get Values()
            {
                return this._values ??= new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection)().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(365073793037)
            
            //--TRIMMABLE-BOUNDARY-START(197570068493)
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980133901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(197570068493)
            
            //--TRIMMABLE-BOUNDARY-START(227634839565)
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044904973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(227634839565)
            
            //--TRIMMABLE-BOUNDARY-START(51541180429)
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this._set.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, value));
            }
            //--TRIMMABLE-BOUNDARY-END(51541180429)
            
            //--TRIMMABLE-BOUNDARY-START(55836147725)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836147725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._set.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(55836147725)
            
            //--TRIMMABLE-BOUNDARY-START(64426082317)
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426082317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this._set.Contains(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
            }
            //--TRIMMABLE-BOUNDARY-END(64426082317)
            
            //--TRIMMABLE-BOUNDARY-START(68721049613)
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721049613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let found = false;
                if ($.$box(value, TValue) === null)
                {
                    this._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                    {
                        if ($.$box(node.Item$1.Value, TValue) === null)
                        {
                            found = true;
                            return false;
                        }
                        return true;
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }
                else 
                {
                    /*EqualityComparer<TValue>*/ let valueComparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                    this._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                    {
                        if (valueComparer.Equals$2(node.Item$1.Value, value))
                        {
                            found = true;
                            return false;
                        }
                        return true;
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                }
                return found;
            }
            //--TRIMMABLE-BOUNDARY-END(68721049613)
            
            //--TRIMMABLE-BOUNDARY-START(73016016909)
            /*void */ CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016016909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._set.CopyTo$1(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(73016016909)
            
            //--TRIMMABLE-BOUNDARY-START(124555624461)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124555624461);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, 1/*Enumerator.KeyValuePair*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555624461)
            
            //--TRIMMABLE-BOUNDARY-START(201865035789)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201865035789);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this._set.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201865035789)
            
            //--TRIMMABLE-BOUNDARY-START(137440526349)
            /*bool */ Remove(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440526349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this._set.Remove(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
            }
            //--TRIMMABLE-BOUNDARY-END(137440526349)
            
            //--TRIMMABLE-BOUNDARY-START(360778825741)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778825741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*TreeSet<KeyValuePair<TKey, TValue>>.Node?*/ let node = this._set.FindNode(new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(key, $.$default(TValue)));
                if (node === null)
                {
                    value.$v = $.$default(TValue);
                    return false;
                }
                value.$v = node.Item$1.Value;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(360778825741)
            
            //--TRIMMABLE-BOUNDARY-START(231929806861)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929806861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this._set).System$Collections$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(231929806861)
            
            //--TRIMMABLE-BOUNDARY-START(317829152781)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879479821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(317829152781)
            
            //--TRIMMABLE-BOUNDARY-START(322124120077)
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469414413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(322124120077)
            
            //--TRIMMABLE-BOUNDARY-START(326419087373)
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649283597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(326419087373)
            
            //--TRIMMABLE-BOUNDARY-START(347893923853)
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239218189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(347893923853)
            
            //--TRIMMABLE-BOUNDARY-START(343598956557)
            //--TRIMMABLE-BOUNDARY-START(90256834561)
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    /*TValue?*/ let value;
                    if (this.TryGetValue($.$cast(key, TKey), $.$ref(() => value, ($v) => value = $v, TValue)))
                    {
                        return $.$box(value, TValue);
                    }
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                try
                {
                    /*TKey*/ let tempKey = $.$cast(key, TKey);
                    try
                    {
                        this.set_Item$1(tempKey, $.$cast(value, TValue));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90256834561)
            
            //--TRIMMABLE-BOUNDARY-END(343598956557)
            
            //--TRIMMABLE-BOUNDARY-START(261994577933)
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994577933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if ($.$box($.$default(TValue), TValue) !== null)
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                try
                {
                    /*TKey*/ let tempKey = $.$cast(key, TKey);
                    try
                    {
                        this.Add(tempKey, $.$cast(value, TValue));
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                }
                catch($e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994577933)
            
            //--TRIMMABLE-BOUNDARY-START(266289545229)
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289545229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    return this.ContainsKey($.$cast(key, TKey));
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(266289545229)
            
            //--TRIMMABLE-BOUNDARY-START(128850591757)
            static /*bool */ IsCompatibleKey(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850591757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                return ($.$is(key, TKey));
            }
            //--TRIMMABLE-BOUNDARY-END(128850591757)
            
            //--TRIMMABLE-BOUNDARY-START(313534185485)
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(313534185485);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, 2/*Enumerator.DictEntry*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313534185485)
            
            //--TRIMMABLE-BOUNDARY-START(330714054669)
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714054669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).IsCompatibleKey(key))
                {
                    this.Remove($.$cast(key, TKey));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(330714054669)
            
            //--TRIMMABLE-BOUNDARY-START(253404643341)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519741453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(253404643341)
            
            //--TRIMMABLE-BOUNDARY-START(257699610637)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109676045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this._set).System$Collections$ICollection$SyncRoot;
            }
            //--TRIMMABLE-BOUNDARY-END(257699610637)
            
            //--TRIMMABLE-BOUNDARY-START(352188891149)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(352188891149);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352188891149)
            
            //--TRIMMABLE-BOUNDARY-START(1638413)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(8591573005)
                    /*TreeSet<KeyValuePair<TKey, TValue>>.Enumerator*/  get _treeEnum() { return this.$getField(0, 17); }
                    /*TreeSet<KeyValuePair<TKey, TValue>>.Enumerator*/  set _treeEnum(value) { this.$setField(0, 17, value); }
                    //--TRIMMABLE-BOUNDARY-END(8591573005)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296605709)
                    /*int*/  get _getEnumeratorRetType() { return this.$getField(17, 4); }
                    /*int*/  set _getEnumeratorRetType(value) { this.$setField(17, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4296605709)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541245965)
                    /*int*/ static KeyValuePair = 1;
                    //--TRIMMABLE-BOUNDARY-END(51541245965)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771442189)
                    /*int*/ static DictEntry = 2;
                    //--TRIMMABLE-BOUNDARY-END(25771442189)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181507597)
                    $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary, /*int*/ getEnumeratorRetType)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17181507597);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._treeEnum = dictionary._set.GetEnumerator();
                            this._getEnumeratorRetType = getEnumeratorRetType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181507597)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836213261)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836213261);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._treeEnum.MoveNext();
                    }
                    //--TRIMMABLE-BOUNDARY-END(55836213261)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066409485)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066409485);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._treeEnum.Dispose();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30066409485)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476474893)
                    /*KeyValuePair<TKey, TValue> */ get Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656344077);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._treeEnum.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476474893)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131180557)
                    /*bool */ get NotStartedOrEnded()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246278669);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._treeEnum.NotStartedOrEnded;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131180557)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426147853)
                    /*void */ Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426147853);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._treeEnum.Reset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426147853)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260722701)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120260722701);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._treeEnum.Reset();
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260722701)
                    
                    //--TRIMMABLE-BOUNDARY-START(107375820813)
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115965755405);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._getEnumeratorRetType === 2/*DictEntry*/)
                        {
                            return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                        }
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(107375820813)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785886221)
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(85900984333);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current.Key, TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785886221)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080853517)
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(94490918925);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return $.$box(this.Current.Value, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080853517)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721115149)
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(77311049741);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this.NotStartedOrEnded)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721115149)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385275905)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385275905);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385275905)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886540301)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886540301)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._treeEnum = this._treeEnum.Clone();
                        copy._getEnumeratorRetType = this._getEnumeratorRetType;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8591573005)
                        this._treeEnum = $.$default($.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Enumerator);
                        //--TRIMMABLE-BOUNDARY-END(8591573005)
                        
                        //--TRIMMABLE-BOUNDARY-START(4296605709)
                        this._getEnumeratorRetType = 0;
                        //--TRIMMABLE-BOUNDARY-END(4296605709)
                        
                    }
                    static $h = 1638413;
                    static $z = 21;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,
  "h": 1638413
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1638413)
            
            //--TRIMMABLE-BOUNDARY-START(1703949)
            static $_KeyCollection;
            static get KeyCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_KeyCollection ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.KeyCollection", ($self) => class KeyCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296671245)
                    /*SortedDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(4296671245)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886605837)
                    $ctor$1(/*SortedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886605837);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886605837)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656409613)
                    /*Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38656409613);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection.Enumerator)().$ctor$3(this._dictionary);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656409613)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721180685)
                    /*IEnumerator<TKey> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68721180685);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721180685)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080919053)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(103080919053);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TKey]);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103080919053)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476540429)
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476540429);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(array, node.Item$1.Key, index++);
                            return true;
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": 1703949,
  "h": 0,
  "f": 17825794
}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476540429)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016147981)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73016147981);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let keys;
                        if ($.$is(array, $.$typeArray(TKey), { set $v(v){ keys = v; } }))
                        {
                            this.CopyTo(keys, index);
                        }
                        else 
                        {
                            try
                            {
                                /*object[]*/ let objects = $.$cast(array, $.$typeArray($.$$.System.Object));
                                this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                                {
                                    $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$1.Key, TKey), index++);
                                    return true;
                                }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": 1703949,
  "h": 0,
  "f": 17825794
}));
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016147981)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771507725)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34361442317);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dictionary.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771507725)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131246093)
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836278797);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131246093)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951376909)
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TKey*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951376909);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951376909)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246344205)
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246344205);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246344205)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181573133)
                    /*bool */ Contains(/*TKey*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181573133);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dictionary.ContainsKey(item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181573133)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426213389)
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TKey*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426213389);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_KeyCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426213389)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490984461)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81606082573);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490984461)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785951757)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90196017165);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785951757)
                    
                    //--TRIMMABLE-BOUNDARY-START(1769485)
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.KeyCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296736781)
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  get _dictEnum() { return this.$getField(0, 21); }
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  set _dictEnum(value) { this.$setField(0, 21, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296736781)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886671373)
                            $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886671373);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._dictEnum = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886671373)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476605965)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476605965);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                this._dictEnum.Dispose();
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476605965)
                            
                            //--TRIMMABLE-BOUNDARY-START(34361507853)
                            /*bool */ MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(34361507853);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._dictEnum.MoveNext();
                            }
                            //--TRIMMABLE-BOUNDARY-END(34361507853)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181638669)
                            /*TKey */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30066540557);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._dictEnum.Current.Key;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181638669)
                            
                            //--TRIMMABLE-BOUNDARY-START(38656475149)
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47246409741);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._dictEnum.NotStartedOrEnded)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return $.$box(this.Current, TKey);
                            }
                            //--TRIMMABLE-BOUNDARY-END(38656475149)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541377037)
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51541377037);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                this._dictEnum.Reset();
                            }
                            //--TRIMMABLE-BOUNDARY-END(51541377037)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944605185)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354670593);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944605185)
                            
                            //--TRIMMABLE-BOUNDARY-START(4385275905)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4385275905);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4385275905)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242652673)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242652673);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242652673)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591704077)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591704077)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._dictEnum = this._dictEnum.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(4296736781)
                                this._dictEnum = $.$default($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator);
                                //--TRIMMABLE-BOUNDARY-END(4296736781)
                                
                            }
                            static $h = 1769485;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 1703949,
  "h": 1769485
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1769485)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944211969)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944211969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944211969)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TKey>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    static $h = 1703949;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,
  "h": 1703949
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection`; }
                }, $cls, ($v) => $cls.$_KeyCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1703949)
            
            //--TRIMMABLE-BOUNDARY-START(1900557)
            static $_ValueCollection;
            static get ValueCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_ValueCollection ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.ValueCollection", ($self) => class ValueCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296867853)
                    /*SortedDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(4296867853)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802445)
                    $ctor$1(/*SortedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886802445);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886802445)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361638925)
                    /*Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34361638925);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection.Enumerator)().$ctor$3(this._dictionary);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34361638925)
                    
                    //--TRIMMABLE-BOUNDARY-START(68721377293)
                    /*IEnumerator<TValue> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68721377293);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68721377293)
                    
                    //--TRIMMABLE-BOUNDARY-START(103081115661)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(103081115661);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TValue]);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(103081115661)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769741)
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181769741);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                        {
                            $.$$.System.Array.$WriteT1.call(array, node.Item$1.Value, index++);
                            return true;
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": 1900557,
  "h": 0,
  "f": 17825794
}));
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181769741)
                    
                    //--TRIMMABLE-BOUNDARY-START(73016344589)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(73016344589);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let values;
                        if ($.$is(array, $.$typeArray(TValue), { set $v(v){ values = v; } }))
                        {
                            this.CopyTo(values, index);
                        }
                        else 
                        {
                            try
                            {
                                /*object?[]*/ let objects = $.$cast(array, $.$typeArray($.$$.System.Object));
                                this._dictionary._set.InOrderTreeWalk(new ($.$sc.System.Collections.Generic.TreeWalkPredicate$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)))().$ctor(this,  (/*TreeSet<KeyValuePair<TKey, TValue>>.Node*/ node) =>
                                {
                                    $.$$.System.Array.$WriteT1.call(objects, $.$box(node.Item$1.Value, TValue), index++);
                                    return true;
                                }, {
  "r": 262145,
  "p": [
    {
      "n": "node",
      "p": $.$sc.System.Collections.Generic.SortedSet$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)).Node.$h
    }
  ],
  "n": "",
  "d": 1900557,
  "h": 0,
  "f": 17825794
}));
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(73016344589)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737037)
                    /*int */ get Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30066671629);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dictionary.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476737037)
                    
                    //--TRIMMABLE-BOUNDARY-START(60131442701)
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55836475405);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60131442701)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656606221)
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TValue*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38656606221);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38656606221)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951573517)
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42951573517);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(42951573517)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246540813)
                    /*bool */ System$Collections$Generic$ICollection$$$Contains(/*TValue*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47246540813);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._dictionary.ContainsValue(item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47246540813)
                    
                    //--TRIMMABLE-BOUNDARY-START(64426409997)
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TValue*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64426409997);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        throw new $.$$.System.NotSupportedException().$ctor$12($.$sc.System.SR.NotSupported_ValueCollectionSet);
                    }
                    //--TRIMMABLE-BOUNDARY-END(64426409997)
                    
                    //--TRIMMABLE-BOUNDARY-START(94491181069)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81606279181);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(94491181069)
                    
                    //--TRIMMABLE-BOUNDARY-START(98786148365)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(90196213773);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98786148365)
                    
                    //--TRIMMABLE-BOUNDARY-START(1966093)
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).ValueCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.SortedDictionary$$$.ValueCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296933389)
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  get _dictEnum() { return this.$getField(0, 21); }
                            /*SortedDictionary<TKey, TValue>.Enumerator*/  set _dictEnum(value) { this.$setField(0, 21, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296933389)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886867981)
                            $ctor$3(/*SortedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886867981);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._dictEnum = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886867981)
                            
                            //--TRIMMABLE-BOUNDARY-START(21476802573)
                            /*void */ Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(21476802573);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                this._dictEnum.Dispose();
                            }
                            //--TRIMMABLE-BOUNDARY-END(21476802573)
                            
                            //--TRIMMABLE-BOUNDARY-START(34361704461)
                            /*bool */ MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(34361704461);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._dictEnum.MoveNext();
                            }
                            //--TRIMMABLE-BOUNDARY-END(34361704461)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181835277)
                            /*TValue */ get Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(30066737165);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this._dictEnum.Current.Value;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181835277)
                            
                            //--TRIMMABLE-BOUNDARY-START(38656671757)
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(47246606349);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                if (this._dictEnum.NotStartedOrEnded)
                                {
                                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sc.System.SR.InvalidOperation_EnumOpCantHappen);
                                }
                                return $.$box(this.Current, TValue);
                            }
                            //--TRIMMABLE-BOUNDARY-END(38656671757)
                            
                            //--TRIMMABLE-BOUNDARY-START(51541573645)
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51541573645);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                this._dictEnum.Reset();
                            }
                            //--TRIMMABLE-BOUNDARY-END(51541573645)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944605185)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354670593);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944605185)
                            
                            //--TRIMMABLE-BOUNDARY-START(4385275905)
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4385275905);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Dispose(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(4385275905)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242652673)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242652673);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242652673)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591900685)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591900685)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._dictEnum = this._dictEnum.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(4296933389)
                                this._dictEnum = $.$default($.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).Enumerator);
                                //--TRIMMABLE-BOUNDARY-END(4296933389)
                                
                            }
                            static $h = 1966093;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 1900557,
  "h": 1966093
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1966093)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TValue>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    static $h = 1900557;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,
  "h": 1900557
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyCollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection`; }
                }, $cls, ($v) => $cls.$_ValueCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900557)
            
            //--TRIMMABLE-BOUNDARY-START(1835021)
            static $_KeyValuePairComparer;
            static get KeyValuePairComparer()
            {
                let $cls = $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue);
                return $cls.$_KeyValuePairComparer ??= $asm.$ncls("$sc.System.Collections.Generic.SortedDictionary$$$.KeyValuePairComparer", ($self) => class KeyValuePairComparer extends $.$$.System.Collections.Generic.Comparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))
                {
                    //--TRIMMABLE-BOUNDARY-START(21476671501)
                    /*IComparer<TKey>*/ keyComparer = null;
                    //--TRIMMABLE-BOUNDARY-END(21476671501)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296802317)
                    $ctor$2(/*IComparer<TKey>?*/ keyComparer)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(4296802317);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.keyComparer = keyComparer ?? $.$$.System.Collections.Generic.Comparer$$(TKey).Default;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296802317)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591769613)
                    /*int */ Compare(/*KeyValuePair<TKey, TValue>*/ x, /*KeyValuePair<TKey, TValue>*/ y)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591769613);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.keyComparer.System$Collections$Generic$IComparer$$$Compare(x.Key, y.Key, [TKey]);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591769613)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886736909)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886736909);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        let other;
                        if ($.$is(obj, $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer, { set $v(v){ other = v; } }))
                        {
                            return this.keyComparer === other.keyComparer || $.$$.System.Object.Equals$1.call(this.keyComparer, other.keyComparer);
                        }
                        return false;
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(12886736909)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181704205)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181704205);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$$.System.Object.GetHashCode.call(this.keyComparer);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).KeyValuePairComparer.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(17181704205)
                    
                    static $h = 1835021;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "d": $.$sc.System.Collections.Generic.SortedDictionary$$$(TKey, TValue).$h,
  "h": 1835021
}; }
                    static get $b() { return $.$$.System.Collections.Generic.Comparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer, $.$$.System.Collections.Generic.IComparer$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) ]; }
                    static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyValuePairComparer`; }
                }, $cls, ($v) => $cls.$_KeyValuePairComparer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1835021)
            
            //--TRIMMABLE-BOUNDARY-START(17239375873)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239375873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239375873)
            
            //--TRIMMABLE-BOUNDARY-START(51599114241)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51599114241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51599114241)
            
            //--TRIMMABLE-BOUNDARY-START(8649441281)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649441281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649441281)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            //--TRIMMABLE-BOUNDARY-START(43009179649)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009179649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009179649)
            
            //--TRIMMABLE-BOUNDARY-START(60189048833)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60189048833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60189048833)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.CopyTo(System.Collections.Generic.KeyValuePair<TKey, TValue>[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(8652455937)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652455937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652455937)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            //--TRIMMABLE-BOUNDARY-START(4355063809)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355063809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355063809)
            
            //--TRIMMABLE-BOUNDARY-START(43009769473)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009769473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009769473)
            
            //--TRIMMABLE-BOUNDARY-START(12944998401)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944998401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944998401)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            static $h = 1572877;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.SortedDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(1572877)
        
        
        //--TRIMMABLE-BOUNDARY-START(851981)
        $asm.$cls("$sc.System.Collections.Generic.OrderedDictionary<,>", (TKey, TValue) => $asm.$gt("$sc.System.Collections.Generic.OrderedDictionary<,>", [TKey, TValue], ($self) => class OrderedDictionary$$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590786573)
            /*IEqualityComparer<TKey>?*/ _comparer = null;
            //--TRIMMABLE-BOUNDARY-END(8590786573)
            
            //--TRIMMABLE-BOUNDARY-START(4295819277)
            /*int[]?*/ _buckets = null;
            //--TRIMMABLE-BOUNDARY-END(4295819277)
            
            //--TRIMMABLE-BOUNDARY-START(17180721165)
            /*Entry[]?*/ _entries = null;
            //--TRIMMABLE-BOUNDARY-END(17180721165)
            
            //--TRIMMABLE-BOUNDARY-START(12885753869)
            /*int*/ _count = 0;
            //--TRIMMABLE-BOUNDARY-END(12885753869)
            
            //--TRIMMABLE-BOUNDARY-START(25770655757)
            /*int*/ _version = 0;
            //--TRIMMABLE-BOUNDARY-END(25770655757)
            
            //--TRIMMABLE-BOUNDARY-START(21475688461)
            /*ulong*/ _fastModMultiplier = 0n;
            //--TRIMMABLE-BOUNDARY-END(21475688461)
            
            //--TRIMMABLE-BOUNDARY-START(55835426829)
            $ctor$1()
            {
                this.$ctor$7(0, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835426829);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835426829)
            
            //--TRIMMABLE-BOUNDARY-START(85900197901)
            $ctor$8(/*int*/ capacity)
            {
                this.$ctor$7(capacity, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85900197901);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85900197901)
            
            //--TRIMMABLE-BOUNDARY-START(77310263309)
            $ctor$6(/*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7(0, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310263309);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263309)
            
            //--TRIMMABLE-BOUNDARY-START(81605230605)
            $ctor$7(/*int*/ capacity, /*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605230605);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                    if (capacity > 0)
                    {
                        this.EnsureBucketsAndEntriesInitialized(capacity);
                    }
                    if (!TKey.$type.IsValueType)
                    {
                        this._comparer = comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                        let stringComparer;
                        if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is($.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer.GetStringComparer(this._comparer), $.$$.System.Collections.Generic.IEqualityComparer$$($.$$.System.String), { set $v(v){ stringComparer = v; } }))
                        {
                            this._comparer = $.$cast(stringComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                        }
                    }
                    else if (!(comparer === null) && comparer !== $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default)
                    {
                        this._comparer = comparer;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230605)
            
            //--TRIMMABLE-BOUNDARY-START(64425361421)
            $ctor$3(/*IDictionary<TKey, TValue>*/ dictionary)
            {
                this.$ctor$2(dictionary, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425361421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64425361421)
            
            //--TRIMMABLE-BOUNDARY-START(60130394125)
            $ctor$2(/*IDictionary<TKey, TValue>*/ dictionary, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7((dictionary?.System$Collections$Generic$ICollection$$$Count ?? null) ?? 0, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130394125);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(dictionary, "dictionary");
                    this.AddRange(dictionary);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130394125)
            
            //--TRIMMABLE-BOUNDARY-START(73015296013)
            $ctor$5(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                this.$ctor$4(collection, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015296013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73015296013)
            
            //--TRIMMABLE-BOUNDARY-START(68720328717)
            $ctor$4(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection, /*IEqualityComparer<TKey>?*/ comparer)
            {
                this.$ctor$7((($.$as(collection, $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))))?.System$Collections$Generic$ICollection$$$Count ?? null) ?? 0, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720328717);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(collection, "collection");
                    this.AddRange(collection);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328717)
            
            //--TRIMMABLE-BOUNDARY-START(124554903565)
            /*void */ EnsureBucketsAndEntriesInitialized(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554903565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Resize($.$sc.System.Collections.HashHelpers.GetPrime(capacity), false);
            }
            //--TRIMMABLE-BOUNDARY-END(124554903565)
            
            //--TRIMMABLE-BOUNDARY-START(98785099789)
            /*int */ get Capacity()
            {
                const $t1 = this._entries;
                return $.$ifnn($t1, ($t) => $t.length) ?? 0;
            }
            //--TRIMMABLE-BOUNDARY-END(98785099789)
            
            //--TRIMMABLE-BOUNDARY-START(107375034381)
            /*IEqualityComparer<TKey> */ get Comparer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029740045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEqualityComparer<TKey>?*/ let comparer = this._comparer;
                let ec;
                if ($.$$.System.Type.op_Equality$1(TKey.$type, $.$$.System.String.$type) && $.$is((($.$as(comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))?.GetUnderlyingEqualityComparer() ?? null), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), { set $v(v){ ec = v; } }))
                {
                    return ec;
                }
                return comparer ?? $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default;
            }
            //--TRIMMABLE-BOUNDARY-END(107375034381)
            
            //--TRIMMABLE-BOUNDARY-START(120259936269)
            /*int */ get Count()
            {
                return this._count;
            }
            //--TRIMMABLE-BOUNDARY-END(120259936269)
            
            //--TRIMMABLE-BOUNDARY-START(283468693517)
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(283468693517)
            
            //--TRIMMABLE-BOUNDARY-START(481037189133)
            /*bool */ get System$Collections$IDictionary$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(481037189133)
            
            //--TRIMMABLE-BOUNDARY-START(562641567757)
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(562641567757)
            
            //--TRIMMABLE-BOUNDARY-START(476742221837)
            /*bool */ get System$Collections$IDictionary$IsFixedSize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(476742221837)
            
            //--TRIMMABLE-BOUNDARY-START(558346600461)
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(558346600461)
            
            //--TRIMMABLE-BOUNDARY-START(210454249485)
            /*KeyCollection*/ Keys$1$ = null;
            /*KeyCollection */ get Keys$1()
            {
                return this.Keys$ ??= new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection)().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(210454249485)
            
            //--TRIMMABLE-BOUNDARY-START(369368039437)
            /*IEnumerable<TKey> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(369368039437)
            
            //--TRIMMABLE-BOUNDARY-START(309238497293)
            /*ICollection<TKey> */ get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(309238497293)
            
            //--TRIMMABLE-BOUNDARY-START(485332156429)
            /*ICollection */ get System$Collections$IDictionary$Keys()
            {
                return this.Keys$1;
            }
            //--TRIMMABLE-BOUNDARY-END(485332156429)
            
            //--TRIMMABLE-BOUNDARY-START(622771109901)
            /*ValueCollection*/ Values$ = null;
            /*ValueCollection */ get Values()
            {
                return this.Values$ ??= new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection)().$ctor$1(this);
            }
            //--TRIMMABLE-BOUNDARY-END(622771109901)
            
            //--TRIMMABLE-BOUNDARY-START(373663006733)
            /*IEnumerable<TValue> */ get System$Collections$Generic$IReadOnlyDictionary$$$$Values()
            {
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(373663006733)
            
            //--TRIMMABLE-BOUNDARY-START(313533464589)
            /*ICollection<TValue> */ get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(313533464589)
            
            //--TRIMMABLE-BOUNDARY-START(506806992909)
            /*ICollection */ get System$Collections$IDictionary$Values()
            {
                return this.Values;
            }
            //--TRIMMABLE-BOUNDARY-END(506806992909)
            
            //--TRIMMABLE-BOUNDARY-START(412317712397)
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(412317712397)
            
            //--TRIMMABLE-BOUNDARY-START(416612679693)
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(416612679693)
            
            //--TRIMMABLE-BOUNDARY-START(579821436941)
            //--TRIMMABLE-BOUNDARY-START(77372391425)
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                let tpair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ tpair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.SetAt(index, tpair.Key, tpair.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(77372391425)
            
            //--TRIMMABLE-BOUNDARY-END(579821436941)
            
            //--TRIMMABLE-BOUNDARY-START(502512025613)
            //--TRIMMABLE-BOUNDARY-START(90256834561)
            /*object?*/ System$Collections$IDictionary$get_Item(/*object*/ key)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                /*TValue?*/ let value;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.TryGetValue$1(tkey, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    return $.$box(value, TValue);
                }
                return null;
            }
            /*void*/ System$Collections$IDictionary$set_Item(/*object*/ key, /*object?*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                let tkey;
                if (!$.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                /*TValue*/ let tvalue = $.$default(TValue);
                if (!(value === null))
                {
                    let temp;
                    if (!$.$is(value, TValue, { set $v(v){ temp = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                    tvalue = temp;
                }
                this.set_Item$1(tkey, tvalue);
            }
            //--TRIMMABLE-BOUNDARY-END(90256834561)
            
            //--TRIMMABLE-BOUNDARY-END(502512025613)
            
            //--TRIMMABLE-BOUNDARY-START(347893202957)
            //--TRIMMABLE-BOUNDARY-START(34419638273)
            /*KeyValuePair<TKey, TValue>*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
            }
            /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*KeyValuePair<TKey, TValue>*/ value)
            {
                this.SetAt(index, value.Key, value.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(34419638273)
            
            //--TRIMMABLE-BOUNDARY-END(347893202957)
            
            //--TRIMMABLE-BOUNDARY-START(386547908621)
            //--TRIMMABLE-BOUNDARY-START(12945063937)
            /*KeyValuePair<TKey, TValue>*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
            {
                return this.GetAt(index);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(12945063937)
            
            //--TRIMMABLE-BOUNDARY-END(386547908621)
            
            //--TRIMMABLE-BOUNDARY-START(584116404237)
            /*TValue*/ get_Item$1(/*TKey*/ key)
            {
                /*TValue?*/ let value;
                if (!this.TryGetValue$1(key, $.$ref(() => value, ($v) => value = $v, TValue)))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowKeyNotFound(TKey, key);
                }
                return value;
            }
            /*void*/ set_Item$1(/*TKey*/ key, /*TValue*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*bool*/ let modified = this.TryInsert(-1, key, value, 1/*InsertionBehavior.OverwriteExisting*/, $.$discardRef());
                $.$$.System.Diagnostics.Debug.Assert$2(modified, "modified");
            }
            //--TRIMMABLE-BOUNDARY-END(584116404237)
            
            //--TRIMMABLE-BOUNDARY-START(614181175309)
            /*bool */ TryInsert(/*int*/ index, /*TKey*/ key, /*TValue*/ value, /*InsertionBehavior*/ behavior, /*out int*/ keyIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614181175309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let hashCode = 0, collisionCount = 0;
                /*int*/ let i = this.IndexOf(key, $.$ref(() => hashCode, ($v) => hashCode = $v, $.$$.System.UInt32), $.$ref(() => collisionCount, ($v) => collisionCount = $v, $.$$.System.UInt32));
                if (i >= 0)
                {
                    keyIndex.$v = i;
                    $.$$.System.Diagnostics.Debug.Assert$2(0 <= keyIndex.$v && keyIndex.$v < this._count, "0 <= keyIndex && keyIndex < _count");
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    switch(behavior)
                    {
                        case 1/*InsertionBehavior.OverwriteExisting*/:
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 0, "Expected index to be unspecied when overwriting an existing key.");
                        $.$$.System.Array.$ReadT1.call(this._entries, i).Value = value;
                        return true;
                        case 2/*InsertionBehavior.ThrowOnExisting*/:
                        $.$sc.System.Collections.ThrowHelper.ThrowDuplicateKey(TKey, key);
                        break;
                        default:
                        $.$$.System.Diagnostics.Debug.Assert$4(behavior === 0, `Unknown behavior: ${behavior}`);
                        $.$$.System.Diagnostics.Debug.Assert$2(index < 0, "Expected index to be unspecied when ignoring a duplicate key.");
                        return false;
                    }
                }
                if (index < 0)
                {
                    index = this._count;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(index <= this._count, "index <= _count");
                if (this._buckets === null)
                {
                    this.EnsureBucketsAndEntriesInitialized(0);
                }
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                if (entries.length === this._count)
                {
                    this.Resize($.$sc.System.Collections.HashHelpers.ExpandPrime(entries.length), false);
                    entries = this._entries;
                }
                for(i = ((this._count - 1) | 0); i >= index; --i)
                {
                    $.$$.System.Array.$WriteT1.call(entries, $.$$.System.Array.$ReadT1.call(entries, i), ((i + 1) | 0));
                    this.UpdateBucketIndex(i, 1);
                }
                /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, index, false, true);
                entry.$v.HashCode = hashCode;
                entry.$v.Key = key;
                entry.$v.Value = value;
                this.PushEntryIntoBucket(entry, index);
                this._count++;
                this._version++;
                this.RehashIfNecessary(collisionCount, entries);
                keyIndex.$v = index;
                $.$$.System.Diagnostics.Debug.Assert$2(0 <= keyIndex.$v && keyIndex.$v < this._count, "0 <= keyIndex && keyIndex < _count");
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(614181175309)
            
            //--TRIMMABLE-BOUNDARY-START(90195165197)
            /*void */ Add(/*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this.TryInsert(-1, key, value, 2/*InsertionBehavior.ThrowOnExisting*/, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(90195165197)
            
            //--TRIMMABLE-BOUNDARY-START(601296273421)
            /*bool */ TryAdd$1(/*TKey*/ key, /*TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(601296273421);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryAdd(key, value, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(601296273421)
            
            //--TRIMMABLE-BOUNDARY-START(597001306125)
            /*bool */ TryAdd(/*TKey*/ key, /*TValue*/ value, /*out int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597001306125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                return this.TryInsert(-1, key, value, 0/*InsertionBehavior.IgnoreInsertion*/, index);
            }
            //--TRIMMABLE-BOUNDARY-END(597001306125)
            
            //--TRIMMABLE-BOUNDARY-START(94490132493)
            /*void */ AddRange(/*IEnumerable<KeyValuePair<TKey, TValue>>*/ collection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490132493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(collection === null), "collection is not null");
                let array;
                if ($.$is(collection, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ array = v; } }))
                {
                    let $i1 = 0;
                    let $arr1 = array;
                    while ($i1 < $arr1.length)
                    {
                        let pair = $arr1[$i1++];
                        this.Add(pair.Key, pair.Value);
                    }
                }
                else 
                {
                    var $en3 = collection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var pair = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.Add(pair.Key, pair.Value);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490132493)
            
            //--TRIMMABLE-BOUNDARY-START(103080067085)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080067085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(this._buckets === null) && this._count !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    $.$$.System.Array.Clear(this._buckets, 0, this._buckets.length);
                    $.$$.System.Array.Clear(this._entries, 0, this._count);
                    this._count = 0;
                    this._version++;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080067085)
            
            //--TRIMMABLE-BOUNDARY-START(111670001677)
            /*bool */ ContainsKey(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670001677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IndexOf$1(key) >= 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670001677)
            
            //--TRIMMABLE-BOUNDARY-START(115964968973)
            /*bool */ ContainsValue(/*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964968973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = this._count;
                /*Entry[]?*/ let entries = this._entries;
                if (entries === null)
                {
                    return false;
                }
                if (TValue.$type.IsValueType)
                {
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                        {
                            return true;
                        }
                    }
                }
                else 
                {
                    /*EqualityComparer<TValue>*/ let comparer = $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default;
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        if (comparer.Equals$2(value, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(115964968973)
            
            //--TRIMMABLE-BOUNDARY-START(184684445709)
            /*KeyValuePair<TKey, TValue> */ GetAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684445709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "count must be positive, which means we must have entries");
                /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, index, false, true);
                return new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(e.$v.Key, e.$v.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(184684445709)
            
            //--TRIMMABLE-BOUNDARY-START(201864314893)
            /*int */ IndexOf$1(/*TKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864314893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*uint*/ let _ = 0;
                return this.IndexOf(key, $.$discardRef(), $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(201864314893)
            
            //--TRIMMABLE-BOUNDARY-START(197569347597)
            /*int */ IndexOf(/*TKey*/ key, /*ref uint*/ outHashCode, /*ref uint*/ outCollisionCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569347597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let hashCode;
                /*uint*/ let collisionCount;
                /*IEqualityComparer<TKey>?*/ let comparer;
                /*int*/ let i;
                /*ref Entry*/ let entry;
                /*Entry[]?*/ let entries;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(key === null), "Key nullness should have been validated by caller.");
                            collisionCount = 0;
                            comparer = this._comparer;
                            if (this._buckets === null)
                            {
                                hashCode = (((comparer?.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]) ?? null) ?? $.$$.System.Object.GetHashCodeT(TKey, key)) >>> 0);
                                collisionCount = 0;
                                $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                continue $gotoJumpStart1;
                            }
                            i = -1;
                            entry = $.$$.System.Runtime.CompilerServices.Unsafe.NullRef($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry);
                            entries = this._entries;
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "expected entries to be is not null");
                            if (TKey.$type.IsValueType && comparer === null)
                            {
                                hashCode = ($.$$.System.Object.GetHashCodeT(TKey, key) >>> 0);
                                i = ((this.GetBucket(hashCode).$v - 1) | 0);
                                do
                                {
                                    if ((i >>> 0) >= (entries.length >>> 0))
                                    {
                                        $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                        continue $gotoJumpStart1;
                                    }
                                    entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                                    if (entry.$v.HashCode === hashCode && $.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(entry.$v.Key, key))
                                    {
                                        $gotoJumpState1 = 3; /*goto Return*/
                                        continue $gotoJumpStart1;
                                    }
                                    i = entry.$v.Next;
                                    collisionCount++;
                                }
                                while(collisionCount <= (entries.length >>> 0));
                                $gotoJumpState1 = 2; /*goto ConcurrentOperation*/
                                continue $gotoJumpStart1;
                            }
                            else 
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(!(comparer === null), "comparer is not null");
                                hashCode = (comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]) >>> 0);
                                i = ((this.GetBucket(hashCode).$v - 1) | 0);
                                do
                                {
                                    if ((i >>> 0) >= (entries.length >>> 0))
                                    {
                                        $gotoJumpState1 = 1; /*goto ReturnNotFound*/
                                        continue $gotoJumpStart1;
                                    }
                                    entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                                    if (entry.$v.HashCode === hashCode && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(entry.$v.Key, key, [TKey]))
                                    {
                                        $gotoJumpState1 = 3; /*goto Return*/
                                        continue $gotoJumpStart1;
                                    }
                                    i = entry.$v.Next;
                                    collisionCount++;
                                }
                                while(collisionCount <= (entries.length >>> 0));
                                $gotoJumpState1 = 2; /*goto ConcurrentOperation*/
                                continue $gotoJumpStart1;
                            }
                        }
                        case 1: /*ReturnNotFound*/
                        i = -1;
                        outCollisionCount.$v = collisionCount;
                        $gotoJumpState1 = 3; /*goto Return*/
                        continue $gotoJumpStart1;
                        case 2: /*ConcurrentOperation*/
                        $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        case 3: /*Return*/
                        outHashCode.$v = hashCode;
                        return i;
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569347597)
            
            //--TRIMMABLE-BOUNDARY-START(206159282189)
            /*void */ Insert(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159282189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index >>> 0) > (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                this.TryInsert(index, key, value, 2/*InsertionBehavior.ThrowOnExisting*/, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(206159282189)
            
            //--TRIMMABLE-BOUNDARY-START(227634118669)
            /*bool */ Remove$1(/*TKey*/ key)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227634118669);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Remove(key, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634118669)
            
            //--TRIMMABLE-BOUNDARY-START(223339151373)
            /*bool */ Remove(/*TKey*/ key, /*out TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339151373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                /*int*/ let index = this.IndexOf$1(key);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    value.$v = $.$$.System.Array.$ReadT1.call(this._entries, index).Value;
                    this.RemoveAt(index);
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(223339151373)
            
            //--TRIMMABLE-BOUNDARY-START(231929085965)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929085965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let count = this._count;
                if ((index >>> 0) >= (count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                this.RemoveEntryFromBucket(index);
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                for(/*int*/ let i = ((index + 1) | 0); i < count; i++)
                {
                    $.$$.System.Array.$WriteT1.call(entries, $.$$.System.Array.$ReadT1.call(entries, i), ((i - 1) | 0));
                    this.UpdateBucketIndex(i, -1);
                }
                $.$$.System.Array.$WriteT1.call(entries, new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry)(), --this._count);
                this._version++;
            }
            //--TRIMMABLE-BOUNDARY-END(231929085965)
            
            //--TRIMMABLE-BOUNDARY-START(257698889741)
            /*void */ SetAt$1(/*int*/ index, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698889741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                $.$$.System.Array.$ReadT1.call(this._entries, index).Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(257698889741)
            
            //--TRIMMABLE-BOUNDARY-START(253403922445)
            /*void */ SetAt(/*int*/ index, /*TKey*/ key, /*TValue*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403922445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowIndexArgumentOutOfRange();
                }
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, index, false, true);
                if (TKey.$type.IsValueType && this._comparer === null)
                {
                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TKey).Default.Equals$2(key, e.$v.Key))
                    {
                        e.$v.Value = value;
                        return;
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                    if (this._comparer.System$Collections$Generic$IEqualityComparer$$$Equals(key, e.$v.Key, [TKey]))
                    {
                        e.$v.Value = value;
                        return;
                    }
                }
                /*uint*/ let hashCode = 0, collisionCount = 0;
                if (this.IndexOf(key, $.$ref(() => hashCode, ($v) => hashCode = $v, $.$$.System.UInt32), $.$ref(() => collisionCount, ($v) => collisionCount = $v, $.$$.System.UInt32)) >= 0)
                {
                    $.$sc.System.Collections.ThrowHelper.ThrowDuplicateKey(TKey, key);
                }
                this.RemoveEntryFromBucket(index);
                e.$v.HashCode = hashCode;
                e.$v.Key = key;
                e.$v.Value = value;
                this.PushEntryIntoBucket(e, index);
                this._version++;
                this.RehashIfNecessary(collisionCount, this._entries);
            }
            //--TRIMMABLE-BOUNDARY-END(253403922445)
            
            //--TRIMMABLE-BOUNDARY-START(128849870861)
            /*int */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849870861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, capacity, "capacity");
                if (this.Capacity < capacity)
                {
                    if (this._buckets === null)
                    {
                        this.EnsureBucketsAndEntriesInitialized(capacity);
                    }
                    else 
                    {
                        this.Resize($.$sc.System.Collections.HashHelpers.GetPrime(capacity), false);
                    }
                    this._version++;
                }
                return this.Capacity;
            }
            //--TRIMMABLE-BOUNDARY-END(128849870861)
            
            //--TRIMMABLE-BOUNDARY-START(588411371533)
            /*void */ TrimExcess()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(588411371533);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TrimExcess$1(this._count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(588411371533)
            
            //--TRIMMABLE-BOUNDARY-START(592706338829)
            /*void */ TrimExcess$1(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706338829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, capacity, this.Count, "capacity");
                const $t1 = this._entries;
                /*int*/ let currentCapacity = $.$ifnn($t1, ($t) => $t.length) ?? 0;
                capacity = $.$sc.System.Collections.HashHelpers.GetPrime(capacity);
                if (capacity < currentCapacity)
                {
                    this.Resize(capacity, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(592706338829)
            
            //--TRIMMABLE-BOUNDARY-START(609886208013)
            /*bool */ TryGetValue$1(/*TKey*/ key, /*out TValue*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(609886208013);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.TryGetValue(key, value, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(609886208013)
            
            //--TRIMMABLE-BOUNDARY-START(605591240717)
            /*bool */ TryGetValue(/*TKey*/ key, /*out TValue*/ value, /*out int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605591240717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(key, TKey), "key");
                index.$v = this.IndexOf$1(key);
                if (index.$v >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    value.$v = $.$$.System.Array.$ReadT1.call(this._entries, index.$v).Value;
                    return true;
                }
                value.$v = $.$default(TValue);
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(605591240717)
            
            //--TRIMMABLE-BOUNDARY-START(214749216781)
            /*void */ PushEntryIntoBucket(/*ref Entry*/ entry, /*int*/ entryIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749216781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ref int*/ let bucket = this.GetBucket(entry.$v.HashCode);
                entry.$v.Next = ((bucket.$v - 1) | 0);
                bucket.$v = ((entryIndex + 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(214749216781)
            
            //--TRIMMABLE-BOUNDARY-START(236224053261)
            /*void */ RemoveEntryFromBucket(/*int*/ entryIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224053261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                /*Entry*/ let entry = $.$$.System.Array.$ReadT1.call(entries, entryIndex);
                /*ref int*/ let bucket = this.GetBucket(entry.HashCode);
                if (bucket.$v === ((entryIndex + 1) | 0))
                {
                    bucket.$v = ((entry.Next + 1) | 0);
                }
                else 
                {
                    /*int*/ let i = ((bucket.$v - 1) | 0);
                    /*int*/ let collisionCount = 0;
                    while(true)
                    {
                        /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                        if (e.$v.Next === entryIndex)
                        {
                            e.$v.Next = entry.Next;
                            return;
                        }
                        i = e.$v.Next;
                        if (++collisionCount > entries.length)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224053261)
            
            //--TRIMMABLE-BOUNDARY-START(618476142605)
            /*void */ UpdateBucketIndex(/*int*/ entryIndex, /*int*/ shiftAmount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618476142605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((shiftAmount === 1) || (shiftAmount === -1), "shiftAmount is 1 or -1");
                /*Entry[]?*/ let entries = this._entries;
                $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                /*Entry*/ let entry = $.$$.System.Array.$ReadT1.call(entries, entryIndex);
                /*ref int*/ let bucket = this.GetBucket(entry.HashCode);
                if (bucket.$v === ((entryIndex + 1) | 0))
                {
                    bucket.$v += shiftAmount;
                }
                else 
                {
                    /*int*/ let i = ((bucket.$v - 1) | 0);
                    /*int*/ let collisionCount = 0;
                    while(true)
                    {
                        /*ref Entry*/ let e = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, entries, i, false, true);
                        if (e.$v.Next === entryIndex)
                        {
                            e.$v.Next += shiftAmount;
                            return;
                        }
                        i = e.$v.Next;
                        if (++collisionCount > entries.length)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowConcurrentOperation();
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(618476142605)
            
            //--TRIMMABLE-BOUNDARY-START(219044184077)
            /*void */ RehashIfNecessary(/*uint*/ collisionCount, /*Entry[]*/ entries)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044184077);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!TKey.$type.IsValueType && collisionCount > 100/*HashHelpers.HashCollisionThreshold*/ && $.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))
                {
                    this.Resize(entries.length, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044184077)
            
            //--TRIMMABLE-BOUNDARY-START(240519020557)
            /*void */ Resize(/*int*/ newSize, /*bool*/ forceNewHashCodes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519020557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!forceNewHashCodes || !TKey.$type.IsValueType, "Value types never rehash.");
                $.$$.System.Diagnostics.Debug.Assert$2(newSize >= this._count, "The requested size must accomodate all of the current elements.");
                /*int[]*/ let newBuckets = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [newSize], null);
                /*Entry[]*/ let newEntries = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry), null, [newSize], null);
                //if (IntPtr.Size == 8) { ... }
                /*int*/ let count = this._count;
                if (!(this._entries === null))
                {
                    $.$$.System.Array.Copy(this._entries, newEntries, count);
                }
                if (!TKey.$type.IsValueType && forceNewHashCodes)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer), "_comparer is NonRandomizedStringEqualityComparer");
                    /*IEqualityComparer<TKey>*/ let comparer = this._comparer = $.$cast(($.$cast(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer)).GetUnderlyingEqualityComparer(), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey));
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer === null), "_comparer is not null");
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._comparer !== null && ($.$is(this._comparer, $.$$.System.Collections.Generic.NonRandomizedStringEqualityComparer))), "_comparer is not NonRandomizedStringEqualityComparer");
                    for(/*int*/ let i = 0; i < count; i++)
                    {
                        $.$$.System.Array.$ReadT1.call(newEntries, i).HashCode = (comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode($.$$.System.Array.$ReadT1.call(newEntries, i).Key, [TKey]) >>> 0);
                    }
                }
                this._buckets = newBuckets;
                for(/*int*/ let i = 0; i < count; i++)
                {
                    this.PushEntryIntoBucket($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, newEntries, i, false, true), i);
                }
                this._entries = newEntries;
            }
            //--TRIMMABLE-BOUNDARY-END(240519020557)
            
            //--TRIMMABLE-BOUNDARY-START(188979413005)
            /*ref int */ GetBucket(/*uint*/ hashCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979413005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int[]?*/ let buckets = this._buckets;
                $.$$.System.Diagnostics.Debug.Assert$2(!(buckets === null), "buckets is not null");
                //if (IntPtr.Size == 8) { ... }
                //else 
                {
                    return $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Int32, buckets, hashCode % buckets.length, false, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979413005)
            
            //--TRIMMABLE-BOUNDARY-START(193274380301)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193274380301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193274380301)
            
            //--TRIMMABLE-BOUNDARY-START(317828431885)
            /*IEnumerator<KeyValuePair<TKey, TValue>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(317828431885);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)) : this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317828431885)
            
            //--TRIMMABLE-BOUNDARY-START(511101960205)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(511101960205);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(511101960205)
            
            //--TRIMMABLE-BOUNDARY-START(472447254541)
            /*IDictionaryEnumerator */ System$Collections$IDictionary$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(472447254541);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator)().$ctor$3(this, true);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(472447254541)
            
            //--TRIMMABLE-BOUNDARY-START(330713333773)
            /*int */ System$Collections$Generic$IList$$$IndexOf(/*KeyValuePair<TKey, TValue>*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713333773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(item.Key, TKey), "item");
                /*int*/ let index = this.IndexOf$1(item.Key);
                if (index >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this._entries === null), "_entries is not null");
                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(item.Value, $.$$.System.Array.$ReadT1.call(this._entries, index).Value))
                    {
                        return index;
                    }
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(330713333773)
            
            //--TRIMMABLE-BOUNDARY-START(335008301069)
            /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*KeyValuePair<TKey, TValue>*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(335008301069);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Insert(index, item.Key, item.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335008301069)
            
            //--TRIMMABLE-BOUNDARY-START(261993857037)
            /*void */ System$Collections$Generic$ICollection$$$Add(/*KeyValuePair<TKey, TValue>*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261993857037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Add(item.Key, item.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261993857037)
            
            //--TRIMMABLE-BOUNDARY-START(266288824333)
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*KeyValuePair<TKey, TValue>*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288824333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2($.$box(item.Key, TKey), "item");
                /*TValue?*/ let value;
                return this.TryGetValue$1(item.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, item.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(266288824333)
            
            //--TRIMMABLE-BOUNDARY-START(270583791629)
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*KeyValuePair<TKey, TValue>[]*/ array, /*int*/ arrayIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583791629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                if (((array.length - arrayIndex) | 0) < this._count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                for(/*int*/ let i = 0; i < this._count; i++)
                {
                    /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, this._entries, i, false, true);
                    $.$$.System.Array.$WriteT1.call(array, new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(entry.$v.Key, entry.$v.Value), arrayIndex++);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270583791629)
            
            //--TRIMMABLE-BOUNDARY-START(287763660813)
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*KeyValuePair<TKey, TValue>*/ item)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287763660813);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*TValue?*/ let value;
                    return this.TryGetValue$1(item.Key, $.$ref(() => value, ($v) => value = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(value, item.Value) && this.Remove$1(item.Key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763660813)
            
            //--TRIMMABLE-BOUNDARY-START(420907646989)
            /*void */ System$Collections$IDictionary$Add(/*object*/ key, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907646989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                let tkey;
                if (!$.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, key, TKey.$type), "key");
                }
                if (!($.$default(TValue) === null))
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                }
                /*TValue*/ let tvalue = $.$default(TValue);
                if (!(value === null))
                {
                    let temp;
                    if (!$.$is(value, TValue, { set $v(v){ temp = v; } }))
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, TValue.$type), "value");
                    }
                    tvalue = temp;
                }
                this.Add(tkey, tvalue);
            }
            //--TRIMMABLE-BOUNDARY-END(420907646989)
            
            //--TRIMMABLE-BOUNDARY-START(425202614285)
            /*bool */ System$Collections$IDictionary$Contains(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202614285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                return $.$is(key, TKey, { set $v(v){ tkey = v; } }) && this.ContainsKey(tkey);
            }
            //--TRIMMABLE-BOUNDARY-END(425202614285)
            
            //--TRIMMABLE-BOUNDARY-START(489627123725)
            /*void */ System$Collections$IDictionary$Remove(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627123725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(key, "key");
                let tkey;
                if ($.$is(key, TKey, { set $v(v){ tkey = v; } }))
                {
                    this.Remove$1(tkey);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(489627123725)
            
            //--TRIMMABLE-BOUNDARY-START(390842875917)
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842875917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                if ($.$$.System.Array.Rank$get.call(array) !== 1)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                }
                if (array.GetLowerBound(0) !== 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                if (((array.length - index) | 0) < this._count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                }
                let tarray;
                if ($.$is(array, $.$typeArray($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), { set $v(v){ tarray = v; } }))
                {
                    (this).System$Collections$Generic$ICollection$$$CopyTo(tarray, index, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
                else 
                {
                    try
                    {
                        let objects;
                        if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                        }
                        var $en4 = this.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var pair = $en4.Current;
                            {
                                $.$$.System.Array.$WriteT1.call(objects, pair, index++);
                            }
                        }
                    }
                    catch($e)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(390842875917)
            
            //--TRIMMABLE-BOUNDARY-START(515396927501)
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396927501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let pair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.Add(pair.Key, pair.Value);
                return ((this.Count - 1) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(515396927501)
            
            //--TRIMMABLE-BOUNDARY-START(519691894797)
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(519691894797);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let pair;
                    /*TValue?*/ let v;
                    return $.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }) && this.TryGetValue$1(pair.Key, $.$ref(() => v, ($v) => v = $v, TValue)) && $.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(v, pair.Value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(519691894797)
            
            //--TRIMMABLE-BOUNDARY-START(549756665869)
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756665869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let pair;
                if ($.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    return (this).System$Collections$Generic$IList$$$IndexOf(pair, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
                return -1;
            }
            //--TRIMMABLE-BOUNDARY-END(549756665869)
            
            //--TRIMMABLE-BOUNDARY-START(554051633165)
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051633165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let pair;
                if (!$.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Format$5($.$sc.System.SR.Arg_WrongType, value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue).$type), "value");
                }
                this.Insert(index, pair.Key, pair.Value);
            }
            //--TRIMMABLE-BOUNDARY-END(554051633165)
            
            //--TRIMMABLE-BOUNDARY-START(566936535053)
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566936535053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let pair;
                if ($.$is(value, $.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue), { set $v(v){ pair = v; } }))
                {
                    (this).System$Collections$Generic$ICollection$$$Remove(pair, [$.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)]);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(566936535053)
            
            //--TRIMMABLE-BOUNDARY-START(917517)
            static $_Entry;
            static get Entry()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_Entry ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.Entry", ($self) => class Entry extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786701)
                    /*int*/  get Next() { return this.$getField(0, 4); }
                    /*int*/  set Next(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180786701)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590852109)
                    /*uint*/  get HashCode() { return this.$getField(4, 4); }
                    /*uint*/  set HashCode(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590852109)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885819405)
                    /*TKey*/  get Key() { return this.$getField(8, 4); }
                    /*TKey*/  set Key(value) { this.$setField(8, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885819405)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475753997)
                    /*TValue*/  get Value() { return this.$getField(12, 4); }
                    /*TValue*/  set Value(value) { this.$setField(12, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(21475753997)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295884813)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295884813)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Next = this.Next;
                        copy.HashCode = this.HashCode;
                        copy.Key = this.Key;
                        copy.Value = this.Value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(17180786701)
                        this.Next = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180786701)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590852109)
                        this.HashCode = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590852109)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885819405)
                        this.Key = $.$default(TKey);
                        //--TRIMMABLE-BOUNDARY-END(12885819405)
                        
                        //--TRIMMABLE-BOUNDARY-START(21475753997)
                        this.Value = $.$default(TValue);
                        //--TRIMMABLE-BOUNDARY-END(21475753997)
                        
                    }
                    static $h = 917517;
                    static $z = 16;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,
  "h": 917517
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Entry`; }
                }, $cls, ($v) => $cls.$_Entry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(917517)
            
            //--TRIMMABLE-BOUNDARY-START(983053)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295950349)
                    /*OrderedDictionary<TKey, TValue>*/  get _dictionary() { return this.$getField(0, 4); }
                    /*OrderedDictionary<TKey, TValue>*/  set _dictionary(value) { this.$setField(0, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295950349)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852237)
                    /*int*/  get _version() { return this.$getField(4, 4); }
                    /*int*/  set _version(value) { this.$setField(4, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(17180852237)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885884941)
                    /*bool*/  get _useDictionaryEntry() { return this.$getField(8, 1); }
                    /*bool*/  set _useDictionaryEntry(value) { this.$setField(8, 1, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885884941)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917645)
                    /*int*/  get _index() { return this.$getField(9, 4); }
                    /*int*/  set _index(value) { this.$setField(9, 4, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590917645)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065754125)
                    $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary, /*bool*/ useDictionaryEntry)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30065754125);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._dictionary = dictionary;
                            this._version = this._dictionary._version;
                            this._useDictionaryEntry = useDictionaryEntry;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065754125)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360721421)
                    /*KeyValuePair<TKey, TValue>*/  get Current() { return this.$getField(13, 8); }
                    /*KeyValuePair<TKey, TValue>*/  set Current(value) { this.$setField(13, 8, value); }
                    //--TRIMMABLE-BOUNDARY-END(34360721421)
                    
                    //--TRIMMABLE-BOUNDARY-START(98785230861)
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this._useDictionaryEntry ? new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue)) : this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(98785230861)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130525197)
                    /*DictionaryEntry */ get System$Collections$IDictionaryEnumerator$Entry()
                    {
                        return new $.$$.System.Collections.DictionaryEntry().$ctor$3($.$box(this.Current.Key, TKey), $.$box(this.Current.Value, TValue));
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130525197)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195296269)
                    /*object */ get System$Collections$IDictionaryEnumerator$Key()
                    {
                        return $.$box(this.Current.Key, TKey);
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195296269)
                    
                    //--TRIMMABLE-BOUNDARY-START(94490263565)
                    /*object? */ get System$Collections$IDictionaryEnumerator$Value()
                    {
                        return $.$box(this.Current.Value, TValue);
                    }
                    //--TRIMMABLE-BOUNDARY-END(94490263565)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245623309)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47245623309);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        if (this._version !== dictionary._version)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                        }
                        if (this._index < dictionary._count)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(dictionary._entries === null), "dictionary._entries is not null");
                            /*ref Entry*/ let entry = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Entry, dictionary._entries, this._index, false, true);
                            this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))().$ctor$3(entry.$v.Key, entry.$v.Value);
                            this._index++;
                            return true;
                        }
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245623309)
                    
                    //--TRIMMABLE-BOUNDARY-START(111670132749)
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(111670132749);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._version !== this._dictionary._version)
                        {
                            $.$sc.System.Collections.ThrowHelper.ThrowVersionCheckFailed();
                        }
                        this._index = 0;
                        this.Current = new ($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue))();
                    }
                    //--TRIMMABLE-BOUNDARY-END(111670132749)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965100045)
                    /*void */ System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(115965100045);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                    }
                    //--TRIMMABLE-BOUNDARY-END(115965100045)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944605185)
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354670593);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Current;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944605185)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242652673)
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17242652673);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.MoveNext(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242652673)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770786829)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770786829)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._dictionary = this._dictionary;
                        copy._version = this._version;
                        copy._useDictionaryEntry = this._useDictionaryEntry;
                        copy._index = this._index;
                        copy.Current = this.Current.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295950349)
                        this._dictionary = null;
                        //--TRIMMABLE-BOUNDARY-END(4295950349)
                        
                        //--TRIMMABLE-BOUNDARY-START(17180852237)
                        this._version = 0;
                        //--TRIMMABLE-BOUNDARY-END(17180852237)
                        
                        //--TRIMMABLE-BOUNDARY-START(12885884941)
                        this._useDictionaryEntry = false;
                        //--TRIMMABLE-BOUNDARY-END(12885884941)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590917645)
                        this._index = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590917645)
                        
                        this.Current = $.$default($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue));
                    }
                    static $h = 983053;
                    static $z = 21;
                    static $f = 0b100010000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,
  "h": 983053
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.IDisposable, $.$$.System.Collections.IDictionaryEnumerator, $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983053)
            
            //--TRIMMABLE-BOUNDARY-START(1048589)
            static $_KeyCollection;
            static get KeyCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_KeyCollection ??= $asm.$ncls("$sc.System.Collections.Generic.OrderedDictionary$$$.KeyCollection", ($self) => class KeyCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296015885)
                    /*OrderedDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(4296015885)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885950477)
                    $ctor$1(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885950477);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885950477)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770852365)
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770852365)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130590733)
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130590733)
                    
                    //--TRIMMABLE-BOUNDARY-START(206159478797)
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(206159478797)
                    
                    //--TRIMMABLE-BOUNDARY-START(201864511501)
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(201864511501)
                    
                    //--TRIMMABLE-BOUNDARY-START(141734969357)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(141734969357)
                    
                    //--TRIMMABLE-BOUNDARY-START(146029936653)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(146029936653)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180917773)
                    /*bool */ Contains(/*TKey*/ key)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180917773);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._dictionary.ContainsKey(key);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180917773)
                    
                    //--TRIMMABLE-BOUNDARY-START(163209805837)
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(163209805837);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(value, TKey, { set $v(v){ key = v; } }) && this.Contains(key);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(163209805837)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475885069)
                    /*void */ CopyTo(/*TKey[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475885069);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        /*int*/ let count = dictionary._count;
                        if (((array.length - arrayIndex) | 0) < count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_ArrayPlusOffTooSmall, "array");
                        }
                        /*Entry[]?*/ let entries = dictionary._entries;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(entries, i).Key, arrayIndex++);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475885069)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260132877)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120260132877);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let keys;
                        if ($.$is(array, $.$typeArray(TKey), { set $v(v){ keys = v; } }))
                        {
                            this.CopyTo(keys, index);
                        }
                        else 
                        {
                            try
                            {
                                let objects;
                                if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                                }
                                var $en6 = this.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var key = $en6.Current;
                                    {
                                        $.$$.System.Array.$WriteT1.call(objects, $.$box(key, TKey), index++);
                                    }
                                }
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260132877)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080263693)
                    //--TRIMMABLE-BOUNDARY-START(34419638273)
                    /*TKey*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Key;
                    }
                    /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*TKey*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34419638273)
                    
                    //--TRIMMABLE-BOUNDARY-END(103080263693)
                    
                    //--TRIMMABLE-BOUNDARY-START(227634315277)
                    //--TRIMMABLE-BOUNDARY-START(77372391425)
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        return $.$box(this._dictionary.GetAt(index).Key, TKey);
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77372391425)
                    
                    //--TRIMMABLE-BOUNDARY-END(227634315277)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965165581)
                    //--TRIMMABLE-BOUNDARY-START(12945063937)
                    /*TKey*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Key;
        ;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945063937)
                    
                    //--TRIMMABLE-BOUNDARY-END(115965165581)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655754253)
                    /*Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655754253);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection.Enumerator)().$ctor$3(this._dictionary);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655754253)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720525325)
                    /*IEnumerator<TKey> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68720525325);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TKey) : this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720525325)
                    
                    //--TRIMMABLE-BOUNDARY-START(150324903949)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(150324903949);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TKey]);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(150324903949)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605427213)
                    /*int */ System$Collections$Generic$IList$$$IndexOf(/*TKey*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(81605427213);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._dictionary.IndexOf$1(item);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605427213)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950721549)
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TKey*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42950721549);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950721549)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245688845)
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245688845);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245688845)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900394509)
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TKey*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(85900394509);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900394509)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425558029)
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TKey*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425558029);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425558029)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195361805)
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(90195361805);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195361805)
                    
                    //--TRIMMABLE-BOUNDARY-START(154619871245)
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(154619871245);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(154619871245)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914838541)
                    /*void */ System$Collections$IList$Clear()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(158914838541);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(158914838541)
                    
                    //--TRIMMABLE-BOUNDARY-START(193274576909)
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(193274576909);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let key;
                            return $.$is(value, TKey, { set $v(v){ key = v; } }) ? this._dictionary.IndexOf$1(key) : -1;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(193274576909)
                    
                    //--TRIMMABLE-BOUNDARY-START(197569544205)
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(197569544205);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(197569544205)
                    
                    //--TRIMMABLE-BOUNDARY-START(210454446093)
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(210454446093);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(210454446093)
                    
                    //--TRIMMABLE-BOUNDARY-START(214749413389)
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(214749413389);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(214749413389)
                    
                    //--TRIMMABLE-BOUNDARY-START(1114125)
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).KeyCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.KeyCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296081421)
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  get _enumerator() { return this.$getField(0, 21); }
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  set _enumerator(value) { this.$setField(0, 21, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296081421)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886016013)
                            $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886016013);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._enumerator = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886016013)
                            
                            //--TRIMMABLE-BOUNDARY-START(17180983309)
                            /*TKey */ get Current()
                            {
                                return this._enumerator.Current.Key;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17180983309)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360852493)
                            /*object */ get System$Collections$IEnumerator$Current()
                            {
                                return $.$box(this.Current, TKey);
                            }
                            //--TRIMMABLE-BOUNDARY-END(34360852493)
                            
                            //--TRIMMABLE-BOUNDARY-START(30065885197)
                            /*bool */ MoveNext()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(30065885197);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.MoveNext();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(30065885197)
                            
                            //--TRIMMABLE-BOUNDARY-START(47245754381)
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(47245754381);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return $.$sc.System.Collections.Generic.EnumerableHelpers.Reset($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(47245754381)
                            
                            //--TRIMMABLE-BOUNDARY-START(51540721677)
                            /*void */ System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51540721677);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                            }
                            //--TRIMMABLE-BOUNDARY-END(51540721677)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944605185)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TKey>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354670593);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944605185)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242652673)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242652673);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242652673)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591048717)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591048717)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(4296081421)
                                this._enumerator = $.$default($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator);
                                //--TRIMMABLE-BOUNDARY-END(4296081421)
                                
                            }
                            static $h = 1114125;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 1048589,
  "h": 1114125
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TKey), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1114125)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944211969)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.Contains(TKey)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12944211969);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Contains(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944211969)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TKey>.CopyTo(TKey[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TKey>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    static $h = 1048589;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,
  "h": 1048589
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TKey), $.$$.System.Collections.Generic.ICollection$$(TKey), $.$$.System.Collections.Generic.IReadOnlyList$$(TKey), $.$$.System.Collections.Generic.IReadOnlyCollection$$(TKey), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.KeyCollection`; }
                }, $cls, ($v) => $cls.$_KeyCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1048589)
            
            //--TRIMMABLE-BOUNDARY-START(1179661)
            static $_ValueCollection;
            static get ValueCollection()
            {
                let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue);
                return $cls.$_ValueCollection ??= $asm.$ncls("$sc.System.Collections.Generic.OrderedDictionary$$$.ValueCollection", ($self) => class ValueCollection extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4296146957)
                    /*OrderedDictionary<TKey, TValue>*/ _dictionary = null;
                    //--TRIMMABLE-BOUNDARY-END(4296146957)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886081549)
                    $ctor$1(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12886081549);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._dictionary = dictionary;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886081549)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476016141)
                    /*int */ get Count()
                    {
                        return this._dictionary.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476016141)
                    
                    //--TRIMMABLE-BOUNDARY-START(60130721805)
                    /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(60130721805)
                    
                    //--TRIMMABLE-BOUNDARY-START(206159609869)
                    /*bool */ get System$Collections$IList$IsReadOnly()
                    {
                        return true;
                    }
                    //--TRIMMABLE-BOUNDARY-END(206159609869)
                    
                    //--TRIMMABLE-BOUNDARY-START(201864642573)
                    /*bool */ get System$Collections$IList$IsFixedSize()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(201864642573)
                    
                    //--TRIMMABLE-BOUNDARY-START(141735100429)
                    /*bool */ get System$Collections$ICollection$IsSynchronized()
                    {
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(141735100429)
                    
                    //--TRIMMABLE-BOUNDARY-START(146030067725)
                    /*object */ get System$Collections$ICollection$SyncRoot()
                    {
                        return (this._dictionary).System$Collections$ICollection$SyncRoot;
                    }
                    //--TRIMMABLE-BOUNDARY-END(146030067725)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181048845)
                    /*void */ CopyTo(/*TValue[]*/ array, /*int*/ arrayIndex)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181048845);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, arrayIndex, "arrayIndex");
                        /*OrderedDictionary<TKey, TValue>*/ let dictionary = this._dictionary;
                        /*int*/ let count = dictionary._count;
                        if (((array.length - arrayIndex) | 0) < count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_ArrayPlusOffTooSmall, "array");
                        }
                        /*Entry[]?*/ let entries = dictionary._entries;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(!(entries === null), "entries is not null");
                            $.$$.System.Array.$WriteT1.call(array, $.$$.System.Array.$ReadT1.call(entries, i).Value, arrayIndex++);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181048845)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360918029)
                    /*Enumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(34360918029);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new ($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection.Enumerator)().$ctor$3(this._dictionary);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360918029)
                    
                    //--TRIMMABLE-BOUNDARY-START(103080394765)
                    //--TRIMMABLE-BOUNDARY-START(34419638273)
                    /*TValue*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Value;
                    }
                    /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*TValue*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(34419638273)
                    
                    //--TRIMMABLE-BOUNDARY-END(103080394765)
                    
                    //--TRIMMABLE-BOUNDARY-START(115965296653)
                    //--TRIMMABLE-BOUNDARY-START(12945063937)
                    /*TValue*/ System$Collections$Generic$IReadOnlyList$$$get_Item(/*int*/ index)
                    {
                        return this._dictionary.GetAt(index).Value;
        ;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12945063937)
                    
                    //--TRIMMABLE-BOUNDARY-END(115965296653)
                    
                    //--TRIMMABLE-BOUNDARY-START(227634446349)
                    //--TRIMMABLE-BOUNDARY-START(77372391425)
                    /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
                    {
                        return $.$box(this._dictionary.GetAt(index).Value, TValue);
                    }
                    /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
                    {
                        throw new $.$$.System.NotSupportedException().$ctor$9();
                    }
                    //--TRIMMABLE-BOUNDARY-END(77372391425)
                    
                    //--TRIMMABLE-BOUNDARY-END(227634446349)
                    
                    //--TRIMMABLE-BOUNDARY-START(47245819917)
                    /*bool */ System$Collections$Generic$ICollection$$$Contains(/*TValue*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(47245819917);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._dictionary.ContainsValue(item);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(47245819917)
                    
                    //--TRIMMABLE-BOUNDARY-START(68720656397)
                    /*IEnumerator<TValue> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(68720656397);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this.Count === 0 ? $.$sc.System.Collections.Generic.EnumerableHelpers.GetEmptyEnumerator(TValue) : this.GetEnumerator();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(68720656397)
                    
                    //--TRIMMABLE-BOUNDARY-START(150325035021)
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(150325035021);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this).System$Collections$Generic$IEnumerable$$$GetEnumerator([TValue]);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(150325035021)
                    
                    //--TRIMMABLE-BOUNDARY-START(81605558285)
                    /*int */ System$Collections$Generic$IList$$$IndexOf(/*TValue*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(81605558285);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Entry[]?*/ let entries = this._dictionary._entries;
                        if (!(entries === null))
                        {
                            /*int*/ let count = this._dictionary._count;
                            for(/*int*/ let i = 0; i < count; i++)
                            {
                                if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(item, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                                {
                                    return i;
                                }
                            }
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(81605558285)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655885325)
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TValue*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(38655885325);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655885325)
                    
                    //--TRIMMABLE-BOUNDARY-START(42950852621)
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42950852621);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950852621)
                    
                    //--TRIMMABLE-BOUNDARY-START(85900525581)
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TValue*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(85900525581);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(85900525581)
                    
                    //--TRIMMABLE-BOUNDARY-START(64425689101)
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TValue*/ item)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(64425689101);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(64425689101)
                    
                    //--TRIMMABLE-BOUNDARY-START(90195492877)
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(90195492877);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(90195492877)
                    
                    //--TRIMMABLE-BOUNDARY-START(154620002317)
                    /*int */ System$Collections$IList$Add(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(154620002317);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(154620002317)
                    
                    //--TRIMMABLE-BOUNDARY-START(158914969613)
                    /*void */ System$Collections$IList$Clear()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(158914969613);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(158914969613)
                    
                    //--TRIMMABLE-BOUNDARY-START(163209936909)
                    /*bool */ System$Collections$IList$Contains(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(163209936909);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            let tvalue;
                            return value === null && $.$default(TValue) === null ? this._dictionary.ContainsValue($.$default(TValue)) : $.$is(value, TValue, { set $v(v){ tvalue = v; } }) && this._dictionary.ContainsValue(tvalue);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(163209936909)
                    
                    //--TRIMMABLE-BOUNDARY-START(193274707981)
                    /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(193274707981);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Entry[]?*/ let entries = this._dictionary._entries;
                        if (!(entries === null))
                        {
                            /*int*/ let count = this._dictionary._count;
                            let tvalue;
                            if (value === null && $.$default(TValue) === null)
                            {
                                for(/*int*/ let i = 0; i < count; i++)
                                {
                                    if ($.$$.System.Array.$ReadT1.call(entries, i).Value === null)
                                    {
                                        return i;
                                    }
                                }
                            }
                            else if ($.$is(value, TValue, { set $v(v){ tvalue = v; } }))
                            {
                                for(/*int*/ let i = 0; i < count; i++)
                                {
                                    if ($.$$.System.Collections.Generic.EqualityComparer$$(TValue).Default.Equals$2(tvalue, $.$$.System.Array.$ReadT1.call(entries, i).Value))
                                    {
                                        return i;
                                    }
                                }
                            }
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(193274707981)
                    
                    //--TRIMMABLE-BOUNDARY-START(197569675277)
                    /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(197569675277);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(197569675277)
                    
                    //--TRIMMABLE-BOUNDARY-START(210454577165)
                    /*void */ System$Collections$IList$Remove(/*object?*/ value)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(210454577165);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(210454577165)
                    
                    //--TRIMMABLE-BOUNDARY-START(214749544461)
                    /*void */ System$Collections$IList$RemoveAt(/*int*/ index)
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(214749544461);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$$.System.NotSupportedException().$ctor$9();
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(214749544461)
                    
                    //--TRIMMABLE-BOUNDARY-START(120260263949)
                    /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(120260263949);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$$.System.ArgumentNullException.ThrowIfNull$2(array, "array");
                        if ($.$$.System.Array.Rank$get.call(array) !== 1)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_RankMultiDimNotSupported, "array");
                        }
                        if (array.GetLowerBound(0) !== 0)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Arg_NonZeroLowerBound, "array");
                        }
                        $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                        if (((array.length - index) | 0) < this._dictionary.Count)
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Arg_ArrayPlusOffTooSmall);
                        }
                        let values;
                        if ($.$is(array, $.$typeArray(TValue), { set $v(v){ values = v; } }))
                        {
                            this.CopyTo(values, index);
                        }
                        else 
                        {
                            try
                            {
                                let objects;
                                if (!$.$is(array, $.$typeArray($.$$.System.Object), { set $v(v){ objects = v; } }))
                                {
                                    throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                                }
                                var $en6 = this.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var value = $en6.Current;
                                    {
                                        $.$$.System.Array.$WriteT1.call(objects, $.$box(value, TValue), index++);
                                    }
                                }
                            }
                            catch($e)
                            {
                                throw new $.$$.System.ArgumentException().$ctor$13($.$sc.System.SR.Argument_IncompatibleArrayType, "array");
                            }
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(120260263949)
                    
                    //--TRIMMABLE-BOUNDARY-START(1245197)
                    static $_Enumerator;
                    static get Enumerator()
                    {
                        let $cls = $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).ValueCollection;
                        return $cls.$_Enumerator ??= $asm.$nstr("$sc.System.Collections.Generic.OrderedDictionary$$$.ValueCollection.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296212493)
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  get _enumerator() { return this.$getField(0, 21); }
                            /*OrderedDictionary<TKey, TValue>.Enumerator*/  set _enumerator(value) { this.$setField(0, 21, value); }
                            //--TRIMMABLE-BOUNDARY-END(4296212493)
                            
                            //--TRIMMABLE-BOUNDARY-START(12886147085)
                            $ctor$3(/*OrderedDictionary<TKey, TValue>*/ dictionary)
                            {
                                super.$ctor$1();
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(12886147085);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    this._enumerator = dictionary.GetEnumerator();
                                }
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12886147085)
                            
                            //--TRIMMABLE-BOUNDARY-START(17181114381)
                            /*TValue */ get Current()
                            {
                                return this._enumerator.Current.Value;
                            }
                            //--TRIMMABLE-BOUNDARY-END(17181114381)
                            
                            //--TRIMMABLE-BOUNDARY-START(34360983565)
                            /*object? */ get System$Collections$IEnumerator$Current()
                            {
                                return $.$box(this.Current, TValue);
                            }
                            //--TRIMMABLE-BOUNDARY-END(34360983565)
                            
                            //--TRIMMABLE-BOUNDARY-START(30066016269)
                            /*bool */ MoveNext()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(30066016269);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return this._enumerator.MoveNext();
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(30066016269)
                            
                            //--TRIMMABLE-BOUNDARY-START(47245885453)
                            /*void */ System$Collections$IEnumerator$Reset()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                                    $.$trace(47245885453);
                                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                                    return $.$sc.System.Collections.Generic.EnumerableHelpers.Reset($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(47245885453)
                            
                            //--TRIMMABLE-BOUNDARY-START(51540852749)
                            /*void */ System$IDisposable$Dispose()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(51540852749);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                            }
                            //--TRIMMABLE-BOUNDARY-END(51540852749)
                            
                            //--TRIMMABLE-BOUNDARY-START(12944605185)
                            //Generated interface implemetation for System.Collections.Generic.IEnumerator<TValue>.Current.get
                            get System$Collections$Generic$IEnumerator$$$Current()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(4354670593);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.Current;
                            }
                            //--TRIMMABLE-BOUNDARY-END(12944605185)
                            
                            //--TRIMMABLE-BOUNDARY-START(17242652673)
                            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                            System$Collections$IEnumerator$MoveNext()
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(17242652673);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return this.MoveNext(...arguments);
                            }
                            //--TRIMMABLE-BOUNDARY-END(17242652673)
                            
                            //--TRIMMABLE-BOUNDARY-START(8591179789)
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            //--TRIMMABLE-BOUNDARY-END(8591179789)
                            
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                copy._enumerator = this._enumerator.Clone();
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //--TRIMMABLE-BOUNDARY-START(4296212493)
                                this._enumerator = $.$default($.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).Enumerator);
                                //--TRIMMABLE-BOUNDARY-END(4296212493)
                                
                            }
                            static $h = 1245197;
                            static $z = 21;
                            static $f = 0b10000001011000001;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 1179661,
  "h": 1245197
}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IEnumerator$$(TValue), $.$$.System.IDisposable, $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection.Enumerator`; }
                        }, $cls, ($v) => $cls.$_Enumerator = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(1245197)
                    
                    //--TRIMMABLE-BOUNDARY-START(30124081153)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21534146561);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30124081153)
                    
                    //--TRIMMABLE-BOUNDARY-START(17239179265)
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TValue>.CopyTo(TValue[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17239179265);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.CopyTo(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(17239179265)
                    
                    //--TRIMMABLE-BOUNDARY-START(12944932865)
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TValue>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4354998273);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12944932865)
                    
                    //--TRIMMABLE-BOUNDARY-START(17242259457)
                    //Generated interface implemetation for System.Collections.ICollection.Count.get
                    get System$Collections$ICollection$Count()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8652324865);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Count;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17242259457)
                    
                    static $h = 1179661;
                    static $f = 0b10000000011010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": $.$sc.System.Collections.Generic.OrderedDictionary$$$(TKey, TValue).$h,
  "h": 1179661
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IList$$(TValue), $.$$.System.Collections.Generic.ICollection$$(TValue), $.$$.System.Collections.Generic.IReadOnlyList$$(TValue), $.$$.System.Collections.Generic.IReadOnlyCollection$$(TValue), $.$$.System.Collections.Generic.IEnumerable$$(TValue), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>.ValueCollection`; }
                }, $cls, ($v) => $cls.$_ValueCollection = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1179661)
            
            //--TRIMMABLE-BOUNDARY-START(17239375873)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239375873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239375873)
            
            //--TRIMMABLE-BOUNDARY-START(51599114241)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.this[TKey].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51599114241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.set_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(51599114241)
            
            //--TRIMMABLE-BOUNDARY-START(8649441281)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649441281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649441281)
            
            //--TRIMMABLE-BOUNDARY-START(4354473985)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Add(TKey, TValue)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354473985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354473985)
            
            //--TRIMMABLE-BOUNDARY-START(43009179649)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.Remove(TKey)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009179649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009179649)
            
            //--TRIMMABLE-BOUNDARY-START(60189048833)
            //Generated interface implemetation for System.Collections.Generic.IDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60189048833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(60189048833)
            
            //--TRIMMABLE-BOUNDARY-START(4355063809)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.ContainsKey(TKey)
            System$Collections$Generic$IReadOnlyDictionary$$$$ContainsKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4355063809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ContainsKey(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4355063809)
            
            //--TRIMMABLE-BOUNDARY-START(43009769473)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.TryGetValue(TKey, out TValue)
            System$Collections$Generic$IReadOnlyDictionary$$$$TryGetValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43009769473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryGetValue$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(43009769473)
            
            //--TRIMMABLE-BOUNDARY-START(12944998401)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyDictionary<TKey, TValue>.this[TKey].get
            System$Collections$Generic$IReadOnlyDictionary$$$$get_Item()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944998401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.get_Item$1(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944998401)
            
            //--TRIMMABLE-BOUNDARY-START(8652455937)
            //Generated interface implemetation for System.Collections.IDictionary.Clear()
            System$Collections$IDictionary$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652455937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652455937)
            
            //--TRIMMABLE-BOUNDARY-START(21534736385)
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<TKey, TValue>>.RemoveAt(int)
            System$Collections$Generic$IList$$$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534736385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(21534736385)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944932865)
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<TKey, TValue>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354998273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(12944932865)
            
            //--TRIMMABLE-BOUNDARY-START(8652914689)
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652914689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8652914689)
            
            //--TRIMMABLE-BOUNDARY-START(64487489537)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64487489537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64487489537)
            
            //--TRIMMABLE-BOUNDARY-START(17242259457)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8652324865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242259457)
            
            static $h = 851981;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "r": 2,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$(TKey, TValue), $.$$.System.Collections.Generic.IReadOnlyDictionary$$$(TKey, TValue), $.$$.System.Collections.IDictionary, $.$$.System.Collections.Generic.IList$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IReadOnlyList$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TValue)), $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Collections.Generic.OrderedDictionary<${TKey?.$fullName},${TValue?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(851981)
        
        
        //--TRIMMABLE-BOUNDARY-START(3080205)
        $asm.$cls("$sc.System.Collections.Generic.TreeSet<>", (T) => $asm.$gt("$sc.System.Collections.Generic.TreeSet<>", [T], ($self) => class TreeSet$$ extends $.$sc.System.Collections.Generic.SortedSet$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(4298047501)
            $ctor$6()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298047501);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298047501)
            
            //--TRIMMABLE-BOUNDARY-START(8593014797)
            $ctor$7(/*IComparer<T>?*/ comparer)
            {
                super.$ctor$2(comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8593014797);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8593014797)
            
            //--TRIMMABLE-BOUNDARY-START(17182949389)
            $ctor$9(/*TreeSet<T>*/ set, /*IComparer<T>?*/ comparer)
            {
                super.$ctor$3(set, comparer);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182949389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182949389)
            
            //--TRIMMABLE-BOUNDARY-START(12887982093)
            $ctor$8(/*SerializationInfo*/ siInfo, /*StreamingContext*/ context)
            {
                super.$ctor$5(siInfo, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887982093);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887982093)
            
            //--TRIMMABLE-BOUNDARY-START(21477916685)
            /*bool */ AddIfNotPresent(/*T*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477916685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let ret = super.AddIfNotPresent(item);
                if (!ret)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sc.System.SR.Format$6($.$sc.System.SR.Argument_AddingDuplicate, $.$box(item, T)));
                }
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(21477916685)
            
            static $h = 3080205;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$sc.System.Collections.Generic.SortedSet$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ISet$$(T), $.$$.System.Collections.Generic.ICollection$$(T), $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlySet$$(T), $.$$.System.Collections.Generic.IReadOnlyCollection$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.Collections.Generic.TreeSet<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(3080205)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(13)
