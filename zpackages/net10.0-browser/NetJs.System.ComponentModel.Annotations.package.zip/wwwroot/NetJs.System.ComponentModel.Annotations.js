
//--TRIMMABLE-BOUNDARY-START(39)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $scm, $so, $scp, $scs, $sdp, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $srw, $srl, $srsf, $sre, $srei, $srel, $srp, $str, $sdts, $sle, $sicb, $snn, $stc, $snq, $srij, $snh, $spx, $spxl, $sxxd, $sct) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel.Annotations", 
    {
  "h": 39,
  "f": "System.ComponentModel.Annotations",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.ComponentModel.Annotations",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.ComponentModel.Annotations",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1507367)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.IValidatableObject", ($self) => class IValidatableObject
        {
            static $h = 1507367;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296474663),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "Validate",
      "o": "System$ComponentModel$DataAnnotations$IValidatableObject$Validate",
      "d": 1507367,
      "h": 4296474663,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296474663)
  ],
  "h": 1507367
}; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.IValidatableObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507367)
        
        
        //--TRIMMABLE-BOUNDARY-START(3211303)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationAttribute", ($self) => class ValidationAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8593145895)
            /*string?*/ _errorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8593145895)
            
            //--TRIMMABLE-BOUNDARY-START(12888113191)
            /*Func<string>?*/ _errorMessageResourceAccessor = null;
            //--TRIMMABLE-BOUNDARY-END(12888113191)
            
            //--TRIMMABLE-BOUNDARY-START(17183080487)
            /*string?*/ _errorMessageResourceName = null;
            //--TRIMMABLE-BOUNDARY-END(17183080487)
            
            //--TRIMMABLE-BOUNDARY-START(21478047783)
            /*Type?*/ _errorMessageResourceType = null;
            //--TRIMMABLE-BOUNDARY-END(21478047783)
            
            //--TRIMMABLE-BOUNDARY-START(25773015079)
            /*bool*/ _hasBaseIsValid = false;
            //--TRIMMABLE-BOUNDARY-END(25773015079)
            
            //--TRIMMABLE-BOUNDARY-START(4298178599)
            /*string?*/ _defaultErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(4298178599)
            
            //--TRIMMABLE-BOUNDARY-START(34362949671)
            $ctor$2()
            {
                this.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.ValidationAttribute_ValidationError;
                }, {
  "r": 1310721,
  "n": "",
  "d": 3211303,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34362949671);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34362949671)
            
            //--TRIMMABLE-BOUNDARY-START(47247851559)
            $ctor$5(/*string*/ errorMessage)
            {
                this.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return errorMessage;
                }, {
  "r": 1310721,
  "n": "",
  "d": 3211303,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47247851559);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47247851559)
            
            //--TRIMMABLE-BOUNDARY-START(42952884263)
            $ctor$4(/*Func<string>*/ errorMessageAccessor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42952884263);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._errorMessageResourceAccessor = errorMessageAccessor;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42952884263)
            
            //--TRIMMABLE-BOUNDARY-START(38657916967)
            $ctor$3(/*bool*/ populateErrorMessageResourceAccessor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38657916967);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(populateErrorMessageResourceAccessor === false, "Use the default constructor instead");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38657916967)
            
            //--TRIMMABLE-BOUNDARY-START(60132753447)
            /*string? */ set DefaultErrorMessage(value)
            {
                this._defaultErrorMessage = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(60132753447)
            
            //--TRIMMABLE-BOUNDARY-START(68722688039)
            /*Func<string> */ set ErrorMessageResourceAccessor(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._defaultErrorMessage === null && this._errorMessageResourceName === null && this._errorMessage === null && this._errorMessageResourceType === null, "_defaultErrorMessage is null && _errorMessageResourceName is null && _errorMessage is null && _errorMessageResourceType is null");
                this._errorMessageResourceAccessor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68722688039)
            
            //--TRIMMABLE-BOUNDARY-START(81607589927)
            /*string */ get ErrorMessageString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852230183);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetupResourceAccessor();
                return this._errorMessageResourceAccessor.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(81607589927)
            
            //--TRIMMABLE-BOUNDARY-START(55837786151)
            /*bool*/ CustomErrorMessageSet = false;
            //--TRIMMABLE-BOUNDARY-END(55837786151)
            
            //--TRIMMABLE-BOUNDARY-START(154622033959)
            /*bool */ get RequiresValidationContext()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(154622033959)
            
            //--TRIMMABLE-BOUNDARY-START(64427720743)
            /*string? */ get ErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103082426407);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._errorMessage ?? this._defaultErrorMessage;
            }
            /*string? */ set ErrorMessage(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180391837735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._errorMessage = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
                if ($.$$.System.String.op_Equality(value, null))
                {
                    this._defaultErrorMessage = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64427720743)
            
            //--TRIMMABLE-BOUNDARY-START(73017655335)
            /*string? */ get ErrorMessageResourceName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111672360999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._errorMessageResourceName;
            }
            /*string? */ set ErrorMessageResourceName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197571706919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._errorMessageResourceName = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(73017655335)
            
            //--TRIMMABLE-BOUNDARY-START(77312622631)
            /*Type? */ get ErrorMessageResourceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120262295591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._errorMessageResourceType;
            }
            /*Type? */ set ErrorMessageResourceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206161641511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._errorMessageResourceType = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            //--TRIMMABLE-BOUNDARY-END(77312622631)
            
            //--TRIMMABLE-BOUNDARY-START(214751576103)
            /*void */ SetupResourceAccessor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214751576103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._errorMessageResourceAccessor === null)
                {
                    /*string?*/ let localErrorMessage = this.ErrorMessage;
                    /*bool*/ let resourceNameSet = !$.$$.System.String.IsNullOrEmpty(this._errorMessageResourceName);
                    /*bool*/ let errorMessageSet = !$.$$.System.String.IsNullOrEmpty(this._errorMessage);
                    /*bool*/ let resourceTypeSet = $.$$.System.Type.op_Inequality$1(this._errorMessageResourceType, null);
                    /*bool*/ let defaultMessageSet = !$.$$.System.String.IsNullOrEmpty(this._defaultErrorMessage);
                    if ((resourceNameSet && errorMessageSet) || !(resourceNameSet || errorMessageSet || defaultMessageSet))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.ValidationAttribute_Cannot_Set_ErrorMessage_And_Resource);
                    }
                    if (resourceTypeSet !== resourceNameSet)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.ValidationAttribute_NeedBothResourceTypeAndResourceName);
                    }
                    if (resourceNameSet)
                    {
                        this.SetResourceAccessorByPropertyLookup();
                    }
                    else 
                    {
                        this._errorMessageResourceAccessor = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                        {
                            return localErrorMessage;
                        }, {
  "r": 1310721,
  "n": "",
  "d": 3211303,
  "h": 0,
  "f": 17825794
});
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214751576103)
            
            //--TRIMMABLE-BOUNDARY-START(210456608807)
            /*void */ SetResourceAccessorByPropertyLookup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210456608807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(this._errorMessageResourceType, null), "_errorMessageResourceType != null");
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.String.IsNullOrEmpty(this._errorMessageResourceName), "!string.IsNullOrEmpty(_errorMessageResourceName)");
                /*var*/ let property = this._errorMessageResourceType.GetProperty$1(this._errorMessageResourceName, 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/ | 2/*BindingFlags.DeclaredOnly*/);
                if ($.$$.System.Reflection.PropertyInfo.op_Inequality$1(property, null))
                {
                    /*var*/ let propertyGetter = property.GetMethod;
                    if ($.$$.System.Reflection.MethodInfo.op_Equality$2(propertyGetter, null) || (!propertyGetter.IsAssembly$1 && !propertyGetter.IsPublic$1))
                    {
                        property = null;
                    }
                }
                if ($.$$.System.Reflection.PropertyInfo.op_Equality$1(property, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.ValidationAttribute_ResourceTypeDoesNotHaveProperty, this._errorMessageResourceType.FullName, this._errorMessageResourceName));
                }
                if ($.$$.System.Type.op_Inequality$1(property.PropertyType, $.$$.System.String.$type))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.ValidationAttribute_ResourcePropertyNotStringType, property.Name, this._errorMessageResourceType.FullName));
                }
                this._errorMessageResourceAccessor = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$cast(property.GetValue(null, null), $.$$.System.String);
                }, {
  "r": 1310721,
  "n": "",
  "d": 3211303,
  "h": 0,
  "f": 17825794
});
            }
            //--TRIMMABLE-BOUNDARY-END(210456608807)
            
            //--TRIMMABLE-BOUNDARY-START(51542818855)
            /*ValidationResult */ CreateFailedValidationResult(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542818855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memberName;
                /*string[]?*/ let memberNames = validationContext.MemberName !== null && ((memberName = validationContext.MemberName, memberName != null && true)) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [memberName], null, null) : null;
                return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1(this.FormatErrorMessage(validationContext.DisplayName), memberNames);
            }
            //--TRIMMABLE-BOUNDARY-END(51542818855)
            
            //--TRIMMABLE-BOUNDARY-START(85902557223)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85902557223);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85902557223)
            
            //--TRIMMABLE-BOUNDARY-START(150327066663)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327066663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._hasBaseIsValid)
                {
                    this._hasBaseIsValid = true;
                }
                return this.IsValid(value, null) === $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success;
            }
            //--TRIMMABLE-BOUNDARY-END(150327066663)
            
            //--TRIMMABLE-BOUNDARY-START(146032099367)
            /*ValidationResult? */ IsValid(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032099367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._hasBaseIsValid)
                {
                    throw $.$sca.System.NotImplemented.ByDesignWithMessage($.$sca.System.SR.ValidationAttribute_IsValid_NotImplemented);
                }
                return this.IsValid$1(value) ? $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success : this.CreateFailedValidationResult(validationContext);
            }
            //--TRIMMABLE-BOUNDARY-END(146032099367)
            
            //--TRIMMABLE-BOUNDARY-START(141737132071)
            /*ValidationResult? */ GetValidationResult(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737132071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                /*var*/ let result = this.IsValid(value, validationContext);
                if (result !== null)
                {
                    if ($.$$.System.String.IsNullOrEmpty(result.ErrorMessage))
                    {
                        /*var*/ let errorMessage = this.FormatErrorMessage(validationContext.DisplayName);
                        result = new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1(errorMessage, result.MemberNames);
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(141737132071)
            
            //--TRIMMABLE-BOUNDARY-START(219046543399)
            /*void */ Validate(/*object?*/ value, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219046543399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.IsValid$1(value))
                {
                    throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$8(this.FormatErrorMessage(name), this, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219046543399)
            
            //--TRIMMABLE-BOUNDARY-START(223341510695)
            /*void */ Validate$1(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223341510695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                /*ValidationResult?*/ let result = this.GetValidationResult(value, validationContext);
                if (result !== null)
                {
                    throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$10(result, this, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223341510695)
            
            static $h = 3211303;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60132753447),
    {
      "p": 1310721,
      "s": {
        "r": 0,
        "d": 0,
        "h": 171801903143,
        "f": 83886080
      },
      "n": "DefaultErrorMessage",
      "d": 3211303,
      "h": 60132753447,
      "f": 2097152
    },
//--TRIMMABLE-BOUNDARY-END(60132753447),
//--TRIMMABLE-BOUNDARY-START(68722688039),
    {
      "p": $.$$.System.Func$$($.$$.System.String).$h,
      "s": {
        "r": 0,
        "d": 0,
        "h": 188981772327,
        "f": 83886080
      },
      "n": "ErrorMessageResourceAccessor",
      "d": 3211303,
      "h": 68722688039,
      "f": 2097152
    },
//--TRIMMABLE-BOUNDARY-END(68722688039),
//--TRIMMABLE-BOUNDARY-START(81607589927),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128852230183,
        "f": 50331652
      },
      "n": "ErrorMessageString",
      "d": 3211303,
      "h": 81607589927,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(81607589927),
//--TRIMMABLE-BOUNDARY-START(55837786151),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94492491815,
        "f": 50331656
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163211968551,
        "f": 83886082
      },
      "n": "CustomErrorMessageSet",
      "d": 3211303,
      "h": 55837786151,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55837786151),
//--TRIMMABLE-BOUNDARY-START(154622033959),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137442164775,
        "f": 50331777
      },
      "n": "RequiresValidationContext",
      "d": 3211303,
      "h": 154622033959,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(154622033959),
//--TRIMMABLE-BOUNDARY-START(64427720743),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103082426407,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180391837735,
        "f": 83886081
      },
      "n": "ErrorMessage",
      "d": 3211303,
      "h": 64427720743,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427720743),
//--TRIMMABLE-BOUNDARY-START(73017655335),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111672360999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197571706919,
        "f": 83886081
      },
      "n": "ErrorMessageResourceName",
      "d": 3211303,
      "h": 73017655335,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017655335),
//--TRIMMABLE-BOUNDARY-START(77312622631),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120262295591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206161641511,
        "f": 83886081
      },
      "n": "ErrorMessageResourceType",
      "d": 3211303,
      "h": 77312622631,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77312622631)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(214751576103),
    {
      "r": 65537,
      "n": "SetupResourceAccessor",
      "d": 3211303,
      "h": 214751576103,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(214751576103),
//--TRIMMABLE-BOUNDARY-START(210456608807),
    {
      "r": 65537,
      "n": "SetResourceAccessorByPropertyLookup",
      "d": 3211303,
      "h": 210456608807,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(210456608807),
//--TRIMMABLE-BOUNDARY-START(51542818855),
    {
      "r": 3670055,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "CreateFailedValidationResult",
      "d": 3211303,
      "h": 51542818855,
      "f": 16777216
    },
//--TRIMMABLE-BOUNDARY-END(51542818855),
//--TRIMMABLE-BOUNDARY-START(85902557223),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 3211303,
      "h": 85902557223,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85902557223),
//--TRIMMABLE-BOUNDARY-START(150327066663),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 3211303,
      "h": 150327066663,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150327066663),
//--TRIMMABLE-BOUNDARY-START(146032099367),
    {
      "r": 3670055,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "IsValid",
      "d": 3211303,
      "h": 146032099367,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(146032099367),
//--TRIMMABLE-BOUNDARY-START(141737132071),
    {
      "r": 3670055,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetValidationResult",
      "d": 3211303,
      "h": 141737132071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141737132071),
//--TRIMMABLE-BOUNDARY-START(219046543399),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Validate",
      "d": 3211303,
      "h": 219046543399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219046543399),
//--TRIMMABLE-BOUNDARY-START(223341510695),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "Validate",
      "o": "@$1",
      "d": 3211303,
      "h": 223341510695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(223341510695)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593145895),
    {
      "t": 1310721,
      "n": "_errorMessage",
      "d": 3211303,
      "h": 8593145895,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593145895),
//--TRIMMABLE-BOUNDARY-START(12888113191),
    {
      "t": $.$$.System.Func$$($.$$.System.String).$h,
      "n": "_errorMessageResourceAccessor",
      "d": 3211303,
      "h": 12888113191,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888113191),
//--TRIMMABLE-BOUNDARY-START(17183080487),
    {
      "t": 1310721,
      "n": "_errorMessageResourceName",
      "d": 3211303,
      "h": 17183080487,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17183080487),
//--TRIMMABLE-BOUNDARY-START(21478047783),
    {
      "t": 187760641,
      "n": "_errorMessageResourceType",
      "d": 3211303,
      "h": 21478047783,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21478047783),
//--TRIMMABLE-BOUNDARY-START(25773015079),
    {
      "t": 262145,
      "n": "_hasBaseIsValid",
      "d": 3211303,
      "h": 25773015079,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25773015079),
//--TRIMMABLE-BOUNDARY-START(4298178599),
    {
      "t": 1310721,
      "n": "_defaultErrorMessage",
      "d": 3211303,
      "h": 4298178599,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298178599)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34362949671),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3211303,
      "h": 34362949671,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34362949671),
//--TRIMMABLE-BOUNDARY-START(47247851559),
    {
      "p": [
        {
          "n": "errorMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 3211303,
      "h": 47247851559,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(47247851559),
//--TRIMMABLE-BOUNDARY-START(42952884263),
    {
      "p": [
        {
          "n": "errorMessageAccessor",
          "p": $.$$.System.Func$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3211303,
      "h": 42952884263,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(42952884263),
//--TRIMMABLE-BOUNDARY-START(38657916967),
    {
      "p": [
        {
          "n": "populateErrorMessageResourceAccessor",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3211303,
      "h": 38657916967,
      "f": 16777216
    },
//--TRIMMABLE-BOUNDARY-END(38657916967)
  ],
  "h": 3211303
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3211303)
        
        
        //--TRIMMABLE-BOUNDARY-START(3866663)
        $asm.$cls("$sca.System.NotImplemented", ($self) => class NotImplemented
        {
            //--TRIMMABLE-BOUNDARY-START(4298833959)
            static /*Exception */ get ByDesign()
            {
                return new $.$$.System.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4298833959)
            
            //--TRIMMABLE-BOUNDARY-START(8593801255)
            static /*Exception */ ByDesignWithMessage(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593801255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.NotImplementedException().$ctor$12(message);
            }
            //--TRIMMABLE-BOUNDARY-END(8593801255)
            
            static $h = 3866663;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(4298833959),
    {
      "p": 80019457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183735847,
        "f": 50331688
      },
      "n": "ByDesign",
      "d": 3866663,
      "h": 4298833959,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(4298833959)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593801255),
    {
      "r": 80019457,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ByDesignWithMessage",
      "d": 3866663,
      "h": 8593801255,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8593801255)
  ],
  "h": 3866663
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.NotImplemented`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3866663)
        
        
        //--TRIMMABLE-BOUNDARY-START(3997735)
        $asm.$cls("$sca.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(1000731377703)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(1000731377703)
            
            //--TRIMMABLE-BOUNDARY-START(992141443111)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(992141443111)
            
            //--TRIMMABLE-BOUNDARY-START(996436410407)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738738372647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sca.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.ComponentModel.Annotations", $.$sca.System.SR.$type.Assembly);
                    $.$sca.System.SR.s_resourceManager = temp;
                }
                return $.$sca.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(996436410407)
            
            //--TRIMMABLE-BOUNDARY-START(42953670695)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403730923559);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sca.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1013616279591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42953670695)
            
            //--TRIMMABLE-BOUNDARY-START(8593932327)
            static /*string */ get AllowedValuesAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335011446823);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field does not equal any of the values specified in AllowedValuesAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(8593932327)
            
            //--TRIMMABLE-BOUNDARY-START(146032885799)
            static /*string */ FormatAllowedValuesAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146032885799);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field does not equal any of the values specified in AllowedValuesAttribute.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146032885799)
            
            //--TRIMMABLE-BOUNDARY-START(12888899623)
            static /*string */ get AssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343601381415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The associated metadata type for type '{0}' contains the following unknown properties or fields: {1}. Please make sure that the names of these members match the names of the properties on the main type.";
            }
            //--TRIMMABLE-BOUNDARY-END(12888899623)
            
            //--TRIMMABLE-BOUNDARY-START(150327853095)
            static /*string */ FormatAssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150327853095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The associated metadata type for type '{0}' contains the following unknown properties or fields: {1}. Please make sure that the names of these members match the names of the properties on the main type.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(150327853095)
            
            //--TRIMMABLE-BOUNDARY-START(17183866919)
            static /*string */ get AttributeStore_Unknown_Property()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352191316007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type '{0}' does not contain a public property named '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17183866919)
            
            //--TRIMMABLE-BOUNDARY-START(154622820391)
            static /*string */ FormatAttributeStore_Unknown_Property(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154622820391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The type '{0}' does not contain a public property named '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(154622820391)
            
            //--TRIMMABLE-BOUNDARY-START(21478834215)
            static /*string */ get Base64StringAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360781250599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is not a valid Base64 encoding.";
            }
            //--TRIMMABLE-BOUNDARY-END(21478834215)
            
            //--TRIMMABLE-BOUNDARY-START(158917787687)
            static /*string */ FormatBase64StringAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158917787687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is not a valid Base64 encoding.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(158917787687)
            
            //--TRIMMABLE-BOUNDARY-START(25773801511)
            static /*string */ get Common_PropertyNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369371185191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The property {0}.{1} could not be found.";
            }
            //--TRIMMABLE-BOUNDARY-END(25773801511)
            
            //--TRIMMABLE-BOUNDARY-START(163212754983)
            static /*string */ FormatCommon_PropertyNotFound(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163212754983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The property {0}.{1} could not be found.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(163212754983)
            
            //--TRIMMABLE-BOUNDARY-START(30068768807)
            static /*string */ get CompareAttribute_MustMatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377961119783);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' and '{1}' do not match.";
            }
            //--TRIMMABLE-BOUNDARY-END(30068768807)
            
            //--TRIMMABLE-BOUNDARY-START(167507722279)
            static /*string */ FormatCompareAttribute_MustMatch(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167507722279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("'{0}' and '{1}' do not match.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(167507722279)
            
            //--TRIMMABLE-BOUNDARY-START(34363736103)
            static /*string */ get CompareAttribute_UnknownProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386551054375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a property named {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(34363736103)
            
            //--TRIMMABLE-BOUNDARY-START(171802689575)
            static /*string */ FormatCompareAttribute_UnknownProperty(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171802689575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find a property named {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(171802689575)
            
            //--TRIMMABLE-BOUNDARY-START(38658703399)
            static /*string */ get CreditCardAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395140988967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is not a valid credit card number.";
            }
            //--TRIMMABLE-BOUNDARY-END(38658703399)
            
            //--TRIMMABLE-BOUNDARY-START(176097656871)
            static /*string */ FormatCreditCardAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176097656871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is not a valid credit card number.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176097656871)
            
            //--TRIMMABLE-BOUNDARY-START(47248637991)
            static /*string */ get CustomValidationAttribute_Method_Must_Return_ValidationResult()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412320858151);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The CustomValidationAttribute method '{0}' in type '{1}' must return System.ComponentModel.DataAnnotations.ValidationResult.  Use System.ComponentModel.DataAnnotations.ValidationResult.Success to represent success.";
            }
            //--TRIMMABLE-BOUNDARY-END(47248637991)
            
            //--TRIMMABLE-BOUNDARY-START(180392624167)
            static /*string */ FormatCustomValidationAttribute_Method_Must_Return_ValidationResult(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180392624167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The CustomValidationAttribute method '{0}' in type '{1}' must return System.ComponentModel.DataAnnotations.ValidationResult.  Use System.ComponentModel.DataAnnotations.ValidationResult.Success to represent success.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(180392624167)
            
            //--TRIMMABLE-BOUNDARY-START(51543605287)
            static /*string */ get CustomValidationAttribute_Method_Not_Found()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420910792743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The CustomValidationAttribute method '{0}' does not exist in type '{1}' or is not public and static.";
            }
            //--TRIMMABLE-BOUNDARY-END(51543605287)
            
            //--TRIMMABLE-BOUNDARY-START(184687591463)
            static /*string */ FormatCustomValidationAttribute_Method_Not_Found(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184687591463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The CustomValidationAttribute method '{0}' does not exist in type '{1}' or is not public and static.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(184687591463)
            
            //--TRIMMABLE-BOUNDARY-START(55838572583)
            static /*string */ get CustomValidationAttribute_Method_Required()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429500727335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The CustomValidationAttribute.Method was not specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(55838572583)
            
            //--TRIMMABLE-BOUNDARY-START(60133539879)
            static /*string */ get CustomValidationAttribute_Method_Signature()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438090661927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The CustomValidationAttribute method '{0}' in type '{1}' must match the expected signature: public static ValidationResult {0}(object value, ValidationContext context).  The value can be strongly typed.  The ValidationContext parameter is optional.";
            }
            //--TRIMMABLE-BOUNDARY-END(60133539879)
            
            //--TRIMMABLE-BOUNDARY-START(188982558759)
            static /*string */ FormatCustomValidationAttribute_Method_Signature(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188982558759);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The CustomValidationAttribute method '{0}' in type '{1}' must match the expected signature: public static ValidationResult {0}(object value, ValidationContext context).  The value can be strongly typed.  The ValidationContext parameter is optional.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(188982558759)
            
            //--TRIMMABLE-BOUNDARY-START(64428507175)
            static /*string */ get CustomValidationAttribute_Type_Conversion_Failed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446680596519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not convert the value of type '{0}' to '{1}' as expected by method {2}.{3}.";
            }
            //--TRIMMABLE-BOUNDARY-END(64428507175)
            
            //--TRIMMABLE-BOUNDARY-START(193277526055)
            static /*string */ FormatCustomValidationAttribute_Type_Conversion_Failed(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193277526055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$11("Could not convert the value of type '{0}' to '{1}' as expected by method {2}.{3}.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(193277526055)
            
            //--TRIMMABLE-BOUNDARY-START(68723474471)
            static /*string */ get CustomValidationAttribute_Type_Must_Be_Public()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455270531111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The custom validation type '{0}' must be public.";
            }
            //--TRIMMABLE-BOUNDARY-END(68723474471)
            
            //--TRIMMABLE-BOUNDARY-START(197572493351)
            static /*string */ FormatCustomValidationAttribute_Type_Must_Be_Public(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197572493351);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The custom validation type '{0}' must be public.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(197572493351)
            
            //--TRIMMABLE-BOUNDARY-START(73018441767)
            static /*string */ get CustomValidationAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463860465703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(73018441767)
            
            //--TRIMMABLE-BOUNDARY-START(201867460647)
            static /*string */ FormatCustomValidationAttribute_ValidationError(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201867460647);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("{0} is not valid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(201867460647)
            
            //--TRIMMABLE-BOUNDARY-START(77313409063)
            static /*string */ get CustomValidationAttribute_ValidatorType_Required()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472450400295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The CustomValidationAttribute.ValidatorType was not specified.";
            }
            //--TRIMMABLE-BOUNDARY-END(77313409063)
            
            //--TRIMMABLE-BOUNDARY-START(81608376359)
            static /*string */ get DataTypeAttribute_EmptyDataTypeString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481040334887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The custom DataType string cannot be null or empty.";
            }
            //--TRIMMABLE-BOUNDARY-END(81608376359)
            
            //--TRIMMABLE-BOUNDARY-START(85903343655)
            static /*string */ get DeniedValuesAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489630269479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field equals one of the values specified in DeniedValuesAttribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(85903343655)
            
            //--TRIMMABLE-BOUNDARY-START(206162427943)
            static /*string */ FormatDeniedValuesAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206162427943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field equals one of the values specified in DeniedValuesAttribute.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(206162427943)
            
            //--TRIMMABLE-BOUNDARY-START(90198310951)
            static /*string */ get DisplayAttribute_PropertyNotSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498220204071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} property has not been set.  Use the {1} method to get the value.";
            }
            //--TRIMMABLE-BOUNDARY-END(90198310951)
            
            //--TRIMMABLE-BOUNDARY-START(210457395239)
            static /*string */ FormatDisplayAttribute_PropertyNotSet(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210457395239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The {0} property has not been set.  Use the {1} method to get the value.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(210457395239)
            
            //--TRIMMABLE-BOUNDARY-START(94493278247)
            static /*string */ get EmailAddressAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506810138663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is not a valid e-mail address.";
            }
            //--TRIMMABLE-BOUNDARY-END(94493278247)
            
            //--TRIMMABLE-BOUNDARY-START(214752362535)
            static /*string */ FormatEmailAddressAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214752362535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is not a valid e-mail address.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(214752362535)
            
            //--TRIMMABLE-BOUNDARY-START(98788245543)
            static /*string */ get EnumDataTypeAttribute_TypeCannotBeNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515400073255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type provided for EnumDataTypeAttribute cannot be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(98788245543)
            
            //--TRIMMABLE-BOUNDARY-START(103083212839)
            static /*string */ get EnumDataTypeAttribute_TypeNeedsToBeAnEnum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523990007847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type '{0}' needs to represent an enumeration type.";
            }
            //--TRIMMABLE-BOUNDARY-END(103083212839)
            
            //--TRIMMABLE-BOUNDARY-START(219047329831)
            static /*string */ FormatEnumDataTypeAttribute_TypeNeedsToBeAnEnum(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219047329831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The type '{0}' needs to represent an enumeration type.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(219047329831)
            
            //--TRIMMABLE-BOUNDARY-START(107378180135)
            static /*string */ get FileExtensionsAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532579942439);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field only accepts files with the following extensions: {1}";
            }
            //--TRIMMABLE-BOUNDARY-END(107378180135)
            
            //--TRIMMABLE-BOUNDARY-START(223342297127)
            static /*string */ FormatFileExtensionsAttribute_Invalid(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223342297127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The {0} field only accepts files with the following extensions: {1}", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(223342297127)
            
            //--TRIMMABLE-BOUNDARY-START(910537064487)
            static /*string */ get LocalizableString_LocalizationFailed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575529615399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot retrieve property '{0}' because localization failed.  Type '{1}' is not public or does not contain a public static string property with the name '{2}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(910537064487)
            
            //--TRIMMABLE-BOUNDARY-START(236227199015)
            static /*string */ FormatLocalizableString_LocalizationFailed(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236227199015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("Cannot retrieve property '{0}' because localization failed.  Type '{1}' is not public or does not contain a public static string property with the name '{2}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(236227199015)
            
            //--TRIMMABLE-BOUNDARY-START(914832031783)
            static /*string */ get MaxLengthAttribute_InvalidMaxLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584119549991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MaxLengthAttribute must have a Length value that is greater than zero. Use MaxLength() without parameters to indicate that the string or array can have the maximum allowable length.";
            }
            //--TRIMMABLE-BOUNDARY-END(914832031783)
            
            //--TRIMMABLE-BOUNDARY-START(919126999079)
            static /*string */ get MaxLengthAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592709484583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be a string or array type with a maximum length of '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(919126999079)
            
            //--TRIMMABLE-BOUNDARY-START(240522166311)
            static /*string */ FormatMaxLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240522166311);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The field {0} must be a string or array type with a maximum length of '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(240522166311)
            
            //--TRIMMABLE-BOUNDARY-START(923421966375)
            static /*string */ get MetadataTypeAttribute_TypeCannotBeNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601299419175);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MetadataClassType cannot be null.";
            }
            //--TRIMMABLE-BOUNDARY-END(923421966375)
            
            //--TRIMMABLE-BOUNDARY-START(927716933671)
            static /*string */ get MinLengthAttribute_InvalidMinLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609889353767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "MinLengthAttribute must have a Length value that is zero or greater.";
            }
            //--TRIMMABLE-BOUNDARY-END(927716933671)
            
            //--TRIMMABLE-BOUNDARY-START(932011900967)
            static /*string */ get MinLengthAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618479288359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be a string or array type with a minimum length of '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(932011900967)
            
            //--TRIMMABLE-BOUNDARY-START(244817133607)
            static /*string */ FormatMinLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244817133607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The field {0} must be a string or array type with a minimum length of '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(244817133607)
            
            //--TRIMMABLE-BOUNDARY-START(897652162599)
            static /*string */ get LengthAttribute_InvalidMinLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549759811623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "LengthAttribute must have a MinimumLength value that is zero or greater.";
            }
            //--TRIMMABLE-BOUNDARY-END(897652162599)
            
            //--TRIMMABLE-BOUNDARY-START(893357195303)
            static /*string */ get LengthAttribute_InvalidMaxLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541169877031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "LengthAttribute must have a MaximumLength value that is greater than or equal to MinimumLength.";
            }
            //--TRIMMABLE-BOUNDARY-END(893357195303)
            
            //--TRIMMABLE-BOUNDARY-START(906242097191)
            static /*string */ get LengthAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566939680807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be a string or collection type with a minimum length of '{1}' and maximum length of '{2}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(906242097191)
            
            //--TRIMMABLE-BOUNDARY-START(231932231719)
            static /*string */ FormatLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231932231719);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be a string or collection type with a minimum length of '{1}' and maximum length of '{2}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(231932231719)
            
            //--TRIMMABLE-BOUNDARY-START(901947129895)
            static /*string */ get LengthAttribute_InvalidValueType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558349746215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field of type {0} must be a string, array or ICollection type.";
            }
            //--TRIMMABLE-BOUNDARY-END(901947129895)
            
            //--TRIMMABLE-BOUNDARY-START(227637264423)
            static /*string */ FormatLengthAttribute_InvalidValueType(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227637264423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The field of type {0} must be a string, array or ICollection type.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(227637264423)
            
            //--TRIMMABLE-BOUNDARY-START(936306868263)
            static /*string */ get PhoneAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627069222951);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is not a valid phone number.";
            }
            //--TRIMMABLE-BOUNDARY-END(936306868263)
            
            //--TRIMMABLE-BOUNDARY-START(249112100903)
            static /*string */ FormatPhoneAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249112100903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is not a valid phone number.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(249112100903)
            
            //--TRIMMABLE-BOUNDARY-START(940601835559)
            static /*string */ get RangeAttribute_ArbitraryTypeNotIComparable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635659157543);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The type {0} must implement {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(940601835559)
            
            //--TRIMMABLE-BOUNDARY-START(253407068199)
            static /*string */ FormatRangeAttribute_ArbitraryTypeNotIComparable(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253407068199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The type {0} must implement {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(253407068199)
            
            //--TRIMMABLE-BOUNDARY-START(949191770151)
            static /*string */ get RangeAttribute_MinGreaterThanMax()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652839026727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The maximum value '{0}' must be greater than or equal to the minimum value '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(949191770151)
            
            //--TRIMMABLE-BOUNDARY-START(257702035495)
            static /*string */ FormatRangeAttribute_MinGreaterThanMax(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257702035495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The maximum value '{0}' must be greater than or equal to the minimum value '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(257702035495)
            
            //--TRIMMABLE-BOUNDARY-START(944896802855)
            static /*string */ get RangeAttribute_CannotUseExclusiveBoundsWhenTheyAreEqual()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644249092135);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot use exclusive bounds when the maximum value is equal to the minimum value.";
            }
            //--TRIMMABLE-BOUNDARY-END(944896802855)
            
            //--TRIMMABLE-BOUNDARY-START(953486737447)
            static /*string */ get RangeAttribute_Must_Set_Min_And_Max()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661428961319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The minimum and maximum values must be set.";
            }
            //--TRIMMABLE-BOUNDARY-END(953486737447)
            
            //--TRIMMABLE-BOUNDARY-START(957781704743)
            static /*string */ get RangeAttribute_Must_Set_Operand_Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670018895911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The OperandType must be set when strings are used for minimum and maximum values.";
            }
            //--TRIMMABLE-BOUNDARY-END(957781704743)
            
            //--TRIMMABLE-BOUNDARY-START(962076672039)
            static /*string */ get RangeAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704378634279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be between {1} and {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(962076672039)
            
            //--TRIMMABLE-BOUNDARY-START(274881904679)
            static /*string */ FormatRangeAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274881904679);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be between {1} and {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(274881904679)
            
            //--TRIMMABLE-BOUNDARY-START(970666606631)
            static /*string */ get RangeAttribute_ValidationError_MinExclusive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695788699687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be between {1} exclusive and {2}.";
            }
            //--TRIMMABLE-BOUNDARY-END(970666606631)
            
            //--TRIMMABLE-BOUNDARY-START(270586937383)
            static /*string */ FormatRangeAttribute_ValidationError_MinExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270586937383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be between {1} exclusive and {2}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(270586937383)
            
            //--TRIMMABLE-BOUNDARY-START(966371639335)
            static /*string */ get RangeAttribute_ValidationError_MaxExclusive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678608830503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be between {1} and {2} exclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(966371639335)
            
            //--TRIMMABLE-BOUNDARY-START(261997002791)
            static /*string */ FormatRangeAttribute_ValidationError_MaxExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261997002791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be between {1} and {2} exclusive.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(261997002791)
            
            //--TRIMMABLE-BOUNDARY-START(974961573927)
            static /*string */ get RangeAttribute_ValidationError_MinExclusive_MaxExclusive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687198765095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be between {1} exclusive and {2} exclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(974961573927)
            
            //--TRIMMABLE-BOUNDARY-START(266291970087)
            static /*string */ FormatRangeAttribute_ValidationError_MinExclusive_MaxExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266291970087);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be between {1} exclusive and {2} exclusive.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(266291970087)
            
            //--TRIMMABLE-BOUNDARY-START(979256541223)
            static /*string */ get RegexAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712968568871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must match the regular expression '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(979256541223)
            
            //--TRIMMABLE-BOUNDARY-START(279176871975)
            static /*string */ FormatRegexAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279176871975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The field {0} must match the regular expression '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(279176871975)
            
            //--TRIMMABLE-BOUNDARY-START(983551508519)
            static /*string */ get RegularExpressionAttribute_Empty_Pattern()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721558503463);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The pattern must be set to a valid regular expression.";
            }
            //--TRIMMABLE-BOUNDARY-END(983551508519)
            
            //--TRIMMABLE-BOUNDARY-START(987846475815)
            static /*string */ get RequiredAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730148438055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is required.";
            }
            //--TRIMMABLE-BOUNDARY-END(987846475815)
            
            //--TRIMMABLE-BOUNDARY-START(283471839271)
            static /*string */ FormatRequiredAttribute_ValidationError(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283471839271);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is required.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(283471839271)
            
            //--TRIMMABLE-BOUNDARY-START(1017911246887)
            static /*string */ get StringLengthAttribute_InvalidMaxLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747328307239);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The maximum length must be a nonnegative integer.";
            }
            //--TRIMMABLE-BOUNDARY-END(1017911246887)
            
            //--TRIMMABLE-BOUNDARY-START(1022206214183)
            static /*string */ get StringLengthAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755918241831);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be a string with a maximum length of {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(1022206214183)
            
            //--TRIMMABLE-BOUNDARY-START(287766806567)
            static /*string */ FormatStringLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287766806567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The field {0} must be a string with a maximum length of {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(287766806567)
            
            //--TRIMMABLE-BOUNDARY-START(1026501181479)
            static /*string */ get StringLengthAttribute_ValidationErrorIncludingMinimum()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764508176423);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} must be a string with a minimum length of {2} and a maximum length of {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(1026501181479)
            
            //--TRIMMABLE-BOUNDARY-START(292061773863)
            static /*string */ FormatStringLengthAttribute_ValidationErrorIncludingMinimum(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292061773863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The field {0} must be a string with a minimum length of {2} and a maximum length of {1}.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(292061773863)
            
            //--TRIMMABLE-BOUNDARY-START(1030796148775)
            static /*string */ get UIHintImplementation_ControlParameterKeyIsNotAString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773098111015);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key parameter at position {0} with value '{1}' is not a string. Every key control parameter must be a string.";
            }
            //--TRIMMABLE-BOUNDARY-END(1030796148775)
            
            //--TRIMMABLE-BOUNDARY-START(296356741159)
            static /*string */ FormatUIHintImplementation_ControlParameterKeyIsNotAString(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296356741159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The key parameter at position {0} with value '{1}' is not a string. Every key control parameter must be a string.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(296356741159)
            
            //--TRIMMABLE-BOUNDARY-START(1035091116071)
            static /*string */ get UIHintImplementation_ControlParameterKeyIsNull()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781688045607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key parameter at position {0} is null. Every key control parameter must be a string.";
            }
            //--TRIMMABLE-BOUNDARY-END(1035091116071)
            
            //--TRIMMABLE-BOUNDARY-START(300651708455)
            static /*string */ FormatUIHintImplementation_ControlParameterKeyIsNull(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300651708455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The key parameter at position {0} is null. Every key control parameter must be a string.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(300651708455)
            
            //--TRIMMABLE-BOUNDARY-START(1039386083367)
            static /*string */ get UIHintImplementation_ControlParameterKeyOccursMoreThanOnce()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790277980199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The key parameter at position {0} with value '{1}' occurs more than once.";
            }
            //--TRIMMABLE-BOUNDARY-END(1039386083367)
            
            //--TRIMMABLE-BOUNDARY-START(304946675751)
            static /*string */ FormatUIHintImplementation_ControlParameterKeyOccursMoreThanOnce(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304946675751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The key parameter at position {0} with value '{1}' occurs more than once.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(304946675751)
            
            //--TRIMMABLE-BOUNDARY-START(1043681050663)
            static /*string */ get UIHintImplementation_NeedEvenNumberOfControlParameters()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798867914791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The number of control parameters must be even.";
            }
            //--TRIMMABLE-BOUNDARY-END(1043681050663)
            
            //--TRIMMABLE-BOUNDARY-START(1047976017959)
            static /*string */ get UrlAttribute_Invalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807457849383);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The {0} field is not a valid fully-qualified http, https, or ftp URL.";
            }
            //--TRIMMABLE-BOUNDARY-END(1047976017959)
            
            //--TRIMMABLE-BOUNDARY-START(309241643047)
            static /*string */ FormatUrlAttribute_Invalid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309241643047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The {0} field is not a valid fully-qualified http, https, or ftp URL.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(309241643047)
            
            //--TRIMMABLE-BOUNDARY-START(1056565952551)
            static /*string */ get ValidationAttribute_Cannot_Set_ErrorMessage_And_Resource()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816047783975);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Either ErrorMessageString or ErrorMessageResourceName must be set, but not both.";
            }
            //--TRIMMABLE-BOUNDARY-END(1056565952551)
            
            //--TRIMMABLE-BOUNDARY-START(1060860919847)
            static /*string */ get ValidationAttribute_IsValid_NotImplemented()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824637718567);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "IsValid(object value) has not been implemented by this class.  The preferred entry point is GetValidationResult() and classes should override IsValid(object value, ValidationContext context).";
            }
            //--TRIMMABLE-BOUNDARY-END(1060860919847)
            
            //--TRIMMABLE-BOUNDARY-START(1065155887143)
            static /*string */ get ValidationAttribute_NeedBothResourceTypeAndResourceName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833227653159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Both ErrorMessageResourceType and ErrorMessageResourceName need to be set on this attribute.";
            }
            //--TRIMMABLE-BOUNDARY-END(1065155887143)
            
            //--TRIMMABLE-BOUNDARY-START(1069450854439)
            static /*string */ get ValidationAttribute_ResourcePropertyNotStringType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841817587751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The property '{0}' on resource type '{1}' is not a string type.";
            }
            //--TRIMMABLE-BOUNDARY-END(1069450854439)
            
            //--TRIMMABLE-BOUNDARY-START(313536610343)
            static /*string */ FormatValidationAttribute_ResourcePropertyNotStringType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313536610343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The property '{0}' on resource type '{1}' is not a string type.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(313536610343)
            
            //--TRIMMABLE-BOUNDARY-START(1073745821735)
            static /*string */ get ValidationAttribute_ResourceTypeDoesNotHaveProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850407522343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The resource type '{0}' does not have an accessible static property named '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1073745821735)
            
            //--TRIMMABLE-BOUNDARY-START(317831577639)
            static /*string */ FormatValidationAttribute_ResourceTypeDoesNotHaveProperty(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317831577639);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The resource type '{0}' does not have an accessible static property named '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(317831577639)
            
            //--TRIMMABLE-BOUNDARY-START(1078040789031)
            static /*string */ get ValidationAttribute_ValidationError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858997456935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The field {0} is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(1078040789031)
            
            //--TRIMMABLE-BOUNDARY-START(322126544935)
            static /*string */ FormatValidationAttribute_ValidationError(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322126544935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The field {0} is invalid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(322126544935)
            
            //--TRIMMABLE-BOUNDARY-START(1082335756327)
            static /*string */ get Validator_InstanceMustMatchValidationContextInstance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(867587391527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The instance provided must match the ObjectInstance on the ValidationContext supplied.";
            }
            //--TRIMMABLE-BOUNDARY-END(1082335756327)
            
            //--TRIMMABLE-BOUNDARY-START(1086630723623)
            static /*string */ get Validator_Property_Value_Wrong_Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876177326119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value for property '{0}' must be of type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(1086630723623)
            
            //--TRIMMABLE-BOUNDARY-START(326421512231)
            static /*string */ FormatValidator_Property_Value_Wrong_Type(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326421512231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The value for property '{0}' must be of type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(326421512231)
            
            //--TRIMMABLE-BOUNDARY-START(1005026344999)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(1005026344999)
            
            //--TRIMMABLE-BOUNDARY-START(889062228007)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(889062228007);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(889062228007)
            
            //--TRIMMABLE-BOUNDARY-START(1052270985255)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1052270985255);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sca.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1052270985255)
            
            //--TRIMMABLE-BOUNDARY-START(884767260711)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(884767260711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sca.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(884767260711)
            
            //--TRIMMABLE-BOUNDARY-START(880472293415)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(880472293415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sca.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(880472293415)
            
            //--TRIMMABLE-BOUNDARY-START(137442951207)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137442951207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(137442951207)
            
            //--TRIMMABLE-BOUNDARY-START(133147983911)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133147983911);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(133147983911)
            
            //--TRIMMABLE-BOUNDARY-START(128853016615)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128853016615);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(128853016615)
            
            //--TRIMMABLE-BOUNDARY-START(141737918503)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141737918503);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(141737918503)
            
            //--TRIMMABLE-BOUNDARY-START(120263082023)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120263082023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(120263082023)
            
            //--TRIMMABLE-BOUNDARY-START(115968114727)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115968114727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(115968114727)
            
            //--TRIMMABLE-BOUNDARY-START(111673147431)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111673147431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(111673147431)
            
            //--TRIMMABLE-BOUNDARY-START(124558049319)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124558049319);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(124558049319)
            
            //--TRIMMABLE-BOUNDARY-START(4298965031)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(1005026344999)
                    this.s_usingResourceKeys = $.$sca.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(1005026344999)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4298965031)
            
            static $h = 3997735;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 3997735
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3997735)
        
        
        //--TRIMMABLE-BOUNDARY-START(3932199)
        $asm.$cls("$sca.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382256021543)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382256021543)
            
            //--TRIMMABLE-BOUNDARY-START(433795629095)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433795629095)
            
            //--TRIMMABLE-BOUNDARY-START(429500661799)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429500661799)
            
            //--TRIMMABLE-BOUNDARY-START(266291904551)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266291904551)
            
            //--TRIMMABLE-BOUNDARY-START(261996937255)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261996937255)
            
            //--TRIMMABLE-BOUNDARY-START(77313343527)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77313343527)
            
            //--TRIMMABLE-BOUNDARY-START(73018376231)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73018376231)
            
            //--TRIMMABLE-BOUNDARY-START(94493212711)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94493212711)
            
            //--TRIMMABLE-BOUNDARY-START(90198245415)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90198245415)
            
            //--TRIMMABLE-BOUNDARY-START(214752296999)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214752296999)
            
            //--TRIMMABLE-BOUNDARY-START(210457329703)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210457329703)
            
            //--TRIMMABLE-BOUNDARY-START(442385563687)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442385563687)
            
            //--TRIMMABLE-BOUNDARY-START(446680530983)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446680530983)
            
            //--TRIMMABLE-BOUNDARY-START(438090596391)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438090596391)
            
            //--TRIMMABLE-BOUNDARY-START(146032820263)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146032820263)
            
            //--TRIMMABLE-BOUNDARY-START(141737852967)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141737852967)
            
            //--TRIMMABLE-BOUNDARY-START(120263016487)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120263016487)
            
            //--TRIMMABLE-BOUNDARY-START(115968049191)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115968049191)
            
            //--TRIMMABLE-BOUNDARY-START(51543539751)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51543539751)
            
            //--TRIMMABLE-BOUNDARY-START(47248572455)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47248572455)
            
            //--TRIMMABLE-BOUNDARY-START(326421446695)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326421446695)
            
            //--TRIMMABLE-BOUNDARY-START(322126479399)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322126479399)
            
            //--TRIMMABLE-BOUNDARY-START(60133474343)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60133474343)
            
            //--TRIMMABLE-BOUNDARY-START(55838507047)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55838507047)
            
            //--TRIMMABLE-BOUNDARY-START(85903278119)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85903278119)
            
            //--TRIMMABLE-BOUNDARY-START(81608310823)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81608310823)
            
            //--TRIMMABLE-BOUNDARY-START(197572427815)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197572427815)
            
            //--TRIMMABLE-BOUNDARY-START(193277460519)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193277460519)
            
            //--TRIMMABLE-BOUNDARY-START(489630203943)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489630203943)
            
            //--TRIMMABLE-BOUNDARY-START(485335236647)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485335236647)
            
            //--TRIMMABLE-BOUNDARY-START(163212689447)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163212689447)
            
            //--TRIMMABLE-BOUNDARY-START(158917722151)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158917722151)
            
            //--TRIMMABLE-BOUNDARY-START(206162362407)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206162362407)
            
            //--TRIMMABLE-BOUNDARY-START(201867395111)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201867395111)
            
            //--TRIMMABLE-BOUNDARY-START(399435890727)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399435890727)
            
            //--TRIMMABLE-BOUNDARY-START(395140923431)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395140923431)
            
            //--TRIMMABLE-BOUNDARY-START(300651642919)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300651642919)
            
            //--TRIMMABLE-BOUNDARY-START(296356675623)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296356675623)
            
            //--TRIMMABLE-BOUNDARY-START(377961054247)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377961054247)
            
            //--TRIMMABLE-BOUNDARY-START(373666086951)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373666086951)
            
            //--TRIMMABLE-BOUNDARY-START(231932166183)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231932166183)
            
            //--TRIMMABLE-BOUNDARY-START(227637198887)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227637198887)
            
            //--TRIMMABLE-BOUNDARY-START(154622754855)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154622754855)
            
            //--TRIMMABLE-BOUNDARY-START(150327787559)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150327787559)
            
            //--TRIMMABLE-BOUNDARY-START(352191250471)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352191250471)
            
            //--TRIMMABLE-BOUNDARY-START(347896283175)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347896283175)
            
            //--TRIMMABLE-BOUNDARY-START(360781185063)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360781185063)
            
            //--TRIMMABLE-BOUNDARY-START(356486217767)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356486217767)
            
            //--TRIMMABLE-BOUNDARY-START(17183801383)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17183801383)
            
            //--TRIMMABLE-BOUNDARY-START(12888834087)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12888834087)
            
            //--TRIMMABLE-BOUNDARY-START(408025825319)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408025825319)
            
            //--TRIMMABLE-BOUNDARY-START(403730858023)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403730858023)
            
            //--TRIMMABLE-BOUNDARY-START(498220138535)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498220138535)
            
            //--TRIMMABLE-BOUNDARY-START(493925171239)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493925171239)
            
            //--TRIMMABLE-BOUNDARY-START(283471773735)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283471773735)
            
            //--TRIMMABLE-BOUNDARY-START(279176806439)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279176806439)
            
            //--TRIMMABLE-BOUNDARY-START(506810073127)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506810073127)
            
            //--TRIMMABLE-BOUNDARY-START(502515105831)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502515105831)
            
            //--TRIMMABLE-BOUNDARY-START(274881839143)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274881839143)
            
            //--TRIMMABLE-BOUNDARY-START(270586871847)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270586871847)
            
            //--TRIMMABLE-BOUNDARY-START(481040269351)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481040269351)
            
            //--TRIMMABLE-BOUNDARY-START(476745302055)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476745302055)
            
            //--TRIMMABLE-BOUNDARY-START(128852951079)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128852951079)
            
            //--TRIMMABLE-BOUNDARY-START(124557983783)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124557983783)
            
            //--TRIMMABLE-BOUNDARY-START(111673081895)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111673081895)
            
            //--TRIMMABLE-BOUNDARY-START(107378114599)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107378114599)
            
            //--TRIMMABLE-BOUNDARY-START(335011381287)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335011381287)
            
            //--TRIMMABLE-BOUNDARY-START(330716413991)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330716413991)
            
            //--TRIMMABLE-BOUNDARY-START(68723408935)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68723408935)
            
            //--TRIMMABLE-BOUNDARY-START(64428441639)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64428441639)
            
            //--TRIMMABLE-BOUNDARY-START(390845956135)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390845956135)
            
            //--TRIMMABLE-BOUNDARY-START(386550988839)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386550988839)
            
            //--TRIMMABLE-BOUNDARY-START(309241577511)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309241577511)
            
            //--TRIMMABLE-BOUNDARY-START(304946610215)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304946610215)
            
            //--TRIMMABLE-BOUNDARY-START(42953605159)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42953605159)
            
            //--TRIMMABLE-BOUNDARY-START(38658637863)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38658637863)
            
            //--TRIMMABLE-BOUNDARY-START(416615759911)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416615759911)
            
            //--TRIMMABLE-BOUNDARY-START(412320792615)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412320792615)
            
            //--TRIMMABLE-BOUNDARY-START(472450334759)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472450334759)
            
            //--TRIMMABLE-BOUNDARY-START(468155367463)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468155367463)
            
            //--TRIMMABLE-BOUNDARY-START(188982493223)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188982493223)
            
            //--TRIMMABLE-BOUNDARY-START(184687525927)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184687525927)
            
            //--TRIMMABLE-BOUNDARY-START(171802624039)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171802624039)
            
            //--TRIMMABLE-BOUNDARY-START(167507656743)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167507656743)
            
            //--TRIMMABLE-BOUNDARY-START(180392558631)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180392558631)
            
            //--TRIMMABLE-BOUNDARY-START(176097591335)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176097591335)
            
            //--TRIMMABLE-BOUNDARY-START(34363670567)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34363670567)
            
            //--TRIMMABLE-BOUNDARY-START(30068703271)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30068703271)
            
            //--TRIMMABLE-BOUNDARY-START(137442885671)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137442885671)
            
            //--TRIMMABLE-BOUNDARY-START(133147918375)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133147918375)
            
            //--TRIMMABLE-BOUNDARY-START(103083147303)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103083147303)
            
            //--TRIMMABLE-BOUNDARY-START(98788180007)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98788180007)
            
            //--TRIMMABLE-BOUNDARY-START(523989942311)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523989942311)
            
            //--TRIMMABLE-BOUNDARY-START(519694975015)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519694975015)
            
            //--TRIMMABLE-BOUNDARY-START(369371119655)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369371119655)
            
            //--TRIMMABLE-BOUNDARY-START(365076152359)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365076152359)
            
            //--TRIMMABLE-BOUNDARY-START(223342231591)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223342231591)
            
            //--TRIMMABLE-BOUNDARY-START(219047264295)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219047264295)
            
            //--TRIMMABLE-BOUNDARY-START(249112035367)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249112035367)
            
            //--TRIMMABLE-BOUNDARY-START(236227133479)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236227133479)
            
            //--TRIMMABLE-BOUNDARY-START(244817068071)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244817068071)
            
            //--TRIMMABLE-BOUNDARY-START(240522100775)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240522100775)
            
            //--TRIMMABLE-BOUNDARY-START(317831512103)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317831512103)
            
            //--TRIMMABLE-BOUNDARY-START(313536544807)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313536544807)
            
            //--TRIMMABLE-BOUNDARY-START(8593866791)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8593866791)
            
            //--TRIMMABLE-BOUNDARY-START(4298899495)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4298899495)
            
            //--TRIMMABLE-BOUNDARY-START(455270465575)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455270465575)
            
            //--TRIMMABLE-BOUNDARY-START(450975498279)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450975498279)
            
            //--TRIMMABLE-BOUNDARY-START(25773735975)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25773735975)
            
            //--TRIMMABLE-BOUNDARY-START(21478768679)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21478768679)
            
            //--TRIMMABLE-BOUNDARY-START(257701969959)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257701969959)
            
            //--TRIMMABLE-BOUNDARY-START(253407002663)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253407002663)
            
            //--TRIMMABLE-BOUNDARY-START(515400007719)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515400007719)
            
            //--TRIMMABLE-BOUNDARY-START(511105040423)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511105040423)
            
            //--TRIMMABLE-BOUNDARY-START(463860400167)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463860400167)
            
            //--TRIMMABLE-BOUNDARY-START(459565432871)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459565432871)
            
            //--TRIMMABLE-BOUNDARY-START(425205694503)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425205694503)
            
            //--TRIMMABLE-BOUNDARY-START(420910727207)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420910727207)
            
            //--TRIMMABLE-BOUNDARY-START(343601315879)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343601315879)
            
            //--TRIMMABLE-BOUNDARY-START(339306348583)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339306348583)
            
            //--TRIMMABLE-BOUNDARY-START(292061708327)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292061708327)
            
            //--TRIMMABLE-BOUNDARY-START(287766741031)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287766741031)
            
            //--TRIMMABLE-BOUNDARY-START(532579876903)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532579876903)
            
            //--TRIMMABLE-BOUNDARY-START(528284909607)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528284909607)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382256021543)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382256021543)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433795629095)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433795629095)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429500661799)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429500661799)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266291904551)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266291904551)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261996937255)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261996937255)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77313343527)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77313343527)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73018376231)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73018376231)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94493212711)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94493212711)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90198245415)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90198245415)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214752296999)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214752296999)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210457329703)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210457329703)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442385563687)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442385563687)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446680530983)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446680530983)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438090596391)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438090596391)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146032820263)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146032820263)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141737852967)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141737852967)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120263016487)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120263016487)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115968049191)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115968049191)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51543539751)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51543539751)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47248572455)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47248572455)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326421446695)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326421446695)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322126479399)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322126479399)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60133474343)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60133474343)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55838507047)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55838507047)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85903278119)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85903278119)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81608310823)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81608310823)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197572427815)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197572427815)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193277460519)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193277460519)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489630203943)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489630203943)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485335236647)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485335236647)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163212689447)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163212689447)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158917722151)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158917722151)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206162362407)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206162362407)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201867395111)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201867395111)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399435890727)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399435890727)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395140923431)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395140923431)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300651642919)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300651642919)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296356675623)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296356675623)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377961054247)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377961054247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373666086951)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373666086951)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231932166183)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231932166183)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227637198887)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227637198887)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154622754855)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154622754855)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150327787559)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150327787559)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352191250471)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352191250471)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347896283175)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347896283175)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360781185063)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360781185063)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356486217767)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356486217767)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17183801383)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17183801383)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12888834087)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12888834087)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408025825319)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408025825319)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403730858023)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403730858023)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498220138535)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498220138535)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493925171239)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493925171239)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283471773735)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283471773735)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279176806439)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279176806439)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506810073127)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506810073127)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502515105831)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502515105831)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274881839143)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274881839143)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270586871847)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270586871847)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481040269351)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481040269351)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476745302055)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476745302055)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128852951079)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128852951079)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124557983783)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124557983783)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111673081895)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111673081895)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107378114599)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107378114599)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335011381287)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335011381287)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330716413991)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330716413991)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68723408935)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68723408935)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64428441639)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64428441639)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390845956135)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390845956135)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386550988839)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386550988839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309241577511)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309241577511)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304946610215)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304946610215)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42953605159)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42953605159)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38658637863)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38658637863)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416615759911)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416615759911)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412320792615)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412320792615)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472450334759)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472450334759)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468155367463)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468155367463)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188982493223)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188982493223)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184687525927)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184687525927)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171802624039)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171802624039)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167507656743)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167507656743)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180392558631)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180392558631)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176097591335)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176097591335)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34363670567)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34363670567)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30068703271)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30068703271)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137442885671)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137442885671)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133147918375)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133147918375)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103083147303)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103083147303)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98788180007)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98788180007)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523989942311)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523989942311)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519694975015)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519694975015)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369371119655)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369371119655)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365076152359)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365076152359)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223342231591)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223342231591)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219047264295)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219047264295)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249112035367)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249112035367)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236227133479)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236227133479)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244817068071)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244817068071)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240522100775)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240522100775)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317831512103)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317831512103)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313536544807)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313536544807)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8593866791)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8593866791)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4298899495)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4298899495)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455270465575)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455270465575)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450975498279)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450975498279)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25773735975)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25773735975)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21478768679)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21478768679)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257701969959)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257701969959)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253407002663)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253407002663)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515400007719)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515400007719)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511105040423)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511105040423)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463860400167)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463860400167)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459565432871)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459565432871)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425205694503)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425205694503)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420910727207)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420910727207)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343601315879)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343601315879)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339306348583)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339306348583)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292061708327)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292061708327)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287766741031)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287766741031)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532579876903)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532579876903)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528284909607)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528284909607)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3932199;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382256021543),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 3932199,
      "h": 382256021543,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382256021543),
//--TRIMMABLE-BOUNDARY-START(433795629095),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 3932199,
      "h": 433795629095,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433795629095),
//--TRIMMABLE-BOUNDARY-START(429500661799),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 3932199,
      "h": 429500661799,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429500661799),
//--TRIMMABLE-BOUNDARY-START(266291904551),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 3932199,
      "h": 266291904551,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266291904551),
//--TRIMMABLE-BOUNDARY-START(261996937255),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 3932199,
      "h": 261996937255,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261996937255),
//--TRIMMABLE-BOUNDARY-START(77313343527),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 3932199,
      "h": 77313343527,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77313343527),
//--TRIMMABLE-BOUNDARY-START(73018376231),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 3932199,
      "h": 73018376231,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73018376231),
//--TRIMMABLE-BOUNDARY-START(94493212711),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 3932199,
      "h": 94493212711,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94493212711),
//--TRIMMABLE-BOUNDARY-START(90198245415),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 3932199,
      "h": 90198245415,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90198245415),
//--TRIMMABLE-BOUNDARY-START(214752296999),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 3932199,
      "h": 214752296999,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214752296999),
//--TRIMMABLE-BOUNDARY-START(210457329703),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 3932199,
      "h": 210457329703,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210457329703),
//--TRIMMABLE-BOUNDARY-START(442385563687),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 3932199,
      "h": 442385563687,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442385563687),
//--TRIMMABLE-BOUNDARY-START(446680530983),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 3932199,
      "h": 446680530983,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446680530983),
//--TRIMMABLE-BOUNDARY-START(438090596391),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 3932199,
      "h": 438090596391,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438090596391),
//--TRIMMABLE-BOUNDARY-START(146032820263),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 3932199,
      "h": 146032820263,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146032820263),
//--TRIMMABLE-BOUNDARY-START(141737852967),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 3932199,
      "h": 141737852967,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141737852967),
//--TRIMMABLE-BOUNDARY-START(120263016487),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 3932199,
      "h": 120263016487,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120263016487),
//--TRIMMABLE-BOUNDARY-START(115968049191),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 3932199,
      "h": 115968049191,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115968049191),
//--TRIMMABLE-BOUNDARY-START(51543539751),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 3932199,
      "h": 51543539751,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51543539751),
//--TRIMMABLE-BOUNDARY-START(47248572455),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 3932199,
      "h": 47248572455,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47248572455),
//--TRIMMABLE-BOUNDARY-START(326421446695),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 3932199,
      "h": 326421446695,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326421446695),
//--TRIMMABLE-BOUNDARY-START(322126479399),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 3932199,
      "h": 322126479399,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322126479399),
//--TRIMMABLE-BOUNDARY-START(60133474343),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 3932199,
      "h": 60133474343,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60133474343),
//--TRIMMABLE-BOUNDARY-START(55838507047),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 3932199,
      "h": 55838507047,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55838507047),
//--TRIMMABLE-BOUNDARY-START(85903278119),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 3932199,
      "h": 85903278119,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85903278119),
//--TRIMMABLE-BOUNDARY-START(81608310823),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 3932199,
      "h": 81608310823,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81608310823),
//--TRIMMABLE-BOUNDARY-START(197572427815),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 3932199,
      "h": 197572427815,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197572427815),
//--TRIMMABLE-BOUNDARY-START(193277460519),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 3932199,
      "h": 193277460519,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193277460519),
//--TRIMMABLE-BOUNDARY-START(489630203943),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 3932199,
      "h": 489630203943,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489630203943),
//--TRIMMABLE-BOUNDARY-START(485335236647),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 3932199,
      "h": 485335236647,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485335236647),
//--TRIMMABLE-BOUNDARY-START(163212689447),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 3932199,
      "h": 163212689447,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163212689447),
//--TRIMMABLE-BOUNDARY-START(158917722151),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 3932199,
      "h": 158917722151,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158917722151),
//--TRIMMABLE-BOUNDARY-START(206162362407),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 3932199,
      "h": 206162362407,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206162362407),
//--TRIMMABLE-BOUNDARY-START(201867395111),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 3932199,
      "h": 201867395111,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201867395111),
//--TRIMMABLE-BOUNDARY-START(399435890727),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 3932199,
      "h": 399435890727,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399435890727),
//--TRIMMABLE-BOUNDARY-START(395140923431),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 3932199,
      "h": 395140923431,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395140923431),
//--TRIMMABLE-BOUNDARY-START(300651642919),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 3932199,
      "h": 300651642919,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300651642919),
//--TRIMMABLE-BOUNDARY-START(296356675623),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 3932199,
      "h": 296356675623,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296356675623),
//--TRIMMABLE-BOUNDARY-START(377961054247),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 3932199,
      "h": 377961054247,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377961054247),
//--TRIMMABLE-BOUNDARY-START(373666086951),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 3932199,
      "h": 373666086951,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373666086951),
//--TRIMMABLE-BOUNDARY-START(231932166183),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 3932199,
      "h": 231932166183,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231932166183),
//--TRIMMABLE-BOUNDARY-START(227637198887),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 3932199,
      "h": 227637198887,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227637198887),
//--TRIMMABLE-BOUNDARY-START(154622754855),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 3932199,
      "h": 154622754855,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154622754855),
//--TRIMMABLE-BOUNDARY-START(150327787559),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 3932199,
      "h": 150327787559,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150327787559),
//--TRIMMABLE-BOUNDARY-START(352191250471),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 3932199,
      "h": 352191250471,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352191250471),
//--TRIMMABLE-BOUNDARY-START(347896283175),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 3932199,
      "h": 347896283175,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347896283175),
//--TRIMMABLE-BOUNDARY-START(360781185063),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 3932199,
      "h": 360781185063,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360781185063),
//--TRIMMABLE-BOUNDARY-START(356486217767),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 3932199,
      "h": 356486217767,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356486217767),
//--TRIMMABLE-BOUNDARY-START(17183801383),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 3932199,
      "h": 17183801383,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17183801383),
//--TRIMMABLE-BOUNDARY-START(12888834087),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 3932199,
      "h": 12888834087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12888834087),
//--TRIMMABLE-BOUNDARY-START(408025825319),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 3932199,
      "h": 408025825319,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408025825319),
//--TRIMMABLE-BOUNDARY-START(403730858023),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 3932199,
      "h": 403730858023,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403730858023),
//--TRIMMABLE-BOUNDARY-START(498220138535),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 3932199,
      "h": 498220138535,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498220138535),
//--TRIMMABLE-BOUNDARY-START(493925171239),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 3932199,
      "h": 493925171239,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493925171239),
//--TRIMMABLE-BOUNDARY-START(283471773735),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 3932199,
      "h": 283471773735,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283471773735),
//--TRIMMABLE-BOUNDARY-START(279176806439),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 3932199,
      "h": 279176806439,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279176806439),
//--TRIMMABLE-BOUNDARY-START(506810073127),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 3932199,
      "h": 506810073127,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506810073127),
//--TRIMMABLE-BOUNDARY-START(502515105831),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 3932199,
      "h": 502515105831,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502515105831),
//--TRIMMABLE-BOUNDARY-START(274881839143),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 3932199,
      "h": 274881839143,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274881839143),
//--TRIMMABLE-BOUNDARY-START(270586871847),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 3932199,
      "h": 270586871847,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270586871847),
//--TRIMMABLE-BOUNDARY-START(481040269351),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 3932199,
      "h": 481040269351,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481040269351),
//--TRIMMABLE-BOUNDARY-START(476745302055),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 3932199,
      "h": 476745302055,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476745302055),
//--TRIMMABLE-BOUNDARY-START(128852951079),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 3932199,
      "h": 128852951079,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128852951079),
//--TRIMMABLE-BOUNDARY-START(124557983783),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 3932199,
      "h": 124557983783,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124557983783),
//--TRIMMABLE-BOUNDARY-START(111673081895),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 3932199,
      "h": 111673081895,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111673081895),
//--TRIMMABLE-BOUNDARY-START(107378114599),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 3932199,
      "h": 107378114599,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107378114599),
//--TRIMMABLE-BOUNDARY-START(335011381287),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 3932199,
      "h": 335011381287,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335011381287),
//--TRIMMABLE-BOUNDARY-START(330716413991),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 3932199,
      "h": 330716413991,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330716413991),
//--TRIMMABLE-BOUNDARY-START(68723408935),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 3932199,
      "h": 68723408935,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68723408935),
//--TRIMMABLE-BOUNDARY-START(64428441639),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 3932199,
      "h": 64428441639,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64428441639),
//--TRIMMABLE-BOUNDARY-START(390845956135),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 3932199,
      "h": 390845956135,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390845956135),
//--TRIMMABLE-BOUNDARY-START(386550988839),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 3932199,
      "h": 386550988839,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386550988839),
//--TRIMMABLE-BOUNDARY-START(309241577511),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 3932199,
      "h": 309241577511,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309241577511),
//--TRIMMABLE-BOUNDARY-START(304946610215),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 3932199,
      "h": 304946610215,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304946610215),
//--TRIMMABLE-BOUNDARY-START(42953605159),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 3932199,
      "h": 42953605159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42953605159),
//--TRIMMABLE-BOUNDARY-START(38658637863),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 3932199,
      "h": 38658637863,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38658637863),
//--TRIMMABLE-BOUNDARY-START(416615759911),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 3932199,
      "h": 416615759911,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416615759911),
//--TRIMMABLE-BOUNDARY-START(412320792615),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 3932199,
      "h": 412320792615,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412320792615),
//--TRIMMABLE-BOUNDARY-START(472450334759),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 3932199,
      "h": 472450334759,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472450334759),
//--TRIMMABLE-BOUNDARY-START(468155367463),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 3932199,
      "h": 468155367463,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468155367463),
//--TRIMMABLE-BOUNDARY-START(188982493223),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 3932199,
      "h": 188982493223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188982493223),
//--TRIMMABLE-BOUNDARY-START(184687525927),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 3932199,
      "h": 184687525927,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184687525927),
//--TRIMMABLE-BOUNDARY-START(171802624039),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 3932199,
      "h": 171802624039,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171802624039),
//--TRIMMABLE-BOUNDARY-START(167507656743),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 3932199,
      "h": 167507656743,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167507656743),
//--TRIMMABLE-BOUNDARY-START(180392558631),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 3932199,
      "h": 180392558631,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180392558631),
//--TRIMMABLE-BOUNDARY-START(176097591335),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 3932199,
      "h": 176097591335,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176097591335),
//--TRIMMABLE-BOUNDARY-START(34363670567),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 3932199,
      "h": 34363670567,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34363670567),
//--TRIMMABLE-BOUNDARY-START(30068703271),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 3932199,
      "h": 30068703271,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30068703271),
//--TRIMMABLE-BOUNDARY-START(137442885671),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 3932199,
      "h": 137442885671,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137442885671),
//--TRIMMABLE-BOUNDARY-START(133147918375),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 3932199,
      "h": 133147918375,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133147918375),
//--TRIMMABLE-BOUNDARY-START(103083147303),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 3932199,
      "h": 103083147303,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103083147303),
//--TRIMMABLE-BOUNDARY-START(98788180007),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 3932199,
      "h": 98788180007,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98788180007),
//--TRIMMABLE-BOUNDARY-START(523989942311),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 3932199,
      "h": 523989942311,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523989942311),
//--TRIMMABLE-BOUNDARY-START(519694975015),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 3932199,
      "h": 519694975015,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519694975015),
//--TRIMMABLE-BOUNDARY-START(369371119655),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 3932199,
      "h": 369371119655,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369371119655),
//--TRIMMABLE-BOUNDARY-START(365076152359),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 3932199,
      "h": 365076152359,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365076152359),
//--TRIMMABLE-BOUNDARY-START(223342231591),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 3932199,
      "h": 223342231591,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223342231591),
//--TRIMMABLE-BOUNDARY-START(219047264295),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 3932199,
      "h": 219047264295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219047264295),
//--TRIMMABLE-BOUNDARY-START(249112035367),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 3932199,
      "h": 249112035367,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249112035367),
//--TRIMMABLE-BOUNDARY-START(236227133479),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 3932199,
      "h": 236227133479,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236227133479),
//--TRIMMABLE-BOUNDARY-START(244817068071),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 3932199,
      "h": 244817068071,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244817068071),
//--TRIMMABLE-BOUNDARY-START(240522100775),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 3932199,
      "h": 240522100775,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240522100775),
//--TRIMMABLE-BOUNDARY-START(317831512103),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 3932199,
      "h": 317831512103,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317831512103),
//--TRIMMABLE-BOUNDARY-START(313536544807),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 3932199,
      "h": 313536544807,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313536544807),
//--TRIMMABLE-BOUNDARY-START(8593866791),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 3932199,
      "h": 8593866791,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8593866791),
//--TRIMMABLE-BOUNDARY-START(4298899495),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 3932199,
      "h": 4298899495,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4298899495),
//--TRIMMABLE-BOUNDARY-START(455270465575),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 3932199,
      "h": 455270465575,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455270465575),
//--TRIMMABLE-BOUNDARY-START(450975498279),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 3932199,
      "h": 450975498279,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450975498279),
//--TRIMMABLE-BOUNDARY-START(25773735975),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 3932199,
      "h": 25773735975,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25773735975),
//--TRIMMABLE-BOUNDARY-START(21478768679),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 3932199,
      "h": 21478768679,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21478768679),
//--TRIMMABLE-BOUNDARY-START(257701969959),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 3932199,
      "h": 257701969959,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257701969959),
//--TRIMMABLE-BOUNDARY-START(253407002663),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 3932199,
      "h": 253407002663,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253407002663),
//--TRIMMABLE-BOUNDARY-START(515400007719),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 3932199,
      "h": 515400007719,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515400007719),
//--TRIMMABLE-BOUNDARY-START(511105040423),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 3932199,
      "h": 511105040423,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511105040423),
//--TRIMMABLE-BOUNDARY-START(463860400167),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 3932199,
      "h": 463860400167,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463860400167),
//--TRIMMABLE-BOUNDARY-START(459565432871),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 3932199,
      "h": 459565432871,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459565432871),
//--TRIMMABLE-BOUNDARY-START(425205694503),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 3932199,
      "h": 425205694503,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425205694503),
//--TRIMMABLE-BOUNDARY-START(420910727207),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 3932199,
      "h": 420910727207,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420910727207),
//--TRIMMABLE-BOUNDARY-START(343601315879),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 3932199,
      "h": 343601315879,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343601315879),
//--TRIMMABLE-BOUNDARY-START(339306348583),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 3932199,
      "h": 339306348583,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339306348583),
//--TRIMMABLE-BOUNDARY-START(292061708327),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 3932199,
      "h": 292061708327,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292061708327),
//--TRIMMABLE-BOUNDARY-START(287766741031),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 3932199,
      "h": 287766741031,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287766741031),
//--TRIMMABLE-BOUNDARY-START(532579876903),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 3932199,
      "h": 532579876903,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532579876903),
//--TRIMMABLE-BOUNDARY-START(528284909607),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 3932199,
      "h": 528284909607,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528284909607)
  ],
  "h": 3932199
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3932199)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703975)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.LocalizableString", ($self) => class LocalizableString extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591638567)
            /*string*/ _propertyName = null;
            //--TRIMMABLE-BOUNDARY-END(8591638567)
            
            //--TRIMMABLE-BOUNDARY-START(4296671271)
            /*Func<string?>?*/ _cachedResult = null;
            //--TRIMMABLE-BOUNDARY-END(4296671271)
            
            //--TRIMMABLE-BOUNDARY-START(12886605863)
            /*string?*/ _propertyValue = null;
            //--TRIMMABLE-BOUNDARY-END(12886605863)
            
            //--TRIMMABLE-BOUNDARY-START(17181573159)
            /*Type?*/ _resourceType = null;
            //--TRIMMABLE-BOUNDARY-END(17181573159)
            
            //--TRIMMABLE-BOUNDARY-START(21476540455)
            $ctor$1(/*string*/ propertyName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476540455);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._propertyName = propertyName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476540455)
            
            //--TRIMMABLE-BOUNDARY-START(73016148007)
            /*string? */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951376935);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._propertyValue;
            }
            /*string? */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721180711);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this._propertyValue, value))
                {
                    this.ClearCache();
                    this._propertyValue = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016148007)
            
            //--TRIMMABLE-BOUNDARY-START(51541311527)
            /*Type? */ get ResourceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361442343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._resourceType;
            }
            /*Type? */ set ResourceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131246119);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Inequality$1(this._resourceType, value))
                {
                    this.ClearCache();
                    this._resourceType = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51541311527)
            
            //--TRIMMABLE-BOUNDARY-START(25771507751)
            /*void */ ClearCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507751);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._cachedResult = null;
            }
            //--TRIMMABLE-BOUNDARY-END(25771507751)
            
            //--TRIMMABLE-BOUNDARY-START(47246344231)
            /*string? */ GetLocalizableValue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246344231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._cachedResult === null)
                {
                    if ($.$$.System.String.op_Equality(this._propertyValue, null) || $.$$.System.Type.op_Equality$1(this._resourceType, null))
                    {
                        this._cachedResult = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                        {
                            return this._propertyValue;
                        }, {
  "r": 1310721,
  "n": "",
  "d": 1703975,
  "h": 0,
  "f": 17825794
});
                    }
                    else 
                    {
                        /*var*/ let property = $.$$.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty(this._resourceType, this._propertyValue);
                        /*var*/ let badlyConfigured = false;
                        if ($.$$.System.Reflection.PropertyInfo.op_Equality$1(property, null) || $.$$.System.Type.op_Inequality$1(property.PropertyType, $.$$.System.String.$type))
                        {
                            badlyConfigured = true;
                        }
                        else 
                        {
                            /*var*/ let getter = property.GetMethod;
                            if ($.$$.System.Reflection.MethodInfo.op_Equality$2(getter, null) || !(getter.IsPublic$1 && getter.IsStatic$1))
                            {
                                badlyConfigured = true;
                            }
                        }
                        if (badlyConfigured)
                        {
                            /*string*/ let exceptionMessage = $.$sca.System.SR.Format$4($.$sca.System.SR.LocalizableString_LocalizationFailed, this._propertyName, this._resourceType.FullName, this._propertyValue);
                            this._cachedResult = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12(exceptionMessage);
                            }, {
  "r": 1310721,
  "n": "",
  "d": 1703975,
  "h": 0,
  "f": 17825794
});
                        }
                        else 
                        {
                            this._cachedResult = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                            {
                                return $.$cast(property.GetValue(null, null), $.$$.System.String);
                            }, {
  "r": 1310721,
  "n": "",
  "d": 1703975,
  "h": 0,
  "f": 17825794
});
                        }
                    }
                }
                return this._cachedResult.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(47246344231)
            
            static $h = 1703975;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73016148007),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951376935,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68721180711,
        "f": 83886081
      },
      "n": "Value",
      "d": 1703975,
      "h": 73016148007,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016148007),
//--TRIMMABLE-BOUNDARY-START(51541311527),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442343,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60131246119,
        "f": 83886081
      },
      "n": "ResourceType",
      "d": 1703975,
      "h": 51541311527,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541311527)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771507751),
    {
      "r": 65537,
      "n": "ClearCache",
      "d": 1703975,
      "h": 25771507751,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25771507751),
//--TRIMMABLE-BOUNDARY-START(47246344231),
    {
      "r": 1310721,
      "n": "GetLocalizableValue",
      "d": 1703975,
      "h": 47246344231,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246344231)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591638567),
    {
      "t": 1310721,
      "n": "_propertyName",
      "d": 1703975,
      "h": 8591638567,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591638567),
//--TRIMMABLE-BOUNDARY-START(4296671271),
    {
      "t": $.$$.System.Func$$($.$$.System.String).$h,
      "n": "_cachedResult",
      "d": 1703975,
      "h": 4296671271,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671271),
//--TRIMMABLE-BOUNDARY-START(12886605863),
    {
      "t": 1310721,
      "n": "_propertyValue",
      "d": 1703975,
      "h": 12886605863,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886605863),
//--TRIMMABLE-BOUNDARY-START(17181573159),
    {
      "t": 187760641,
      "n": "_resourceType",
      "d": 1703975,
      "h": 17181573159,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573159)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476540455),
    {
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703975,
      "h": 21476540455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476540455)
  ],
  "h": 1703975
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.LocalizableString`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703975)
        
        
        //--TRIMMABLE-BOUNDARY-START(3276839)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore", ($self) => class ValidationAttributeStore extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4298244135)
            /*ConcurrentDictionary<Type, TypeStoreItem>*/ _typeStoreItems = null;
            //--TRIMMABLE-BOUNDARY-END(4298244135)
            
            //--TRIMMABLE-BOUNDARY-START(73017720871)
            /*ValidationAttributeStore*/ static Instance = null;
            //--TRIMMABLE-BOUNDARY-END(73017720871)
            
            //--TRIMMABLE-BOUNDARY-START(68722753575)
            /*IEnumerable<ValidationAttribute> */ GetTypeValidationAttributes(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68722753575);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let item = this.GetTypeStoreItem(validationContext.ObjectType);
                return item.ValidationAttributes;
            }
            //--TRIMMABLE-BOUNDARY-END(68722753575)
            
            //--TRIMMABLE-BOUNDARY-START(60132818983)
            /*DisplayAttribute? */ GetTypeDisplayAttribute(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60132818983);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let item = this.GetTypeStoreItem(validationContext.ObjectType);
                return item.DisplayAttribute;
            }
            //--TRIMMABLE-BOUNDARY-END(60132818983)
            
            //--TRIMMABLE-BOUNDARY-START(55837851687)
            /*IEnumerable<ValidationAttribute> */ GetPropertyValidationAttributes(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55837851687);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.ValidationAttributes;
            }
            //--TRIMMABLE-BOUNDARY-END(55837851687)
            
            //--TRIMMABLE-BOUNDARY-START(47247917095)
            /*DisplayAttribute? */ GetPropertyDisplayAttribute(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247917095);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.DisplayAttribute;
            }
            //--TRIMMABLE-BOUNDARY-END(47247917095)
            
            //--TRIMMABLE-BOUNDARY-START(51542884391)
            /*Type */ GetPropertyType(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51542884391);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.PropertyType;
            }
            //--TRIMMABLE-BOUNDARY-END(51542884391)
            
            //--TRIMMABLE-BOUNDARY-START(77312688167)
            /*bool */ IsPropertyContext(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77312688167);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                return typeItem.TryGetPropertyStoreItem(validationContext.MemberName, $.$discardRef());
            }
            //--TRIMMABLE-BOUNDARY-END(77312688167)
            
            //--TRIMMABLE-BOUNDARY-START(64427786279)
            /*TypeStoreItem */ GetTypeStoreItem(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64427786279);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(type, null), "type != null");
                return this._typeStoreItems.GetOrAdd(type, new ($.$$.System.Func$$$($.$$.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem))().$ctor($.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore, AddTypeStoreItem));
                /*static TypeStoreItem*/  function AddTypeStoreItem(/*Type*/ type)
                {
                    /*AttributeCollection*/ let attributes = $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes$2(type);
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem().$ctor$2(type, attributes);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64427786279)
            
            //--TRIMMABLE-BOUNDARY-START(34363015207)
            static /*void */ EnsureValidationContext(/*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363015207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
            }
            //--TRIMMABLE-BOUNDARY-END(34363015207)
            
            //--TRIMMABLE-BOUNDARY-START(81607655463)
            static /*bool */ IsPublic(/*PropertyInfo*/ p)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81607655463);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return ($.$$.System.Reflection.MethodInfo.op_Inequality$2(p.GetMethod, null) && p.GetMethod.IsPublic$1) || ($.$$.System.Reflection.MethodInfo.op_Inequality$2(p.SetMethod, null) && p.SetMethod.IsPublic$1);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81607655463)
            
            //--TRIMMABLE-BOUNDARY-START(3407911)
            static $_StoreItem;
            static get StoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_StoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem", ($self) => class StoreItem extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12888309799)
                    $ctor$1(/*AttributeCollection*/ attributes)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12888309799);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.ValidationAttributes = $.$sl.System.Linq.Enumerable.OfType($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, attributes);
                            this.DisplayAttribute = $.$sl.System.Linq.Enumerable.SingleOrDefault$3($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, $.$sl.System.Linq.Enumerable.OfType($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, attributes));
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12888309799)
                    
                    //--TRIMMABLE-BOUNDARY-START(38658113575)
                    /*IEnumerable<ValidationAttribute>*/ ValidationAttributes = null;
                    //--TRIMMABLE-BOUNDARY-END(38658113575)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183277095)
                    /*DisplayAttribute?*/ DisplayAttribute = null;
                    //--TRIMMABLE-BOUNDARY-END(17183277095)
                    
                    static $h = 3407911;
                    static $f = 0b10000000000110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38658113575),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363146279,
        "f": 50331656
      },
      "n": "ValidationAttributes",
      "d": 3407911,
      "h": 38658113575,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(38658113575),
//--TRIMMABLE-BOUNDARY-START(17183277095),
    {
      "p": 983079,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773211687,
        "f": 50331656
      },
      "n": "DisplayAttribute",
      "d": 3407911,
      "h": 17183277095,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(17183277095)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12888309799),
    {
      "p": [
        {
          "n": "attributes",
          "p": 1179689
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3407911,
      "h": 12888309799,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12888309799)
  ],
  "d": 3276839,
  "h": 3407911
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem`; }
                }, $cls, ($v) => $cls.$_StoreItem = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3407911)
            
            //--TRIMMABLE-BOUNDARY-START(3473447)
            static $_TypeStoreItem;
            static get TypeStoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_TypeStoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem", ($self) => class TypeStoreItem extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem
                {
                    //--TRIMMABLE-BOUNDARY-START(25773277223)
                    /*DynamicallyAccessedMemberTypes*/ static DynamicallyAccessedTypes = 4194303;
                    //--TRIMMABLE-BOUNDARY-END(25773277223)
                    
                    //--TRIMMABLE-BOUNDARY-START(8593408039)
                    /*object*/ _syncRoot = null;
                    //--TRIMMABLE-BOUNDARY-END(8593408039)
                    
                    //--TRIMMABLE-BOUNDARY-START(12888375335)
                    /*Type*/ _type = null;
                    //--TRIMMABLE-BOUNDARY-END(12888375335)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298440743)
                    /*Dictionary<string, PropertyStoreItem>?*/ _propertyStoreItems = null;
                    //--TRIMMABLE-BOUNDARY-END(4298440743)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183342631)
                    $ctor$2(/*Type*/ type, /*AttributeCollection*/ attributes)
                    {
                        super.$ctor$1(attributes);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17183342631);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._type = type;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183342631)
                    
                    //--TRIMMABLE-BOUNDARY-START(34363211815)
                    /*PropertyStoreItem */ GetPropertyStoreItem(/*string*/ propertyName)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34363211815);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*PropertyStoreItem?*/ let item;
                        if (!this.TryGetPropertyStoreItem(propertyName, $.$ref(() => item, ($v) => item = $v, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem)))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$13($.$sca.System.SR.Format$5($.$sca.System.SR.AttributeStore_Unknown_Property, this._type.Name, propertyName), "propertyName");
                        }
                        return item;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34363211815)
                    
                    //--TRIMMABLE-BOUNDARY-START(38658179111)
                    /*bool */ TryGetPropertyStoreItem(/*string*/ propertyName, /*out PropertyStoreItem?*/ item)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38658179111);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if ($.$$.System.String.IsNullOrEmpty(propertyName))
                        {
                            throw new $.$$.System.ArgumentNullException().$ctor$19("propertyName");
                        }
                        if (this._propertyStoreItems === null)
                        {
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(this._syncRoot)
                                {
                                    this._propertyStoreItems ??= this.CreatePropertyStoreItems();
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(this._syncRoot)
                            }
                        }
                        return this._propertyStoreItems.TryGetValue(propertyName, item);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38658179111)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478309927)
                    /*Dictionary<string, PropertyStoreItem> */ CreatePropertyStoreItems()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21478309927);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let propertyStoreItems = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem))().$ctor$1();
                        /*var*/ let properties = $.$sct.System.ComponentModel.TypeDescriptor.GetProperties$5(this._type);
                        var $en4 = properties.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var property = $en4.System$Collections$IEnumerator$Current;
                            {
                                /*var*/ let item = new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem().$ctor$2(property.PropertyType, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem.GetExplicitAttributes(property));
                                propertyStoreItems.set_Item(property.Name, item);
                            }
                        }
                        return propertyStoreItems;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21478309927)
                    
                    //--TRIMMABLE-BOUNDARY-START(30068244519)
                    static /*AttributeCollection */ GetExplicitAttributes(/*PropertyDescriptor*/ propertyDescriptor)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30068244519);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*AttributeCollection*/ let propertyDescriptorAttributes = propertyDescriptor.Attributes;
                        /*List<Attribute>*/ let attributes = new ($.$$.System.Collections.Generic.List$$($.$$.System.Attribute))().$ctor$3(propertyDescriptorAttributes.Count);
                        var $en4 = propertyDescriptorAttributes.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attribute = $en4.System$Collections$IEnumerator$Current;
                            {
                                attributes.Add(attribute);
                            }
                        }
                        /*AttributeCollection*/ let typeAttributes = $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes$2(propertyDescriptor.PropertyType);
                        /*bool*/ let removedAttribute = false;
                        var $en4 = typeAttributes.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var attr = $en4.System$Collections$IEnumerator$Current;
                            {
                                for(/*int*/ let i = ((attributes.Count - 1) | 0); i >= 0; --i)
                                {
                                    if ($.$$.System.Object.ReferenceEquals(attr, attributes.get_Item(i)))
                                    {
                                        attributes.RemoveAt(i);
                                        removedAttribute = true;
                                    }
                                }
                            }
                        }
                        return removedAttribute ? new $.$sct.System.ComponentModel.AttributeCollection().$ctor$2(attributes.ToArray()) : propertyDescriptorAttributes;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30068244519)
                    
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(8593408039)
                        this._syncRoot = new $.$$.System.Object().$ctor();
                        //--TRIMMABLE-BOUNDARY-END(8593408039)
                        
                    }
                    static $h = 3473447;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 3407911,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34363211815),
    {
      "r": 3342375,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        }
      ],
      "n": "GetPropertyStoreItem",
      "d": 3473447,
      "h": 34363211815,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(34363211815),
//--TRIMMABLE-BOUNDARY-START(38658179111),
    {
      "r": 262145,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "item",
          "p": 3342375,
          "f": 2
        }
      ],
      "n": "TryGetPropertyStoreItem",
      "d": 3473447,
      "h": 38658179111,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(38658179111),
//--TRIMMABLE-BOUNDARY-START(21478309927),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem).$h,
      "n": "CreatePropertyStoreItems",
      "d": 3473447,
      "h": 21478309927,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21478309927),
//--TRIMMABLE-BOUNDARY-START(30068244519),
    {
      "r": 1179689,
      "p": [
        {
          "n": "propertyDescriptor",
          "p": 14024745
        }
      ],
      "n": "GetExplicitAttributes",
      "d": 3473447,
      "h": 30068244519,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30068244519)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25773277223),
    {
      "n": "DynamicallyAccessedTypes",
      "d": 3473447,
      "h": 25773277223,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25773277223),
//--TRIMMABLE-BOUNDARY-START(8593408039),
    {
      "t": 131073,
      "n": "_syncRoot",
      "d": 3473447,
      "h": 8593408039,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593408039),
//--TRIMMABLE-BOUNDARY-START(12888375335),
    {
      "t": 187760641,
      "n": "_type",
      "d": 3473447,
      "h": 12888375335,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888375335),
//--TRIMMABLE-BOUNDARY-START(4298440743),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem).$h,
      "n": "_propertyStoreItems",
      "d": 3473447,
      "h": 4298440743,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298440743)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183342631),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "attributes",
          "p": 1179689
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3473447,
      "h": 17183342631,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17183342631)
  ],
  "d": 3276839,
  "h": 3473447
}; }
                    static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem`; }
                }, $cls, ($v) => $cls.$_TypeStoreItem = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3473447)
            
            //--TRIMMABLE-BOUNDARY-START(3342375)
            static $_PropertyStoreItem;
            static get PropertyStoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_PropertyStoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem", ($self) => class PropertyStoreItem extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem
                {
                    //--TRIMMABLE-BOUNDARY-START(8593276967)
                    $ctor$2(/*Type*/ propertyType, /*AttributeCollection*/ attributes)
                    {
                        super.$ctor$1(attributes);
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8593276967);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Inequality$1(propertyType, null), "propertyType != null");
                            this.PropertyType = propertyType;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8593276967)
                    
                    //--TRIMMABLE-BOUNDARY-START(21478178855)
                    /*Type*/ PropertyType = null;
                    //--TRIMMABLE-BOUNDARY-END(21478178855)
                    
                    static $h = 3342375;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 3407911,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21478178855),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17183211559,
        "f": 50331656
      },
      "n": "PropertyType",
      "d": 3342375,
      "h": 21478178855,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21478178855)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8593276967),
    {
      "p": [
        {
          "n": "propertyType",
          "p": 187760641
        },
        {
          "n": "attributes",
          "p": 1179689
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3342375,
      "h": 8593276967,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8593276967)
  ],
  "d": 3276839,
  "h": 3342375
}; }
                    static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem`; }
                }, $cls, ($v) => $cls.$_PropertyStoreItem = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3342375)
            
            //--TRIMMABLE-BOUNDARY-START(30068047911)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068047911)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4298244135)
                this._typeStoreItems = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4298244135)
                
            }
            //--TRIMMABLE-BOUNDARY-START(25773080615)
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore().$ctor$1();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773080615)
            
            static $h = 3276839;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73017720871),
    {
      "p": 3276839,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952949799,
        "f": 50331688
      },
      "n": "Instance",
      "d": 3276839,
      "h": 73017720871,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(73017720871)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(68722753575),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetTypeValidationAttributes",
      "d": 3276839,
      "h": 68722753575,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68722753575),
//--TRIMMABLE-BOUNDARY-START(60132818983),
    {
      "r": 983079,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetTypeDisplayAttribute",
      "d": 3276839,
      "h": 60132818983,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(60132818983),
//--TRIMMABLE-BOUNDARY-START(55837851687),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetPropertyValidationAttributes",
      "d": 3276839,
      "h": 55837851687,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(55837851687),
//--TRIMMABLE-BOUNDARY-START(47247917095),
    {
      "r": 983079,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetPropertyDisplayAttribute",
      "d": 3276839,
      "h": 47247917095,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47247917095),
//--TRIMMABLE-BOUNDARY-START(51542884391),
    {
      "r": 187760641,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetPropertyType",
      "d": 3276839,
      "h": 51542884391,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51542884391),
//--TRIMMABLE-BOUNDARY-START(77312688167),
    {
      "r": 262145,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "IsPropertyContext",
      "d": 3276839,
      "h": 77312688167,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(77312688167),
//--TRIMMABLE-BOUNDARY-START(64427786279),
    {
      "r": 3473447,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetTypeStoreItem",
      "d": 3276839,
      "h": 64427786279,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(64427786279),
//--TRIMMABLE-BOUNDARY-START(34363015207),
    {
      "r": 65537,
      "p": [
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "EnsureValidationContext",
      "d": 3276839,
      "h": 34363015207,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34363015207),
//--TRIMMABLE-BOUNDARY-START(81607655463),
    {
      "r": 262145,
      "p": [
        {
          "n": "p",
          "p": 118882305
        }
      ],
      "n": "IsPublic",
      "d": 3276839,
      "h": 81607655463,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(81607655463)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298244135),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem).$h,
      "n": "_typeStoreItems",
      "d": 3276839,
      "h": 4298244135,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298244135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30068047911),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3276839,
      "h": 30068047911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068047911)
  ],
  "j": [3407911,3473447,3342375
  ],
  "h": 3276839
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3276839)
        
        
        //--TRIMMABLE-BOUNDARY-START(3735591)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Validator", ($self) => class Validator
        {
            //--TRIMMABLE-BOUNDARY-START(4298702887)
            /*ValidationAttributeStore*/ static _store = null;
            //--TRIMMABLE-BOUNDARY-END(4298702887)
            
            //--TRIMMABLE-BOUNDARY-START(60133277735)
            static /*bool */ TryValidateProperty(/*object?*/ value, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60133277735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let propertyType = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyType(validationContext);
                /*var*/ let propertyName = validationContext.MemberName;
                $.$sca.System.ComponentModel.DataAnnotations.Validator.EnsureValidPropertyType(propertyName, propertyType, value);
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = (validationResults === null);
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(validationContext);
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, attributes, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(60133277735)
            
            //--TRIMMABLE-BOUNDARY-START(55838310439)
            static /*bool */ TryValidateObject$1(/*object*/ instance, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55838310439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateObject(instance, validationContext, validationResults, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55838310439)
            
            //--TRIMMABLE-BOUNDARY-START(51543343143)
            static /*bool */ TryValidateObject(/*object*/ instance, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults, /*bool*/ validateAllProperties)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543343143);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                if (validationContext !== null && instance !== validationContext.ObjectInstance)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sca.System.SR.Validator_InstanceMustMatchValidationContextInstance, "instance");
                }
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = (validationResults === null);
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectValidationErrors(instance, validationContext, validateAllProperties, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(51543343143)
            
            //--TRIMMABLE-BOUNDARY-START(64428245031)
            static /*bool */ TryValidateValue(/*object?*/ value, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults, /*IEnumerable<ValidationAttribute>*/ validationAttributes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64428245031);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationAttributes, "validationAttributes");
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = validationResults === null;
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, validationAttributes, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(64428245031)
            
            //--TRIMMABLE-BOUNDARY-START(77313146919)
            static /*void */ ValidateProperty(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77313146919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let propertyType = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyType(validationContext);
                $.$sca.System.ComponentModel.DataAnnotations.Validator.EnsureValidPropertyType(validationContext.MemberName, propertyType, value);
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(validationContext);
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, attributes, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77313146919)
            
            //--TRIMMABLE-BOUNDARY-START(73018179623)
            static /*void */ ValidateObject$1(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73018179623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidateObject(instance, validationContext, false);
            }
            //--TRIMMABLE-BOUNDARY-END(73018179623)
            
            //--TRIMMABLE-BOUNDARY-START(68723212327)
            static /*void */ ValidateObject(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68723212327);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                if (instance !== validationContext.ObjectInstance)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sca.System.SR.Validator_InstanceMustMatchValidationContextInstance, "instance");
                }
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectValidationErrors(instance, validationContext, validateAllProperties, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68723212327)
            
            //--TRIMMABLE-BOUNDARY-START(81608114215)
            static /*void */ ValidateValue(/*object?*/ value, /*ValidationContext*/ validationContext, /*IEnumerable<ValidationAttribute>*/ validationAttributes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81608114215);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationAttributes, "validationAttributes");
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, validationAttributes, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81608114215)
            
            //--TRIMMABLE-BOUNDARY-START(21478572071)
            static /*ValidationContext */ CreateValidationContext(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21478572071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(validationContext !== null, "validationContext != null");
                /*var*/ let context = new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext().$ctor$3(instance, validationContext, validationContext.Items);
                return context;
            }
            //--TRIMMABLE-BOUNDARY-END(21478572071)
            
            //--TRIMMABLE-BOUNDARY-START(17183604775)
            static /*bool */ CanBeAssigned(/*Type*/ destinationType, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17183604775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return !destinationType.IsValueType || (destinationType.IsGenericType && $.$$.System.Type.op_Equality$1(destinationType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type));
                }
                return destinationType.IsInstanceOfType(value);
            }
            //--TRIMMABLE-BOUNDARY-END(17183604775)
            
            //--TRIMMABLE-BOUNDARY-START(25773539367)
            static /*void */ EnsureValidPropertyType(/*string*/ propertyName, /*Type*/ propertyType, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25773539367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.CanBeAssigned(propertyType, value))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sca.System.SR.Format$5($.$sca.System.SR.Validator_Property_Value_Wrong_Type, propertyName, propertyType), "value");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25773539367)
            
            //--TRIMMABLE-BOUNDARY-START(34363473959)
            static /*List<ValidationError> */ GetObjectValidationErrors(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties, /*bool*/ breakOnFirstError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34363473959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                $.$$.System.Diagnostics.Debug.Assert$2(instance !== null, "instance != null");
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectPropertyValidationErrors(instance, validationContext, validateAllProperties, breakOnFirstError);
                if (errors.Count > 0)
                {
                    return errors;
                }
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetTypeValidationAttributes(validationContext);
                errors.AddRange($.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(instance, validationContext, attributes, breakOnFirstError));
                if (errors.Count > 0)
                {
                    return errors;
                }
                let validatable;
                if ($.$is(instance, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject, { set $v(v){ validatable = v; } }))
                {
                    /*var*/ let results = validatable.System$ComponentModel$DataAnnotations$IValidatableObject$Validate(validationContext);
                    if (results !== null)
                    {
                        var $en4 = results.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var result = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                                {
                                    errors.Add(new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(null, instance, result));
                                }
                            }
                        }
                    }
                }
                return errors;
            }
            //--TRIMMABLE-BOUNDARY-END(34363473959)
            
            //--TRIMMABLE-BOUNDARY-START(30068506663)
            static /*List<ValidationError> */ GetObjectPropertyValidationErrors(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties, /*bool*/ breakOnFirstError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30068506663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetPropertyValues(instance, validationContext);
                /*var*/ let errors = new ($.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError))().$ctor$1();
                var $en2 = properties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(property.Key);
                        if (validateAllProperties)
                        {
                            errors.AddRange($.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(property.Value, property.Key, attributes, breakOnFirstError));
                        }
                        else 
                        {
                            var $en5 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var attribute = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    let reqAttr;
                                    if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute, { set $v(v){ reqAttr = v; } }))
                                    {
                                        /*var*/ let validationResult = reqAttr.GetValidationResult(property.Value, property.Key);
                                        if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                                        {
                                            errors.Add(new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(reqAttr, property.Value, validationResult));
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        if (breakOnFirstError && errors.Count > 0)
                        {
                            break;
                        }
                    }
                }
                return errors;
            }
            //--TRIMMABLE-BOUNDARY-END(30068506663)
            
            //--TRIMMABLE-BOUNDARY-START(38658441255)
            static /*List<KeyValuePair<ValidationContext, object?>> */ GetPropertyValues(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38658441255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let properties = $.$sct.System.ComponentModel.TypeDescriptor.GetProperties$5($.$$.System.Object.GetType.call(instance));
                /*var*/ let items = new ($.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$$.System.Object)))().$ctor$3(properties.Count);
                var $en2 = properties.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var property = $en2.System$Collections$IEnumerator$Current;
                    {
                        /*var*/ let context = $.$sca.System.ComponentModel.DataAnnotations.Validator.CreateValidationContext(instance, validationContext);
                        context.MemberName = property.Name;
                        if ($.$sl.System.Linq.Enumerable.Any$1($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(context)))
                        {
                            items.Add(new ($.$$.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$$.System.Object))().$ctor$3(context, property.GetValue(instance)));
                        }
                    }
                }
                return items;
            }
            //--TRIMMABLE-BOUNDARY-END(38658441255)
            
            //--TRIMMABLE-BOUNDARY-START(42953408551)
            static /*List<ValidationError> */ GetValidationErrors(/*object?*/ value, /*ValidationContext*/ validationContext, /*IEnumerable<ValidationAttribute>*/ attributes, /*bool*/ breakOnFirstError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42953408551);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                /*var*/ let errors = new ($.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError))().$ctor$1();
                /*ValidationError?*/ let validationError;
                /*RequiredAttribute?*/ let required = null;
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        required = $.$as(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute);
                        if (!(required === null))
                        {
                            if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidate(value, validationContext, required, $.$ref(() => validationError, ($v) => validationError = $v, $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError)))
                            {
                                errors.Add(validationError);
                                return errors;
                            }
                            break;
                        }
                    }
                }
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attr = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attr !== required)
                        {
                            if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidate(value, validationContext, attr, $.$ref(() => validationError, ($v) => validationError = $v, $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError)))
                            {
                                errors.Add(validationError);
                                if (breakOnFirstError)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                return errors;
            }
            //--TRIMMABLE-BOUNDARY-END(42953408551)
            
            //--TRIMMABLE-BOUNDARY-START(47248375847)
            static /*bool */ TryValidate(/*object?*/ value, /*ValidationContext*/ validationContext, /*ValidationAttribute*/ attribute, /*out ValidationError?*/ validationError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47248375847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(validationContext !== null, "validationContext != null");
                /*var*/ let validationResult = attribute.GetValidationResult(value, validationContext);
                if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                {
                    validationError.$v = new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(attribute, value, validationResult);
                    return false;
                }
                validationError.$v = null;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(47248375847)
            
            //--TRIMMABLE-BOUNDARY-START(3801127)
            static $_ValidationError;
            static get ValidationError()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.Validator;
                return $cls.$_ValidationError ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError", ($self) => class ValidationError extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8593735719)
                    /*object?*/ _value = null;
                    //--TRIMMABLE-BOUNDARY-END(8593735719)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298768423)
                    /*ValidationAttribute?*/ _validationAttribute = null;
                    //--TRIMMABLE-BOUNDARY-END(4298768423)
                    
                    //--TRIMMABLE-BOUNDARY-START(17183670311)
                    $ctor$1(/*ValidationAttribute?*/ validationAttribute, /*object?*/ value, /*ValidationResult*/ validationResult)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17183670311);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._validationAttribute = validationAttribute;
                            this.ValidationResult = validationResult;
                            this._value = value;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17183670311)
                    
                    //--TRIMMABLE-BOUNDARY-START(34363539495)
                    /*ValidationResult*/ ValidationResult = null;
                    //--TRIMMABLE-BOUNDARY-END(34363539495)
                    
                    //--TRIMMABLE-BOUNDARY-START(30068572199)
                    /*void */ ThrowValidationException()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(30068572199);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$10(this.ValidationResult, this._validationAttribute, this._value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(30068572199)
                    
                    static $h = 3801127;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34363539495),
    {
      "p": 3670055,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25773604903,
        "f": 50331656
      },
      "n": "ValidationResult",
      "d": 3801127,
      "h": 34363539495,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34363539495)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30068572199),
    {
      "r": 65537,
      "n": "ThrowValidationException",
      "d": 3801127,
      "h": 30068572199,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(30068572199)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593735719),
    {
      "t": 131073,
      "n": "_value",
      "d": 3801127,
      "h": 8593735719,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593735719),
//--TRIMMABLE-BOUNDARY-START(4298768423),
    {
      "t": 3211303,
      "n": "_validationAttribute",
      "d": 3801127,
      "h": 4298768423,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298768423)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183670311),
    {
      "p": [
        {
          "n": "validationAttribute",
          "p": 3211303
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationResult",
          "p": 3670055
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3801127,
      "h": 17183670311,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17183670311)
  ],
  "d": 3735591,
  "h": 3801127
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.Validator.ValidationError`; }
                }, $cls, ($v) => $cls.$_ValidationError = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3801127)
            
            //--TRIMMABLE-BOUNDARY-START(12888637479)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4298702887)
                    this._store = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.Instance;
                    //--TRIMMABLE-BOUNDARY-END(4298702887)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12888637479)
            
            static $h = 3735591;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(60133277735),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validationResults",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h
        }
      ],
      "n": "TryValidateProperty",
      "d": 3735591,
      "h": 60133277735,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60133277735),
//--TRIMMABLE-BOUNDARY-START(55838310439),
    {
      "r": 262145,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validationResults",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h
        }
      ],
      "n": "TryValidateObject",
      "o": "@$1",
      "d": 3735591,
      "h": 55838310439,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55838310439),
//--TRIMMABLE-BOUNDARY-START(51543343143),
    {
      "r": 262145,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validationResults",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h
        },
        {
          "n": "validateAllProperties",
          "p": 262145
        }
      ],
      "n": "TryValidateObject",
      "d": 3735591,
      "h": 51543343143,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51543343143),
//--TRIMMABLE-BOUNDARY-START(64428245031),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validationResults",
          "p": $.$$.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h
        },
        {
          "n": "validationAttributes",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h
        }
      ],
      "n": "TryValidateValue",
      "d": 3735591,
      "h": 64428245031,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64428245031),
//--TRIMMABLE-BOUNDARY-START(77313146919),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "ValidateProperty",
      "d": 3735591,
      "h": 77313146919,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77313146919),
//--TRIMMABLE-BOUNDARY-START(73018179623),
    {
      "r": 65537,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "ValidateObject",
      "o": "@$1",
      "d": 3735591,
      "h": 73018179623,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73018179623),
//--TRIMMABLE-BOUNDARY-START(68723212327),
    {
      "r": 65537,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validateAllProperties",
          "p": 262145
        }
      ],
      "n": "ValidateObject",
      "d": 3735591,
      "h": 68723212327,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68723212327),
//--TRIMMABLE-BOUNDARY-START(81608114215),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validationAttributes",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h
        }
      ],
      "n": "ValidateValue",
      "d": 3735591,
      "h": 81608114215,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81608114215),
//--TRIMMABLE-BOUNDARY-START(21478572071),
    {
      "r": 3538983,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "CreateValidationContext",
      "d": 3735591,
      "h": 21478572071,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21478572071),
//--TRIMMABLE-BOUNDARY-START(17183604775),
    {
      "r": 262145,
      "p": [
        {
          "n": "destinationType",
          "p": 187760641
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "CanBeAssigned",
      "d": 3735591,
      "h": 17183604775,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17183604775),
//--TRIMMABLE-BOUNDARY-START(25773539367),
    {
      "r": 65537,
      "p": [
        {
          "n": "propertyName",
          "p": 1310721
        },
        {
          "n": "propertyType",
          "p": 187760641
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "EnsureValidPropertyType",
      "d": 3735591,
      "h": 25773539367,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25773539367),
//--TRIMMABLE-BOUNDARY-START(34363473959),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validateAllProperties",
          "p": 262145
        },
        {
          "n": "breakOnFirstError",
          "p": 262145
        }
      ],
      "n": "GetObjectValidationErrors",
      "d": 3735591,
      "h": 34363473959,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34363473959),
//--TRIMMABLE-BOUNDARY-START(30068506663),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "validateAllProperties",
          "p": 262145
        },
        {
          "n": "breakOnFirstError",
          "p": 262145
        }
      ],
      "n": "GetObjectPropertyValidationErrors",
      "d": 3735591,
      "h": 30068506663,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30068506663),
//--TRIMMABLE-BOUNDARY-START(38658441255),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$$.System.Object)).$h,
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "GetPropertyValues",
      "d": 3735591,
      "h": 38658441255,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38658441255),
//--TRIMMABLE-BOUNDARY-START(42953408551),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "attributes",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h
        },
        {
          "n": "breakOnFirstError",
          "p": 262145
        }
      ],
      "n": "GetValidationErrors",
      "d": 3735591,
      "h": 42953408551,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42953408551),
//--TRIMMABLE-BOUNDARY-START(47248375847),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        },
        {
          "n": "attribute",
          "p": 3211303
        },
        {
          "n": "validationError",
          "p": 3801127,
          "f": 2
        }
      ],
      "n": "TryValidate",
      "d": 3735591,
      "h": 47248375847,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47248375847)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4298702887),
    {
      "t": 3276839,
      "n": "_store",
      "d": 3735591,
      "h": 4298702887,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4298702887)
  ],
  "j": [3801127
  ],
  "h": 3735591
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Validator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3735591)
        
        
        //--TRIMMABLE-BOUNDARY-START(589863)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper", ($self) => class CountPropertyHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295557159)
            /*string*/ static RequiresUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(4295557159)
            
            //--TRIMMABLE-BOUNDARY-START(8590524455)
            static /*bool */ TryGetCount(/*object*/ value, /*out int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590524455);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value !== null, "value != null");
                let collection;
                if ($.$is(value, $.$$.System.Collections.ICollection, { set $v(v){ collection = v; } }))
                {
                    count.$v = collection.System$Collections$ICollection$Count;
                    return true;
                }
                /*PropertyInfo?*/ let property = $.$$.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty($.$$.System.Object.GetType.call(value), "Count");
                if ($.$$.System.Reflection.PropertyInfo.op_Inequality$1(property, null) && property.CanRead && $.$$.System.Type.op_Equality$1(property.PropertyType, $.$$.System.Int32.$type))
                {
                    count.$v = $.$cast(property.GetValue$2(value), $.$$.System.Int32);
                    return true;
                }
                count.$v = -1;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524455)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557159)
                    this.RequiresUnreferencedCodeMessage = "Uses reflection to get the 'Count' property on types that don't implement ICollection. This 'Count' property may be trimmed. Ensure it is preserved.";
                    //--TRIMMABLE-BOUNDARY-END(4295557159)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 589863;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590524455),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "count",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetCount",
      "d": 589863,
      "h": 8590524455,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590524455)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557159),
    {
      "t": 1310721,
      "n": "RequiresUnreferencedCodeMessage",
      "d": 589863,
      "h": 4295557159,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295557159)
  ],
  "h": 589863
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CountPropertyHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589863)
        
        
        //--TRIMMABLE-BOUNDARY-START(3670055)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationResult", ($self) => class ValidationResult extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(60133212199)
            /*ValidationResult?*/ static Success = null;
            //--TRIMMABLE-BOUNDARY-END(60133212199)
            
            //--TRIMMABLE-BOUNDARY-START(17183539239)
            $ctor$2(/*string?*/ errorMessage)
            {
                this.$ctor$1(errorMessage, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183539239);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183539239)
            
            //--TRIMMABLE-BOUNDARY-START(12888571943)
            $ctor$1(/*string?*/ errorMessage, /*IEnumerable<string>?*/ memberNames)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12888571943);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ErrorMessage = errorMessage;
                    this.MemberNames = memberNames ?? $.$$.System.Array.Empty($.$$.System.String);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12888571943)
            
            //--TRIMMABLE-BOUNDARY-START(21478506535)
            $ctor$3(/*ValidationResult*/ validationResult)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478506535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(validationResult, "validationResult");
                    this.ErrorMessage = validationResult.ErrorMessage;
                    this.MemberNames = validationResult.MemberNames;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478506535)
            
            //--TRIMMABLE-BOUNDARY-START(47248310311)
            /*IEnumerable<string>*/ MemberNames = null;
            //--TRIMMABLE-BOUNDARY-END(47248310311)
            
            //--TRIMMABLE-BOUNDARY-START(25773473831)
            /*string?*/ ErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25773473831)
            
            //--TRIMMABLE-BOUNDARY-START(64428179495)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64428179495);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ErrorMessage ?? $.$$.System.Object.ToString.call(this);
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(64428179495)
            
            static $h = 3670055;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47248310311),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42953343015,
        "f": 50331649
      },
      "n": "MemberNames",
      "d": 3670055,
      "h": 47248310311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47248310311),
//--TRIMMABLE-BOUNDARY-START(25773473831),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34363408423,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 55838244903,
        "f": 83886081
      },
      "n": "ErrorMessage",
      "d": 3670055,
      "h": 25773473831,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25773473831)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64428179495),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 3670055,
      "h": 64428179495,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64428179495)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(60133212199),
    {
      "t": 3670055,
      "n": "Success",
      "d": 3670055,
      "h": 60133212199,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60133212199)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17183539239),
    {
      "p": [
        {
          "n": "errorMessage",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3670055,
      "h": 17183539239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17183539239),
//--TRIMMABLE-BOUNDARY-START(12888571943),
    {
      "p": [
        {
          "n": "errorMessage",
          "p": 1310721
        },
        {
          "n": "memberNames",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3670055,
      "h": 12888571943,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12888571943),
//--TRIMMABLE-BOUNDARY-START(21478506535),
    {
      "p": [
        {
          "n": "validationResult",
          "p": 3670055
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3670055,
      "h": 21478506535,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(21478506535)
  ],
  "h": 3670055
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationResult`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3670055)
        
        
        //--TRIMMABLE-BOUNDARY-START(3538983)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationContext", ($self) => class ValidationContext extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(103082754087)
            /*string*/ static InstanceTypeNotStaticallyDiscovered = null;
            //--TRIMMABLE-BOUNDARY-END(103082754087)
            
            //--TRIMMABLE-BOUNDARY-START(8593473575)
            /*Dictionary<object, object?>*/ _items = null;
            //--TRIMMABLE-BOUNDARY-END(8593473575)
            
            //--TRIMMABLE-BOUNDARY-START(4298506279)
            /*string?*/ _displayName = null;
            //--TRIMMABLE-BOUNDARY-END(4298506279)
            
            //--TRIMMABLE-BOUNDARY-START(12888440871)
            /*Func<Type, object?>?*/ _serviceProvider = null;
            //--TRIMMABLE-BOUNDARY-END(12888440871)
            
            //--TRIMMABLE-BOUNDARY-START(38658244647)
            $ctor$4(/*object*/ instance)
            {
                this.$ctor$3(instance, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658244647);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38658244647)
            
            //--TRIMMABLE-BOUNDARY-START(25773342759)
            $ctor$1(/*object*/ instance, /*IDictionary<object, object?>?*/ items)
            {
                this.$ctor$3(instance, null, items);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773342759);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25773342759)
            
            //--TRIMMABLE-BOUNDARY-START(34363277351)
            $ctor$3(/*object*/ instance, /*IServiceProvider?*/ serviceProvider, /*IDictionary<object, object?>?*/ items)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363277351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                    if (serviceProvider !== null)
                    {
                        /*IServiceProvider*/ let localServiceProvider = serviceProvider;
                        this.InitializeServiceProvider(new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object))().$ctor(localServiceProvider, localServiceProvider.System$IServiceProvider$GetService));
                    }
                    this._items = items !== null ? new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$3(items) : new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$1();
                    this.ObjectInstance = instance;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34363277351)
            
            //--TRIMMABLE-BOUNDARY-START(30068310055)
            $ctor$2(/*object*/ instance, /*string*/ displayName, /*IServiceProvider?*/ serviceProvider, /*IDictionary<object, object?>?*/ items)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068310055);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrEmpty(displayName, "displayName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(instance, "instance");
                    if (serviceProvider !== null)
                    {
                        /*IServiceProvider*/ let localServiceProvider = serviceProvider;
                        this.InitializeServiceProvider(new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object))().$ctor(localServiceProvider, localServiceProvider.System$IServiceProvider$GetService));
                    }
                    this._items = items !== null ? new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$3(items) : new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object))().$ctor$1();
                    this.ObjectInstance = instance;
                    this.DisplayName = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068310055)
            
            //--TRIMMABLE-BOUNDARY-START(115967655975)
            /*object*/ ObjectInstance = null;
            //--TRIMMABLE-BOUNDARY-END(115967655975)
            
            //--TRIMMABLE-BOUNDARY-START(120262623271)
            /*Type */ get ObjectType()
            {
                return $.$$.System.Object.GetType.call(this.ObjectInstance);
            }
            //--TRIMMABLE-BOUNDARY-END(120262623271)
            
            //--TRIMMABLE-BOUNDARY-START(42953211943)
            /*string */ get DisplayName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51543146535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(this._displayName))
                {
                    this._displayName = this.GetDisplayName();
                    if ($.$$.System.String.IsNullOrEmpty(this._displayName))
                    {
                        this._displayName = this.ObjectType.Name;
                    }
                }
                return this._displayName;
            }
            /*string */ set DisplayName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128852557863);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("value");
                }
                this._displayName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42953211943)
            
            //--TRIMMABLE-BOUNDARY-START(111672688679)
            /*string?*/ MemberName = null;
            //--TRIMMABLE-BOUNDARY-END(111672688679)
            
            //--TRIMMABLE-BOUNDARY-START(107377721383)
            /*IDictionary<object, object?> */ get Items()
            {
                return this._items;
            }
            //--TRIMMABLE-BOUNDARY-END(107377721383)
            
            //--TRIMMABLE-BOUNDARY-START(90197852199)
            /*string? */ GetDisplayName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90197852199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let displayName = null;
                /*ValidationAttributeStore*/ let store = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.Instance;
                /*DisplayAttribute?*/ let displayAttribute = null;
                if ($.$$.System.String.IsNullOrEmpty(this.MemberName))
                {
                    displayAttribute = store.GetTypeDisplayAttribute(this);
                }
                else if (store.IsPropertyContext(this))
                {
                    displayAttribute = store.GetPropertyDisplayAttribute(this);
                }
                if (displayAttribute !== null)
                {
                    displayName = displayAttribute.GetName();
                }
                return displayName ?? this.MemberName;
            }
            //--TRIMMABLE-BOUNDARY-END(90197852199)
            
            //--TRIMMABLE-BOUNDARY-START(98787786791)
            /*void */ InitializeServiceProvider(/*Func<Type, object?>*/ serviceProvider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98787786791);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._serviceProvider = serviceProvider;
            }
            //--TRIMMABLE-BOUNDARY-END(98787786791)
            
            //--TRIMMABLE-BOUNDARY-START(94492819495)
            /*object? */ GetService(/*Type*/ serviceType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94492819495);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._serviceProvider?.Invoke(serviceType) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94492819495)
            
            //--TRIMMABLE-BOUNDARY-START(4295295014)
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295014);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetService(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295295014)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(103082754087)
                    this.InstanceTypeNotStaticallyDiscovered = "Constructing a ValidationContext without a display name is not trim-safe because it uses reflection to discover the type of the instance being validated in order to resolve the DisplayNameAttribute when a display name is not provided.";
                    //--TRIMMABLE-BOUNDARY-END(103082754087)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 3538983;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(115967655975),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77312950311,
        "f": 50331649
      },
      "n": "ObjectInstance",
      "d": 3538983,
      "h": 115967655975,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115967655975),
//--TRIMMABLE-BOUNDARY-START(120262623271),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85902884903,
        "f": 50331649
      },
      "n": "ObjectType",
      "d": 3538983,
      "h": 120262623271,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120262623271),
//--TRIMMABLE-BOUNDARY-START(42953211943),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51543146535,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128852557863,
        "f": 83886081
      },
      "n": "DisplayName",
      "d": 3538983,
      "h": 42953211943,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42953211943),
//--TRIMMABLE-BOUNDARY-START(111672688679),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68723015719,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137442492455,
        "f": 83886081
      },
      "n": "MemberName",
      "d": 3538983,
      "h": 111672688679,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111672688679),
//--TRIMMABLE-BOUNDARY-START(107377721383),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.Object, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60133081127,
        "f": 50331649
      },
      "n": "Items",
      "d": 3538983,
      "h": 107377721383,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107377721383)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(90197852199),
    {
      "r": 1310721,
      "n": "GetDisplayName",
      "d": 3538983,
      "h": 90197852199,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90197852199),
//--TRIMMABLE-BOUNDARY-START(98787786791),
    {
      "r": 65537,
      "p": [
        {
          "n": "serviceProvider",
          "p": $.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object).$h
        }
      ],
      "n": "InitializeServiceProvider",
      "d": 3538983,
      "h": 98787786791,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98787786791),
//--TRIMMABLE-BOUNDARY-START(94492819495),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetService",
      "d": 3538983,
      "h": 94492819495,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94492819495)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(103082754087),
    {
      "t": 1310721,
      "n": "InstanceTypeNotStaticallyDiscovered",
      "d": 3538983,
      "h": 103082754087,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103082754087),
//--TRIMMABLE-BOUNDARY-START(8593473575),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Object, $.$$.System.Object).$h,
      "n": "_items",
      "d": 3538983,
      "h": 8593473575,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593473575),
//--TRIMMABLE-BOUNDARY-START(4298506279),
    {
      "t": 1310721,
      "n": "_displayName",
      "d": 3538983,
      "h": 4298506279,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298506279),
//--TRIMMABLE-BOUNDARY-START(12888440871),
    {
      "t": $.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object).$h,
      "n": "_serviceProvider",
      "d": 3538983,
      "h": 12888440871,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12888440871)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38658244647),
    {
      "p": [
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3538983,
      "h": 38658244647,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38658244647),
//--TRIMMABLE-BOUNDARY-START(25773342759),
    {
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3538983,
      "h": 25773342759,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25773342759),
//--TRIMMABLE-BOUNDARY-START(34363277351),
    {
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3538983,
      "h": 34363277351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34363277351),
//--TRIMMABLE-BOUNDARY-START(30068310055),
    {
      "p": [
        {
          "n": "instance",
          "p": 131073
        },
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "serviceProvider",
          "p": 327718
        },
        {
          "n": "items",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3538983,
      "h": 30068310055,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30068310055)
  ],
  "i": [327718
  ],
  "h": 3538983
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3538983)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114151)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute", ($self) => class DisplayFormatAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296081447)
            /*LocalizableString*/ _nullDisplayText = null;
            //--TRIMMABLE-BOUNDARY-END(4296081447)
            
            //--TRIMMABLE-BOUNDARY-START(25770917927)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770917927);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ConvertEmptyStringToNull = true;
                    this.HtmlEncode = true;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770917927)
            
            //--TRIMMABLE-BOUNDARY-START(38655819815)
            /*string?*/ DataFormatString = null;
            //--TRIMMABLE-BOUNDARY-END(38655819815)
            
            //--TRIMMABLE-BOUNDARY-START(103080329255)
            /*string? */ get NullDisplayText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605492775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nullDisplayText.Value;
            }
            /*string? */ set NullDisplayText(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324969511);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nullDisplayText.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(103080329255)
            
            //--TRIMMABLE-BOUNDARY-START(34360852519)
            /*bool*/ ConvertEmptyStringToNull = false;
            //--TRIMMABLE-BOUNDARY-END(34360852519)
            
            //--TRIMMABLE-BOUNDARY-START(30065885223)
            /*bool*/ ApplyFormatInEditMode = false;
            //--TRIMMABLE-BOUNDARY-END(30065885223)
            
            //--TRIMMABLE-BOUNDARY-START(98785361959)
            /*bool*/ HtmlEncode = false;
            //--TRIMMABLE-BOUNDARY-END(98785361959)
            
            //--TRIMMABLE-BOUNDARY-START(107375296551)
            /*Type? */ get NullDisplayTextResourceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195427367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nullDisplayText.ResourceType;
            }
            /*Type? */ set NullDisplayTextResourceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914904103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._nullDisplayText.ResourceType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(107375296551)
            
            //--TRIMMABLE-BOUNDARY-START(94490394663)
            /*string? */ GetNullDisplayText()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490394663);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._nullDisplayText.GetLocalizableValue();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490394663)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296081447)
                this._nullDisplayText = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("NullDisplayText");
                //--TRIMMABLE-BOUNDARY-END(4296081447)
                
            }
            static $h = 1114151;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655819815),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425623591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145100327,
        "f": 83886081
      },
      "n": "DataFormatString",
      "d": 1114151,
      "h": 38655819815,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819815),
//--TRIMMABLE-BOUNDARY-START(103080329255),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605492775,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324969511,
        "f": 83886081
      },
      "n": "NullDisplayText",
      "d": 1114151,
      "h": 103080329255,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080329255),
//--TRIMMABLE-BOUNDARY-START(34360852519),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835688999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124555165735,
        "f": 83886081
      },
      "n": "ConvertEmptyStringToNull",
      "d": 1114151,
      "h": 34360852519,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360852519),
//--TRIMMABLE-BOUNDARY-START(30065885223),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245754407,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115965231143,
        "f": 83886081
      },
      "n": "ApplyFormatInEditMode",
      "d": 1114151,
      "h": 30065885223,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065885223),
//--TRIMMABLE-BOUNDARY-START(98785361959),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015558183,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141735034919,
        "f": 83886081
      },
      "n": "HtmlEncode",
      "d": 1114151,
      "h": 98785361959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785361959),
//--TRIMMABLE-BOUNDARY-START(107375296551),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195427367,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914904103,
        "f": 83886081
      },
      "n": "NullDisplayTextResourceType",
      "d": 1114151,
      "h": 107375296551,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375296551)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490394663),
    {
      "r": 1310721,
      "n": "GetNullDisplayText",
      "d": 1114151,
      "h": 94490394663,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490394663)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081447),
    {
      "t": 1703975,
      "n": "_nullDisplayText",
      "d": 1114151,
      "h": 4296081447,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770917927),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114151,
      "h": 25770917927,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770917927)
  ],
  "h": 1114151,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayFormatAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114151)
        
        
        //--TRIMMABLE-BOUNDARY-START(327719)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociationAttribute", ($self) => class AssociationAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475164199)
            $ctor$2(/*string*/ name, /*string*/ thisKey, /*string*/ otherKey)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475164199);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Name = name;
                    this.ThisKey = thisKey;
                    this.OtherKey = otherKey;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164199)
            
            //--TRIMMABLE-BOUNDARY-START(85899673639)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(85899673639)
            
            //--TRIMMABLE-BOUNDARY-START(107374510119)
            /*string*/ ThisKey = null;
            //--TRIMMABLE-BOUNDARY-END(107374510119)
            
            //--TRIMMABLE-BOUNDARY-START(90194640935)
            /*string*/ OtherKey = null;
            //--TRIMMABLE-BOUNDARY-END(90194640935)
            
            //--TRIMMABLE-BOUNDARY-START(81604706343)
            /*bool*/ IsForeignKey = false;
            //--TRIMMABLE-BOUNDARY-END(81604706343)
            
            //--TRIMMABLE-BOUNDARY-START(111669477415)
            /*IEnumerable<string> */ get ThisKeyMembers()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.AssociationAttribute.GetKeyMembers(this.ThisKey);
            }
            //--TRIMMABLE-BOUNDARY-END(111669477415)
            
            //--TRIMMABLE-BOUNDARY-START(94489608231)
            /*IEnumerable<string> */ get OtherKeyMembers()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.AssociationAttribute.GetKeyMembers(this.OtherKey);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608231)
            
            //--TRIMMABLE-BOUNDARY-START(77309739047)
            static /*string[] */ GetKeyMembers(/*string?*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(key, null))
                {
                    return $.$$.System.Array.Empty($.$$.System.String);
                }
                return $.$$.System.String.Split$1.call($.$$.System.String.Replace$3.call(key, " ", $.$$.System.String.Empty), /*,*/ 44, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(77309739047)
            
            static $h = 327719;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899673639),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033383,
        "f": 50331649
      },
      "n": "Name",
      "d": 327719,
      "h": 85899673639,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899673639),
//--TRIMMABLE-BOUNDARY-START(107374510119),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837159,
        "f": 50331649
      },
      "n": "ThisKey",
      "d": 327719,
      "h": 107374510119,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374510119),
//--TRIMMABLE-BOUNDARY-START(90194640935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244967975,
        "f": 50331649
      },
      "n": "OtherKey",
      "d": 327719,
      "h": 90194640935,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640935),
//--TRIMMABLE-BOUNDARY-START(81604706343),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065098791,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103079542823,
        "f": 83886081
      },
      "n": "IsForeignKey",
      "d": 327719,
      "h": 81604706343,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604706343),
//--TRIMMABLE-BOUNDARY-START(111669477415),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771751,
        "f": 50331649
      },
      "n": "ThisKeyMembers",
      "d": 327719,
      "h": 111669477415,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669477415),
//--TRIMMABLE-BOUNDARY-START(94489608231),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902567,
        "f": 50331649
      },
      "n": "OtherKeyMembers",
      "d": 327719,
      "h": 94489608231,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608231)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77309739047),
    {
      "r": $.$typeArray($.$$.System.String).$h,
      "p": [
        {
          "n": "key",
          "p": 1310721
        }
      ],
      "n": "GetKeyMembers",
      "d": 327719,
      "h": 77309739047,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(77309739047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475164199),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "thisKey",
          "p": 1310721
        },
        {
          "n": "otherKey",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327719,
      "h": 21475164199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475164199)
  ],
  "h": 327719,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 103743489,
      "c": 30168514561,
      "a": [
        {
          "v": "AssociationAttribute has been deprecated and is not supported.",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327719)
        
        
        //--TRIMMABLE-BOUNDARY-START(131111)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptionProvider", ($self) => class AssociatedMetadataTypeTypeDescriptionProvider extends $.$sct.System.ComponentModel.TypeDescriptionProvider
        {
            //--TRIMMABLE-BOUNDARY-START(17180000295)
            /*DynamicallyAccessedMemberTypes*/ static AllMembersAndInterfaces = 4194303;
            //--TRIMMABLE-BOUNDARY-END(17180000295)
            
            //--TRIMMABLE-BOUNDARY-START(4295098407)
            /*Type?*/ _associatedMetadataType = null;
            //--TRIMMABLE-BOUNDARY-END(4295098407)
            
            //--TRIMMABLE-BOUNDARY-START(12885032999)
            $ctor$4(/*Type*/ type)
            {
                super.$ctor$2($.$sct.System.ComponentModel.TypeDescriptor.GetProvider$1(type));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885032999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032999)
            
            //--TRIMMABLE-BOUNDARY-START(8590065703)
            $ctor$3(/*Type*/ type, /*Type*/ associatedMetadataType)
            {
                this.$ctor$4(type);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(associatedMetadataType, "associatedMetadataType");
                    this._associatedMetadataType = associatedMetadataType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065703)
            
            //--TRIMMABLE-BOUNDARY-START(21474967591)
            /*ICustomTypeDescriptor */ GetTypeDescriptor$1(/*Type*/ objectType, /*object?*/ instance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ICustomTypeDescriptor?*/ let baseDescriptor = super.GetTypeDescriptor$1(objectType, instance);
                return new $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor().$ctor$3(baseDescriptor, objectType, this._associatedMetadataType);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967591)
            
            static $h = 131111;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 16121897,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474967591),
    {
      "r": 10616873,
      "p": [
        {
          "n": "objectType",
          "p": 187760641
        },
        {
          "n": "instance",
          "p": 131073
        }
      ],
      "n": "GetTypeDescriptor",
      "o": "@$1",
      "d": 131111,
      "h": 21474967591,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21474967591)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180000295),
    {
      "n": "AllMembersAndInterfaces",
      "d": 131111,
      "h": 17180000295,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180000295),
//--TRIMMABLE-BOUNDARY-START(4295098407),
    {
      "t": 187760641,
      "n": "_associatedMetadataType",
      "d": 131111,
      "h": 4295098407,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098407)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885032999),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 131111,
      "h": 12885032999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885032999),
//--TRIMMABLE-BOUNDARY-START(8590065703),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "associatedMetadataType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131111,
      "h": 8590065703,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065703)
  ],
  "h": 131111
}; }
            static get $b() { return $.$sct.System.ComponentModel.TypeDescriptionProvider; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptionProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131111)
        
        
        //--TRIMMABLE-BOUNDARY-START(524327)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ConcurrencyCheckAttribute", ($self) => class ConcurrencyCheckAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295491623)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491623)
            
            static $h = 524327;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491623),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524327,
      "h": 4295491623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491623)
  ],
  "h": 524327,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ConcurrencyCheckAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524327)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572903)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.KeyAttribute", ($self) => class KeyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296540199)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540199)
            
            static $h = 1572903;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540199),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572903,
      "h": 4296540199,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540199)
  ],
  "h": 1572903,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.KeyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572903)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179687)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EditableAttribute", ($self) => class EditableAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12886081575)
            $ctor$2(/*bool*/ allowEdit)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081575);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AllowEdit = allowEdit;
                    this.AllowInitialValue = allowEdit;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081575)
            
            //--TRIMMABLE-BOUNDARY-START(17181048871)
            /*bool*/ AllowEdit = false;
            //--TRIMMABLE-BOUNDARY-END(17181048871)
            
            //--TRIMMABLE-BOUNDARY-START(21476016167)
            /*bool*/ AllowInitialValue = false;
            //--TRIMMABLE-BOUNDARY-END(21476016167)
            
            static $h = 1179687;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181048871),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950759,
        "f": 50331649
      },
      "n": "AllowEdit",
      "d": 1179687,
      "h": 17181048871,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181048871),
//--TRIMMABLE-BOUNDARY-START(21476016167),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655885351,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47245819943,
        "f": 83886081
      },
      "n": "AllowInitialValue",
      "d": 1179687,
      "h": 21476016167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476016167)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081575),
    {
      "p": [
        {
          "n": "allowEdit",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179687,
      "h": 12886081575,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081575)
  ],
  "h": 1179687,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EditableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179687)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048615)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayColumnAttribute", ($self) => class DisplayColumnAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(25770852391)
            $ctor$4(/*string*/ displayColumn)
            {
                this.$ctor$3(displayColumn, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770852391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770852391)
            
            //--TRIMMABLE-BOUNDARY-START(21475885095)
            $ctor$3(/*string*/ displayColumn, /*string?*/ sortColumn)
            {
                this.$ctor$2(displayColumn, sortColumn, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475885095);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885095)
            
            //--TRIMMABLE-BOUNDARY-START(17180917799)
            $ctor$2(/*string*/ displayColumn, /*string?*/ sortColumn, /*bool*/ sortDescending)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180917799);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DisplayColumn = displayColumn;
                    this.SortColumn = sortColumn;
                    this.SortDescending = sortDescending;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180917799)
            
            //--TRIMMABLE-BOUNDARY-START(30065819687)
            /*string*/ DisplayColumn = null;
            //--TRIMMABLE-BOUNDARY-END(30065819687)
            
            //--TRIMMABLE-BOUNDARY-START(60130590759)
            /*string?*/ SortColumn = null;
            //--TRIMMABLE-BOUNDARY-END(60130590759)
            
            //--TRIMMABLE-BOUNDARY-START(64425558055)
            /*bool*/ SortDescending = false;
            //--TRIMMABLE-BOUNDARY-END(64425558055)
            
            static $h = 1048615;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065819687),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655754279,
        "f": 50331649
      },
      "n": "DisplayColumn",
      "d": 1048615,
      "h": 30065819687,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065819687),
//--TRIMMABLE-BOUNDARY-START(60130590759),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245688871,
        "f": 50331649
      },
      "n": "SortColumn",
      "d": 1048615,
      "h": 60130590759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130590759),
//--TRIMMABLE-BOUNDARY-START(64425558055),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835623463,
        "f": 50331649
      },
      "n": "SortDescending",
      "d": 1048615,
      "h": 64425558055,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425558055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770852391),
    {
      "p": [
        {
          "n": "displayColumn",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1048615,
      "h": 25770852391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770852391),
//--TRIMMABLE-BOUNDARY-START(21475885095),
    {
      "p": [
        {
          "n": "displayColumn",
          "p": 1310721
        },
        {
          "n": "sortColumn",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048615,
      "h": 21475885095,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475885095),
//--TRIMMABLE-BOUNDARY-START(17180917799),
    {
      "p": [
        {
          "n": "displayColumn",
          "p": 1310721
        },
        {
          "n": "sortColumn",
          "p": 1310721
        },
        {
          "n": "sortDescending",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1048615,
      "h": 17180917799,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180917799)
  ],
  "h": 1048615,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        },
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayColumnAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048615)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900583)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute", ($self) => class MetadataTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296867879)
            /*Type*/ _metadataClassType = null;
            //--TRIMMABLE-BOUNDARY-END(4296867879)
            
            //--TRIMMABLE-BOUNDARY-START(8591835175)
            $ctor$2(/*Type*/ metadataClassType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591835175);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._metadataClassType = metadataClassType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591835175)
            
            //--TRIMMABLE-BOUNDARY-START(21476737063)
            /*Type */ get MetadataClassType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181769767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(this._metadataClassType, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.MetadataTypeAttribute_TypeCannotBeNull);
                }
                return this._metadataClassType;
            }
            //--TRIMMABLE-BOUNDARY-END(21476737063)
            
            static $h = 1900583;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21476737063),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181769767,
        "f": 50331649
      },
      "n": "MetadataClassType",
      "d": 1900583,
      "h": 21476737063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476737063)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867879),
    {
      "t": 187760641,
      "n": "_metadataClassType",
      "d": 1900583,
      "h": 4296867879,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296867879)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591835175),
    {
      "p": [
        {
          "n": "metadataClassType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900583,
      "h": 8591835175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591835175)
  ],
  "h": 1900583,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MetadataTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900583)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441831)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute", ($self) => class FilterUIHintAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296409127)
            /*UIHintAttribute.UIHintImplementation*/ _implementation = null;
            //--TRIMMABLE-BOUNDARY-END(4296409127)
            
            //--TRIMMABLE-BOUNDARY-START(30066212903)
            /*string */ get FilterUIHint()
            {
                return this._implementation.UIHint;
            }
            //--TRIMMABLE-BOUNDARY-END(30066212903)
            
            //--TRIMMABLE-BOUNDARY-START(64425951271)
            /*string? */ get PresentationLayer()
            {
                return this._implementation.PresentationLayer;
            }
            //--TRIMMABLE-BOUNDARY-END(64425951271)
            
            //--TRIMMABLE-BOUNDARY-START(21476278311)
            /*IDictionary<string, object?> */ get ControlParameters()
            {
                return this._implementation.ControlParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(21476278311)
            
            //--TRIMMABLE-BOUNDARY-START(17181311015)
            $ctor$4(/*string*/ filterUIHint)
            {
                this.$ctor$2(filterUIHint, null, $.$$.System.Array.Empty($.$$.System.Object));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311015);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311015)
            
            //--TRIMMABLE-BOUNDARY-START(12886343719)
            $ctor$3(/*string*/ filterUIHint, /*string?*/ presentationLayer)
            {
                this.$ctor$2(filterUIHint, presentationLayer, $.$$.System.Array.Empty($.$$.System.Object));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343719);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343719)
            
            //--TRIMMABLE-BOUNDARY-START(8591376423)
            $ctor$2(/*string*/ filterUIHint, /*string?*/ presentationLayer, /*params object?[]*/ controlParameters)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376423);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._implementation = new $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation().$ctor$1(filterUIHint, presentationLayer, controlParameters);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376423)
            
            //--TRIMMABLE-BOUNDARY-START(60130983975)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130983975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.call(this._implementation);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(60130983975)
            
            //--TRIMMABLE-BOUNDARY-START(25771245607)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771245607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let otherAttribute;
                    return $.$is(obj, $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute, { set $v(v){ otherAttribute = v; } }) && $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals$1.call(this._implementation, otherAttribute._implementation);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771245607)
            
            static $h = 1441831;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30066212903),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082087,
        "f": 50331649
      },
      "n": "FilterUIHint",
      "d": 1441831,
      "h": 30066212903,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066212903),
//--TRIMMABLE-BOUNDARY-START(64425951271),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836016679,
        "f": 50331649
      },
      "n": "PresentationLayer",
      "d": 1441831,
      "h": 64425951271,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425951271),
//--TRIMMABLE-BOUNDARY-START(21476278311),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147495,
        "f": 50331649
      },
      "n": "ControlParameters",
      "d": 1441831,
      "h": 21476278311,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476278311)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60130983975),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1441831,
      "h": 60130983975,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130983975),
//--TRIMMABLE-BOUNDARY-START(25771245607),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1441831,
      "h": 25771245607,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771245607)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409127),
    {
      "t": 3080231,
      "n": "_implementation",
      "d": 1441831,
      "h": 4296409127,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409127)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181311015),
    {
      "p": [
        {
          "n": "filterUIHint",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441831,
      "h": 17181311015,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181311015),
//--TRIMMABLE-BOUNDARY-START(12886343719),
    {
      "p": [
        {
          "n": "filterUIHint",
          "p": 1310721
        },
        {
          "n": "presentationLayer",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441831,
      "h": 12886343719,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886343719),
//--TRIMMABLE-BOUNDARY-START(8591376423),
    {
      "p": [
        {
          "n": "filterUIHint",
          "p": 1310721
        },
        {
          "n": "presentationLayer",
          "p": 1310721
        },
        {
          "n": "controlParameters",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1441831,
      "h": 8591376423,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591376423)
  ],
  "h": 1441831,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 103743489,
      "c": 30168514561,
      "a": [
        {
          "v": "FilterUIHintAttribute has been deprecated and is not supported.",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.FilterUIHintAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441831)
        
        
        //--TRIMMABLE-BOUNDARY-START(2490407)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedAttribute", ($self) => class DatabaseGeneratedAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592424999)
            $ctor$2(/*DatabaseGeneratedOption*/ databaseGeneratedOption)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592424999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (!$.$$.System.Enum.IsDefined$1($.$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption, databaseGeneratedOption))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("databaseGeneratedOption");
                    }
                    this.DatabaseGeneratedOption = databaseGeneratedOption;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592424999)
            
            //--TRIMMABLE-BOUNDARY-START(12887392295)
            /*DatabaseGeneratedOption*/ DatabaseGeneratedOption = 0;
            //--TRIMMABLE-BOUNDARY-END(12887392295)
            
            static $h = 2490407;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887392295),
    {
      "p": 2555943,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477326887,
        "f": 50331649
      },
      "n": "DatabaseGeneratedOption",
      "d": 2490407,
      "h": 12887392295,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887392295)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592424999),
    {
      "p": [
        {
          "n": "databaseGeneratedOption",
          "p": 2555943
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2490407,
      "h": 8592424999,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592424999)
  ],
  "h": 2490407,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2490407)
        
        
        //--TRIMMABLE-BOUNDARY-START(2424871)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ComplexTypeAttribute", ($self) => class ComplexTypeAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297392167)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297392167)
            
            static $h = 2424871;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297392167),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2424871,
      "h": 4297392167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297392167)
  ],
  "h": 2424871,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ComplexTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2424871)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359335)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ColumnAttribute", ($self) => class ColumnAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297326631)
            /*int*/ _order = -1;
            //--TRIMMABLE-BOUNDARY-END(4297326631)
            
            //--TRIMMABLE-BOUNDARY-START(8592293927)
            /*string?*/ _typeName = null;
            //--TRIMMABLE-BOUNDARY-END(8592293927)
            
            //--TRIMMABLE-BOUNDARY-START(17182228519)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182228519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182228519)
            
            //--TRIMMABLE-BOUNDARY-START(21477195815)
            $ctor$3(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477195815);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477195815)
            
            //--TRIMMABLE-BOUNDARY-START(51541966887)
            /*string?*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(51541966887)
            
            //--TRIMMABLE-BOUNDARY-START(55836934183)
            /*int */ get Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38657064999);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._order;
            }
            /*int */ set Order(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426868775);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, value, "value");
                this._order = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55836934183)
            
            //--TRIMMABLE-BOUNDARY-START(77311770663)
            /*string? */ get TypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246999591);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._typeName;
            }
            /*string? */ set TypeName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016803367);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(value, "value");
                this._typeName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(77311770663)
            
            static $h = 2359335;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541966887),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067130407,
        "f": 50331649
      },
      "n": "Name",
      "d": 2359335,
      "h": 51541966887,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541966887),
//--TRIMMABLE-BOUNDARY-START(55836934183),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657064999,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64426868775,
        "f": 83886081
      },
      "n": "Order",
      "d": 2359335,
      "h": 55836934183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836934183),
//--TRIMMABLE-BOUNDARY-START(77311770663),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246999591,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016803367,
        "f": 83886081
      },
      "n": "TypeName",
      "d": 2359335,
      "h": 77311770663,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311770663)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297326631),
    {
      "t": 655361,
      "n": "_order",
      "d": 2359335,
      "h": 4297326631,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297326631),
//--TRIMMABLE-BOUNDARY-START(8592293927),
    {
      "t": 1310721,
      "n": "_typeName",
      "d": 2359335,
      "h": 8592293927,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8592293927)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182228519),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2359335,
      "h": 17182228519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182228519),
//--TRIMMABLE-BOUNDARY-START(21477195815),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2359335,
      "h": 21477195815,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477195815)
  ],
  "h": 2359335,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ColumnAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359335)
        
        
        //--TRIMMABLE-BOUNDARY-START(983079)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayAttribute", ($self) => class DisplayAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12885884967)
            /*LocalizableString*/ _description = null;
            //--TRIMMABLE-BOUNDARY-END(12885884967)
            
            //--TRIMMABLE-BOUNDARY-START(17180852263)
            /*LocalizableString*/ _groupName = null;
            //--TRIMMABLE-BOUNDARY-END(17180852263)
            
            //--TRIMMABLE-BOUNDARY-START(21475819559)
            /*LocalizableString*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(21475819559)
            
            //--TRIMMABLE-BOUNDARY-START(30065754151)
            /*LocalizableString*/ _prompt = null;
            //--TRIMMABLE-BOUNDARY-END(30065754151)
            
            //--TRIMMABLE-BOUNDARY-START(38655688743)
            /*LocalizableString*/ _shortName = null;
            //--TRIMMABLE-BOUNDARY-END(38655688743)
            
            //--TRIMMABLE-BOUNDARY-START(4295950375)
            /*bool?*/ _autoGenerateField = null;
            //--TRIMMABLE-BOUNDARY-END(4295950375)
            
            //--TRIMMABLE-BOUNDARY-START(8590917671)
            /*bool?*/ _autoGenerateFilter = null;
            //--TRIMMABLE-BOUNDARY-END(8590917671)
            
            //--TRIMMABLE-BOUNDARY-START(25770786855)
            /*int?*/ _order = null;
            //--TRIMMABLE-BOUNDARY-END(25770786855)
            
            //--TRIMMABLE-BOUNDARY-START(34360721447)
            /*Type?*/ _resourceType = null;
            //--TRIMMABLE-BOUNDARY-END(34360721447)
            
            //--TRIMMABLE-BOUNDARY-START(270583922727)
            /*string? */ get ShortName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._shortName.Value;
            }
            /*string? */ set ShortName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288955431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._shortName.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(270583922727)
            
            //--TRIMMABLE-BOUNDARY-START(176094642215)
            /*string? */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230887);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name.Value;
            }
            /*string? */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929217063);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(176094642215)
            
            //--TRIMMABLE-BOUNDARY-START(55835557927)
            /*string? */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361703);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._description.Value;
            }
            /*string? */ set Description(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749347879);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._description.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55835557927)
            
            //--TRIMMABLE-BOUNDARY-START(184684576807)
            /*string? */ get Prompt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100071);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._prompt.Value;
            }
            /*string? */ set Prompt(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109086247);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._prompt.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(184684576807)
            
            //--TRIMMABLE-BOUNDARY-START(171799674919)
            /*string? */ get GroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296295);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._groupName.Value;
            }
            /*string? */ set GroupName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339282471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._groupName.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171799674919)
            
            //--TRIMMABLE-BOUNDARY-START(188979544103)
            /*Type? */ get ResourceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._resourceType;
            }
            /*Type? */ set ResourceType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699020839);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Inequality$1(this._resourceType, value))
                {
                    this._resourceType = value;
                    this._shortName.ResourceType = value;
                    this._name.ResourceType = value;
                    this._description.ResourceType = value;
                    this._prompt.ResourceType = value;
                    this._groupName.ResourceType = value;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979544103)
            
            //--TRIMMABLE-BOUNDARY-START(47245623335)
            /*bool */ get AutoGenerateField()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492519);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(this._autoGenerateField))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "AutoGenerateField", "GetAutoGenerateField"));
                }
                return $.$$.System.Nullable$$($.$$.System.Boolean).GetValueOrDefault.call(this._autoGenerateField);
            }
            /*bool */ set AutoGenerateField(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569478695);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._autoGenerateField = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623335)
            
            //--TRIMMABLE-BOUNDARY-START(51540590631)
            /*bool */ get AutoGenerateFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427111);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(this._autoGenerateFilter))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "AutoGenerateFilter", "GetAutoGenerateFilter"));
                }
                return $.$$.System.Nullable$$($.$$.System.Boolean).GetValueOrDefault.call(this._autoGenerateFilter);
            }
            /*bool */ set AutoGenerateFilter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159413287);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._autoGenerateFilter = value;
            }
            //--TRIMMABLE-BOUNDARY-END(51540590631)
            
            //--TRIMMABLE-BOUNDARY-START(180389609511)
            /*int */ get Order()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165479);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.Nullable$$($.$$.System.Int32).HasValue$get.call(this._order))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "Order", "GetOrder"));
                }
                return $.$$.System.Nullable$$($.$$.System.Int32).GetValueOrDefault.call(this._order);
            }
            /*int */ set Order(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519151655);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._order = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180389609511)
            
            //--TRIMMABLE-BOUNDARY-START(167504707623)
            /*string? */ GetShortName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504707623);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._shortName.GetLocalizableValue() ?? this.GetName();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504707623)
            
            //--TRIMMABLE-BOUNDARY-START(154619805735)
            /*string? */ GetName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619805735);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._name.GetLocalizableValue();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619805735)
            
            //--TRIMMABLE-BOUNDARY-START(146029871143)
            /*string? */ GetDescription()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029871143);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._description.GetLocalizableValue();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029871143)
            
            //--TRIMMABLE-BOUNDARY-START(163209740327)
            /*string? */ GetPrompt()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209740327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._prompt.GetLocalizableValue();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209740327)
            
            //--TRIMMABLE-BOUNDARY-START(150324838439)
            /*string? */ GetGroupName()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324838439);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._groupName.GetLocalizableValue();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324838439)
            
            //--TRIMMABLE-BOUNDARY-START(137439936551)
            /*bool? */ GetAutoGenerateField()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439936551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._autoGenerateField;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439936551)
            
            //--TRIMMABLE-BOUNDARY-START(141734903847)
            /*bool? */ GetAutoGenerateFilter()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734903847);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._autoGenerateFilter;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734903847)
            
            //--TRIMMABLE-BOUNDARY-START(158914773031)
            /*int? */ GetOrder()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914773031);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._order;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914773031)
            
            //--TRIMMABLE-BOUNDARY-START(42950656039)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656039)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885884967)
                this._description = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Description");
                //--TRIMMABLE-BOUNDARY-END(12885884967)
                
                //--TRIMMABLE-BOUNDARY-START(17180852263)
                this._groupName = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("GroupName");
                //--TRIMMABLE-BOUNDARY-END(17180852263)
                
                //--TRIMMABLE-BOUNDARY-START(21475819559)
                this._name = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Name");
                //--TRIMMABLE-BOUNDARY-END(21475819559)
                
                //--TRIMMABLE-BOUNDARY-START(30065754151)
                this._prompt = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Prompt");
                //--TRIMMABLE-BOUNDARY-END(30065754151)
                
                //--TRIMMABLE-BOUNDARY-START(38655688743)
                this._shortName = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("ShortName");
                //--TRIMMABLE-BOUNDARY-END(38655688743)
                
            }
            static $h = 983079;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(270583922727),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144969255,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288955431,
        "f": 83886081
      },
      "n": "ShortName",
      "d": 983079,
      "h": 270583922727,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583922727),
//--TRIMMABLE-BOUNDARY-START(176094642215),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785230887,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929217063,
        "f": 83886081
      },
      "n": "Name",
      "d": 983079,
      "h": 176094642215,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094642215),
//--TRIMMABLE-BOUNDARY-START(55835557927),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361703,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749347879,
        "f": 83886081
      },
      "n": "Description",
      "d": 983079,
      "h": 55835557927,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835557927),
//--TRIMMABLE-BOUNDARY-START(184684576807),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965100071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109086247,
        "f": 83886081
      },
      "n": "Prompt",
      "d": 983079,
      "h": 184684576807,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684576807),
//--TRIMMABLE-BOUNDARY-START(171799674919),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195296295,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339282471,
        "f": 83886081
      },
      "n": "GroupName",
      "d": 983079,
      "h": 171799674919,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799674919),
//--TRIMMABLE-BOUNDARY-START(188979544103),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555034663,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699020839,
        "f": 83886081
      },
      "n": "ResourceType",
      "d": 983079,
      "h": 188979544103,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979544103),
//--TRIMMABLE-BOUNDARY-START(47245623335),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425492519,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197569478695,
        "f": 83886081
      },
      "n": "AutoGenerateField",
      "d": 983079,
      "h": 47245623335,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245623335),
//--TRIMMABLE-BOUNDARY-START(51540590631),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015427111,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159413287,
        "f": 83886081
      },
      "n": "AutoGenerateFilter",
      "d": 983079,
      "h": 51540590631,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540590631),
//--TRIMMABLE-BOUNDARY-START(180389609511),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375165479,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519151655,
        "f": 83886081
      },
      "n": "Order",
      "d": 983079,
      "h": 180389609511,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389609511)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504707623),
    {
      "r": 1310721,
      "n": "GetShortName",
      "d": 983079,
      "h": 167504707623,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504707623),
//--TRIMMABLE-BOUNDARY-START(154619805735),
    {
      "r": 1310721,
      "n": "GetName",
      "d": 983079,
      "h": 154619805735,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619805735),
//--TRIMMABLE-BOUNDARY-START(146029871143),
    {
      "r": 1310721,
      "n": "GetDescription",
      "d": 983079,
      "h": 146029871143,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029871143),
//--TRIMMABLE-BOUNDARY-START(163209740327),
    {
      "r": 1310721,
      "n": "GetPrompt",
      "d": 983079,
      "h": 163209740327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209740327),
//--TRIMMABLE-BOUNDARY-START(150324838439),
    {
      "r": 1310721,
      "n": "GetGroupName",
      "d": 983079,
      "h": 150324838439,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(150324838439),
//--TRIMMABLE-BOUNDARY-START(137439936551),
    {
      "r": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "GetAutoGenerateField",
      "d": 983079,
      "h": 137439936551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439936551),
//--TRIMMABLE-BOUNDARY-START(141734903847),
    {
      "r": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "GetAutoGenerateFilter",
      "d": 983079,
      "h": 141734903847,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734903847),
//--TRIMMABLE-BOUNDARY-START(158914773031),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "n": "GetOrder",
      "d": 983079,
      "h": 158914773031,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914773031)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884967),
    {
      "t": 1703975,
      "n": "_description",
      "d": 983079,
      "h": 12885884967,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885884967),
//--TRIMMABLE-BOUNDARY-START(17180852263),
    {
      "t": 1703975,
      "n": "_groupName",
      "d": 983079,
      "h": 17180852263,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180852263),
//--TRIMMABLE-BOUNDARY-START(21475819559),
    {
      "t": 1703975,
      "n": "_name",
      "d": 983079,
      "h": 21475819559,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475819559),
//--TRIMMABLE-BOUNDARY-START(30065754151),
    {
      "t": 1703975,
      "n": "_prompt",
      "d": 983079,
      "h": 30065754151,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065754151),
//--TRIMMABLE-BOUNDARY-START(38655688743),
    {
      "t": 1703975,
      "n": "_shortName",
      "d": 983079,
      "h": 38655688743,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655688743),
//--TRIMMABLE-BOUNDARY-START(4295950375),
    {
      "t": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "_autoGenerateField",
      "d": 983079,
      "h": 4295950375,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950375),
//--TRIMMABLE-BOUNDARY-START(8590917671),
    {
      "t": $.$typeNullable($.$$.System.Boolean).$h,
      "n": "_autoGenerateFilter",
      "d": 983079,
      "h": 8590917671,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590917671),
//--TRIMMABLE-BOUNDARY-START(25770786855),
    {
      "t": $.$typeNullable($.$$.System.Int32).$h,
      "n": "_order",
      "d": 983079,
      "h": 25770786855,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770786855),
//--TRIMMABLE-BOUNDARY-START(34360721447),
    {
      "t": 187760641,
      "n": "_resourceType",
      "d": 983079,
      "h": 34360721447,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360721447)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950656039),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983079,
      "h": 42950656039,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950656039)
  ],
  "h": 983079,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2500,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983079)
        
        
        //--TRIMMABLE-BOUNDARY-START(2621479)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ForeignKeyAttribute", ($self) => class ForeignKeyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592556071)
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592556071);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592556071)
            
            //--TRIMMABLE-BOUNDARY-START(21477457959)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(21477457959)
            
            static $h = 2621479;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477457959),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182490663,
        "f": 50331649
      },
      "n": "Name",
      "d": 2621479,
      "h": 21477457959,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477457959)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592556071),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2621479,
      "h": 8592556071,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592556071)
  ],
  "h": 2621479,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ForeignKeyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2621479)
        
        
        //--TRIMMABLE-BOUNDARY-START(2752551)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute", ($self) => class NotMappedAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297719847)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297719847)
            
            static $h = 2752551;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297719847),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2752551,
      "h": 4297719847,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297719847)
  ],
  "h": 2752551,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 388,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2752551)
        
        
        //--TRIMMABLE-BOUNDARY-START(2687015)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.InversePropertyAttribute", ($self) => class InversePropertyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592621607)
            $ctor$2(/*string*/ property)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592621607);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(property, "property");
                    this.Property = property;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592621607)
            
            //--TRIMMABLE-BOUNDARY-START(21477523495)
            /*string*/ Property = null;
            //--TRIMMABLE-BOUNDARY-END(21477523495)
            
            static $h = 2687015;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477523495),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182556199,
        "f": 50331649
      },
      "n": "Property",
      "d": 2687015,
      "h": 21477523495,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477523495)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592621607),
    {
      "p": [
        {
          "n": "property",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2687015,
      "h": 8592621607,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592621607)
  ],
  "h": 2687015,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.InversePropertyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2687015)
        
        
        //--TRIMMABLE-BOUNDARY-START(2818087)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.TableAttribute", ($self) => class TableAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297785383)
            /*string?*/ _schema = null;
            //--TRIMMABLE-BOUNDARY-END(4297785383)
            
            //--TRIMMABLE-BOUNDARY-START(12887719975)
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887719975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887719975)
            
            //--TRIMMABLE-BOUNDARY-START(34362556455)
            /*string*/ Name = null;
            //--TRIMMABLE-BOUNDARY-END(34362556455)
            
            //--TRIMMABLE-BOUNDARY-START(38657523751)
            /*string? */ get Schema()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30067589159);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._schema;
            }
            /*string? */ set Schema(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47247458343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentException.ThrowIfNullOrWhiteSpace(value, "value");
                this._schema = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38657523751)
            
            static $h = 2818087;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34362556455),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477654567,
        "f": 50331649
      },
      "n": "Name",
      "d": 2818087,
      "h": 34362556455,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34362556455),
//--TRIMMABLE-BOUNDARY-START(38657523751),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067589159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 47247458343,
        "f": 83886081
      },
      "n": "Schema",
      "d": 2818087,
      "h": 38657523751,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38657523751)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297785383),
    {
      "t": 1310721,
      "n": "_schema",
      "d": 2818087,
      "h": 4297785383,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297785383)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887719975),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2818087,
      "h": 12887719975,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887719975)
  ],
  "h": 2818087,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.TableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2818087)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293799)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ScaffoldColumnAttribute", ($self) => class ScaffoldColumnAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592228391)
            $ctor$2(/*bool*/ scaffold)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592228391);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Scaffold = scaffold;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592228391)
            
            //--TRIMMABLE-BOUNDARY-START(21477130279)
            /*bool*/ Scaffold = false;
            //--TRIMMABLE-BOUNDARY-END(21477130279)
            
            static $h = 2293799;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21477130279),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17182162983,
        "f": 50331649
      },
      "n": "Scaffold",
      "d": 2293799,
      "h": 21477130279,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21477130279)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592228391),
    {
      "p": [
        {
          "n": "scaffold",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293799,
      "h": 8592228391,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592228391)
  ],
  "h": 2293799,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ScaffoldColumnAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293799)
        
        
        //--TRIMMABLE-BOUNDARY-START(3014695)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.UIHintAttribute", ($self) => class UIHintAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297981991)
            /*UIHintImplementation*/ _implementation = null;
            //--TRIMMABLE-BOUNDARY-END(4297981991)
            
            //--TRIMMABLE-BOUNDARY-START(21477851175)
            $ctor$4(/*string*/ uiHint)
            {
                this.$ctor$2(uiHint, null, $.$$.System.Array.Empty($.$$.System.Object));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21477851175);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21477851175)
            
            //--TRIMMABLE-BOUNDARY-START(17182883879)
            $ctor$3(/*string*/ uiHint, /*string?*/ presentationLayer)
            {
                this.$ctor$2(uiHint, presentationLayer, $.$$.System.Array.Empty($.$$.System.Object));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182883879);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182883879)
            
            //--TRIMMABLE-BOUNDARY-START(12887916583)
            $ctor$2(/*string*/ uiHint, /*string?*/ presentationLayer, /*params object?[]?*/ controlParameters)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887916583);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._implementation = new $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation().$ctor$1(uiHint, presentationLayer, controlParameters);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887916583)
            
            //--TRIMMABLE-BOUNDARY-START(68722491431)
            /*string */ get UIHint()
            {
                return this._implementation.UIHint;
            }
            //--TRIMMABLE-BOUNDARY-END(68722491431)
            
            //--TRIMMABLE-BOUNDARY-START(64427524135)
            /*string? */ get PresentationLayer()
            {
                return this._implementation.PresentationLayer;
            }
            //--TRIMMABLE-BOUNDARY-END(64427524135)
            
            //--TRIMMABLE-BOUNDARY-START(25772818471)
            /*IDictionary<string, object?> */ get ControlParameters()
            {
                return this._implementation.ControlParameters;
            }
            //--TRIMMABLE-BOUNDARY-END(25772818471)
            
            //--TRIMMABLE-BOUNDARY-START(60132556839)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60132556839);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.call(this._implementation);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(60132556839)
            
            //--TRIMMABLE-BOUNDARY-START(30067785767)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30067785767);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let otherAttribute;
                    return $.$is(obj, $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute, { set $v(v){ otherAttribute = v; } }) && $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals$1.call(this._implementation, otherAttribute._implementation);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(30067785767)
            
            //--TRIMMABLE-BOUNDARY-START(3080231)
            static $_UIHintImplementation;
            static get UIHintImplementation()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute;
                return $cls.$_UIHintImplementation ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation", ($self) => class UIHintImplementation extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(8593014823)
                    /*object?[]?*/ _inputControlParameters = null;
                    //--TRIMMABLE-BOUNDARY-END(8593014823)
                    
                    //--TRIMMABLE-BOUNDARY-START(4298047527)
                    /*IDictionary<string, object?>?*/ _controlParameters = null;
                    //--TRIMMABLE-BOUNDARY-END(4298047527)
                    
                    //--TRIMMABLE-BOUNDARY-START(21477916711)
                    $ctor$1(/*string*/ uiHint, /*string?*/ presentationLayer, /*params object?[]?*/ controlParameters)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21477916711);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.UIHint = uiHint;
                            this.PresentationLayer = presentationLayer;
                            if (controlParameters !== null)
                            {
                                this._inputControlParameters = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), null, [controlParameters.length], null);
                                $.$$.System.Array.Copy(controlParameters, this._inputControlParameters, controlParameters.length);
                            }
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21477916711)
                    
                    //--TRIMMABLE-BOUNDARY-START(73017524263)
                    /*string*/ UIHint = null;
                    //--TRIMMABLE-BOUNDARY-END(73017524263)
                    
                    //--TRIMMABLE-BOUNDARY-START(68722556967)
                    /*string?*/ PresentationLayer = null;
                    //--TRIMMABLE-BOUNDARY-END(68722556967)
                    
                    //--TRIMMABLE-BOUNDARY-START(30067851303)
                    /*IDictionary<string, object?> */ get ControlParameters()
                    {
                        return this._controlParameters ??= this.BuildControlParametersDictionary();
                    }
                    //--TRIMMABLE-BOUNDARY-END(30067851303)
                    
                    //--TRIMMABLE-BOUNDARY-START(64427589671)
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64427589671);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let a = this.UIHint ?? $.$$.System.String.Empty;
                        /*var*/ let b = this.PresentationLayer ?? $.$$.System.String.Empty;
                        return $.$$.System.String.GetHashCode.call(a) ^ $.$$.System.String.GetHashCode.call(b);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(64427589671)
                    
                    //--TRIMMABLE-BOUNDARY-START(34362818599)
                    static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34362818599);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let otherImplementation = $.$as(obj, $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation);
                        if (otherImplementation === null || $.$$.System.String.op_Inequality(this.UIHint, otherImplementation.UIHint) || $.$$.System.String.op_Inequality(this.PresentationLayer, otherImplementation.PresentationLayer))
                        {
                            return false;
                        }
                        /*IDictionary<string, object?>*/ let leftParams;
                        /*IDictionary<string, object?>*/ let rightParams;
                        try
                        {
                            leftParams = this.ControlParameters;
                            rightParams = otherImplementation.ControlParameters;
                        }
                        catch($e)
                        {
                            return false;
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(leftParams !== null, "leftParams shouldn't be null");
                        $.$$.System.Diagnostics.Debug.Assert$2(rightParams !== null, "rightParams shouldn't be null");
                        if (leftParams.System$Collections$Generic$ICollection$$$Count !== rightParams.System$Collections$Generic$ICollection$$$Count)
                        {
                            return false;
                        }
                        return $.$sl.System.Linq.Enumerable.SequenceEqual$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$sl.System.Linq.Enumerable.OrderBy$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String, leftParams, new ($.$$.System.Func$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Key;
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "p",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 3080231,
  "h": 0,
  "f": 17825794
})), $.$sl.System.Linq.Enumerable.OrderBy$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String, rightParams, new ($.$$.System.Func$$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), $.$$.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Key;
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "p",
      "p": $.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object).$h
    }
  ],
  "n": "",
  "d": 3080231,
  "h": 0,
  "f": 17825794
})));
                    }
                    //Static convention instance redirect
                    /*bool */ Equals$1() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals$1.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(34362818599)
                    
                    //--TRIMMABLE-BOUNDARY-START(25772884007)
                    /*Dictionary<string, object?> */ BuildControlParametersDictionary()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25772884007);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*var*/ let controlParameters = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                        /*object?[]?*/ let inputControlParameters = this._inputControlParameters;
                        if (inputControlParameters === null || inputControlParameters.length === 0)
                        {
                            return controlParameters;
                        }
                        if (inputControlParameters.length % 2 !== 0)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.UIHintImplementation_NeedEvenNumberOfControlParameters);
                        }
                        for(/*int*/ let i = 0; i < inputControlParameters.length; i += 2)
                        {
                            /*object?*/ let key = $.$$.System.Array.$ReadT1.call(inputControlParameters, i);
                            /*object?*/ let value = $.$$.System.Array.$ReadT1.call(inputControlParameters, ((i + 1) | 0));
                            if (key === null)
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$6($.$sca.System.SR.UIHintImplementation_ControlParameterKeyIsNull, $.$box(i, $.$$.System.Int32)));
                            }
                            let keyString;
                            if (!($.$is(key, $.$$.System.String, { set $v(v){ keyString = v; } })))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.UIHintImplementation_ControlParameterKeyIsNotAString, $.$box(i, $.$$.System.Int32), $.$$.System.Object.ToString.call($.$$.System.Array.$ReadT1.call(inputControlParameters, i))));
                            }
                            if (controlParameters.ContainsKey(keyString))
                            {
                                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.UIHintImplementation_ControlParameterKeyOccursMoreThanOnce, $.$box(i, $.$$.System.Int32), keyString));
                            }
                            controlParameters.set_Item(keyString, value);
                        }
                        return controlParameters;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25772884007)
                    
                    static $h = 3080231;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(73017524263),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60132622375,
        "f": 50331649
      },
      "n": "UIHint",
      "d": 3080231,
      "h": 73017524263,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73017524263),
//--TRIMMABLE-BOUNDARY-START(68722556967),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51542687783,
        "f": 50331649
      },
      "n": "PresentationLayer",
      "d": 3080231,
      "h": 68722556967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722556967),
//--TRIMMABLE-BOUNDARY-START(30067851303),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952753191,
        "f": 50331649
      },
      "n": "ControlParameters",
      "d": 3080231,
      "h": 30067851303,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30067851303)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(64427589671),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 3080231,
      "h": 64427589671,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64427589671),
//--TRIMMABLE-BOUNDARY-START(34362818599),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 3080231,
      "h": 34362818599,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34362818599),
//--TRIMMABLE-BOUNDARY-START(25772884007),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "BuildControlParametersDictionary",
      "d": 3080231,
      "h": 25772884007,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25772884007)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8593014823),
    {
      "t": $.$typeArray($.$$.System.Object).$h,
      "n": "_inputControlParameters",
      "d": 3080231,
      "h": 8593014823,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8593014823),
//--TRIMMABLE-BOUNDARY-START(4298047527),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "n": "_controlParameters",
      "d": 3080231,
      "h": 4298047527,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4298047527)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477916711),
    {
      "p": [
        {
          "n": "uiHint",
          "p": 1310721
        },
        {
          "n": "presentationLayer",
          "p": 1310721
        },
        {
          "n": "controlParameters",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 3080231,
      "h": 21477916711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477916711)
  ],
  "d": 3014695,
  "h": 3080231
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation`; }
                }, $cls, ($v) => $cls.$_UIHintImplementation = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(3080231)
            
            static $h = 3014695;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68722491431),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55837589543,
        "f": 50331649
      },
      "n": "UIHint",
      "d": 3014695,
      "h": 68722491431,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68722491431),
//--TRIMMABLE-BOUNDARY-START(64427524135),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47247654951,
        "f": 50331649
      },
      "n": "PresentationLayer",
      "d": 3014695,
      "h": 64427524135,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64427524135),
//--TRIMMABLE-BOUNDARY-START(25772818471),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657720359,
        "f": 50331649
      },
      "n": "ControlParameters",
      "d": 3014695,
      "h": 25772818471,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25772818471)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60132556839),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 3014695,
      "h": 60132556839,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60132556839),
//--TRIMMABLE-BOUNDARY-START(30067785767),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 3014695,
      "h": 30067785767,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30067785767)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4297981991),
    {
      "t": 3080231,
      "n": "_implementation",
      "d": 3014695,
      "h": 4297981991,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4297981991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21477851175),
    {
      "p": [
        {
          "n": "uiHint",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 3014695,
      "h": 21477851175,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21477851175),
//--TRIMMABLE-BOUNDARY-START(17182883879),
    {
      "p": [
        {
          "n": "uiHint",
          "p": 1310721
        },
        {
          "n": "presentationLayer",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 3014695,
      "h": 17182883879,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182883879),
//--TRIMMABLE-BOUNDARY-START(12887916583),
    {
      "p": [
        {
          "n": "uiHint",
          "p": 1310721
        },
        {
          "n": "presentationLayer",
          "p": 1310721
        },
        {
          "n": "controlParameters",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 3014695,
      "h": 12887916583,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887916583)
  ],
  "j": [3080231
  ],
  "h": 3014695,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.UIHintAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3014695)
        
        
        //--TRIMMABLE-BOUNDARY-START(2949159)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.TimestampAttribute", ($self) => class TimestampAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4297916455)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297916455)
            
            static $h = 2949159;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297916455),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2949159,
      "h": 4297916455,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297916455)
  ],
  "h": 2949159,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 384,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.TimestampAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2949159)
        
        
        //--TRIMMABLE-BOUNDARY-START(196647)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor", ($self) => class AssociatedMetadataTypeTypeDescriptor extends $.$sct.System.ComponentModel.CustomTypeDescriptor
        {
            //--TRIMMABLE-BOUNDARY-START(21475033127)
            /*Type?*/ AssociatedMetadataType = null;
            //--TRIMMABLE-BOUNDARY-END(21475033127)
            
            //--TRIMMABLE-BOUNDARY-START(60129738791)
            /*bool*/ IsSelfAssociated = false;
            //--TRIMMABLE-BOUNDARY-END(60129738791)
            
            //--TRIMMABLE-BOUNDARY-START(17180065831)
            $ctor$3(/*ICustomTypeDescriptor?*/ parent, /*Type*/ type, /*Type?*/ associatedMetadataType)
            {
                super.$ctor$2(parent);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AssociatedMetadataType = associatedMetadataType ?? $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.GetAssociatedMetadataType(type);
                    this.IsSelfAssociated = ($.$$.System.Type.op_Equality$1(type, this.AssociatedMetadataType));
                    if ($.$$.System.Type.op_Inequality$1(this.AssociatedMetadataType, null))
                    {
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.ValidateMetadataType(type, this.AssociatedMetadataType);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065831)
            
            //--TRIMMABLE-BOUNDARY-START(51539804199)
            /*PropertyDescriptorCollection */ GetProperties$1(/*Attribute[]?*/ attributes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804199);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPropertiesWithMetadata(super.GetProperties$1(attributes));
            }
            //--TRIMMABLE-BOUNDARY-END(51539804199)
            
            //--TRIMMABLE-BOUNDARY-START(47244836903)
            /*PropertyDescriptorCollection */ GetProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836903);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetPropertiesWithMetadata(super.GetProperties());
            }
            //--TRIMMABLE-BOUNDARY-END(47244836903)
            
            //--TRIMMABLE-BOUNDARY-START(55834771495)
            /*PropertyDescriptorCollection */ GetPropertiesWithMetadata(/*PropertyDescriptorCollection*/ originalCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771495);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(this.AssociatedMetadataType, null))
                {
                    return originalCollection;
                }
                /*bool*/ let customDescriptorsCreated = false;
                /*List<PropertyDescriptor>*/ let tempPropertyDescriptors = new ($.$$.System.Collections.Generic.List$$($.$sct.System.ComponentModel.PropertyDescriptor))().$ctor$1();
                var $en2 = originalCollection.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var propDescriptor = $en2.System$Collections$IEnumerator$Current;
                    {
                        /*Attribute[]*/ let newMetadata = $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.GetAssociatedMetadata(this.AssociatedMetadataType, propDescriptor.Name);
                        /*PropertyDescriptor*/ let descriptor = propDescriptor;
                        if (newMetadata.length > 0)
                        {
                            descriptor = new $.$sca.System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper().$ctor$8(propDescriptor, newMetadata);
                            customDescriptorsCreated = true;
                        }
                        tempPropertyDescriptors.Add(descriptor);
                    }
                }
                if (customDescriptorsCreated)
                {
                    return new $.$sct.System.ComponentModel.PropertyDescriptorCollection().$ctor$1(tempPropertyDescriptors.ToArray(), true);
                }
                return originalCollection;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771495)
            
            //--TRIMMABLE-BOUNDARY-START(42949869607)
            /*AttributeCollection */ GetAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869607);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*AttributeCollection*/ let attributes = super.GetAttributes();
                if ($.$$.System.Type.op_Inequality$1(this.AssociatedMetadataType, null) && !this.IsSelfAssociated)
                {
                    /*Attribute[]*/ let newAttributes = $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Attribute, $.$sl.System.Linq.Enumerable.OfType($.$$.System.Attribute, $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes$2(this.AssociatedMetadataType)));
                    attributes = $.$sct.System.ComponentModel.AttributeCollection.FromExisting(attributes, newAttributes);
                }
                return attributes;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869607)
            
            //--TRIMMABLE-BOUNDARY-START(262183)
            static $_TypeDescriptorCache;
            static get TypeDescriptorCache()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor;
                return $cls.$_TypeDescriptorCache ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache", ($self) => class TypeDescriptorCache
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098663)
                    /*ConcurrentDictionary<Type, Type?>*/ static s_metadataTypeCache = null;
                    //--TRIMMABLE-BOUNDARY-END(21475098663)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770065959)
                    /*ConcurrentDictionary<(Type, string), Attribute[]>*/ static s_typeMemberCache = null;
                    //--TRIMMABLE-BOUNDARY-END(25770065959)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033255)
                    /*ConcurrentDictionary<(Type, Type), bool>*/ static s_validatedMetadataTypeCache = null;
                    //--TRIMMABLE-BOUNDARY-END(30065033255)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360000551)
                    static /*void */ ValidateMetadataType(/*Type*/ type, /*Type*/ associatedType)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360000551);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*(Type, Type)*/ let typeTuple = new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Type))().$ctor$3(type, associatedType);
                        if (!$.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_validatedMetadataTypeCache.ContainsKey(typeTuple.Clone()))
                        {
                            $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.CheckAssociatedMetadataType(type, associatedType);
                            $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_validatedMetadataTypeCache.TryAdd(typeTuple.Clone(), true);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360000551)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131367)
                    static /*Type? */ GetAssociatedMetadataType(/*Type*/ type)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180131367);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*Type?*/ let associatedMetadataType;
                        if (TryGetAssociatedMetadataTypeFromCache(type, $.$ref(() => associatedMetadataType, ($v) => associatedMetadataType = $v, $.$$.System.Type)))
                        {
                            return associatedMetadataType;
                        }
                        /*MetadataTypeAttribute?*/ let attribute = $.$cast($.$$.System.Attribute.GetCustomAttribute$3(type, $.$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute.$type), $.$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute);
                        if (attribute !== null)
                        {
                            associatedMetadataType = attribute.MetadataClassType;
                        }
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_metadataTypeCache.TryAdd(type, associatedMetadataType);
                        return associatedMetadataType;
                        /*static bool*/  function TryGetAssociatedMetadataTypeFromCache(/*Type*/ type, /*out Type?*/ associatedMetadataType)
                        {
                            return $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_metadataTypeCache.TryGetValue(type, associatedMetadataType);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180131367)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196775)
                    static /*void */ CheckAssociatedMetadataType(/*Type*/ mainType, /*Type*/ associatedMetadataType)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590196775);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*HashSet<string>*/ let mainTypeMemberNames = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$3($.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.PropertyInfo, $.$$.System.String, mainType.GetProperties(), new ($.$$.System.Func$$$($.$$.System.Reflection.PropertyInfo, $.$$.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Name;
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "p",
      "p": 118882305
    }
  ],
  "n": "",
  "d": 262183,
  "h": 0,
  "f": 17825794
})));
                        /*var*/ let buddyFields = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.FieldInfo, $.$$.System.String, associatedMetadataType.GetFields(), new ($.$$.System.Func$$$($.$$.System.Reflection.FieldInfo, $.$$.System.String))().$ctor(this,  (/*f*/ f) =>
                        {
                            return f.Name;
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "f",
      "p": 113901569
    }
  ],
  "n": "",
  "d": 262183,
  "h": 0,
  "f": 17825794
}));
                        /*var*/ let buddyProperties = $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.PropertyInfo, $.$$.System.String, associatedMetadataType.GetProperties(), new ($.$$.System.Func$$$($.$$.System.Reflection.PropertyInfo, $.$$.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Name;
                        }, {
  "r": 1310721,
  "p": [
    {
      "n": "p",
      "p": 118882305
    }
  ],
  "n": "",
  "d": 262183,
  "h": 0,
  "f": 17825794
}));
                        /*HashSet<string>*/ let buddyTypeMembers = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$2($.$sl.System.Linq.Enumerable.Concat($.$$.System.String, buddyFields, buddyProperties), $.$$.System.StringComparer.Ordinal);
                        if (!buddyTypeMembers.IsSubsetOf(mainTypeMemberNames))
                        {
                            buddyTypeMembers.ExceptWith(mainTypeMemberNames);
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.AssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties, mainType.FullName, $.$$.System.String.Join$10(", ", $.$sl.System.Linq.Enumerable.ToArray($.$$.System.String, buddyTypeMembers))));
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590196775)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164071)
                    static /*Attribute[] */ GetAssociatedMetadata(/*Type*/ type, /*string*/ memberName)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885164071);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*(Type, string)*/ let memberTuple = new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String))().$ctor$3(type, memberName);
                        /*Attribute[]?*/ let attributes;
                        if ($.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_typeMemberCache.TryGetValue(memberTuple.Clone(), $.$ref(() => attributes, ($v) => attributes = $v, $.$typeArray($.$$.System.Attribute))))
                        {
                            return attributes;
                        }
                        /*MemberTypes*/ let allowedMemberTypes = 16/*MemberTypes.Property*/ | 4/*MemberTypes.Field*/;
                        /*BindingFlags*/ let searchFlags = 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/;
                        /*MemberInfo?*/ let matchingMember = $.$sl.System.Linq.Enumerable.FirstOrDefault$3($.$$.System.Reflection.MemberInfo, type.GetMember$1(memberName, allowedMemberTypes, searchFlags));
                        if ($.$$.System.Reflection.MemberInfo.op_Inequality(matchingMember, null))
                        {
                            attributes = $.$$.System.Attribute.GetCustomAttributes$4(matchingMember, true);
                        }
                        else 
                        {
                            attributes = $.$$.System.Array.Empty($.$$.System.Attribute);
                        }
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_typeMemberCache.TryAdd(memberTuple.Clone(), attributes);
                        return attributes;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885164071)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229479)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(21475098663)
                            this.s_metadataTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Type))().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(21475098663)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25770065959)
                            this.s_typeMemberCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$typeArray($.$$.System.Attribute)))().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(25770065959)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065033255)
                            this.s_validatedMetadataTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Type), $.$$.System.Boolean))().$ctor$1();
                            //--TRIMMABLE-BOUNDARY-END(30065033255)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295229479)
                    
                    static $h = 262183;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360000551),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "associatedType",
          "p": 187760641
        }
      ],
      "n": "ValidateMetadataType",
      "d": 262183,
      "h": 34360000551,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360000551),
//--TRIMMABLE-BOUNDARY-START(17180131367),
    {
      "r": 187760641,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetAssociatedMetadataType",
      "d": 262183,
      "h": 17180131367,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180131367),
//--TRIMMABLE-BOUNDARY-START(8590196775),
    {
      "r": 65537,
      "p": [
        {
          "n": "mainType",
          "p": 187760641
        },
        {
          "n": "associatedMetadataType",
          "p": 187760641
        }
      ],
      "n": "CheckAssociatedMetadataType",
      "d": 262183,
      "h": 8590196775,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590196775),
//--TRIMMABLE-BOUNDARY-START(12885164071),
    {
      "r": $.$typeArray($.$$.System.Attribute).$h,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "memberName",
          "p": 1310721
        }
      ],
      "n": "GetAssociatedMetadata",
      "d": 262183,
      "h": 12885164071,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885164071)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475098663),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.Type, $.$$.System.Type).$h,
      "n": "s_metadataTypeCache",
      "d": 262183,
      "h": 21475098663,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21475098663),
//--TRIMMABLE-BOUNDARY-START(25770065959),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.String), $.$typeArray($.$$.System.Attribute)).$h,
      "n": "s_typeMemberCache",
      "d": 262183,
      "h": 25770065959,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770065959),
//--TRIMMABLE-BOUNDARY-START(30065033255),
    {
      "t": $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$$.System.ValueTuple$$$($.$$.System.Type, $.$$.System.Type), $.$$.System.Boolean).$h,
      "n": "s_validatedMetadataTypeCache",
      "d": 262183,
      "h": 30065033255,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(30065033255)
  ],
  "d": 196647,
  "h": 262183
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache`; }
                }, $cls, ($v) => $cls.$_TypeDescriptorCache = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262183)
            
            static $h = 196647;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 2883625,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475033127),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967719,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719673383,
        "f": 83886082
      },
      "n": "AssociatedMetadataType",
      "d": 196647,
      "h": 21475033127,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21475033127),
//--TRIMMABLE-BOUNDARY-START(60129738791),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902311,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77309607975,
        "f": 83886082
      },
      "n": "IsSelfAssociated",
      "d": 196647,
      "h": 60129738791,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60129738791)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539804199),
    {
      "r": 14090281,
      "p": [
        {
          "n": "attributes",
          "p": $.$typeArray($.$$.System.Attribute).$h
        }
      ],
      "n": "GetProperties",
      "o": "@$1",
      "d": 196647,
      "h": 51539804199,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51539804199),
//--TRIMMABLE-BOUNDARY-START(47244836903),
    {
      "r": 14090281,
      "n": "GetProperties",
      "d": 196647,
      "h": 47244836903,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47244836903),
//--TRIMMABLE-BOUNDARY-START(55834771495),
    {
      "r": 14090281,
      "p": [
        {
          "n": "originalCollection",
          "p": 14090281
        }
      ],
      "n": "GetPropertiesWithMetadata",
      "d": 196647,
      "h": 55834771495,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55834771495),
//--TRIMMABLE-BOUNDARY-START(42949869607),
    {
      "r": 1179689,
      "n": "GetAttributes",
      "d": 196647,
      "h": 42949869607,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949869607)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065831),
    {
      "p": [
        {
          "n": "parent",
          "p": 10616873
        },
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "associatedMetadataType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196647,
      "h": 17180065831,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065831)
  ],
  "i": [10616873
  ],
  "j": [262183
  ],
  "h": 196647
}; }
            static get $b() { return $.$sct.System.ComponentModel.CustomTypeDescriptor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sct.System.ComponentModel.ICustomTypeDescriptor ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196647)
        
        
        //--TRIMMABLE-BOUNDARY-START(917543)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DeniedValuesAttribute", ($self) => class DeniedValuesAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590852135)
            $ctor$6(/*params object?[]*/ values)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590852135);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(values, "values");
                    this.Values = values;
                    this.DefaultErrorMessage = $.$sca.System.SR.DeniedValuesAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852135)
            
            //--TRIMMABLE-BOUNDARY-START(25770721319)
            /*object?[]*/ Values = null;
            //--TRIMMABLE-BOUNDARY-END(25770721319)
            
            //--TRIMMABLE-BOUNDARY-START(21475754023)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this.Values;
                while ($i1 < $arr1.length)
                {
                    let denied = $arr1[$i1++];
                    if (denied === null ? value === null : $.$$.System.Object.Equals$1.call(denied, value))
                    {
                        return false;
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754023)
            
            static $h = 917543;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770721319),
    {
      "p": $.$typeArray($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180786727,
        "f": 50331649
      },
      "n": "Values",
      "d": 917543,
      "h": 25770721319,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770721319)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475754023),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 917543,
      "h": 21475754023,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475754023)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852135),
    {
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 917543,
      "h": 8590852135,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852135)
  ],
  "h": 917543,
  "a": [
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DeniedValuesAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917543)
        
        
        //--TRIMMABLE-BOUNDARY-START(393255)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Base64StringAttribute", ($self) => class Base64StringAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295360551)
            $ctor$6()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360551);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.Base64StringAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360551)
            
            //--TRIMMABLE-BOUNDARY-START(8590327847)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327847);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!$.$is(value, $.$$.System.String, { set $v(v){ valueAsString = v; } }))
                {
                    return false;
                }
                return $.$$.System.Buffers.Text.Base64.IsValid$3($.$$.System.String.op_Implicit(valueAsString));
            }
            //--TRIMMABLE-BOUNDARY-END(8590327847)
            
            static $h = 393255;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327847),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 393255,
      "h": 8590327847,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590327847)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360551),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 393255,
      "h": 4295360551,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360551)
  ],
  "h": 393255,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Base64StringAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393255)
        
        
        //--TRIMMABLE-BOUNDARY-START(65575)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AllowedValuesAttribute", ($self) => class AllowedValuesAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590000167)
            $ctor$6(/*params object?[]*/ values)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000167);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(values, "values");
                    this.Values = values;
                    this.DefaultErrorMessage = $.$sca.System.SR.AllowedValuesAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000167)
            
            //--TRIMMABLE-BOUNDARY-START(25769869351)
            /*object?[]*/ Values = null;
            //--TRIMMABLE-BOUNDARY-END(25769869351)
            
            //--TRIMMABLE-BOUNDARY-START(21474902055)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902055);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = this.Values;
                while ($i1 < $arr1.length)
                {
                    let allowed = $arr1[$i1++];
                    if (allowed === null ? value === null : $.$$.System.Object.Equals$1.call(allowed, value))
                    {
                        return true;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902055)
            
            static $h = 65575;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25769869351),
    {
      "p": $.$typeArray($.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17179934759,
        "f": 50331649
      },
      "n": "Values",
      "d": 65575,
      "h": 25769869351,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25769869351)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21474902055),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 65575,
      "h": 21474902055,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21474902055)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000167),
    {
      "p": [
        {
          "n": "values",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 65575,
      "h": 8590000167,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000167)
  ],
  "h": 65575,
  "a": [
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AllowedValuesAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65575)
        
        
        //--TRIMMABLE-BOUNDARY-START(458791)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CompareAttribute", ($self) => class CompareAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(12885360679)
            $ctor$6(/*string*/ otherProperty)
            {
                super.$ctor$5($.$sca.System.SR.CompareAttribute_MustMatch);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885360679);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(otherProperty, "otherProperty");
                    this.OtherProperty = otherProperty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360679)
            
            //--TRIMMABLE-BOUNDARY-START(55835033639)
            /*string*/ OtherProperty = null;
            //--TRIMMABLE-BOUNDARY-END(55835033639)
            
            //--TRIMMABLE-BOUNDARY-START(60130000935)
            /*string?*/ OtherPropertyDisplayName = null;
            //--TRIMMABLE-BOUNDARY-END(60130000935)
            
            //--TRIMMABLE-BOUNDARY-START(64424968231)
            /*bool */ get RequiresValidationContext()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968231)
            
            //--TRIMMABLE-BOUNDARY-START(17180327975)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180327975);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.OtherPropertyDisplayName ?? this.OtherProperty);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180327975)
            
            //--TRIMMABLE-BOUNDARY-START(51540066343)
            /*ValidationResult? */ IsValid(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066343);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(validationContext, "validationContext");
                /*var*/ let otherPropertyInfo = $.$$.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty(validationContext.ObjectType, this.OtherProperty);
                if ($.$$.System.Reflection.PropertyInfo.op_Equality$1(otherPropertyInfo, null))
                {
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2($.$sca.System.SR.Format$6($.$sca.System.SR.CompareAttribute_UnknownProperty, this.OtherProperty));
                }
                if (otherPropertyInfo.GetIndexParameters().length > 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sca.System.SR.Format$5($.$sca.System.SR.Common_PropertyNotFound, validationContext.ObjectType.FullName, this.OtherProperty));
                }
                /*object?*/ let otherPropertyValue = otherPropertyInfo.GetValue(validationContext.ObjectInstance, null);
                if (!$.$$.System.Object.Equals(value, otherPropertyValue))
                {
                    this.OtherPropertyDisplayName ??= this.GetDisplayNameForProperty(otherPropertyInfo);
                    /*string[]?*/ let memberNames = $.$$.System.String.op_Inequality(validationContext.MemberName, null) ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), [validationContext.MemberName], null, null) : null;
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1(this.FormatErrorMessage(validationContext.DisplayName), memberNames);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(51540066343)
            
            //--TRIMMABLE-BOUNDARY-START(47245099047)
            /*string? */ GetDisplayNameForProperty(/*PropertyInfo*/ property)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099047);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<Attribute>*/ let attributes = $.$$.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$2(property, true);
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let display;
                        if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, { set $v(v){ display = v; } }))
                        {
                            return display.GetName();
                        }
                    }
                }
                return this.OtherProperty;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099047)
            
            static $h = 458791;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835033639),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262567,
        "f": 50331649
      },
      "n": "OtherProperty",
      "d": 458791,
      "h": 55835033639,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835033639),
//--TRIMMABLE-BOUNDARY-START(60130000935),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360197159,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014902823,
        "f": 83886088
      },
      "n": "OtherPropertyDisplayName",
      "d": 458791,
      "h": 60130000935,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60130000935),
//--TRIMMABLE-BOUNDARY-START(64424968231),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950131751,
        "f": 50364417
      },
      "n": "RequiresValidationContext",
      "d": 458791,
      "h": 64424968231,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424968231)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180327975),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 458791,
      "h": 17180327975,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180327975),
//--TRIMMABLE-BOUNDARY-START(51540066343),
    {
      "r": 3670055,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "IsValid",
      "d": 458791,
      "h": 51540066343,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(51540066343),
//--TRIMMABLE-BOUNDARY-START(47245099047),
    {
      "r": 1310721,
      "p": [
        {
          "n": "property",
          "p": 118882305
        }
      ],
      "n": "GetDisplayNameForProperty",
      "d": 458791,
      "h": 47245099047,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245099047)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885360679),
    {
      "p": [
        {
          "n": "otherProperty",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458791,
      "h": 12885360679,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360679)
  ],
  "h": 458791,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 128,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CompareAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458791)
        
        
        //--TRIMMABLE-BOUNDARY-START(852007)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute", ($self) => class DataTypeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295819303)
            /*string[]*/ static _dataTypeStrings = null;
            //--TRIMMABLE-BOUNDARY-END(4295819303)
            
            //--TRIMMABLE-BOUNDARY-START(30065623079)
            $ctor$7(/*DataType*/ dataType)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623079);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DataType = dataType;
                    switch(dataType)
                    {
                        case 2/*DataType.Date*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:d}";
                        this.DisplayFormat.ApplyFormatInEditMode = true;
                        break;
                        case 3/*DataType.Time*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:t}";
                        this.DisplayFormat.ApplyFormatInEditMode = true;
                        break;
                        case 6/*DataType.Currency*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:C}";
                        break;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623079)
            
            //--TRIMMABLE-BOUNDARY-START(25770655783)
            $ctor$6(/*string*/ customDataType)
            {
                this.$ctor$7(0/*DataType.Custom*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655783);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CustomDataType = customDataType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655783)
            
            //--TRIMMABLE-BOUNDARY-START(38655557671)
            /*DataType*/ DataType = 0;
            //--TRIMMABLE-BOUNDARY-END(38655557671)
            
            //--TRIMMABLE-BOUNDARY-START(34360590375)
            /*string?*/ CustomDataType = null;
            //--TRIMMABLE-BOUNDARY-END(34360590375)
            
            //--TRIMMABLE-BOUNDARY-START(42950524967)
            /*DisplayFormatAttribute?*/ DisplayFormat = null;
            //--TRIMMABLE-BOUNDARY-END(42950524967)
            
            //--TRIMMABLE-BOUNDARY-START(77310263335)
            /*string */ GetDataTypeName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureValidDataType();
                if (this.DataType === 0/*DataType.Custom*/)
                {
                    return this.CustomDataType;
                }
                return $.$$.System.Array.$ReadT1.call($.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute._dataTypeStrings, this.DataType);
            }
            //--TRIMMABLE-BOUNDARY-END(77310263335)
            
            //--TRIMMABLE-BOUNDARY-START(81605230631)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605230631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureValidDataType();
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230631)
            
            //--TRIMMABLE-BOUNDARY-START(47245492263)
            /*void */ EnsureValidDataType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.DataType === 0/*DataType.Custom*/ && $.$$.System.String.IsNullOrWhiteSpace(this.CustomDataType))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.DataTypeAttribute_EmptyDataTypeString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492263)
            
            //--TRIMMABLE-BOUNDARY-START(21475688487)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295819303)
                    this._dataTypeStrings = $.$$.System.Enum.GetNames$1($.$sca.System.ComponentModel.DataAnnotations.DataType);
                    //--TRIMMABLE-BOUNDARY-END(4295819303)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475688487)
            
            static $h = 852007;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655557671),
    {
      "p": 786471,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425361447,
        "f": 50331649
      },
      "n": "DataType",
      "d": 852007,
      "h": 38655557671,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655557671),
//--TRIMMABLE-BOUNDARY-START(34360590375),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835426855,
        "f": 50331649
      },
      "n": "CustomDataType",
      "d": 852007,
      "h": 34360590375,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360590375),
//--TRIMMABLE-BOUNDARY-START(42950524967),
    {
      "p": 1114151,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015296039,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90195165223,
        "f": 83886084
      },
      "n": "DisplayFormat",
      "d": 852007,
      "h": 42950524967,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950524967)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77310263335),
    {
      "r": 1310721,
      "n": "GetDataTypeName",
      "d": 852007,
      "h": 77310263335,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77310263335),
//--TRIMMABLE-BOUNDARY-START(81605230631),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 852007,
      "h": 81605230631,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605230631),
//--TRIMMABLE-BOUNDARY-START(47245492263),
    {
      "r": 65537,
      "n": "EnsureValidDataType",
      "d": 852007,
      "h": 47245492263,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47245492263)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819303),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "_dataTypeStrings",
      "d": 852007,
      "h": 4295819303,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295819303)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(30065623079),
    {
      "p": [
        {
          "n": "dataType",
          "p": 786471
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 852007,
      "h": 30065623079,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623079),
//--TRIMMABLE-BOUNDARY-START(25770655783),
    {
      "p": [
        {
          "n": "customDataType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 852007,
      "h": 25770655783,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655783)
  ],
  "h": 852007,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2496,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DataTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852007)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638439)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.LengthAttribute", ($self) => class LengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(12886540327)
            $ctor$6(/*int*/ minimumLength, /*int*/ maximumLength)
            {
                super.$ctor$5($.$sca.System.SR.LengthAttribute_ValidationError);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540327);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MinimumLength = minimumLength;
                    this.MaximumLength = maximumLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540327)
            
            //--TRIMMABLE-BOUNDARY-START(51541245991)
            /*int*/ MinimumLength = 0;
            //--TRIMMABLE-BOUNDARY-END(51541245991)
            
            //--TRIMMABLE-BOUNDARY-START(47246278695)
            /*int*/ MaximumLength = 0;
            //--TRIMMABLE-BOUNDARY-END(47246278695)
            
            //--TRIMMABLE-BOUNDARY-START(42951311399)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951311399);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                {
                    throw new $.$$.System.InvalidCastException().$ctor$13($.$sca.System.SR.Format$6($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$$.System.Object.GetType.call(value)));
                }
                return ((((length - this.MinimumLength) | 0)) >>> 0) <= ((((this.MaximumLength - this.MinimumLength) | 0)) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(42951311399)
            
            //--TRIMMABLE-BOUNDARY-START(21476474919)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476474919);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.MinimumLength, $.$$.System.Int32), $.$box(this.MaximumLength, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476474919)
            
            //--TRIMMABLE-BOUNDARY-START(17181507623)
            /*void */ EnsureLegalLengths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MinimumLength < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.LengthAttribute_InvalidMinLength);
                }
                if (this.MaximumLength < this.MinimumLength)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.LengthAttribute_InvalidMaxLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181507623)
            
            static $h = 1638439;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541245991),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656344103,
        "f": 50331649
      },
      "n": "MinimumLength",
      "d": 1638439,
      "h": 51541245991,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541245991),
//--TRIMMABLE-BOUNDARY-START(47246278695),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066409511,
        "f": 50331649
      },
      "n": "MaximumLength",
      "d": 1638439,
      "h": 47246278695,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246278695)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951311399),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1638439,
      "h": 42951311399,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951311399),
//--TRIMMABLE-BOUNDARY-START(21476474919),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 1638439,
      "h": 21476474919,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476474919),
//--TRIMMABLE-BOUNDARY-START(17181507623),
    {
      "r": 65537,
      "n": "EnsureLegalLengths",
      "d": 1638439,
      "h": 17181507623,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17181507623)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540327),
    {
      "p": [
        {
          "n": "minimumLength",
          "p": 655361
        },
        {
          "n": "maximumLength",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1638439,
      "h": 12886540327,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540327)
  ],
  "h": 1638439,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.LengthAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638439)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966119)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MinLengthAttribute", ($self) => class MinLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591900711)
            $ctor$6(/*int*/ length)
            {
                super.$ctor$5($.$sca.System.SR.MinLengthAttribute_ValidationError);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591900711);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591900711)
            
            //--TRIMMABLE-BOUNDARY-START(34361704487)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(34361704487)
            
            //--TRIMMABLE-BOUNDARY-START(30066737191)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                {
                    throw new $.$$.System.InvalidCastException().$ctor$13($.$sca.System.SR.Format$6($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$$.System.Object.GetType.call(value)));
                }
                return length >= this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(30066737191)
            
            //--TRIMMABLE-BOUNDARY-START(17181835303)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181835303);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.Length, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181835303)
            
            //--TRIMMABLE-BOUNDARY-START(12886868007)
            /*void */ EnsureLegalLengths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Length < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.MinLengthAttribute_InvalidMinLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886868007)
            
            static $h = 1966119;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361704487),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771769895,
        "f": 50331649
      },
      "n": "Length",
      "d": 1966119,
      "h": 34361704487,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361704487)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066737191),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1966119,
      "h": 30066737191,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066737191),
//--TRIMMABLE-BOUNDARY-START(17181835303),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 1966119,
      "h": 17181835303,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181835303),
//--TRIMMABLE-BOUNDARY-START(12886868007),
    {
      "r": 65537,
      "n": "EnsureLegalLengths",
      "d": 1966119,
      "h": 12886868007,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(12886868007)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591900711),
    {
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1966119,
      "h": 8591900711,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591900711)
  ],
  "h": 1966119,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MinLengthAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966119)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835047)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper", ($self) => class MetadataPropertyDescriptorWrapper extends $.$sct.System.ComponentModel.PropertyDescriptor
        {
            //--TRIMMABLE-BOUNDARY-START(4296802343)
            /*PropertyDescriptor*/ _descriptor = null;
            //--TRIMMABLE-BOUNDARY-END(4296802343)
            
            //--TRIMMABLE-BOUNDARY-START(8591769639)
            /*bool*/ _isReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(8591769639)
            
            //--TRIMMABLE-BOUNDARY-START(12886736935)
            $ctor$8(/*PropertyDescriptor*/ descriptor, /*Attribute[]*/ newAttributes)
            {
                super.$ctor$6(descriptor, newAttributes);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886736935);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._descriptor = descriptor;
                    let $i1 = 0;
                    let $arr1 = newAttributes;
                    while ($i1 < $arr1.length)
                    {
                        let attribute = $arr1[$i1++];
                        let readOnlyAttribute;
                        if ($.$is(attribute, $.$scp.System.ComponentModel.ReadOnlyAttribute, { set $v(v){ readOnlyAttribute = v; } }))
                        {
                            this._isReadOnly = readOnlyAttribute.IsReadOnly;
                            break;
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736935)
            
            //--TRIMMABLE-BOUNDARY-START(17181704231)
            /*void */ AddValueChanged(/*object*/ component, /*EventHandler*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181704231);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptor.AddValueChanged(component, handler);
            }
            //--TRIMMABLE-BOUNDARY-END(17181704231)
            
            //--TRIMMABLE-BOUNDARY-START(21476671527)
            /*bool */ CanResetValue(/*object*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476671527);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.CanResetValue(component);
            }
            //--TRIMMABLE-BOUNDARY-END(21476671527)
            
            //--TRIMMABLE-BOUNDARY-START(25771638823)
            /*Type */ get ComponentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361573415);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.ComponentType;
            }
            //--TRIMMABLE-BOUNDARY-END(25771638823)
            
            //--TRIMMABLE-BOUNDARY-START(64426344487)
            /*object? */ GetValue(/*object?*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426344487);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.GetValue(component);
            }
            //--TRIMMABLE-BOUNDARY-END(64426344487)
            
            //--TRIMMABLE-BOUNDARY-START(68721311783)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951508007);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._isReadOnly || this._descriptor.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(68721311783)
            
            //--TRIMMABLE-BOUNDARY-START(73016279079)
            /*Type */ get PropertyType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541442599);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.PropertyType;
            }
            //--TRIMMABLE-BOUNDARY-END(73016279079)
            
            //--TRIMMABLE-BOUNDARY-START(77311246375)
            /*void */ RemoveValueChanged(/*object*/ component, /*EventHandler*/ handler)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311246375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptor.RemoveValueChanged(component, handler);
            }
            //--TRIMMABLE-BOUNDARY-END(77311246375)
            
            //--TRIMMABLE-BOUNDARY-START(81606213671)
            /*void */ ResetValue(/*object*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606213671);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptor.ResetValue(component);
            }
            //--TRIMMABLE-BOUNDARY-END(81606213671)
            
            //--TRIMMABLE-BOUNDARY-START(85901180967)
            /*void */ SetValue(/*object?*/ component, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85901180967);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._descriptor.SetValue(component, value);
            }
            //--TRIMMABLE-BOUNDARY-END(85901180967)
            
            //--TRIMMABLE-BOUNDARY-START(90196148263)
            /*bool */ ShouldSerializeValue(/*object*/ component)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196148263);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.ShouldSerializeValue(component);
            }
            //--TRIMMABLE-BOUNDARY-END(90196148263)
            
            //--TRIMMABLE-BOUNDARY-START(94491115559)
            /*bool */ get SupportsChangeEvents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131377191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._descriptor.SupportsChangeEvents;
            }
            //--TRIMMABLE-BOUNDARY-END(94491115559)
            
            static $h = 1835047;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 14024745,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771638823),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361573415,
        "f": 50364417
      },
      "n": "ComponentType",
      "d": 1835047,
      "h": 25771638823,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25771638823),
//--TRIMMABLE-BOUNDARY-START(68721311783),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951508007,
        "f": 50364417
      },
      "n": "IsReadOnly",
      "d": 1835047,
      "h": 68721311783,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(68721311783),
//--TRIMMABLE-BOUNDARY-START(73016279079),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541442599,
        "f": 50364417
      },
      "n": "PropertyType",
      "d": 1835047,
      "h": 73016279079,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73016279079),
//--TRIMMABLE-BOUNDARY-START(94491115559),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131377191,
        "f": 50364417
      },
      "n": "SupportsChangeEvents",
      "d": 1835047,
      "h": 94491115559,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94491115559)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181704231),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 79822849
        }
      ],
      "n": "AddValueChanged",
      "d": 1835047,
      "h": 17181704231,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181704231),
//--TRIMMABLE-BOUNDARY-START(21476671527),
    {
      "r": 262145,
      "p": [
        {
          "n": "component",
          "p": 131073
        }
      ],
      "n": "CanResetValue",
      "d": 1835047,
      "h": 21476671527,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476671527),
//--TRIMMABLE-BOUNDARY-START(64426344487),
    {
      "r": 131073,
      "p": [
        {
          "n": "component",
          "p": 131073
        }
      ],
      "n": "GetValue",
      "d": 1835047,
      "h": 64426344487,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64426344487),
//--TRIMMABLE-BOUNDARY-START(77311246375),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 79822849
        }
      ],
      "n": "RemoveValueChanged",
      "d": 1835047,
      "h": 77311246375,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77311246375),
//--TRIMMABLE-BOUNDARY-START(81606213671),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 131073
        }
      ],
      "n": "ResetValue",
      "d": 1835047,
      "h": 81606213671,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81606213671),
//--TRIMMABLE-BOUNDARY-START(85901180967),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 131073
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "SetValue",
      "d": 1835047,
      "h": 85901180967,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85901180967),
//--TRIMMABLE-BOUNDARY-START(90196148263),
    {
      "r": 262145,
      "p": [
        {
          "n": "component",
          "p": 131073
        }
      ],
      "n": "ShouldSerializeValue",
      "d": 1835047,
      "h": 90196148263,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90196148263)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802343),
    {
      "t": 14024745,
      "n": "_descriptor",
      "d": 1835047,
      "h": 4296802343,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296802343),
//--TRIMMABLE-BOUNDARY-START(8591769639),
    {
      "t": 262145,
      "n": "_isReadOnly",
      "d": 1835047,
      "h": 8591769639,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591769639)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886736935),
    {
      "p": [
        {
          "n": "descriptor",
          "p": 14024745
        },
        {
          "n": "newAttributes",
          "p": $.$typeArray($.$$.System.Attribute).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1835047,
      "h": 12886736935,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886736935)
  ],
  "h": 1835047
}; }
            static get $b() { return $.$sct.System.ComponentModel.PropertyDescriptor; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835047)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228263)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RequiredAttribute", ($self) => class RequiredAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8592162855)
            $ctor$6()
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.RequiredAttribute_ValidationError;
                }, {
  "r": 1310721,
  "n": "",
  "d": 2228263,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8592162855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8592162855)
            
            //--TRIMMABLE-BOUNDARY-START(12887130151)
            /*bool*/ AllowEmptyStrings = false;
            //--TRIMMABLE-BOUNDARY-END(12887130151)
            
            //--TRIMMABLE-BOUNDARY-START(25772032039)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25772032039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return false;
                }
                let stringValue;
                return this.AllowEmptyStrings || !$.$is(value, $.$$.System.String, { set $v(v){ stringValue = v; } }) || !$.$$.System.String.IsNullOrWhiteSpace(stringValue);
            }
            //--TRIMMABLE-BOUNDARY-END(25772032039)
            
            static $h = 2228263;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12887130151),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477064743,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34361966631,
        "f": 83886081
      },
      "n": "AllowEmptyStrings",
      "d": 2228263,
      "h": 12887130151,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12887130151)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25772032039),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 2228263,
      "h": 25772032039,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25772032039)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8592162855),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2228263,
      "h": 8592162855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8592162855)
  ],
  "h": 2228263,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RequiredAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228263)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162727)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RegularExpressionAttribute", ($self) => class RegularExpressionAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(17182031911)
            $ctor$6(/*string*/ pattern)
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.RegexAttribute_ValidationError;
                }, {
  "r": 1310721,
  "n": "",
  "d": 2162727,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17182031911);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Pattern = pattern;
                    this.MatchTimeoutInMilliseconds = 2000;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17182031911)
            
            //--TRIMMABLE-BOUNDARY-START(68721639463)
            /*int*/ MatchTimeoutInMilliseconds = 0;
            //--TRIMMABLE-BOUNDARY-END(68721639463)
            
            //--TRIMMABLE-BOUNDARY-START(64426672167)
            /*TimeSpan */ get MatchTimeout()
            {
                return $.$$.System.TimeSpan.FromMilliseconds$2(BigInt(this.MatchTimeoutInMilliseconds));
            }
            //--TRIMMABLE-BOUNDARY-END(64426672167)
            
            //--TRIMMABLE-BOUNDARY-START(73016606759)
            /*string*/ Pattern = null;
            //--TRIMMABLE-BOUNDARY-END(73016606759)
            
            //--TRIMMABLE-BOUNDARY-START(77311574055)
            /*Regex?*/ Regex = null;
            //--TRIMMABLE-BOUNDARY-END(77311574055)
            
            //--TRIMMABLE-BOUNDARY-START(60131704871)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131704871);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetupRegex();
                /*string?*/ let stringValue = $.$$.System.Convert.ToString$23(value, $.$$.System.Globalization.CultureInfo.CurrentCulture);
                if ($.$$.System.String.IsNullOrEmpty(stringValue))
                {
                    return true;
                }
                var $en2 = this.Regex.EnumerateMatches$4($.$$.System.String.op_Implicit(stringValue)).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var m = $en2.Current;
                    {
                        return m.Index === 0 && m.Length === stringValue.length;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(60131704871)
            
            //--TRIMMABLE-BOUNDARY-START(21476999207)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476999207);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetupRegex();
                return $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.Pattern);
            }
            //--TRIMMABLE-BOUNDARY-END(21476999207)
            
            //--TRIMMABLE-BOUNDARY-START(98786410535)
            /*void */ SetupRegex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786410535);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Regex === null)
                {
                    if ($.$$.System.String.IsNullOrEmpty(this.Pattern))
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.RegularExpressionAttribute_Empty_Pattern);
                    }
                    this.Regex = this.MatchTimeoutInMilliseconds === -1 ? new $.$str.System.Text.RegularExpressions.Regex().$ctor$7(this.Pattern) : new $.$str.System.Text.RegularExpressions.Regex().$ctor$5(this.Pattern, 0, $.$$.System.TimeSpan.FromMilliseconds$2(BigInt(this.MatchTimeoutInMilliseconds)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98786410535)
            
            static $h = 2162727;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68721639463),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656868391,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85901508647,
        "f": 83886081
      },
      "n": "MatchTimeoutInMilliseconds",
      "d": 2162727,
      "h": 68721639463,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721639463),
//--TRIMMABLE-BOUNDARY-START(64426672167),
    {
      "p": 185860097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066933799,
        "f": 50331649
      },
      "n": "MatchTimeout",
      "d": 2162727,
      "h": 64426672167,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64426672167),
//--TRIMMABLE-BOUNDARY-START(73016606759),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246802983,
        "f": 50331649
      },
      "n": "Pattern",
      "d": 2162727,
      "h": 73016606759,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73016606759),
//--TRIMMABLE-BOUNDARY-START(77311574055),
    {
      "p": 1900602,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836737575,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94491443239,
        "f": 83886082
      },
      "n": "Regex",
      "d": 2162727,
      "h": 77311574055,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(77311574055)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131704871),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 2162727,
      "h": 60131704871,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131704871),
//--TRIMMABLE-BOUNDARY-START(21476999207),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 2162727,
      "h": 21476999207,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476999207),
//--TRIMMABLE-BOUNDARY-START(98786410535),
    {
      "r": 65537,
      "n": "SetupRegex",
      "d": 2162727,
      "h": 98786410535,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98786410535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17182031911),
    {
      "p": [
        {
          "n": "pattern",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2162727,
      "h": 17182031911,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17182031911)
  ],
  "h": 2162727,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RegularExpressionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162727)
        
        
        //--TRIMMABLE-BOUNDARY-START(2883623)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.StringLengthAttribute", ($self) => class StringLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(12887785511)
            $ctor$6(/*int*/ maximumLength)
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.StringLengthAttribute_ValidationError;
                }, {
  "r": 1310721,
  "n": "",
  "d": 2883623,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12887785511);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.MaximumLength = maximumLength;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12887785511)
            
            //--TRIMMABLE-BOUNDARY-START(47247523879)
            /*int*/ MaximumLength = 0;
            //--TRIMMABLE-BOUNDARY-END(47247523879)
            
            //--TRIMMABLE-BOUNDARY-START(51542491175)
            /*int*/ MinimumLength = 0;
            //--TRIMMABLE-BOUNDARY-END(51542491175)
            
            //--TRIMMABLE-BOUNDARY-START(42952556583)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952556583);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureLegalLengths();
                if (value === null)
                {
                    return true;
                }
                /*int*/ let length = ($.$cast(value, $.$$.System.String)).length;
                return length >= this.MinimumLength && length <= this.MaximumLength;
            }
            //--TRIMMABLE-BOUNDARY-END(42952556583)
            
            //--TRIMMABLE-BOUNDARY-START(21477720103)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477720103);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureLegalLengths();
                /*bool*/ let useErrorMessageWithMinimum = this.MinimumLength !== 0 && !this.CustomErrorMessageSet;
                /*string*/ let errorMessage = useErrorMessageWithMinimum ? $.$sca.System.SR.StringLengthAttribute_ValidationErrorIncludingMinimum : this.ErrorMessageString;
                return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, errorMessage, name, $.$box(this.MaximumLength, $.$$.System.Int32), $.$box(this.MinimumLength, $.$$.System.Int32));
            }
            //--TRIMMABLE-BOUNDARY-END(21477720103)
            
            //--TRIMMABLE-BOUNDARY-START(17182752807)
            /*void */ EnsureLegalLengths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182752807);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.MaximumLength < 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.StringLengthAttribute_InvalidMaxLength);
                }
                if (this.MaximumLength < this.MinimumLength)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.RangeAttribute_MinGreaterThanMax, $.$box(this.MaximumLength, $.$$.System.Int32), $.$box(this.MinimumLength, $.$$.System.Int32)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17182752807)
            
            static $h = 2883623;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47247523879),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067654695,
        "f": 50331649
      },
      "n": "MaximumLength",
      "d": 2883623,
      "h": 47247523879,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47247523879),
//--TRIMMABLE-BOUNDARY-START(51542491175),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38657589287,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60132425767,
        "f": 83886081
      },
      "n": "MinimumLength",
      "d": 2883623,
      "h": 51542491175,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51542491175)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42952556583),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 2883623,
      "h": 42952556583,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42952556583),
//--TRIMMABLE-BOUNDARY-START(21477720103),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 2883623,
      "h": 21477720103,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21477720103),
//--TRIMMABLE-BOUNDARY-START(17182752807),
    {
      "r": 65537,
      "n": "EnsureLegalLengths",
      "d": 2883623,
      "h": 17182752807,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(17182752807)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12887785511),
    {
      "p": [
        {
          "n": "maximumLength",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2883623,
      "h": 12887785511,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12887785511)
  ],
  "h": 2883623,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.StringLengthAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2883623)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097191)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RangeAttribute", ($self) => class RangeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(42951770151)
            $ctor$7(/*int*/ minimum, /*int*/ maximum)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951770151);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Minimum = $.$box(minimum, $.$$.System.Int32);
                    this.Maximum = $.$box(maximum, $.$$.System.Int32);
                    this.OperandType = $.$$.System.Int32.$type;
                    this.ErrorMessageResourceAccessor = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951770151)
            
            //--TRIMMABLE-BOUNDARY-START(38656802855)
            $ctor$6(/*double*/ minimum, /*double*/ maximum)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656802855);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Minimum = $.$box(minimum, $.$$.System.Double);
                    this.Maximum = $.$box(maximum, $.$$.System.Double);
                    this.OperandType = $.$$.System.Double.$type;
                    this.ErrorMessageResourceAccessor = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656802855)
            
            //--TRIMMABLE-BOUNDARY-START(47246737447)
            $ctor$8(/*Type*/ type, /*string*/ minimum, /*string*/ maximum)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246737447);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.OperandType = type;
                    this.Minimum = minimum;
                    this.Maximum = maximum;
                    this.ErrorMessageResourceAccessor = new ($.$$.System.Func$$($.$$.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246737447)
            
            //--TRIMMABLE-BOUNDARY-START(158915887143)
            /*object*/ Minimum = null;
            //--TRIMMABLE-BOUNDARY-END(158915887143)
            
            //--TRIMMABLE-BOUNDARY-START(150325952551)
            /*object*/ Maximum = null;
            //--TRIMMABLE-BOUNDARY-END(150325952551)
            
            //--TRIMMABLE-BOUNDARY-START(163210854439)
            /*bool*/ MinimumIsExclusive = false;
            //--TRIMMABLE-BOUNDARY-END(163210854439)
            
            //--TRIMMABLE-BOUNDARY-START(154620919847)
            /*bool*/ MaximumIsExclusive = false;
            //--TRIMMABLE-BOUNDARY-END(154620919847)
            
            //--TRIMMABLE-BOUNDARY-START(167505821735)
            /*Type*/ OperandType = null;
            //--TRIMMABLE-BOUNDARY-END(167505821735)
            
            //--TRIMMABLE-BOUNDARY-START(171800789031)
            /*bool*/ ParseLimitsInInvariantCulture = false;
            //--TRIMMABLE-BOUNDARY-END(171800789031)
            
            //--TRIMMABLE-BOUNDARY-START(55836672039)
            /*bool*/ ConvertValueInInvariantCulture = false;
            //--TRIMMABLE-BOUNDARY-END(55836672039)
            
            //--TRIMMABLE-BOUNDARY-START(51541704743)
            /*Func<object, object?>?*/ Conversion = null;
            //--TRIMMABLE-BOUNDARY-END(51541704743)
            
            //--TRIMMABLE-BOUNDARY-START(141736017959)
            /*void */ Initialize(/*IComparable*/ minimum, /*IComparable*/ maximum, /*Func<object, object?>*/ conversion)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736017959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let cmp = minimum.System$IComparable$CompareTo(maximum);
                if (cmp > 0)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.RangeAttribute_MinGreaterThanMax, maximum, minimum));
                }
                else if (cmp === 0 && (this.MinimumIsExclusive || this.MaximumIsExclusive))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.RangeAttribute_CannotUseExclusiveBoundsWhenTheyAreEqual);
                }
                this.Minimum = minimum;
                this.Maximum = maximum;
                this.Conversion = conversion;
            }
            //--TRIMMABLE-BOUNDARY-END(141736017959)
            
            //--TRIMMABLE-BOUNDARY-START(146030985255)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030985255);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetupConversion();
                if ((value === null) || ($.$is(value, $.$$.System.String) && value.length === 0))
                {
                    return true;
                }
                /*object?*/ let convertedValue;
                try
                {
                    convertedValue = this.Conversion.Invoke(value);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.NotSupportedException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
                /*var*/ let min = $.$cast(this.Minimum, $.$$.System.IComparable);
                /*var*/ let max = $.$cast(this.Maximum, $.$$.System.IComparable);
                return (this.MinimumIsExclusive ? min.System$IComparable$CompareTo(convertedValue) < 0 : min.System$IComparable$CompareTo(convertedValue) <= 0) && (this.MaximumIsExclusive ? max.System$IComparable$CompareTo(convertedValue) > 0 : max.System$IComparable$CompareTo(convertedValue) >= 0);
            }
            //--TRIMMABLE-BOUNDARY-END(146030985255)
            
            //--TRIMMABLE-BOUNDARY-START(60131639335)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131639335);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SetupConversion();
                return $.$$.System.String.Format($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.Minimum, this.Maximum);
            }
            //--TRIMMABLE-BOUNDARY-END(60131639335)
            
            //--TRIMMABLE-BOUNDARY-START(236225298471)
            /*void */ SetupConversion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225298471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Conversion === null)
                {
                    /*object*/ let minimum = this.Minimum;
                    /*object*/ let maximum = this.Maximum;
                    if (minimum === null || maximum === null)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.RangeAttribute_Must_Set_Min_And_Max);
                    }
                    /*Type*/ let operandType = $.$$.System.Object.GetType.call(minimum);
                    if ($.$$.System.Type.op_Equality$1(operandType, $.$$.System.Int32.$type))
                    {
                        this.Initialize($.$box($.$cast(minimum, $.$$.System.Int32), $.$$.System.Int32), $.$box($.$cast(maximum, $.$$.System.Int32), $.$$.System.Int32), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor(this,  (/*v*/ v) =>
                        {
                            return $.$box($.$$.System.Convert.ToInt32$9(v, $.$$.System.Globalization.CultureInfo.InvariantCulture), $.$$.System.Int32);
                        }, {
  "r": 131073,
  "p": [
    {
      "n": "v",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2097191,
  "h": 0,
  "f": 17825794
}));
                    }
                    else if ($.$$.System.Type.op_Equality$1(operandType, $.$$.System.Double.$type))
                    {
                        this.Initialize($.$box($.$cast(minimum, $.$$.System.Double), $.$$.System.Double), $.$box($.$cast(maximum, $.$$.System.Double), $.$$.System.Double), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor(this,  (/**/ v) =>
                        {
                            return $.$box($.$$.System.Convert.ToDouble$9(v, $.$$.System.Globalization.CultureInfo.InvariantCulture), $.$$.System.Double);
                        }, {
  "r": 131073,
  "p": [
    {
      "n": "v",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2097191,
  "h": 0,
  "f": 17825794
}));
                    }
                    else 
                    {
                        /*Type*/ let type = this.OperandType;
                        if ($.$$.System.Type.op_Equality$1(type, null))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.RangeAttribute_Must_Set_Operand_Type);
                        }
                        /*Type*/ let comparableType = $.$$.System.IComparable.$type;
                        if (!comparableType.IsAssignableFrom(type))
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$5($.$sca.System.SR.RangeAttribute_ArbitraryTypeNotIComparable, type.FullName, comparableType.FullName));
                        }
                        /*TypeConverter*/ let converter = this.GetOperandTypeConverter();
                        /*IComparable*/ let min = $.$cast((this.ParseLimitsInInvariantCulture ? converter.ConvertFromInvariantString($.$cast(minimum, $.$$.System.String)) : converter.ConvertFromString($.$cast(minimum, $.$$.System.String))), $.$$.System.IComparable);
                        /*IComparable*/ let max = $.$cast((this.ParseLimitsInInvariantCulture ? converter.ConvertFromInvariantString($.$cast(maximum, $.$$.System.String)) : converter.ConvertFromString($.$cast(maximum, $.$$.System.String))), $.$$.System.IComparable);
                        /*Func<object, object?>*/ let conversion;
                        if (this.ConvertValueInInvariantCulture)
                        {
                            conversion = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor(this,  (/*value*/ value) =>
                            {
                                return $.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(value), type) ? value : converter.ConvertFrom$1(null, $.$$.System.Globalization.CultureInfo.InvariantCulture, value);
                            }, {
  "r": 131073,
  "p": [
    {
      "n": "value",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2097191,
  "h": 0,
  "f": 17825794
});
                        }
                        else 
                        {
                            conversion = new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object))().$ctor(this,  (/*value*/ value) =>
                            {
                                return $.$$.System.Type.op_Equality$1($.$$.System.Object.GetType.call(value), type) ? value : converter.ConvertFrom(value);
                            }, {
  "r": 131073,
  "p": [
    {
      "n": "value",
      "p": 131073
    }
  ],
  "n": "",
  "d": 2097191,
  "h": 0,
  "f": 17825794
});
                        }
                        this.Initialize(min, max, conversion);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236225298471)
            
            //--TRIMMABLE-BOUNDARY-START(133146083367)
            /*TypeConverter */ GetOperandTypeConverter()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133146083367);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sct.System.ComponentModel.TypeDescriptor.GetConverter$2(this.OperandType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133146083367)
            
            //--TRIMMABLE-BOUNDARY-START(137441050663)
            /*string */ GetValidationErrorMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137441050663);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    let $switch1 = this.MinimumIsExclusive;
                    let $switch2 = this.MaximumIsExclusive;
                    if (($switch1 === false) && ($switch2 === false))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError;
                    }
                    if (($switch1 === true) && ($switch2 === false))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MinExclusive;
                    }
                    if (($switch1 === false) && ($switch2 === true))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MaxExclusive;
                    }
                    if (($switch1 === true) && ($switch2 === true))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MinExclusive_MaxExclusive;
                    }
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(137441050663)
            
            static $h = 2097191;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(158915887143),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103081312295,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214750461991,
        "f": 83886082
      },
      "n": "Minimum",
      "d": 2097191,
      "h": 158915887143,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158915887143),
//--TRIMMABLE-BOUNDARY-START(150325952551),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85901443111,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570592807,
        "f": 83886082
      },
      "n": "Maximum",
      "d": 2097191,
      "h": 150325952551,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325952551),
//--TRIMMABLE-BOUNDARY-START(163210854439),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111671246887,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223340396583,
        "f": 83886081
      },
      "n": "MinimumIsExclusive",
      "d": 2097191,
      "h": 163210854439,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(163210854439),
//--TRIMMABLE-BOUNDARY-START(154620919847),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94491377703,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206160527399,
        "f": 83886081
      },
      "n": "MaximumIsExclusive",
      "d": 2097191,
      "h": 154620919847,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620919847),
//--TRIMMABLE-BOUNDARY-START(167505821735),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120261181479,
        "f": 50331649
      },
      "n": "OperandType",
      "d": 2097191,
      "h": 167505821735,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167505821735),
//--TRIMMABLE-BOUNDARY-START(171800789031),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128851116071,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231930331175,
        "f": 83886081
      },
      "n": "ParseLimitsInInvariantCulture",
      "d": 2097191,
      "h": 171800789031,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171800789031),
//--TRIMMABLE-BOUNDARY-START(55836672039),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77311508519,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980658215,
        "f": 83886081
      },
      "n": "ConvertValueInInvariantCulture",
      "d": 2097191,
      "h": 55836672039,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836672039),
//--TRIMMABLE-BOUNDARY-START(51541704743),
    {
      "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68721573927,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390723623,
        "f": 83886082
      },
      "n": "Conversion",
      "d": 2097191,
      "h": 51541704743,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(51541704743)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(141736017959),
    {
      "r": 65537,
      "p": [
        {
          "n": "minimum",
          "p": 90046465
        },
        {
          "n": "maximum",
          "p": 90046465
        },
        {
          "n": "conversion",
          "p": $.$$.System.Func$$$($.$$.System.Object, $.$$.System.Object).$h
        }
      ],
      "n": "Initialize",
      "d": 2097191,
      "h": 141736017959,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(141736017959),
//--TRIMMABLE-BOUNDARY-START(146030985255),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 2097191,
      "h": 146030985255,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030985255),
//--TRIMMABLE-BOUNDARY-START(60131639335),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 2097191,
      "h": 60131639335,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60131639335),
//--TRIMMABLE-BOUNDARY-START(236225298471),
    {
      "r": 65537,
      "n": "SetupConversion",
      "d": 2097191,
      "h": 236225298471,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(236225298471),
//--TRIMMABLE-BOUNDARY-START(133146083367),
    {
      "r": 15925289,
      "n": "GetOperandTypeConverter",
      "d": 2097191,
      "h": 133146083367,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133146083367),
//--TRIMMABLE-BOUNDARY-START(137441050663),
    {
      "r": 1310721,
      "n": "GetValidationErrorMessage",
      "d": 2097191,
      "h": 137441050663,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137441050663)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42951770151),
    {
      "p": [
        {
          "n": "minimum",
          "p": 655361
        },
        {
          "n": "maximum",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 2097191,
      "h": 42951770151,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951770151),
//--TRIMMABLE-BOUNDARY-START(38656802855),
    {
      "p": [
        {
          "n": "minimum",
          "p": 1179649
        },
        {
          "n": "maximum",
          "p": 1179649
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 2097191,
      "h": 38656802855,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656802855),
//--TRIMMABLE-BOUNDARY-START(47246737447),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "minimum",
          "p": 1310721
        },
        {
          "n": "maximum",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2097191,
      "h": 47246737447,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246737447)
  ],
  "h": 2097191,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RangeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097191)
        
        
        //--TRIMMABLE-BOUNDARY-START(720935)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CustomValidationAttribute", ($self) => class CustomValidationAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180590119)
            /*Lazy<string?>*/ _malformedErrorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180590119)
            
            //--TRIMMABLE-BOUNDARY-START(8590655527)
            /*bool*/ _isSingleArgumentMethod = false;
            //--TRIMMABLE-BOUNDARY-END(8590655527)
            
            //--TRIMMABLE-BOUNDARY-START(12885622823)
            /*string?*/ _lastMessage = null;
            //--TRIMMABLE-BOUNDARY-END(12885622823)
            
            //--TRIMMABLE-BOUNDARY-START(21475557415)
            /*MethodInfo?*/ _methodInfo = null;
            //--TRIMMABLE-BOUNDARY-END(21475557415)
            
            //--TRIMMABLE-BOUNDARY-START(4295688231)
            /*Type?*/ _firstParameterType = null;
            //--TRIMMABLE-BOUNDARY-END(4295688231)
            
            //--TRIMMABLE-BOUNDARY-START(25770524711)
            /*Tuple<string, Type>?*/ _typeId = null;
            //--TRIMMABLE-BOUNDARY-END(25770524711)
            
            //--TRIMMABLE-BOUNDARY-START(38655426599)
            $ctor$6(/*Type*/ validatorType, /*string*/ method)
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.CustomValidationAttribute_ValidationError;
                }, {
  "r": 1310721,
  "n": "",
  "d": 720935,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426599);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.ValidatorType = validatorType;
                    this.Method = method;
                    this._malformedErrorMessage = new ($.$$.System.Lazy$$($.$$.System.String))().$ctor$6(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this, this.CheckAttributeWellFormed));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426599)
            
            //--TRIMMABLE-BOUNDARY-START(120259805223)
            /*Type*/ ValidatorType = null;
            //--TRIMMABLE-BOUNDARY-END(120259805223)
            
            //--TRIMMABLE-BOUNDARY-START(107374903335)
            /*object */ get TypeId()
            {
                return this._typeId ??= new ($.$$.System.Tuple$$$($.$$.System.String, $.$$.System.Type))().$ctor$1(this.Method, this.ValidatorType);
            }
            //--TRIMMABLE-BOUNDARY-END(107374903335)
            
            //--TRIMMABLE-BOUNDARY-START(90195034151)
            /*string*/ Method = null;
            //--TRIMMABLE-BOUNDARY-END(90195034151)
            
            //--TRIMMABLE-BOUNDARY-START(94490001447)
            /*bool */ get RequiresValidationContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230375);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfAttributeNotWellFormed();
                return !this._isSingleArgumentMethod;
            }
            //--TRIMMABLE-BOUNDARY-END(94490001447)
            
            //--TRIMMABLE-BOUNDARY-START(85900066855)
            /*ValidationResult? */ IsValid(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900066855);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfAttributeNotWellFormed();
                /*var*/ let methodInfo = this._methodInfo;
                /*object?*/ let convertedValue;
                if (!this.TryConvertValue(value, $.$ref(() => convertedValue, ($v) => convertedValue = $v, $.$$.System.Object)))
                {
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2($.$sca.System.SR.Format$7($.$sca.System.SR.CustomValidationAttribute_Type_Conversion_Failed, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ (value !== null ? $.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(value)) : "null"), this._firstParameterType, this.ValidatorType, this.Method ], null, null)));
                }
                try
                {
                    /*var*/ let methodParams = this._isSingleArgumentMethod ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [convertedValue], [-1], null) : $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [convertedValue, validationContext], null, null);
                    /*var*/ let result = $.$cast(methodInfo.Invoke(null, methodParams), $.$sca.System.ComponentModel.DataAnnotations.ValidationResult);
                    this._lastMessage = null;
                    if (result !== null)
                    {
                        this._lastMessage = result.ErrorMessage;
                    }
                    return result;
                }
                catch(tie)
                {
                    throw tie.InnerException;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900066855)
            
            //--TRIMMABLE-BOUNDARY-START(47245361191)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361191);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ThrowIfAttributeNotWellFormed();
                if (!$.$$.System.String.IsNullOrEmpty(this._lastMessage))
                {
                    return $.$$.System.String.Format$2($.$$.System.Globalization.CultureInfo.CurrentCulture, this._lastMessage, name);
                }
                return super.FormatErrorMessage(name);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361191)
            
            //--TRIMMABLE-BOUNDARY-START(42950393895)
            /*string? */ CheckAttributeWellFormed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393895);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ValidateValidatorTypeParameter() ?? this.ValidateMethodParameter();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393895)
            
            //--TRIMMABLE-BOUNDARY-START(115964837927)
            /*string? */ ValidateValidatorTypeParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837927);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(this.ValidatorType, null))
                {
                    return $.$sca.System.SR.CustomValidationAttribute_ValidatorType_Required;
                }
                if (!this.ValidatorType.IsVisible)
                {
                    return $.$sca.System.SR.Format$6($.$sca.System.SR.CustomValidationAttribute_Type_Must_Be_Public, this.ValidatorType.Name);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(115964837927)
            
            //--TRIMMABLE-BOUNDARY-START(111669870631)
            /*string? */ ValidateMethodParameter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870631);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(this.Method))
                {
                    return $.$sca.System.SR.CustomValidationAttribute_Method_Required;
                }
                /*var*/ let methodInfo = $.$sl.System.Linq.Enumerable.SingleOrDefault$1($.$$.System.Reflection.MethodInfo, this.ValidatorType.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$$.System.String.Equals$2(m.Name, this.Method, 4/*StringComparison.Ordinal*/);
                }, {
  "r": 262145,
  "p": [
    {
      "n": "m",
      "p": 116850689
    }
  ],
  "n": "",
  "d": 720935,
  "h": 0,
  "f": 17825794
}));
                if ($.$$.System.Reflection.MethodInfo.op_Equality$2(methodInfo, null))
                {
                    return $.$sca.System.SR.Format$5($.$sca.System.SR.CustomValidationAttribute_Method_Not_Found, this.Method, this.ValidatorType.Name);
                }
                if (!$.$sca.System.ComponentModel.DataAnnotations.ValidationResult.$type.IsAssignableFrom(methodInfo.ReturnType))
                {
                    return $.$sca.System.SR.Format$5($.$sca.System.SR.CustomValidationAttribute_Method_Must_Return_ValidationResult, this.Method, this.ValidatorType.Name);
                }
                /*ParameterInfo[]*/ let parameterInfos = methodInfo.GetParameters();
                if (parameterInfos.length === 0 || $.$$.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType.IsByRef)
                {
                    return $.$sca.System.SR.Format$5($.$sca.System.SR.CustomValidationAttribute_Method_Signature, this.Method, this.ValidatorType.Name);
                }
                this._isSingleArgumentMethod = (parameterInfos.length === 1);
                if (!this._isSingleArgumentMethod)
                {
                    if ((parameterInfos.length !== 2) || ($.$$.System.Type.op_Inequality$1($.$$.System.Array.$ReadT1.call(parameterInfos, 1).ParameterType, $.$sca.System.ComponentModel.DataAnnotations.ValidationContext.$type)))
                    {
                        return $.$sca.System.SR.Format$5($.$sca.System.SR.CustomValidationAttribute_Method_Signature, this.Method, this.ValidatorType.Name);
                    }
                }
                this._methodInfo = methodInfo;
                this._firstParameterType = $.$$.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType;
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(111669870631)
            
            //--TRIMMABLE-BOUNDARY-START(98784968743)
            /*void */ ThrowIfAttributeNotWellFormed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968743);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string?*/ let errorMessage = this._malformedErrorMessage.Value;
                if ($.$$.System.String.op_Inequality(errorMessage, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12(errorMessage);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784968743)
            
            //--TRIMMABLE-BOUNDARY-START(103079936039)
            /*bool */ TryConvertValue(/*object?*/ value, /*out object?*/ convertedValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079936039);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                convertedValue.$v = null;
                /*var*/ let expectedValueType = this._firstParameterType;
                if (value === null)
                {
                    if (expectedValueType.IsValueType && (!expectedValueType.IsGenericType || $.$$.System.Type.op_Inequality$1(expectedValueType.GetGenericTypeDefinition(), $.$$.System.Nullable$$().$type)))
                    {
                        return false;
                    }
                    return true;
                }
                if (expectedValueType.IsInstanceOfType(value))
                {
                    convertedValue.$v = value;
                    return true;
                }
                try
                {
                    convertedValue.$v = $.$$.System.Convert.ChangeType(value, expectedValueType, $.$$.System.Globalization.CultureInfo.CurrentCulture);
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.NotSupportedException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079936039)
            
            static $h = 720935;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259805223),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099559,
        "f": 50331649
      },
      "n": "ValidatorType",
      "d": 720935,
      "h": 120259805223,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259805223),
//--TRIMMABLE-BOUNDARY-START(107374903335),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015164967,
        "f": 50364417
      },
      "n": "TypeId",
      "d": 720935,
      "h": 107374903335,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(107374903335),
//--TRIMMABLE-BOUNDARY-START(90195034151),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835295783,
        "f": 50331649
      },
      "n": "Method",
      "d": 720935,
      "h": 90195034151,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195034151),
//--TRIMMABLE-BOUNDARY-START(94490001447),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230375,
        "f": 50364417
      },
      "n": "RequiresValidationContext",
      "d": 720935,
      "h": 94490001447,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94490001447)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(85900066855),
    {
      "r": 3670055,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "validationContext",
          "p": 3538983
        }
      ],
      "n": "IsValid",
      "d": 720935,
      "h": 85900066855,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(85900066855),
//--TRIMMABLE-BOUNDARY-START(47245361191),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 720935,
      "h": 47245361191,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245361191),
//--TRIMMABLE-BOUNDARY-START(42950393895),
    {
      "r": 1310721,
      "n": "CheckAttributeWellFormed",
      "d": 720935,
      "h": 42950393895,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(42950393895),
//--TRIMMABLE-BOUNDARY-START(115964837927),
    {
      "r": 1310721,
      "n": "ValidateValidatorTypeParameter",
      "d": 720935,
      "h": 115964837927,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(115964837927),
//--TRIMMABLE-BOUNDARY-START(111669870631),
    {
      "r": 1310721,
      "n": "ValidateMethodParameter",
      "d": 720935,
      "h": 111669870631,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(111669870631),
//--TRIMMABLE-BOUNDARY-START(98784968743),
    {
      "r": 65537,
      "n": "ThrowIfAttributeNotWellFormed",
      "d": 720935,
      "h": 98784968743,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784968743),
//--TRIMMABLE-BOUNDARY-START(103079936039),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "convertedValue",
          "p": 131073,
          "f": 2
        }
      ],
      "n": "TryConvertValue",
      "d": 720935,
      "h": 103079936039,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(103079936039)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180590119),
    {
      "t": $.$$.System.Lazy$$($.$$.System.String).$h,
      "n": "_malformedErrorMessage",
      "d": 720935,
      "h": 17180590119,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180590119),
//--TRIMMABLE-BOUNDARY-START(8590655527),
    {
      "t": 262145,
      "n": "_isSingleArgumentMethod",
      "d": 720935,
      "h": 8590655527,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655527),
//--TRIMMABLE-BOUNDARY-START(12885622823),
    {
      "t": 1310721,
      "n": "_lastMessage",
      "d": 720935,
      "h": 12885622823,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885622823),
//--TRIMMABLE-BOUNDARY-START(21475557415),
    {
      "t": 116850689,
      "n": "_methodInfo",
      "d": 720935,
      "h": 21475557415,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475557415),
//--TRIMMABLE-BOUNDARY-START(4295688231),
    {
      "t": 187760641,
      "n": "_firstParameterType",
      "d": 720935,
      "h": 4295688231,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688231),
//--TRIMMABLE-BOUNDARY-START(25770524711),
    {
      "t": $.$$.System.Tuple$$$($.$$.System.String, $.$$.System.Type).$h,
      "n": "_typeId",
      "d": 720935,
      "h": 25770524711,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770524711)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(38655426599),
    {
      "p": [
        {
          "n": "validatorType",
          "p": 187760641
        },
        {
          "n": "method",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 720935,
      "h": 38655426599,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426599)
  ],
  "h": 720935,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2500,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CustomValidationAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720935)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769511)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute", ($self) => class MaxLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(55836344359)
            /*int*/ static MaxAllowableLength = -1;
            //--TRIMMABLE-BOUNDARY-END(55836344359)
            
            //--TRIMMABLE-BOUNDARY-START(12886671399)
            $ctor$7(/*int*/ length)
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute.DefaultErrorMessageString;
                }, {
  "r": 1310721,
  "n": "",
  "d": 1769511,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671399);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Length = length;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671399)
            
            //--TRIMMABLE-BOUNDARY-START(8591704103)
            $ctor$6()
            {
                super.$ctor$4(new ($.$$.System.Func$$($.$$.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute.DefaultErrorMessageString;
                }, {
  "r": 1310721,
  "n": "",
  "d": 1769511,
  "h": 0,
  "f": 17825794
}));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704103);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Length = -1/*MaxAllowableLength*/;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591704103)
            
            //--TRIMMABLE-BOUNDARY-START(51541377063)
            /*int*/ Length = 0;
            //--TRIMMABLE-BOUNDARY-END(51541377063)
            
            //--TRIMMABLE-BOUNDARY-START(17181638695)
            static /*string */ get DefaultErrorMessageString()
            {
                return $.$sca.System.SR.MaxLengthAttribute_ValidationError;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638695)
            
            //--TRIMMABLE-BOUNDARY-START(47246409767)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246409767);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                {
                    throw new $.$$.System.InvalidCastException().$ctor$13($.$sca.System.SR.Format$6($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$$.System.Object.GetType.call(value)));
                }
                return -1/*MaxAllowableLength*/ === this.Length || length <= this.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(47246409767)
            
            //--TRIMMABLE-BOUNDARY-START(25771573287)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771573287);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.Length, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771573287)
            
            //--TRIMMABLE-BOUNDARY-START(21476605991)
            /*void */ EnsureLegalLengths()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476605991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Length === 0 || this.Length < -1)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.MaxLengthAttribute_InvalidMaxLength);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476605991)
            
            static $h = 1769511;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 3211303,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51541377063),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951442471,
        "f": 50331649
      },
      "n": "Length",
      "d": 1769511,
      "h": 51541377063,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51541377063),
//--TRIMMABLE-BOUNDARY-START(17181638695),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361507879,
        "f": 50331682
      },
      "n": "DefaultErrorMessageString",
      "d": 1769511,
      "h": 17181638695,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(17181638695)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47246409767),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1769511,
      "h": 47246409767,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47246409767),
//--TRIMMABLE-BOUNDARY-START(25771573287),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 1769511,
      "h": 25771573287,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771573287),
//--TRIMMABLE-BOUNDARY-START(21476605991),
    {
      "r": 65537,
      "n": "EnsureLegalLengths",
      "d": 1769511,
      "h": 21476605991,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(21476605991)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55836344359),
    {
      "t": 655361,
      "n": "MaxAllowableLength",
      "d": 1769511,
      "h": 55836344359,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55836344359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671399),
    {
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1769511,
      "h": 12886671399,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671399),
//--TRIMMABLE-BOUNDARY-START(8591704103),
    {
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1769511,
      "h": 8591704103,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704103)
  ],
  "h": 1769511,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MaxLengthAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769511)
        
        
        //--TRIMMABLE-BOUNDARY-START(786471)
        $asm.$str("$sca.System.ComponentModel.DataAnnotations.DataType", ($self) => class DataType extends $.$$.System.Enum
        {
            static Custom = 0;
            static DateTime = 1;
            static Date = 2;
            static Time = 3;
            static Duration = 4;
            static PhoneNumber = 5;
            static Currency = 6;
            static Text = 7;
            static Html = 8;
            static MultilineText = 9;
            static EmailAddress = 10;
            static Password = 11;
            static Url = 12;
            static ImageUrl = 13;
            static CreditCard = 14;
            static PostalCode = 15;
            static Upload = 16;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786471);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Custom": 0n,
                    "DateTime": 1n,
                    "Date": 2n,
                    "Time": 3n,
                    "Duration": 4n,
                    "PhoneNumber": 5n,
                    "Currency": 6n,
                    "Text": 7n,
                    "Html": 8n,
                    "MultilineText": 9n,
                    "EmailAddress": 10n,
                    "Password": 11n,
                    "Url": 12n,
                    "ImageUrl": 13n,
                    "CreditCard": 14n,
                    "PostalCode": 15n,
                    "Upload": 16n
                };
            }
            static $h = 786471;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180655655),
    {
      "t": 786471,
      "n": "Custom",
      "d": 786471,
      "h": 17180655655,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655655),
//--TRIMMABLE-BOUNDARY-START(25770590247),
    {
      "t": 786471,
      "n": "DateTime",
      "d": 786471,
      "h": 25770590247,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590247),
//--TRIMMABLE-BOUNDARY-START(21475622951),
    {
      "t": 786471,
      "n": "Date",
      "d": 786471,
      "h": 21475622951,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622951),
//--TRIMMABLE-BOUNDARY-START(68720263207),
    {
      "t": 786471,
      "n": "Time",
      "d": 786471,
      "h": 68720263207,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720263207),
//--TRIMMABLE-BOUNDARY-START(30065557543),
    {
      "t": 786471,
      "n": "Duration",
      "d": 786471,
      "h": 30065557543,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557543),
//--TRIMMABLE-BOUNDARY-START(55835361319),
    {
      "t": 786471,
      "n": "PhoneNumber",
      "d": 786471,
      "h": 55835361319,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835361319),
//--TRIMMABLE-BOUNDARY-START(12885688359),
    {
      "t": 786471,
      "n": "Currency",
      "d": 786471,
      "h": 12885688359,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688359),
//--TRIMMABLE-BOUNDARY-START(64425295911),
    {
      "t": 786471,
      "n": "Text",
      "d": 786471,
      "h": 64425295911,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425295911),
//--TRIMMABLE-BOUNDARY-START(38655492135),
    {
      "t": 786471,
      "n": "Html",
      "d": 786471,
      "h": 38655492135,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655492135),
//--TRIMMABLE-BOUNDARY-START(47245426727),
    {
      "t": 786471,
      "n": "MultilineText",
      "d": 786471,
      "h": 47245426727,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245426727),
//--TRIMMABLE-BOUNDARY-START(34360524839),
    {
      "t": 786471,
      "n": "EmailAddress",
      "d": 786471,
      "h": 34360524839,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524839),
//--TRIMMABLE-BOUNDARY-START(51540394023),
    {
      "t": 786471,
      "n": "Password",
      "d": 786471,
      "h": 51540394023,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540394023),
//--TRIMMABLE-BOUNDARY-START(77310197799),
    {
      "t": 786471,
      "n": "Url",
      "d": 786471,
      "h": 77310197799,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310197799),
//--TRIMMABLE-BOUNDARY-START(42950459431),
    {
      "t": 786471,
      "n": "ImageUrl",
      "d": 786471,
      "h": 42950459431,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950459431),
//--TRIMMABLE-BOUNDARY-START(8590721063),
    {
      "t": 786471,
      "n": "CreditCard",
      "d": 786471,
      "h": 8590721063,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721063),
//--TRIMMABLE-BOUNDARY-START(60130328615),
    {
      "t": 786471,
      "n": "PostalCode",
      "d": 786471,
      "h": 60130328615,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130328615),
//--TRIMMABLE-BOUNDARY-START(73015230503),
    {
      "t": 786471,
      "n": "Upload",
      "d": 786471,
      "h": 73015230503,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230503)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753767),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786471,
      "h": 4295753767,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753767)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 786471
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DataType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786471)
        
        
        //--TRIMMABLE-BOUNDARY-START(2555943)
        $asm.$str("$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption", ($self) => class DatabaseGeneratedOption extends $.$$.System.Enum
        {
            static None = 0;
            static Identity = 1;
            static Computed = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2555943);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Identity": 1n,
                    "Computed": 2n
                };
            }
            static $h = 2555943;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17182425127),
    {
      "t": 2555943,
      "n": "None",
      "d": 2555943,
      "h": 17182425127,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17182425127),
//--TRIMMABLE-BOUNDARY-START(12887457831),
    {
      "t": 2555943,
      "n": "Identity",
      "d": 2555943,
      "h": 12887457831,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12887457831),
//--TRIMMABLE-BOUNDARY-START(8592490535),
    {
      "t": 2555943,
      "n": "Computed",
      "d": 2555943,
      "h": 8592490535,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592490535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297523239),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2555943,
      "h": 4297523239,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297523239)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2555943
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2555943)
        
        
        //--TRIMMABLE-BOUNDARY-START(655399)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CreditCardAttribute", ($self) => class CreditCardAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295622695)
            $ctor$8()
            {
                super.$ctor$7(14/*DataType.CreditCard*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622695);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.CreditCardAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622695)
            
            //--TRIMMABLE-BOUNDARY-START(8590589991)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590589991);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return true;
                }
                let ccValue;
                if (!$.$is(value, $.$$.System.String, { set $v(v){ ccValue = v; } }))
                {
                    return false;
                }
                /*int*/ let checksum = 0;
                /*bool*/ let evenDigit = false;
                for(/*int*/ let i = ((ccValue.length - 1) | 0); i >= 0; i--)
                {
                    /*char*/ let digit = $.$$.System.String.get_Chars.call(ccValue, i);
                    if (!$.$$.System.Char.IsAsciiDigit(digit))
                    {
                        if ((digit === /*-*/ 45) || (digit === /* */ 32))
                        {
                            continue;
                        }
                        return false;
                    }
                    /*int*/ let digitValue = (((digit - /*0*/ 48) * (evenDigit ? 2 : 1)) | 0);
                    evenDigit = !evenDigit;
                    while(digitValue > 0)
                    {
                        checksum += digitValue % 10;
                        digitValue /= 10;
                    }
                }
                return (checksum % 10) === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(8590589991)
            
            static $h = 655399;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590589991),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 655399,
      "h": 8590589991,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590589991)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622695),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 655399,
      "h": 4295622695,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622695)
  ],
  "h": 655399,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CreditCardAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655399)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245223)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EmailAddressAttribute", ($self) => class EmailAddressAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296212519)
            $ctor$8()
            {
                super.$ctor$7(10/*DataType.EmailAddress*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212519);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.EmailAddressAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212519)
            
            //--TRIMMABLE-BOUNDARY-START(8591179815)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179815);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!($.$is(value, $.$$.System.String, { set $v(v){ valueAsString = v; } })))
                {
                    return false;
                }
                if ($.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(valueAsString), /*\r*/ 13, /*\n*/ 10))
                {
                    return false;
                }
                /*int*/ let index = $.$$.System.String.IndexOf$3.call(valueAsString, /*@*/ 64);
                return index > 0 && index !== ((valueAsString.length - 1) | 0) && index === $.$$.System.String.LastIndexOf$2.call(valueAsString, /*@*/ 64);
            }
            //--TRIMMABLE-BOUNDARY-END(8591179815)
            
            static $h = 1245223;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591179815),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1245223,
      "h": 8591179815,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591179815)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212519),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1245223,
      "h": 4296212519,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212519)
  ],
  "h": 1245223,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EmailAddressAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245223)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310759)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute", ($self) => class EnumDataTypeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591245351)
            $ctor$8(/*Type*/ enumType)
            {
                super.$ctor$6("Enumeration");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245351);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.EnumType = enumType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245351)
            
            //--TRIMMABLE-BOUNDARY-START(12886212647)
            /*Type*/ EnumType = null;
            //--TRIMMABLE-BOUNDARY-END(12886212647)
            
            //--TRIMMABLE-BOUNDARY-START(34361049127)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049127);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(this.EnumType, null))
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.EnumDataTypeAttribute_TypeCannotBeNull);
                }
                if (!this.EnumType.IsEnum)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$sca.System.SR.Format$6($.$sca.System.SR.EnumDataTypeAttribute_TypeNeedsToBeAnEnum, this.EnumType.FullName));
                }
                if (value === null)
                {
                    return true;
                }
                /*var*/ let stringValue = $.$as(value, $.$$.System.String);
                const $t1 = stringValue;
                if ($.$ifnn($t1, ($t) => $t.length) === 0)
                {
                    return true;
                }
                /*Type*/ let valueType = $.$$.System.Object.GetType.call(value);
                if (valueType.IsEnum && $.$$.System.Type.op_Inequality$1(this.EnumType, valueType))
                {
                    return false;
                }
                if (!valueType.IsValueType && $.$$.System.Type.op_Inequality$1(valueType, $.$$.System.String.$type))
                {
                    return false;
                }
                if ($.$$.System.Type.op_Equality$1(valueType, $.$$.System.Boolean.$type) || $.$$.System.Type.op_Equality$1(valueType, $.$$.System.Single.$type) || $.$$.System.Type.op_Equality$1(valueType, $.$$.System.Double.$type) || $.$$.System.Type.op_Equality$1(valueType, $.$$.System.Decimal.$type) || $.$$.System.Type.op_Equality$1(valueType, $.$$.System.Char.$type))
                {
                    return false;
                }
                /*object*/ let convertedValue;
                if (valueType.IsEnum)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(valueType, $.$$.System.Object.GetType.call(value)), "The valueType should equal the Type of the value");
                    convertedValue = value;
                }
                else 
                {
                    try
                    {
                        convertedValue = $.$$.System.String.op_Inequality(stringValue, null) ? $.$$.System.Enum.Parse$2(this.EnumType, stringValue, false) : $.$$.System.Enum.ToObject$4(this.EnumType, value);
                    }
                    catch($e)
                    {
                        return false;
                    }
                }
                if ($.$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute.IsEnumTypeInFlagsMode(this.EnumType))
                {
                    /*string*/ let underlying = $.$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute.GetUnderlyingTypeValueString(this.EnumType, convertedValue);
                    /*string?*/ let converted = $.$$.System.Object.ToString.call(convertedValue);
                    return !$.$$.System.String.Equals$5.call(underlying, converted);
                }
                return $.$$.System.Enum.IsDefined(this.EnumType, convertedValue);
            }
            //--TRIMMABLE-BOUNDARY-END(34361049127)
            
            //--TRIMMABLE-BOUNDARY-START(30066081831)
            static /*bool */ IsEnumTypeInFlagsMode(/*Type*/ enumType)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066081831);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return enumType.IsDefined($.$$.System.FlagsAttribute.$type, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066081831)
            
            //--TRIMMABLE-BOUNDARY-START(25771114535)
            static /*string? */ GetUnderlyingTypeValueString(/*Type*/ enumType, /*object*/ enumValue)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771114535);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Object.ToString.call($.$$.System.Convert.ChangeType(enumValue, $.$$.System.Enum.GetUnderlyingType(enumType), $.$$.System.Globalization.CultureInfo.InvariantCulture));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771114535)
            
            static $h = 1310759;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886212647),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476147239,
        "f": 50331649
      },
      "n": "EnumType",
      "d": 1310759,
      "h": 12886212647,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886212647)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361049127),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1310759,
      "h": 34361049127,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361049127),
//--TRIMMABLE-BOUNDARY-START(30066081831),
    {
      "r": 262145,
      "p": [
        {
          "n": "enumType",
          "p": 187760641
        }
      ],
      "n": "IsEnumTypeInFlagsMode",
      "d": 1310759,
      "h": 30066081831,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066081831),
//--TRIMMABLE-BOUNDARY-START(25771114535),
    {
      "r": 1310721,
      "p": [
        {
          "n": "enumType",
          "p": 187760641
        },
        {
          "n": "enumValue",
          "p": 131073
        }
      ],
      "n": "GetUnderlyingTypeValueString",
      "d": 1310759,
      "h": 25771114535,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771114535)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245351),
    {
      "p": [
        {
          "n": "enumType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1310759,
      "h": 8591245351,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591245351)
  ],
  "h": 1310759,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2496,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EnumDataTypeAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310759)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031655)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.PhoneAttribute", ($self) => class PhoneAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591966247)
            /*string*/ static AdditionalPhoneNumberCharacters = null;
            //--TRIMMABLE-BOUNDARY-END(8591966247)
            
            //--TRIMMABLE-BOUNDARY-START(17181900839)
            /*string*/ static ExtensionAbbreviationExtDot = null;
            //--TRIMMABLE-BOUNDARY-END(17181900839)
            
            //--TRIMMABLE-BOUNDARY-START(12886933543)
            /*string*/ static ExtensionAbbreviationExt = null;
            //--TRIMMABLE-BOUNDARY-END(12886933543)
            
            //--TRIMMABLE-BOUNDARY-START(21476868135)
            /*string*/ static ExtensionAbbreviationX = null;
            //--TRIMMABLE-BOUNDARY-END(21476868135)
            
            //--TRIMMABLE-BOUNDARY-START(4296998951)
            $ctor$8()
            {
                super.$ctor$7(5/*DataType.PhoneNumber*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296998951);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.PhoneAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296998951)
            
            //--TRIMMABLE-BOUNDARY-START(25771835431)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771835431);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!($.$is(value, $.$$.System.String, { set $v(v){ valueAsString = v; } })))
                {
                    return false;
                }
                /*ReadOnlySpan<char>*/ let valueSpan = $.$$.System.MemoryExtensions.TrimEnd$4($.$$.System.MemoryExtensions.AsSpan$4($.$$.System.String.Replace$3.call(valueAsString, "+", $.$$.System.String.Empty)));
                valueSpan = $.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.RemoveExtension(valueSpan);
                /*bool*/ let digitFound = false;
                var $en2 = valueSpan.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if ($.$$.System.Char.IsDigit(c))
                        {
                            digitFound = true;
                            break;
                        }
                    }
                }
                if (!digitFound)
                {
                    return false;
                }
                var $en2 = valueSpan.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if (!($.$$.System.Char.IsDigit(c) || $.$$.System.Char.IsWhiteSpace(c) || $.$$.System.String.Contains$1.call("-.()"/*AdditionalPhoneNumberCharacters*/, c)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(25771835431)
            
            //--TRIMMABLE-BOUNDARY-START(34361770023)
            static /*ReadOnlySpan<char> */ RemoveExtension(/*ReadOnlySpan<char>*/ potentialPhoneNumber)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361770023);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let lastIndexOfExtension = $.$$.System.MemoryExtensions.LastIndexOf(potentialPhoneNumber, $.$$.System.String.op_Implicit("ext."/*ExtensionAbbreviationExtDot*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice$1(((lastIndexOfExtension + "ext."/*ExtensionAbbreviationExtDot*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice(0, lastIndexOfExtension);
                    }
                }
                lastIndexOfExtension = $.$$.System.MemoryExtensions.LastIndexOf(potentialPhoneNumber, $.$$.System.String.op_Implicit("ext"/*ExtensionAbbreviationExt*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice$1(((lastIndexOfExtension + "ext"/*ExtensionAbbreviationExt*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice(0, lastIndexOfExtension);
                    }
                }
                lastIndexOfExtension = $.$$.System.MemoryExtensions.LastIndexOf(potentialPhoneNumber, $.$$.System.String.op_Implicit("x"/*ExtensionAbbreviationX*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice$1(((lastIndexOfExtension + "x"/*ExtensionAbbreviationX*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice(0, lastIndexOfExtension);
                    }
                }
                return potentialPhoneNumber;
            }
            //--TRIMMABLE-BOUNDARY-END(34361770023)
            
            //--TRIMMABLE-BOUNDARY-START(30066802727)
            static /*bool */ MatchesExtension(/*ReadOnlySpan<char>*/ potentialExtension)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066802727);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                potentialExtension = $.$$.System.MemoryExtensions.TrimStart$4(potentialExtension);
                if (potentialExtension.Length === 0)
                {
                    return false;
                }
                var $en2 = potentialExtension.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if (!$.$$.System.Char.IsDigit(c))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30066802727)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8591966247)
                    this.AdditionalPhoneNumberCharacters = "-.()";
                    //--TRIMMABLE-BOUNDARY-END(8591966247)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181900839)
                    this.ExtensionAbbreviationExtDot = "ext.";
                    //--TRIMMABLE-BOUNDARY-END(17181900839)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886933543)
                    this.ExtensionAbbreviationExt = "ext";
                    //--TRIMMABLE-BOUNDARY-END(12886933543)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476868135)
                    this.ExtensionAbbreviationX = "x";
                    //--TRIMMABLE-BOUNDARY-END(21476868135)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2031655;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771835431),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 2031655,
      "h": 25771835431,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771835431),
//--TRIMMABLE-BOUNDARY-START(34361770023),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "potentialPhoneNumber",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "RemoveExtension",
      "d": 2031655,
      "h": 34361770023,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361770023),
//--TRIMMABLE-BOUNDARY-START(30066802727),
    {
      "r": 262145,
      "p": [
        {
          "n": "potentialExtension",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "MatchesExtension",
      "d": 2031655,
      "h": 30066802727,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066802727)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591966247),
    {
      "t": 1310721,
      "n": "AdditionalPhoneNumberCharacters",
      "d": 2031655,
      "h": 8591966247,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8591966247),
//--TRIMMABLE-BOUNDARY-START(17181900839),
    {
      "t": 1310721,
      "n": "ExtensionAbbreviationExtDot",
      "d": 2031655,
      "h": 17181900839,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17181900839),
//--TRIMMABLE-BOUNDARY-START(12886933543),
    {
      "t": 1310721,
      "n": "ExtensionAbbreviationExt",
      "d": 2031655,
      "h": 12886933543,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12886933543),
//--TRIMMABLE-BOUNDARY-START(21476868135),
    {
      "t": 1310721,
      "n": "ExtensionAbbreviationX",
      "d": 2031655,
      "h": 21476868135,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(21476868135)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296998951),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 2031655,
      "h": 4296998951,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296998951)
  ],
  "h": 2031655,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.PhoneAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031655)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376295)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.FileExtensionsAttribute", ($self) => class FileExtensionsAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4296343591)
            /*string?*/ _extensions = null;
            //--TRIMMABLE-BOUNDARY-END(4296343591)
            
            //--TRIMMABLE-BOUNDARY-START(8591310887)
            $ctor$8()
            {
                super.$ctor$7(16/*DataType.Upload*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591310887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.FileExtensionsAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310887)
            
            //--TRIMMABLE-BOUNDARY-START(12886278183)
            /*string */ get Extensions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081959);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.IsNullOrWhiteSpace(this._extensions) ? "png,jpg,jpeg,gif" : this._extensions;
            }
            /*string */ set Extensions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310787623);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._extensions = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278183)
            
            //--TRIMMABLE-BOUNDARY-START(17181245479)
            /*string */ get ExtensionsFormatted()
            {
                return $.$sl.System.Linq.Enumerable.Aggregate$2($.$$.System.String, this.ExtensionsParsed, new ($.$$.System.Func$$$$($.$$.System.String, $.$$.System.String, $.$$.System.String))().$ctor(this,  (/*left*/ left, /*right*/ right) =>
                {
                    return left + ", " + right;
                }, {
  "r": 1310721,
  "p": [
    {
      "n": "left",
      "p": 1310721
    },
    {
      "n": "right",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 1376295,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(17181245479)
            
            //--TRIMMABLE-BOUNDARY-START(21476212775)
            /*string */ get ExtensionsNormalized()
            {
                return $.$$.System.String.ToLowerInvariant.call($.$$.System.String.Replace$3.call($.$$.System.String.Replace$3.call(this.Extensions, " ", $.$$.System.String.Empty), ".", $.$$.System.String.Empty));
            }
            //--TRIMMABLE-BOUNDARY-END(21476212775)
            
            //--TRIMMABLE-BOUNDARY-START(25771180071)
            /*IEnumerable<string> */ get ExtensionsParsed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425885735);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.System.Linq.Enumerable.Select$1($.$$.System.String, $.$$.System.String, $.$$.System.String.Split$1.call(this.ExtensionsNormalized, /*,*/ 44, 0), new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.String))().$ctor(this,  (/*e*/ e) =>
                {
                    return "." + e;
                }, {
  "r": 1310721,
  "p": [
    {
      "n": "e",
      "p": 1310721
    }
  ],
  "n": "",
  "d": 1376295,
  "h": 0,
  "f": 17825794
}));
            }
            //--TRIMMABLE-BOUNDARY-END(25771180071)
            
            //--TRIMMABLE-BOUNDARY-START(30066147367)
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30066147367);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.Format$1($.$$.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.ExtensionsFormatted);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066147367)
            
            //--TRIMMABLE-BOUNDARY-START(68720853031)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720853031);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let valueAsString;
                    return value === null || $.$is(value, $.$$.System.String, { set $v(v){ valueAsString = v; } }) && this.ValidateExtension(valueAsString);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720853031)
            
            //--TRIMMABLE-BOUNDARY-START(81605754919)
            /*bool */ ValidateExtension(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605754919);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sl.System.Linq.Enumerable.Contains$1($.$$.System.String, this.ExtensionsParsed, $.$$.System.String.ToLowerInvariant.call($.$$.System.IO.Path.GetExtension$1(fileName)));
            }
            //--TRIMMABLE-BOUNDARY-END(81605754919)
            
            static $h = 1376295;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886278183),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656081959,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310787623,
        "f": 83886081
      },
      "n": "Extensions",
      "d": 1376295,
      "h": 12886278183,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886278183),
//--TRIMMABLE-BOUNDARY-START(17181245479),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246016551,
        "f": 50331650
      },
      "n": "ExtensionsFormatted",
      "d": 1376295,
      "h": 17181245479,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(17181245479),
//--TRIMMABLE-BOUNDARY-START(21476212775),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835951143,
        "f": 50331650
      },
      "n": "ExtensionsNormalized",
      "d": 1376295,
      "h": 21476212775,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(21476212775),
//--TRIMMABLE-BOUNDARY-START(25771180071),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425885735,
        "f": 50331650
      },
      "n": "ExtensionsParsed",
      "d": 1376295,
      "h": 25771180071,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(25771180071)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30066147367),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FormatErrorMessage",
      "d": 1376295,
      "h": 30066147367,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066147367),
//--TRIMMABLE-BOUNDARY-START(68720853031),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 1376295,
      "h": 68720853031,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720853031),
//--TRIMMABLE-BOUNDARY-START(81605754919),
    {
      "r": 262145,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "ValidateExtension",
      "d": 1376295,
      "h": 81605754919,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605754919)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296343591),
    {
      "t": 1310721,
      "n": "_extensions",
      "d": 1376295,
      "h": 4296343591,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296343591)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591310887),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1376295,
      "h": 8591310887,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591310887)
  ],
  "h": 1376295,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.FileExtensionsAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376295)
        
        
        //--TRIMMABLE-BOUNDARY-START(3145767)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.UrlAttribute", ($self) => class UrlAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4298113063)
            $ctor$8()
            {
                super.$ctor$7(12/*DataType.Url*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4298113063);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DefaultErrorMessage = $.$sca.System.SR.UrlAttribute_Invalid;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4298113063)
            
            //--TRIMMABLE-BOUNDARY-START(8593080359)
            /*bool */ IsValid$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8593080359);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //switch (value)
                {
                    let valueAsUri;
                    let valueAsString;
                    $switchJumpStart1: 
                    //case Uri valueAsUri when valueAsUri.IsAbsoluteUri:
                    if ($.$is(value, $.$spu.System.Uri, { set $v(v){ valueAsUri = v; } }) && valueAsUri.IsAbsoluteUri)
                    {
                        {
                            return $.$$.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeHttp) || $.$$.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeHttps) || $.$$.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeFtp);
                        }
                    }
                    //case string valueAsString:
                    else if ($.$is(value, $.$$.System.String, { set $v(v){ valueAsString = v; } }))
                    {
                        {
                            return $.$$.System.String.StartsWith$2.call(valueAsString, "http://", 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.String.StartsWith$2.call(valueAsString, "https://", 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.String.StartsWith$2.call(valueAsString, "ftp://", 5/*StringComparison.OrdinalIgnoreCase*/);
                        }
                    }
                    //case null:
                    else if (value == null)
                    {
                        {
                            return true;
                        }
                    }
                    //default
                    else
                    {
                        {
                            return false;
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8593080359)
            
            static $h = 3145767;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 852007,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8593080359),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "IsValid",
      "o": "@$1",
      "d": 3145767,
      "h": 8593080359,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8593080359)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4298113063),
    {
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 3145767,
      "h": 4298113063,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4298113063)
  ],
  "h": 3145767,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 2432,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.UrlAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3145767)
        
        
        //--TRIMMABLE-BOUNDARY-START(3604519)
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationException", ($self) => class ValidationException extends $.$$.System.Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4298571815)
            /*ValidationResult?*/ _validationResult = null;
            //--TRIMMABLE-BOUNDARY-END(4298571815)
            
            //--TRIMMABLE-BOUNDARY-START(38658310183)
            $ctor$10(/*ValidationResult*/ validationResult, /*ValidationAttribute?*/ validatingAttribute, /*object?*/ value)
            {
                this.$ctor$8(validationResult.ErrorMessage, validatingAttribute, value);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38658310183);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._validationResult = validationResult;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38658310183)
            
            //--TRIMMABLE-BOUNDARY-START(30068375591)
            $ctor$8(/*string?*/ errorMessage, /*ValidationAttribute?*/ validatingAttribute, /*object?*/ value)
            {
                super.$ctor$4(errorMessage);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30068375591);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Value = value;
                    this.ValidationAttribute = validatingAttribute;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30068375591)
            
            //--TRIMMABLE-BOUNDARY-START(17183473703)
            $ctor$5()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17183473703);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17183473703)
            
            //--TRIMMABLE-BOUNDARY-START(34363342887)
            $ctor$9(/*string?*/ message)
            {
                super.$ctor$4(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34363342887);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34363342887)
            
            //--TRIMMABLE-BOUNDARY-START(25773408295)
            $ctor$7(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25773408295);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25773408295)
            
            //--TRIMMABLE-BOUNDARY-START(21478440999)
            $ctor$6(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$2(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21478440999);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21478440999)
            
            //--TRIMMABLE-BOUNDARY-START(68723081255)
            /*ValidationAttribute?*/ ValidationAttribute = null;
            //--TRIMMABLE-BOUNDARY-END(68723081255)
            
            //--TRIMMABLE-BOUNDARY-START(73018048551)
            /*ValidationResult */ get ValidationResult()
            {
                return this._validationResult ??= new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2(this.Message);
            }
            //--TRIMMABLE-BOUNDARY-END(73018048551)
            
            //--TRIMMABLE-BOUNDARY-START(77313015847)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(77313015847)
            
            static $h = 3604519;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 80019457,
  "h": 3604519
}; }
            static get $b() { return $.$$.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(3604519)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Linq.Expressions", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.NetworkInformation", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter"))
//--TRIMMABLE-BOUNDARY-END(39)
