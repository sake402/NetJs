
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $srw, $srn, $ssc, $sris, $stc, $srsf, $scp, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $scs, $sdp, $sicb, $sci, $sdd, $sdts, $srm, $snnr, $sds, $sre, $sns, $sscr, $sle, $str, $snn, $snsc, $snq, $snh, $spx, $spxl, $sxxd, $sct) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel.Annotations", 
    {"h":38,"f":"System.ComponentModel.Annotations","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ComponentModel.Annotations","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ComponentModel.Annotations","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.IValidatableObject", ($self) => class IValidatableObject
        {
            static $h = 1507366;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h,"p":[{"n":"validationContext","p":3538982}],"n":"Validate","o":"System$ComponentModel$DataAnnotations$IValidatableObject$Validate","d":1507366,"h":4296474662,"f":257}],"h":1507366}; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.IValidatableObject`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationAttribute", ($self) => class ValidationAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _errorMessage = null;
            /*Func<string>?*/ _errorMessageResourceAccessor = null;
            /*string?*/ _errorMessageResourceName = null;
            /*Type?*/ _errorMessageResourceType = null;
            /*bool*/ _hasBaseIsValid = false;
            /*string?*/ _defaultErrorMessage = null;
            $ctor$2()
            {
                this.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.ValidationAttribute_ValidationError;
                }));
                {
                }
                return this;
            }
            $ctor$3(/*string*/ errorMessage)
            {
                this.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return errorMessage;
                }));
                {
                }
                return this;
            }
            $ctor$4(/*Func<string>*/ errorMessageAccessor)
            {
                super.$ctor$1();
                {
                    this._errorMessageResourceAccessor = errorMessageAccessor;
                }
                return this;
            }
            $ctor$5(/*bool*/ populateErrorMessageResourceAccessor)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(populateErrorMessageResourceAccessor === false, "Use the default constructor instead");
                }
                return this;
            }
            /*string? */ set DefaultErrorMessage(value)
            {
                this._defaultErrorMessage = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            /*Func<string> */ set ErrorMessageResourceAccessor(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._defaultErrorMessage === null && this._errorMessageResourceName === null && this._errorMessage === null && this._errorMessageResourceType === null, "_defaultErrorMessage is null && _errorMessageResourceName is null && _errorMessage is null && _errorMessageResourceType is null");
                this._errorMessageResourceAccessor = value;
            }
            /*string */ get ErrorMessageString()
            {
                this.SetupResourceAccessor();
                return this._errorMessageResourceAccessor.Invoke();
            }
            /*bool*/ CustomErrorMessageSet = false;
            /*bool */ get RequiresValidationContext()
            {
                return false;
            }
            /*string? */ get ErrorMessage()
            {
                return this._errorMessage ?? this._defaultErrorMessage;
            }
            /*string? */ set ErrorMessage(value)
            {
                this._errorMessage = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
                if ($.$spc.System.String.op_Equality(value, null))
                {
                    this._defaultErrorMessage = null;
                }
            }
            /*string? */ get ErrorMessageResourceName()
            {
                return this._errorMessageResourceName;
            }
            /*string? */ set ErrorMessageResourceName(value)
            {
                this._errorMessageResourceName = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            /*Type? */ get ErrorMessageResourceType()
            {
                return this._errorMessageResourceType;
            }
            /*Type? */ set ErrorMessageResourceType(value)
            {
                this._errorMessageResourceType = value;
                this._errorMessageResourceAccessor = null;
                this.CustomErrorMessageSet = true;
            }
            /*void */ SetupResourceAccessor()
            {
                if (this._errorMessageResourceAccessor === null)
                {
                    /*string?*/ let localErrorMessage = this.ErrorMessage;
                    /*bool*/ let resourceNameSet = !$.$spc.System.String.IsNullOrEmpty(this._errorMessageResourceName);
                    /*bool*/ let errorMessageSet = !$.$spc.System.String.IsNullOrEmpty(this._errorMessage);
                    /*bool*/ let resourceTypeSet = $.$spc.System.Type.op_Inequality$1(this._errorMessageResourceType, null);
                    /*bool*/ let defaultMessageSet = !$.$spc.System.String.IsNullOrEmpty(this._defaultErrorMessage);
                    if ((resourceNameSet && errorMessageSet) || !(resourceNameSet || errorMessageSet || defaultMessageSet))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.ValidationAttribute_Cannot_Set_ErrorMessage_And_Resource);
                    }
                    if (resourceTypeSet !== resourceNameSet)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.ValidationAttribute_NeedBothResourceTypeAndResourceName);
                    }
                    if (resourceNameSet)
                    {
                        this.SetResourceAccessorByPropertyLookup();
                    }
                    else 
                    {
                        this._errorMessageResourceAccessor = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                        {
                            return localErrorMessage;
                        });
                    }
                }
            }
            /*void */ SetResourceAccessorByPropertyLookup()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(this._errorMessageResourceType, null), "_errorMessageResourceType != null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.String.IsNullOrEmpty(this._errorMessageResourceName), "!string.IsNullOrEmpty(_errorMessageResourceName)");
                /*var*/ let property = this._errorMessageResourceType.GetProperty$1(this._errorMessageResourceName, 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/ | 2/*BindingFlags.DeclaredOnly*/);
                if ($.$spc.System.Reflection.PropertyInfo.op_Inequality$1(property, null))
                {
                    /*var*/ let propertyGetter = property.GetMethod;
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(propertyGetter, null) || (!propertyGetter.IsAssembly$1 && !propertyGetter.IsPublic$1))
                    {
                        property = null;
                    }
                }
                if ($.$spc.System.Reflection.PropertyInfo.op_Equality$1(property, null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.ValidationAttribute_ResourceTypeDoesNotHaveProperty, this._errorMessageResourceType.FullName, this._errorMessageResourceName));
                }
                if ($.$spc.System.Type.op_Inequality$1(property.PropertyType, $.$spc.System.String.$type))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.ValidationAttribute_ResourcePropertyNotStringType, property.Name, this._errorMessageResourceType.FullName));
                }
                this._errorMessageResourceAccessor = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$cast(property.GetValue$1(null, null), $.$spc.System.String);
                });
            }
            /*ValidationResult */ CreateFailedValidationResult(/*ValidationContext*/ validationContext)
            {
                let memberName;
                /*string[]?*/ let memberNames = validationContext.MemberName !== null && ((memberName = validationContext.MemberName, memberName != null && true)) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [memberName], null, null) : null;
                return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2(this.FormatErrorMessage(validationContext.DisplayName), memberNames);
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$5($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name);
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                if (!this._hasBaseIsValid)
                {
                    this._hasBaseIsValid = true;
                }
                return this.IsValid$1(value, null) === $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success;
            }
            /*ValidationResult? */ IsValid$1(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                if (this._hasBaseIsValid)
                {
                    throw $.$sca.System.NotImplemented.ByDesignWithMessage($.$sca.System.SR.ValidationAttribute_IsValid_NotImplemented);
                }
                return this.IsValid(value) ? $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success : this.CreateFailedValidationResult(validationContext);
            }
            /*ValidationResult? */ GetValidationResult(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                /*var*/ let result = this.IsValid$1(value, validationContext);
                if (result !== null)
                {
                    if ($.$spc.System.String.IsNullOrEmpty(result.ErrorMessage))
                    {
                        /*var*/ let errorMessage = this.FormatErrorMessage(validationContext.DisplayName);
                        result = new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2(errorMessage, result.MemberNames);
                    }
                }
                return result;
            }
            /*void */ Validate(/*object?*/ value, /*string*/ name)
            {
                if (!this.IsValid(value))
                {
                    throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$6(this.FormatErrorMessage(name), this, value);
                }
            }
            /*void */ Validate$1(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                /*ValidationResult?*/ let result = this.GetValidationResult(value, validationContext);
                if (result !== null)
                {
                    throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$5(result, this, value);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.CustomErrorMessageSet = false;
            }
            static $h = 3211302;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"s":{"r":0,"d":0,"h":51542818854},"n":"DefaultErrorMessage","d":3211302,"h":47247851558},{"p":$.$spc.System.Func$$($.$spc.System.String).$h,"s":{"r":0,"d":0,"h":60132753446},"n":"ErrorMessageResourceAccessor","d":3211302,"h":55837786150},{"p":1310721,"g":{"r":0,"d":0,"h":68722688038,"f":4},"n":"ErrorMessageString","d":3211302,"h":64427720742,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":81607589926,"f":8},"s":{"r":0,"d":0,"h":85902557222,"f":2},"n":"CustomErrorMessageSet","d":3211302,"h":77312622630,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":94492491814,"f":129},"n":"RequiresValidationContext","d":3211302,"h":90197524518,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":103082426406,"f":1},"s":{"r":0,"d":0,"h":107377393702,"f":1},"n":"ErrorMessage","d":3211302,"h":98787459110,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":115967328294,"f":1},"s":{"r":0,"d":0,"h":120262295590,"f":1},"n":"ErrorMessageResourceName","d":3211302,"h":111672360998,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":128852230182,"f":1},"s":{"r":0,"d":0,"h":133147197478,"f":1},"n":"ErrorMessageResourceType","d":3211302,"h":124557262886,"f":1}],"m":[{"r":65537,"n":"SetupResourceAccessor","d":3211302,"h":137442164774,"f":2},{"r":65537,"n":"SetResourceAccessorByPropertyLookup","d":3211302,"h":141737132070,"f":2},{"r":3670054,"p":[{"n":"validationContext","p":3538982}],"n":"CreateFailedValidationResult","d":3211302,"h":146032099366},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":3211302,"h":150327066662,"f":129},{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":3211302,"h":154622033958,"f":129},{"r":3670054,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"IsValid","o":"@$1","d":3211302,"h":158917001254,"f":132},{"r":3670054,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"GetValidationResult","d":3211302,"h":163211968550,"f":1},{"r":65537,"p":[{"n":"value","p":131073},{"n":"name","p":1310721}],"n":"Validate","d":3211302,"h":167506935846,"f":1},{"r":65537,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"Validate","o":"@$1","d":3211302,"h":171801903142,"f":1}],"l":[{"t":1310721,"n":"_errorMessage","d":3211302,"h":4298178598,"f":2},{"t":$.$spc.System.Func$$($.$spc.System.String).$h,"n":"_errorMessageResourceAccessor","d":3211302,"h":8593145894,"f":2},{"t":1310721,"n":"_errorMessageResourceName","d":3211302,"h":12888113190,"f":2},{"t":142606337,"n":"_errorMessageResourceType","d":3211302,"h":17183080486,"f":2},{"t":262145,"n":"_hasBaseIsValid","d":3211302,"h":21478047782,"f":2},{"t":1310721,"n":"_defaultErrorMessage","d":3211302,"h":25773015078,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":3211302,"h":30067982374,"f":4},{"p":[{"n":"errorMessage","p":1310721}],"n":".ctor","o":"$ctor$3","d":3211302,"h":34362949670,"f":4},{"p":[{"n":"errorMessageAccessor","p":$.$spc.System.Func$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":3211302,"h":38657916966,"f":4},{"p":[{"n":"populateErrorMessageResourceAccessor","p":262145}],"n":".ctor","o":"$ctor$5","d":3211302,"h":42952884262}],"h":3211302}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttribute`; }
        });
        
        $asm.$cls("$sca.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sca.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.ComponentModel.Annotations", $.$sca.System.SR.$type.Assembly);
                    $.$sca.System.SR.s_resourceManager = temp;
                }
                return $.$sca.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sca.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sca.System.SR.resourceCulture = value;
            }
            static /*string */ get AllowedValuesAttribute_Invalid()
            {
                return "The {0} field does not equal any of the values specified in AllowedValuesAttribute.";
            }
            static /*string */ FormatAllowedValuesAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field does not equal any of the values specified in AllowedValuesAttribute.", arg1);
            }
            static /*string */ get AssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties()
            {
                return "The associated metadata type for type '{0}' contains the following unknown properties or fields: {1}. Please make sure that the names of these members match the names of the properties on the main type.";
            }
            static /*string */ FormatAssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The associated metadata type for type '{0}' contains the following unknown properties or fields: {1}. Please make sure that the names of these members match the names of the properties on the main type.", arg1, arg2);
            }
            static /*string */ get AttributeStore_Unknown_Property()
            {
                return "The type '{0}' does not contain a public property named '{1}'.";
            }
            static /*string */ FormatAttributeStore_Unknown_Property(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The type '{0}' does not contain a public property named '{1}'.", arg1, arg2);
            }
            static /*string */ get Base64StringAttribute_Invalid()
            {
                return "The {0} field is not a valid Base64 encoding.";
            }
            static /*string */ FormatBase64StringAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is not a valid Base64 encoding.", arg1);
            }
            static /*string */ get Common_PropertyNotFound()
            {
                return "The property {0}.{1} could not be found.";
            }
            static /*string */ FormatCommon_PropertyNotFound(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The property {0}.{1} could not be found.", arg1, arg2);
            }
            static /*string */ get CompareAttribute_MustMatch()
            {
                return "'{0}' and '{1}' do not match.";
            }
            static /*string */ FormatCompareAttribute_MustMatch(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("'{0}' and '{1}' do not match.", arg1, arg2);
            }
            static /*string */ get CompareAttribute_UnknownProperty()
            {
                return "Could not find a property named {0}.";
            }
            static /*string */ FormatCompareAttribute_UnknownProperty(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a property named {0}.", arg1);
            }
            static /*string */ get CreditCardAttribute_Invalid()
            {
                return "The {0} field is not a valid credit card number.";
            }
            static /*string */ FormatCreditCardAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is not a valid credit card number.", arg1);
            }
            static /*string */ get CustomValidationAttribute_Method_Must_Return_ValidationResult()
            {
                return "The CustomValidationAttribute method '{0}' in type '{1}' must return System.ComponentModel.DataAnnotations.ValidationResult.  Use System.ComponentModel.DataAnnotations.ValidationResult.Success to represent success.";
            }
            static /*string */ FormatCustomValidationAttribute_Method_Must_Return_ValidationResult(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The CustomValidationAttribute method '{0}' in type '{1}' must return System.ComponentModel.DataAnnotations.ValidationResult.  Use System.ComponentModel.DataAnnotations.ValidationResult.Success to represent success.", arg1, arg2);
            }
            static /*string */ get CustomValidationAttribute_Method_Not_Found()
            {
                return "The CustomValidationAttribute method '{0}' does not exist in type '{1}' or is not public and static.";
            }
            static /*string */ FormatCustomValidationAttribute_Method_Not_Found(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The CustomValidationAttribute method '{0}' does not exist in type '{1}' or is not public and static.", arg1, arg2);
            }
            static /*string */ get CustomValidationAttribute_Method_Required()
            {
                return "The CustomValidationAttribute.Method was not specified.";
            }
            static /*string */ get CustomValidationAttribute_Method_Signature()
            {
                return "The CustomValidationAttribute method '{0}' in type '{1}' must match the expected signature: public static ValidationResult {0}(object value, ValidationContext context).  The value can be strongly typed.  The ValidationContext parameter is optional.";
            }
            static /*string */ FormatCustomValidationAttribute_Method_Signature(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The CustomValidationAttribute method '{0}' in type '{1}' must match the expected signature: public static ValidationResult {0}(object value, ValidationContext context).  The value can be strongly typed.  The ValidationContext parameter is optional.", arg1, arg2, arg3);
            }
            static /*string */ get CustomValidationAttribute_Type_Conversion_Failed()
            {
                return "Could not convert the value of type '{0}' to '{1}' as expected by method {2}.{3}.";
            }
            static /*string */ FormatCustomValidationAttribute_Type_Conversion_Failed(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4)
            {
                return $.$spc.System.String.Format$4("Could not convert the value of type '{0}' to '{1}' as expected by method {2}.{3}.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4 ]));
            }
            static /*string */ get CustomValidationAttribute_Type_Must_Be_Public()
            {
                return "The custom validation type '{0}' must be public.";
            }
            static /*string */ FormatCustomValidationAttribute_Type_Must_Be_Public(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The custom validation type '{0}' must be public.", arg1);
            }
            static /*string */ get CustomValidationAttribute_ValidationError()
            {
                return "{0} is not valid.";
            }
            static /*string */ FormatCustomValidationAttribute_ValidationError(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0} is not valid.", arg1);
            }
            static /*string */ get CustomValidationAttribute_ValidatorType_Required()
            {
                return "The CustomValidationAttribute.ValidatorType was not specified.";
            }
            static /*string */ get DataTypeAttribute_EmptyDataTypeString()
            {
                return "The custom DataType string cannot be null or empty.";
            }
            static /*string */ get DeniedValuesAttribute_Invalid()
            {
                return "The {0} field equals one of the values specified in DeniedValuesAttribute.";
            }
            static /*string */ FormatDeniedValuesAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field equals one of the values specified in DeniedValuesAttribute.", arg1);
            }
            static /*string */ get DisplayAttribute_PropertyNotSet()
            {
                return "The {0} property has not been set.  Use the {1} method to get the value.";
            }
            static /*string */ FormatDisplayAttribute_PropertyNotSet(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The {0} property has not been set.  Use the {1} method to get the value.", arg1, arg2);
            }
            static /*string */ get EmailAddressAttribute_Invalid()
            {
                return "The {0} field is not a valid e-mail address.";
            }
            static /*string */ FormatEmailAddressAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is not a valid e-mail address.", arg1);
            }
            static /*string */ get EnumDataTypeAttribute_TypeCannotBeNull()
            {
                return "The type provided for EnumDataTypeAttribute cannot be null.";
            }
            static /*string */ get EnumDataTypeAttribute_TypeNeedsToBeAnEnum()
            {
                return "The type '{0}' needs to represent an enumeration type.";
            }
            static /*string */ FormatEnumDataTypeAttribute_TypeNeedsToBeAnEnum(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The type '{0}' needs to represent an enumeration type.", arg1);
            }
            static /*string */ get FileExtensionsAttribute_Invalid()
            {
                return "The {0} field only accepts files with the following extensions: {1}";
            }
            static /*string */ FormatFileExtensionsAttribute_Invalid(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The {0} field only accepts files with the following extensions: {1}", arg1, arg2);
            }
            static /*string */ get LocalizableString_LocalizationFailed()
            {
                return "Cannot retrieve property '{0}' because localization failed.  Type '{1}' is not public or does not contain a public static string property with the name '{2}'.";
            }
            static /*string */ FormatLocalizableString_LocalizationFailed(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Cannot retrieve property '{0}' because localization failed.  Type '{1}' is not public or does not contain a public static string property with the name '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get MaxLengthAttribute_InvalidMaxLength()
            {
                return "MaxLengthAttribute must have a Length value that is greater than zero. Use MaxLength() without parameters to indicate that the string or array can have the maximum allowable length.";
            }
            static /*string */ get MaxLengthAttribute_ValidationError()
            {
                return "The field {0} must be a string or array type with a maximum length of '{1}'.";
            }
            static /*string */ FormatMaxLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The field {0} must be a string or array type with a maximum length of '{1}'.", arg1, arg2);
            }
            static /*string */ get MetadataTypeAttribute_TypeCannotBeNull()
            {
                return "MetadataClassType cannot be null.";
            }
            static /*string */ get MinLengthAttribute_InvalidMinLength()
            {
                return "MinLengthAttribute must have a Length value that is zero or greater.";
            }
            static /*string */ get MinLengthAttribute_ValidationError()
            {
                return "The field {0} must be a string or array type with a minimum length of '{1}'.";
            }
            static /*string */ FormatMinLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The field {0} must be a string or array type with a minimum length of '{1}'.", arg1, arg2);
            }
            static /*string */ get LengthAttribute_InvalidMinLength()
            {
                return "LengthAttribute must have a MinimumLength value that is zero or greater.";
            }
            static /*string */ get LengthAttribute_InvalidMaxLength()
            {
                return "LengthAttribute must have a MaximumLength value that is greater than or equal to MinimumLength.";
            }
            static /*string */ get LengthAttribute_ValidationError()
            {
                return "The field {0} must be a string or collection type with a minimum length of '{1}' and maximum length of '{2}'.";
            }
            static /*string */ FormatLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be a string or collection type with a minimum length of '{1}' and maximum length of '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get LengthAttribute_InvalidValueType()
            {
                return "The field of type {0} must be a string, array or ICollection type.";
            }
            static /*string */ FormatLengthAttribute_InvalidValueType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The field of type {0} must be a string, array or ICollection type.", arg1);
            }
            static /*string */ get PhoneAttribute_Invalid()
            {
                return "The {0} field is not a valid phone number.";
            }
            static /*string */ FormatPhoneAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is not a valid phone number.", arg1);
            }
            static /*string */ get RangeAttribute_ArbitraryTypeNotIComparable()
            {
                return "The type {0} must implement {1}.";
            }
            static /*string */ FormatRangeAttribute_ArbitraryTypeNotIComparable(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The type {0} must implement {1}.", arg1, arg2);
            }
            static /*string */ get RangeAttribute_MinGreaterThanMax()
            {
                return "The maximum value '{0}' must be greater than or equal to the minimum value '{1}'.";
            }
            static /*string */ FormatRangeAttribute_MinGreaterThanMax(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The maximum value '{0}' must be greater than or equal to the minimum value '{1}'.", arg1, arg2);
            }
            static /*string */ get RangeAttribute_CannotUseExclusiveBoundsWhenTheyAreEqual()
            {
                return "Cannot use exclusive bounds when the maximum value is equal to the minimum value.";
            }
            static /*string */ get RangeAttribute_Must_Set_Min_And_Max()
            {
                return "The minimum and maximum values must be set.";
            }
            static /*string */ get RangeAttribute_Must_Set_Operand_Type()
            {
                return "The OperandType must be set when strings are used for minimum and maximum values.";
            }
            static /*string */ get RangeAttribute_ValidationError()
            {
                return "The field {0} must be between {1} and {2}.";
            }
            static /*string */ FormatRangeAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be between {1} and {2}.", arg1, arg2, arg3);
            }
            static /*string */ get RangeAttribute_ValidationError_MinExclusive()
            {
                return "The field {0} must be between {1} exclusive and {2}.";
            }
            static /*string */ FormatRangeAttribute_ValidationError_MinExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be between {1} exclusive and {2}.", arg1, arg2, arg3);
            }
            static /*string */ get RangeAttribute_ValidationError_MaxExclusive()
            {
                return "The field {0} must be between {1} and {2} exclusive.";
            }
            static /*string */ FormatRangeAttribute_ValidationError_MaxExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be between {1} and {2} exclusive.", arg1, arg2, arg3);
            }
            static /*string */ get RangeAttribute_ValidationError_MinExclusive_MaxExclusive()
            {
                return "The field {0} must be between {1} exclusive and {2} exclusive.";
            }
            static /*string */ FormatRangeAttribute_ValidationError_MinExclusive_MaxExclusive(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be between {1} exclusive and {2} exclusive.", arg1, arg2, arg3);
            }
            static /*string */ get RegexAttribute_ValidationError()
            {
                return "The field {0} must match the regular expression '{1}'.";
            }
            static /*string */ FormatRegexAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The field {0} must match the regular expression '{1}'.", arg1, arg2);
            }
            static /*string */ get RegularExpressionAttribute_Empty_Pattern()
            {
                return "The pattern must be set to a valid regular expression.";
            }
            static /*string */ get RequiredAttribute_ValidationError()
            {
                return "The {0} field is required.";
            }
            static /*string */ FormatRequiredAttribute_ValidationError(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is required.", arg1);
            }
            static /*string */ get StringLengthAttribute_InvalidMaxLength()
            {
                return "The maximum length must be a nonnegative integer.";
            }
            static /*string */ get StringLengthAttribute_ValidationError()
            {
                return "The field {0} must be a string with a maximum length of {1}.";
            }
            static /*string */ FormatStringLengthAttribute_ValidationError(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The field {0} must be a string with a maximum length of {1}.", arg1, arg2);
            }
            static /*string */ get StringLengthAttribute_ValidationErrorIncludingMinimum()
            {
                return "The field {0} must be a string with a minimum length of {2} and a maximum length of {1}.";
            }
            static /*string */ FormatStringLengthAttribute_ValidationErrorIncludingMinimum(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("The field {0} must be a string with a minimum length of {2} and a maximum length of {1}.", arg1, arg2, arg3);
            }
            static /*string */ get UIHintImplementation_ControlParameterKeyIsNotAString()
            {
                return "The key parameter at position {0} with value '{1}' is not a string. Every key control parameter must be a string.";
            }
            static /*string */ FormatUIHintImplementation_ControlParameterKeyIsNotAString(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The key parameter at position {0} with value '{1}' is not a string. Every key control parameter must be a string.", arg1, arg2);
            }
            static /*string */ get UIHintImplementation_ControlParameterKeyIsNull()
            {
                return "The key parameter at position {0} is null. Every key control parameter must be a string.";
            }
            static /*string */ FormatUIHintImplementation_ControlParameterKeyIsNull(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The key parameter at position {0} is null. Every key control parameter must be a string.", arg1);
            }
            static /*string */ get UIHintImplementation_ControlParameterKeyOccursMoreThanOnce()
            {
                return "The key parameter at position {0} with value '{1}' occurs more than once.";
            }
            static /*string */ FormatUIHintImplementation_ControlParameterKeyOccursMoreThanOnce(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The key parameter at position {0} with value '{1}' occurs more than once.", arg1, arg2);
            }
            static /*string */ get UIHintImplementation_NeedEvenNumberOfControlParameters()
            {
                return "The number of control parameters must be even.";
            }
            static /*string */ get UrlAttribute_Invalid()
            {
                return "The {0} field is not a valid fully-qualified http, https, or ftp URL.";
            }
            static /*string */ FormatUrlAttribute_Invalid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The {0} field is not a valid fully-qualified http, https, or ftp URL.", arg1);
            }
            static /*string */ get ValidationAttribute_Cannot_Set_ErrorMessage_And_Resource()
            {
                return "Either ErrorMessageString or ErrorMessageResourceName must be set, but not both.";
            }
            static /*string */ get ValidationAttribute_IsValid_NotImplemented()
            {
                return "IsValid(object value) has not been implemented by this class.  The preferred entry point is GetValidationResult() and classes should override IsValid(object value, ValidationContext context).";
            }
            static /*string */ get ValidationAttribute_NeedBothResourceTypeAndResourceName()
            {
                return "Both ErrorMessageResourceType and ErrorMessageResourceName need to be set on this attribute.";
            }
            static /*string */ get ValidationAttribute_ResourcePropertyNotStringType()
            {
                return "The property '{0}' on resource type '{1}' is not a string type.";
            }
            static /*string */ FormatValidationAttribute_ResourcePropertyNotStringType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The property '{0}' on resource type '{1}' is not a string type.", arg1, arg2);
            }
            static /*string */ get ValidationAttribute_ResourceTypeDoesNotHaveProperty()
            {
                return "The resource type '{0}' does not have an accessible static property named '{1}'.";
            }
            static /*string */ FormatValidationAttribute_ResourceTypeDoesNotHaveProperty(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The resource type '{0}' does not have an accessible static property named '{1}'.", arg1, arg2);
            }
            static /*string */ get ValidationAttribute_ValidationError()
            {
                return "The field {0} is invalid.";
            }
            static /*string */ FormatValidationAttribute_ValidationError(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The field {0} is invalid.", arg1);
            }
            static /*string */ get Validator_InstanceMustMatchValidationContextInstance()
            {
                return "The instance provided must match the ObjectInstance on the ValidationContext supplied.";
            }
            static /*string */ get Validator_Property_Value_Wrong_Type()
            {
                return "The value for property '{0}' must be of type '{1}'.";
            }
            static /*string */ FormatValidator_Property_Value_Wrong_Type(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The value for property '{0}' must be of type '{1}'.", arg1, arg2);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sca.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sca.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sca.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sca.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sca.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sca.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 3997734;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3997734}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.LocalizableString", ($self) => class LocalizableString extends $.$spc.System.Object
        {
            /*string*/ _propertyName = null;
            /*Func<string?>?*/ _cachedResult = null;
            /*string?*/ _propertyValue = null;
            /*Type?*/ _resourceType = null;
            $ctor$1(/*string*/ propertyName)
            {
                super.$ctor();
                {
                    this._propertyName = propertyName;
                }
                return this;
            }
            /*string? */ get Value()
            {
                return this._propertyValue;
            }
            /*string? */ set Value(value)
            {
                if ($.$spc.System.String.op_Inequality(this._propertyValue, value))
                {
                    this.ClearCache();
                    this._propertyValue = value;
                }
            }
            /*Type? */ get ResourceType()
            {
                return this._resourceType;
            }
            /*Type? */ set ResourceType(value)
            {
                if ($.$spc.System.Type.op_Inequality$1(this._resourceType, value))
                {
                    this.ClearCache();
                    this._resourceType = value;
                }
            }
            /*void */ ClearCache()
            {
                this._cachedResult = null;
            }
            /*string? */ GetLocalizableValue()
            {
                if (this._cachedResult === null)
                {
                    if ($.$spc.System.String.op_Equality(this._propertyValue, null) || $.$spc.System.Type.op_Equality$1(this._resourceType, null))
                    {
                        this._cachedResult = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                        {
                            return this._propertyValue;
                        });
                    }
                    else 
                    {
                        /*var*/ let property = $.$spc.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty(this._resourceType, this._propertyValue);
                        /*var*/ let badlyConfigured = false;
                        if ($.$spc.System.Reflection.PropertyInfo.op_Equality$1(property, null) || $.$spc.System.Type.op_Inequality$1(property.PropertyType, $.$spc.System.String.$type))
                        {
                            badlyConfigured = true;
                        }
                        else 
                        {
                            /*var*/ let getter = property.GetMethod;
                            if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(getter, null) || !(getter.IsPublic$1 && getter.IsStatic$1))
                            {
                                badlyConfigured = true;
                            }
                        }
                        if (badlyConfigured)
                        {
                            /*string*/ let exceptionMessage = $.$sca.System.SR.Format$2($.$sca.System.SR.LocalizableString_LocalizationFailed, this._propertyName, this._resourceType.FullName, this._propertyValue);
                            this._cachedResult = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10(exceptionMessage);
                            });
                        }
                        else 
                        {
                            this._cachedResult = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                            {
                                return $.$cast(property.GetValue$1(null, null), $.$spc.System.String);
                            });
                        }
                    }
                }
                return this._cachedResult.Invoke();
            }
            static $h = 1703974;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30066475046,"f":1},"s":{"r":0,"d":0,"h":34361442342,"f":1},"n":"Value","d":1703974,"h":25771507750,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":42951376934,"f":1},"s":{"r":0,"d":0,"h":47246344230,"f":1},"n":"ResourceType","d":1703974,"h":38656409638,"f":1}],"m":[{"r":65537,"n":"ClearCache","d":1703974,"h":51541311526,"f":2},{"r":1310721,"n":"GetLocalizableValue","d":1703974,"h":55836278822,"f":1}],"l":[{"t":1310721,"n":"_propertyName","d":1703974,"h":4296671270,"f":2},{"t":$.$spc.System.Func$$($.$spc.System.String).$h,"n":"_cachedResult","d":1703974,"h":8591638566,"f":2},{"t":1310721,"n":"_propertyValue","d":1703974,"h":12886605862,"f":2},{"t":142606337,"n":"_resourceType","d":1703974,"h":17181573158,"f":2}],"c":[{"p":[{"n":"propertyName","p":1310721}],"n":".ctor","o":"$ctor$1","d":1703974,"h":21476540454,"f":1}],"h":1703974}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.LocalizableString`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationResult", ($self) => class ValidationResult extends $.$spc.System.Object
        {
            /*ValidationResult?*/ static Success = null;
            $ctor$1(/*string?*/ errorMessage)
            {
                this.$ctor$2(errorMessage, null);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ errorMessage, /*IEnumerable<string>?*/ memberNames)
            {
                super.$ctor();
                {
                    this.ErrorMessage = errorMessage;
                    this.MemberNames = memberNames ?? $.$spc.System.Array.Empty($.$spc.System.String);
                }
                return this;
            }
            $ctor$3(/*ValidationResult*/ validationResult)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(validationResult, "validationResult");
                    this.ErrorMessage = validationResult.ErrorMessage;
                    this.MemberNames = validationResult.MemberNames;
                }
                return this;
            }
            /*IEnumerable<string>*/ MemberNames = null;
            /*string?*/ ErrorMessage = null;
            static/*conventional*/ /*string */ ToString()
            {
                return this.ErrorMessage ?? $.$spc.System.Object.ToString.call(this);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.ToString.apply(this, arguments); }
            static $h = 3670054;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":30068441126,"f":1},"n":"MemberNames","d":3670054,"h":25773473830,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42953343014,"f":1},"s":{"r":0,"d":0,"h":47248310310,"f":1},"n":"ErrorMessage","d":3670054,"h":38658375718,"f":1}],"m":[{"r":1310721,"n":"ToString","d":3670054,"h":51543277606,"f":32769}],"l":[{"t":3670054,"n":"Success","d":3670054,"h":4298637350,"f":33}],"c":[{"p":[{"n":"errorMessage","p":1310721}],"n":".ctor","o":"$ctor$1","d":3670054,"h":8593604646,"f":1},{"p":[{"n":"errorMessage","p":1310721},{"n":"memberNames","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$2","d":3670054,"h":12888571942,"f":1},{"p":[{"n":"validationResult","p":3670054}],"n":".ctor","o":"$ctor$3","d":3670054,"h":17183539238,"f":4}],"h":3670054}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationResult`; }
        });
        
        $asm.$cls("$sca.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 3932198;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":3932198,"h":4298899494,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":3932198,"h":8593866790,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":3932198,"h":12888834086,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":3932198,"h":17183801382,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":3932198,"h":21478768678,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":3932198,"h":25773735974,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":3932198,"h":30068703270,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":3932198,"h":34363670566,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":3932198,"h":38658637862,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":3932198,"h":42953605158,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":3932198,"h":47248572454,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":3932198,"h":51543539750,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":3932198,"h":55838507046,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":3932198,"h":60133474342,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":3932198,"h":64428441638,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":3932198,"h":68723408934,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":3932198,"h":73018376230,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":3932198,"h":77313343526,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":3932198,"h":81608310822,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":3932198,"h":85903278118,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":3932198,"h":90198245414,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":3932198,"h":94493212710,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":3932198,"h":98788180006,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":3932198,"h":103083147302,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":3932198,"h":107378114598,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":3932198,"h":111673081894,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":3932198,"h":115968049190,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":3932198,"h":120263016486,"f":40},{"t":1310721,"n":"WebRequestMessage","d":3932198,"h":124557983782,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":3932198,"h":128852951078,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":3932198,"h":133147918374,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":3932198,"h":137442885670,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":3932198,"h":141737852966,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":3932198,"h":146032820262,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":3932198,"h":150327787558,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":3932198,"h":154622754854,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":3932198,"h":158917722150,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":3932198,"h":163212689446,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":3932198,"h":167507656742,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":3932198,"h":171802624038,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":3932198,"h":176097591334,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":3932198,"h":180392558630,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":3932198,"h":184687525926,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":3932198,"h":188982493222,"f":40},{"t":1310721,"n":"RijndaelMessage","d":3932198,"h":193277460518,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":3932198,"h":197572427814,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":3932198,"h":201867395110,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":3932198,"h":206162362406,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":3932198,"h":210457329702,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":3932198,"h":214752296998,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":3932198,"h":219047264294,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":3932198,"h":223342231590,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":3932198,"h":227637198886,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":3932198,"h":231932166182,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":3932198,"h":236227133478,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":3932198,"h":240522100774,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":3932198,"h":244817068070,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":3932198,"h":249112035366,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":3932198,"h":253407002662,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":3932198,"h":257701969958,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":3932198,"h":261996937254,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":3932198,"h":266291904550,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":3932198,"h":270586871846,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":3932198,"h":274881839142,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":3932198,"h":279176806438,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":3932198,"h":283471773734,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":3932198,"h":287766741030,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":3932198,"h":292061708326,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":3932198,"h":296356675622,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":3932198,"h":300651642918,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":3932198,"h":304946610214,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":3932198,"h":309241577510,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":3932198,"h":313536544806,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":3932198,"h":317831512102,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":3932198,"h":322126479398,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":3932198,"h":326421446694,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":3932198,"h":330716413990,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":3932198,"h":335011381286,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":3932198,"h":339306348582,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":3932198,"h":343601315878,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":3932198,"h":347896283174,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":3932198,"h":352191250470,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":3932198,"h":356486217766,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":3932198,"h":360781185062,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":3932198,"h":365076152358,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":3932198,"h":369371119654,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":3932198,"h":373666086950,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":3932198,"h":377961054246,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":3932198,"h":382256021542,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":3932198,"h":386550988838,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":3932198,"h":390845956134,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":3932198,"h":395140923430,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":3932198,"h":399435890726,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":3932198,"h":403730858022,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":3932198,"h":408025825318,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":3932198,"h":412320792614,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":3932198,"h":416615759910,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":3932198,"h":420910727206,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":3932198,"h":425205694502,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":3932198,"h":429500661798,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":3932198,"h":433795629094,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":3932198,"h":438090596390,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":3932198,"h":442385563686,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":3932198,"h":446680530982,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":3932198,"h":450975498278,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":3932198,"h":455270465574,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":3932198,"h":459565432870,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":3932198,"h":463860400166,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":3932198,"h":468155367462,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":3932198,"h":472450334758,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":3932198,"h":476745302054,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":3932198,"h":481040269350,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":3932198,"h":485335236646,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":3932198,"h":489630203942,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":3932198,"h":493925171238,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":3932198,"h":498220138534,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":3932198,"h":502515105830,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":3932198,"h":506810073126,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":3932198,"h":511105040422,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":3932198,"h":515400007718,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":3932198,"h":519694975014,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":3932198,"h":523989942310,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":3932198,"h":528284909606,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":3932198,"h":532579876902,"f":40}],"h":3932198}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper", ($self) => class CountPropertyHelper
        {
            /*string*/ static RequiresUnreferencedCodeMessage = null;
            static /*bool */ TryGetCount(/*object*/ value, /*out int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value !== null, "value != null");
                let collection;
                if ($.$is(value, $.$spc.System.Collections.ICollection, { set $v(v){ collection = v; } }))
                {
                    count.$v = collection.System$Collections$ICollection$Count;
                    return true;
                }
                /*PropertyInfo?*/ let property = $.$spc.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty($.$spc.System.Object.GetType.call(value), "Count");
                if ($.$spc.System.Reflection.PropertyInfo.op_Inequality$1(property, null) && property.CanRead && $.$spc.System.Type.op_Equality$1(property.PropertyType, $.$spc.System.Int32.$type))
                {
                    count.$v = $.$cast(property.GetValue(value), $.$spc.System.Int32);
                    return true;
                }
                count.$v = -1;
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.RequiresUnreferencedCodeMessage = "Uses reflection to get the 'Count' property on types that don't implement ICollection. This 'Count' property may be trimmed. Ensure it is preserved.";
                }
            }
            static $h = 589862;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"value","p":131073},{"n":"count","p":655361,"f":2}],"n":"TryGetCount","d":589862,"h":8590524454,"f":33}],"l":[{"t":1310721,"n":"RequiresUnreferencedCodeMessage","d":589862,"h":4295557158,"f":40}],"h":589862}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CountPropertyHelper`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Validator", ($self) => class Validator
        {
            /*ValidationAttributeStore*/ static _store = null;
            static /*bool */ TryValidateProperty(/*object?*/ value, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults)
            {
                /*var*/ let propertyType = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyType(validationContext);
                /*var*/ let propertyName = validationContext.MemberName;
                $.$sca.System.ComponentModel.DataAnnotations.Validator.EnsureValidPropertyType(propertyName, propertyType, value);
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = (validationResults === null);
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(validationContext);
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, attributes, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            static /*bool */ TryValidateObject(/*object*/ instance, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults)
            {
                return $.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidateObject$1(instance, validationContext, validationResults, false);
            }
            static /*bool */ TryValidateObject$1(/*object*/ instance, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults, /*bool*/ validateAllProperties)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(instance, "instance");
                if (validationContext !== null && instance !== validationContext.ObjectInstance)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sca.System.SR.Validator_InstanceMustMatchValidationContextInstance, "instance");
                }
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = (validationResults === null);
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectValidationErrors(instance, validationContext, validateAllProperties, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            static /*bool */ TryValidateValue(/*object?*/ value, /*ValidationContext*/ validationContext, /*ICollection<ValidationResult>?*/ validationResults, /*IEnumerable<ValidationAttribute>*/ validationAttributes)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationAttributes, "validationAttributes");
                /*var*/ let result = true;
                /*var*/ let breakOnFirstError = validationResults === null;
                var $en2 = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, validationAttributes, breakOnFirstError).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var err = $en2.Current;
                    {
                        result = false;
                        validationResults?.System$Collections$Generic$ICollection$$$Add(err.ValidationResult, [$.$sca.System.ComponentModel.DataAnnotations.ValidationResult]);
                    }
                }
                return result;
            }
            static /*void */ ValidateProperty(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                /*var*/ let propertyType = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyType(validationContext);
                $.$sca.System.ComponentModel.DataAnnotations.Validator.EnsureValidPropertyType(validationContext.MemberName, propertyType, value);
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(validationContext);
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, attributes, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            static /*void */ ValidateObject(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidateObject$1(instance, validationContext, false);
            }
            static /*void */ ValidateObject$1(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(instance, "instance");
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                if (instance !== validationContext.ObjectInstance)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sca.System.SR.Validator_InstanceMustMatchValidationContextInstance, "instance");
                }
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectValidationErrors(instance, validationContext, validateAllProperties, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            static /*void */ ValidateValue(/*object?*/ value, /*ValidationContext*/ validationContext, /*IEnumerable<ValidationAttribute>*/ validationAttributes)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationAttributes, "validationAttributes");
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(value, validationContext, validationAttributes, false);
                if (errors.Count > 0)
                {
                    errors.get_Item(0).ThrowValidationException();
                }
            }
            static /*ValidationContext */ CreateValidationContext(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(validationContext !== null, "validationContext != null");
                /*var*/ let context = new $.$sca.System.ComponentModel.DataAnnotations.ValidationContext().$ctor$3(instance, validationContext, validationContext.Items);
                return context;
            }
            static /*bool */ CanBeAssigned(/*Type*/ destinationType, /*object?*/ value)
            {
                if (value === null)
                {
                    return !destinationType.IsValueType || (destinationType.IsGenericType && $.$spc.System.Type.op_Equality$1(destinationType.GetGenericTypeDefinition(), $.$spc.System.Nullable$$().$type));
                }
                return destinationType.IsInstanceOfType(value);
            }
            static /*void */ EnsureValidPropertyType(/*string*/ propertyName, /*Type*/ propertyType, /*object?*/ value)
            {
                if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.CanBeAssigned(propertyType, value))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sca.System.SR.Format$1($.$sca.System.SR.Validator_Property_Value_Wrong_Type, propertyName, propertyType), "value");
                }
            }
            static /*List<ValidationError> */ GetObjectValidationErrors(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties, /*bool*/ breakOnFirstError)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                $.$spc.System.Diagnostics.Debug.Assert$1(instance !== null, "instance != null");
                /*List<ValidationError>*/ let errors = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetObjectPropertyValidationErrors(instance, validationContext, validateAllProperties, breakOnFirstError);
                if (errors.Count > 0)
                {
                    return errors;
                }
                /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetTypeValidationAttributes(validationContext);
                errors.AddRange($.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(instance, validationContext, attributes, breakOnFirstError));
                if (errors.Count > 0)
                {
                    return errors;
                }
                let validatable;
                if ($.$is(instance, $.$sca.System.ComponentModel.DataAnnotations.IValidatableObject, { set $v(v){ validatable = v; } }))
                {
                    /*var*/ let results = validatable.System$ComponentModel$DataAnnotations$IValidatableObject$Validate(validationContext);
                    if (results !== null)
                    {
                        var $en4 = results.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var result = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (result !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                                {
                                    errors.Add(new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(null, instance, result));
                                }
                            }
                        }
                    }
                }
                return errors;
            }
            static /*List<ValidationError> */ GetObjectPropertyValidationErrors(/*object*/ instance, /*ValidationContext*/ validationContext, /*bool*/ validateAllProperties, /*bool*/ breakOnFirstError)
            {
                /*var*/ let properties = $.$sca.System.ComponentModel.DataAnnotations.Validator.GetPropertyValues(instance, validationContext);
                /*var*/ let errors = new ($.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError))().$ctor$1();
                var $en2 = properties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        /*var*/ let attributes = $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(property.Key);
                        if (validateAllProperties)
                        {
                            errors.AddRange($.$sca.System.ComponentModel.DataAnnotations.Validator.GetValidationErrors(property.Value, property.Key, attributes, breakOnFirstError));
                        }
                        else 
                        {
                            var $en5 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var attribute = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    let reqAttr;
                                    if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute, { set $v(v){ reqAttr = v; } }))
                                    {
                                        /*var*/ let validationResult = reqAttr.GetValidationResult(property.Value, property.Key);
                                        if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                                        {
                                            errors.Add(new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(reqAttr, property.Value, validationResult));
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        if (breakOnFirstError && errors.Count > 0)
                        {
                            break;
                        }
                    }
                }
                return errors;
            }
            static /*List<KeyValuePair<ValidationContext, object?>> */ GetPropertyValues(/*object*/ instance, /*ValidationContext*/ validationContext)
            {
                /*var*/ let properties = $.$sct.System.ComponentModel.TypeDescriptor.GetProperties($.$spc.System.Object.GetType.call(instance));
                /*var*/ let items = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$spc.System.Object)))().$ctor$2(properties.Count);
                var $en2 = properties.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var property = $en2.Current;
                    {
                        /*var*/ let context = $.$sca.System.ComponentModel.DataAnnotations.Validator.CreateValidationContext(instance, validationContext);
                        context.MemberName = property.Name;
                        if ($.$sl.System.Linq.Enumerable.Any($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, $.$sca.System.ComponentModel.DataAnnotations.Validator._store.GetPropertyValidationAttributes(context)))
                        {
                            items.Add(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$spc.System.Object))().$ctor$2(context, property.GetValue(instance)));
                        }
                    }
                }
                return items;
            }
            static /*List<ValidationError> */ GetValidationErrors(/*object?*/ value, /*ValidationContext*/ validationContext, /*IEnumerable<ValidationAttribute>*/ attributes, /*bool*/ breakOnFirstError)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                /*var*/ let errors = new ($.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError))().$ctor$1();
                /*ValidationError?*/ let validationError;
                /*RequiredAttribute?*/ let required = null;
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        required = $.$as(attribute, $.$sca.System.ComponentModel.DataAnnotations.RequiredAttribute);
                        if (!(required === null))
                        {
                            if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidate(value, validationContext, required, $.$ref(() => validationError, ($v) => validationError = $v, $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError)))
                            {
                                errors.Add(validationError);
                                return errors;
                            }
                            break;
                        }
                    }
                }
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attr = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (attr !== required)
                        {
                            if (!$.$sca.System.ComponentModel.DataAnnotations.Validator.TryValidate(value, validationContext, attr, $.$ref(() => validationError, ($v) => validationError = $v, $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError)))
                            {
                                errors.Add(validationError);
                                if (breakOnFirstError)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                return errors;
            }
            static /*bool */ TryValidate(/*object?*/ value, /*ValidationContext*/ validationContext, /*ValidationAttribute*/ attribute, /*out ValidationError?*/ validationError)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(validationContext !== null, "validationContext != null");
                /*var*/ let validationResult = attribute.GetValidationResult(value, validationContext);
                if (validationResult !== $.$sca.System.ComponentModel.DataAnnotations.ValidationResult.Success)
                {
                    validationError.$v = new $.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError().$ctor$1(attribute, value, validationResult);
                    return false;
                }
                validationError.$v = null;
                return true;
            }
            static $_ValidationError;
            static get ValidationError()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.Validator;
                return $cls.$_ValidationError ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError", ($self) => class ValidationError extends $.$spc.System.Object
                {
                    /*object?*/ _value = null;
                    /*ValidationAttribute?*/ _validationAttribute = null;
                    $ctor$1(/*ValidationAttribute?*/ validationAttribute, /*object?*/ value, /*ValidationResult*/ validationResult)
                    {
                        super.$ctor();
                        {
                            this._validationAttribute = validationAttribute;
                            this.ValidationResult = validationResult;
                            this._value = value;
                        }
                        return this;
                    }
                    /*ValidationResult*/ ValidationResult = null;
                    /*void */ ThrowValidationException()
                    {
                        throw new $.$sca.System.ComponentModel.DataAnnotations.ValidationException().$ctor$5(this.ValidationResult, this._validationAttribute, this._value);
                    }
                    static $h = 3801126;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3670054,"g":{"r":0,"d":0,"h":25773604902,"f":8},"n":"ValidationResult","d":3801126,"h":21478637606,"f":8}],"m":[{"r":65537,"n":"ThrowValidationException","d":3801126,"h":30068572198,"f":8}],"l":[{"t":131073,"n":"_value","d":3801126,"h":4298768422,"f":2},{"t":3211302,"n":"_validationAttribute","d":3801126,"h":8593735718,"f":2}],"c":[{"p":[{"n":"validationAttribute","p":3211302},{"n":"value","p":131073},{"n":"validationResult","p":3670054}],"n":".ctor","o":"$ctor$1","d":3801126,"h":12888703014,"f":8}],"d":3735590,"h":3801126}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.Validator.ValidationError`; }
                }, $cls, ($v) => $cls.$_ValidationError = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._store = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.Instance;
                }
            }
            static $h = 3735590;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982},{"n":"validationResults","p":$.$spc.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h}],"n":"TryValidateProperty","d":3735590,"h":8593670182,"f":33},{"r":262145,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982},{"n":"validationResults","p":$.$spc.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h}],"n":"TryValidateObject","d":3735590,"h":12888637478,"f":33},{"r":262145,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982},{"n":"validationResults","p":$.$spc.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h},{"n":"validateAllProperties","p":262145}],"n":"TryValidateObject","o":"@$1","d":3735590,"h":17183604774,"f":33},{"r":262145,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982},{"n":"validationResults","p":$.$spc.System.Collections.Generic.ICollection$$($.$sca.System.ComponentModel.DataAnnotations.ValidationResult).$h},{"n":"validationAttributes","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h}],"n":"TryValidateValue","d":3735590,"h":21478572070,"f":33},{"r":65537,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"ValidateProperty","d":3735590,"h":25773539366,"f":33},{"r":65537,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982}],"n":"ValidateObject","d":3735590,"h":30068506662,"f":33},{"r":65537,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982},{"n":"validateAllProperties","p":262145}],"n":"ValidateObject","o":"@$1","d":3735590,"h":34363473958,"f":33},{"r":65537,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982},{"n":"validationAttributes","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h}],"n":"ValidateValue","d":3735590,"h":38658441254,"f":33},{"r":3538982,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982}],"n":"CreateValidationContext","d":3735590,"h":42953408550,"f":34},{"r":262145,"p":[{"n":"destinationType","p":142606337},{"n":"value","p":131073}],"n":"CanBeAssigned","d":3735590,"h":47248375846,"f":34},{"r":65537,"p":[{"n":"propertyName","p":1310721},{"n":"propertyType","p":142606337},{"n":"value","p":131073}],"n":"EnsureValidPropertyType","d":3735590,"h":51543343142,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982},{"n":"validateAllProperties","p":262145},{"n":"breakOnFirstError","p":262145}],"n":"GetObjectValidationErrors","d":3735590,"h":55838310438,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982},{"n":"validateAllProperties","p":262145},{"n":"breakOnFirstError","p":262145}],"n":"GetObjectPropertyValidationErrors","d":3735590,"h":60133277734,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$sca.System.ComponentModel.DataAnnotations.ValidationContext, $.$spc.System.Object)).$h,"p":[{"n":"instance","p":131073},{"n":"validationContext","p":3538982}],"n":"GetPropertyValues","d":3735590,"h":64428245030,"f":34},{"r":$.$spc.System.Collections.Generic.List$$($.$sca.System.ComponentModel.DataAnnotations.Validator.ValidationError).$h,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982},{"n":"attributes","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h},{"n":"breakOnFirstError","p":262145}],"n":"GetValidationErrors","d":3735590,"h":68723212326,"f":34},{"r":262145,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982},{"n":"attribute","p":3211302},{"n":"validationError","p":3801126,"f":2}],"n":"TryValidate","d":3735590,"h":73018179622,"f":34}],"l":[{"t":3276838,"n":"_store","d":3735590,"h":4298702886,"f":34}],"j":[3801126],"h":3735590}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Validator`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore", ($self) => class ValidationAttributeStore extends $.$spc.System.Object
        {
            /*ConcurrentDictionary<Type, TypeStoreItem>*/ _typeStoreItems = null;
            /*ValidationAttributeStore*/ static Instance = null;
            /*IEnumerable<ValidationAttribute> */ GetTypeValidationAttributes(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let item = this.GetTypeStoreItem(validationContext.ObjectType);
                return item.ValidationAttributes;
            }
            /*DisplayAttribute? */ GetTypeDisplayAttribute(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let item = this.GetTypeStoreItem(validationContext.ObjectType);
                return item.DisplayAttribute;
            }
            /*IEnumerable<ValidationAttribute> */ GetPropertyValidationAttributes(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.ValidationAttributes;
            }
            /*DisplayAttribute? */ GetPropertyDisplayAttribute(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.DisplayAttribute;
            }
            /*Type */ GetPropertyType(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                /*var*/ let item = typeItem.GetPropertyStoreItem(validationContext.MemberName);
                return item.PropertyType;
            }
            /*bool */ IsPropertyContext(/*ValidationContext*/ validationContext)
            {
                $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.EnsureValidationContext(validationContext);
                /*var*/ let typeItem = this.GetTypeStoreItem(validationContext.ObjectType);
                return typeItem.TryGetPropertyStoreItem(validationContext.MemberName, $.$discardRef());
            }
            /*TypeStoreItem */ GetTypeStoreItem(/*Type*/ type)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "type != null");
                return this._typeStoreItems.GetOrAdd(type, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem))().$ctor(null, AddTypeStoreItem));
                /*static TypeStoreItem*/  function AddTypeStoreItem(/*Type*/ type)
                {
                    /*AttributeCollection*/ let attributes = $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes(type);
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem().$ctor$2(type, attributes);
                }
            }
            static /*void */ EnsureValidationContext(/*ValidationContext*/ validationContext)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
            }
            static /*bool */ IsPublic(/*PropertyInfo*/ p)
            {
                return ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(p.GetMethod, null) && p.GetMethod.IsPublic$1) || ($.$spc.System.Reflection.MethodInfo.op_Inequality$2(p.SetMethod, null) && p.SetMethod.IsPublic$1);
            }
            static $_StoreItem;
            static get StoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_StoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem", ($self) => class StoreItem extends $.$spc.System.Object
                {
                    $ctor$1(/*AttributeCollection*/ attributes)
                    {
                        super.$ctor();
                        {
                            this.ValidationAttributes = $.$sl.System.Linq.Enumerable.OfType($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute, attributes);
                            this.DisplayAttribute = $.$sl.System.Linq.Enumerable.SingleOrDefault($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, $.$sl.System.Linq.Enumerable.OfType($.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, attributes));
                        }
                        return this;
                    }
                    /*IEnumerable<ValidationAttribute>*/ ValidationAttributes = null;
                    /*DisplayAttribute?*/ DisplayAttribute = null;
                    static $h = 3407910;
                    static $f = 0b10000000000110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"g":{"r":0,"d":0,"h":17183277094,"f":8},"n":"ValidationAttributes","d":3407910,"h":12888309798,"f":8},{"p":983078,"g":{"r":0,"d":0,"h":30068178982,"f":8},"n":"DisplayAttribute","d":3407910,"h":25773211686,"f":8}],"c":[{"p":[{"n":"attributes","p":1179688}],"n":".ctor","o":"$ctor$1","d":3407910,"h":4298375206,"f":8}],"d":3276838,"h":3407910}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem`; }
                }, $cls, ($v) => $cls.$_StoreItem = $v);
            }
            static $_TypeStoreItem;
            static get TypeStoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_TypeStoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem", ($self) => class TypeStoreItem extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem
                {
                    /*DynamicallyAccessedMemberTypes*/ static DynamicallyAccessedTypes = 4194303;
                    /*object*/ _syncRoot = null;
                    /*Type*/ _type = null;
                    /*Dictionary<string, PropertyStoreItem>?*/ _propertyStoreItems = null;
                    $ctor$2(/*Type*/ type, /*AttributeCollection*/ attributes)
                    {
                        super.$ctor$1(attributes);
                        {
                            this._type = type;
                        }
                        return this;
                    }
                    /*PropertyStoreItem */ GetPropertyStoreItem(/*string*/ propertyName)
                    {
                        /*PropertyStoreItem?*/ let item;
                        if (!this.TryGetPropertyStoreItem(propertyName, $.$ref(() => item, ($v) => item = $v, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem)))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$13($.$sca.System.SR.Format$1($.$sca.System.SR.AttributeStore_Unknown_Property, this._type.Name, propertyName), "propertyName");
                        }
                        return item;
                    }
                    /*bool */ TryGetPropertyStoreItem(/*string*/ propertyName, /*out PropertyStoreItem?*/ item)
                    {
                        if ($.$spc.System.String.IsNullOrEmpty(propertyName))
                        {
                            throw new $.$spc.System.ArgumentNullException().$ctor$16("propertyName");
                        }
                        if (this._propertyStoreItems === null)
                        {
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(this._syncRoot)
                                {
                                    this._propertyStoreItems ??= this.CreatePropertyStoreItems();
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(this._syncRoot)
                            }
                        }
                        return this._propertyStoreItems.TryGetValue(propertyName, item);
                    }
                    /*Dictionary<string, PropertyStoreItem> */ CreatePropertyStoreItems()
                    {
                        /*var*/ let propertyStoreItems = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem))().$ctor$1();
                        /*var*/ let properties = $.$sct.System.ComponentModel.TypeDescriptor.GetProperties(this._type);
                        var $en4 = properties.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var property = $en4.Current;
                            {
                                /*var*/ let item = new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem().$ctor$2(property.PropertyType, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem.GetExplicitAttributes(property));
                                propertyStoreItems.set_Item(property.Name, item);
                            }
                        }
                        return propertyStoreItems;
                    }
                    static /*AttributeCollection */ GetExplicitAttributes(/*PropertyDescriptor*/ propertyDescriptor)
                    {
                        /*AttributeCollection*/ let propertyDescriptorAttributes = propertyDescriptor.Attributes;
                        /*List<Attribute>*/ let attributes = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Attribute))().$ctor$2(propertyDescriptorAttributes.Count);
                        var $en4 = propertyDescriptorAttributes.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var attribute = $en4.Current;
                            {
                                attributes.Add(attribute);
                            }
                        }
                        /*AttributeCollection*/ let typeAttributes = $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes(propertyDescriptor.PropertyType);
                        /*bool*/ let removedAttribute = false;
                        var $en4 = typeAttributes.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var attr = $en4.Current;
                            {
                                for(/*int*/ let i = ((attributes.Count - 1) | 0); i >= 0; --i)
                                {
                                    if ($.$spc.System.Object.ReferenceEquals(attr, attributes.get_Item(i)))
                                    {
                                        attributes.RemoveAt(i);
                                        removedAttribute = true;
                                    }
                                }
                            }
                        }
                        return removedAttribute ? new $.$sct.System.ComponentModel.AttributeCollection().$ctor$1(attributes.ToArray()) : propertyDescriptorAttributes;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._syncRoot = new $.$spc.System.Object().$ctor();
                    }
                    static $h = 3473446;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":3407910,"m":[{"r":3342374,"p":[{"n":"propertyName","p":1310721}],"n":"GetPropertyStoreItem","d":3473446,"h":25773277222,"f":8},{"r":262145,"p":[{"n":"propertyName","p":1310721},{"n":"item","p":3342374,"f":2}],"n":"TryGetPropertyStoreItem","d":3473446,"h":30068244518,"f":8},{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem).$h,"n":"CreatePropertyStoreItems","d":3473446,"h":34363211814,"f":2},{"r":1179688,"p":[{"n":"propertyDescriptor","p":14024744}],"n":"GetExplicitAttributes","d":3473446,"h":38658179110,"f":34}],"l":[{"t":35848193,"n":"DynamicallyAccessedTypes","d":3473446,"h":4298440742,"f":40},{"t":131073,"n":"_syncRoot","d":3473446,"h":8593408038,"f":2},{"t":142606337,"n":"_type","d":3473446,"h":12888375334,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem).$h,"n":"_propertyStoreItems","d":3473446,"h":17183342630,"f":2}],"c":[{"p":[{"n":"type","p":142606337},{"n":"attributes","p":1179688}],"n":".ctor","o":"$ctor$2","d":3473446,"h":21478309926,"f":8}],"d":3276838,"h":3473446}; }
                    static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem`; }
                }, $cls, ($v) => $cls.$_TypeStoreItem = $v);
            }
            static $_PropertyStoreItem;
            static get PropertyStoreItem()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore;
                return $cls.$_PropertyStoreItem ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem", ($self) => class PropertyStoreItem extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem
                {
                    $ctor$2(/*Type*/ propertyType, /*AttributeCollection*/ attributes)
                    {
                        super.$ctor$1(attributes);
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(propertyType, null), "propertyType != null");
                            this.PropertyType = propertyType;
                        }
                        return this;
                    }
                    /*Type*/ PropertyType = null;
                    static $h = 3342374;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":3407910,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17183211558,"f":8},"n":"PropertyType","d":3342374,"h":12888244262,"f":8}],"c":[{"p":[{"n":"propertyType","p":142606337},{"n":"attributes","p":1179688}],"n":".ctor","o":"$ctor$2","d":3342374,"h":4298309670,"f":8}],"d":3276838,"h":3342374}; }
                    static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.StoreItem; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore.PropertyStoreItem`; }
                }, $cls, ($v) => $cls.$_PropertyStoreItem = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._typeStoreItems = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore().$ctor$1();
                }
            }
            static $h = 3276838;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3276838,"g":{"r":0,"d":0,"h":17183146022,"f":40},"n":"Instance","d":3276838,"h":12888178726,"f":40}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"p":[{"n":"validationContext","p":3538982}],"n":"GetTypeValidationAttributes","d":3276838,"h":21478113318,"f":8},{"r":983078,"p":[{"n":"validationContext","p":3538982}],"n":"GetTypeDisplayAttribute","d":3276838,"h":25773080614,"f":8},{"r":$.$spc.System.Collections.Generic.IEnumerable$$($.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute).$h,"p":[{"n":"validationContext","p":3538982}],"n":"GetPropertyValidationAttributes","d":3276838,"h":30068047910,"f":8},{"r":983078,"p":[{"n":"validationContext","p":3538982}],"n":"GetPropertyDisplayAttribute","d":3276838,"h":34363015206,"f":8},{"r":142606337,"p":[{"n":"validationContext","p":3538982}],"n":"GetPropertyType","d":3276838,"h":38657982502,"f":8},{"r":262145,"p":[{"n":"validationContext","p":3538982}],"n":"IsPropertyContext","d":3276838,"h":42952949798,"f":8},{"r":3473446,"p":[{"n":"type","p":142606337}],"n":"GetTypeStoreItem","d":3276838,"h":47247917094,"f":2},{"r":65537,"p":[{"n":"validationContext","p":3538982}],"n":"EnsureValidationContext","d":3276838,"h":51542884390,"f":34},{"r":262145,"p":[{"n":"p","p":81657857}],"n":"IsPublic","d":3276838,"h":55837851686,"f":40}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.TypeStoreItem).$h,"n":"_typeStoreItems","d":3276838,"h":4298244134,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3276838,"h":73017720870,"f":1}],"j":[3407910,3473446,3342374],"h":3276838}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationAttributeStore`; }
        });
        
        $asm.$cls("$sca.System.NotImplemented", ($self) => class NotImplemented
        {
            static /*Exception */ get ByDesign()
            {
                return new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static /*Exception */ ByDesignWithMessage(/*string*/ message)
            {
                return new $.$spc.System.NotImplementedException().$ctor$10(message);
            }
            static $h = 3866662;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":47185921,"g":{"r":0,"d":0,"h":8593801254,"f":40},"n":"ByDesign","d":3866662,"h":4298833958,"f":40}],"m":[{"r":47185921,"p":[{"n":"message","p":1310721}],"n":"ByDesignWithMessage","d":3866662,"h":12888768550,"f":40}],"h":3866662}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.NotImplemented`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationContext", ($self) => class ValidationContext extends $.$spc.System.Object
        {
            /*string*/ static InstanceTypeNotStaticallyDiscovered = null;
            /*Dictionary<object, object?>*/ _items = null;
            /*string?*/ _displayName = null;
            /*Func<Type, object?>?*/ _serviceProvider = null;
            $ctor$1(/*object*/ instance)
            {
                this.$ctor$3(instance, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*object*/ instance, /*IDictionary<object, object?>?*/ items)
            {
                this.$ctor$3(instance, null, items);
                {
                }
                return this;
            }
            $ctor$3(/*object*/ instance, /*IServiceProvider?*/ serviceProvider, /*IDictionary<object, object?>?*/ items)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(instance, "instance");
                    if (serviceProvider !== null)
                    {
                        /*IServiceProvider*/ let localServiceProvider = serviceProvider;
                        this.InitializeServiceProvider(new ($.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Object))().$ctor(localServiceProvider, localServiceProvider.System$IServiceProvider$GetService));
                    }
                    this._items = items !== null ? new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$5(items) : new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$1();
                    this.ObjectInstance = instance;
                }
                return this;
            }
            $ctor$4(/*object*/ instance, /*string*/ displayName, /*IServiceProvider?*/ serviceProvider, /*IDictionary<object, object?>?*/ items)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(displayName, "displayName");
                    $.$spc.System.ArgumentNullException.ThrowIfNull(instance, "instance");
                    if (serviceProvider !== null)
                    {
                        /*IServiceProvider*/ let localServiceProvider = serviceProvider;
                        this.InitializeServiceProvider(new ($.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Object))().$ctor(localServiceProvider, localServiceProvider.System$IServiceProvider$GetService));
                    }
                    this._items = items !== null ? new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$5(items) : new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor$1();
                    this.ObjectInstance = instance;
                    this.DisplayName = displayName;
                }
                return this;
            }
            /*object*/ ObjectInstance = null;
            /*Type */ get ObjectType()
            {
                return $.$spc.System.Object.GetType.call(this.ObjectInstance);
            }
            /*string */ get DisplayName()
            {
                if ($.$spc.System.String.IsNullOrEmpty(this._displayName))
                {
                    this._displayName = this.GetDisplayName();
                    if ($.$spc.System.String.IsNullOrEmpty(this._displayName))
                    {
                        this._displayName = this.ObjectType.Name;
                    }
                }
                return this._displayName;
            }
            /*string */ set DisplayName(value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value))
                {
                    throw new $.$spc.System.ArgumentNullException().$ctor$16("value");
                }
                this._displayName = value;
            }
            /*string?*/ MemberName = null;
            /*IDictionary<object, object?> */ get Items()
            {
                return this._items;
            }
            /*string? */ GetDisplayName()
            {
                /*string?*/ let displayName = null;
                /*ValidationAttributeStore*/ let store = $.$sca.System.ComponentModel.DataAnnotations.ValidationAttributeStore.Instance;
                /*DisplayAttribute?*/ let displayAttribute = null;
                if ($.$spc.System.String.IsNullOrEmpty(this.MemberName))
                {
                    displayAttribute = store.GetTypeDisplayAttribute(this);
                }
                else if (store.IsPropertyContext(this))
                {
                    displayAttribute = store.GetPropertyDisplayAttribute(this);
                }
                if (displayAttribute !== null)
                {
                    displayName = displayAttribute.GetName();
                }
                return displayName ?? this.MemberName;
            }
            /*void */ InitializeServiceProvider(/*Func<Type, object?>*/ serviceProvider)
            {
                this._serviceProvider = serviceProvider;
            }
            /*object? */ GetService(/*Type*/ serviceType)
            {
                return (this._serviceProvider?.Invoke(serviceType) ?? null);
            }
            //Generated interface implemetation for System.IServiceProvider.GetService(System.Type)
            System$IServiceProvider$GetService()
            {
                return this.GetService(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.InstanceTypeNotStaticallyDiscovered = "Constructing a ValidationContext without a display name is not trim-safe because it uses reflection to discover the type of the instance being validated in order to resolve the DisplayNameAttribute when a display name is not provided.";
                }
            }
            static $h = 3538982;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":47248179238,"f":1},"n":"ObjectInstance","d":3538982,"h":42953211942,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":55838113830,"f":1},"n":"ObjectType","d":3538982,"h":51543146534,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64428048422,"f":1},"s":{"r":0,"d":0,"h":68723015718,"f":1},"n":"DisplayName","d":3538982,"h":60133081126,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81607917606,"f":1},"s":{"r":0,"d":0,"h":85902884902,"f":1},"n":"MemberName","d":3538982,"h":77312950310,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":94492819494,"f":1},"n":"Items","d":3538982,"h":90197852198,"f":1}],"m":[{"r":1310721,"n":"GetDisplayName","d":3538982,"h":98787786790,"f":2},{"r":65537,"p":[{"n":"serviceProvider","p":$.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Object).$h}],"n":"InitializeServiceProvider","d":3538982,"h":103082754086,"f":1},{"r":131073,"p":[{"n":"serviceType","p":142606337}],"n":"GetService","d":3538982,"h":107377721382,"f":1}],"l":[{"t":1310721,"n":"InstanceTypeNotStaticallyDiscovered","d":3538982,"h":4298506278,"f":40},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h,"n":"_items","d":3538982,"h":8593473574,"f":2},{"t":1310721,"n":"_displayName","d":3538982,"h":12888440870,"f":2},{"t":$.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Object).$h,"n":"_serviceProvider","d":3538982,"h":17183408166,"f":2}],"c":[{"p":[{"n":"instance","p":131073}],"n":".ctor","o":"$ctor$1","d":3538982,"h":21478375462,"f":1},{"p":[{"n":"instance","p":131073},{"n":"items","p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$2","d":3538982,"h":25773342758,"f":1},{"p":[{"n":"instance","p":131073},{"n":"serviceProvider","p":327717},{"n":"items","p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$3","d":3538982,"h":30068310054,"f":1},{"p":[{"n":"instance","p":131073},{"n":"displayName","p":1310721},{"n":"serviceProvider","p":327717},{"n":"items","p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.Object, $.$spc.System.Object).$h}],"n":".ctor","o":"$ctor$4","d":3538982,"h":34363277350,"f":1}],"i":[327717],"h":3538982}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationContext`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ConcurrencyCheckAttribute", ($self) => class ConcurrencyCheckAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 524326;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":524326,"h":4295491622,"f":1}],"h":524326,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ConcurrencyCheckAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociationAttribute", ($self) => class AssociationAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ name, /*string*/ thisKey, /*string*/ otherKey)
            {
                super.$ctor$1();
                {
                    this.Name = name;
                    this.ThisKey = thisKey;
                    this.OtherKey = otherKey;
                }
                return this;
            }
            /*string*/ Name = null;
            /*string*/ ThisKey = null;
            /*string*/ OtherKey = null;
            /*bool*/ IsForeignKey = false;
            /*IEnumerable<string> */ get ThisKeyMembers()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.AssociationAttribute.GetKeyMembers(this.ThisKey);
            }
            /*IEnumerable<string> */ get OtherKeyMembers()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.AssociationAttribute.GetKeyMembers(this.OtherKey);
            }
            static /*string[] */ GetKeyMembers(/*string?*/ key)
            {
                if ($.$spc.System.String.op_Equality(key, null))
                {
                    return $.$spc.System.Array.Empty($.$spc.System.String);
                }
                return $.$spc.System.String.Split.call($.$spc.System.String.Replace$3.call(key, " ", $.$spc.System.String.Empty), /*,*/ 44, 0);
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsForeignKey = false;
            }
            static $h = 327718;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180196902,"f":1},"n":"Name","d":327718,"h":12885229606,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065098790,"f":1},"n":"ThisKey","d":327718,"h":25770131494,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42950000678,"f":1},"n":"OtherKey","d":327718,"h":38655033382,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55834902566,"f":1},"s":{"r":0,"d":0,"h":60129869862,"f":1},"n":"IsForeignKey","d":327718,"h":51539935270,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":68719804454,"f":1},"n":"ThisKeyMembers","d":327718,"h":64424837158,"f":1},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":77309739046,"f":1},"n":"OtherKeyMembers","d":327718,"h":73014771750,"f":1}],"m":[{"r":0,"p":[{"n":"key","p":1310721}],"n":"GetKeyMembers","d":327718,"h":81604706342,"f":34}],"c":[{"p":[{"n":"name","p":1310721},{"n":"thisKey","p":1310721},{"n":"otherKey","p":1310721}],"n":".ctor","o":"$ctor$2","d":327718,"h":4295295014,"f":1}],"h":327718,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]},{"t":70909953,"c":8660844545,"a":[{"v":"AssociationAttribute has been deprecated and is not supported.","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociationAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptionProvider", ($self) => class AssociatedMetadataTypeTypeDescriptionProvider extends $.$sct.System.ComponentModel.TypeDescriptionProvider
        {
            /*DynamicallyAccessedMemberTypes*/ static AllMembersAndInterfaces = 4194303;
            /*Type?*/ _associatedMetadataType = null;
            $ctor$3(/*Type*/ type)
            {
                super.$ctor$2($.$sct.System.ComponentModel.TypeDescriptor.GetProvider(type));
                {
                }
                return this;
            }
            $ctor$4(/*Type*/ type, /*Type*/ associatedMetadataType)
            {
                this.$ctor$3(type);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(associatedMetadataType, "associatedMetadataType");
                    this._associatedMetadataType = associatedMetadataType;
                }
                return this;
            }
            /*ICustomTypeDescriptor */ GetTypeDescriptor$2(/*Type*/ objectType, /*object?*/ instance)
            {
                /*ICustomTypeDescriptor?*/ let baseDescriptor = super.GetTypeDescriptor$2(objectType, instance);
                return new $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor().$ctor$3(baseDescriptor, objectType, this._associatedMetadataType);
            }
            static $h = 131110;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":16121896,"m":[{"r":10616872,"p":[{"n":"objectType","p":142606337},{"n":"instance","p":131073}],"n":"GetTypeDescriptor","o":"@$2","d":131110,"h":21474967590,"f":32769}],"l":[{"t":35848193,"n":"AllMembersAndInterfaces","d":131110,"h":4295098406,"f":40},{"t":142606337,"n":"_associatedMetadataType","d":131110,"h":8590065702,"f":2}],"c":[{"p":[{"n":"type","p":142606337}],"n":".ctor","o":"$ctor$3","d":131110,"h":12885032998,"f":1},{"p":[{"n":"type","p":142606337},{"n":"associatedMetadataType","p":142606337}],"n":".ctor","o":"$ctor$4","d":131110,"h":17180000294,"f":1}],"h":131110}; }
            static get $b() { return $.$sct.System.ComponentModel.TypeDescriptionProvider; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptionProvider`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayAttribute", ($self) => class DisplayAttribute extends $.$spc.System.Attribute
        {
            /*LocalizableString*/ _description = null;
            /*LocalizableString*/ _groupName = null;
            /*LocalizableString*/ _name = null;
            /*LocalizableString*/ _prompt = null;
            /*LocalizableString*/ _shortName = null;
            /*bool?*/ _autoGenerateField = null;
            /*bool?*/ _autoGenerateFilter = null;
            /*int?*/ _order = null;
            /*Type?*/ _resourceType = null;
            /*string? */ get ShortName()
            {
                return this._shortName.Value;
            }
            /*string? */ set ShortName(value)
            {
                this._shortName.Value = value;
            }
            /*string? */ get Name()
            {
                return this._name.Value;
            }
            /*string? */ set Name(value)
            {
                this._name.Value = value;
            }
            /*string? */ get Description()
            {
                return this._description.Value;
            }
            /*string? */ set Description(value)
            {
                this._description.Value = value;
            }
            /*string? */ get Prompt()
            {
                return this._prompt.Value;
            }
            /*string? */ set Prompt(value)
            {
                this._prompt.Value = value;
            }
            /*string? */ get GroupName()
            {
                return this._groupName.Value;
            }
            /*string? */ set GroupName(value)
            {
                this._groupName.Value = value;
            }
            /*Type? */ get ResourceType()
            {
                return this._resourceType;
            }
            /*Type? */ set ResourceType(value)
            {
                if ($.$spc.System.Type.op_Inequality$1(this._resourceType, value))
                {
                    this._resourceType = value;
                    this._shortName.ResourceType = value;
                    this._name.ResourceType = value;
                    this._description.ResourceType = value;
                    this._prompt.ResourceType = value;
                    this._groupName.ResourceType = value;
                }
            }
            /*bool */ get AutoGenerateField()
            {
                if (!$.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(this._autoGenerateField))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "AutoGenerateField", "GetAutoGenerateField"));
                }
                return $.$spc.System.Nullable$$($.$spc.System.Boolean).GetValueOrDefault.call(this._autoGenerateField);
            }
            /*bool */ set AutoGenerateField(value)
            {
                this._autoGenerateField = value;
            }
            /*bool */ get AutoGenerateFilter()
            {
                if (!$.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(this._autoGenerateFilter))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "AutoGenerateFilter", "GetAutoGenerateFilter"));
                }
                return $.$spc.System.Nullable$$($.$spc.System.Boolean).GetValueOrDefault.call(this._autoGenerateFilter);
            }
            /*bool */ set AutoGenerateFilter(value)
            {
                this._autoGenerateFilter = value;
            }
            /*int */ get Order()
            {
                if (!$.$spc.System.Nullable$$($.$spc.System.Int32).HasValue$get.call(this._order))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.DisplayAttribute_PropertyNotSet, "Order", "GetOrder"));
                }
                return $.$spc.System.Nullable$$($.$spc.System.Int32).GetValueOrDefault.call(this._order);
            }
            /*int */ set Order(value)
            {
                this._order = value;
            }
            /*string? */ GetShortName()
            {
                return this._shortName.GetLocalizableValue() ?? this.GetName();
            }
            /*string? */ GetName()
            {
                return this._name.GetLocalizableValue();
            }
            /*string? */ GetDescription()
            {
                return this._description.GetLocalizableValue();
            }
            /*string? */ GetPrompt()
            {
                return this._prompt.GetLocalizableValue();
            }
            /*string? */ GetGroupName()
            {
                return this._groupName.GetLocalizableValue();
            }
            /*bool? */ GetAutoGenerateField()
            {
                return this._autoGenerateField;
            }
            /*bool? */ GetAutoGenerateFilter()
            {
                return this._autoGenerateFilter;
            }
            /*int? */ GetOrder()
            {
                return this._order;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._description = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Description");
                this._groupName = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("GroupName");
                this._name = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Name");
                this._prompt = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("Prompt");
                this._shortName = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("ShortName");
            }
            static $h = 983078;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":47245623334,"f":1},"s":{"r":0,"d":0,"h":51540590630,"f":1},"n":"ShortName","d":983078,"h":42950656038,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":60130525222,"f":1},"s":{"r":0,"d":0,"h":64425492518,"f":1},"n":"Name","d":983078,"h":55835557926,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015427110,"f":1},"s":{"r":0,"d":0,"h":77310394406,"f":1},"n":"Description","d":983078,"h":68720459814,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85900328998,"f":1},"s":{"r":0,"d":0,"h":90195296294,"f":1},"n":"Prompt","d":983078,"h":81605361702,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":98785230886,"f":1},"s":{"r":0,"d":0,"h":103080198182,"f":1},"n":"GroupName","d":983078,"h":94490263590,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":111670132774,"f":1},"s":{"r":0,"d":0,"h":115965100070,"f":1},"n":"ResourceType","d":983078,"h":107375165478,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555034662,"f":1},"s":{"r":0,"d":0,"h":128850001958,"f":1},"n":"AutoGenerateField","d":983078,"h":120260067366,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":137439936550,"f":1},"s":{"r":0,"d":0,"h":141734903846,"f":1},"n":"AutoGenerateFilter","d":983078,"h":133144969254,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":150324838438,"f":1},"s":{"r":0,"d":0,"h":154619805734,"f":1},"n":"Order","d":983078,"h":146029871142,"f":1}],"m":[{"r":1310721,"n":"GetShortName","d":983078,"h":158914773030,"f":1},{"r":1310721,"n":"GetName","d":983078,"h":163209740326,"f":1},{"r":1310721,"n":"GetDescription","d":983078,"h":167504707622,"f":1},{"r":1310721,"n":"GetPrompt","d":983078,"h":171799674918,"f":1},{"r":1310721,"n":"GetGroupName","d":983078,"h":176094642214,"f":1},{"r":$.$typeNullable($.$spc.System.Boolean).$h,"n":"GetAutoGenerateField","d":983078,"h":180389609510,"f":1},{"r":$.$typeNullable($.$spc.System.Boolean).$h,"n":"GetAutoGenerateFilter","d":983078,"h":184684576806,"f":1},{"r":$.$typeNullable($.$spc.System.Int32).$h,"n":"GetOrder","d":983078,"h":188979544102,"f":1}],"l":[{"t":1703974,"n":"_description","d":983078,"h":4295950374,"f":2},{"t":1703974,"n":"_groupName","d":983078,"h":8590917670,"f":2},{"t":1703974,"n":"_name","d":983078,"h":12885884966,"f":2},{"t":1703974,"n":"_prompt","d":983078,"h":17180852262,"f":2},{"t":1703974,"n":"_shortName","d":983078,"h":21475819558,"f":2},{"t":$.$typeNullable($.$spc.System.Boolean).$h,"n":"_autoGenerateField","d":983078,"h":25770786854,"f":2},{"t":$.$typeNullable($.$spc.System.Boolean).$h,"n":"_autoGenerateFilter","d":983078,"h":30065754150,"f":2},{"t":$.$typeNullable($.$spc.System.Int32).$h,"n":"_order","d":983078,"h":34360721446,"f":2},{"t":142606337,"n":"_resourceType","d":983078,"h":38655688742,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":983078,"h":193274511398,"f":1}],"h":983078,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2500,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayColumnAttribute", ($self) => class DisplayColumnAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ displayColumn)
            {
                this.$ctor$3(displayColumn, null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ displayColumn, /*string?*/ sortColumn)
            {
                this.$ctor$4(displayColumn, sortColumn, false);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ displayColumn, /*string?*/ sortColumn, /*bool*/ sortDescending)
            {
                super.$ctor$1();
                {
                    this.DisplayColumn = displayColumn;
                    this.SortColumn = sortColumn;
                    this.SortDescending = sortDescending;
                }
                return this;
            }
            /*string*/ DisplayColumn = null;
            /*string?*/ SortColumn = null;
            /*bool*/ SortDescending = false;
            //default member initializer
            constructor()
            {
                super();
                this.SortDescending = false;
            }
            static $h = 1048614;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25770852390,"f":1},"n":"DisplayColumn","d":1048614,"h":21475885094,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655754278,"f":1},"n":"SortColumn","d":1048614,"h":34360786982,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540656166,"f":1},"n":"SortDescending","d":1048614,"h":47245688870,"f":1}],"c":[{"p":[{"n":"displayColumn","p":1310721}],"n":".ctor","o":"$ctor$2","d":1048614,"h":4296015910,"f":1},{"p":[{"n":"displayColumn","p":1310721},{"n":"sortColumn","p":1310721}],"n":".ctor","o":"$ctor$3","d":1048614,"h":8590983206,"f":1},{"p":[{"n":"displayColumn","p":1310721},{"n":"sortColumn","p":1310721},{"n":"sortDescending","p":262145}],"n":".ctor","o":"$ctor$4","d":1048614,"h":12885950502,"f":1}],"h":1048614,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"Inherited","v":true,"t":262145},{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayColumnAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute", ($self) => class DisplayFormatAttribute extends $.$spc.System.Attribute
        {
            /*LocalizableString*/ _nullDisplayText = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.ConvertEmptyStringToNull = true;
                    this.HtmlEncode = true;
                }
                return this;
            }
            /*string?*/ DataFormatString = null;
            /*string? */ get NullDisplayText()
            {
                return this._nullDisplayText.Value;
            }
            /*string? */ set NullDisplayText(value)
            {
                this._nullDisplayText.Value = value;
            }
            /*bool*/ ConvertEmptyStringToNull = false;
            /*bool*/ ApplyFormatInEditMode = false;
            /*bool*/ HtmlEncode = false;
            /*Type? */ get NullDisplayTextResourceType()
            {
                return this._nullDisplayText.ResourceType;
            }
            /*Type? */ set NullDisplayTextResourceType(value)
            {
                this._nullDisplayText.ResourceType = value;
            }
            /*string? */ GetNullDisplayText()
            {
                return this._nullDisplayText.GetLocalizableValue();
            }
            //default member initializer
            constructor()
            {
                super();
                this._nullDisplayText = new $.$sca.System.ComponentModel.DataAnnotations.LocalizableString().$ctor$1("NullDisplayText");
                this.ConvertEmptyStringToNull = false;
                this.ApplyFormatInEditMode = false;
                this.HtmlEncode = false;
            }
            static $h = 1114150;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475950630,"f":1},"s":{"r":0,"d":0,"h":25770917926,"f":1},"n":"DataFormatString","d":1114150,"h":17180983334,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360852518,"f":1},"s":{"r":0,"d":0,"h":38655819814,"f":1},"n":"NullDisplayText","d":1114150,"h":30065885222,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540721702,"f":1},"s":{"r":0,"d":0,"h":55835688998,"f":1},"n":"ConvertEmptyStringToNull","d":1114150,"h":47245754406,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68720590886,"f":1},"s":{"r":0,"d":0,"h":73015558182,"f":1},"n":"ApplyFormatInEditMode","d":1114150,"h":64425623590,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":85900460070,"f":1},"s":{"r":0,"d":0,"h":90195427366,"f":1},"n":"HtmlEncode","d":1114150,"h":81605492774,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":98785361958,"f":1},"s":{"r":0,"d":0,"h":103080329254,"f":1},"n":"NullDisplayTextResourceType","d":1114150,"h":94490394662,"f":1}],"m":[{"r":1310721,"n":"GetNullDisplayText","d":1114150,"h":107375296550,"f":1}],"l":[{"t":1703974,"n":"_nullDisplayText","d":1114150,"h":4296081446,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1114150,"h":8591048742,"f":1}],"h":1114150,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DisplayFormatAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute", ($self) => class FilterUIHintAttribute extends $.$spc.System.Attribute
        {
            /*UIHintAttribute.UIHintImplementation*/ _implementation = null;
            /*string */ get FilterUIHint()
            {
                return this._implementation.UIHint;
            }
            /*string? */ get PresentationLayer()
            {
                return this._implementation.PresentationLayer;
            }
            /*IDictionary<string, object?> */ get ControlParameters()
            {
                return this._implementation.ControlParameters;
            }
            $ctor$2(/*string*/ filterUIHint)
            {
                this.$ctor$4(filterUIHint, null, $.$spc.System.Array.Empty($.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$3(/*string*/ filterUIHint, /*string?*/ presentationLayer)
            {
                this.$ctor$4(filterUIHint, presentationLayer, $.$spc.System.Array.Empty($.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$4(/*string*/ filterUIHint, /*string?*/ presentationLayer, /*params object?[]*/ controlParameters)
            {
                super.$ctor$1();
                {
                    this._implementation = new $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation().$ctor$1(filterUIHint, presentationLayer, controlParameters);
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.call(this._implementation);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let otherAttribute;
                return $.$is(obj, $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute, { set $v(v){ otherAttribute = v; } }) && $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals.call(this._implementation, otherAttribute._implementation);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sca.System.ComponentModel.DataAnnotations.FilterUIHintAttribute.Equals.apply(this, arguments); }
            static $h = 1441830;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886343718,"f":1},"n":"FilterUIHint","d":1441830,"h":8591376422,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21476278310,"f":1},"n":"PresentationLayer","d":1441830,"h":17181311014,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":30066212902,"f":1},"n":"ControlParameters","d":1441830,"h":25771245606,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":1441830,"h":47246082086,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":1441830,"h":51541049382,"f":32769}],"l":[{"t":3080230,"n":"_implementation","d":1441830,"h":4296409126,"f":2}],"c":[{"p":[{"n":"filterUIHint","p":1310721}],"n":".ctor","o":"$ctor$2","d":1441830,"h":34361180198,"f":1},{"p":[{"n":"filterUIHint","p":1310721},{"n":"presentationLayer","p":1310721}],"n":".ctor","o":"$ctor$3","d":1441830,"h":38656147494,"f":1},{"p":[{"n":"filterUIHint","p":1310721},{"n":"presentationLayer","p":1310721},{"n":"controlParameters","p":0,"f":16}],"n":".ctor","o":"$ctor$4","d":1441830,"h":42951114790,"f":1}],"h":1441830,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]},{"t":70909953,"c":8660844545,"a":[{"v":"FilterUIHintAttribute has been deprecated and is not supported.","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.FilterUIHintAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EditableAttribute", ($self) => class EditableAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*bool*/ allowEdit)
            {
                super.$ctor$1();
                {
                    this.AllowEdit = allowEdit;
                    this.AllowInitialValue = allowEdit;
                }
                return this;
            }
            /*bool*/ AllowEdit = false;
            /*bool*/ AllowInitialValue = false;
            //default member initializer
            constructor()
            {
                super();
                this.AllowEdit = false;
                this.AllowInitialValue = false;
            }
            static $h = 1179686;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181048870,"f":1},"n":"AllowEdit","d":1179686,"h":12886081574,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065950758,"f":1},"s":{"r":0,"d":0,"h":34360918054,"f":1},"n":"AllowInitialValue","d":1179686,"h":25770983462,"f":1}],"c":[{"p":[{"n":"allowEdit","p":262145}],"n":".ctor","o":"$ctor$2","d":1179686,"h":4296146982,"f":1}],"h":1179686,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EditableAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.KeyAttribute", ($self) => class KeyAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 1572902;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":1572902,"h":4296540198,"f":1}],"h":1572902,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.KeyAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute", ($self) => class MetadataTypeAttribute extends $.$spc.System.Attribute
        {
            /*Type*/ _metadataClassType = null;
            $ctor$2(/*Type*/ metadataClassType)
            {
                super.$ctor$1();
                {
                    this._metadataClassType = metadataClassType;
                }
                return this;
            }
            /*Type */ get MetadataClassType()
            {
                if ($.$spc.System.Type.op_Equality$1(this._metadataClassType, null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.MetadataTypeAttribute_TypeCannotBeNull);
                }
                return this._metadataClassType;
            }
            static $h = 1900582;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17181769766,"f":1},"n":"MetadataClassType","d":1900582,"h":12886802470,"f":1}],"l":[{"t":142606337,"n":"_metadataClassType","d":1900582,"h":4296867878,"f":2}],"c":[{"p":[{"n":"metadataClassType","p":142606337}],"n":".ctor","o":"$ctor$2","d":1900582,"h":8591835174,"f":1}],"h":1900582,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MetadataTypeAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ScaffoldColumnAttribute", ($self) => class ScaffoldColumnAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*bool*/ scaffold)
            {
                super.$ctor$1();
                {
                    this.Scaffold = scaffold;
                }
                return this;
            }
            /*bool*/ Scaffold = false;
            //default member initializer
            constructor()
            {
                super();
                this.Scaffold = false;
            }
            static $h = 2293798;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17182162982,"f":1},"n":"Scaffold","d":2293798,"h":12887195686,"f":1}],"c":[{"p":[{"n":"scaffold","p":262145}],"n":".ctor","o":"$ctor$2","d":2293798,"h":4297261094,"f":1}],"h":2293798,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ScaffoldColumnAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ComplexTypeAttribute", ($self) => class ComplexTypeAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2424870;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2424870,"h":4297392166,"f":1}],"h":2424870,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ComplexTypeAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedAttribute", ($self) => class DatabaseGeneratedAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*DatabaseGeneratedOption*/ databaseGeneratedOption)
            {
                super.$ctor$1();
                {
                    if (!$.$spc.System.Enum.IsDefined($.$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption, databaseGeneratedOption))
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("databaseGeneratedOption");
                    }
                    this.DatabaseGeneratedOption = databaseGeneratedOption;
                }
                return this;
            }
            /*DatabaseGeneratedOption*/ DatabaseGeneratedOption = 0;
            //default member initializer
            constructor()
            {
                super();
                this.DatabaseGeneratedOption = 0;
            }
            static $h = 2490406;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":2555942,"g":{"r":0,"d":0,"h":17182359590,"f":1},"n":"DatabaseGeneratedOption","d":2490406,"h":12887392294,"f":1}],"c":[{"p":[{"n":"databaseGeneratedOption","p":2555942}],"n":".ctor","o":"$ctor$2","d":2490406,"h":4297457702,"f":1}],"h":2490406,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ColumnAttribute", ($self) => class ColumnAttribute extends $.$spc.System.Attribute
        {
            /*int*/ _order = -1;
            /*string?*/ _typeName = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ name)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            /*string?*/ Name = null;
            /*int */ get Order()
            {
                return this._order;
            }
            /*int */ set Order(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, value, "value");
                this._order = value;
            }
            /*string? */ get TypeName()
            {
                return this._typeName;
            }
            /*string? */ set TypeName(value)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(value, "value");
                this._typeName = value;
            }
            static $h = 2359334;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30067130406,"f":1},"n":"Name","d":2359334,"h":25772163110,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38657064998,"f":1},"s":{"r":0,"d":0,"h":42952032294,"f":1},"n":"Order","d":2359334,"h":34362097702,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51541966886,"f":1},"s":{"r":0,"d":0,"h":55836934182,"f":1},"n":"TypeName","d":2359334,"h":47246999590,"f":1}],"l":[{"t":655361,"n":"_order","d":2359334,"h":4297326630,"f":2},{"t":1310721,"n":"_typeName","d":2359334,"h":8592293926,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":2359334,"h":12887261222,"f":1},{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$3","d":2359334,"h":17182228518,"f":1}],"h":2359334,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ColumnAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.ForeignKeyAttribute", ($self) => class ForeignKeyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            /*string*/ Name = null;
            static $h = 2621478;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182490662,"f":1},"n":"Name","d":2621478,"h":12887523366,"f":1}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":2621478,"h":4297588774,"f":1}],"h":2621478,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.ForeignKeyAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.InversePropertyAttribute", ($self) => class InversePropertyAttribute extends $.$spc.System.Attribute
        {
            $ctor$2(/*string*/ property)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(property, "property");
                    this.Property = property;
                }
                return this;
            }
            /*string*/ Property = null;
            static $h = 2687014;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17182556198,"f":1},"n":"Property","d":2687014,"h":12887588902,"f":1}],"c":[{"p":[{"n":"property","p":1310721}],"n":".ctor","o":"$ctor$2","d":2687014,"h":4297654310,"f":1}],"h":2687014,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.InversePropertyAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.TableAttribute", ($self) => class TableAttribute extends $.$spc.System.Attribute
        {
            /*string?*/ _schema = null;
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(name, "name");
                    this.Name = name;
                }
                return this;
            }
            /*string*/ Name = null;
            /*string? */ get Schema()
            {
                return this._schema;
            }
            /*string? */ set Schema(value)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrWhiteSpace(value, "value");
                this._schema = value;
            }
            static $h = 2818086;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477654566,"f":1},"n":"Name","d":2818086,"h":17182687270,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30067589158,"f":1},"s":{"r":0,"d":0,"h":34362556454,"f":1},"n":"Schema","d":2818086,"h":25772621862,"f":1}],"l":[{"t":1310721,"n":"_schema","d":2818086,"h":4297785382,"f":2}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":2818086,"h":8592752678,"f":1}],"h":2818086,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.TableAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute", ($self) => class NotMappedAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2752550;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2752550,"h":4297719846,"f":1}],"h":2752550,"a":[{"t":14614529,"c":21489451009,"a":[{"v":388,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.NotMappedAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.UIHintAttribute", ($self) => class UIHintAttribute extends $.$spc.System.Attribute
        {
            /*UIHintImplementation*/ _implementation = null;
            $ctor$2(/*string*/ uiHint)
            {
                this.$ctor$4(uiHint, null, $.$spc.System.Array.Empty($.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$3(/*string*/ uiHint, /*string?*/ presentationLayer)
            {
                this.$ctor$4(uiHint, presentationLayer, $.$spc.System.Array.Empty($.$spc.System.Object));
                {
                }
                return this;
            }
            $ctor$4(/*string*/ uiHint, /*string?*/ presentationLayer, /*params object?[]?*/ controlParameters)
            {
                super.$ctor$1();
                {
                    this._implementation = new $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation().$ctor$1(uiHint, presentationLayer, controlParameters);
                }
                return this;
            }
            /*string */ get UIHint()
            {
                return this._implementation.UIHint;
            }
            /*string? */ get PresentationLayer()
            {
                return this._implementation.PresentationLayer;
            }
            /*IDictionary<string, object?> */ get ControlParameters()
            {
                return this._implementation.ControlParameters;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.call(this._implementation);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let otherAttribute;
                return $.$is(obj, $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute, { set $v(v){ otherAttribute = v; } }) && $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals.call(this._implementation, otherAttribute._implementation);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.Equals.apply(this, arguments); }
            static $_UIHintImplementation;
            static get UIHintImplementation()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute;
                return $cls.$_UIHintImplementation ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation", ($self) => class UIHintImplementation extends $.$spc.System.Object
                {
                    /*object?[]?*/ _inputControlParameters = null;
                    /*IDictionary<string, object?>?*/ _controlParameters = null;
                    $ctor$1(/*string*/ uiHint, /*string?*/ presentationLayer, /*params object?[]?*/ controlParameters)
                    {
                        super.$ctor();
                        {
                            this.UIHint = uiHint;
                            this.PresentationLayer = presentationLayer;
                            if (controlParameters !== null)
                            {
                                this._inputControlParameters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [controlParameters.length], null);
                                $.$spc.System.Array.Copy(controlParameters, this._inputControlParameters, controlParameters.length);
                            }
                        }
                        return this;
                    }
                    /*string*/ UIHint = null;
                    /*string?*/ PresentationLayer = null;
                    /*IDictionary<string, object?> */ get ControlParameters()
                    {
                        return this._controlParameters ??= this.BuildControlParametersDictionary();
                    }
                    static/*conventional*/ /*int */ GetHashCode()
                    {
                        /*var*/ let a = this.UIHint ?? $.$spc.System.String.Empty;
                        /*var*/ let b = this.PresentationLayer ?? $.$spc.System.String.Empty;
                        return $.$spc.System.String.GetHashCode.call(a) ^ $.$spc.System.String.GetHashCode.call(b);
                    }
                    //Static convention instance redirect
                    /*int */ GetHashCode() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.GetHashCode.apply(this, arguments); }
                    static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
                    {
                        /*var*/ let otherImplementation = $.$as(obj, $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation);
                        if (otherImplementation === null || $.$spc.System.String.op_Inequality(this.UIHint, otherImplementation.UIHint) || $.$spc.System.String.op_Inequality(this.PresentationLayer, otherImplementation.PresentationLayer))
                        {
                            return false;
                        }
                        /*IDictionary<string, object?>*/ let leftParams;
                        /*IDictionary<string, object?>*/ let rightParams;
                        try
                        {
                            leftParams = this.ControlParameters;
                            rightParams = otherImplementation.ControlParameters;
                        }
                        catch($e)
                        {
                            return false;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(leftParams !== null, "leftParams shouldn't be null");
                        $.$spc.System.Diagnostics.Debug.Assert$1(rightParams !== null, "rightParams shouldn't be null");
                        if (leftParams.System$Collections$Generic$ICollection$$$Count !== rightParams.System$Collections$Generic$ICollection$$$Count)
                        {
                            return false;
                        }
                        return $.$sl.System.Linq.Enumerable.SequenceEqual($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$sl.System.Linq.Enumerable.OrderBy($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String, leftParams, new ($.$spc.System.Func$$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Key;
                        })), $.$sl.System.Linq.Enumerable.OrderBy($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String, rightParams, new ($.$spc.System.Func$$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Key;
                        })));
                    }
                    //Static convention instance redirect
                    /*bool */ Equals() { return $.$sca.System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation.Equals.apply(this, arguments); }
                    /*Dictionary<string, object?> */ BuildControlParametersDictionary()
                    {
                        /*var*/ let controlParameters = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$1();
                        /*object?[]?*/ let inputControlParameters = this._inputControlParameters;
                        if (inputControlParameters === null || inputControlParameters.length === 0)
                        {
                            return controlParameters;
                        }
                        if (inputControlParameters.length % 2 !== 0)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.UIHintImplementation_NeedEvenNumberOfControlParameters);
                        }
                        for(/*int*/ let i = 0; i < inputControlParameters.length; i += 2)
                        {
                            /*object?*/ let key = $.$spc.System.Array.$ReadT1.call(inputControlParameters, i);
                            /*object?*/ let value = $.$spc.System.Array.$ReadT1.call(inputControlParameters, ((i + 1) | 0));
                            if (key === null)
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format($.$sca.System.SR.UIHintImplementation_ControlParameterKeyIsNull, $.$box(i, $.$spc.System.Int32)));
                            }
                            let keyString;
                            if (!($.$is(key, $.$spc.System.String, { set $v(v){ keyString = v; } })))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.UIHintImplementation_ControlParameterKeyIsNotAString, $.$box(i, $.$spc.System.Int32), $.$spc.System.Object.ToString.call($.$spc.System.Array.$ReadT1.call(inputControlParameters, i))));
                            }
                            if (controlParameters.ContainsKey(keyString))
                            {
                                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.UIHintImplementation_ControlParameterKeyOccursMoreThanOnce, $.$box(i, $.$spc.System.Int32), keyString));
                            }
                            controlParameters.set_Item(keyString, value);
                        }
                        return controlParameters;
                    }
                    static $h = 3080230;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25772884006,"f":1},"n":"UIHint","d":3080230,"h":21477916710,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38657785894,"f":1},"n":"PresentationLayer","d":3080230,"h":34362818598,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":47247720486,"f":1},"n":"ControlParameters","d":3080230,"h":42952753190,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":3080230,"h":51542687782,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":3080230,"h":55837655078,"f":32769},{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"n":"BuildControlParametersDictionary","d":3080230,"h":60132622374,"f":2}],"l":[{"t":0,"n":"_inputControlParameters","d":3080230,"h":4298047526,"f":2},{"t":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"n":"_controlParameters","d":3080230,"h":8593014822,"f":2}],"c":[{"p":[{"n":"uiHint","p":1310721},{"n":"presentationLayer","p":1310721},{"n":"controlParameters","p":0,"f":16}],"n":".ctor","o":"$ctor$1","d":3080230,"h":12887982118,"f":1}],"d":3014694,"h":3080230}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.UIHintAttribute.UIHintImplementation`; }
                }, $cls, ($v) => $cls.$_UIHintImplementation = $v);
            }
            static $h = 3014694;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":25772818470,"f":1},"n":"UIHint","d":3014694,"h":21477851174,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34362753062,"f":1},"n":"PresentationLayer","d":3014694,"h":30067785766,"f":1},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":42952687654,"f":1},"n":"ControlParameters","d":3014694,"h":38657720358,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":3014694,"h":47247654950,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":3014694,"h":51542622246,"f":32769}],"l":[{"t":3080230,"n":"_implementation","d":3014694,"h":4297981990,"f":2}],"c":[{"p":[{"n":"uiHint","p":1310721}],"n":".ctor","o":"$ctor$2","d":3014694,"h":8592949286,"f":1},{"p":[{"n":"uiHint","p":1310721},{"n":"presentationLayer","p":1310721}],"n":".ctor","o":"$ctor$3","d":3014694,"h":12887916582,"f":1},{"p":[{"n":"uiHint","p":1310721},{"n":"presentationLayer","p":1310721},{"n":"controlParameters","p":0,"f":16}],"n":".ctor","o":"$ctor$4","d":3014694,"h":17182883878,"f":1}],"j":[3080230],"h":3014694,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.UIHintAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.TimestampAttribute", ($self) => class TimestampAttribute extends $.$spc.System.Attribute
        {
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 2949158;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"c":[{"n":".ctor","o":"$ctor$2","d":2949158,"h":4297916454,"f":1}],"h":2949158,"a":[{"t":14614529,"c":21489451009,"a":[{"v":384,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.TimestampAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor", ($self) => class AssociatedMetadataTypeTypeDescriptor extends $.$sct.System.ComponentModel.CustomTypeDescriptor
        {
            /*Type?*/ AssociatedMetadataType = null;
            /*bool*/ IsSelfAssociated = false;
            $ctor$3(/*ICustomTypeDescriptor?*/ parent, /*Type*/ type, /*Type?*/ associatedMetadataType)
            {
                super.$ctor$2(parent);
                {
                    this.AssociatedMetadataType = associatedMetadataType ?? $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.GetAssociatedMetadataType(type);
                    this.IsSelfAssociated = ($.$spc.System.Type.op_Equality$1(type, this.AssociatedMetadataType));
                    if ($.$spc.System.Type.op_Inequality$1(this.AssociatedMetadataType, null))
                    {
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.ValidateMetadataType(type, this.AssociatedMetadataType);
                    }
                }
                return this;
            }
            /*PropertyDescriptorCollection */ GetProperties$1(/*Attribute[]?*/ attributes)
            {
                return this.GetPropertiesWithMetadata(super.GetProperties$1(attributes));
            }
            /*PropertyDescriptorCollection */ GetProperties()
            {
                return this.GetPropertiesWithMetadata(super.GetProperties());
            }
            /*PropertyDescriptorCollection */ GetPropertiesWithMetadata(/*PropertyDescriptorCollection*/ originalCollection)
            {
                if ($.$spc.System.Type.op_Equality$1(this.AssociatedMetadataType, null))
                {
                    return originalCollection;
                }
                /*bool*/ let customDescriptorsCreated = false;
                /*List<PropertyDescriptor>*/ let tempPropertyDescriptors = new ($.$spc.System.Collections.Generic.List$$($.$sct.System.ComponentModel.PropertyDescriptor))().$ctor$1();
                var $en2 = originalCollection.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var propDescriptor = $en2.Current;
                    {
                        /*Attribute[]*/ let newMetadata = $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.GetAssociatedMetadata(this.AssociatedMetadataType, propDescriptor.Name);
                        /*PropertyDescriptor*/ let descriptor = propDescriptor;
                        if (newMetadata.length > 0)
                        {
                            descriptor = new $.$sca.System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper().$ctor$8(propDescriptor, newMetadata);
                            customDescriptorsCreated = true;
                        }
                        tempPropertyDescriptors.Add(descriptor);
                    }
                }
                if (customDescriptorsCreated)
                {
                    return new $.$sct.System.ComponentModel.PropertyDescriptorCollection().$ctor$2(tempPropertyDescriptors.ToArray(), true);
                }
                return originalCollection;
            }
            /*AttributeCollection */ GetAttributes()
            {
                /*AttributeCollection*/ let attributes = super.GetAttributes();
                if ($.$spc.System.Type.op_Inequality$1(this.AssociatedMetadataType, null) && !this.IsSelfAssociated)
                {
                    /*Attribute[]*/ let newAttributes = $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Attribute, $.$sl.System.Linq.Enumerable.OfType($.$spc.System.Attribute, $.$sct.System.ComponentModel.TypeDescriptor.GetAttributes(this.AssociatedMetadataType)));
                    attributes = $.$sct.System.ComponentModel.AttributeCollection.FromExisting(attributes, newAttributes);
                }
                return attributes;
            }
            static $_TypeDescriptorCache;
            static get TypeDescriptorCache()
            {
                let $cls = $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor;
                return $cls.$_TypeDescriptorCache ??= $asm.$ncls("$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache", ($self) => class TypeDescriptorCache
                {
                    /*ConcurrentDictionary<Type, Type?>*/ static s_metadataTypeCache = null;
                    /*ConcurrentDictionary<(Type, string), Attribute[]>*/ static s_typeMemberCache = null;
                    /*ConcurrentDictionary<(Type, Type), bool>*/ static s_validatedMetadataTypeCache = null;
                    static /*void */ ValidateMetadataType(/*Type*/ type, /*Type*/ associatedType)
                    {
                        /*(Type, Type)*/ let typeTuple = new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Type))().$ctor$2(type, associatedType);
                        if (!$.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_validatedMetadataTypeCache.ContainsKey(typeTuple.Clone()))
                        {
                            $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.CheckAssociatedMetadataType(type, associatedType);
                            $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_validatedMetadataTypeCache.TryAdd(typeTuple.Clone(), true);
                        }
                    }
                    static /*Type? */ GetAssociatedMetadataType(/*Type*/ type)
                    {
                        /*Type?*/ let associatedMetadataType;
                        if (TryGetAssociatedMetadataTypeFromCache(type, $.$ref(() => associatedMetadataType, ($v) => associatedMetadataType = $v, $.$spc.System.Type)))
                        {
                            return associatedMetadataType;
                        }
                        /*MetadataTypeAttribute?*/ let attribute = $.$cast($.$spc.System.Attribute.GetCustomAttribute$2(type, $.$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute.$type), $.$sca.System.ComponentModel.DataAnnotations.MetadataTypeAttribute);
                        if (attribute !== null)
                        {
                            associatedMetadataType = attribute.MetadataClassType;
                        }
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_metadataTypeCache.TryAdd(type, associatedMetadataType);
                        return associatedMetadataType;
                        /*static bool*/  function TryGetAssociatedMetadataTypeFromCache(/*Type*/ type, /*out Type?*/ associatedMetadataType)
                        {
                            return $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_metadataTypeCache.TryGetValue(type, associatedMetadataType);
                        }
                    }
                    static /*void */ CheckAssociatedMetadataType(/*Type*/ mainType, /*Type*/ associatedMetadataType)
                    {
                        /*HashSet<string>*/ let mainTypeMemberNames = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$4($.$sl.System.Linq.Enumerable.Select($.$spc.System.Reflection.PropertyInfo, $.$spc.System.String, mainType.GetProperties(), new ($.$spc.System.Func$$$($.$spc.System.Reflection.PropertyInfo, $.$spc.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Name;
                        })));
                        /*var*/ let buddyFields = $.$sl.System.Linq.Enumerable.Select($.$spc.System.Reflection.FieldInfo, $.$spc.System.String, associatedMetadataType.GetFields(), new ($.$spc.System.Func$$$($.$spc.System.Reflection.FieldInfo, $.$spc.System.String))().$ctor(this,  (/**/ f) =>
                        {
                            return f.Name;
                        }));
                        /*var*/ let buddyProperties = $.$sl.System.Linq.Enumerable.Select($.$spc.System.Reflection.PropertyInfo, $.$spc.System.String, associatedMetadataType.GetProperties(), new ($.$spc.System.Func$$$($.$spc.System.Reflection.PropertyInfo, $.$spc.System.String))().$ctor(this,  (/*p*/ p) =>
                        {
                            return p.Name;
                        }));
                        /*HashSet<string>*/ let buddyTypeMembers = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$5($.$sl.System.Linq.Enumerable.Concat($.$spc.System.String, buddyFields, buddyProperties), $.$spc.System.StringComparer.Ordinal);
                        if (!buddyTypeMembers.IsSubsetOf(mainTypeMemberNames))
                        {
                            buddyTypeMembers.ExceptWith(mainTypeMemberNames);
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.AssociatedMetadataTypeTypeDescriptor_MetadataTypeContainsUnknownProperties, mainType.FullName, $.$spc.System.String.Join$2(", ", $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.String, buddyTypeMembers))));
                        }
                    }
                    static /*Attribute[] */ GetAssociatedMetadata(/*Type*/ type, /*string*/ memberName)
                    {
                        /*(Type, string)*/ let memberTuple = new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String))().$ctor$2(type, memberName);
                        /*Attribute[]?*/ let attributes;
                        if ($.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_typeMemberCache.TryGetValue(memberTuple.Clone(), $.$ref(() => attributes, ($v) => attributes = $v, $.$typeArray($.$spc.System.Attribute))))
                        {
                            return attributes;
                        }
                        /*MemberTypes*/ let allowedMemberTypes = 16/*MemberTypes.Property*/ | 4/*MemberTypes.Field*/;
                        /*BindingFlags*/ let searchFlags = 16/*BindingFlags.Public*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/;
                        /*MemberInfo?*/ let matchingMember = $.$sl.System.Linq.Enumerable.FirstOrDefault($.$spc.System.Reflection.MemberInfo, type.GetMember$2(memberName, allowedMemberTypes, searchFlags));
                        if ($.$spc.System.Reflection.MemberInfo.op_Inequality(matchingMember, null))
                        {
                            attributes = $.$spc.System.Attribute.GetCustomAttributes$5(matchingMember, true);
                        }
                        else 
                        {
                            attributes = $.$spc.System.Array.Empty($.$spc.System.Attribute);
                        }
                        $.$sca.System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache.s_typeMemberCache.TryAdd(memberTuple.Clone(), attributes);
                        return attributes;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_metadataTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Type))().$ctor$1();
                        }
                        {
                            this.s_typeMemberCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String), $.$typeArray($.$spc.System.Attribute)))().$ctor$1();
                        }
                        {
                            this.s_validatedMetadataTypeCache = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Type), $.$spc.System.Boolean))().$ctor$1();
                        }
                    }
                    static $h = 262182;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"type","p":142606337},{"n":"associatedType","p":142606337}],"n":"ValidateMetadataType","d":262182,"h":17180131366,"f":33},{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetAssociatedMetadataType","d":262182,"h":21475098662,"f":33},{"r":65537,"p":[{"n":"mainType","p":142606337},{"n":"associatedMetadataType","p":142606337}],"n":"CheckAssociatedMetadataType","d":262182,"h":25770065958,"f":34},{"r":0,"p":[{"n":"type","p":142606337},{"n":"memberName","p":1310721}],"n":"GetAssociatedMetadata","d":262182,"h":30065033254,"f":33}],"l":[{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$spc.System.Type).$h,"n":"s_metadataTypeCache","d":262182,"h":4295229478,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.String), $.$typeArray($.$spc.System.Attribute)).$h,"n":"s_typeMemberCache","d":262182,"h":8590196774,"f":34},{"t":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$spc.System.Type), $.$spc.System.Boolean).$h,"n":"s_validatedMetadataTypeCache","d":262182,"h":12885164070,"f":34}],"d":196646,"h":262182}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor.TypeDescriptorCache`; }
                }, $cls, ($v) => $cls.$_TypeDescriptorCache = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsSelfAssociated = false;
            }
            static $h = 196646;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2883624,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":12885098534,"f":2},"s":{"r":0,"d":0,"h":17180065830,"f":2},"n":"AssociatedMetadataType","d":196646,"h":8590131238,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":30064967718,"f":2},"s":{"r":0,"d":0,"h":34359935014,"f":2},"n":"IsSelfAssociated","d":196646,"h":25770000422,"f":2}],"m":[{"r":14090280,"p":[{"n":"attributes","p":0}],"n":"GetProperties","o":"@$1","d":196646,"h":42949869606,"f":32769},{"r":14090280,"n":"GetProperties","d":196646,"h":47244836902,"f":32769},{"r":14090280,"p":[{"n":"originalCollection","p":14090280}],"n":"GetPropertiesWithMetadata","d":196646,"h":51539804198,"f":2},{"r":1179688,"n":"GetAttributes","d":196646,"h":55834771494,"f":32769}],"c":[{"p":[{"n":"parent","p":10616872},{"n":"type","p":142606337},{"n":"associatedMetadataType","p":142606337}],"n":".ctor","o":"$ctor$3","d":196646,"h":38654902310,"f":1}],"i":[10616872],"j":[262182],"h":196646}; }
            static get $b() { return $.$sct.System.ComponentModel.CustomTypeDescriptor; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sct.System.ComponentModel.ICustomTypeDescriptor ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AssociatedMetadataTypeTypeDescriptor`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CustomValidationAttribute", ($self) => class CustomValidationAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            /*Lazy<string?>*/ _malformedErrorMessage = null;
            /*bool*/ _isSingleArgumentMethod = false;
            /*string?*/ _lastMessage = null;
            /*MethodInfo?*/ _methodInfo = null;
            /*Type?*/ _firstParameterType = null;
            /*Tuple<string, Type>?*/ _typeId = null;
            $ctor$6(/*Type*/ validatorType, /*string*/ method)
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.CustomValidationAttribute_ValidationError;
                }));
                {
                    this.ValidatorType = validatorType;
                    this.Method = method;
                    this._malformedErrorMessage = new ($.$spc.System.Lazy$$($.$spc.System.String))().$ctor$3(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this, this.CheckAttributeWellFormed));
                }
                return this;
            }
            /*Type*/ ValidatorType = null;
            /*object */ get TypeId()
            {
                return this._typeId ??= new ($.$spc.System.Tuple$$$($.$spc.System.String, $.$spc.System.Type))().$ctor$1(this.Method, this.ValidatorType);
            }
            /*string*/ Method = null;
            /*bool */ get RequiresValidationContext()
            {
                this.ThrowIfAttributeNotWellFormed();
                return !this._isSingleArgumentMethod;
            }
            /*ValidationResult? */ IsValid$1(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                this.ThrowIfAttributeNotWellFormed();
                /*var*/ let methodInfo = this._methodInfo;
                /*object?*/ let convertedValue;
                if (!this.TryConvertValue(value, $.$ref(() => convertedValue, ($v) => convertedValue = $v, $.$spc.System.Object)))
                {
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1($.$sca.System.SR.Format$3($.$sca.System.SR.CustomValidationAttribute_Type_Conversion_Failed, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ (value !== null ? $.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(value)) : "null"), this._firstParameterType, this.ValidatorType, this.Method ], null, null)));
                }
                try
                {
                    /*var*/ let methodParams = this._isSingleArgumentMethod ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [convertedValue], [-1], null) : $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [convertedValue, validationContext], null, null);
                    /*var*/ let result = $.$cast(methodInfo.Invoke(null, methodParams), $.$sca.System.ComponentModel.DataAnnotations.ValidationResult);
                    this._lastMessage = null;
                    if (result !== null)
                    {
                        this._lastMessage = result.ErrorMessage;
                    }
                    return result;
                }
                catch(tie)
                {
                    throw tie.InnerException;
                }
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                this.ThrowIfAttributeNotWellFormed();
                if (!$.$spc.System.String.IsNullOrEmpty(this._lastMessage))
                {
                    return $.$spc.System.String.Format$5($.$spc.System.Globalization.CultureInfo.CurrentCulture, this._lastMessage, name);
                }
                return super.FormatErrorMessage(name);
            }
            /*string? */ CheckAttributeWellFormed()
            {
                return this.ValidateValidatorTypeParameter() ?? this.ValidateMethodParameter();
            }
            /*string? */ ValidateValidatorTypeParameter()
            {
                if ($.$spc.System.Type.op_Equality$1(this.ValidatorType, null))
                {
                    return $.$sca.System.SR.CustomValidationAttribute_ValidatorType_Required;
                }
                if (!this.ValidatorType.IsVisible)
                {
                    return $.$sca.System.SR.Format($.$sca.System.SR.CustomValidationAttribute_Type_Must_Be_Public, this.ValidatorType.Name);
                }
                return null;
            }
            /*string? */ ValidateMethodParameter()
            {
                if ($.$spc.System.String.IsNullOrEmpty(this.Method))
                {
                    return $.$sca.System.SR.CustomValidationAttribute_Method_Required;
                }
                /*var*/ let methodInfo = $.$sl.System.Linq.Enumerable.SingleOrDefault$2($.$spc.System.Reflection.MethodInfo, this.ValidatorType.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/), new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$spc.System.Boolean))().$ctor(this,  (/**/ m) =>
                {
                    return $.$spc.System.String.Equals$5(m.Name, this.Method, 4/*StringComparison.Ordinal*/);
                }));
                if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(methodInfo, null))
                {
                    return $.$sca.System.SR.Format$1($.$sca.System.SR.CustomValidationAttribute_Method_Not_Found, this.Method, this.ValidatorType.Name);
                }
                if (!$.$sca.System.ComponentModel.DataAnnotations.ValidationResult.$type.IsAssignableFrom(methodInfo.ReturnType))
                {
                    return $.$sca.System.SR.Format$1($.$sca.System.SR.CustomValidationAttribute_Method_Must_Return_ValidationResult, this.Method, this.ValidatorType.Name);
                }
                /*ParameterInfo[]*/ let parameterInfos = methodInfo.GetParameters();
                if (parameterInfos.length === 0 || $.$spc.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType.IsByRef)
                {
                    return $.$sca.System.SR.Format$1($.$sca.System.SR.CustomValidationAttribute_Method_Signature, this.Method, this.ValidatorType.Name);
                }
                this._isSingleArgumentMethod = (parameterInfos.length === 1);
                if (!this._isSingleArgumentMethod)
                {
                    if ((parameterInfos.length !== 2) || ($.$spc.System.Type.op_Inequality$1($.$spc.System.Array.$ReadT1.call(parameterInfos, 1).ParameterType, $.$sca.System.ComponentModel.DataAnnotations.ValidationContext.$type)))
                    {
                        return $.$sca.System.SR.Format$1($.$sca.System.SR.CustomValidationAttribute_Method_Signature, this.Method, this.ValidatorType.Name);
                    }
                }
                this._methodInfo = methodInfo;
                this._firstParameterType = $.$spc.System.Array.$ReadT1.call(parameterInfos, 0).ParameterType;
                return null;
            }
            /*void */ ThrowIfAttributeNotWellFormed()
            {
                /*string?*/ let errorMessage = this._malformedErrorMessage.Value;
                if ($.$spc.System.String.op_Inequality(errorMessage, null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10(errorMessage);
                }
            }
            /*bool */ TryConvertValue(/*object?*/ value, /*out object?*/ convertedValue)
            {
                convertedValue.$v = null;
                /*var*/ let expectedValueType = this._firstParameterType;
                if (value === null)
                {
                    if (expectedValueType.IsValueType && (!expectedValueType.IsGenericType || $.$spc.System.Type.op_Inequality$1(expectedValueType.GetGenericTypeDefinition(), $.$spc.System.Nullable$$().$type)))
                    {
                        return false;
                    }
                    return true;
                }
                if (expectedValueType.IsInstanceOfType(value))
                {
                    convertedValue.$v = value;
                    return true;
                }
                try
                {
                    convertedValue.$v = $.$spc.System.Convert.ChangeType$3(value, expectedValueType, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$spc.System.InvalidCastException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$spc.System.NotSupportedException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            static $h = 720934;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":42950393894,"f":1},"n":"ValidatorType","d":720934,"h":38655426598,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":51540328486,"f":32769},"n":"TypeId","d":720934,"h":47245361190,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":64425230374,"f":1},"n":"Method","d":720934,"h":60130263078,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":73015164966,"f":32769},"n":"RequiresValidationContext","d":720934,"h":68720197670,"f":32769}],"m":[{"r":3670054,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"IsValid","o":"@$1","d":720934,"h":77310132262,"f":32772},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":720934,"h":81605099558,"f":32769},{"r":1310721,"n":"CheckAttributeWellFormed","d":720934,"h":85900066854,"f":2},{"r":1310721,"n":"ValidateValidatorTypeParameter","d":720934,"h":90195034150,"f":2},{"r":1310721,"n":"ValidateMethodParameter","d":720934,"h":94490001446,"f":2},{"r":65537,"n":"ThrowIfAttributeNotWellFormed","d":720934,"h":98784968742,"f":2},{"r":262145,"p":[{"n":"value","p":131073},{"n":"convertedValue","p":131073,"f":2}],"n":"TryConvertValue","d":720934,"h":103079936038,"f":2}],"l":[{"t":$.$spc.System.Lazy$$($.$spc.System.String).$h,"n":"_malformedErrorMessage","d":720934,"h":4295688230,"f":2},{"t":262145,"n":"_isSingleArgumentMethod","d":720934,"h":8590655526,"f":2},{"t":1310721,"n":"_lastMessage","d":720934,"h":12885622822,"f":2},{"t":79626241,"n":"_methodInfo","d":720934,"h":17180590118,"f":2},{"t":142606337,"n":"_firstParameterType","d":720934,"h":21475557414,"f":2},{"t":$.$spc.System.Tuple$$$($.$spc.System.String, $.$spc.System.Type).$h,"n":"_typeId","d":720934,"h":25770524710,"f":2}],"c":[{"p":[{"n":"validatorType","p":142606337},{"n":"method","p":1310721}],"n":".ctor","o":"$ctor$6","d":720934,"h":30065492006,"f":1}],"h":720934,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2500,"t":14548993}],"n":[{"n":"AllowMultiple","v":true,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CustomValidationAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.AllowedValuesAttribute", ($self) => class AllowedValuesAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*params object?[]*/ values)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(values, "values");
                    this.Values = values;
                    this.DefaultErrorMessage = $.$sca.System.SR.AllowedValuesAttribute_Invalid;
                }
                return this;
            }
            /*object?[]*/ Values = null;
            /*bool */ IsValid(/*object?*/ value)
            {
                let $i1 = 0;
                let $arr1 = this.Values;
                while ($i1 < $arr1.length)
                {
                    let allowed = $arr1[$i1++];
                    if (allowed === null ? value === null : $.$spc.System.Object.Equals.call(allowed, value))
                    {
                        return true;
                    }
                }
                return false;
            }
            static $h = 65574;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":0,"g":{"r":0,"d":0,"h":17179934758,"f":1},"n":"Values","d":65574,"h":12884967462,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":65574,"h":21474902054,"f":32769}],"c":[{"p":[{"n":"values","p":0,"f":16}],"n":".ctor","o":"$ctor$6","d":65574,"h":4295032870,"f":1}],"h":65574,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.AllowedValuesAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.Base64StringAttribute", ($self) => class Base64StringAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6()
            {
                super.$ctor$2();
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.Base64StringAttribute_Invalid;
                }
                return this;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!$.$is(value, $.$spc.System.String, { set $v(v){ valueAsString = v; } }))
                {
                    return false;
                }
                return $.$spc.System.Buffers.Text.Base64.IsValid($.$spc.System.String.op_Implicit(valueAsString));
            }
            static $h = 393254;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":393254,"h":8590327846,"f":32769}],"c":[{"n":".ctor","o":"$ctor$6","d":393254,"h":4295360550,"f":1}],"h":393254,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Base64StringAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CompareAttribute", ($self) => class CompareAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*string*/ otherProperty)
            {
                super.$ctor$3($.$sca.System.SR.CompareAttribute_MustMatch);
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(otherProperty, "otherProperty");
                    this.OtherProperty = otherProperty;
                }
                return this;
            }
            /*string*/ OtherProperty = null;
            /*string?*/ OtherPropertyDisplayName = null;
            /*bool */ get RequiresValidationContext()
            {
                return true;
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$6($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.OtherPropertyDisplayName ?? this.OtherProperty);
            }
            /*ValidationResult? */ IsValid$1(/*object?*/ value, /*ValidationContext*/ validationContext)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(validationContext, "validationContext");
                /*var*/ let otherPropertyInfo = $.$spc.System.Reflection.RuntimeReflectionExtensions.GetRuntimeProperty(validationContext.ObjectType, this.OtherProperty);
                if ($.$spc.System.Reflection.PropertyInfo.op_Equality$1(otherPropertyInfo, null))
                {
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1($.$sca.System.SR.Format($.$sca.System.SR.CompareAttribute_UnknownProperty, this.OtherProperty));
                }
                if (otherPropertyInfo.GetIndexParameters().length > 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.Common_PropertyNotFound, validationContext.ObjectType.FullName, this.OtherProperty));
                }
                /*object?*/ let otherPropertyValue = otherPropertyInfo.GetValue$1(validationContext.ObjectInstance, null);
                if (!$.$spc.System.Object.Equals$1(value, otherPropertyValue))
                {
                    this.OtherPropertyDisplayName ??= this.GetDisplayNameForProperty(otherPropertyInfo);
                    /*string[]?*/ let memberNames = $.$spc.System.String.op_Inequality(validationContext.MemberName, null) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), [validationContext.MemberName], null, null) : null;
                    return new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$2(this.FormatErrorMessage(validationContext.DisplayName), memberNames);
                }
                return null;
            }
            /*string? */ GetDisplayNameForProperty(/*PropertyInfo*/ property)
            {
                /*IEnumerable<Attribute>*/ let attributes = $.$spc.System.Reflection.CustomAttributeExtensions.GetCustomAttributes$4(property, true);
                var $en2 = attributes.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var attribute = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let display;
                        if ($.$is(attribute, $.$sca.System.ComponentModel.DataAnnotations.DisplayAttribute, { set $v(v){ display = v; } }))
                        {
                            return display.GetName();
                        }
                    }
                }
                return this.OtherProperty;
            }
            static $h = 458790;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17180327974,"f":1},"n":"OtherProperty","d":458790,"h":12885360678,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065229862,"f":1},"s":{"r":0,"d":0,"h":34360197158,"f":8},"n":"OtherPropertyDisplayName","d":458790,"h":25770262566,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950131750,"f":32769},"n":"RequiresValidationContext","d":458790,"h":38655164454,"f":32769}],"m":[{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":458790,"h":47245099046,"f":32769},{"r":3670054,"p":[{"n":"value","p":131073},{"n":"validationContext","p":3538982}],"n":"IsValid","o":"@$1","d":458790,"h":51540066342,"f":32772},{"r":1310721,"p":[{"n":"property","p":81657857}],"n":"GetDisplayNameForProperty","d":458790,"h":55835033638,"f":2}],"c":[{"p":[{"n":"otherProperty","p":1310721}],"n":".ctor","o":"$ctor$6","d":458790,"h":4295426086,"f":1}],"h":458790,"a":[{"t":14614529,"c":21489451009,"a":[{"v":128,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CompareAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute", ($self) => class DataTypeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            /*string[]*/ static _dataTypeStrings = null;
            $ctor$6(/*DataType*/ dataType)
            {
                super.$ctor$2();
                {
                    this.DataType = dataType;
                    switch(dataType)
                    {
                        case 2/*DataType.Date*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:d}";
                        this.DisplayFormat.ApplyFormatInEditMode = true;
                        break;
                        case 3/*DataType.Time*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:t}";
                        this.DisplayFormat.ApplyFormatInEditMode = true;
                        break;
                        case 6/*DataType.Currency*/:
                        this.DisplayFormat = new $.$sca.System.ComponentModel.DataAnnotations.DisplayFormatAttribute().$ctor$2();
                        this.DisplayFormat.DataFormatString = "{0:C}";
                        break;
                    }
                }
                return this;
            }
            $ctor$7(/*string*/ customDataType)
            {
                this.$ctor$6(0/*DataType.Custom*/);
                {
                    this.CustomDataType = customDataType;
                }
                return this;
            }
            /*DataType*/ DataType = 0;
            /*string?*/ CustomDataType = null;
            /*DisplayFormatAttribute?*/ DisplayFormat = null;
            /*string */ GetDataTypeName()
            {
                this.EnsureValidDataType();
                if (this.DataType === 0/*DataType.Custom*/)
                {
                    return this.CustomDataType;
                }
                return $.$spc.System.Array.$ReadT1.call($.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute._dataTypeStrings, this.DataType);
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                this.EnsureValidDataType();
                return true;
            }
            /*void */ EnsureValidDataType()
            {
                if (this.DataType === 0/*DataType.Custom*/ && $.$spc.System.String.IsNullOrWhiteSpace(this.CustomDataType))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.DataTypeAttribute_EmptyDataTypeString);
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.DataType = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this._dataTypeStrings = $.$spc.System.Enum.GetNames($.$sca.System.ComponentModel.DataAnnotations.DataType);
                }
            }
            static $h = 852006;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":786470,"g":{"r":0,"d":0,"h":25770655782,"f":1},"n":"DataType","d":852006,"h":21475688486,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655557670,"f":1},"n":"CustomDataType","d":852006,"h":34360590374,"f":1},{"p":1114150,"g":{"r":0,"d":0,"h":51540459558,"f":1},"s":{"r":0,"d":0,"h":55835426854,"f":4},"n":"DisplayFormat","d":852006,"h":47245492262,"f":1}],"m":[{"r":1310721,"n":"GetDataTypeName","d":852006,"h":60130394150,"f":129},{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":852006,"h":64425361446,"f":32769},{"r":65537,"n":"EnsureValidDataType","d":852006,"h":68720328742,"f":2}],"l":[{"t":0,"n":"_dataTypeStrings","d":852006,"h":4295819302,"f":34}],"c":[{"p":[{"n":"dataType","p":786470}],"n":".ctor","o":"$ctor$6","d":852006,"h":8590786598,"f":1},{"p":[{"n":"customDataType","p":1310721}],"n":".ctor","o":"$ctor$7","d":852006,"h":12885753894,"f":1}],"h":852006,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2496,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DataTypeAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.DeniedValuesAttribute", ($self) => class DeniedValuesAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*params object?[]*/ values)
            {
                super.$ctor$2();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(values, "values");
                    this.Values = values;
                    this.DefaultErrorMessage = $.$sca.System.SR.DeniedValuesAttribute_Invalid;
                }
                return this;
            }
            /*object?[]*/ Values = null;
            /*bool */ IsValid(/*object?*/ value)
            {
                let $i1 = 0;
                let $arr1 = this.Values;
                while ($i1 < $arr1.length)
                {
                    let denied = $arr1[$i1++];
                    if (denied === null ? value === null : $.$spc.System.Object.Equals.call(denied, value))
                    {
                        return false;
                    }
                }
                return true;
            }
            static $h = 917542;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":0,"g":{"r":0,"d":0,"h":17180786726,"f":1},"n":"Values","d":917542,"h":12885819430,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":917542,"h":21475754022,"f":32769}],"c":[{"p":[{"n":"values","p":0,"f":16}],"n":".ctor","o":"$ctor$6","d":917542,"h":4295884838,"f":1}],"h":917542,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DeniedValuesAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper", ($self) => class MetadataPropertyDescriptorWrapper extends $.$sct.System.ComponentModel.PropertyDescriptor
        {
            /*PropertyDescriptor*/ _descriptor = null;
            /*bool*/ _isReadOnly = false;
            $ctor$8(/*PropertyDescriptor*/ descriptor, /*Attribute[]*/ newAttributes)
            {
                super.$ctor$7(descriptor, newAttributes);
                {
                    this._descriptor = descriptor;
                    let $i1 = 0;
                    let $arr1 = newAttributes;
                    while ($i1 < $arr1.length)
                    {
                        let attribute = $arr1[$i1++];
                        let readOnlyAttribute;
                        if ($.$is(attribute, $.$scp.System.ComponentModel.ReadOnlyAttribute, { set $v(v){ readOnlyAttribute = v; } }))
                        {
                            this._isReadOnly = readOnlyAttribute.IsReadOnly;
                            break;
                        }
                    }
                }
                return this;
            }
            /*void */ AddValueChanged(/*object*/ component, /*EventHandler*/ handler)
            {
                this._descriptor.AddValueChanged(component, handler);
            }
            /*bool */ CanResetValue(/*object*/ component)
            {
                return this._descriptor.CanResetValue(component);
            }
            /*Type */ get ComponentType()
            {
                return this._descriptor.ComponentType;
            }
            /*object? */ GetValue(/*object?*/ component)
            {
                return this._descriptor.GetValue(component);
            }
            /*bool */ get IsReadOnly()
            {
                return this._isReadOnly || this._descriptor.IsReadOnly;
            }
            /*Type */ get PropertyType()
            {
                return this._descriptor.PropertyType;
            }
            /*void */ RemoveValueChanged(/*object*/ component, /*EventHandler*/ handler)
            {
                this._descriptor.RemoveValueChanged(component, handler);
            }
            /*void */ ResetValue(/*object*/ component)
            {
                this._descriptor.ResetValue(component);
            }
            /*void */ SetValue(/*object?*/ component, /*object?*/ value)
            {
                this._descriptor.SetValue(component, value);
            }
            /*bool */ ShouldSerializeValue(/*object*/ component)
            {
                return this._descriptor.ShouldSerializeValue(component);
            }
            /*bool */ get SupportsChangeEvents()
            {
                return this._descriptor.SupportsChangeEvents;
            }
            static $h = 1835046;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14024744,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":30066606118,"f":32769},"n":"ComponentType","d":1835046,"h":25771638822,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42951508006,"f":32769},"n":"IsReadOnly","d":1835046,"h":38656540710,"f":32769},{"p":142606337,"g":{"r":0,"d":0,"h":51541442598,"f":32769},"n":"PropertyType","d":1835046,"h":47246475302,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77311246374,"f":32769},"n":"SupportsChangeEvents","d":1835046,"h":73016279078,"f":32769}],"m":[{"r":65537,"p":[{"n":"component","p":131073},{"n":"handler","p":46989313}],"n":"AddValueChanged","d":1835046,"h":17181704230,"f":32769},{"r":262145,"p":[{"n":"component","p":131073}],"n":"CanResetValue","d":1835046,"h":21476671526,"f":32769},{"r":131073,"p":[{"n":"component","p":131073}],"n":"GetValue","d":1835046,"h":34361573414,"f":32769},{"r":65537,"p":[{"n":"component","p":131073},{"n":"handler","p":46989313}],"n":"RemoveValueChanged","d":1835046,"h":55836409894,"f":32769},{"r":65537,"p":[{"n":"component","p":131073}],"n":"ResetValue","d":1835046,"h":60131377190,"f":32769},{"r":65537,"p":[{"n":"component","p":131073},{"n":"value","p":131073}],"n":"SetValue","d":1835046,"h":64426344486,"f":32769},{"r":262145,"p":[{"n":"component","p":131073}],"n":"ShouldSerializeValue","d":1835046,"h":68721311782,"f":32769}],"l":[{"t":14024744,"n":"_descriptor","d":1835046,"h":4296802342,"f":2},{"t":262145,"n":"_isReadOnly","d":1835046,"h":8591769638,"f":2}],"c":[{"p":[{"n":"descriptor","p":14024744},{"n":"newAttributes","p":0}],"n":".ctor","o":"$ctor$8","d":1835046,"h":12886736934,"f":1}],"h":1835046}; }
            static get $b() { return $.$sct.System.ComponentModel.PropertyDescriptor; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MetadataPropertyDescriptorWrapper`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.LengthAttribute", ($self) => class LengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*int*/ minimumLength, /*int*/ maximumLength)
            {
                super.$ctor$3($.$sca.System.SR.LengthAttribute_ValidationError);
                {
                    this.MinimumLength = minimumLength;
                    this.MaximumLength = maximumLength;
                }
                return this;
            }
            /*int*/ MinimumLength = 0;
            /*int*/ MaximumLength = 0;
            /*bool */ IsValid(/*object?*/ value)
            {
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$spc.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32)))
                {
                    throw new $.$spc.System.InvalidCastException().$ctor$10($.$sca.System.SR.Format($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$spc.System.Object.GetType.call(value)));
                }
                return ((((length - this.MinimumLength) | 0)) >>> 0) <= ((((this.MaximumLength - this.MinimumLength) | 0)) >>> 0);
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$7($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.MinimumLength, $.$spc.System.Int32), $.$box(this.MaximumLength, $.$spc.System.Int32));
            }
            /*void */ EnsureLegalLengths()
            {
                if (this.MinimumLength < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.LengthAttribute_InvalidMinLength);
                }
                if (this.MaximumLength < this.MinimumLength)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.LengthAttribute_InvalidMaxLength);
                }
            }
            static $h = 1638438;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181507622,"f":1},"n":"MinimumLength","d":1638438,"h":12886540326,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30066409510,"f":1},"n":"MaximumLength","d":1638438,"h":25771442214,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1638438,"h":34361376806,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":1638438,"h":38656344102,"f":32769},{"r":65537,"n":"EnsureLegalLengths","d":1638438,"h":42951311398,"f":2}],"c":[{"p":[{"n":"minimumLength","p":655361},{"n":"maximumLength","p":655361}],"n":".ctor","o":"$ctor$6","d":1638438,"h":4296605734,"f":1}],"h":1638438,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.LengthAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MinLengthAttribute", ($self) => class MinLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*int*/ length)
            {
                super.$ctor$3($.$sca.System.SR.MinLengthAttribute_ValidationError);
                {
                    this.Length = length;
                }
                return this;
            }
            /*int*/ Length = 0;
            /*bool */ IsValid(/*object?*/ value)
            {
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$spc.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32)))
                {
                    throw new $.$spc.System.InvalidCastException().$ctor$10($.$sca.System.SR.Format($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$spc.System.Object.GetType.call(value)));
                }
                return length >= this.Length;
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$6($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.Length, $.$spc.System.Int32));
            }
            /*void */ EnsureLegalLengths()
            {
                if (this.Length < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.MinLengthAttribute_InvalidMinLength);
                }
            }
            static $h = 1966118;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17181835302,"f":1},"n":"Length","d":1966118,"h":12886868006,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1966118,"h":21476802598,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":1966118,"h":25771769894,"f":32769},{"r":65537,"n":"EnsureLegalLengths","d":1966118,"h":30066737190,"f":2}],"c":[{"p":[{"n":"length","p":655361}],"n":".ctor","o":"$ctor$6","d":1966118,"h":4296933414,"f":1}],"h":1966118,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MinLengthAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RegularExpressionAttribute", ($self) => class RegularExpressionAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*string*/ pattern)
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.RegexAttribute_ValidationError;
                }));
                {
                    this.Pattern = pattern;
                    this.MatchTimeoutInMilliseconds = 2000;
                }
                return this;
            }
            /*int*/ MatchTimeoutInMilliseconds = 0;
            /*TimeSpan */ get MatchTimeout()
            {
                return $.$spc.System.TimeSpan.FromMilliseconds(BigInt(this.MatchTimeoutInMilliseconds));
            }
            /*string*/ Pattern = null;
            /*Regex?*/ Regex = null;
            /*bool */ IsValid(/*object?*/ value)
            {
                this.SetupRegex();
                /*string?*/ let stringValue = $.$spc.System.Convert.ToString$2(value, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                if ($.$spc.System.String.IsNullOrEmpty(stringValue))
                {
                    return true;
                }
                var $en2 = this.Regex.EnumerateMatches$3($.$spc.System.String.op_Implicit(stringValue)).GetEnumerator();
                while ($en2.MoveNext())
                {
                    var m = $en2.Current;
                    {
                        return m.Index === 0 && m.Length === stringValue.length;
                    }
                }
                return false;
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                this.SetupRegex();
                return $.$spc.System.String.Format$6($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.Pattern);
            }
            /*void */ SetupRegex()
            {
                if (this.Regex === null)
                {
                    if ($.$spc.System.String.IsNullOrEmpty(this.Pattern))
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.RegularExpressionAttribute_Empty_Pattern);
                    }
                    this.Regex = this.MatchTimeoutInMilliseconds === -1 ? new $.$str.System.Text.RegularExpressions.Regex().$ctor$2(this.Pattern) : new $.$str.System.Text.RegularExpressions.Regex().$ctor$4(this.Pattern, 0, $.$spc.System.TimeSpan.FromMilliseconds(BigInt(this.MatchTimeoutInMilliseconds)));
                }
            }
            static $h = 2162726;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182031910,"f":1},"s":{"r":0,"d":0,"h":21476999206,"f":1},"n":"MatchTimeoutInMilliseconds","d":2162726,"h":12887064614,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":30066933798,"f":1},"n":"MatchTimeout","d":2162726,"h":25771966502,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":42951835686,"f":1},"n":"Pattern","d":2162726,"h":38656868390,"f":1},{"p":1953158,"g":{"r":0,"d":0,"h":55836737574,"f":2},"s":{"r":0,"d":0,"h":60131704870,"f":2},"n":"Regex","d":2162726,"h":51541770278,"f":2}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":2162726,"h":64426672166,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":2162726,"h":68721639462,"f":32769},{"r":65537,"n":"SetupRegex","d":2162726,"h":73016606758,"f":2}],"c":[{"p":[{"n":"pattern","p":1310721}],"n":".ctor","o":"$ctor$6","d":2162726,"h":4297130022,"f":1}],"h":2162726,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RegularExpressionAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.StringLengthAttribute", ($self) => class StringLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*int*/ maximumLength)
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.StringLengthAttribute_ValidationError;
                }));
                {
                    this.MaximumLength = maximumLength;
                }
                return this;
            }
            /*int*/ MaximumLength = 0;
            /*int*/ MinimumLength = 0;
            /*bool */ IsValid(/*object?*/ value)
            {
                this.EnsureLegalLengths();
                if (value === null)
                {
                    return true;
                }
                /*int*/ let length = ($.$cast(value, $.$spc.System.String)).length;
                return length >= this.MinimumLength && length <= this.MaximumLength;
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                this.EnsureLegalLengths();
                /*bool*/ let useErrorMessageWithMinimum = this.MinimumLength !== 0 && !this.CustomErrorMessageSet;
                /*string*/ let errorMessage = useErrorMessageWithMinimum ? $.$sca.System.SR.StringLengthAttribute_ValidationErrorIncludingMinimum : this.ErrorMessageString;
                return $.$spc.System.String.Format$7($.$spc.System.Globalization.CultureInfo.CurrentCulture, errorMessage, name, $.$box(this.MaximumLength, $.$spc.System.Int32), $.$box(this.MinimumLength, $.$spc.System.Int32));
            }
            /*void */ EnsureLegalLengths()
            {
                if (this.MaximumLength < 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.StringLengthAttribute_InvalidMaxLength);
                }
                if (this.MaximumLength < this.MinimumLength)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.RangeAttribute_MinGreaterThanMax, $.$box(this.MaximumLength, $.$spc.System.Int32), $.$box(this.MinimumLength, $.$spc.System.Int32)));
                }
            }
            static $h = 2883622;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17182752806,"f":1},"n":"MaximumLength","d":2883622,"h":12887785510,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30067654694,"f":1},"s":{"r":0,"d":0,"h":34362621990,"f":1},"n":"MinimumLength","d":2883622,"h":25772687398,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":2883622,"h":38657589286,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":2883622,"h":42952556582,"f":32769},{"r":65537,"n":"EnsureLegalLengths","d":2883622,"h":47247523878,"f":2}],"c":[{"p":[{"n":"maximumLength","p":655361}],"n":".ctor","o":"$ctor$6","d":2883622,"h":4297850918,"f":1}],"h":2883622,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.StringLengthAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute", ($self) => class MaxLengthAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            /*int*/ static MaxAllowableLength = -1;
            $ctor$6(/*int*/ length)
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute.DefaultErrorMessageString;
                }));
                {
                    this.Length = length;
                }
                return this;
            }
            $ctor$7()
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.ComponentModel.DataAnnotations.MaxLengthAttribute.DefaultErrorMessageString;
                }));
                {
                    this.Length = -1/*MaxAllowableLength*/;
                }
                return this;
            }
            /*int*/ Length = 0;
            static /*string */ get DefaultErrorMessageString()
            {
                return $.$sca.System.SR.MaxLengthAttribute_ValidationError;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                this.EnsureLegalLengths();
                /*int*/ let length;
                if (value === null)
                {
                    return true;
                }
                let str;
                if ($.$is(value, $.$spc.System.String, { set $v(v){ str = v; } }))
                {
                    length = str.length;
                }
                else if (!$.$sca.System.ComponentModel.DataAnnotations.CountPropertyHelper.TryGetCount(value, $.$ref(() => length, ($v) => length = $v, $.$spc.System.Int32)))
                {
                    throw new $.$spc.System.InvalidCastException().$ctor$10($.$sca.System.SR.Format($.$sca.System.SR.LengthAttribute_InvalidValueType, $.$spc.System.Object.GetType.call(value)));
                }
                return -1/*MaxAllowableLength*/ === this.Length || length <= this.Length;
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$6($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, $.$box(this.Length, $.$spc.System.Int32));
            }
            /*void */ EnsureLegalLengths()
            {
                if (this.Length === 0 || this.Length < -1)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.MaxLengthAttribute_InvalidMaxLength);
                }
            }
            static $h = 1769510;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25771573286,"f":1},"n":"Length","d":1769510,"h":21476605990,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34361507878,"f":34},"n":"DefaultErrorMessageString","d":1769510,"h":30066540582,"f":34}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1769510,"h":38656475174,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":1769510,"h":42951442470,"f":32769},{"r":65537,"n":"EnsureLegalLengths","d":1769510,"h":47246409766,"f":2}],"l":[{"t":655361,"n":"MaxAllowableLength","d":1769510,"h":4296736806,"f":34}],"c":[{"p":[{"n":"length","p":655361}],"n":".ctor","o":"$ctor$6","d":1769510,"h":8591704102,"f":1},{"n":".ctor","o":"$ctor$7","d":1769510,"h":12886671398,"f":1}],"h":1769510,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.MaxLengthAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RequiredAttribute", ($self) => class RequiredAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6()
            {
                super.$ctor$4(new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this,  () =>
                {
                    return $.$sca.System.SR.RequiredAttribute_ValidationError;
                }));
                {
                }
                return this;
            }
            /*bool*/ AllowEmptyStrings = false;
            /*bool */ IsValid(/*object?*/ value)
            {
                if (value === null)
                {
                    return false;
                }
                let stringValue;
                return this.AllowEmptyStrings || !$.$is(value, $.$spc.System.String, { set $v(v){ stringValue = v; } }) || !$.$spc.System.String.IsNullOrWhiteSpace(stringValue);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AllowEmptyStrings = false;
            }
            static $h = 2228262;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17182097446,"f":1},"s":{"r":0,"d":0,"h":21477064742,"f":1},"n":"AllowEmptyStrings","d":2228262,"h":12887130150,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":2228262,"h":25772032038,"f":32769}],"c":[{"n":".ctor","o":"$ctor$6","d":2228262,"h":4297195558,"f":1}],"h":2228262,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RequiredAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.RangeAttribute", ($self) => class RangeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute
        {
            $ctor$6(/*int*/ minimum, /*int*/ maximum)
            {
                super.$ctor$5(false);
                {
                    this.Minimum = $.$box(minimum, $.$spc.System.Int32);
                    this.Maximum = $.$box(maximum, $.$spc.System.Int32);
                    this.OperandType = $.$spc.System.Int32.$type;
                    this.ErrorMessageResourceAccessor = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            $ctor$7(/*double*/ minimum, /*double*/ maximum)
            {
                super.$ctor$5(false);
                {
                    this.Minimum = $.$box(minimum, $.$spc.System.Double);
                    this.Maximum = $.$box(maximum, $.$spc.System.Double);
                    this.OperandType = $.$spc.System.Double.$type;
                    this.ErrorMessageResourceAccessor = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            $ctor$8(/*Type*/ type, /*string*/ minimum, /*string*/ maximum)
            {
                super.$ctor$5(false);
                {
                    this.OperandType = type;
                    this.Minimum = minimum;
                    this.Maximum = maximum;
                    this.ErrorMessageResourceAccessor = new ($.$spc.System.Func$$($.$spc.System.String))().$ctor(this, this.GetValidationErrorMessage);
                }
                return this;
            }
            /*object*/ Minimum = null;
            /*object*/ Maximum = null;
            /*bool*/ MinimumIsExclusive = false;
            /*bool*/ MaximumIsExclusive = false;
            /*Type*/ OperandType = null;
            /*bool*/ ParseLimitsInInvariantCulture = false;
            /*bool*/ ConvertValueInInvariantCulture = false;
            /*Func<object, object?>?*/ Conversion = null;
            /*void */ Initialize(/*IComparable*/ minimum, /*IComparable*/ maximum, /*Func<object, object?>*/ conversion)
            {
                /*int*/ let cmp = minimum.System$IComparable$CompareTo(maximum);
                if (cmp > 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.RangeAttribute_MinGreaterThanMax, maximum, minimum));
                }
                else if (cmp === 0 && (this.MinimumIsExclusive || this.MaximumIsExclusive))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.RangeAttribute_CannotUseExclusiveBoundsWhenTheyAreEqual);
                }
                this.Minimum = minimum;
                this.Maximum = maximum;
                this.Conversion = conversion;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                this.SetupConversion();
                if ((value === null) || ($.$is(value, $.$spc.System.String) && value.length === 0))
                {
                    return true;
                }
                /*object?*/ let convertedValue;
                try
                {
                    convertedValue = this.Conversion.Invoke(value);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$spc.System.InvalidCastException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$spc.System.NotSupportedException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
                /*var*/ let min = $.$cast(this.Minimum, $.$spc.System.IComparable);
                /*var*/ let max = $.$cast(this.Maximum, $.$spc.System.IComparable);
                return (this.MinimumIsExclusive ? min.System$IComparable$CompareTo(convertedValue) < 0 : min.System$IComparable$CompareTo(convertedValue) <= 0) && (this.MaximumIsExclusive ? max.System$IComparable$CompareTo(convertedValue) > 0 : max.System$IComparable$CompareTo(convertedValue) >= 0);
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                this.SetupConversion();
                return $.$spc.System.String.Format$7($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.Minimum, this.Maximum);
            }
            /*void */ SetupConversion()
            {
                if (this.Conversion === null)
                {
                    /*object*/ let minimum = this.Minimum;
                    /*object*/ let maximum = this.Maximum;
                    if (minimum === null || maximum === null)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.RangeAttribute_Must_Set_Min_And_Max);
                    }
                    /*Type*/ let operandType = $.$spc.System.Object.GetType.call(minimum);
                    if ($.$spc.System.Type.op_Equality$1(operandType, $.$spc.System.Int32.$type))
                    {
                        this.Initialize($.$box($.$cast(minimum, $.$spc.System.Int32), $.$spc.System.Int32), $.$box($.$cast(maximum, $.$spc.System.Int32), $.$spc.System.Int32), new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor(this,  (/*v*/ v) =>
                        {
                            return $.$box($.$spc.System.Convert.ToInt32$1(v, $.$spc.System.Globalization.CultureInfo.InvariantCulture), $.$spc.System.Int32);
                        }));
                    }
                    else if ($.$spc.System.Type.op_Equality$1(operandType, $.$spc.System.Double.$type))
                    {
                        this.Initialize($.$box($.$cast(minimum, $.$spc.System.Double), $.$spc.System.Double), $.$box($.$cast(maximum, $.$spc.System.Double), $.$spc.System.Double), new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor(this,  (/*v*/ v) =>
                        {
                            return $.$box($.$spc.System.Convert.ToDouble$1(v, $.$spc.System.Globalization.CultureInfo.InvariantCulture), $.$spc.System.Double);
                        }));
                    }
                    else 
                    {
                        /*Type*/ let type = this.OperandType;
                        if ($.$spc.System.Type.op_Equality$1(type, null))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.RangeAttribute_Must_Set_Operand_Type);
                        }
                        /*Type*/ let comparableType = $.$spc.System.IComparable.$type;
                        if (!comparableType.IsAssignableFrom(type))
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format$1($.$sca.System.SR.RangeAttribute_ArbitraryTypeNotIComparable, type.FullName, comparableType.FullName));
                        }
                        /*TypeConverter*/ let converter = this.GetOperandTypeConverter();
                        /*IComparable*/ let min = $.$cast((this.ParseLimitsInInvariantCulture ? converter.ConvertFromInvariantString($.$cast(minimum, $.$spc.System.String)) : converter.ConvertFromString($.$cast(minimum, $.$spc.System.String))), $.$spc.System.IComparable);
                        /*IComparable*/ let max = $.$cast((this.ParseLimitsInInvariantCulture ? converter.ConvertFromInvariantString($.$cast(maximum, $.$spc.System.String)) : converter.ConvertFromString($.$cast(maximum, $.$spc.System.String))), $.$spc.System.IComparable);
                        /*Func<object, object?>*/ let conversion;
                        if (this.ConvertValueInInvariantCulture)
                        {
                            conversion = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor(this,  (/*value*/ value) =>
                            {
                                return $.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(value), type) ? value : converter.ConvertFrom$1(null, $.$spc.System.Globalization.CultureInfo.InvariantCulture, value);
                            });
                        }
                        else 
                        {
                            conversion = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object))().$ctor(this,  (/*value*/ value) =>
                            {
                                return $.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(value), type) ? value : converter.ConvertFrom(value);
                            });
                        }
                        this.Initialize(min, max, conversion);
                    }
                }
            }
            /*TypeConverter */ GetOperandTypeConverter()
            {
                return $.$sct.System.ComponentModel.TypeDescriptor.GetConverter$2(this.OperandType);
            }
            /*string */ GetValidationErrorMessage()
            {
                return (() =>
                {
                    let $switch1 = this.MinimumIsExclusive;
                    let $switch2 = this.MaximumIsExclusive;
                    if (($switch1 === false) && ($switch2 === false))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError;
                    }
                    if (($switch1 === true) && ($switch2 === false))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MinExclusive;
                    }
                    if (($switch1 === false) && ($switch2 === true))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MaxExclusive;
                    }
                    if (($switch1 === true) && ($switch2 === true))
                    {
                        return $.$sca.System.SR.RangeAttribute_ValidationError_MinExclusive_MaxExclusive;
                    }
                })();
            }
            //default member initializer
            constructor()
            {
                super();
                this.MinimumIsExclusive = false;
                this.MaximumIsExclusive = false;
                this.ParseLimitsInInvariantCulture = false;
                this.ConvertValueInInvariantCulture = false;
            }
            static $h = 2097190;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3211302,"p":[{"p":131073,"g":{"r":0,"d":0,"h":25771900966,"f":1},"s":{"r":0,"d":0,"h":30066868262,"f":2},"n":"Minimum","d":2097190,"h":21476933670,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":42951770150,"f":1},"s":{"r":0,"d":0,"h":47246737446,"f":2},"n":"Maximum","d":2097190,"h":38656802854,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60131639334,"f":1},"s":{"r":0,"d":0,"h":64426606630,"f":1},"n":"MinimumIsExclusive","d":2097190,"h":55836672038,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77311508518,"f":1},"s":{"r":0,"d":0,"h":81606475814,"f":1},"n":"MaximumIsExclusive","d":2097190,"h":73016541222,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":94491377702,"f":1},"n":"OperandType","d":2097190,"h":90196410406,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107376279590,"f":1},"s":{"r":0,"d":0,"h":111671246886,"f":1},"n":"ParseLimitsInInvariantCulture","d":2097190,"h":103081312294,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124556148774,"f":1},"s":{"r":0,"d":0,"h":128851116070,"f":1},"n":"ConvertValueInInvariantCulture","d":2097190,"h":120261181478,"f":1},{"p":$.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object).$h,"g":{"r":0,"d":0,"h":141736017958,"f":2},"s":{"r":0,"d":0,"h":146030985254,"f":2},"n":"Conversion","d":2097190,"h":137441050662,"f":2}],"m":[{"r":65537,"p":[{"n":"minimum","p":57212929},{"n":"maximum","p":57212929},{"n":"conversion","p":$.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Object).$h}],"n":"Initialize","d":2097190,"h":150325952550,"f":2},{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":2097190,"h":154620919846,"f":32769},{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":2097190,"h":158915887142,"f":32769},{"r":65537,"n":"SetupConversion","d":2097190,"h":163210854438,"f":2},{"r":15925288,"n":"GetOperandTypeConverter","d":2097190,"h":167505821734,"f":2},{"r":1310721,"n":"GetValidationErrorMessage","d":2097190,"h":171800789030,"f":2}],"c":[{"p":[{"n":"minimum","p":655361},{"n":"maximum","p":655361}],"n":".ctor","o":"$ctor$6","d":2097190,"h":4297064486,"f":1},{"p":[{"n":"minimum","p":1179649},{"n":"maximum","p":1179649}],"n":".ctor","o":"$ctor$7","d":2097190,"h":8592031782,"f":1},{"p":[{"n":"type","p":142606337},{"n":"minimum","p":1310721},{"n":"maximum","p":1310721}],"n":".ctor","o":"$ctor$8","d":2097190,"h":12886999078,"f":1}],"h":2097190,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.ValidationAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.RangeAttribute`; }
        });
        
        $asm.$str("$sca.System.ComponentModel.DataAnnotations.DataType", ($self) => class DataType extends $.$spc.System.Enum
        {
            static Custom = 0;
            static DateTime = 1;
            static Date = 2;
            static Time = 3;
            static Duration = 4;
            static PhoneNumber = 5;
            static Currency = 6;
            static Text = 7;
            static Html = 8;
            static MultilineText = 9;
            static EmailAddress = 10;
            static Password = 11;
            static Url = 12;
            static ImageUrl = 13;
            static CreditCard = 14;
            static PostalCode = 15;
            static Upload = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Custom": 0n,
                    "DateTime": 1n,
                    "Date": 2n,
                    "Time": 3n,
                    "Duration": 4n,
                    "PhoneNumber": 5n,
                    "Currency": 6n,
                    "Text": 7n,
                    "Html": 8n,
                    "MultilineText": 9n,
                    "EmailAddress": 10n,
                    "Password": 11n,
                    "Url": 12n,
                    "ImageUrl": 13n,
                    "CreditCard": 14n,
                    "PostalCode": 15n,
                    "Upload": 16n
                };
            }
            static $h = 786470;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":786470,"n":"Custom","d":786470,"h":4295753766,"f":33},{"t":786470,"n":"DateTime","d":786470,"h":8590721062,"f":33},{"t":786470,"n":"Date","d":786470,"h":12885688358,"f":33},{"t":786470,"n":"Time","d":786470,"h":17180655654,"f":33},{"t":786470,"n":"Duration","d":786470,"h":21475622950,"f":33},{"t":786470,"n":"PhoneNumber","d":786470,"h":25770590246,"f":33},{"t":786470,"n":"Currency","d":786470,"h":30065557542,"f":33},{"t":786470,"n":"Text","d":786470,"h":34360524838,"f":33},{"t":786470,"n":"Html","d":786470,"h":38655492134,"f":33},{"t":786470,"n":"MultilineText","d":786470,"h":42950459430,"f":33},{"t":786470,"n":"EmailAddress","d":786470,"h":47245426726,"f":33},{"t":786470,"n":"Password","d":786470,"h":51540394022,"f":33},{"t":786470,"n":"Url","d":786470,"h":55835361318,"f":33},{"t":786470,"n":"ImageUrl","d":786470,"h":60130328614,"f":33},{"t":786470,"n":"CreditCard","d":786470,"h":64425295910,"f":33},{"t":786470,"n":"PostalCode","d":786470,"h":68720263206,"f":33},{"t":786470,"n":"Upload","d":786470,"h":73015230502,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":786470,"h":77310197798,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":786470}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.DataType`; }
        });
        
        $asm.$str("$sca.System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption", ($self) => class DatabaseGeneratedOption extends $.$spc.System.Enum
        {
            static None = 0;
            static Identity = 1;
            static Computed = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Identity": 1n,
                    "Computed": 2n
                };
            }
            static $h = 2555942;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2555942,"n":"None","d":2555942,"h":4297523238,"f":33},{"t":2555942,"n":"Identity","d":2555942,"h":8592490534,"f":33},{"t":2555942,"n":"Computed","d":2555942,"h":12887457830,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2555942,"h":17182425126,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2555942}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.CreditCardAttribute", ($self) => class CreditCardAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            $ctor$8()
            {
                super.$ctor$6(14/*DataType.CreditCard*/);
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.CreditCardAttribute_Invalid;
                }
                return this;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                if (value === null)
                {
                    return true;
                }
                let ccValue;
                if (!$.$is(value, $.$spc.System.String, { set $v(v){ ccValue = v; } }))
                {
                    return false;
                }
                /*int*/ let checksum = 0;
                /*bool*/ let evenDigit = false;
                for(/*int*/ let i = ((ccValue.length - 1) | 0); i >= 0; i--)
                {
                    /*char*/ let digit = $.$spc.System.String.get_Chars.call(ccValue, i);
                    if (!$.$spc.System.Char.IsAsciiDigit(digit))
                    {
                        if ((digit === /*-*/ 45) || (digit === /* */ 32))
                        {
                            continue;
                        }
                        return false;
                    }
                    /*int*/ let digitValue = (((digit - /*0*/ 48) * (evenDigit ? 2 : 1)) | 0);
                    evenDigit = !evenDigit;
                    while(digitValue > 0)
                    {
                        checksum += digitValue % 10;
                        digitValue /= 10;
                    }
                }
                return (checksum % 10) === 0;
            }
            static $h = 655398;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":655398,"h":8590589990,"f":32769}],"c":[{"n":".ctor","o":"$ctor$8","d":655398,"h":4295622694,"f":1}],"h":655398,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.CreditCardAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EmailAddressAttribute", ($self) => class EmailAddressAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            $ctor$8()
            {
                super.$ctor$6(10/*DataType.EmailAddress*/);
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.EmailAddressAttribute_Invalid;
                }
                return this;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!($.$is(value, $.$spc.System.String, { set $v(v){ valueAsString = v; } })))
                {
                    return false;
                }
                if ($.$spc.System.MemoryExtensions.ContainsAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(valueAsString), /*\r*/ 13, /*\n*/ 10))
                {
                    return false;
                }
                /*int*/ let index = $.$spc.System.String.IndexOf.call(valueAsString, /*@*/ 64);
                return index > 0 && index !== ((valueAsString.length - 1) | 0) && index === $.$spc.System.String.LastIndexOf.call(valueAsString, /*@*/ 64);
            }
            static $h = 1245222;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1245222,"h":8591179814,"f":32769}],"c":[{"n":".ctor","o":"$ctor$8","d":1245222,"h":4296212518,"f":1}],"h":1245222,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EmailAddressAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute", ($self) => class EnumDataTypeAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            $ctor$8(/*Type*/ enumType)
            {
                super.$ctor$7("Enumeration");
                {
                    this.EnumType = enumType;
                }
                return this;
            }
            /*Type*/ EnumType = null;
            /*bool */ IsValid(/*object?*/ value)
            {
                if ($.$spc.System.Type.op_Equality$1(this.EnumType, null))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.EnumDataTypeAttribute_TypeCannotBeNull);
                }
                if (!this.EnumType.IsEnum)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sca.System.SR.Format($.$sca.System.SR.EnumDataTypeAttribute_TypeNeedsToBeAnEnum, this.EnumType.FullName));
                }
                if (value === null)
                {
                    return true;
                }
                /*var*/ let stringValue = $.$as(value, $.$spc.System.String);
                const $t1 = stringValue;
                if ($.$ifnn($t1, ($t) => $t.length) === 0)
                {
                    return true;
                }
                /*Type*/ let valueType = $.$spc.System.Object.GetType.call(value);
                if (valueType.IsEnum && $.$spc.System.Type.op_Inequality$1(this.EnumType, valueType))
                {
                    return false;
                }
                if (!valueType.IsValueType && $.$spc.System.Type.op_Inequality$1(valueType, $.$spc.System.String.$type))
                {
                    return false;
                }
                if ($.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Boolean.$type) || $.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Single.$type) || $.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Double.$type) || $.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Decimal.$type) || $.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Char.$type))
                {
                    return false;
                }
                /*object*/ let convertedValue;
                if (valueType.IsEnum)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(valueType, $.$spc.System.Object.GetType.call(value)), "The valueType should equal the Type of the value");
                    convertedValue = value;
                }
                else 
                {
                    try
                    {
                        convertedValue = $.$spc.System.String.op_Inequality(stringValue, null) ? $.$spc.System.Enum.Parse$2(this.EnumType, stringValue, false) : $.$spc.System.Enum.ToObject(this.EnumType, value);
                    }
                    catch($e)
                    {
                        return false;
                    }
                }
                if ($.$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute.IsEnumTypeInFlagsMode(this.EnumType))
                {
                    /*string*/ let underlying = $.$sca.System.ComponentModel.DataAnnotations.EnumDataTypeAttribute.GetUnderlyingTypeValueString(this.EnumType, convertedValue);
                    /*string?*/ let converted = $.$spc.System.Object.ToString.call(convertedValue);
                    return !$.$spc.System.String.Equals$2.call(underlying, converted);
                }
                return $.$spc.System.Enum.IsDefined$1(this.EnumType, convertedValue);
            }
            static /*bool */ IsEnumTypeInFlagsMode(/*Type*/ enumType)
            {
                return enumType.IsDefined($.$spc.System.FlagsAttribute.$type, false);
            }
            static /*string? */ GetUnderlyingTypeValueString(/*Type*/ enumType, /*object*/ enumValue)
            {
                return $.$spc.System.Object.ToString.call($.$spc.System.Convert.ChangeType$3(enumValue, $.$spc.System.Enum.GetUnderlyingType(enumType), $.$spc.System.Globalization.CultureInfo.InvariantCulture));
            }
            static $h = 1310758;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17181179942,"f":1},"n":"EnumType","d":1310758,"h":12886212646,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1310758,"h":21476147238,"f":32769},{"r":262145,"p":[{"n":"enumType","p":142606337}],"n":"IsEnumTypeInFlagsMode","d":1310758,"h":25771114534,"f":34},{"r":1310721,"p":[{"n":"enumType","p":142606337},{"n":"enumValue","p":131073}],"n":"GetUnderlyingTypeValueString","d":1310758,"h":30066081830,"f":34}],"c":[{"p":[{"n":"enumType","p":142606337}],"n":".ctor","o":"$ctor$8","d":1310758,"h":4296278054,"f":1}],"h":1310758,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2496,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.EnumDataTypeAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.FileExtensionsAttribute", ($self) => class FileExtensionsAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            /*string?*/ _extensions = null;
            $ctor$8()
            {
                super.$ctor$6(16/*DataType.Upload*/);
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.FileExtensionsAttribute_Invalid;
                }
                return this;
            }
            /*string */ get Extensions()
            {
                return $.$spc.System.String.IsNullOrWhiteSpace(this._extensions) ? "png,jpg,jpeg,gif" : this._extensions;
            }
            /*string */ set Extensions(value)
            {
                this._extensions = value;
            }
            /*string */ get ExtensionsFormatted()
            {
                return $.$sl.System.Linq.Enumerable.Aggregate($.$spc.System.String, this.ExtensionsParsed, new ($.$spc.System.Func$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.String))().$ctor(this,  (/*left*/ left, /*right*/ right) =>
                {
                    return left + ", " + right;
                }));
            }
            /*string */ get ExtensionsNormalized()
            {
                return $.$spc.System.String.ToLowerInvariant.call($.$spc.System.String.Replace$3.call($.$spc.System.String.Replace$3.call(this.Extensions, " ", $.$spc.System.String.Empty), ".", $.$spc.System.String.Empty));
            }
            /*IEnumerable<string> */ get ExtensionsParsed()
            {
                return $.$sl.System.Linq.Enumerable.Select($.$spc.System.String, $.$spc.System.String, $.$spc.System.String.Split.call(this.ExtensionsNormalized, /*,*/ 44, 0), new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.String))().$ctor(this,  (/*e*/ e) =>
                {
                    return "." + e;
                }));
            }
            /*string */ FormatErrorMessage(/*string*/ name)
            {
                return $.$spc.System.String.Format$6($.$spc.System.Globalization.CultureInfo.CurrentCulture, this.ErrorMessageString, name, this.ExtensionsFormatted);
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                let valueAsString;
                return value === null || $.$is(value, $.$spc.System.String, { set $v(v){ valueAsString = v; } }) && this.ValidateExtension(valueAsString);
            }
            /*bool */ ValidateExtension(/*string*/ fileName)
            {
                return $.$sl.System.Linq.Enumerable.Contains($.$spc.System.String, this.ExtensionsParsed, $.$spc.System.String.ToLowerInvariant.call($.$spc.System.IO.Path.GetExtension(fileName)));
            }
            static $h = 1376294;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181245478,"f":1},"s":{"r":0,"d":0,"h":21476212774,"f":1},"n":"Extensions","d":1376294,"h":12886278182,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30066147366,"f":2},"n":"ExtensionsFormatted","d":1376294,"h":25771180070,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":38656081958,"f":2},"n":"ExtensionsNormalized","d":1376294,"h":34361114662,"f":2},{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":47246016550,"f":2},"n":"ExtensionsParsed","d":1376294,"h":42951049254,"f":2}],"m":[{"r":1310721,"p":[{"n":"name","p":1310721}],"n":"FormatErrorMessage","d":1376294,"h":51540983846,"f":32769},{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":1376294,"h":55835951142,"f":32769},{"r":262145,"p":[{"n":"fileName","p":1310721}],"n":"ValidateExtension","d":1376294,"h":60130918438,"f":2}],"l":[{"t":1310721,"n":"_extensions","d":1376294,"h":4296343590,"f":2}],"c":[{"n":".ctor","o":"$ctor$8","d":1376294,"h":8591310886,"f":1}],"h":1376294,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.FileExtensionsAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.PhoneAttribute", ($self) => class PhoneAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            /*string*/ static AdditionalPhoneNumberCharacters = null;
            /*string*/ static ExtensionAbbreviationExtDot = null;
            /*string*/ static ExtensionAbbreviationExt = null;
            /*string*/ static ExtensionAbbreviationX = null;
            $ctor$8()
            {
                super.$ctor$6(5/*DataType.PhoneNumber*/);
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.PhoneAttribute_Invalid;
                }
                return this;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                if (value === null)
                {
                    return true;
                }
                let valueAsString;
                if (!($.$is(value, $.$spc.System.String, { set $v(v){ valueAsString = v; } })))
                {
                    return false;
                }
                /*ReadOnlySpan<char>*/ let valueSpan = $.$spc.System.MemoryExtensions.TrimEnd$10($.$spc.System.MemoryExtensions.AsSpan$3($.$spc.System.String.Replace$3.call(valueAsString, "+", $.$spc.System.String.Empty)));
                valueSpan = $.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.RemoveExtension(valueSpan);
                /*bool*/ let digitFound = false;
                var $en2 = valueSpan.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if ($.$spc.System.Char.IsDigit(c))
                        {
                            digitFound = true;
                            break;
                        }
                    }
                }
                if (!digitFound)
                {
                    return false;
                }
                var $en2 = valueSpan.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if (!($.$spc.System.Char.IsDigit(c) || $.$spc.System.Char.IsWhiteSpace(c) || $.$spc.System.String.Contains$2.call("-.()"/*AdditionalPhoneNumberCharacters*/, c)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            static /*ReadOnlySpan<char> */ RemoveExtension(/*ReadOnlySpan<char>*/ potentialPhoneNumber)
            {
                /*int*/ let lastIndexOfExtension = $.$spc.System.MemoryExtensions.LastIndexOf$6(potentialPhoneNumber, $.$spc.System.String.op_Implicit("ext."/*ExtensionAbbreviationExtDot*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice(((lastIndexOfExtension + "ext."/*ExtensionAbbreviationExtDot*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice$1(0, lastIndexOfExtension);
                    }
                }
                lastIndexOfExtension = $.$spc.System.MemoryExtensions.LastIndexOf$6(potentialPhoneNumber, $.$spc.System.String.op_Implicit("ext"/*ExtensionAbbreviationExt*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice(((lastIndexOfExtension + "ext"/*ExtensionAbbreviationExt*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice$1(0, lastIndexOfExtension);
                    }
                }
                lastIndexOfExtension = $.$spc.System.MemoryExtensions.LastIndexOf$6(potentialPhoneNumber, $.$spc.System.String.op_Implicit("x"/*ExtensionAbbreviationX*/), 5/*StringComparison.OrdinalIgnoreCase*/);
                if (lastIndexOfExtension >= 0)
                {
                    /*ReadOnlySpan<char>*/ let extension = potentialPhoneNumber.Slice(((lastIndexOfExtension + "x"/*ExtensionAbbreviationX*/.length) | 0));
                    if ($.$sca.System.ComponentModel.DataAnnotations.PhoneAttribute.MatchesExtension(extension))
                    {
                        return potentialPhoneNumber.Slice$1(0, lastIndexOfExtension);
                    }
                }
                return potentialPhoneNumber;
            }
            static /*bool */ MatchesExtension(/*ReadOnlySpan<char>*/ potentialExtension)
            {
                potentialExtension = $.$spc.System.MemoryExtensions.TrimStart$10(potentialExtension);
                if (potentialExtension.Length === 0)
                {
                    return false;
                }
                var $en2 = potentialExtension.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current.$v;
                    {
                        if (!$.$spc.System.Char.IsDigit(c))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.AdditionalPhoneNumberCharacters = "-.()";
                }
                {
                    this.ExtensionAbbreviationExtDot = "ext.";
                }
                {
                    this.ExtensionAbbreviationExt = "ext";
                }
                {
                    this.ExtensionAbbreviationX = "x";
                }
            }
            static $h = 2031654;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":2031654,"h":25771835430,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"potentialPhoneNumber","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"RemoveExtension","d":2031654,"h":30066802726,"f":34},{"r":262145,"p":[{"n":"potentialExtension","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"MatchesExtension","d":2031654,"h":34361770022,"f":34}],"l":[{"t":1310721,"n":"AdditionalPhoneNumberCharacters","d":2031654,"h":4296998950,"f":34},{"t":1310721,"n":"ExtensionAbbreviationExtDot","d":2031654,"h":8591966246,"f":34},{"t":1310721,"n":"ExtensionAbbreviationExt","d":2031654,"h":12886933542,"f":34},{"t":1310721,"n":"ExtensionAbbreviationX","d":2031654,"h":17181900838,"f":34}],"c":[{"n":".ctor","o":"$ctor$8","d":2031654,"h":21476868134,"f":1}],"h":2031654,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.PhoneAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.UrlAttribute", ($self) => class UrlAttribute extends $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute
        {
            $ctor$8()
            {
                super.$ctor$6(12/*DataType.Url*/);
                {
                    this.DefaultErrorMessage = $.$sca.System.SR.UrlAttribute_Invalid;
                }
                return this;
            }
            /*bool */ IsValid(/*object?*/ value)
            {
                //switch (value)
                {
                    let valueAsUri;
                    let valueAsString;
                    $switchJumpStart1: 
                    //case Uri valueAsUri when valueAsUri.IsAbsoluteUri:
                    if ($.$is(value, $.$spu.System.Uri, { set $v(v){ valueAsUri = v; } }) && valueAsUri.IsAbsoluteUri)
                    {
                        {
                            return $.$spc.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeHttp) || $.$spc.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeHttps) || $.$spc.System.String.op_Equality(valueAsUri.Scheme, $.$spu.System.Uri.UriSchemeFtp);
                        }
                    }
                    //case string valueAsString:
                    else if ($.$is(value, $.$spc.System.String, { set $v(v){ valueAsString = v; } }))
                    {
                        {
                            return $.$spc.System.String.StartsWith$1.call(valueAsString, "http://", 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.String.StartsWith$1.call(valueAsString, "https://", 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.String.StartsWith$1.call(valueAsString, "ftp://", 5/*StringComparison.OrdinalIgnoreCase*/);
                        }
                    }
                    //case null:
                    else if (value == null)
                    {
                        {
                            return true;
                        }
                    }
                    //default
                    else
                    {
                        {
                            return false;
                        }
                    }
                }
            }
            static $h = 3145766;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":852006,"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"IsValid","d":3145766,"h":8593080358,"f":32769}],"c":[{"n":".ctor","o":"$ctor$8","d":3145766,"h":4298113062,"f":1}],"h":3145766,"a":[{"t":14614529,"c":21489451009,"a":[{"v":2432,"t":14548993}],"n":[{"n":"AllowMultiple","v":false,"t":262145}]}]}; }
            static get $b() { return $.$sca.System.ComponentModel.DataAnnotations.DataTypeAttribute; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.UrlAttribute`; }
        });
        
        $asm.$cls("$sca.System.ComponentModel.DataAnnotations.ValidationException", ($self) => class ValidationException extends $.$spc.System.Exception
        {
            /*ValidationResult?*/ _validationResult = null;
            $ctor$5(/*ValidationResult*/ validationResult, /*ValidationAttribute?*/ validatingAttribute, /*object?*/ value)
            {
                this.$ctor$6(validationResult.ErrorMessage, validatingAttribute, value);
                {
                    this._validationResult = validationResult;
                }
                return this;
            }
            $ctor$6(/*string?*/ errorMessage, /*ValidationAttribute?*/ validatingAttribute, /*object?*/ value)
            {
                super.$ctor$2(errorMessage);
                {
                    this.Value = value;
                    this.ValidationAttribute = validatingAttribute;
                }
                return this;
            }
            $ctor$7()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$8(/*string?*/ message)
            {
                super.$ctor$2(message);
                {
                }
                return this;
            }
            $ctor$9(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$3(message, innerException);
                {
                }
                return this;
            }
            $ctor$10(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$4(info, context);
                {
                }
                return this;
            }
            /*ValidationAttribute?*/ ValidationAttribute = null;
            /*ValidationResult */ get ValidationResult()
            {
                return this._validationResult ??= new $.$sca.System.ComponentModel.DataAnnotations.ValidationResult().$ctor$1(this.Message);
            }
            /*object?*/ Value = null;
            static $h = 3604518;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":3604518}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.DataAnnotations.ValidationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Linq.Expressions", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Net.Quic", "NetJs.System.Net.Http", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter"))