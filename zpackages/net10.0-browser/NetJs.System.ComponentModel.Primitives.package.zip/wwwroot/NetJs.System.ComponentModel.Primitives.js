
//--TRIMMABLE-BOUNDARY-START(40)
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel.Primitives", 
    {
  "h": 40,
  "f": "System.ComponentModel.Primitives",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.ComponentModel.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.ComponentModel.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1572904)
        $asm.$cls("$scp.System.ComponentModel.ISynchronizeInvoke", ($self) => class ISynchronizeInvoke
        {
            static $h = 1572904;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771376680),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181442088,
        "f": 50331905
      },
      "n": "InvokeRequired",
      "o": "System$ComponentModel$ISynchronizeInvoke$InvokeRequired",
      "d": 1572904,
      "h": 25771376680,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771376680)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296540200),
    {
      "r": 89784321,
      "p": [
        {
          "n": "method",
          "p": 66781185
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "BeginInvoke",
      "o": "System$ComponentModel$ISynchronizeInvoke$BeginInvoke",
      "d": 1572904,
      "h": 4296540200,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296540200),
//--TRIMMABLE-BOUNDARY-START(8591507496),
    {
      "r": 131073,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "o": "System$ComponentModel$ISynchronizeInvoke$EndInvoke",
      "d": 1572904,
      "h": 8591507496,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591507496),
//--TRIMMABLE-BOUNDARY-START(21476409384),
    {
      "r": 131073,
      "p": [
        {
          "n": "method",
          "p": 66781185
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.System.Object).$h
        }
      ],
      "n": "Invoke",
      "o": "System$ComponentModel$ISynchronizeInvoke$Invoke",
      "d": 1572904,
      "h": 21476409384,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21476409384)
  ],
  "h": 1572904
}; }
            static get $fullName() { return `System.ComponentModel.ISynchronizeInvoke`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572904)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507368)
        $asm.$cls("$scp.System.ComponentModel.ISupportInitialize", ($self) => class ISupportInitialize
        {
            static $h = 1507368;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296474664),
    {
      "r": 65537,
      "n": "BeginInit",
      "o": "System$ComponentModel$ISupportInitialize$BeginInit",
      "d": 1507368,
      "h": 4296474664,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296474664),
//--TRIMMABLE-BOUNDARY-START(8591441960),
    {
      "r": 65537,
      "n": "EndInit",
      "o": "System$ComponentModel$ISupportInitialize$EndInit",
      "d": 1507368,
      "h": 8591441960,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591441960)
  ],
  "h": 1507368
}; }
            static get $fullName() { return `System.ComponentModel.ISupportInitialize`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507368)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114152)
        $asm.$cls("$scp.System.ComponentModel.IContainer", ($self) => class IContainer
        {
            static $h = 1114152;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886016040),
    {
      "p": 262184,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475950632,
        "f": 50331905
      },
      "n": "Components",
      "o": "System$ComponentModel$IContainer$Components",
      "d": 1114152,
      "h": 12886016040,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886016040)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591048744),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 1048616
        }
      ],
      "n": "Add",
      "o": "System$ComponentModel$IContainer$Add$1",
      "d": 1114152,
      "h": 8591048744,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591048744),
//--TRIMMABLE-BOUNDARY-START(4296081448),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 1048616
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Add",
      "o": "System$ComponentModel$IContainer$Add",
      "d": 1114152,
      "h": 4296081448,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081448),
//--TRIMMABLE-BOUNDARY-START(25770917928),
    {
      "r": 65537,
      "p": [
        {
          "n": "component",
          "p": 1048616
        }
      ],
      "n": "Remove",
      "o": "System$ComponentModel$IContainer$Remove",
      "d": 1114152,
      "h": 25770917928,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770917928)
  ],
  "i": [90308609
  ],
  "h": 1114152
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.IContainer`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114152)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441832)
        $asm.$cls("$scp.System.ComponentModel.ISite", ($self) => class ISite
        {
            static $h = 1441832;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(4296409128),
    {
      "p": 1048616,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476278312,
        "f": 50331905
      },
      "n": "Component",
      "o": "System$ComponentModel$ISite$Component",
      "d": 1441832,
      "h": 4296409128,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4296409128),
//--TRIMMABLE-BOUNDARY-START(8591376424),
    {
      "p": 1114152,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066212904,
        "f": 50331905
      },
      "n": "Container",
      "o": "System$ComponentModel$ISite$Container",
      "d": 1441832,
      "h": 8591376424,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8591376424),
//--TRIMMABLE-BOUNDARY-START(12886343720),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656147496,
        "f": 50331905
      },
      "n": "DesignMode",
      "o": "System$ComponentModel$ISite$DesignMode",
      "d": 1441832,
      "h": 12886343720,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12886343720),
//--TRIMMABLE-BOUNDARY-START(51541049384),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246082088,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130983976,
        "f": 83886337
      },
      "n": "Name",
      "o": "System$ComponentModel$ISite$Name",
      "d": 1441832,
      "h": 51541049384,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51541049384)
  ],
  "i": [327718
  ],
  "h": 1441832
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `System.ComponentModel.ISite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441832)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048616)
        $asm.$cls("$scp.System.ComponentModel.IComponent", ($self) => class IComponent
        {
            static $h = 1048616;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950721576),
    {
      "p": 1441832,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475885096,
        "f": 50331905
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655754280,
        "f": 83886337
      },
      "n": "Site",
      "o": "System$ComponentModel$IComponent$Site",
      "d": 1048616,
      "h": 42950721576,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42950721576)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(12885950504),
    {
      "e": 79822849,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79822849
          }
        ],
        "n": "add_Disposed",
        "o": "System$ComponentModel$IComponent$add_Disposed",
        "d": 1048616,
        "h": 8590983208,
        "f": 150995201
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79822849
          }
        ],
        "n": "remove_Disposed",
        "o": "System$ComponentModel$IComponent$remove_Disposed",
        "d": 1048616,
        "h": 30065819688,
        "f": 285212929
      },
      "n": "Disposed",
      "o": "System$ComponentModel$IComponent$Disposed",
      "d": 1048616,
      "h": 12885950504,
      "f": 8388865
    },
//--TRIMMABLE-BOUNDARY-END(12885950504)
  ],
  "i": [90308609
  ],
  "h": 1048616,
  "a": [
    {
      "t": 458792,
      "c": 25770262568,
      "a": [
        {
          "v": "System.ComponentModel.Design.ComponentDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 458792,
      "c": 17180327976,
      "a": [
        {
          "v": "System.Windows.Forms.Design.ComponentDocumentDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        },
        {
          "v": "System.ComponentModel.Design.IRootDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.ComponentModel.ComponentConverter, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.IComponent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048616)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162728)
        $asm.$cls("$scp.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(373664317480)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(373664317480)
            
            //--TRIMMABLE-BOUNDARY-START(365074382888)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(365074382888)
            
            //--TRIMMABLE-BOUNDARY-START(369369350184)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253405233192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$scp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.ComponentModel.Primitives", $.$scp.System.SR.$type.Assembly);
                    $.$scp.System.SR.s_resourceManager = temp;
                }
                return $.$scp.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(369369350184)
            
            //--TRIMMABLE-BOUNDARY-START(8592097320)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836737576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386549219368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scp.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(8592097320)
            
            //--TRIMMABLE-BOUNDARY-START(270585102376)
            static /*string */ get InvalidEnumArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426672168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value of argument '{0}' ({1}) is invalid for Enum type '{2}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(270585102376)
            
            //--TRIMMABLE-BOUNDARY-START(47246802984)
            static /*string */ FormatInvalidEnumArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246802984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$7("The value of argument '{0}' ({1}) is invalid for Enum type '{2}'.", arg1, arg2, arg3);
            }
            //--TRIMMABLE-BOUNDARY-END(47246802984)
            
            //--TRIMMABLE-BOUNDARY-START(274880069672)
            static /*string */ get PropertyCategoryAction()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016606760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Action";
            }
            //--TRIMMABLE-BOUNDARY-END(274880069672)
            
            //--TRIMMABLE-BOUNDARY-START(279175036968)
            static /*string */ get PropertyCategoryAppearance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606541352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Appearance";
            }
            //--TRIMMABLE-BOUNDARY-END(279175036968)
            
            //--TRIMMABLE-BOUNDARY-START(283470004264)
            static /*string */ get PropertyCategoryAsynchronous()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196475944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Asynchronous";
            }
            //--TRIMMABLE-BOUNDARY-END(283470004264)
            
            //--TRIMMABLE-BOUNDARY-START(287764971560)
            static /*string */ get PropertyCategoryBehavior()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786410536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Behavior";
            }
            //--TRIMMABLE-BOUNDARY-END(287764971560)
            
            //--TRIMMABLE-BOUNDARY-START(292059938856)
            static /*string */ get PropertyCategoryConfig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376345128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Configurations";
            }
            //--TRIMMABLE-BOUNDARY-END(292059938856)
            
            //--TRIMMABLE-BOUNDARY-START(296354906152)
            static /*string */ get PropertyCategoryData()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966279720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Data";
            }
            //--TRIMMABLE-BOUNDARY-END(296354906152)
            
            //--TRIMMABLE-BOUNDARY-START(300649873448)
            static /*string */ get PropertyCategoryDDE()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556214312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "DDE";
            }
            //--TRIMMABLE-BOUNDARY-END(300649873448)
            
            //--TRIMMABLE-BOUNDARY-START(304944840744)
            static /*string */ get PropertyCategoryDefault()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133146148904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Misc";
            }
            //--TRIMMABLE-BOUNDARY-END(304944840744)
            
            //--TRIMMABLE-BOUNDARY-START(309239808040)
            static /*string */ get PropertyCategoryDesign()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141736083496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Design";
            }
            //--TRIMMABLE-BOUNDARY-END(309239808040)
            
            //--TRIMMABLE-BOUNDARY-START(313534775336)
            static /*string */ get PropertyCategoryDragDrop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150326018088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Drag Drop";
            }
            //--TRIMMABLE-BOUNDARY-END(313534775336)
            
            //--TRIMMABLE-BOUNDARY-START(317829742632)
            static /*string */ get PropertyCategoryFocus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915952680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Focus";
            }
            //--TRIMMABLE-BOUNDARY-END(317829742632)
            
            //--TRIMMABLE-BOUNDARY-START(322124709928)
            static /*string */ get PropertyCategoryFont()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505887272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Font";
            }
            //--TRIMMABLE-BOUNDARY-END(322124709928)
            
            //--TRIMMABLE-BOUNDARY-START(326419677224)
            static /*string */ get PropertyCategoryFormat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095821864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Format";
            }
            //--TRIMMABLE-BOUNDARY-END(326419677224)
            
            //--TRIMMABLE-BOUNDARY-START(330714644520)
            static /*string */ get PropertyCategoryKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685756456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Key";
            }
            //--TRIMMABLE-BOUNDARY-END(330714644520)
            
            //--TRIMMABLE-BOUNDARY-START(335009611816)
            static /*string */ get PropertyCategoryLayout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275691048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Layout";
            }
            //--TRIMMABLE-BOUNDARY-END(335009611816)
            
            //--TRIMMABLE-BOUNDARY-START(339304579112)
            static /*string */ get PropertyCategoryList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865625640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "List";
            }
            //--TRIMMABLE-BOUNDARY-END(339304579112)
            
            //--TRIMMABLE-BOUNDARY-START(343599546408)
            static /*string */ get PropertyCategoryMouse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455560232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Mouse";
            }
            //--TRIMMABLE-BOUNDARY-END(343599546408)
            
            //--TRIMMABLE-BOUNDARY-START(347894513704)
            static /*string */ get PropertyCategoryPosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219045494824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Position";
            }
            //--TRIMMABLE-BOUNDARY-END(347894513704)
            
            //--TRIMMABLE-BOUNDARY-START(352189481000)
            static /*string */ get PropertyCategoryScale()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227635429416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Scale";
            }
            //--TRIMMABLE-BOUNDARY-END(352189481000)
            
            //--TRIMMABLE-BOUNDARY-START(356484448296)
            static /*string */ get PropertyCategoryText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225364008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Text";
            }
            //--TRIMMABLE-BOUNDARY-END(356484448296)
            
            //--TRIMMABLE-BOUNDARY-START(360779415592)
            static /*string */ get PropertyCategoryWindowStyle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244815298600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Window Style";
            }
            //--TRIMMABLE-BOUNDARY-END(360779415592)
            
            //--TRIMMABLE-BOUNDARY-START(377959284776)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(377959284776)
            
            //--TRIMMABLE-BOUNDARY-START(266290135080)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266290135080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266290135080)
            
            //--TRIMMABLE-BOUNDARY-START(390844186664)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(390844186664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(390844186664)
            
            //--TRIMMABLE-BOUNDARY-START(261995167784)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261995167784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(261995167784)
            
            //--TRIMMABLE-BOUNDARY-START(257700200488)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257700200488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(257700200488)
            
            //--TRIMMABLE-BOUNDARY-START(38656868392)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656868392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(38656868392)
            
            //--TRIMMABLE-BOUNDARY-START(34361901096)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361901096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(34361901096)
            
            //--TRIMMABLE-BOUNDARY-START(30066933800)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066933800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(30066933800)
            
            //--TRIMMABLE-BOUNDARY-START(42951835688)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951835688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(42951835688)
            
            //--TRIMMABLE-BOUNDARY-START(21476999208)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476999208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(21476999208)
            
            //--TRIMMABLE-BOUNDARY-START(17182031912)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182031912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(17182031912)
            
            //--TRIMMABLE-BOUNDARY-START(12887064616)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887064616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(12887064616)
            
            //--TRIMMABLE-BOUNDARY-START(25771966504)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771966504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(25771966504)
            
            //--TRIMMABLE-BOUNDARY-START(4297130024)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(377959284776)
                    this.s_usingResourceKeys = $.$scp.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(377959284776)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4297130024)
            
            static $h = 2162728;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 2162728
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162728)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097192)
        $asm.$cls("$scp.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382254186536)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382254186536)
            
            //--TRIMMABLE-BOUNDARY-START(433793794088)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433793794088)
            
            //--TRIMMABLE-BOUNDARY-START(429498826792)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429498826792)
            
            //--TRIMMABLE-BOUNDARY-START(266290069544)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266290069544)
            
            //--TRIMMABLE-BOUNDARY-START(261995102248)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261995102248)
            
            //--TRIMMABLE-BOUNDARY-START(77311508520)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77311508520)
            
            //--TRIMMABLE-BOUNDARY-START(73016541224)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73016541224)
            
            //--TRIMMABLE-BOUNDARY-START(94491377704)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94491377704)
            
            //--TRIMMABLE-BOUNDARY-START(90196410408)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90196410408)
            
            //--TRIMMABLE-BOUNDARY-START(214750461992)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214750461992)
            
            //--TRIMMABLE-BOUNDARY-START(210455494696)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210455494696)
            
            //--TRIMMABLE-BOUNDARY-START(442383728680)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442383728680)
            
            //--TRIMMABLE-BOUNDARY-START(446678695976)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446678695976)
            
            //--TRIMMABLE-BOUNDARY-START(438088761384)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438088761384)
            
            //--TRIMMABLE-BOUNDARY-START(146030985256)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146030985256)
            
            //--TRIMMABLE-BOUNDARY-START(141736017960)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141736017960)
            
            //--TRIMMABLE-BOUNDARY-START(120261181480)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120261181480)
            
            //--TRIMMABLE-BOUNDARY-START(115966214184)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115966214184)
            
            //--TRIMMABLE-BOUNDARY-START(51541704744)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51541704744)
            
            //--TRIMMABLE-BOUNDARY-START(47246737448)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47246737448)
            
            //--TRIMMABLE-BOUNDARY-START(326419611688)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326419611688)
            
            //--TRIMMABLE-BOUNDARY-START(322124644392)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322124644392)
            
            //--TRIMMABLE-BOUNDARY-START(60131639336)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60131639336)
            
            //--TRIMMABLE-BOUNDARY-START(55836672040)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55836672040)
            
            //--TRIMMABLE-BOUNDARY-START(85901443112)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85901443112)
            
            //--TRIMMABLE-BOUNDARY-START(81606475816)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81606475816)
            
            //--TRIMMABLE-BOUNDARY-START(197570592808)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197570592808)
            
            //--TRIMMABLE-BOUNDARY-START(193275625512)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193275625512)
            
            //--TRIMMABLE-BOUNDARY-START(489628368936)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489628368936)
            
            //--TRIMMABLE-BOUNDARY-START(485333401640)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485333401640)
            
            //--TRIMMABLE-BOUNDARY-START(163210854440)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163210854440)
            
            //--TRIMMABLE-BOUNDARY-START(158915887144)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158915887144)
            
            //--TRIMMABLE-BOUNDARY-START(206160527400)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206160527400)
            
            //--TRIMMABLE-BOUNDARY-START(201865560104)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201865560104)
            
            //--TRIMMABLE-BOUNDARY-START(399434055720)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399434055720)
            
            //--TRIMMABLE-BOUNDARY-START(395139088424)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395139088424)
            
            //--TRIMMABLE-BOUNDARY-START(300649807912)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300649807912)
            
            //--TRIMMABLE-BOUNDARY-START(296354840616)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296354840616)
            
            //--TRIMMABLE-BOUNDARY-START(377959219240)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377959219240)
            
            //--TRIMMABLE-BOUNDARY-START(373664251944)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373664251944)
            
            //--TRIMMABLE-BOUNDARY-START(231930331176)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231930331176)
            
            //--TRIMMABLE-BOUNDARY-START(227635363880)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227635363880)
            
            //--TRIMMABLE-BOUNDARY-START(154620919848)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154620919848)
            
            //--TRIMMABLE-BOUNDARY-START(150325952552)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150325952552)
            
            //--TRIMMABLE-BOUNDARY-START(352189415464)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352189415464)
            
            //--TRIMMABLE-BOUNDARY-START(347894448168)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347894448168)
            
            //--TRIMMABLE-BOUNDARY-START(360779350056)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360779350056)
            
            //--TRIMMABLE-BOUNDARY-START(356484382760)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356484382760)
            
            //--TRIMMABLE-BOUNDARY-START(17181966376)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17181966376)
            
            //--TRIMMABLE-BOUNDARY-START(12886999080)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12886999080)
            
            //--TRIMMABLE-BOUNDARY-START(408023990312)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408023990312)
            
            //--TRIMMABLE-BOUNDARY-START(403729023016)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403729023016)
            
            //--TRIMMABLE-BOUNDARY-START(498218303528)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498218303528)
            
            //--TRIMMABLE-BOUNDARY-START(493923336232)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493923336232)
            
            //--TRIMMABLE-BOUNDARY-START(283469938728)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283469938728)
            
            //--TRIMMABLE-BOUNDARY-START(279174971432)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279174971432)
            
            //--TRIMMABLE-BOUNDARY-START(506808238120)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506808238120)
            
            //--TRIMMABLE-BOUNDARY-START(502513270824)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502513270824)
            
            //--TRIMMABLE-BOUNDARY-START(274880004136)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274880004136)
            
            //--TRIMMABLE-BOUNDARY-START(270585036840)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270585036840)
            
            //--TRIMMABLE-BOUNDARY-START(481038434344)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481038434344)
            
            //--TRIMMABLE-BOUNDARY-START(476743467048)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476743467048)
            
            //--TRIMMABLE-BOUNDARY-START(128851116072)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128851116072)
            
            //--TRIMMABLE-BOUNDARY-START(124556148776)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124556148776)
            
            //--TRIMMABLE-BOUNDARY-START(111671246888)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111671246888)
            
            //--TRIMMABLE-BOUNDARY-START(107376279592)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107376279592)
            
            //--TRIMMABLE-BOUNDARY-START(335009546280)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335009546280)
            
            //--TRIMMABLE-BOUNDARY-START(330714578984)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330714578984)
            
            //--TRIMMABLE-BOUNDARY-START(68721573928)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68721573928)
            
            //--TRIMMABLE-BOUNDARY-START(64426606632)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64426606632)
            
            //--TRIMMABLE-BOUNDARY-START(390844121128)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390844121128)
            
            //--TRIMMABLE-BOUNDARY-START(386549153832)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386549153832)
            
            //--TRIMMABLE-BOUNDARY-START(309239742504)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309239742504)
            
            //--TRIMMABLE-BOUNDARY-START(304944775208)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304944775208)
            
            //--TRIMMABLE-BOUNDARY-START(42951770152)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42951770152)
            
            //--TRIMMABLE-BOUNDARY-START(38656802856)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38656802856)
            
            //--TRIMMABLE-BOUNDARY-START(416613924904)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416613924904)
            
            //--TRIMMABLE-BOUNDARY-START(412318957608)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412318957608)
            
            //--TRIMMABLE-BOUNDARY-START(472448499752)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472448499752)
            
            //--TRIMMABLE-BOUNDARY-START(468153532456)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468153532456)
            
            //--TRIMMABLE-BOUNDARY-START(188980658216)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188980658216)
            
            //--TRIMMABLE-BOUNDARY-START(184685690920)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184685690920)
            
            //--TRIMMABLE-BOUNDARY-START(171800789032)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171800789032)
            
            //--TRIMMABLE-BOUNDARY-START(167505821736)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167505821736)
            
            //--TRIMMABLE-BOUNDARY-START(180390723624)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180390723624)
            
            //--TRIMMABLE-BOUNDARY-START(176095756328)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176095756328)
            
            //--TRIMMABLE-BOUNDARY-START(34361835560)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34361835560)
            
            //--TRIMMABLE-BOUNDARY-START(30066868264)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30066868264)
            
            //--TRIMMABLE-BOUNDARY-START(137441050664)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137441050664)
            
            //--TRIMMABLE-BOUNDARY-START(133146083368)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133146083368)
            
            //--TRIMMABLE-BOUNDARY-START(103081312296)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103081312296)
            
            //--TRIMMABLE-BOUNDARY-START(98786345000)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98786345000)
            
            //--TRIMMABLE-BOUNDARY-START(523988107304)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523988107304)
            
            //--TRIMMABLE-BOUNDARY-START(519693140008)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519693140008)
            
            //--TRIMMABLE-BOUNDARY-START(369369284648)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369369284648)
            
            //--TRIMMABLE-BOUNDARY-START(365074317352)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365074317352)
            
            //--TRIMMABLE-BOUNDARY-START(223340396584)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223340396584)
            
            //--TRIMMABLE-BOUNDARY-START(219045429288)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219045429288)
            
            //--TRIMMABLE-BOUNDARY-START(249110200360)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249110200360)
            
            //--TRIMMABLE-BOUNDARY-START(236225298472)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236225298472)
            
            //--TRIMMABLE-BOUNDARY-START(244815233064)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244815233064)
            
            //--TRIMMABLE-BOUNDARY-START(240520265768)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240520265768)
            
            //--TRIMMABLE-BOUNDARY-START(317829677096)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317829677096)
            
            //--TRIMMABLE-BOUNDARY-START(313534709800)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313534709800)
            
            //--TRIMMABLE-BOUNDARY-START(8592031784)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8592031784)
            
            //--TRIMMABLE-BOUNDARY-START(4297064488)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4297064488)
            
            //--TRIMMABLE-BOUNDARY-START(455268630568)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455268630568)
            
            //--TRIMMABLE-BOUNDARY-START(450973663272)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450973663272)
            
            //--TRIMMABLE-BOUNDARY-START(25771900968)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25771900968)
            
            //--TRIMMABLE-BOUNDARY-START(21476933672)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21476933672)
            
            //--TRIMMABLE-BOUNDARY-START(257700134952)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257700134952)
            
            //--TRIMMABLE-BOUNDARY-START(253405167656)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253405167656)
            
            //--TRIMMABLE-BOUNDARY-START(515398172712)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515398172712)
            
            //--TRIMMABLE-BOUNDARY-START(511103205416)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511103205416)
            
            //--TRIMMABLE-BOUNDARY-START(463858565160)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463858565160)
            
            //--TRIMMABLE-BOUNDARY-START(459563597864)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459563597864)
            
            //--TRIMMABLE-BOUNDARY-START(425203859496)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425203859496)
            
            //--TRIMMABLE-BOUNDARY-START(420908892200)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420908892200)
            
            //--TRIMMABLE-BOUNDARY-START(343599480872)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343599480872)
            
            //--TRIMMABLE-BOUNDARY-START(339304513576)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339304513576)
            
            //--TRIMMABLE-BOUNDARY-START(292059873320)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292059873320)
            
            //--TRIMMABLE-BOUNDARY-START(287764906024)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287764906024)
            
            //--TRIMMABLE-BOUNDARY-START(532578041896)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532578041896)
            
            //--TRIMMABLE-BOUNDARY-START(528283074600)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528283074600)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382254186536)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382254186536)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433793794088)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433793794088)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429498826792)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429498826792)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266290069544)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266290069544)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261995102248)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261995102248)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77311508520)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77311508520)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73016541224)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73016541224)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94491377704)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94491377704)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90196410408)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90196410408)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214750461992)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214750461992)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210455494696)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210455494696)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442383728680)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442383728680)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446678695976)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446678695976)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438088761384)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438088761384)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146030985256)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146030985256)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141736017960)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141736017960)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120261181480)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120261181480)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115966214184)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115966214184)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541704744)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51541704744)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246737448)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47246737448)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326419611688)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326419611688)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322124644392)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322124644392)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60131639336)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60131639336)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55836672040)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55836672040)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85901443112)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85901443112)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81606475816)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81606475816)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197570592808)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197570592808)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193275625512)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193275625512)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489628368936)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489628368936)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485333401640)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485333401640)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163210854440)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163210854440)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158915887144)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158915887144)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206160527400)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206160527400)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201865560104)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201865560104)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399434055720)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399434055720)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395139088424)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395139088424)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300649807912)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300649807912)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296354840616)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296354840616)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377959219240)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377959219240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373664251944)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373664251944)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231930331176)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231930331176)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227635363880)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227635363880)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154620919848)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154620919848)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150325952552)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150325952552)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352189415464)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352189415464)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347894448168)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347894448168)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360779350056)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360779350056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356484382760)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356484382760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181966376)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17181966376)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12886999080)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12886999080)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408023990312)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408023990312)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403729023016)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403729023016)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498218303528)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498218303528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493923336232)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493923336232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283469938728)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283469938728)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279174971432)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279174971432)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506808238120)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506808238120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502513270824)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502513270824)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274880004136)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274880004136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270585036840)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270585036840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481038434344)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481038434344)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476743467048)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476743467048)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128851116072)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128851116072)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124556148776)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124556148776)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111671246888)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111671246888)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107376279592)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107376279592)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335009546280)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335009546280)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330714578984)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330714578984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68721573928)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68721573928)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64426606632)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64426606632)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390844121128)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390844121128)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386549153832)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386549153832)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309239742504)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309239742504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304944775208)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304944775208)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951770152)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42951770152)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38656802856)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38656802856)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416613924904)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416613924904)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412318957608)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412318957608)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472448499752)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472448499752)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468153532456)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468153532456)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188980658216)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188980658216)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184685690920)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184685690920)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171800789032)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171800789032)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167505821736)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167505821736)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180390723624)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180390723624)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176095756328)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176095756328)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34361835560)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34361835560)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30066868264)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30066868264)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137441050664)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137441050664)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133146083368)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133146083368)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103081312296)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103081312296)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98786345000)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98786345000)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523988107304)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523988107304)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519693140008)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519693140008)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369369284648)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369369284648)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365074317352)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365074317352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223340396584)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223340396584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219045429288)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219045429288)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249110200360)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249110200360)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236225298472)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236225298472)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244815233064)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244815233064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240520265768)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240520265768)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317829677096)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317829677096)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313534709800)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313534709800)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8592031784)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8592031784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4297064488)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4297064488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455268630568)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455268630568)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450973663272)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450973663272)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25771900968)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25771900968)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476933672)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21476933672)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257700134952)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257700134952)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253405167656)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253405167656)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515398172712)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515398172712)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511103205416)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511103205416)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463858565160)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463858565160)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459563597864)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459563597864)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425203859496)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425203859496)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420908892200)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420908892200)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343599480872)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343599480872)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339304513576)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339304513576)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292059873320)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292059873320)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287764906024)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287764906024)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532578041896)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532578041896)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528283074600)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528283074600)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 2097192;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382254186536),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 2097192,
      "h": 382254186536,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382254186536),
//--TRIMMABLE-BOUNDARY-START(433793794088),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 2097192,
      "h": 433793794088,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433793794088),
//--TRIMMABLE-BOUNDARY-START(429498826792),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 2097192,
      "h": 429498826792,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429498826792),
//--TRIMMABLE-BOUNDARY-START(266290069544),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 2097192,
      "h": 266290069544,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266290069544),
//--TRIMMABLE-BOUNDARY-START(261995102248),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 2097192,
      "h": 261995102248,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261995102248),
//--TRIMMABLE-BOUNDARY-START(77311508520),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 2097192,
      "h": 77311508520,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77311508520),
//--TRIMMABLE-BOUNDARY-START(73016541224),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 2097192,
      "h": 73016541224,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73016541224),
//--TRIMMABLE-BOUNDARY-START(94491377704),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 2097192,
      "h": 94491377704,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94491377704),
//--TRIMMABLE-BOUNDARY-START(90196410408),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 2097192,
      "h": 90196410408,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90196410408),
//--TRIMMABLE-BOUNDARY-START(214750461992),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 2097192,
      "h": 214750461992,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214750461992),
//--TRIMMABLE-BOUNDARY-START(210455494696),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 2097192,
      "h": 210455494696,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210455494696),
//--TRIMMABLE-BOUNDARY-START(442383728680),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 2097192,
      "h": 442383728680,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442383728680),
//--TRIMMABLE-BOUNDARY-START(446678695976),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 2097192,
      "h": 446678695976,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446678695976),
//--TRIMMABLE-BOUNDARY-START(438088761384),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 2097192,
      "h": 438088761384,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438088761384),
//--TRIMMABLE-BOUNDARY-START(146030985256),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 2097192,
      "h": 146030985256,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146030985256),
//--TRIMMABLE-BOUNDARY-START(141736017960),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 2097192,
      "h": 141736017960,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141736017960),
//--TRIMMABLE-BOUNDARY-START(120261181480),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 2097192,
      "h": 120261181480,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120261181480),
//--TRIMMABLE-BOUNDARY-START(115966214184),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 2097192,
      "h": 115966214184,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115966214184),
//--TRIMMABLE-BOUNDARY-START(51541704744),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 2097192,
      "h": 51541704744,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51541704744),
//--TRIMMABLE-BOUNDARY-START(47246737448),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 2097192,
      "h": 47246737448,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47246737448),
//--TRIMMABLE-BOUNDARY-START(326419611688),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 2097192,
      "h": 326419611688,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326419611688),
//--TRIMMABLE-BOUNDARY-START(322124644392),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 2097192,
      "h": 322124644392,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322124644392),
//--TRIMMABLE-BOUNDARY-START(60131639336),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 2097192,
      "h": 60131639336,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60131639336),
//--TRIMMABLE-BOUNDARY-START(55836672040),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 2097192,
      "h": 55836672040,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55836672040),
//--TRIMMABLE-BOUNDARY-START(85901443112),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 2097192,
      "h": 85901443112,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85901443112),
//--TRIMMABLE-BOUNDARY-START(81606475816),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 2097192,
      "h": 81606475816,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81606475816),
//--TRIMMABLE-BOUNDARY-START(197570592808),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 2097192,
      "h": 197570592808,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197570592808),
//--TRIMMABLE-BOUNDARY-START(193275625512),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 2097192,
      "h": 193275625512,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193275625512),
//--TRIMMABLE-BOUNDARY-START(489628368936),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 2097192,
      "h": 489628368936,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489628368936),
//--TRIMMABLE-BOUNDARY-START(485333401640),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 2097192,
      "h": 485333401640,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485333401640),
//--TRIMMABLE-BOUNDARY-START(163210854440),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 2097192,
      "h": 163210854440,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163210854440),
//--TRIMMABLE-BOUNDARY-START(158915887144),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 2097192,
      "h": 158915887144,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158915887144),
//--TRIMMABLE-BOUNDARY-START(206160527400),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 2097192,
      "h": 206160527400,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206160527400),
//--TRIMMABLE-BOUNDARY-START(201865560104),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 2097192,
      "h": 201865560104,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201865560104),
//--TRIMMABLE-BOUNDARY-START(399434055720),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 2097192,
      "h": 399434055720,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399434055720),
//--TRIMMABLE-BOUNDARY-START(395139088424),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 2097192,
      "h": 395139088424,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395139088424),
//--TRIMMABLE-BOUNDARY-START(300649807912),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 2097192,
      "h": 300649807912,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300649807912),
//--TRIMMABLE-BOUNDARY-START(296354840616),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 2097192,
      "h": 296354840616,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296354840616),
//--TRIMMABLE-BOUNDARY-START(377959219240),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 2097192,
      "h": 377959219240,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377959219240),
//--TRIMMABLE-BOUNDARY-START(373664251944),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 2097192,
      "h": 373664251944,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373664251944),
//--TRIMMABLE-BOUNDARY-START(231930331176),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 2097192,
      "h": 231930331176,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231930331176),
//--TRIMMABLE-BOUNDARY-START(227635363880),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 2097192,
      "h": 227635363880,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227635363880),
//--TRIMMABLE-BOUNDARY-START(154620919848),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 2097192,
      "h": 154620919848,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154620919848),
//--TRIMMABLE-BOUNDARY-START(150325952552),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 2097192,
      "h": 150325952552,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150325952552),
//--TRIMMABLE-BOUNDARY-START(352189415464),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 2097192,
      "h": 352189415464,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352189415464),
//--TRIMMABLE-BOUNDARY-START(347894448168),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 2097192,
      "h": 347894448168,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347894448168),
//--TRIMMABLE-BOUNDARY-START(360779350056),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 2097192,
      "h": 360779350056,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360779350056),
//--TRIMMABLE-BOUNDARY-START(356484382760),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 2097192,
      "h": 356484382760,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356484382760),
//--TRIMMABLE-BOUNDARY-START(17181966376),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 2097192,
      "h": 17181966376,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17181966376),
//--TRIMMABLE-BOUNDARY-START(12886999080),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 2097192,
      "h": 12886999080,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12886999080),
//--TRIMMABLE-BOUNDARY-START(408023990312),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 2097192,
      "h": 408023990312,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408023990312),
//--TRIMMABLE-BOUNDARY-START(403729023016),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 2097192,
      "h": 403729023016,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403729023016),
//--TRIMMABLE-BOUNDARY-START(498218303528),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 2097192,
      "h": 498218303528,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498218303528),
//--TRIMMABLE-BOUNDARY-START(493923336232),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 2097192,
      "h": 493923336232,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493923336232),
//--TRIMMABLE-BOUNDARY-START(283469938728),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 2097192,
      "h": 283469938728,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283469938728),
//--TRIMMABLE-BOUNDARY-START(279174971432),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 2097192,
      "h": 279174971432,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279174971432),
//--TRIMMABLE-BOUNDARY-START(506808238120),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 2097192,
      "h": 506808238120,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506808238120),
//--TRIMMABLE-BOUNDARY-START(502513270824),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 2097192,
      "h": 502513270824,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502513270824),
//--TRIMMABLE-BOUNDARY-START(274880004136),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 2097192,
      "h": 274880004136,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274880004136),
//--TRIMMABLE-BOUNDARY-START(270585036840),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 2097192,
      "h": 270585036840,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270585036840),
//--TRIMMABLE-BOUNDARY-START(481038434344),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 2097192,
      "h": 481038434344,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481038434344),
//--TRIMMABLE-BOUNDARY-START(476743467048),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 2097192,
      "h": 476743467048,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476743467048),
//--TRIMMABLE-BOUNDARY-START(128851116072),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 2097192,
      "h": 128851116072,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128851116072),
//--TRIMMABLE-BOUNDARY-START(124556148776),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 2097192,
      "h": 124556148776,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124556148776),
//--TRIMMABLE-BOUNDARY-START(111671246888),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 2097192,
      "h": 111671246888,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111671246888),
//--TRIMMABLE-BOUNDARY-START(107376279592),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 2097192,
      "h": 107376279592,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107376279592),
//--TRIMMABLE-BOUNDARY-START(335009546280),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 2097192,
      "h": 335009546280,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335009546280),
//--TRIMMABLE-BOUNDARY-START(330714578984),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 2097192,
      "h": 330714578984,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330714578984),
//--TRIMMABLE-BOUNDARY-START(68721573928),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 2097192,
      "h": 68721573928,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68721573928),
//--TRIMMABLE-BOUNDARY-START(64426606632),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 2097192,
      "h": 64426606632,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64426606632),
//--TRIMMABLE-BOUNDARY-START(390844121128),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 2097192,
      "h": 390844121128,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390844121128),
//--TRIMMABLE-BOUNDARY-START(386549153832),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 2097192,
      "h": 386549153832,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386549153832),
//--TRIMMABLE-BOUNDARY-START(309239742504),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 2097192,
      "h": 309239742504,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309239742504),
//--TRIMMABLE-BOUNDARY-START(304944775208),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 2097192,
      "h": 304944775208,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304944775208),
//--TRIMMABLE-BOUNDARY-START(42951770152),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 2097192,
      "h": 42951770152,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42951770152),
//--TRIMMABLE-BOUNDARY-START(38656802856),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 2097192,
      "h": 38656802856,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656802856),
//--TRIMMABLE-BOUNDARY-START(416613924904),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 2097192,
      "h": 416613924904,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416613924904),
//--TRIMMABLE-BOUNDARY-START(412318957608),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 2097192,
      "h": 412318957608,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412318957608),
//--TRIMMABLE-BOUNDARY-START(472448499752),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 2097192,
      "h": 472448499752,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472448499752),
//--TRIMMABLE-BOUNDARY-START(468153532456),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 2097192,
      "h": 468153532456,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468153532456),
//--TRIMMABLE-BOUNDARY-START(188980658216),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 2097192,
      "h": 188980658216,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188980658216),
//--TRIMMABLE-BOUNDARY-START(184685690920),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 2097192,
      "h": 184685690920,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184685690920),
//--TRIMMABLE-BOUNDARY-START(171800789032),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 2097192,
      "h": 171800789032,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171800789032),
//--TRIMMABLE-BOUNDARY-START(167505821736),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 2097192,
      "h": 167505821736,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167505821736),
//--TRIMMABLE-BOUNDARY-START(180390723624),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 2097192,
      "h": 180390723624,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180390723624),
//--TRIMMABLE-BOUNDARY-START(176095756328),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 2097192,
      "h": 176095756328,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176095756328),
//--TRIMMABLE-BOUNDARY-START(34361835560),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 2097192,
      "h": 34361835560,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34361835560),
//--TRIMMABLE-BOUNDARY-START(30066868264),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 2097192,
      "h": 30066868264,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30066868264),
//--TRIMMABLE-BOUNDARY-START(137441050664),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 2097192,
      "h": 137441050664,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137441050664),
//--TRIMMABLE-BOUNDARY-START(133146083368),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 2097192,
      "h": 133146083368,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133146083368),
//--TRIMMABLE-BOUNDARY-START(103081312296),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 2097192,
      "h": 103081312296,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103081312296),
//--TRIMMABLE-BOUNDARY-START(98786345000),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 2097192,
      "h": 98786345000,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98786345000),
//--TRIMMABLE-BOUNDARY-START(523988107304),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 2097192,
      "h": 523988107304,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523988107304),
//--TRIMMABLE-BOUNDARY-START(519693140008),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 2097192,
      "h": 519693140008,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519693140008),
//--TRIMMABLE-BOUNDARY-START(369369284648),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 2097192,
      "h": 369369284648,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369369284648),
//--TRIMMABLE-BOUNDARY-START(365074317352),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 2097192,
      "h": 365074317352,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365074317352),
//--TRIMMABLE-BOUNDARY-START(223340396584),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 2097192,
      "h": 223340396584,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223340396584),
//--TRIMMABLE-BOUNDARY-START(219045429288),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 2097192,
      "h": 219045429288,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219045429288),
//--TRIMMABLE-BOUNDARY-START(249110200360),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 2097192,
      "h": 249110200360,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249110200360),
//--TRIMMABLE-BOUNDARY-START(236225298472),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 2097192,
      "h": 236225298472,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236225298472),
//--TRIMMABLE-BOUNDARY-START(244815233064),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 2097192,
      "h": 244815233064,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244815233064),
//--TRIMMABLE-BOUNDARY-START(240520265768),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 2097192,
      "h": 240520265768,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240520265768),
//--TRIMMABLE-BOUNDARY-START(317829677096),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 2097192,
      "h": 317829677096,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317829677096),
//--TRIMMABLE-BOUNDARY-START(313534709800),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 2097192,
      "h": 313534709800,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313534709800),
//--TRIMMABLE-BOUNDARY-START(8592031784),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 2097192,
      "h": 8592031784,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8592031784),
//--TRIMMABLE-BOUNDARY-START(4297064488),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 2097192,
      "h": 4297064488,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4297064488),
//--TRIMMABLE-BOUNDARY-START(455268630568),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 2097192,
      "h": 455268630568,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455268630568),
//--TRIMMABLE-BOUNDARY-START(450973663272),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 2097192,
      "h": 450973663272,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450973663272),
//--TRIMMABLE-BOUNDARY-START(25771900968),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 2097192,
      "h": 25771900968,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25771900968),
//--TRIMMABLE-BOUNDARY-START(21476933672),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 2097192,
      "h": 21476933672,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21476933672),
//--TRIMMABLE-BOUNDARY-START(257700134952),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 2097192,
      "h": 257700134952,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257700134952),
//--TRIMMABLE-BOUNDARY-START(253405167656),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 2097192,
      "h": 253405167656,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253405167656),
//--TRIMMABLE-BOUNDARY-START(515398172712),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 2097192,
      "h": 515398172712,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515398172712),
//--TRIMMABLE-BOUNDARY-START(511103205416),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 2097192,
      "h": 511103205416,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511103205416),
//--TRIMMABLE-BOUNDARY-START(463858565160),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 2097192,
      "h": 463858565160,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463858565160),
//--TRIMMABLE-BOUNDARY-START(459563597864),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 2097192,
      "h": 459563597864,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459563597864),
//--TRIMMABLE-BOUNDARY-START(425203859496),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 2097192,
      "h": 425203859496,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425203859496),
//--TRIMMABLE-BOUNDARY-START(420908892200),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 2097192,
      "h": 420908892200,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420908892200),
//--TRIMMABLE-BOUNDARY-START(343599480872),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 2097192,
      "h": 343599480872,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343599480872),
//--TRIMMABLE-BOUNDARY-START(339304513576),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 2097192,
      "h": 339304513576,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339304513576),
//--TRIMMABLE-BOUNDARY-START(292059873320),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 2097192,
      "h": 292059873320,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292059873320),
//--TRIMMABLE-BOUNDARY-START(287764906024),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 2097192,
      "h": 287764906024,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287764906024),
//--TRIMMABLE-BOUNDARY-START(532578041896),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 2097192,
      "h": 532578041896,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532578041896),
//--TRIMMABLE-BOUNDARY-START(528283074600),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 2097192,
      "h": 528283074600,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528283074600)
  ],
  "h": 2097192
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097192)
        
        
        //--TRIMMABLE-BOUNDARY-START(917544)
        $asm.$cls("$scp.System.ComponentModel.EventHandlerList", ($self) => class EventHandlerList extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884840)
            /*ListEntry?*/ _head = null;
            //--TRIMMABLE-BOUNDARY-END(4295884840)
            
            //--TRIMMABLE-BOUNDARY-START(8590852136)
            /*Component?*/ _parent = null;
            //--TRIMMABLE-BOUNDARY-END(8590852136)
            
            //--TRIMMABLE-BOUNDARY-START(21475754024)
            $ctor$2(/*Component*/ parent)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._parent = parent;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754024)
            
            //--TRIMMABLE-BOUNDARY-START(17180786728)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786728)
            
            //--TRIMMABLE-BOUNDARY-START(64425426984)
            /*Delegate?*/ get_Item$1(/*object*/ key)
            {
                /*ListEntry?*/ let e = null;
                if (this._parent === null || this._parent.CanRaiseEventsInternal)
                {
                    e = this.Find(key);
                }
                return e?._handler ?? null;
            }
            /*void*/ set_Item$1(/*object*/ key, /*Delegate?*/ value)
            {
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = value;
                }
                else 
                {
                    this._head = new $.$scp.System.ComponentModel.EventHandlerList.ListEntry().$ctor$1(key, value, this._head);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425426984)
            
            //--TRIMMABLE-BOUNDARY-START(25770721320)
            /*void */ AddHandler(/*object*/ key, /*Delegate?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = $.$$.System.Delegate.Combine(e._handler, value);
                }
                else 
                {
                    this._head = new $.$scp.System.ComponentModel.EventHandlerList.ListEntry().$ctor$1(key, value, this._head);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770721320)
            
            //--TRIMMABLE-BOUNDARY-START(30065688616)
            /*void */ AddHandlers(/*EventHandlerList*/ listToAddFrom)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(listToAddFrom, "listToAddFrom");
                /*ListEntry?*/ let currentListEntry = listToAddFrom._head;
                while(currentListEntry !== null)
                {
                    this.AddHandler(currentListEntry._key, currentListEntry._handler);
                    currentListEntry = currentListEntry._next;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065688616)
            
            //--TRIMMABLE-BOUNDARY-START(34360655912)
            /*void */ Dispose()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360655912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._head = null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360655912)
            
            //--TRIMMABLE-BOUNDARY-START(38655623208)
            /*ListEntry? */ Find(/*object*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ListEntry?*/ let found = this._head;
                while(found !== null)
                {
                    if (found._key === key)
                    {
                        break;
                    }
                    found = found._next;
                }
                return found;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623208)
            
            //--TRIMMABLE-BOUNDARY-START(51540525096)
            /*void */ RemoveHandler(/*object*/ key, /*Delegate?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = $.$$.System.Delegate.Remove(e._handler, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540525096)
            
            //--TRIMMABLE-BOUNDARY-START(983080)
            static $_ListEntry;
            static get ListEntry()
            {
                let $cls = $.$scp.System.ComponentModel.EventHandlerList;
                return $cls.$_ListEntry ??= $asm.$ncls("$scp.System.ComponentModel.EventHandlerList.ListEntry", ($self) => class ListEntry extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(12885884968)
                    /*ListEntry?*/ _next = null;
                    //--TRIMMABLE-BOUNDARY-END(12885884968)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590917672)
                    /*object*/ _key = null;
                    //--TRIMMABLE-BOUNDARY-END(8590917672)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295950376)
                    /*Delegate?*/ _handler = null;
                    //--TRIMMABLE-BOUNDARY-END(4295950376)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180852264)
                    $ctor$1(/*object*/ key, /*Delegate?*/ handler, /*ListEntry?*/ next)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180852264);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._next = next;
                            this._key = key;
                            this._handler = handler;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180852264)
                    
                    static $h = 983080;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884968),
    {
      "t": 983080,
      "n": "_next",
      "d": 983080,
      "h": 12885884968,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885884968),
//--TRIMMABLE-BOUNDARY-START(8590917672),
    {
      "t": 131073,
      "n": "_key",
      "d": 983080,
      "h": 8590917672,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590917672),
//--TRIMMABLE-BOUNDARY-START(4295950376),
    {
      "t": 66781185,
      "n": "_handler",
      "d": 983080,
      "h": 4295950376,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295950376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180852264),
    {
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "handler",
          "p": 66781185
        },
        {
          "n": "next",
          "p": 983080
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983080,
      "h": 17180852264,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180852264)
  ],
  "d": 917544,
  "h": 983080
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.EventHandlerList.ListEntry`; }
                }, $cls, ($v) => $cls.$_ListEntry = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(983080)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            static $h = 917544;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(64425426984),
    {
      "p": 66781185,
      "i": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245557800,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130459688,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 917544,
      "h": 64425426984,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425426984)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770721320),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 66781185
        }
      ],
      "n": "AddHandler",
      "d": 917544,
      "h": 25770721320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721320),
//--TRIMMABLE-BOUNDARY-START(30065688616),
    {
      "r": 65537,
      "p": [
        {
          "n": "listToAddFrom",
          "p": 917544
        }
      ],
      "n": "AddHandlers",
      "d": 917544,
      "h": 30065688616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688616),
//--TRIMMABLE-BOUNDARY-START(34360655912),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 917544,
      "h": 34360655912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655912),
//--TRIMMABLE-BOUNDARY-START(38655623208),
    {
      "r": 983080,
      "p": [
        {
          "n": "key",
          "p": 131073
        }
      ],
      "n": "Find",
      "d": 917544,
      "h": 38655623208,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655623208),
//--TRIMMABLE-BOUNDARY-START(51540525096),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 131073
        },
        {
          "n": "value",
          "p": 66781185
        }
      ],
      "n": "RemoveHandler",
      "d": 917544,
      "h": 51540525096,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540525096)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884840),
    {
      "t": 983080,
      "n": "_head",
      "d": 917544,
      "h": 4295884840,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884840),
//--TRIMMABLE-BOUNDARY-START(8590852136),
    {
      "t": 196648,
      "n": "_parent",
      "d": 917544,
      "h": 8590852136,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475754024),
    {
      "p": [
        {
          "n": "parent",
          "p": 196648
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917544,
      "h": 21475754024,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475754024),
//--TRIMMABLE-BOUNDARY-START(17180786728),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917544,
      "h": 17180786728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786728)
  ],
  "i": [90308609
  ],
  "j": [983080
  ],
  "h": 917544
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.EventHandlerList`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917544)
        
        
        //--TRIMMABLE-BOUNDARY-START(852008)
        $asm.$cls("$scp.System.ComponentModel.EditorAttribute", ($self) => class EditorAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295819304)
            /*string?*/ _typeId = null;
            //--TRIMMABLE-BOUNDARY-END(4295819304)
            
            //--TRIMMABLE-BOUNDARY-START(17180721192)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180721192);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.EditorTypeName = $.$$.System.String.Empty;
                    this.EditorBaseTypeName = $.$$.System.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721192)
            
            //--TRIMMABLE-BOUNDARY-START(21475688488)
            $ctor$3(/*string*/ typeName, /*string?*/ baseTypeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688488);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.EditorTypeName = typeName;
                    this.EditorBaseTypeName = baseTypeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688488)
            
            //--TRIMMABLE-BOUNDARY-START(25770655784)
            $ctor$4(/*string*/ typeName, /*Type*/ baseType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655784);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseType, "baseType");
                    this.EditorTypeName = typeName;
                    this.EditorBaseTypeName = baseType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655784)
            
            //--TRIMMABLE-BOUNDARY-START(30065623080)
            $ctor$5(/*Type*/ type, /*Type*/ baseType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623080);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseType, "baseType");
                    this.EditorTypeName = type.AssemblyQualifiedName;
                    this.EditorBaseTypeName = baseType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623080)
            
            //--TRIMMABLE-BOUNDARY-START(34360590376)
            /*string?*/ EditorBaseTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(34360590376)
            
            //--TRIMMABLE-BOUNDARY-START(38655557672)
            /*string*/ EditorTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(38655557672)
            
            //--TRIMMABLE-BOUNDARY-START(77310263336)
            /*object */ get TypeId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720328744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.EditorBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263336)
            
            //--TRIMMABLE-BOUNDARY-START(42950524968)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950524968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === this)
                {
                    return true;
                }
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.EditorAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.EditorTypeName, this.EditorTypeName) && $.$$.System.String.op_Equality(other.EditorBaseTypeName, this.EditorBaseTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.EditorAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(42950524968)
            
            //--TRIMMABLE-BOUNDARY-START(73015296040)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015296040);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.EditorAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(73015296040)
            
            static $h = 852008;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360590376),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540459560,
        "f": 50331649
      },
      "n": "EditorBaseTypeName",
      "d": 852008,
      "h": 34360590376,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360590376),
//--TRIMMABLE-BOUNDARY-START(38655557672),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394152,
        "f": 50331649
      },
      "n": "EditorTypeName",
      "d": 852008,
      "h": 38655557672,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655557672),
//--TRIMMABLE-BOUNDARY-START(77310263336),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328744,
        "f": 50364417
      },
      "n": "TypeId",
      "d": 852008,
      "h": 77310263336,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77310263336)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950524968),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 852008,
      "h": 42950524968,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950524968),
//--TRIMMABLE-BOUNDARY-START(73015296040),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 852008,
      "h": 73015296040,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015296040)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295819304),
    {
      "t": 1310721,
      "n": "_typeId",
      "d": 852008,
      "h": 4295819304,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819304)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180721192),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852008,
      "h": 17180721192,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721192),
//--TRIMMABLE-BOUNDARY-START(21475688488),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "baseTypeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852008,
      "h": 21475688488,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688488),
//--TRIMMABLE-BOUNDARY-START(25770655784),
    {
      "p": [
        {
          "n": "typeName",
          "p": 1310721
        },
        {
          "n": "baseType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 852008,
      "h": 25770655784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655784),
//--TRIMMABLE-BOUNDARY-START(30065623080),
    {
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "baseType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 852008,
      "h": 30065623080,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623080)
  ],
  "h": 852008,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.EditorAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852008)
        
        
        //--TRIMMABLE-BOUNDARY-START(393256)
        $asm.$cls("$scp.System.ComponentModel.Design.Serialization.DesignerSerializerAttribute", ($self) => class DesignerSerializerAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295360552)
            /*string?*/ _typeId = null;
            //--TRIMMABLE-BOUNDARY-END(4295360552)
            
            //--TRIMMABLE-BOUNDARY-START(25770197032)
            $ctor$4(/*Type*/ serializerType, /*Type*/ baseSerializerType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197032);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serializerType, "serializerType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseSerializerType, "baseSerializerType");
                    this.SerializerTypeName = serializerType.AssemblyQualifiedName;
                    this.SerializerBaseTypeName = baseSerializerType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770197032)
            
            //--TRIMMABLE-BOUNDARY-START(21475229736)
            $ctor$3(/*string?*/ serializerTypeName, /*Type*/ baseSerializerType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229736);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseSerializerType, "baseSerializerType");
                    this.SerializerTypeName = serializerTypeName;
                    this.SerializerBaseTypeName = baseSerializerType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229736)
            
            //--TRIMMABLE-BOUNDARY-START(17180262440)
            $ctor$2(/*string?*/ serializerTypeName, /*string?*/ baseSerializerTypeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262440);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SerializerTypeName = serializerTypeName;
                    this.SerializerBaseTypeName = baseSerializerTypeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262440)
            
            //--TRIMMABLE-BOUNDARY-START(60129935400)
            /*string?*/ SerializerTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(60129935400)
            
            //--TRIMMABLE-BOUNDARY-START(55834968104)
            /*string?*/ SerializerBaseTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(55834968104)
            
            //--TRIMMABLE-BOUNDARY-START(64424902696)
            /*object */ get TypeId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.SerializerBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            //--TRIMMABLE-BOUNDARY-END(64424902696)
            
            static $h = 393256;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(60129935400),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066216,
        "f": 50331649
      },
      "n": "SerializerTypeName",
      "d": 393256,
      "h": 60129935400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60129935400),
//--TRIMMABLE-BOUNDARY-START(55834968104),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131624,
        "f": 50331649
      },
      "n": "SerializerBaseTypeName",
      "d": 393256,
      "h": 55834968104,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834968104),
//--TRIMMABLE-BOUNDARY-START(64424902696),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000808,
        "f": 50364417
      },
      "n": "TypeId",
      "d": 393256,
      "h": 64424902696,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64424902696)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295360552),
    {
      "t": 1310721,
      "n": "_typeId",
      "d": 393256,
      "h": 4295360552,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295360552)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770197032),
    {
      "p": [
        {
          "n": "serializerType",
          "p": 187760641
        },
        {
          "n": "baseSerializerType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393256,
      "h": 25770197032,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770197032),
//--TRIMMABLE-BOUNDARY-START(21475229736),
    {
      "p": [
        {
          "n": "serializerTypeName",
          "p": 1310721
        },
        {
          "n": "baseSerializerType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393256,
      "h": 21475229736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229736),
//--TRIMMABLE-BOUNDARY-START(17180262440),
    {
      "p": [
        {
          "n": "serializerTypeName",
          "p": 1310721
        },
        {
          "n": "baseSerializerTypeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393256,
      "h": 17180262440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262440)
  ],
  "h": 393256,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 1028,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.Design.Serialization.DesignerSerializerAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393256)
        
        
        //--TRIMMABLE-BOUNDARY-START(458792)
        $asm.$cls("$scp.System.ComponentModel.DesignerAttribute", ($self) => class DesignerAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295426088)
            /*string?*/ _typeId = null;
            //--TRIMMABLE-BOUNDARY-END(4295426088)
            
            //--TRIMMABLE-BOUNDARY-START(25770262568)
            $ctor$4(/*string*/ designerTypeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = "System.ComponentModel.Design.IDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770262568)
            
            //--TRIMMABLE-BOUNDARY-START(34360197160)
            $ctor$6(/*Type*/ designerType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360197160);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerType, "designerType");
                    this.DesignerTypeName = designerType.AssemblyQualifiedName;
                    this.DesignerBaseTypeName = "System.ComponentModel.Design.IDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197160)
            
            //--TRIMMABLE-BOUNDARY-START(17180327976)
            $ctor$2(/*string*/ designerTypeName, /*string*/ designerBaseTypeName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180327976);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = designerBaseTypeName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180327976)
            
            //--TRIMMABLE-BOUNDARY-START(21475295272)
            $ctor$3(/*string*/ designerTypeName, /*Type*/ designerBaseType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475295272);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerBaseType, "designerBaseType");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = designerBaseType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475295272)
            
            //--TRIMMABLE-BOUNDARY-START(30065229864)
            $ctor$5(/*Type*/ designerType, /*Type*/ designerBaseType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065229864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerType, "designerType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerBaseType, "designerBaseType");
                    this.DesignerTypeName = designerType.AssemblyQualifiedName;
                    this.DesignerBaseTypeName = designerBaseType.AssemblyQualifiedName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065229864)
            
            //--TRIMMABLE-BOUNDARY-START(38655164456)
            /*string*/ DesignerBaseTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(38655164456)
            
            //--TRIMMABLE-BOUNDARY-START(42950131752)
            /*string*/ DesignerTypeName = null;
            //--TRIMMABLE-BOUNDARY-END(42950131752)
            
            //--TRIMMABLE-BOUNDARY-START(81604837416)
            /*object */ get TypeId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.DesignerBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            //--TRIMMABLE-BOUNDARY-END(81604837416)
            
            //--TRIMMABLE-BOUNDARY-START(47245099048)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (obj === this)
                {
                    return true;
                }
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DesignerAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.DesignerBaseTypeName, this.DesignerBaseTypeName) && $.$$.System.String.op_Equality(other.DesignerTypeName, this.DesignerTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(47245099048)
            
            //--TRIMMABLE-BOUNDARY-START(77309870120)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309870120);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.DesignerBaseTypeName, this.DesignerTypeName);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(77309870120)
            
            static $h = 458792;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655164456),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033640,
        "f": 50331649
      },
      "n": "DesignerBaseTypeName",
      "d": 458792,
      "h": 38655164456,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655164456),
//--TRIMMABLE-BOUNDARY-START(42950131752),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968232,
        "f": 50331649
      },
      "n": "DesignerTypeName",
      "d": 458792,
      "h": 42950131752,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950131752),
//--TRIMMABLE-BOUNDARY-START(81604837416),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014902824,
        "f": 50364417
      },
      "n": "TypeId",
      "d": 458792,
      "h": 81604837416,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604837416)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245099048),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 458792,
      "h": 47245099048,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245099048),
//--TRIMMABLE-BOUNDARY-START(77309870120),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 458792,
      "h": 77309870120,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309870120)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426088),
    {
      "t": 1310721,
      "n": "_typeId",
      "d": 458792,
      "h": 4295426088,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426088)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770262568),
    {
      "p": [
        {
          "n": "designerTypeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458792,
      "h": 25770262568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770262568),
//--TRIMMABLE-BOUNDARY-START(34360197160),
    {
      "p": [
        {
          "n": "designerType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458792,
      "h": 34360197160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360197160),
//--TRIMMABLE-BOUNDARY-START(17180327976),
    {
      "p": [
        {
          "n": "designerTypeName",
          "p": 1310721
        },
        {
          "n": "designerBaseTypeName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458792,
      "h": 17180327976,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180327976),
//--TRIMMABLE-BOUNDARY-START(21475295272),
    {
      "p": [
        {
          "n": "designerTypeName",
          "p": 1310721
        },
        {
          "n": "designerBaseType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458792,
      "h": 21475295272,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475295272),
//--TRIMMABLE-BOUNDARY-START(30065229864),
    {
      "p": [
        {
          "n": "designerType",
          "p": 187760641
        },
        {
          "n": "designerBaseType",
          "p": 187760641
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458792,
      "h": 30065229864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229864)
  ],
  "h": 458792,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 1028,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": true,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458792)
        
        
        //--TRIMMABLE-BOUNDARY-START(720936)
        $asm.$cls("$scp.System.ComponentModel.DesignOnlyAttribute", ($self) => class DesignOnlyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51540328488)
            /*DesignOnlyAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51540328488)
            
            //--TRIMMABLE-BOUNDARY-START(47245361192)
            /*DesignOnlyAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47245361192)
            
            //--TRIMMABLE-BOUNDARY-START(17180590120)
            /*DesignOnlyAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17180590120)
            
            //--TRIMMABLE-BOUNDARY-START(12885622824)
            $ctor$2(/*bool*/ isDesignOnly)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.IsDesignOnly = isDesignOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622824)
            
            //--TRIMMABLE-BOUNDARY-START(42950393896)
            /*bool*/ IsDesignOnly = false;
            //--TRIMMABLE-BOUNDARY-END(42950393896)
            
            //--TRIMMABLE-BOUNDARY-START(21475557416)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557416);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.DesignOnlyAttribute, { set $v(v){ other = v; } }) && other.IsDesignOnly === this.IsDesignOnly;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignOnlyAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21475557416)
            
            //--TRIMMABLE-BOUNDARY-START(34360459304)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360459304);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Boolean.GetHashCode.call(this.IsDesignOnly);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignOnlyAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360459304)
            
            //--TRIMMABLE-BOUNDARY-START(38655426600)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426600);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsDesignOnly === $.$scp.System.ComponentModel.DesignOnlyAttribute.Default.IsDesignOnly;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426600)
            
            //--TRIMMABLE-BOUNDARY-START(8590655528)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328488)
                    this.Yes = new $.$scp.System.ComponentModel.DesignOnlyAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51540328488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361192)
                    this.No = new $.$scp.System.ComponentModel.DesignOnlyAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47245361192)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590120)
                    this.Default = $.$scp.System.ComponentModel.DesignOnlyAttribute.No;
                    //--TRIMMABLE-BOUNDARY-END(17180590120)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590655528)
            
            static $h = 720936;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950393896),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492008,
        "f": 50331649
      },
      "n": "IsDesignOnly",
      "d": 720936,
      "h": 42950393896,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950393896)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21475557416),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 720936,
      "h": 21475557416,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475557416),
//--TRIMMABLE-BOUNDARY-START(34360459304),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 720936,
      "h": 34360459304,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360459304),
//--TRIMMABLE-BOUNDARY-START(38655426600),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 720936,
      "h": 38655426600,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655426600)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540328488),
    {
      "t": 720936,
      "n": "Yes",
      "d": 720936,
      "h": 51540328488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328488),
//--TRIMMABLE-BOUNDARY-START(47245361192),
    {
      "t": 720936,
      "n": "No",
      "d": 720936,
      "h": 47245361192,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361192),
//--TRIMMABLE-BOUNDARY-START(17180590120),
    {
      "t": 720936,
      "n": "Default",
      "d": 720936,
      "h": 17180590120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590120)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622824),
    {
      "p": [
        {
          "n": "isDesignOnly",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720936,
      "h": 12885622824,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622824)
  ],
  "h": 720936,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignOnlyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720936)
        
        
        //--TRIMMABLE-BOUNDARY-START(655400)
        $asm.$cls("$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute", ($self) => class DesignerSerializationVisibilityAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17180524584)
            /*DesignerSerializationVisibilityAttribute*/ static Content = null;
            //--TRIMMABLE-BOUNDARY-END(17180524584)
            
            //--TRIMMABLE-BOUNDARY-START(42950328360)
            /*DesignerSerializationVisibilityAttribute*/ static Hidden = null;
            //--TRIMMABLE-BOUNDARY-END(42950328360)
            
            //--TRIMMABLE-BOUNDARY-START(55835230248)
            /*DesignerSerializationVisibilityAttribute*/ static Visible = null;
            //--TRIMMABLE-BOUNDARY-END(55835230248)
            
            //--TRIMMABLE-BOUNDARY-START(21475491880)
            /*DesignerSerializationVisibilityAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21475491880)
            
            //--TRIMMABLE-BOUNDARY-START(12885557288)
            $ctor$2(/*DesignerSerializationVisibility*/ visibility)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557288);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Visibility = visibility;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557288)
            
            //--TRIMMABLE-BOUNDARY-START(51540262952)
            /*DesignerSerializationVisibility*/ Visibility = 0;
            //--TRIMMABLE-BOUNDARY-END(51540262952)
            
            //--TRIMMABLE-BOUNDARY-START(25770459176)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770459176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute, { set $v(v){ other = v; } }) && other.Visibility === this.Visibility;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25770459176)
            
            //--TRIMMABLE-BOUNDARY-START(38655361064)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655361064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38655361064)
            
            //--TRIMMABLE-BOUNDARY-START(47245295656)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245295656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245295656)
            
            //--TRIMMABLE-BOUNDARY-START(8590589992)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524584)
                    this.Content = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(2/*DesignerSerializationVisibility.Content*/);
                    //--TRIMMABLE-BOUNDARY-END(17180524584)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950328360)
                    this.Hidden = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(0/*DesignerSerializationVisibility.Hidden*/);
                    //--TRIMMABLE-BOUNDARY-END(42950328360)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835230248)
                    this.Visible = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(1/*DesignerSerializationVisibility.Visible*/);
                    //--TRIMMABLE-BOUNDARY-END(55835230248)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475491880)
                    this.Default = $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Visible;
                    //--TRIMMABLE-BOUNDARY-END(21475491880)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590589992)
            
            static $h = 655400;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540262952),
    {
      "p": 589864,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393768,
        "f": 50331649
      },
      "n": "Visibility",
      "d": 655400,
      "h": 51540262952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540262952)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770459176),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 655400,
      "h": 25770459176,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770459176),
//--TRIMMABLE-BOUNDARY-START(38655361064),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 655400,
      "h": 38655361064,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655361064),
//--TRIMMABLE-BOUNDARY-START(47245295656),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 655400,
      "h": 47245295656,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245295656)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524584),
    {
      "t": 655400,
      "n": "Content",
      "d": 655400,
      "h": 17180524584,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524584),
//--TRIMMABLE-BOUNDARY-START(42950328360),
    {
      "t": 655400,
      "n": "Hidden",
      "d": 655400,
      "h": 42950328360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950328360),
//--TRIMMABLE-BOUNDARY-START(55835230248),
    {
      "t": 655400,
      "n": "Visible",
      "d": 655400,
      "h": 55835230248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835230248),
//--TRIMMABLE-BOUNDARY-START(21475491880),
    {
      "t": 655400,
      "n": "Default",
      "d": 655400,
      "h": 21475491880,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491880)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885557288),
    {
      "p": [
        {
          "n": "visibility",
          "p": 589864
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655400,
      "h": 12885557288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557288)
  ],
  "h": 655400,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 960,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerSerializationVisibilityAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655400)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245224)
        $asm.$cls("$scp.System.ComponentModel.InitializationEventAttribute", ($self) => class InitializationEventAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8591179816)
            $ctor$2(/*string*/ eventName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.EventName = eventName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179816)
            
            //--TRIMMABLE-BOUNDARY-START(12886147112)
            /*string*/ EventName = null;
            //--TRIMMABLE-BOUNDARY-END(12886147112)
            
            static $h = 1245224;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886147112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476081704,
        "f": 50331649
      },
      "n": "EventName",
      "d": 1245224,
      "h": 12886147112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886147112)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591179816),
    {
      "p": [
        {
          "n": "eventName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1245224,
      "h": 8591179816,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179816)
  ],
  "h": 1245224,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.InitializationEventAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245224)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179688)
        $asm.$cls("$scp.System.ComponentModel.ImmutableObjectAttribute", ($self) => class ImmutableObjectAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51540787240)
            /*ImmutableObjectAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51540787240)
            
            //--TRIMMABLE-BOUNDARY-START(47245819944)
            /*ImmutableObjectAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47245819944)
            
            //--TRIMMABLE-BOUNDARY-START(17181048872)
            /*ImmutableObjectAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17181048872)
            
            //--TRIMMABLE-BOUNDARY-START(12886081576)
            $ctor$2(/*bool*/ immutable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Immutable = immutable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081576)
            
            //--TRIMMABLE-BOUNDARY-START(38655885352)
            /*bool*/ Immutable = false;
            //--TRIMMABLE-BOUNDARY-END(38655885352)
            
            //--TRIMMABLE-BOUNDARY-START(21476016168)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.ImmutableObjectAttribute, { set $v(v){ other = v; } }) && other.Immutable === this.Immutable;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ImmutableObjectAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21476016168)
            
            //--TRIMMABLE-BOUNDARY-START(34360918056)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ImmutableObjectAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360918056)
            
            //--TRIMMABLE-BOUNDARY-START(42950852648)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950852648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.ImmutableObjectAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.ImmutableObjectAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950852648)
            
            //--TRIMMABLE-BOUNDARY-START(8591114280)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540787240)
                    this.Yes = new $.$scp.System.ComponentModel.ImmutableObjectAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51540787240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245819944)
                    this.No = new $.$scp.System.ComponentModel.ImmutableObjectAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47245819944)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181048872)
                    this.Default = $.$scp.System.ComponentModel.ImmutableObjectAttribute.No;
                    //--TRIMMABLE-BOUNDARY-END(17181048872)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591114280)
            
            static $h = 1179688;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655885352),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065950760,
        "f": 50331649
      },
      "n": "Immutable",
      "d": 1179688,
      "h": 38655885352,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655885352)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476016168),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179688,
      "h": 21476016168,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476016168),
//--TRIMMABLE-BOUNDARY-START(34360918056),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179688,
      "h": 34360918056,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360918056),
//--TRIMMABLE-BOUNDARY-START(42950852648),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1179688,
      "h": 42950852648,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950852648)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540787240),
    {
      "t": 1179688,
      "n": "Yes",
      "d": 1179688,
      "h": 51540787240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540787240),
//--TRIMMABLE-BOUNDARY-START(47245819944),
    {
      "t": 1179688,
      "n": "No",
      "d": 1179688,
      "h": 47245819944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245819944),
//--TRIMMABLE-BOUNDARY-START(17181048872),
    {
      "t": 1179688,
      "n": "Default",
      "d": 1179688,
      "h": 17181048872,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181048872)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081576),
    {
      "p": [
        {
          "n": "immutable",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179688,
      "h": 12886081576,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081576)
  ],
  "h": 1179688,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ImmutableObjectAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179688)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638440)
        $asm.$cls("$scp.System.ComponentModel.LocalizableAttribute", ($self) => class LocalizableAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(12886540328)
            $ctor$2(/*bool*/ isLocalizable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886540328);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.IsLocalizable = isLocalizable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886540328)
            
            //--TRIMMABLE-BOUNDARY-START(42951311400)
            /*bool*/ IsLocalizable = false;
            //--TRIMMABLE-BOUNDARY-END(42951311400)
            
            //--TRIMMABLE-BOUNDARY-START(51541245992)
            /*LocalizableAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51541245992)
            
            //--TRIMMABLE-BOUNDARY-START(47246278696)
            /*LocalizableAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47246278696)
            
            //--TRIMMABLE-BOUNDARY-START(17181507624)
            /*LocalizableAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17181507624)
            
            //--TRIMMABLE-BOUNDARY-START(21476474920)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476474920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.LocalizableAttribute, { set $v(v){ other = v; } }) && other.IsLocalizable === this.IsLocalizable;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.LocalizableAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21476474920)
            
            //--TRIMMABLE-BOUNDARY-START(34361376808)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361376808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.LocalizableAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361376808)
            
            //--TRIMMABLE-BOUNDARY-START(38656344104)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656344104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsLocalizable === $.$scp.System.ComponentModel.LocalizableAttribute.Default.IsLocalizable;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656344104)
            
            //--TRIMMABLE-BOUNDARY-START(8591573032)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51541245992)
                    this.Yes = new $.$scp.System.ComponentModel.LocalizableAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51541245992)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246278696)
                    this.No = new $.$scp.System.ComponentModel.LocalizableAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47246278696)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181507624)
                    this.Default = $.$scp.System.ComponentModel.LocalizableAttribute.No;
                    //--TRIMMABLE-BOUNDARY-END(17181507624)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591573032)
            
            static $h = 1638440;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951311400),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066409512,
        "f": 50331649
      },
      "n": "IsLocalizable",
      "d": 1638440,
      "h": 42951311400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951311400)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476474920),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1638440,
      "h": 21476474920,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476474920),
//--TRIMMABLE-BOUNDARY-START(34361376808),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1638440,
      "h": 34361376808,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361376808),
//--TRIMMABLE-BOUNDARY-START(38656344104),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1638440,
      "h": 38656344104,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656344104)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541245992),
    {
      "t": 1638440,
      "n": "Yes",
      "d": 1638440,
      "h": 51541245992,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541245992),
//--TRIMMABLE-BOUNDARY-START(47246278696),
    {
      "t": 1638440,
      "n": "No",
      "d": 1638440,
      "h": 47246278696,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246278696),
//--TRIMMABLE-BOUNDARY-START(17181507624),
    {
      "t": 1638440,
      "n": "Default",
      "d": 1638440,
      "h": 17181507624,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507624)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886540328),
    {
      "p": [
        {
          "n": "isLocalizable",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638440,
      "h": 12886540328,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886540328)
  ],
  "h": 1638440,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.LocalizableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638440)
        
        
        //--TRIMMABLE-BOUNDARY-START(65576)
        $asm.$cls("$scp.System.ComponentModel.BrowsableAttribute", ($self) => class BrowsableAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51539673128)
            /*BrowsableAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51539673128)
            
            //--TRIMMABLE-BOUNDARY-START(47244705832)
            /*BrowsableAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47244705832)
            
            //--TRIMMABLE-BOUNDARY-START(21474902056)
            /*BrowsableAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21474902056)
            
            //--TRIMMABLE-BOUNDARY-START(12884967464)
            $ctor$2(/*bool*/ browsable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Browsable = browsable;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967464)
            
            //--TRIMMABLE-BOUNDARY-START(17179934760)
            /*bool*/ Browsable = false;
            //--TRIMMABLE-BOUNDARY-END(17179934760)
            
            //--TRIMMABLE-BOUNDARY-START(25769869352)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.BrowsableAttribute, { set $v(v){ other = v; } }) && other.Browsable === this.Browsable;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.BrowsableAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25769869352)
            
            //--TRIMMABLE-BOUNDARY-START(38654771240)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654771240);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Boolean.GetHashCode.call(this.Browsable);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.BrowsableAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38654771240)
            
            //--TRIMMABLE-BOUNDARY-START(42949738536)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949738536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.BrowsableAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.BrowsableAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949738536)
            
            //--TRIMMABLE-BOUNDARY-START(8590000168)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51539673128)
                    this.Yes = new $.$scp.System.ComponentModel.BrowsableAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51539673128)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244705832)
                    this.No = new $.$scp.System.ComponentModel.BrowsableAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47244705832)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474902056)
                    this.Default = $.$scp.System.ComponentModel.BrowsableAttribute.Yes;
                    //--TRIMMABLE-BOUNDARY-END(21474902056)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000168)
            
            static $h = 65576;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934760),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359803944,
        "f": 50331649
      },
      "n": "Browsable",
      "d": 65576,
      "h": 17179934760,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934760)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869352),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 65576,
      "h": 25769869352,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25769869352),
//--TRIMMABLE-BOUNDARY-START(38654771240),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 65576,
      "h": 38654771240,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38654771240),
//--TRIMMABLE-BOUNDARY-START(42949738536),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 65576,
      "h": 42949738536,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949738536)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51539673128),
    {
      "t": 65576,
      "n": "Yes",
      "d": 65576,
      "h": 51539673128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539673128),
//--TRIMMABLE-BOUNDARY-START(47244705832),
    {
      "t": 65576,
      "n": "No",
      "d": 65576,
      "h": 47244705832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244705832),
//--TRIMMABLE-BOUNDARY-START(21474902056),
    {
      "t": 65576,
      "n": "Default",
      "d": 65576,
      "h": 21474902056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902056)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967464),
    {
      "p": [
        {
          "n": "browsable",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65576,
      "h": 12884967464,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967464)
  ],
  "h": 65576,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.BrowsableAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65576)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769512)
        $asm.$cls("$scp.System.ComponentModel.NotifyParentPropertyAttribute", ($self) => class NotifyParentPropertyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51541377064)
            /*NotifyParentPropertyAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51541377064)
            
            //--TRIMMABLE-BOUNDARY-START(42951442472)
            /*NotifyParentPropertyAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(42951442472)
            
            //--TRIMMABLE-BOUNDARY-START(17181638696)
            /*NotifyParentPropertyAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17181638696)
            
            //--TRIMMABLE-BOUNDARY-START(12886671400)
            $ctor$2(/*bool*/ notifyParent)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.NotifyParent = notifyParent;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671400)
            
            //--TRIMMABLE-BOUNDARY-START(47246409768)
            /*bool*/ NotifyParent = false;
            //--TRIMMABLE-BOUNDARY-END(47246409768)
            
            //--TRIMMABLE-BOUNDARY-START(21476605992)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476605992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.NotifyParentPropertyAttribute, { set $v(v){ other = v; } }) && other.NotifyParent === this.NotifyParent;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21476605992)
            
            //--TRIMMABLE-BOUNDARY-START(34361507880)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361507880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361507880)
            
            //--TRIMMABLE-BOUNDARY-START(38656475176)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656475176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656475176)
            
            //--TRIMMABLE-BOUNDARY-START(8591704104)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51541377064)
                    this.Yes = new $.$scp.System.ComponentModel.NotifyParentPropertyAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51541377064)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42951442472)
                    this.No = new $.$scp.System.ComponentModel.NotifyParentPropertyAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(42951442472)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181638696)
                    this.Default = $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.No;
                    //--TRIMMABLE-BOUNDARY-END(17181638696)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591704104)
            
            static $h = 1769512;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246409768),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066540584,
        "f": 50331649
      },
      "n": "NotifyParent",
      "d": 1769512,
      "h": 47246409768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246409768)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476605992),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1769512,
      "h": 21476605992,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476605992),
//--TRIMMABLE-BOUNDARY-START(34361507880),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1769512,
      "h": 34361507880,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361507880),
//--TRIMMABLE-BOUNDARY-START(38656475176),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1769512,
      "h": 38656475176,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656475176)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541377064),
    {
      "t": 1769512,
      "n": "Yes",
      "d": 1769512,
      "h": 51541377064,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541377064),
//--TRIMMABLE-BOUNDARY-START(42951442472),
    {
      "t": 1769512,
      "n": "No",
      "d": 1769512,
      "h": 42951442472,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951442472),
//--TRIMMABLE-BOUNDARY-START(17181638696),
    {
      "t": 1769512,
      "n": "Default",
      "d": 1769512,
      "h": 17181638696,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181638696)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886671400),
    {
      "p": [
        {
          "n": "notifyParent",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1769512,
      "h": 12886671400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671400)
  ],
  "h": 1769512,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 128,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.NotifyParentPropertyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769512)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703976)
        $asm.$cls("$scp.System.ComponentModel.MergablePropertyAttribute", ($self) => class MergablePropertyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51541311528)
            /*MergablePropertyAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51541311528)
            
            //--TRIMMABLE-BOUNDARY-START(47246344232)
            /*MergablePropertyAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47246344232)
            
            //--TRIMMABLE-BOUNDARY-START(21476540456)
            /*MergablePropertyAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21476540456)
            
            //--TRIMMABLE-BOUNDARY-START(12886605864)
            $ctor$2(/*bool*/ allowMerge)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886605864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.AllowMerge = allowMerge;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886605864)
            
            //--TRIMMABLE-BOUNDARY-START(17181573160)
            /*bool*/ AllowMerge = false;
            //--TRIMMABLE-BOUNDARY-END(17181573160)
            
            //--TRIMMABLE-BOUNDARY-START(25771507752)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771507752);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.MergablePropertyAttribute, { set $v(v){ other = v; } }) && other.AllowMerge === this.AllowMerge;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.MergablePropertyAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771507752)
            
            //--TRIMMABLE-BOUNDARY-START(38656409640)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656409640);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.MergablePropertyAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38656409640)
            
            //--TRIMMABLE-BOUNDARY-START(42951376936)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951376936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.MergablePropertyAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.MergablePropertyAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951376936)
            
            //--TRIMMABLE-BOUNDARY-START(8591638568)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51541311528)
                    this.Yes = new $.$scp.System.ComponentModel.MergablePropertyAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51541311528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246344232)
                    this.No = new $.$scp.System.ComponentModel.MergablePropertyAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47246344232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476540456)
                    this.Default = $.$scp.System.ComponentModel.MergablePropertyAttribute.Yes;
                    //--TRIMMABLE-BOUNDARY-END(21476540456)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591638568)
            
            static $h = 1703976;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181573160),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361442344,
        "f": 50331649
      },
      "n": "AllowMerge",
      "d": 1703976,
      "h": 17181573160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181573160)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771507752),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1703976,
      "h": 25771507752,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771507752),
//--TRIMMABLE-BOUNDARY-START(38656409640),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1703976,
      "h": 38656409640,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656409640),
//--TRIMMABLE-BOUNDARY-START(42951376936),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1703976,
      "h": 42951376936,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951376936)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541311528),
    {
      "t": 1703976,
      "n": "Yes",
      "d": 1703976,
      "h": 51541311528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541311528),
//--TRIMMABLE-BOUNDARY-START(47246344232),
    {
      "t": 1703976,
      "n": "No",
      "d": 1703976,
      "h": 47246344232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246344232),
//--TRIMMABLE-BOUNDARY-START(21476540456),
    {
      "t": 1703976,
      "n": "Default",
      "d": 1703976,
      "h": 21476540456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476540456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886605864),
    {
      "p": [
        {
          "n": "allowMerge",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703976,
      "h": 12886605864,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605864)
  ],
  "h": 1703976,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.MergablePropertyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703976)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900584)
        $asm.$cls("$scp.System.ComponentModel.ReadOnlyAttribute", ($self) => class ReadOnlyAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(51541508136)
            /*ReadOnlyAttribute*/ static Yes = null;
            //--TRIMMABLE-BOUNDARY-END(51541508136)
            
            //--TRIMMABLE-BOUNDARY-START(47246540840)
            /*ReadOnlyAttribute*/ static No = null;
            //--TRIMMABLE-BOUNDARY-END(47246540840)
            
            //--TRIMMABLE-BOUNDARY-START(17181769768)
            /*ReadOnlyAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(17181769768)
            
            //--TRIMMABLE-BOUNDARY-START(12886802472)
            $ctor$2(/*bool*/ isReadOnly)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886802472);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.IsReadOnly = isReadOnly;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802472)
            
            //--TRIMMABLE-BOUNDARY-START(42951573544)
            /*bool*/ IsReadOnly = false;
            //--TRIMMABLE-BOUNDARY-END(42951573544)
            
            //--TRIMMABLE-BOUNDARY-START(21476737064)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476737064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(value, $.$scp.System.ComponentModel.ReadOnlyAttribute, { set $v(v){ other = v; } }) && other.IsReadOnly === this.IsReadOnly;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ReadOnlyAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(21476737064)
            
            //--TRIMMABLE-BOUNDARY-START(34361638952)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361638952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ReadOnlyAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361638952)
            
            //--TRIMMABLE-BOUNDARY-START(38656606248)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656606248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsReadOnly === $.$scp.System.ComponentModel.ReadOnlyAttribute.Default.IsReadOnly;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656606248)
            
            //--TRIMMABLE-BOUNDARY-START(8591835176)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51541508136)
                    this.Yes = new $.$scp.System.ComponentModel.ReadOnlyAttribute().$ctor$2(true);
                    //--TRIMMABLE-BOUNDARY-END(51541508136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47246540840)
                    this.No = new $.$scp.System.ComponentModel.ReadOnlyAttribute().$ctor$2(false);
                    //--TRIMMABLE-BOUNDARY-END(47246540840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17181769768)
                    this.Default = $.$scp.System.ComponentModel.ReadOnlyAttribute.No;
                    //--TRIMMABLE-BOUNDARY-END(17181769768)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591835176)
            
            static $h = 1900584;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951573544),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066671656,
        "f": 50331649
      },
      "n": "IsReadOnly",
      "d": 1900584,
      "h": 42951573544,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951573544)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476737064),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1900584,
      "h": 21476737064,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476737064),
//--TRIMMABLE-BOUNDARY-START(34361638952),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1900584,
      "h": 34361638952,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361638952),
//--TRIMMABLE-BOUNDARY-START(38656606248),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1900584,
      "h": 38656606248,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656606248)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51541508136),
    {
      "t": 1900584,
      "n": "Yes",
      "d": 1900584,
      "h": 51541508136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541508136),
//--TRIMMABLE-BOUNDARY-START(47246540840),
    {
      "t": 1900584,
      "n": "No",
      "d": 1900584,
      "h": 47246540840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246540840),
//--TRIMMABLE-BOUNDARY-START(17181769768),
    {
      "t": 1900584,
      "n": "Default",
      "d": 1900584,
      "h": 17181769768,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181769768)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886802472),
    {
      "p": [
        {
          "n": "isReadOnly",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1900584,
      "h": 12886802472,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886802472)
  ],
  "h": 1900584,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ReadOnlyAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900584)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031656)
        $asm.$cls("$scp.System.ComponentModel.RefreshPropertiesAttribute", ($self) => class RefreshPropertiesAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(17181900840)
            /*RefreshPropertiesAttribute*/ static All = null;
            //--TRIMMABLE-BOUNDARY-END(17181900840)
            
            //--TRIMMABLE-BOUNDARY-START(51541639208)
            /*RefreshPropertiesAttribute*/ static Repaint = null;
            //--TRIMMABLE-BOUNDARY-END(51541639208)
            
            //--TRIMMABLE-BOUNDARY-START(21476868136)
            /*RefreshPropertiesAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21476868136)
            
            //--TRIMMABLE-BOUNDARY-START(12886933544)
            $ctor$2(/*RefreshProperties*/ refresh)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886933544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.RefreshProperties = refresh;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886933544)
            
            //--TRIMMABLE-BOUNDARY-START(47246671912)
            /*RefreshProperties*/ RefreshProperties = 0;
            //--TRIMMABLE-BOUNDARY-END(47246671912)
            
            //--TRIMMABLE-BOUNDARY-START(25771835432)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771835432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.RefreshPropertiesAttribute, { set $v(v){ other = v; } }) && other.RefreshProperties === this.RefreshProperties;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771835432)
            
            //--TRIMMABLE-BOUNDARY-START(38656737320)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656737320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38656737320)
            
            //--TRIMMABLE-BOUNDARY-START(42951704616)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951704616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951704616)
            
            //--TRIMMABLE-BOUNDARY-START(8591966248)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17181900840)
                    this.All = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(1/*RefreshProperties.All*/);
                    //--TRIMMABLE-BOUNDARY-END(17181900840)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51541639208)
                    this.Repaint = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(2/*RefreshProperties.Repaint*/);
                    //--TRIMMABLE-BOUNDARY-END(51541639208)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21476868136)
                    this.Default = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(0/*RefreshProperties.None*/);
                    //--TRIMMABLE-BOUNDARY-END(21476868136)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591966248)
            
            static $h = 2031656;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246671912),
    {
      "p": 1966120,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361770024,
        "f": 50331649
      },
      "n": "RefreshProperties",
      "d": 2031656,
      "h": 47246671912,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246671912)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771835432),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 2031656,
      "h": 25771835432,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771835432),
//--TRIMMABLE-BOUNDARY-START(38656737320),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 2031656,
      "h": 38656737320,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656737320),
//--TRIMMABLE-BOUNDARY-START(42951704616),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 2031656,
      "h": 42951704616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951704616)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181900840),
    {
      "t": 2031656,
      "n": "All",
      "d": 2031656,
      "h": 17181900840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181900840),
//--TRIMMABLE-BOUNDARY-START(51541639208),
    {
      "t": 2031656,
      "n": "Repaint",
      "d": 2031656,
      "h": 51541639208,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541639208),
//--TRIMMABLE-BOUNDARY-START(21476868136),
    {
      "t": 2031656,
      "n": "Default",
      "d": 2031656,
      "h": 21476868136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476868136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886933544),
    {
      "p": [
        {
          "n": "refresh",
          "p": 1966120
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2031656,
      "h": 12886933544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886933544)
  ],
  "h": 2031656,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.RefreshPropertiesAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031656)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835048)
        $asm.$cls("$scp.System.ComponentModel.ParenthesizePropertyNameAttribute", ($self) => class ParenthesizePropertyNameAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21476671528)
            /*ParenthesizePropertyNameAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21476671528)
            
            //--TRIMMABLE-BOUNDARY-START(12886736936)
            $ctor$2()
            {
                this.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886736936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886736936)
            
            //--TRIMMABLE-BOUNDARY-START(17181704232)
            $ctor$3(/*bool*/ needParenthesis)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181704232);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.NeedParenthesis = needParenthesis;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181704232)
            
            //--TRIMMABLE-BOUNDARY-START(47246475304)
            /*bool*/ NeedParenthesis = false;
            //--TRIMMABLE-BOUNDARY-END(47246475304)
            
            //--TRIMMABLE-BOUNDARY-START(25771638824)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771638824);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute, { set $v(v){ other = v; } }) && other.NeedParenthesis === this.NeedParenthesis;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25771638824)
            
            //--TRIMMABLE-BOUNDARY-START(38656540712)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656540712);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Attribute.GetHashCode.call(this);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38656540712)
            
            //--TRIMMABLE-BOUNDARY-START(42951508008)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951508008);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951508008)
            
            //--TRIMMABLE-BOUNDARY-START(8591769640)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21476671528)
                    this.Default = new $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(21476671528)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591769640)
            
            static $h = 1835048;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47246475304),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361573416,
        "f": 50331649
      },
      "n": "NeedParenthesis",
      "d": 1835048,
      "h": 47246475304,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246475304)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771638824),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1835048,
      "h": 25771638824,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771638824),
//--TRIMMABLE-BOUNDARY-START(38656540712),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1835048,
      "h": 38656540712,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656540712),
//--TRIMMABLE-BOUNDARY-START(42951508008),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 1835048,
      "h": 42951508008,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42951508008)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476671528),
    {
      "t": 1835048,
      "n": "Default",
      "d": 1835048,
      "h": 21476671528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476671528)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886736936),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1835048,
      "h": 12886736936,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886736936),
//--TRIMMABLE-BOUNDARY-START(17181704232),
    {
      "p": [
        {
          "n": "needParenthesis",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835048,
      "h": 17181704232,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181704232)
  ],
  "h": 1835048,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ParenthesizePropertyNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835048)
        
        
        //--TRIMMABLE-BOUNDARY-START(327720)
        $asm.$cls("$scp.System.ComponentModel.DescriptionAttribute", ($self) => class DescriptionAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475164200)
            /*DescriptionAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21475164200)
            
            //--TRIMMABLE-BOUNDARY-START(12885229608)
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229608);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229608)
            
            //--TRIMMABLE-BOUNDARY-START(17180196904)
            $ctor$3(/*string*/ description)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196904);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DescriptionValue = description;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196904)
            
            //--TRIMMABLE-BOUNDARY-START(25770131496)
            /*string */ get Description()
            {
                return this.DescriptionValue;
            }
            //--TRIMMABLE-BOUNDARY-END(25770131496)
            
            //--TRIMMABLE-BOUNDARY-START(30065098792)
            /*string*/ DescriptionValue = null;
            //--TRIMMABLE-BOUNDARY-END(30065098792)
            
            //--TRIMMABLE-BOUNDARY-START(34360066088)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360066088);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.DescriptionAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Description, this.Description);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DescriptionAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360066088)
            
            //--TRIMMABLE-BOUNDARY-START(55834902568)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834902568);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this.Description;
                    return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DescriptionAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(55834902568)
            
            //--TRIMMABLE-BOUNDARY-START(60129869864)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129869864);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.DescriptionAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DescriptionAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129869864)
            
            //--TRIMMABLE-BOUNDARY-START(8590262312)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21475164200)
                    this.Default = new $.$scp.System.ComponentModel.DescriptionAttribute().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(21475164200)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590262312)
            
            static $h = 327720;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770131496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950000680,
        "f": 50331777
      },
      "n": "Description",
      "d": 327720,
      "h": 25770131496,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770131496),
//--TRIMMABLE-BOUNDARY-START(30065098792),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539935272,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719804456,
        "f": 83886084
      },
      "n": "DescriptionValue",
      "d": 327720,
      "h": 30065098792,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(30065098792)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066088),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 327720,
      "h": 34360066088,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360066088),
//--TRIMMABLE-BOUNDARY-START(55834902568),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 327720,
      "h": 55834902568,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834902568),
//--TRIMMABLE-BOUNDARY-START(60129869864),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 327720,
      "h": 60129869864,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129869864)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475164200),
    {
      "t": 327720,
      "n": "Default",
      "d": 327720,
      "h": 21475164200,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164200)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229608),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327720,
      "h": 12885229608,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229608),
//--TRIMMABLE-BOUNDARY-START(17180196904),
    {
      "p": [
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327720,
      "h": 17180196904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196904)
  ],
  "h": 327720,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DescriptionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327720)
        
        
        //--TRIMMABLE-BOUNDARY-START(131112)
        $asm.$cls("$scp.System.ComponentModel.CategoryAttribute", ($self) => class CategoryAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590065704)
            /*bool*/ _localized = false;
            //--TRIMMABLE-BOUNDARY-END(8590065704)
            
            //--TRIMMABLE-BOUNDARY-START(12885033000)
            /*object*/ _locker = null;
            //--TRIMMABLE-BOUNDARY-END(12885033000)
            
            //--TRIMMABLE-BOUNDARY-START(4295098408)
            /*string*/ _categoryValue = null;
            //--TRIMMABLE-BOUNDARY-END(4295098408)
            
            //--TRIMMABLE-BOUNDARY-START(85899477032)
            /*CategoryAttribute*/ static Action$ = null;
            static /*CategoryAttribute */ get Action()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Action$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Action");
            }
            //--TRIMMABLE-BOUNDARY-END(85899477032)
            
            //--TRIMMABLE-BOUNDARY-START(90194444328)
            /*CategoryAttribute*/ static Appearance$ = null;
            static /*CategoryAttribute */ get Appearance()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Appearance$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Appearance");
            }
            //--TRIMMABLE-BOUNDARY-END(90194444328)
            
            //--TRIMMABLE-BOUNDARY-START(94489411624)
            /*CategoryAttribute*/ static Asynchronous$ = null;
            static /*CategoryAttribute */ get Asynchronous()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Asynchronous$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Asynchronous");
            }
            //--TRIMMABLE-BOUNDARY-END(94489411624)
            
            //--TRIMMABLE-BOUNDARY-START(98784378920)
            /*CategoryAttribute*/ static Behavior$ = null;
            static /*CategoryAttribute */ get Behavior()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Behavior$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Behavior");
            }
            //--TRIMMABLE-BOUNDARY-END(98784378920)
            
            //--TRIMMABLE-BOUNDARY-START(107374313512)
            /*CategoryAttribute*/ static Data$ = null;
            static /*CategoryAttribute */ get Data()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Data$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Data");
            }
            //--TRIMMABLE-BOUNDARY-END(107374313512)
            
            //--TRIMMABLE-BOUNDARY-START(111669280808)
            /*CategoryAttribute*/ static Default$ = null;
            static /*CategoryAttribute */ get Default()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Default$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(111669280808)
            
            //--TRIMMABLE-BOUNDARY-START(115964248104)
            /*CategoryAttribute*/ static Design$ = null;
            static /*CategoryAttribute */ get Design()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Design$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Design");
            }
            //--TRIMMABLE-BOUNDARY-END(115964248104)
            
            //--TRIMMABLE-BOUNDARY-START(120259215400)
            /*CategoryAttribute*/ static DragDrop$ = null;
            static /*CategoryAttribute */ get DragDrop()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.DragDrop$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("DragDrop");
            }
            //--TRIMMABLE-BOUNDARY-END(120259215400)
            
            //--TRIMMABLE-BOUNDARY-START(128849149992)
            /*CategoryAttribute*/ static Focus$ = null;
            static /*CategoryAttribute */ get Focus()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Focus$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Focus");
            }
            //--TRIMMABLE-BOUNDARY-END(128849149992)
            
            //--TRIMMABLE-BOUNDARY-START(133144117288)
            /*CategoryAttribute*/ static Format$ = null;
            static /*CategoryAttribute */ get Format()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Format$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Format");
            }
            //--TRIMMABLE-BOUNDARY-END(133144117288)
            
            //--TRIMMABLE-BOUNDARY-START(279173005352)
            /*CategoryAttribute*/ static Key$ = null;
            static /*CategoryAttribute */ get Key()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Key$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Key");
            }
            //--TRIMMABLE-BOUNDARY-END(279173005352)
            
            //--TRIMMABLE-BOUNDARY-START(283467972648)
            /*CategoryAttribute*/ static Layout$ = null;
            static /*CategoryAttribute */ get Layout()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Layout$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Layout");
            }
            //--TRIMMABLE-BOUNDARY-END(283467972648)
            
            //--TRIMMABLE-BOUNDARY-START(287762939944)
            /*CategoryAttribute*/ static Mouse$ = null;
            static /*CategoryAttribute */ get Mouse()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Mouse$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Mouse");
            }
            //--TRIMMABLE-BOUNDARY-END(287762939944)
            
            //--TRIMMABLE-BOUNDARY-START(292057907240)
            /*CategoryAttribute*/ static WindowStyle$ = null;
            static /*CategoryAttribute */ get WindowStyle()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.WindowStyle$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("WindowStyle");
            }
            //--TRIMMABLE-BOUNDARY-END(292057907240)
            
            //--TRIMMABLE-BOUNDARY-START(77309542440)
            $ctor$2()
            {
                this.$ctor$3("Default");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309542440);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309542440)
            
            //--TRIMMABLE-BOUNDARY-START(81604509736)
            $ctor$3(/*string*/ category)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604509736);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._categoryValue = category;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604509736)
            
            //--TRIMMABLE-BOUNDARY-START(103079346216)
            /*string */ get Category()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093790248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._localized)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._locker)
                        {
                            /*string?*/ let localizedValue = this.GetLocalizedString(this._categoryValue);
                            if ($.$$.System.String.op_Inequality(localizedValue, null))
                            {
                                this._categoryValue = localizedValue;
                            }
                            this._localized = true;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._locker)
                    }
                }
                return this._categoryValue;
            }
            //--TRIMMABLE-BOUNDARY-END(103079346216)
            
            //--TRIMMABLE-BOUNDARY-START(124554182696)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554182696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.CategoryAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Category, this.Category);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.CategoryAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(124554182696)
            
            //--TRIMMABLE-BOUNDARY-START(266288103464)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266288103464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this.Category;
                    return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.CategoryAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(266288103464)
            
            //--TRIMMABLE-BOUNDARY-START(270583070760)
            /*string? */ GetLocalizedString(/*string*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(270583070760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (() =>
                    {
                        if (value === "Action")
                        {
                            return $.$scp.System.SR.PropertyCategoryAction;
                        }
                        if (value === "Appearance")
                        {
                            return $.$scp.System.SR.PropertyCategoryAppearance;
                        }
                        if (value === "Asynchronous")
                        {
                            return $.$scp.System.SR.PropertyCategoryAsynchronous;
                        }
                        if (value === "Behavior")
                        {
                            return $.$scp.System.SR.PropertyCategoryBehavior;
                        }
                        if (value === "Config")
                        {
                            return $.$scp.System.SR.PropertyCategoryConfig;
                        }
                        if (value === "Data")
                        {
                            return $.$scp.System.SR.PropertyCategoryData;
                        }
                        if (value === "DDE")
                        {
                            return $.$scp.System.SR.PropertyCategoryDDE;
                        }
                        if (value === "Default")
                        {
                            return $.$scp.System.SR.PropertyCategoryDefault;
                        }
                        if (value === "Design")
                        {
                            return $.$scp.System.SR.PropertyCategoryDesign;
                        }
                        if (value === "DragDrop")
                        {
                            return $.$scp.System.SR.PropertyCategoryDragDrop;
                        }
                        if (value === "Focus")
                        {
                            return $.$scp.System.SR.PropertyCategoryFocus;
                        }
                        if (value === "Font")
                        {
                            return $.$scp.System.SR.PropertyCategoryFont;
                        }
                        if (value === "Format")
                        {
                            return $.$scp.System.SR.PropertyCategoryFormat;
                        }
                        if (value === "Key")
                        {
                            return $.$scp.System.SR.PropertyCategoryKey;
                        }
                        if (value === "Layout")
                        {
                            return $.$scp.System.SR.PropertyCategoryLayout;
                        }
                        if (value === "List")
                        {
                            return $.$scp.System.SR.PropertyCategoryList;
                        }
                        if (value === "Mouse")
                        {
                            return $.$scp.System.SR.PropertyCategoryMouse;
                        }
                        if (value === "Position")
                        {
                            return $.$scp.System.SR.PropertyCategoryPosition;
                        }
                        if (value === "Scale")
                        {
                            return $.$scp.System.SR.PropertyCategoryScale;
                        }
                        if (value === "Text")
                        {
                            return $.$scp.System.SR.PropertyCategoryText;
                        }
                        if (value === "WindowStyle")
                        {
                            return $.$scp.System.SR.PropertyCategoryWindowStyle;
                        }
                        return null;
                    })();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(270583070760)
            
            //--TRIMMABLE-BOUNDARY-START(274878038056)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274878038056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Equality(this.Category, $.$scp.System.ComponentModel.CategoryAttribute.Default.Category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274878038056)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(12885033000)
                this._locker = new $.$$.System.Object().$ctor();
                //--TRIMMABLE-BOUNDARY-END(12885033000)
                
            }
            static $h = 131112;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899477032),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734051880,
        "f": 50331681
      },
      "n": "Action",
      "d": 131112,
      "h": 85899477032,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(85899477032),
//--TRIMMABLE-BOUNDARY-START(90194444328),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150323986472,
        "f": 50331681
      },
      "n": "Appearance",
      "d": 131112,
      "h": 90194444328,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(90194444328),
//--TRIMMABLE-BOUNDARY-START(94489411624),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158913921064,
        "f": 50331681
      },
      "n": "Asynchronous",
      "d": 131112,
      "h": 94489411624,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(94489411624),
//--TRIMMABLE-BOUNDARY-START(98784378920),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503855656,
        "f": 50331681
      },
      "n": "Behavior",
      "d": 131112,
      "h": 98784378920,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(98784378920),
//--TRIMMABLE-BOUNDARY-START(107374313512),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683724840,
        "f": 50331681
      },
      "n": "Data",
      "d": 131112,
      "h": 107374313512,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(107374313512),
//--TRIMMABLE-BOUNDARY-START(111669280808),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273659432,
        "f": 50331681
      },
      "n": "Default",
      "d": 131112,
      "h": 111669280808,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111669280808),
//--TRIMMABLE-BOUNDARY-START(115964248104),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863594024,
        "f": 50331681
      },
      "n": "Design",
      "d": 131112,
      "h": 115964248104,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(115964248104),
//--TRIMMABLE-BOUNDARY-START(120259215400),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453528616,
        "f": 50331681
      },
      "n": "DragDrop",
      "d": 131112,
      "h": 120259215400,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120259215400),
//--TRIMMABLE-BOUNDARY-START(128849149992),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043463208,
        "f": 50331681
      },
      "n": "Focus",
      "d": 131112,
      "h": 128849149992,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(128849149992),
//--TRIMMABLE-BOUNDARY-START(133144117288),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633397800,
        "f": 50331681
      },
      "n": "Format",
      "d": 131112,
      "h": 133144117288,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(133144117288),
//--TRIMMABLE-BOUNDARY-START(279173005352),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223332392,
        "f": 50331681
      },
      "n": "Key",
      "d": 131112,
      "h": 279173005352,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(279173005352),
//--TRIMMABLE-BOUNDARY-START(283467972648),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813266984,
        "f": 50331681
      },
      "n": "Layout",
      "d": 131112,
      "h": 283467972648,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(283467972648),
//--TRIMMABLE-BOUNDARY-START(287762939944),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403201576,
        "f": 50331681
      },
      "n": "Mouse",
      "d": 131112,
      "h": 287762939944,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(287762939944),
//--TRIMMABLE-BOUNDARY-START(292057907240),
    {
      "p": 131112,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993136168,
        "f": 50331681
      },
      "n": "WindowStyle",
      "d": 131112,
      "h": 292057907240,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(292057907240),
//--TRIMMABLE-BOUNDARY-START(103079346216),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093790248,
        "f": 50331649
      },
      "n": "Category",
      "d": 131112,
      "h": 103079346216,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079346216)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(124554182696),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 131112,
      "h": 124554182696,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124554182696),
//--TRIMMABLE-BOUNDARY-START(266288103464),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 131112,
      "h": 266288103464,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266288103464),
//--TRIMMABLE-BOUNDARY-START(270583070760),
    {
      "r": 1310721,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "GetLocalizedString",
      "d": 131112,
      "h": 270583070760,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(270583070760),
//--TRIMMABLE-BOUNDARY-START(274878038056),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 131112,
      "h": 274878038056,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(274878038056)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065704),
    {
      "t": 262145,
      "n": "_localized",
      "d": 131112,
      "h": 8590065704,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065704),
//--TRIMMABLE-BOUNDARY-START(12885033000),
    {
      "t": 131073,
      "n": "_locker",
      "d": 131112,
      "h": 12885033000,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033000),
//--TRIMMABLE-BOUNDARY-START(4295098408),
    {
      "t": 1310721,
      "n": "_categoryValue",
      "d": 131112,
      "h": 4295098408,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098408)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(77309542440),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131112,
      "h": 77309542440,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309542440),
//--TRIMMABLE-BOUNDARY-START(81604509736),
    {
      "p": [
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131112,
      "h": 81604509736,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604509736)
  ],
  "h": 131112,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 32767,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.CategoryAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131112)
        
        
        //--TRIMMABLE-BOUNDARY-START(524328)
        $asm.$cls("$scp.System.ComponentModel.DesignerCategoryAttribute", ($self) => class DesignerCategoryAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(25770328104)
            /*DesignerCategoryAttribute*/ static Component = null;
            //--TRIMMABLE-BOUNDARY-END(25770328104)
            
            //--TRIMMABLE-BOUNDARY-START(30065295400)
            /*DesignerCategoryAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(30065295400)
            
            //--TRIMMABLE-BOUNDARY-START(38655229992)
            /*DesignerCategoryAttribute*/ static Form = null;
            //--TRIMMABLE-BOUNDARY-END(38655229992)
            
            //--TRIMMABLE-BOUNDARY-START(42950197288)
            /*DesignerCategoryAttribute*/ static Generic = null;
            //--TRIMMABLE-BOUNDARY-END(42950197288)
            
            //--TRIMMABLE-BOUNDARY-START(12885426216)
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426216);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426216)
            
            //--TRIMMABLE-BOUNDARY-START(17180393512)
            $ctor$3(/*string*/ category)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Category = category;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393512)
            
            //--TRIMMABLE-BOUNDARY-START(21475360808)
            /*string*/ Category = null;
            //--TRIMMABLE-BOUNDARY-END(21475360808)
            
            //--TRIMMABLE-BOUNDARY-START(34360262696)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.DesignerCategoryAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Category, this.Category);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerCategoryAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360262696)
            
            //--TRIMMABLE-BOUNDARY-START(64425033768)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425033768);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this.Category;
                    return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerCategoryAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(64425033768)
            
            //--TRIMMABLE-BOUNDARY-START(68720001064)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68720001064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.op_Equality(this.Category, $.$scp.System.ComponentModel.DesignerCategoryAttribute.Default.Category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68720001064)
            
            //--TRIMMABLE-BOUNDARY-START(73014968360)
            /*object */ get TypeId()
            {
                return $.$$.System.Object.GetType.call(this).FullName + this.Category;
            }
            //--TRIMMABLE-BOUNDARY-END(73014968360)
            
            //--TRIMMABLE-BOUNDARY-START(8590458920)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(25770328104)
                    this.Component = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Component");
                    //--TRIMMABLE-BOUNDARY-END(25770328104)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065295400)
                    this.Default = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(30065295400)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655229992)
                    this.Form = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Form");
                    //--TRIMMABLE-BOUNDARY-END(38655229992)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950197288)
                    this.Generic = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Designer");
                    //--TRIMMABLE-BOUNDARY-END(42950197288)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458920)
            
            static $h = 524328;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360808),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131880,
        "f": 50331649
      },
      "n": "Category",
      "d": 524328,
      "h": 21475360808,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360808),
//--TRIMMABLE-BOUNDARY-START(73014968360),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130066472,
        "f": 50364417
      },
      "n": "TypeId",
      "d": 524328,
      "h": 73014968360,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014968360)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360262696),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 524328,
      "h": 34360262696,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360262696),
//--TRIMMABLE-BOUNDARY-START(64425033768),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 524328,
      "h": 64425033768,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425033768),
//--TRIMMABLE-BOUNDARY-START(68720001064),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 524328,
      "h": 68720001064,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720001064)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328104),
    {
      "t": 524328,
      "n": "Component",
      "d": 524328,
      "h": 25770328104,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328104),
//--TRIMMABLE-BOUNDARY-START(30065295400),
    {
      "t": 524328,
      "n": "Default",
      "d": 524328,
      "h": 30065295400,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295400),
//--TRIMMABLE-BOUNDARY-START(38655229992),
    {
      "t": 524328,
      "n": "Form",
      "d": 524328,
      "h": 38655229992,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655229992),
//--TRIMMABLE-BOUNDARY-START(42950197288),
    {
      "t": 524328,
      "n": "Generic",
      "d": 524328,
      "h": 42950197288,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197288)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885426216),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524328,
      "h": 12885426216,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426216),
//--TRIMMABLE-BOUNDARY-START(17180393512),
    {
      "p": [
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524328,
      "h": 17180393512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393512)
  ],
  "h": 524328,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 4,
          "t": 45416449
        }
      ],
      "n": [
        {
          "n": "AllowMultiple",
          "v": false,
          "t": 262145
        },
        {
          "n": "Inherited",
          "v": true,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerCategoryAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524328)
        
        
        //--TRIMMABLE-BOUNDARY-START(786472)
        $asm.$cls("$scp.System.ComponentModel.DisplayNameAttribute", ($self) => class DisplayNameAttribute extends $.$$.System.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(21475622952)
            /*DisplayNameAttribute*/ static Default = null;
            //--TRIMMABLE-BOUNDARY-END(21475622952)
            
            //--TRIMMABLE-BOUNDARY-START(12885688360)
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688360)
            
            //--TRIMMABLE-BOUNDARY-START(17180655656)
            $ctor$3(/*string*/ displayName)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655656);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.DisplayNameValue = displayName;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655656)
            
            //--TRIMMABLE-BOUNDARY-START(25770590248)
            /*string */ get DisplayName()
            {
                return this.DisplayNameValue;
            }
            //--TRIMMABLE-BOUNDARY-END(25770590248)
            
            //--TRIMMABLE-BOUNDARY-START(30065557544)
            /*string*/ DisplayNameValue = null;
            //--TRIMMABLE-BOUNDARY-END(30065557544)
            
            //--TRIMMABLE-BOUNDARY-START(34360524840)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$scp.System.ComponentModel.DisplayNameAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.DisplayName, this.DisplayName);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DisplayNameAttribute.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34360524840)
            
            //--TRIMMABLE-BOUNDARY-START(55835361320)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835361320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this.DisplayName;
                    return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DisplayNameAttribute.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(55835361320)
            
            //--TRIMMABLE-BOUNDARY-START(60130328616)
            /*bool */ IsDefaultAttribute()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130328616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scp.System.ComponentModel.DisplayNameAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DisplayNameAttribute.Default);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130328616)
            
            //--TRIMMABLE-BOUNDARY-START(8590721064)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(21475622952)
                    this.Default = new $.$scp.System.ComponentModel.DisplayNameAttribute().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(21475622952)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590721064)
            
            static $h = 786472;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 45350913,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770590248),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950459432,
        "f": 50331777
      },
      "n": "DisplayName",
      "d": 786472,
      "h": 25770590248,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770590248),
//--TRIMMABLE-BOUNDARY-START(30065557544),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540394024,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720263208,
        "f": 83886084
      },
      "n": "DisplayNameValue",
      "d": 786472,
      "h": 30065557544,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(30065557544)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360524840),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 786472,
      "h": 34360524840,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360524840),
//--TRIMMABLE-BOUNDARY-START(55835361320),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 786472,
      "h": 55835361320,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835361320),
//--TRIMMABLE-BOUNDARY-START(60130328616),
    {
      "r": 262145,
      "n": "IsDefaultAttribute",
      "d": 786472,
      "h": 60130328616,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130328616)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475622952),
    {
      "t": 786472,
      "n": "Default",
      "d": 786472,
      "h": 21475622952,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688360),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786472,
      "h": 12885688360,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688360),
//--TRIMMABLE-BOUNDARY-START(17180655656),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786472,
      "h": 17180655656,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655656)
  ],
  "h": 786472,
  "a": [
    {
      "t": 45481985,
      "c": 25815285761,
      "a": [
        {
          "v": 708,
          "t": 45416449
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DisplayNameAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786472)
        
        
        //--TRIMMABLE-BOUNDARY-START(262184)
        $asm.$cls("$scp.System.ComponentModel.ComponentCollection", ($self) => class ComponentCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295229480)
            $ctor$2(/*IComponent[]*/ components)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.InnerList.AddRange(components);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229480)
            
            //--TRIMMABLE-BOUNDARY-START(34360000552)
            /*IComponent?*/ get_Item$2(/*string?*/ name)
            {
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    /*IList*/ let list = this.InnerList;
                    var $en3 = list.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var comp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (comp !== null && comp.System$ComponentModel$IComponent$Site !== null && $.$$.System.String.op_Inequality(comp.System$ComponentModel$IComponent$Site.System$ComponentModel$ISite$Name, null) && $.$$.System.String.Equals$2(comp.System$ComponentModel$IComponent$Site.System$ComponentModel$ISite$Name, name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return comp;
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(34360000552)
            
            //--TRIMMABLE-BOUNDARY-START(30065033256)
            /*IComponent?*/ get_Item$1(/*int*/ index)
            {
                return $.$cast(this.InnerList.get_Item(index), $.$scp.System.ComponentModel.IComponent);
        ;
            }
            //--TRIMMABLE-BOUNDARY-END(30065033256)
            
            //--TRIMMABLE-BOUNDARY-START(8590196776)
            /*void */ CopyTo(/*IComponent[]*/ array, /*int*/ index)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590196776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.InnerList.CopyTo(array, index);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196776)
            
            static $h = 262184;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655376,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360000552),
    {
      "p": 1048616,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770065960,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$2",
      "d": 262184,
      "h": 34360000552,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(34360000552),
//--TRIMMABLE-BOUNDARY-START(30065033256),
    {
      "p": 1048616,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180131368,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 262184,
      "h": 30065033256,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(30065033256)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590196776),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$scp.System.ComponentModel.IComponent).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 262184,
      "h": 8590196776,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590196776)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229480),
    {
      "p": [
        {
          "n": "components",
          "p": $.$typeArray($.$scp.System.ComponentModel.IComponent).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262184,
      "h": 4295229480,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229480)
  ],
  "i": [62390273,62652417
  ],
  "h": 262184
}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.ComponentModel.ComponentCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262184)
        
        
        //--TRIMMABLE-BOUNDARY-START(196648)
        $asm.$cls("$scp.System.ComponentModel.Component", ($self) => class Component extends $.$$.System.MarshalByRefObject
        {
            //--TRIMMABLE-BOUNDARY-START(133144182824)
            /*object*/ static s_eventDisposed = null;
            //--TRIMMABLE-BOUNDARY-END(133144182824)
            
            //--TRIMMABLE-BOUNDARY-START(8590131240)
            /*ISite?*/ _site = null;
            //--TRIMMABLE-BOUNDARY-END(8590131240)
            
            //--TRIMMABLE-BOUNDARY-START(4295163944)
            /*EventHandlerList?*/ _events = null;
            //--TRIMMABLE-BOUNDARY-END(4295163944)
            
            $dtor()
            {
                {
                    return this.Dispose$1(false);
                }
            }
            //--TRIMMABLE-BOUNDARY-START(30064967720)
            /*bool */ get CanRaiseEvents()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967720)
            
            //--TRIMMABLE-BOUNDARY-START(34359935016)
            /*bool */ get CanRaiseEventsInternal()
            {
                return this.CanRaiseEvents;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935016)
            
            //--TRIMMABLE-BOUNDARY-START(55834771496)
            /*EventHandler?*/ add_Disposed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Events.AddHandler($.$scp.System.ComponentModel.Component.s_eventDisposed, value);
            }
            /*EventHandler?*/ remove_Disposed(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849215528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Events.RemoveHandler($.$scp.System.ComponentModel.Component.s_eventDisposed, value);
            }
            //--TRIMMABLE-BOUNDARY-END(55834771496)
            
            //--TRIMMABLE-BOUNDARY-START(60129738792)
            /*EventHandlerList */ get Events()
            {
                return this._events ??= new $.$scp.System.ComponentModel.EventHandlerList().$ctor$2(this);
            }
            //--TRIMMABLE-BOUNDARY-END(60129738792)
            
            //--TRIMMABLE-BOUNDARY-START(146029084712)
            /*ISite? */ get Site()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964313640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._site;
            }
            /*ISite? */ set Site(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734117416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._site = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146029084712)
            
            //--TRIMMABLE-BOUNDARY-START(47244836904)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(47244836904)
            
            //--TRIMMABLE-BOUNDARY-START(51539804200)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539804200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            /*System.ComponentModel.ISite?*/ let __ca1__;
                            /*System.ComponentModel.IContainer?*/ let __ca2__;
                            if ((__ca1__ = this._site) !== null)
                            {
                                if ((__ca2__ = __ca1__.System$ComponentModel$ISite$Container) !== null)
                                {
                                    __ca2__.System$ComponentModel$IContainer$Remove(this);
                                }
                            }
                            if (this._events !== null)
                            {
                                ($.$cast(this._events.get_Item$1($.$scp.System.ComponentModel.Component.s_eventDisposed), $.$$.System.EventHandler))?.Invoke(this, $.$$.System.EventArgs.Empty);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539804200)
            
            //--TRIMMABLE-BOUNDARY-START(38654902312)
            /*IContainer? */ get Container()
            {
                return (this._site?.System$ComponentModel$ISite$Container ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(38654902312)
            
            //--TRIMMABLE-BOUNDARY-START(120259280936)
            /*object? */ GetService(/*Type*/ service)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259280936);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this._site?.System$IServiceProvider$GetService(service) ?? null);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259280936)
            
            //--TRIMMABLE-BOUNDARY-START(42949869608)
            /*bool */ get DesignMode()
            {
                return (this._site?.System$ComponentModel$ISite$DesignMode ?? null) ?? false;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869608)
            
            //--TRIMMABLE-BOUNDARY-START(150324052008)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324052008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ISite?*/ let s = this._site;
                if (s === null)
                {
                    return $.$$.System.Object.GetType.call(this).FullName;
                }
                return s.System$ComponentModel$ISite$Name + " [" + $.$$.System.Object.GetType.call(this).FullName + "]";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scp.System.ComponentModel.Component.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(150324052008)
            
            //--TRIMMABLE-BOUNDARY-START(21475885096)
            //Generated interface implemetation for System.ComponentModel.IComponent.Site.get
            get System$ComponentModel$IComponent$Site()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Site;
            }
            //--TRIMMABLE-BOUNDARY-END(21475885096)
            
            //--TRIMMABLE-BOUNDARY-START(38655754280)
            //Generated interface implemetation for System.ComponentModel.IComponent.Site.set
            set System$ComponentModel$IComponent$Site(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Site = value;
            }
            //--TRIMMABLE-BOUNDARY-END(38655754280)
            
            //--TRIMMABLE-BOUNDARY-START(8590983208)
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed.add
            System$ComponentModel$IComponent$add_Disposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.add_Disposed(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590983208)
            
            //--TRIMMABLE-BOUNDARY-START(30065819688)
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed.remove
            System$ComponentModel$IComponent$remove_Disposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.remove_Disposed(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(30065819688)
            
            //--TRIMMABLE-BOUNDARY-START(12885950504)
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed
            System$ComponentModel$IComponent$Disposed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Disposed;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950504)
            
            //--TRIMMABLE-BOUNDARY-START(4385275905)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385275905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385275905)
            
            //--TRIMMABLE-BOUNDARY-START(17180065832)
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065832)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            //--TRIMMABLE-BOUNDARY-START(12885098536)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(133144182824)
                    this.s_eventDisposed = new $.$$.System.Object().$ctor();
                    //--TRIMMABLE-BOUNDARY-END(133144182824)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098536)
            
            static $h = 196648;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 97779713,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064967720),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014640680,
        "f": 50331780
      },
      "n": "CanRaiseEvents",
      "d": 196648,
      "h": 30064967720,
      "f": 2097284
    },
//--TRIMMABLE-BOUNDARY-END(30064967720),
//--TRIMMABLE-BOUNDARY-START(34359935016),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604575272,
        "f": 50331656
      },
      "n": "CanRaiseEventsInternal",
      "d": 196648,
      "h": 34359935016,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(34359935016),
//--TRIMMABLE-BOUNDARY-START(60129738792),
    {
      "p": 917544,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374379048,
        "f": 50331652
      },
      "n": "Events",
      "d": 196648,
      "h": 60129738792,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(60129738792),
//--TRIMMABLE-BOUNDARY-START(146029084712),
    {
      "p": 1441832,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964313640,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734117416,
        "f": 83886209
      },
      "n": "Site",
      "d": 196648,
      "h": 146029084712,
      "f": 2097281,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 655400,
          "c": 12885557288,
          "a": [
            {
              "v": 0,
              "t": 589864
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(146029084712),
//--TRIMMABLE-BOUNDARY-START(38654902312),
    {
      "p": 1114152,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509864,
        "f": 50331649
      },
      "n": "Container",
      "d": 196648,
      "h": 38654902312,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 655400,
          "c": 12885557288,
          "a": [
            {
              "v": 0,
              "t": 589864
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654902312),
//--TRIMMABLE-BOUNDARY-START(42949869608),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784444456,
        "f": 50331652
      },
      "n": "DesignMode",
      "d": 196648,
      "h": 42949869608,
      "f": 2097156,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 655400,
          "c": 12885557288,
          "a": [
            {
              "v": 0,
              "t": 589864
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42949869608)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244836904),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 196648,
      "h": 47244836904,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244836904),
//--TRIMMABLE-BOUNDARY-START(51539804200),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 196648,
      "h": 51539804200,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(51539804200),
//--TRIMMABLE-BOUNDARY-START(120259280936),
    {
      "r": 131073,
      "p": [
        {
          "n": "service",
          "p": 187760641
        }
      ],
      "n": "GetService",
      "d": 196648,
      "h": 120259280936,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(120259280936),
//--TRIMMABLE-BOUNDARY-START(150324052008),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196648,
      "h": 150324052008,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324052008)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(133144182824),
    {
      "t": 131073,
      "n": "s_eventDisposed",
      "d": 196648,
      "h": 133144182824,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133144182824),
//--TRIMMABLE-BOUNDARY-START(8590131240),
    {
      "t": 1441832,
      "n": "_site",
      "d": 196648,
      "h": 8590131240,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590131240),
//--TRIMMABLE-BOUNDARY-START(4295163944),
    {
      "t": 917544,
      "n": "_events",
      "d": 196648,
      "h": 4295163944,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163944)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065832),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196648,
      "h": 17180065832,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065832)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(55834771496),
    {
      "e": 79822849,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79822849
          }
        ],
        "n": "add_Disposed",
        "d": 196648,
        "h": 25770000424,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79822849
          }
        ],
        "n": "remove_Disposed",
        "d": 196648,
        "h": 128849215528,
        "f": 285212673
      },
      "n": "Disposed",
      "d": 196648,
      "h": 55834771496,
      "f": 8388609,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 2,
              "t": 64356353
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834771496)
  ],
  "i": [1048616,90308609
  ],
  "h": 196648,
  "a": [
    {
      "t": 524328,
      "c": 17180393512,
      "a": [
        {
          "v": "Component",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.Component`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196648)
        
        
        //--TRIMMABLE-BOUNDARY-START(589864)
        $asm.$str("$scp.System.ComponentModel.DesignerSerializationVisibility", ($self) => class DesignerSerializationVisibility extends $.$$.System.Enum
        {
            static Hidden = 0;
            static Visible = 1;
            static Content = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Hidden": 0n,
                    "Visible": 1n,
                    "Content": 2n
                };
            }
            static $h = 589864;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491752),
    {
      "t": 589864,
      "n": "Hidden",
      "d": 589864,
      "h": 12885491752,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491752),
//--TRIMMABLE-BOUNDARY-START(17180459048),
    {
      "t": 589864,
      "n": "Visible",
      "d": 589864,
      "h": 17180459048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459048),
//--TRIMMABLE-BOUNDARY-START(8590524456),
    {
      "t": 589864,
      "n": "Content",
      "d": 589864,
      "h": 8590524456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557160),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589864,
      "h": 4295557160,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557160)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 589864
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DesignerSerializationVisibility`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589864)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966120)
        $asm.$str("$scp.System.ComponentModel.RefreshProperties", ($self) => class RefreshProperties extends $.$$.System.Enum
        {
            static None = 0;
            static All = 1;
            static Repaint = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1966120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "All": 1n,
                    "Repaint": 2n
                };
            }
            static $h = 1966120;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886868008),
    {
      "t": 1966120,
      "n": "None",
      "d": 1966120,
      "h": 12886868008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886868008),
//--TRIMMABLE-BOUNDARY-START(8591900712),
    {
      "t": 1966120,
      "n": "All",
      "d": 1966120,
      "h": 8591900712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591900712),
//--TRIMMABLE-BOUNDARY-START(17181835304),
    {
      "t": 1966120,
      "n": "Repaint",
      "d": 1966120,
      "h": 17181835304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181835304)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933416),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966120,
      "h": 4296933416,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933416)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1966120
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.RefreshProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966120)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310760)
        $asm.$cls("$scp.System.ComponentModel.InvalidAsynchronousStateException", ($self) => class InvalidAsynchronousStateException extends $.$$.System.ArgumentException
        {
            //--TRIMMABLE-BOUNDARY-START(4296278056)
            $ctor$15()
            {
                this.$ctor$18(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278056)
            
            //--TRIMMABLE-BOUNDARY-START(17181179944)
            $ctor$18(/*string?*/ message)
            {
                super.$ctor$14(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181179944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181179944)
            
            //--TRIMMABLE-BOUNDARY-START(12886212648)
            $ctor$17(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886212648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212648)
            
            //--TRIMMABLE-BOUNDARY-START(8591245352)
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245352)
            
            static $h = 1310760;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 44236801,
  "h": 1310760
}; }
            static get $b() { return $.$$.System.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.InvalidAsynchronousStateException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310760)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376296)
        $asm.$cls("$scp.System.ComponentModel.InvalidEnumArgumentException", ($self) => class InvalidEnumArgumentException extends $.$$.System.ArgumentException
        {
            //--TRIMMABLE-BOUNDARY-START(4296343592)
            $ctor$15()
            {
                this.$ctor$19(null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343592)
            
            //--TRIMMABLE-BOUNDARY-START(21476212776)
            $ctor$19(/*string?*/ message)
            {
                super.$ctor$14(message);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476212776);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476212776)
            
            //--TRIMMABLE-BOUNDARY-START(12886278184)
            $ctor$17(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886278184);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886278184)
            
            //--TRIMMABLE-BOUNDARY-START(17181245480)
            $ctor$18(/*string?*/ argumentName, /*int*/ invalidValue, /*Type*/ enumClass)
            {
                super.$ctor$13($.$scp.System.SR.Format$4($.$scp.System.SR.InvalidEnumArgument, argumentName, $.$box(invalidValue, $.$$.System.Int32), (enumClass?.Name ?? null)), argumentName);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181245480);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(enumClass, "enumClass");
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181245480)
            
            //--TRIMMABLE-BOUNDARY-START(8591310888)
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591310888);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591310888)
            
            static $h = 1376296;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 44236801,
  "h": 1376296
}; }
            static get $b() { return $.$$.System.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.InvalidEnumArgumentException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376296)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel"))
//--TRIMMABLE-BOUNDARY-END(40)
