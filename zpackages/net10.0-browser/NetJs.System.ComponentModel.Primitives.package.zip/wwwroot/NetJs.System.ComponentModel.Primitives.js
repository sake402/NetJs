
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel.Primitives", 
    {"h":39,"f":"System.ComponentModel.Primitives","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ComponentModel.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ComponentModel.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scp.System.ComponentModel.ISynchronizeInvoke", ($self) => class ISynchronizeInvoke
        {
            static $h = 1572903;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8591507495,"f":50331905},"n":"InvokeRequired","o":"System$ComponentModel$ISynchronizeInvoke$InvokeRequired","d":1572903,"h":4296540199,"f":2097409}],"m":[{"r":57016321,"p":[{"n":"method","p":35782657},{"n":"args","p":$.$typeArray($.$$.System.Object).$h}],"n":"BeginInvoke","o":"System$ComponentModel$ISynchronizeInvoke$BeginInvoke","d":1572903,"h":12886474791,"f":16777473},{"r":131073,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","o":"System$ComponentModel$ISynchronizeInvoke$EndInvoke","d":1572903,"h":17181442087,"f":16777473},{"r":131073,"p":[{"n":"method","p":35782657},{"n":"args","p":$.$typeArray($.$$.System.Object).$h}],"n":"Invoke","o":"System$ComponentModel$ISynchronizeInvoke$Invoke","d":1572903,"h":21476409383,"f":16777473}],"h":1572903}; }
            static get $fullName() { return `System.ComponentModel.ISynchronizeInvoke`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ISupportInitialize", ($self) => class ISupportInitialize
        {
            static $h = 1507367;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"BeginInit","o":"System$ComponentModel$ISupportInitialize$BeginInit","d":1507367,"h":4296474663,"f":16777473},{"r":65537,"n":"EndInit","o":"System$ComponentModel$ISupportInitialize$EndInit","d":1507367,"h":8591441959,"f":16777473}],"h":1507367}; }
            static get $fullName() { return `System.ComponentModel.ISupportInitialize`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.IContainer", ($self) => class IContainer
        {
            static $h = 1114151;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262183,"g":{"r":0,"d":0,"h":17180983335,"f":50331905},"n":"Components","o":"System$ComponentModel$IContainer$Components","d":1114151,"h":12886016039,"f":2097409}],"m":[{"r":65537,"p":[{"n":"component","p":1048615}],"n":"Add","o":"System$ComponentModel$IContainer$Add$1","d":1114151,"h":4296081447,"f":16777473},{"r":65537,"p":[{"n":"component","p":1048615},{"n":"name","p":1310721}],"n":"Add","o":"System$ComponentModel$IContainer$Add","d":1114151,"h":8591048743,"f":16777473},{"r":65537,"p":[{"n":"component","p":1048615}],"n":"Remove","o":"System$ComponentModel$IContainer$Remove","d":1114151,"h":21475950631,"f":16777473}],"i":[57540609],"h":1114151}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.IContainer`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.IComponent", ($self) => class IComponent
        {
            static $h = 1048615;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1441831,"g":{"r":0,"d":0,"h":8590983207,"f":50331905},"s":{"r":0,"d":0,"h":12885950503,"f":83886337},"n":"Site","o":"System$ComponentModel$IComponent$Site","d":1048615,"h":4296015911,"f":2097409}],"e":[{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Disposed","o":"System$ComponentModel$IComponent$add_Disposed","d":1048615,"h":17180917799,"f":150995201},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Disposed","o":"System$ComponentModel$IComponent$remove_Disposed","d":1048615,"h":21475885095,"f":285212929},"n":"Disposed","o":"System$ComponentModel$IComponent$Disposed","d":1048615,"h":25770852391,"f":8388865}],"i":[57540609],"h":1048615,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.ComponentModel.Design.ComponentDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":458791,"c":17180327975,"a":[{"v":"System.Windows.Forms.Design.ComponentDocumentDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.ComponentModel.Design.IRootDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.ComponentModel.ComponentConverter, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.IComponent`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ISite", ($self) => class ISite
        {
            static $h = 1441831;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1048615,"g":{"r":0,"d":0,"h":8591376423,"f":50331905},"n":"Component","o":"System$ComponentModel$ISite$Component","d":1441831,"h":4296409127,"f":2097409},{"p":1114151,"g":{"r":0,"d":0,"h":17181311015,"f":50331905},"n":"Container","o":"System$ComponentModel$ISite$Container","d":1441831,"h":12886343719,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":25771245607,"f":50331905},"n":"DesignMode","o":"System$ComponentModel$ISite$DesignMode","d":1441831,"h":21476278311,"f":2097409},{"p":1310721,"g":{"r":0,"d":0,"h":34361180199,"f":50331905},"s":{"r":0,"d":0,"h":38656147495,"f":83886337},"n":"Name","o":"System$ComponentModel$ISite$Name","d":1441831,"h":30066212903,"f":2097409}],"i":[327717],"h":1441831}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.IServiceProvider ]; }
            static get $fullName() { return `System.ComponentModel.ISite`; }
        });
        
        $asm.$cls("$scp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$scp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.ComponentModel.Primitives", $.$scp.System.SR.$type.Assembly);
                    $.$scp.System.SR.s_resourceManager = temp;
                }
                return $.$scp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$scp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$scp.System.SR.resourceCulture = value;
            }
            static /*string */ get InvalidEnumArgument()
            {
                return "The value of argument '{0}' ({1}) is invalid for Enum type '{2}'.";
            }
            static /*string */ FormatInvalidEnumArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("The value of argument '{0}' ({1}) is invalid for Enum type '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get PropertyCategoryAction()
            {
                return "Action";
            }
            static /*string */ get PropertyCategoryAppearance()
            {
                return "Appearance";
            }
            static /*string */ get PropertyCategoryAsynchronous()
            {
                return "Asynchronous";
            }
            static /*string */ get PropertyCategoryBehavior()
            {
                return "Behavior";
            }
            static /*string */ get PropertyCategoryConfig()
            {
                return "Configurations";
            }
            static /*string */ get PropertyCategoryData()
            {
                return "Data";
            }
            static /*string */ get PropertyCategoryDDE()
            {
                return "DDE";
            }
            static /*string */ get PropertyCategoryDefault()
            {
                return "Misc";
            }
            static /*string */ get PropertyCategoryDesign()
            {
                return "Design";
            }
            static /*string */ get PropertyCategoryDragDrop()
            {
                return "Drag Drop";
            }
            static /*string */ get PropertyCategoryFocus()
            {
                return "Focus";
            }
            static /*string */ get PropertyCategoryFont()
            {
                return "Font";
            }
            static /*string */ get PropertyCategoryFormat()
            {
                return "Format";
            }
            static /*string */ get PropertyCategoryKey()
            {
                return "Key";
            }
            static /*string */ get PropertyCategoryLayout()
            {
                return "Layout";
            }
            static /*string */ get PropertyCategoryList()
            {
                return "List";
            }
            static /*string */ get PropertyCategoryMouse()
            {
                return "Mouse";
            }
            static /*string */ get PropertyCategoryPosition()
            {
                return "Position";
            }
            static /*string */ get PropertyCategoryScale()
            {
                return "Scale";
            }
            static /*string */ get PropertyCategoryText()
            {
                return "Text";
            }
            static /*string */ get PropertyCategoryWindowStyle()
            {
                return "Window Style";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$scp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$scp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$scp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 2162727;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2162727}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$scp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 2097191;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":2097191,"h":4297064487,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":2097191,"h":8592031783,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":2097191,"h":12886999079,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":2097191,"h":17181966375,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":2097191,"h":21476933671,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":2097191,"h":25771900967,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":2097191,"h":30066868263,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":2097191,"h":34361835559,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":2097191,"h":38656802855,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":2097191,"h":42951770151,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":2097191,"h":47246737447,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":2097191,"h":51541704743,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":2097191,"h":55836672039,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":2097191,"h":60131639335,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":2097191,"h":64426606631,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":2097191,"h":68721573927,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":2097191,"h":73016541223,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":2097191,"h":77311508519,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":2097191,"h":81606475815,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":2097191,"h":85901443111,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":2097191,"h":90196410407,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":2097191,"h":94491377703,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":2097191,"h":98786344999,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":2097191,"h":103081312295,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":2097191,"h":107376279591,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":2097191,"h":111671246887,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":2097191,"h":115966214183,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":2097191,"h":120261181479,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":2097191,"h":124556148775,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":2097191,"h":128851116071,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":2097191,"h":133146083367,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":2097191,"h":137441050663,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":2097191,"h":141736017959,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":2097191,"h":146030985255,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":2097191,"h":150325952551,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":2097191,"h":154620919847,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":2097191,"h":158915887143,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":2097191,"h":163210854439,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":2097191,"h":167505821735,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":2097191,"h":171800789031,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":2097191,"h":176095756327,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":2097191,"h":180390723623,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":2097191,"h":184685690919,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":2097191,"h":188980658215,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":2097191,"h":193275625511,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":2097191,"h":197570592807,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":2097191,"h":201865560103,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":2097191,"h":206160527399,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":2097191,"h":210455494695,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":2097191,"h":214750461991,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":2097191,"h":219045429287,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":2097191,"h":223340396583,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":2097191,"h":227635363879,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":2097191,"h":231930331175,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":2097191,"h":236225298471,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":2097191,"h":240520265767,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":2097191,"h":244815233063,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":2097191,"h":249110200359,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":2097191,"h":253405167655,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":2097191,"h":257700134951,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":2097191,"h":261995102247,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":2097191,"h":266290069543,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":2097191,"h":270585036839,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":2097191,"h":274880004135,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":2097191,"h":279174971431,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":2097191,"h":283469938727,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":2097191,"h":287764906023,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":2097191,"h":292059873319,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":2097191,"h":296354840615,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":2097191,"h":300649807911,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":2097191,"h":304944775207,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":2097191,"h":309239742503,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":2097191,"h":313534709799,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":2097191,"h":317829677095,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":2097191,"h":322124644391,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":2097191,"h":326419611687,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":2097191,"h":330714578983,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":2097191,"h":335009546279,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":2097191,"h":339304513575,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":2097191,"h":343599480871,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":2097191,"h":347894448167,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":2097191,"h":352189415463,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":2097191,"h":356484382759,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":2097191,"h":360779350055,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":2097191,"h":365074317351,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":2097191,"h":369369284647,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":2097191,"h":373664251943,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":2097191,"h":377959219239,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":2097191,"h":382254186535,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":2097191,"h":386549153831,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":2097191,"h":390844121127,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":2097191,"h":395139088423,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":2097191,"h":399434055719,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":2097191,"h":403729023015,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":2097191,"h":408023990311,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":2097191,"h":412318957607,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":2097191,"h":416613924903,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":2097191,"h":420908892199,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":2097191,"h":425203859495,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":2097191,"h":429498826791,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":2097191,"h":433793794087,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":2097191,"h":438088761383,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":2097191,"h":442383728679,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":2097191,"h":446678695975,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":2097191,"h":450973663271,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":2097191,"h":455268630567,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":2097191,"h":459563597863,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":2097191,"h":463858565159,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":2097191,"h":468153532455,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":2097191,"h":472448499751,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":2097191,"h":476743467047,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":2097191,"h":481038434343,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":2097191,"h":485333401639,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":2097191,"h":489628368935,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":2097191,"h":493923336231,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":2097191,"h":498218303527,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":2097191,"h":502513270823,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":2097191,"h":506808238119,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":2097191,"h":511103205415,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":2097191,"h":515398172711,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":2097191,"h":519693140007,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":2097191,"h":523988107303,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":2097191,"h":528283074599,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":2097191,"h":532578041895,"f":4194344}],"h":2097191}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.EventHandlerList", ($self) => class EventHandlerList extends $.$$.System.Object
        {
            /*ListEntry?*/ _head = null;
            /*Component?*/ _parent = null;
            $ctor$2(/*Component*/ parent)
            {
                super.$ctor();
                {
                    this._parent = parent;
                }
                return this;
            }
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Delegate?*/ get_Item(/*object*/ key)
            {
                /*ListEntry?*/ let e = null;
                if (this._parent === null || this._parent.CanRaiseEventsInternal)
                {
                    e = this.Find(key);
                }
                return e?._handler ?? null;
            }
            /*void*/ set_Item(/*object*/ key, /*Delegate?*/ value)
            {
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = value;
                }
                else 
                {
                    this._head = new $.$scp.System.ComponentModel.EventHandlerList.ListEntry().$ctor$1(key, value, this._head);
                }
            }
            /*void */ AddHandler(/*object*/ key, /*Delegate?*/ value)
            {
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = $.$$.System.Delegate.Combine(e._handler, value);
                }
                else 
                {
                    this._head = new $.$scp.System.ComponentModel.EventHandlerList.ListEntry().$ctor$1(key, value, this._head);
                }
            }
            /*void */ AddHandlers(/*EventHandlerList*/ listToAddFrom)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(listToAddFrom, "listToAddFrom");
                /*ListEntry?*/ let currentListEntry = listToAddFrom._head;
                while(currentListEntry !== null)
                {
                    this.AddHandler(currentListEntry._key, currentListEntry._handler);
                    currentListEntry = currentListEntry._next;
                }
            }
            /*void */ Dispose()
            {
                return this._head = null;
            }
            /*ListEntry? */ Find(/*object*/ key)
            {
                /*ListEntry?*/ let found = this._head;
                while(found !== null)
                {
                    if (found._key === key)
                    {
                        break;
                    }
                    found = found._next;
                }
                return found;
            }
            /*void */ RemoveHandler(/*object*/ key, /*Delegate?*/ value)
            {
                /*ListEntry?*/ let e = this.Find(key);
                if (e !== null)
                {
                    e._handler = $.$$.System.Delegate.Remove(e._handler, value);
                }
            }
            static $_ListEntry;
            static get ListEntry()
            {
                let $cls = $.$scp.System.ComponentModel.EventHandlerList;
                return $cls.$_ListEntry ??= $asm.$ncls("$scp.System.ComponentModel.EventHandlerList.ListEntry", ($self) => class ListEntry extends $.$$.System.Object
                {
                    /*ListEntry?*/ _next = null;
                    /*object*/ _key = null;
                    /*Delegate?*/ _handler = null;
                    $ctor$1(/*object*/ key, /*Delegate?*/ handler, /*ListEntry?*/ next)
                    {
                        super.$ctor();
                        {
                            this._next = next;
                            this._key = key;
                            this._handler = handler;
                        }
                        return this;
                    }
                    static $h = 983079;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":983079,"n":"_next","d":983079,"h":4295950375,"f":4194312},{"t":131073,"n":"_key","d":983079,"h":8590917671,"f":4194312},{"t":35782657,"n":"_handler","d":983079,"h":12885884967,"f":4194312}],"c":[{"p":[{"n":"key","p":131073},{"n":"handler","p":35782657},{"n":"next","p":983079}],"n":".ctor","o":"$ctor$1","d":983079,"h":17180852263,"f":16777217}],"d":917543,"h":983079}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.ComponentModel.EventHandlerList.ListEntry`; }
                }, $cls, ($v) => $cls.$_ListEntry = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 917543;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":35782657,"i":[{"n":"key","p":131073}],"g":{"r":0,"d":0,"h":25770721319,"f":50331649},"s":{"r":0,"d":0,"h":30065688615,"f":83886081},"n":"Item","o":"@$2","d":917543,"h":21475754023,"f":2097153}],"m":[{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":35782657}],"n":"AddHandler","d":917543,"h":34360655911,"f":16777217},{"r":65537,"p":[{"n":"listToAddFrom","p":917543}],"n":"AddHandlers","d":917543,"h":38655623207,"f":16777217},{"r":65537,"n":"Dispose","d":917543,"h":42950590503,"f":16777217},{"r":983079,"p":[{"n":"key","p":131073}],"n":"Find","d":917543,"h":47245557799,"f":16777218},{"r":65537,"p":[{"n":"key","p":131073},{"n":"value","p":35782657}],"n":"RemoveHandler","d":917543,"h":51540525095,"f":16777217}],"l":[{"t":983079,"n":"_head","d":917543,"h":4295884839,"f":4194306},{"t":196647,"n":"_parent","d":917543,"h":8590852135,"f":4194306}],"c":[{"p":[{"n":"parent","p":196647}],"n":".ctor","o":"$ctor$2","d":917543,"h":12885819431,"f":16777224},{"n":".ctor","o":"$ctor$1","d":917543,"h":17180786727,"f":16777217}],"i":[57540609],"j":[983079],"h":917543}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.EventHandlerList`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ImmutableObjectAttribute", ($self) => class ImmutableObjectAttribute extends $.$$.System.Attribute
        {
            /*ImmutableObjectAttribute*/ static Yes = null;
            /*ImmutableObjectAttribute*/ static No = null;
            /*ImmutableObjectAttribute*/ static Default = null;
            $ctor$2(/*bool*/ immutable)
            {
                super.$ctor$1();
                {
                    this.Immutable = immutable;
                }
                return this;
            }
            /*bool*/ Immutable = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.ImmutableObjectAttribute, { set $v(v){ other = v; } }) && other.Immutable === this.Immutable;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ImmutableObjectAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ImmutableObjectAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.ImmutableObjectAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.ImmutableObjectAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Immutable = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.ImmutableObjectAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.ImmutableObjectAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.ImmutableObjectAttribute.No;
                }
            }
            static $h = 1179687;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065950759,"f":50331649},"n":"Immutable","d":1179687,"h":25770983463,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1179687,"h":34360918055,"f":16809985},{"r":655361,"n":"GetHashCode","d":1179687,"h":38655885351,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1179687,"h":42950852647,"f":16809985}],"l":[{"t":1179687,"n":"Yes","d":1179687,"h":4296146983,"f":4194337},{"t":1179687,"n":"No","d":1179687,"h":8591114279,"f":4194337},{"t":1179687,"n":"Default","d":1179687,"h":12886081575,"f":4194337}],"c":[{"p":[{"n":"immutable","p":262145}],"n":".ctor","o":"$ctor$2","d":1179687,"h":17181048871,"f":16777217}],"h":1179687,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ImmutableObjectAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.EditorAttribute", ($self) => class EditorAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _typeId = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                    this.EditorTypeName = $.$$.System.String.Empty;
                    this.EditorBaseTypeName = $.$$.System.String.Empty;
                }
                return this;
            }
            $ctor$3(/*string*/ typeName, /*string?*/ baseTypeName)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    this.EditorTypeName = typeName;
                    this.EditorBaseTypeName = baseTypeName;
                }
                return this;
            }
            $ctor$4(/*string*/ typeName, /*Type*/ baseType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(typeName, "typeName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseType, "baseType");
                    this.EditorTypeName = typeName;
                    this.EditorBaseTypeName = baseType.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$5(/*Type*/ type, /*Type*/ baseType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(type, "type");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseType, "baseType");
                    this.EditorTypeName = type.AssemblyQualifiedName;
                    this.EditorBaseTypeName = baseType.AssemblyQualifiedName;
                }
                return this;
            }
            /*string?*/ EditorBaseTypeName = null;
            /*string*/ EditorTypeName = null;
            /*object */ get TypeId()
            {
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.EditorBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                if (obj === this)
                {
                    return true;
                }
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.EditorAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.EditorTypeName, this.EditorTypeName) && $.$$.System.String.op_Equality(other.EditorBaseTypeName, this.EditorBaseTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.EditorAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.EditorAttribute.GetHashCode.apply(this, arguments); }
            static $h = 852007;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":34360590375,"f":50331649},"n":"EditorBaseTypeName","d":852007,"h":30065623079,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":47245492263,"f":50331649},"n":"EditorTypeName","d":852007,"h":42950524967,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":55835426855,"f":50364417},"n":"TypeId","d":852007,"h":51540459559,"f":2129921}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":852007,"h":60130394151,"f":16809985},{"r":655361,"n":"GetHashCode","d":852007,"h":64425361447,"f":16809985}],"l":[{"t":1310721,"n":"_typeId","d":852007,"h":4295819303,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":852007,"h":8590786599,"f":16777217},{"p":[{"n":"typeName","p":1310721},{"n":"baseTypeName","p":1310721}],"n":".ctor","o":"$ctor$3","d":852007,"h":12885753895,"f":16777217},{"p":[{"n":"typeName","p":1310721},{"n":"baseType","p":142475265}],"n":".ctor","o":"$ctor$4","d":852007,"h":17180721191,"f":16777217},{"p":[{"n":"type","p":142475265},{"n":"baseType","p":142475265}],"n":".ctor","o":"$ctor$5","d":852007,"h":21475688487,"f":16777217}],"h":852007,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.EditorAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.BrowsableAttribute", ($self) => class BrowsableAttribute extends $.$$.System.Attribute
        {
            /*BrowsableAttribute*/ static Yes = null;
            /*BrowsableAttribute*/ static No = null;
            /*BrowsableAttribute*/ static Default = null;
            $ctor$2(/*bool*/ browsable)
            {
                super.$ctor$1();
                {
                    this.Browsable = browsable;
                }
                return this;
            }
            /*bool*/ Browsable = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.BrowsableAttribute, { set $v(v){ other = v; } }) && other.Browsable === this.Browsable;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.BrowsableAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Boolean.GetHashCode.call(this.Browsable);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.BrowsableAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.BrowsableAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.BrowsableAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Browsable = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.BrowsableAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.BrowsableAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.BrowsableAttribute.Yes;
                }
            }
            static $h = 65575;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30064836647,"f":50331649},"n":"Browsable","d":65575,"h":25769869351,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":65575,"h":34359803943,"f":16809985},{"r":655361,"n":"GetHashCode","d":65575,"h":38654771239,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":65575,"h":42949738535,"f":16809985}],"l":[{"t":65575,"n":"Yes","d":65575,"h":4295032871,"f":4194337},{"t":65575,"n":"No","d":65575,"h":8590000167,"f":4194337},{"t":65575,"n":"Default","d":65575,"h":12884967463,"f":4194337}],"c":[{"p":[{"n":"browsable","p":262145}],"n":".ctor","o":"$ctor$2","d":65575,"h":17179934759,"f":16777217}],"h":65575,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.BrowsableAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DesignOnlyAttribute", ($self) => class DesignOnlyAttribute extends $.$$.System.Attribute
        {
            /*DesignOnlyAttribute*/ static Yes = null;
            /*DesignOnlyAttribute*/ static No = null;
            /*DesignOnlyAttribute*/ static Default = null;
            $ctor$2(/*bool*/ isDesignOnly)
            {
                super.$ctor$1();
                {
                    this.IsDesignOnly = isDesignOnly;
                }
                return this;
            }
            /*bool*/ IsDesignOnly = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DesignOnlyAttribute, { set $v(v){ other = v; } }) && other.IsDesignOnly === this.IsDesignOnly;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignOnlyAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Boolean.GetHashCode.call(this.IsDesignOnly);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignOnlyAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return this.IsDesignOnly === $.$scp.System.ComponentModel.DesignOnlyAttribute.Default.IsDesignOnly;
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsDesignOnly = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.DesignOnlyAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.DesignOnlyAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.DesignOnlyAttribute.No;
                }
            }
            static $h = 720935;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30065492007,"f":50331649},"n":"IsDesignOnly","d":720935,"h":25770524711,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":720935,"h":34360459303,"f":16809985},{"r":655361,"n":"GetHashCode","d":720935,"h":38655426599,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":720935,"h":42950393895,"f":16809985}],"l":[{"t":720935,"n":"Yes","d":720935,"h":4295688231,"f":4194337},{"t":720935,"n":"No","d":720935,"h":8590655527,"f":4194337},{"t":720935,"n":"Default","d":720935,"h":12885622823,"f":4194337}],"c":[{"p":[{"n":"isDesignOnly","p":262145}],"n":".ctor","o":"$ctor$2","d":720935,"h":17180590119,"f":16777217}],"h":720935,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignOnlyAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute", ($self) => class DesignerSerializationVisibilityAttribute extends $.$$.System.Attribute
        {
            /*DesignerSerializationVisibilityAttribute*/ static Content = null;
            /*DesignerSerializationVisibilityAttribute*/ static Hidden = null;
            /*DesignerSerializationVisibilityAttribute*/ static Visible = null;
            /*DesignerSerializationVisibilityAttribute*/ static Default = null;
            $ctor$2(/*DesignerSerializationVisibility*/ visibility)
            {
                super.$ctor$1();
                {
                    this.Visibility = visibility;
                }
                return this;
            }
            /*DesignerSerializationVisibility*/ Visibility = 0;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute, { set $v(v){ other = v; } }) && other.Visibility === this.Visibility;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Visibility = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Content = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(2/*DesignerSerializationVisibility.Content*/);
                }
                {
                    this.Hidden = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(0/*DesignerSerializationVisibility.Hidden*/);
                }
                {
                    this.Visible = new $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute().$ctor$2(1/*DesignerSerializationVisibility.Visible*/);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.DesignerSerializationVisibilityAttribute.Visible;
                }
            }
            static $h = 655399;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":589863,"g":{"r":0,"d":0,"h":34360393767,"f":50331649},"n":"Visibility","d":655399,"h":30065426471,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":655399,"h":38655361063,"f":16809985},{"r":655361,"n":"GetHashCode","d":655399,"h":42950328359,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":655399,"h":47245295655,"f":16809985}],"l":[{"t":655399,"n":"Content","d":655399,"h":4295622695,"f":4194337},{"t":655399,"n":"Hidden","d":655399,"h":8590589991,"f":4194337},{"t":655399,"n":"Visible","d":655399,"h":12885557287,"f":4194337},{"t":655399,"n":"Default","d":655399,"h":17180524583,"f":4194337}],"c":[{"p":[{"n":"visibility","p":589863}],"n":".ctor","o":"$ctor$2","d":655399,"h":21475491879,"f":16777217}],"h":655399,"a":[{"t":14745601,"c":21489582081,"a":[{"v":960,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerSerializationVisibilityAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.InitializationEventAttribute", ($self) => class InitializationEventAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*string*/ eventName)
            {
                super.$ctor$1();
                {
                    this.EventName = eventName;
                }
                return this;
            }
            /*string*/ EventName = null;
            static $h = 1245223;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":17181114407,"f":50331649},"n":"EventName","d":1245223,"h":12886147111,"f":2097153}],"c":[{"p":[{"n":"eventName","p":1310721}],"n":".ctor","o":"$ctor$2","d":1245223,"h":4296212519,"f":16777217}],"h":1245223,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.InitializationEventAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.LocalizableAttribute", ($self) => class LocalizableAttribute extends $.$$.System.Attribute
        {
            $ctor$2(/*bool*/ isLocalizable)
            {
                super.$ctor$1();
                {
                    this.IsLocalizable = isLocalizable;
                }
                return this;
            }
            /*bool*/ IsLocalizable = false;
            /*LocalizableAttribute*/ static Yes = null;
            /*LocalizableAttribute*/ static No = null;
            /*LocalizableAttribute*/ static Default = null;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.LocalizableAttribute, { set $v(v){ other = v; } }) && other.IsLocalizable === this.IsLocalizable;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.LocalizableAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.LocalizableAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return this.IsLocalizable === $.$scp.System.ComponentModel.LocalizableAttribute.Default.IsLocalizable;
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsLocalizable = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.LocalizableAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.LocalizableAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.LocalizableAttribute.No;
                }
            }
            static $h = 1638439;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17181507623,"f":50331649},"n":"IsLocalizable","d":1638439,"h":12886540327,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1638439,"h":34361376807,"f":16809985},{"r":655361,"n":"GetHashCode","d":1638439,"h":38656344103,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1638439,"h":42951311399,"f":16809985}],"l":[{"t":1638439,"n":"Yes","d":1638439,"h":21476474919,"f":4194337},{"t":1638439,"n":"No","d":1638439,"h":25771442215,"f":4194337},{"t":1638439,"n":"Default","d":1638439,"h":30066409511,"f":4194337}],"c":[{"p":[{"n":"isLocalizable","p":262145}],"n":".ctor","o":"$ctor$2","d":1638439,"h":4296605735,"f":16777217}],"h":1638439,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.LocalizableAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.NotifyParentPropertyAttribute", ($self) => class NotifyParentPropertyAttribute extends $.$$.System.Attribute
        {
            /*NotifyParentPropertyAttribute*/ static Yes = null;
            /*NotifyParentPropertyAttribute*/ static No = null;
            /*NotifyParentPropertyAttribute*/ static Default = null;
            $ctor$2(/*bool*/ notifyParent)
            {
                super.$ctor$1();
                {
                    this.NotifyParent = notifyParent;
                }
                return this;
            }
            /*bool*/ NotifyParent = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.NotifyParentPropertyAttribute, { set $v(v){ other = v; } }) && other.NotifyParent === this.NotifyParent;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.NotifyParent = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.NotifyParentPropertyAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.NotifyParentPropertyAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.NotifyParentPropertyAttribute.No;
                }
            }
            static $h = 1769511;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066540583,"f":50331649},"n":"NotifyParent","d":1769511,"h":25771573287,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1769511,"h":34361507879,"f":16809985},{"r":655361,"n":"GetHashCode","d":1769511,"h":38656475175,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1769511,"h":42951442471,"f":16809985}],"l":[{"t":1769511,"n":"Yes","d":1769511,"h":4296736807,"f":4194337},{"t":1769511,"n":"No","d":1769511,"h":8591704103,"f":4194337},{"t":1769511,"n":"Default","d":1769511,"h":12886671399,"f":4194337}],"c":[{"p":[{"n":"notifyParent","p":262145}],"n":".ctor","o":"$ctor$2","d":1769511,"h":17181638695,"f":16777217}],"h":1769511,"a":[{"t":14745601,"c":21489582081,"a":[{"v":128,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.NotifyParentPropertyAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ParenthesizePropertyNameAttribute", ($self) => class ParenthesizePropertyNameAttribute extends $.$$.System.Attribute
        {
            /*ParenthesizePropertyNameAttribute*/ static Default = null;
            $ctor$2()
            {
                this.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ needParenthesis)
            {
                super.$ctor$1();
                {
                    this.NeedParenthesis = needParenthesis;
                }
                return this;
            }
            /*bool*/ NeedParenthesis = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute, { set $v(v){ other = v; } }) && other.NeedParenthesis === this.NeedParenthesis;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.NeedParenthesis = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$scp.System.ComponentModel.ParenthesizePropertyNameAttribute().$ctor$2();
                }
            }
            static $h = 1835047;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771638823,"f":50331649},"n":"NeedParenthesis","d":1835047,"h":21476671527,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1835047,"h":30066606119,"f":16809985},{"r":655361,"n":"GetHashCode","d":1835047,"h":34361573415,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1835047,"h":38656540711,"f":16809985}],"l":[{"t":1835047,"n":"Default","d":1835047,"h":4296802343,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":1835047,"h":8591769639,"f":16777217},{"p":[{"n":"needParenthesis","p":262145}],"n":".ctor","o":"$ctor$3","d":1835047,"h":12886736935,"f":16777217}],"h":1835047,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ParenthesizePropertyNameAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.MergablePropertyAttribute", ($self) => class MergablePropertyAttribute extends $.$$.System.Attribute
        {
            /*MergablePropertyAttribute*/ static Yes = null;
            /*MergablePropertyAttribute*/ static No = null;
            /*MergablePropertyAttribute*/ static Default = null;
            $ctor$2(/*bool*/ allowMerge)
            {
                super.$ctor$1();
                {
                    this.AllowMerge = allowMerge;
                }
                return this;
            }
            /*bool*/ AllowMerge = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.MergablePropertyAttribute, { set $v(v){ other = v; } }) && other.AllowMerge === this.AllowMerge;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.MergablePropertyAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.MergablePropertyAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.MergablePropertyAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.MergablePropertyAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.AllowMerge = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.MergablePropertyAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.MergablePropertyAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.MergablePropertyAttribute.Yes;
                }
            }
            static $h = 1703975;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066475047,"f":50331649},"n":"AllowMerge","d":1703975,"h":25771507751,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1703975,"h":34361442343,"f":16809985},{"r":655361,"n":"GetHashCode","d":1703975,"h":38656409639,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1703975,"h":42951376935,"f":16809985}],"l":[{"t":1703975,"n":"Yes","d":1703975,"h":4296671271,"f":4194337},{"t":1703975,"n":"No","d":1703975,"h":8591638567,"f":4194337},{"t":1703975,"n":"Default","d":1703975,"h":12886605863,"f":4194337}],"c":[{"p":[{"n":"allowMerge","p":262145}],"n":".ctor","o":"$ctor$2","d":1703975,"h":17181573159,"f":16777217}],"h":1703975,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.MergablePropertyAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ReadOnlyAttribute", ($self) => class ReadOnlyAttribute extends $.$$.System.Attribute
        {
            /*ReadOnlyAttribute*/ static Yes = null;
            /*ReadOnlyAttribute*/ static No = null;
            /*ReadOnlyAttribute*/ static Default = null;
            $ctor$2(/*bool*/ isReadOnly)
            {
                super.$ctor$1();
                this.IsReadOnly = isReadOnly;
                return this;
            }
            /*bool*/ IsReadOnly = false;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ value)
            {
                let other;
                return $.$is(value, $.$scp.System.ComponentModel.ReadOnlyAttribute, { set $v(v){ other = v; } }) && other.IsReadOnly === this.IsReadOnly;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.ReadOnlyAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.ReadOnlyAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return this.IsReadOnly === $.$scp.System.ComponentModel.ReadOnlyAttribute.Default.IsReadOnly;
            }
            //default member initializer
            constructor()
            {
                super();
                this.IsReadOnly = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Yes = new $.$scp.System.ComponentModel.ReadOnlyAttribute().$ctor$2(true);
                }
                {
                    this.No = new $.$scp.System.ComponentModel.ReadOnlyAttribute().$ctor$2(false);
                }
                {
                    this.Default = $.$scp.System.ComponentModel.ReadOnlyAttribute.No;
                }
            }
            static $h = 1900583;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066671655,"f":50331649},"n":"IsReadOnly","d":1900583,"h":25771704359,"f":2097153}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"Equals","o":"@$1","d":1900583,"h":34361638951,"f":16809985},{"r":655361,"n":"GetHashCode","d":1900583,"h":38656606247,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":1900583,"h":42951573543,"f":16809985}],"l":[{"t":1900583,"n":"Yes","d":1900583,"h":4296867879,"f":4194337},{"t":1900583,"n":"No","d":1900583,"h":8591835175,"f":4194337},{"t":1900583,"n":"Default","d":1900583,"h":12886802471,"f":4194337}],"c":[{"p":[{"n":"isReadOnly","p":262145}],"n":".ctor","o":"$ctor$2","d":1900583,"h":17181769767,"f":16777217}],"h":1900583,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.ReadOnlyAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.Design.Serialization.DesignerSerializerAttribute", ($self) => class DesignerSerializerAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _typeId = null;
            $ctor$4(/*Type*/ serializerType, /*Type*/ baseSerializerType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(serializerType, "serializerType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseSerializerType, "baseSerializerType");
                    this.SerializerTypeName = serializerType.AssemblyQualifiedName;
                    this.SerializerBaseTypeName = baseSerializerType.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$3(/*string?*/ serializerTypeName, /*Type*/ baseSerializerType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseSerializerType, "baseSerializerType");
                    this.SerializerTypeName = serializerTypeName;
                    this.SerializerBaseTypeName = baseSerializerType.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$2(/*string?*/ serializerTypeName, /*string?*/ baseSerializerTypeName)
            {
                super.$ctor$1();
                {
                    this.SerializerTypeName = serializerTypeName;
                    this.SerializerBaseTypeName = baseSerializerTypeName;
                }
                return this;
            }
            /*string?*/ SerializerTypeName = null;
            /*string?*/ SerializerBaseTypeName = null;
            /*object */ get TypeId()
            {
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.SerializerBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            static $h = 393255;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":30065164327,"f":50331649},"n":"SerializerTypeName","d":393255,"h":25770197031,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":42950066215,"f":50331649},"n":"SerializerBaseTypeName","d":393255,"h":38655098919,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":51540000807,"f":50364417},"n":"TypeId","d":393255,"h":47245033511,"f":2129921}],"l":[{"t":1310721,"n":"_typeId","d":393255,"h":4295360551,"f":4194306}],"c":[{"p":[{"n":"serializerType","p":142475265},{"n":"baseSerializerType","p":142475265}],"n":".ctor","o":"$ctor$4","d":393255,"h":8590327847,"f":16777217},{"p":[{"n":"serializerTypeName","p":1310721},{"n":"baseSerializerType","p":142475265}],"n":".ctor","o":"$ctor$3","d":393255,"h":12885295143,"f":16777217},{"p":[{"n":"serializerTypeName","p":1310721},{"n":"baseSerializerTypeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":393255,"h":17180262439,"f":16777217}],"h":393255,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1028,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.Design.Serialization.DesignerSerializerAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DisplayNameAttribute", ($self) => class DisplayNameAttribute extends $.$$.System.Attribute
        {
            /*DisplayNameAttribute*/ static Default = null;
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ displayName)
            {
                super.$ctor$1();
                {
                    this.DisplayNameValue = displayName;
                }
                return this;
            }
            /*string */ get DisplayName()
            {
                return this.DisplayNameValue;
            }
            /*string*/ DisplayNameValue = null;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DisplayNameAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.DisplayName, this.DisplayName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DisplayNameAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this.DisplayName;
                return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DisplayNameAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.DisplayNameAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DisplayNameAttribute.Default);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$scp.System.ComponentModel.DisplayNameAttribute().$ctor$2();
                }
            }
            static $h = 786471;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475622951,"f":50331777},"n":"DisplayName","d":786471,"h":17180655655,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":34360524839,"f":50331652},"s":{"r":0,"d":0,"h":38655492135,"f":83886084},"n":"DisplayNameValue","d":786471,"h":30065557543,"f":2097156}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":786471,"h":42950459431,"f":16809985},{"r":655361,"n":"GetHashCode","d":786471,"h":47245426727,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":786471,"h":51540394023,"f":16809985}],"l":[{"t":786471,"n":"Default","d":786471,"h":4295753767,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":786471,"h":8590721063,"f":16777217},{"p":[{"n":"displayName","p":1310721}],"n":".ctor","o":"$ctor$3","d":786471,"h":12885688359,"f":16777217}],"h":786471,"a":[{"t":14745601,"c":21489582081,"a":[{"v":708,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DisplayNameAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DesignerCategoryAttribute", ($self) => class DesignerCategoryAttribute extends $.$$.System.Attribute
        {
            /*DesignerCategoryAttribute*/ static Component = null;
            /*DesignerCategoryAttribute*/ static Default = null;
            /*DesignerCategoryAttribute*/ static Form = null;
            /*DesignerCategoryAttribute*/ static Generic = null;
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ category)
            {
                super.$ctor$1();
                {
                    this.Category = category;
                }
                return this;
            }
            /*string*/ Category = null;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DesignerCategoryAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Category, this.Category);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerCategoryAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this.Category;
                return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerCategoryAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$$.System.String.op_Equality(this.Category, $.$scp.System.ComponentModel.DesignerCategoryAttribute.Default.Category);
            }
            /*object */ get TypeId()
            {
                return $.$$.System.Object.GetType.call(this).FullName + this.Category;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Component = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Component");
                }
                {
                    this.Default = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$2();
                }
                {
                    this.Form = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Form");
                }
                {
                    this.Generic = new $.$scp.System.ComponentModel.DesignerCategoryAttribute().$ctor$3("Designer");
                }
            }
            static $h = 524327;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38655229991,"f":50331649},"n":"Category","d":524327,"h":34360262695,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":60130066471,"f":50364417},"n":"TypeId","d":524327,"h":55835099175,"f":2129921}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":524327,"h":42950197287,"f":16809985},{"r":655361,"n":"GetHashCode","d":524327,"h":47245164583,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":524327,"h":51540131879,"f":16809985}],"l":[{"t":524327,"n":"Component","d":524327,"h":4295491623,"f":4194337},{"t":524327,"n":"Default","d":524327,"h":8590458919,"f":4194337},{"t":524327,"n":"Form","d":524327,"h":12885426215,"f":4194337},{"t":524327,"n":"Generic","d":524327,"h":17180393511,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":524327,"h":21475360807,"f":16777217},{"p":[{"n":"category","p":1310721}],"n":".ctor","o":"$ctor$3","d":524327,"h":25770328103,"f":16777217}],"h":524327,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}],"n":[{"n":"AllowMultiple","v":false,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerCategoryAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.RefreshPropertiesAttribute", ($self) => class RefreshPropertiesAttribute extends $.$$.System.Attribute
        {
            /*RefreshPropertiesAttribute*/ static All = null;
            /*RefreshPropertiesAttribute*/ static Repaint = null;
            /*RefreshPropertiesAttribute*/ static Default = null;
            $ctor$2(/*RefreshProperties*/ refresh)
            {
                super.$ctor$1();
                {
                    this.RefreshProperties = refresh;
                }
                return this;
            }
            /*RefreshProperties*/ RefreshProperties = 0;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.RefreshPropertiesAttribute, { set $v(v){ other = v; } }) && other.RefreshProperties === this.RefreshProperties;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.Attribute.GetHashCode.call(this);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.RefreshPropertiesAttribute.Default);
            }
            //default member initializer
            constructor()
            {
                super();
                this.RefreshProperties = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.All = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(1/*RefreshProperties.All*/);
                }
                {
                    this.Repaint = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(2/*RefreshProperties.Repaint*/);
                }
                {
                    this.Default = new $.$scp.System.ComponentModel.RefreshPropertiesAttribute().$ctor$2(0/*RefreshProperties.None*/);
                }
            }
            static $h = 2031655;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1966119,"g":{"r":0,"d":0,"h":30066802727,"f":50331649},"n":"RefreshProperties","d":2031655,"h":25771835431,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2031655,"h":34361770023,"f":16809985},{"r":655361,"n":"GetHashCode","d":2031655,"h":38656737319,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":2031655,"h":42951704615,"f":16809985}],"l":[{"t":2031655,"n":"All","d":2031655,"h":4296998951,"f":4194337},{"t":2031655,"n":"Repaint","d":2031655,"h":8591966247,"f":4194337},{"t":2031655,"n":"Default","d":2031655,"h":12886933543,"f":4194337}],"c":[{"p":[{"n":"refresh","p":1966119}],"n":".ctor","o":"$ctor$2","d":2031655,"h":17181900839,"f":16777217}],"h":2031655,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.RefreshPropertiesAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DescriptionAttribute", ($self) => class DescriptionAttribute extends $.$$.System.Attribute
        {
            /*DescriptionAttribute*/ static Default = null;
            $ctor$2()
            {
                this.$ctor$3($.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ description)
            {
                super.$ctor$1();
                {
                    this.DescriptionValue = description;
                }
                return this;
            }
            /*string */ get Description()
            {
                return this.DescriptionValue;
            }
            /*string*/ DescriptionValue = null;
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DescriptionAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Description, this.Description);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DescriptionAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this.Description;
                return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DescriptionAttribute.GetHashCode.apply(this, arguments); }
            /*bool */ IsDefaultAttribute()
            {
                return $.$scp.System.ComponentModel.DescriptionAttribute.Equals$1.call(this, $.$scp.System.ComponentModel.DescriptionAttribute.Default);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Default = new $.$scp.System.ComponentModel.DescriptionAttribute().$ctor$2();
                }
            }
            static $h = 327719;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475164199,"f":50331777},"n":"Description","d":327719,"h":17180196903,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":34360066087,"f":50331652},"s":{"r":0,"d":0,"h":38655033383,"f":83886084},"n":"DescriptionValue","d":327719,"h":30065098791,"f":2097156}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":327719,"h":42950000679,"f":16809985},{"r":655361,"n":"GetHashCode","d":327719,"h":47244967975,"f":16809985},{"r":262145,"n":"IsDefaultAttribute","d":327719,"h":51539935271,"f":16809985}],"l":[{"t":327719,"n":"Default","d":327719,"h":4295295015,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$2","d":327719,"h":8590262311,"f":16777217},{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$3","d":327719,"h":12885229607,"f":16777217}],"h":327719,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DescriptionAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.DesignerAttribute", ($self) => class DesignerAttribute extends $.$$.System.Attribute
        {
            /*string?*/ _typeId = null;
            $ctor$4(/*string*/ designerTypeName)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = "System.ComponentModel.Design.IDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                return this;
            }
            $ctor$6(/*Type*/ designerType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerType, "designerType");
                    this.DesignerTypeName = designerType.AssemblyQualifiedName;
                    this.DesignerBaseTypeName = "System.ComponentModel.Design.IDesigner, System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089";
                }
                return this;
            }
            $ctor$2(/*string*/ designerTypeName, /*string*/ designerBaseTypeName)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = designerBaseTypeName;
                }
                return this;
            }
            $ctor$3(/*string*/ designerTypeName, /*Type*/ designerBaseType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerTypeName, "designerTypeName");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerBaseType, "designerBaseType");
                    this.DesignerTypeName = designerTypeName;
                    this.DesignerBaseTypeName = designerBaseType.AssemblyQualifiedName;
                }
                return this;
            }
            $ctor$5(/*Type*/ designerType, /*Type*/ designerBaseType)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerType, "designerType");
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(designerBaseType, "designerBaseType");
                    this.DesignerTypeName = designerType.AssemblyQualifiedName;
                    this.DesignerBaseTypeName = designerBaseType.AssemblyQualifiedName;
                }
                return this;
            }
            /*string*/ DesignerBaseTypeName = null;
            /*string*/ DesignerTypeName = null;
            /*object */ get TypeId()
            {
                if ($.$$.System.String.op_Equality(this._typeId, null))
                {
                    /*string*/ let baseType = this.DesignerBaseTypeName ?? $.$$.System.String.Empty;
                    /*int*/ let comma = $.$$.System.String.IndexOf$3.call(baseType, /*,*/ 44);
                    if (comma !== -1)
                    {
                        baseType = $.$$.System.String.Substring.call(baseType, 0, comma);
                    }
                    this._typeId = $.$$.System.Object.GetType.call(this).FullName + baseType;
                }
                return this._typeId;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                if (obj === this)
                {
                    return true;
                }
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.DesignerAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.DesignerBaseTypeName, this.DesignerBaseTypeName) && $.$$.System.String.op_Equality(other.DesignerTypeName, this.DesignerTypeName);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.DesignerAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$$.System.String, $.$$.System.String, this.DesignerBaseTypeName, this.DesignerTypeName);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.DesignerAttribute.GetHashCode.apply(this, arguments); }
            static $h = 458791;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":38655164455,"f":50331649},"n":"DesignerBaseTypeName","d":458791,"h":34360197159,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540066343,"f":50331649},"n":"DesignerTypeName","d":458791,"h":47245099047,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":60130000935,"f":50364417},"n":"TypeId","d":458791,"h":55835033639,"f":2129921}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":458791,"h":64424968231,"f":16809985},{"r":655361,"n":"GetHashCode","d":458791,"h":68719935527,"f":16809985}],"l":[{"t":1310721,"n":"_typeId","d":458791,"h":4295426087,"f":4194306}],"c":[{"p":[{"n":"designerTypeName","p":1310721}],"n":".ctor","o":"$ctor$4","d":458791,"h":8590393383,"f":16777217},{"p":[{"n":"designerType","p":142475265}],"n":".ctor","o":"$ctor$6","d":458791,"h":12885360679,"f":16777217},{"p":[{"n":"designerTypeName","p":1310721},{"n":"designerBaseTypeName","p":1310721}],"n":".ctor","o":"$ctor$2","d":458791,"h":17180327975,"f":16777217},{"p":[{"n":"designerTypeName","p":1310721},{"n":"designerBaseType","p":142475265}],"n":".ctor","o":"$ctor$3","d":458791,"h":21475295271,"f":16777217},{"p":[{"n":"designerType","p":142475265},{"n":"designerBaseType","p":142475265}],"n":".ctor","o":"$ctor$5","d":458791,"h":25770262567,"f":16777217}],"h":458791,"a":[{"t":14745601,"c":21489582081,"a":[{"v":1028,"t":14680065}],"n":[{"n":"AllowMultiple","v":true,"t":262145},{"n":"Inherited","v":true,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.DesignerAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.CategoryAttribute", ($self) => class CategoryAttribute extends $.$$.System.Attribute
        {
            /*bool*/ _localized = false;
            /*object*/ _locker = null;
            /*string*/ _categoryValue = null;
            /*CategoryAttribute*/ static Action$ = null;
            static /*CategoryAttribute */ get Action()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Action$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Action");
            }
            /*CategoryAttribute*/ static Appearance$ = null;
            static /*CategoryAttribute */ get Appearance()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Appearance$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Appearance");
            }
            /*CategoryAttribute*/ static Asynchronous$ = null;
            static /*CategoryAttribute */ get Asynchronous()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Asynchronous$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Asynchronous");
            }
            /*CategoryAttribute*/ static Behavior$ = null;
            static /*CategoryAttribute */ get Behavior()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Behavior$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Behavior");
            }
            /*CategoryAttribute*/ static Data$ = null;
            static /*CategoryAttribute */ get Data()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Data$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Data");
            }
            /*CategoryAttribute*/ static Default$ = null;
            static /*CategoryAttribute */ get Default()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Default$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$2();
            }
            /*CategoryAttribute*/ static Design$ = null;
            static /*CategoryAttribute */ get Design()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Design$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Design");
            }
            /*CategoryAttribute*/ static DragDrop$ = null;
            static /*CategoryAttribute */ get DragDrop()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.DragDrop$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("DragDrop");
            }
            /*CategoryAttribute*/ static Focus$ = null;
            static /*CategoryAttribute */ get Focus()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Focus$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Focus");
            }
            /*CategoryAttribute*/ static Format$ = null;
            static /*CategoryAttribute */ get Format()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Format$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Format");
            }
            /*CategoryAttribute*/ static Key$ = null;
            static /*CategoryAttribute */ get Key()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Key$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Key");
            }
            /*CategoryAttribute*/ static Layout$ = null;
            static /*CategoryAttribute */ get Layout()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Layout$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Layout");
            }
            /*CategoryAttribute*/ static Mouse$ = null;
            static /*CategoryAttribute */ get Mouse()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.Mouse$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("Mouse");
            }
            /*CategoryAttribute*/ static WindowStyle$ = null;
            static /*CategoryAttribute */ get WindowStyle()
            {
                return $.$scp.System.ComponentModel.CategoryAttribute.WindowStyle$ ??= new $.$scp.System.ComponentModel.CategoryAttribute().$ctor$3("WindowStyle");
            }
            $ctor$2()
            {
                this.$ctor$3("Default");
                {
                }
                return this;
            }
            $ctor$3(/*string*/ category)
            {
                super.$ctor$1();
                {
                    this._categoryValue = category;
                }
                return this;
            }
            /*string */ get Category()
            {
                if (!this._localized)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this._locker)
                        {
                            /*string?*/ let localizedValue = this.GetLocalizedString(this._categoryValue);
                            if ($.$$.System.String.op_Inequality(localizedValue, null))
                            {
                                this._categoryValue = localizedValue;
                            }
                            this._localized = true;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this._locker)
                    }
                }
                return this._categoryValue;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$scp.System.ComponentModel.CategoryAttribute, { set $v(v){ other = v; } }) && $.$$.System.String.op_Equality(other.Category, this.Category);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scp.System.ComponentModel.CategoryAttribute.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this.Category;
                return $.$ifnn($t1, ($t) => $.$$.System.String.GetHashCode.call($t)) ?? 0;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scp.System.ComponentModel.CategoryAttribute.GetHashCode.apply(this, arguments); }
            /*string? */ GetLocalizedString(/*string*/ value)
            {
                return (() =>
                {
                    if (value === "Action")
                    {
                        return $.$scp.System.SR.PropertyCategoryAction;
                    }
                    if (value === "Appearance")
                    {
                        return $.$scp.System.SR.PropertyCategoryAppearance;
                    }
                    if (value === "Asynchronous")
                    {
                        return $.$scp.System.SR.PropertyCategoryAsynchronous;
                    }
                    if (value === "Behavior")
                    {
                        return $.$scp.System.SR.PropertyCategoryBehavior;
                    }
                    if (value === "Config")
                    {
                        return $.$scp.System.SR.PropertyCategoryConfig;
                    }
                    if (value === "Data")
                    {
                        return $.$scp.System.SR.PropertyCategoryData;
                    }
                    if (value === "DDE")
                    {
                        return $.$scp.System.SR.PropertyCategoryDDE;
                    }
                    if (value === "Default")
                    {
                        return $.$scp.System.SR.PropertyCategoryDefault;
                    }
                    if (value === "Design")
                    {
                        return $.$scp.System.SR.PropertyCategoryDesign;
                    }
                    if (value === "DragDrop")
                    {
                        return $.$scp.System.SR.PropertyCategoryDragDrop;
                    }
                    if (value === "Focus")
                    {
                        return $.$scp.System.SR.PropertyCategoryFocus;
                    }
                    if (value === "Font")
                    {
                        return $.$scp.System.SR.PropertyCategoryFont;
                    }
                    if (value === "Format")
                    {
                        return $.$scp.System.SR.PropertyCategoryFormat;
                    }
                    if (value === "Key")
                    {
                        return $.$scp.System.SR.PropertyCategoryKey;
                    }
                    if (value === "Layout")
                    {
                        return $.$scp.System.SR.PropertyCategoryLayout;
                    }
                    if (value === "List")
                    {
                        return $.$scp.System.SR.PropertyCategoryList;
                    }
                    if (value === "Mouse")
                    {
                        return $.$scp.System.SR.PropertyCategoryMouse;
                    }
                    if (value === "Position")
                    {
                        return $.$scp.System.SR.PropertyCategoryPosition;
                    }
                    if (value === "Scale")
                    {
                        return $.$scp.System.SR.PropertyCategoryScale;
                    }
                    if (value === "Text")
                    {
                        return $.$scp.System.SR.PropertyCategoryText;
                    }
                    if (value === "WindowStyle")
                    {
                        return $.$scp.System.SR.PropertyCategoryWindowStyle;
                    }
                    return null;
                })();
            }
            /*bool */ IsDefaultAttribute()
            {
                return $.$$.System.String.op_Equality(this.Category, $.$scp.System.ComponentModel.CategoryAttribute.Default.Category);
            }
            //default member initializer
            constructor()
            {
                super();
                this._locker = new $.$$.System.Object().$ctor();
            }
            static $h = 131111;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":131111,"g":{"r":0,"d":0,"h":25769934887,"f":50331681},"n":"Action","d":131111,"h":21474967591,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":38654836775,"f":50331681},"n":"Appearance","d":131111,"h":34359869479,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":51539738663,"f":50331681},"n":"Asynchronous","d":131111,"h":47244771367,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":64424640551,"f":50331681},"n":"Behavior","d":131111,"h":60129673255,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":77309542439,"f":50331681},"n":"Data","d":131111,"h":73014575143,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":90194444327,"f":50331681},"n":"Default","d":131111,"h":85899477031,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":103079346215,"f":50331681},"n":"Design","d":131111,"h":98784378919,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":115964248103,"f":50331681},"n":"DragDrop","d":131111,"h":111669280807,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":128849149991,"f":50331681},"n":"Focus","d":131111,"h":124554182695,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":141734051879,"f":50331681},"n":"Format","d":131111,"h":137439084583,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":154618953767,"f":50331681},"n":"Key","d":131111,"h":150323986471,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":167503855655,"f":50331681},"n":"Layout","d":131111,"h":163208888359,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":180388757543,"f":50331681},"n":"Mouse","d":131111,"h":176093790247,"f":2097185},{"p":131111,"g":{"r":0,"d":0,"h":193273659431,"f":50331681},"n":"WindowStyle","d":131111,"h":188978692135,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":210453528615,"f":50331649},"n":"Category","d":131111,"h":206158561319,"f":2097153}],"m":[{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":131111,"h":214748495911,"f":16809985},{"r":655361,"n":"GetHashCode","d":131111,"h":219043463207,"f":16809985},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"GetLocalizedString","d":131111,"h":223338430503,"f":16777348},{"r":262145,"n":"IsDefaultAttribute","d":131111,"h":227633397799,"f":16809985}],"l":[{"t":262145,"n":"_localized","d":131111,"h":4295098407,"f":4194306},{"t":131073,"n":"_locker","d":131111,"h":8590065703,"f":4194306},{"t":1310721,"n":"_categoryValue","d":131111,"h":12885032999,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":131111,"h":197568626727,"f":16777217},{"p":[{"n":"category","p":1310721}],"n":".ctor","o":"$ctor$3","d":131111,"h":201863594023,"f":16777217}],"h":131111,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.ComponentModel.CategoryAttribute`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.ComponentCollection", ($self) => class ComponentCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*IComponent[]*/ components)
            {
                super.$ctor$1();
                this.InnerList.AddRange(components);
                return this;
            }
            /*IComponent?*/ get_Item$1(/*string?*/ name)
            {
                if ($.$$.System.String.op_Inequality(name, null))
                {
                    /*IList*/ let list = this.InnerList;
                    var $en3 = list.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var comp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (comp !== null && comp.System$ComponentModel$IComponent$Site !== null && $.$$.System.String.op_Inequality(comp.System$ComponentModel$IComponent$Site.System$ComponentModel$ISite$Name, null) && $.$$.System.String.Equals$2(comp.System$ComponentModel$IComponent$Site.System$ComponentModel$ISite$Name, name, 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                return comp;
                            }
                        }
                    }
                }
                return null;
            }
            /*IComponent?*/ get_Item(/*int*/ index)
            {
                return $.$cast(this.InnerList.get_Item(index), $.$scp.System.ComponentModel.IComponent);
        ;
            }
            /*void */ CopyTo(/*IComponent[]*/ array, /*int*/ index)
            {
                return this.InnerList.CopyTo(array, index);
            }
            static $h = 262183;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":1048615,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":12885164071,"f":50331777},"n":"Item","o":"@$3","d":262183,"h":8590196775,"f":2097281},{"p":1048615,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":21475098663,"f":50331777},"n":"Item","o":"@$2","d":262183,"h":17180131367,"f":2097281}],"m":[{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$scp.System.ComponentModel.IComponent).$h},{"n":"index","p":655361}],"n":"CopyTo","d":262183,"h":25770065959,"f":16777217}],"c":[{"p":[{"n":"components","p":$.$typeArray($.$scp.System.ComponentModel.IComponent).$h}],"n":".ctor","o":"$ctor$2","d":262183,"h":4295229479,"f":16777217}],"i":[31457281,31719425],"h":262183}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.ComponentModel.ComponentCollection`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.Component", ($self) => class Component extends $.$$.System.MarshalByRefObject
        {
            /*object*/ static s_eventDisposed = null;
            /*ISite?*/ _site = null;
            /*EventHandlerList?*/ _events = null;
            $dtor()
            {
                return this.Dispose$1(false);
            }
            /*bool */ get CanRaiseEvents()
            {
                return true;
            }
            /*bool */ get CanRaiseEventsInternal()
            {
                return this.CanRaiseEvents;
            }
            /*EventHandler?*/ add_Disposed(value)
            {
                return this.Events.AddHandler($.$scp.System.ComponentModel.Component.s_eventDisposed, value);
            }
            /*EventHandler?*/ remove_Disposed(value)
            {
                this.Events.RemoveHandler($.$scp.System.ComponentModel.Component.s_eventDisposed, value);
            }
            /*EventHandlerList */ get Events()
            {
                return this._events ??= new $.$scp.System.ComponentModel.EventHandlerList().$ctor$2(this);
            }
            /*ISite? */ get Site()
            {
                return this._site;
            }
            /*ISite? */ set Site(value)
            {
                this._site = value;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            /*System.ComponentModel.ISite?*/ let __ca1__;
                            /*System.ComponentModel.IContainer?*/ let __ca2__;
                            if ((__ca1__ = this._site) !== null)
                            {
                                if ((__ca2__ = __ca1__.System$ComponentModel$ISite$Container) !== null)
                                {
                                    __ca2__.System$ComponentModel$IContainer$Remove(this);
                                }
                            }
                            if (this._events !== null)
                            {
                                ($.$cast(this._events.get_Item($.$scp.System.ComponentModel.Component.s_eventDisposed), $.$$.System.EventHandler))?.Invoke(this, $.$$.System.EventArgs.Empty);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            /*IContainer? */ get Container()
            {
                return (this._site?.System$ComponentModel$ISite$Container ?? null);
            }
            /*object? */ GetService(/*Type*/ service)
            {
                return (this._site?.System$IServiceProvider$GetService(service) ?? null);
            }
            /*bool */ get DesignMode()
            {
                return (this._site?.System$ComponentModel$ISite$DesignMode ?? null) ?? false;
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*ISite?*/ let s = this._site;
                if (s === null)
                {
                    return $.$$.System.Object.GetType.call(this).FullName;
                }
                return s.System$ComponentModel$ISite$Name + " [" + $.$$.System.Object.GetType.call(this).FullName + "]";
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scp.System.ComponentModel.Component.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.ComponentModel.IComponent.Site.get
            get System$ComponentModel$IComponent$Site()
            {
                return this.Site;
            }
            //Generated interface implemetation for System.ComponentModel.IComponent.Site.set
            set System$ComponentModel$IComponent$Site(value)
            {
                this.Site = value;
            }
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed.add
            System$ComponentModel$IComponent$add_Disposed()
            {
                return this.add_Disposed(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed.remove
            System$ComponentModel$IComponent$remove_Disposed()
            {
                return this.remove_Disposed(...arguments);
            }
            //Generated interface implemetation for System.ComponentModel.IComponent.Disposed
            System$ComponentModel$IComponent$Disposed()
            {
                this.Disposed;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_eventDisposed = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 196647;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65011713,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770000423,"f":50331780},"n":"CanRaiseEvents","d":196647,"h":21475033127,"f":2097284},{"p":262145,"g":{"r":0,"d":0,"h":34359935015,"f":50331656},"n":"CanRaiseEventsInternal","d":196647,"h":30064967719,"f":2097160},{"p":917543,"g":{"r":0,"d":0,"h":55834771495,"f":50331652},"n":"Events","d":196647,"h":51539804199,"f":2097156},{"p":1441831,"g":{"r":0,"d":0,"h":64424706087,"f":50331777},"s":{"r":0,"d":0,"h":68719673383,"f":83886209},"n":"Site","d":196647,"h":60129738791,"f":2097281,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]},{"t":655399,"c":21475491879,"a":[{"v":0,"t":589863}]}]},{"p":1114151,"g":{"r":0,"d":0,"h":85899542567,"f":50331649},"n":"Container","d":196647,"h":81604575271,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]},{"t":655399,"c":21475491879,"a":[{"v":0,"t":589863}]}]},{"p":262145,"g":{"r":0,"d":0,"h":98784444455,"f":50331652},"n":"DesignMode","d":196647,"h":94489477159,"f":2097156,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]},{"t":655399,"c":21475491879,"a":[{"v":0,"t":589863}]}]}],"m":[{"r":65537,"n":"Dispose","d":196647,"h":73014640679,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":196647,"h":77309607975,"f":16777348},{"r":131073,"p":[{"n":"service","p":142475265}],"n":"GetService","d":196647,"h":90194509863,"f":16777348},{"r":1310721,"n":"ToString","d":196647,"h":103079411751,"f":16809985}],"l":[{"t":131073,"n":"s_eventDisposed","d":196647,"h":4295163943,"f":4194338},{"t":1441831,"n":"_site","d":196647,"h":8590131239,"f":4194306},{"t":917543,"n":"_events","d":196647,"h":12885098535,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":196647,"h":107374379047,"f":16777217}],"e":[{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Disposed","d":196647,"h":42949869607,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Disposed","d":196647,"h":47244836903,"f":285212673},"n":"Disposed","d":196647,"h":38654902311,"f":8388609,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]},{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]}],"i":[1048615,57540609],"h":196647,"a":[{"t":524327,"c":25770328103,"a":[{"v":"Component","t":1310721}]}]}; }
            static get $b() { return $.$$.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.ComponentModel.Component`; }
        });
        
        $asm.$str("$scp.System.ComponentModel.DesignerSerializationVisibility", ($self) => class DesignerSerializationVisibility extends $.$$.System.Enum
        {
            static Hidden = 0;
            static Visible = 1;
            static Content = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Hidden": 0n,
                    "Visible": 1n,
                    "Content": 2n
                };
            }
            static $h = 589863;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":589863,"n":"Hidden","d":589863,"h":4295557159,"f":4194337},{"t":589863,"n":"Visible","d":589863,"h":8590524455,"f":4194337},{"t":589863,"n":"Content","d":589863,"h":12885491751,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":589863,"h":17180459047,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":589863}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.DesignerSerializationVisibility`; }
        });
        
        $asm.$str("$scp.System.ComponentModel.RefreshProperties", ($self) => class RefreshProperties extends $.$$.System.Enum
        {
            static None = 0;
            static All = 1;
            static Repaint = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "All": 1n,
                    "Repaint": 2n
                };
            }
            static $h = 1966119;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1966119,"n":"None","d":1966119,"h":4296933415,"f":4194337},{"t":1966119,"n":"All","d":1966119,"h":8591900711,"f":4194337},{"t":1966119,"n":"Repaint","d":1966119,"h":12886868007,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1966119,"h":17181835303,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1966119}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ComponentModel.RefreshProperties`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.InvalidAsynchronousStateException", ($self) => class InvalidAsynchronousStateException extends $.$$.System.ArgumentException
        {
            $ctor$15()
            {
                this.$ctor$18(null);
                {
                }
                return this;
            }
            $ctor$18(/*string?*/ message)
            {
                super.$ctor$14(message);
                {
                }
                return this;
            }
            $ctor$17(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 1310759;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":13500417,"h":1310759}; }
            static get $b() { return $.$$.System.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.InvalidAsynchronousStateException`; }
        });
        
        $asm.$cls("$scp.System.ComponentModel.InvalidEnumArgumentException", ($self) => class InvalidEnumArgumentException extends $.$$.System.ArgumentException
        {
            $ctor$15()
            {
                this.$ctor$19(null);
                {
                }
                return this;
            }
            $ctor$19(/*string?*/ message)
            {
                super.$ctor$14(message);
                {
                }
                return this;
            }
            $ctor$17(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                }
                return this;
            }
            $ctor$18(/*string?*/ argumentName, /*int*/ invalidValue, /*Type*/ enumClass)
            {
                super.$ctor$13($.$scp.System.SR.Format$4($.$scp.System.SR.InvalidEnumArgument, argumentName, $.$box(invalidValue, $.$$.System.Int32), (enumClass?.Name ?? null)), argumentName);
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(enumClass, "enumClass");
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ info, /*StreamingContext*/ context)
            {
                super.$ctor$10(info, context);
                {
                }
                return this;
            }
            static $h = 1376295;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":13500417,"h":1376295}; }
            static get $b() { return $.$$.System.ArgumentException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ComponentModel.InvalidEnumArgumentException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel"))