
//--TRIMMABLE-BOUNDARY-START(38)
(async function () {
(function ($global, $, $$, $spu, $sr) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.ComponentModel", 
    {
  "h": 38,
  "f": "System.ComponentModel",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(196646)
        $asm.$cls(`$scm.SC.IEditableObject`, ($self) => class IEditableObject
        {
            static $h = 196646;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163942),
    {
      "r": 65537,
      "n": "BeginEdit",
      "o": "SC$IEditableObject$BeginEdit",
      "d": 196646,
      "h": 4295163942,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295163942),
//--TRIMMABLE-BOUNDARY-START(12885098534),
    {
      "r": 65537,
      "n": "EndEdit",
      "o": "SC$IEditableObject$EndEdit",
      "d": 196646,
      "h": 12885098534,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885098534),
//--TRIMMABLE-BOUNDARY-START(8590131238),
    {
      "r": 65537,
      "n": "CancelEdit",
      "o": "SC$IEditableObject$CancelEdit",
      "d": 196646,
      "h": 8590131238,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131238)
  ],
  "h": 196646
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.IEditableObject`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}IEditableObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196646)
        
        

        //--TRIMMABLE-BOUNDARY-START(131110)
        $asm.$cls(`$scm.SC.IChangeTracking`, ($self) => class IChangeTracking
        {
            static $h = 131110;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000294),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885032998,
        "f": 50331905
      },
      "n": "IsChanged",
      "o": "SC$IChangeTracking$IsChanged",
      "d": 131110,
      "h": 17180000294,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180000294)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098406),
    {
      "r": 65537,
      "n": "AcceptChanges",
      "o": "SC$IChangeTracking$AcceptChanges",
      "d": 131110,
      "h": 4295098406,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098406)
  ],
  "h": 131110
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.IChangeTracking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}IChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131110)
        
        

        //--TRIMMABLE-BOUNDARY-START(327718)
        $asm.$cls(`$scm.S.IServiceProvider`, ($self) => class IServiceProvider
        {
            static $h = 327718;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295014),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 188547073
        }
      ],
      "n": "GetService",
      "o": "S$IServiceProvider$GetService",
      "d": 327718,
      "h": 4295295014,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295014)
  ],
  "h": 327718
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IServiceProvider`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327718)
        
        

        //--TRIMMABLE-BOUNDARY-START(262182)
        $asm.$cls(`$scm.SC.IRevertibleChangeTracking`, ($self) => class IRevertibleChangeTracking
        {
            static $h = 262182;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229478),
    {
      "r": 65537,
      "n": "RejectChanges",
      "o": "SC$IRevertibleChangeTracking$RejectChanges",
      "d": 262182,
      "h": 4295229478,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229478)
  ],
  "h": 262182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.SC.IChangeTracking ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.IRevertibleChangeTracking`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}IRevertibleChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262182)
        
        

        //--TRIMMABLE-BOUNDARY-START(65574)
        $asm.$cls(`$scm.SC.CancelEventArgs`, ($self) => class CancelEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(17179934758)
            /*bool*/ Cancel = false;
            //--TRIMMABLE-BOUNDARY-END(17179934758)
            
            //--TRIMMABLE-BOUNDARY-START(8590000166)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000166)
            
            //--TRIMMABLE-BOUNDARY-START(12884967462)
            $ctor$3(/*bool*/ cancel)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Cancel = cancel;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967462)
            
            //--TRIMMABLE-BOUNDARY-START(8590000166)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000166)
            
            static $h = 65574;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934758),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869350,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359803942,
        "f": 83886081
      },
      "n": "Cancel",
      "d": 65574,
      "h": 17179934758,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000166),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65574,
      "h": 8590000166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000166),
//--TRIMMABLE-BOUNDARY-START(12884967462),
    {
      "p": [
        {
          "n": "cancel",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65574,
      "h": 12884967462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967462)
  ],
  "h": 65574
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ComponentModel.CancelEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ComponentModel${separator}CancelEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65574)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime"));
})();
//--TRIMMABLE-BOUNDARY-END(38)
