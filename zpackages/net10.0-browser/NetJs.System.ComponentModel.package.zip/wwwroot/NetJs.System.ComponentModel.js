
//--TRIMMABLE-BOUNDARY-START(38)
(function ($global, $, $$, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel", 
    {
  "h": 38,
  "f": "System.ComponentModel",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131110)
        $asm.$cls("$scm.System.ComponentModel.IChangeTracking", ($self) => class IChangeTracking
        {
            static $h = 131110;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000294),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885032998,
        "f": 50331905
      },
      "n": "IsChanged",
      "o": "System$ComponentModel$IChangeTracking$IsChanged",
      "d": 131110,
      "h": 17180000294,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180000294)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098406),
    {
      "r": 65537,
      "n": "AcceptChanges",
      "o": "System$ComponentModel$IChangeTracking$AcceptChanges",
      "d": 131110,
      "h": 4295098406,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098406)
  ],
  "h": 131110
}; }
            static get $fullName() { return `System.ComponentModel.IChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131110)
        
        
        //--TRIMMABLE-BOUNDARY-START(196646)
        $asm.$cls("$scm.System.ComponentModel.IEditableObject", ($self) => class IEditableObject
        {
            static $h = 196646;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163942),
    {
      "r": 65537,
      "n": "BeginEdit",
      "o": "System$ComponentModel$IEditableObject$BeginEdit",
      "d": 196646,
      "h": 4295163942,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295163942),
//--TRIMMABLE-BOUNDARY-START(12885098534),
    {
      "r": 65537,
      "n": "EndEdit",
      "o": "System$ComponentModel$IEditableObject$EndEdit",
      "d": 196646,
      "h": 12885098534,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885098534),
//--TRIMMABLE-BOUNDARY-START(8590131238),
    {
      "r": 65537,
      "n": "CancelEdit",
      "o": "System$ComponentModel$IEditableObject$CancelEdit",
      "d": 196646,
      "h": 8590131238,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131238)
  ],
  "h": 196646
}; }
            static get $fullName() { return `System.ComponentModel.IEditableObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196646)
        
        
        //--TRIMMABLE-BOUNDARY-START(327718)
        $asm.$cls("$scm.System.IServiceProvider", ($self) => class IServiceProvider
        {
            static $h = 327718;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295014),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187760641
        }
      ],
      "n": "GetService",
      "o": "System$IServiceProvider$GetService",
      "d": 327718,
      "h": 4295295014,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295014)
  ],
  "h": 327718
}; }
            static get $fullName() { return `System.IServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327718)
        
        
        //--TRIMMABLE-BOUNDARY-START(262182)
        $asm.$cls("$scm.System.ComponentModel.IRevertibleChangeTracking", ($self) => class IRevertibleChangeTracking
        {
            static $h = 262182;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229478),
    {
      "r": 65537,
      "n": "RejectChanges",
      "o": "System$ComponentModel$IRevertibleChangeTracking$RejectChanges",
      "d": 262182,
      "h": 4295229478,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229478)
  ],
  "i": [131110
  ],
  "h": 262182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.ComponentModel.IChangeTracking ]; }
            static get $fullName() { return `System.ComponentModel.IRevertibleChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262182)
        
        
        //--TRIMMABLE-BOUNDARY-START(65574)
        $asm.$cls("$scm.System.ComponentModel.CancelEventArgs", ($self) => class CancelEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(17179934758)
            /*bool*/ Cancel = false;
            //--TRIMMABLE-BOUNDARY-END(17179934758)
            
            //--TRIMMABLE-BOUNDARY-START(8590000166)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000166)
            
            //--TRIMMABLE-BOUNDARY-START(12884967462)
            $ctor$3(/*bool*/ cancel)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Cancel = cancel;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967462)
            
            static $h = 65574;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79757313,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934758),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869350,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359803942,
        "f": 83886081
      },
      "n": "Cancel",
      "d": 65574,
      "h": 17179934758,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000166),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65574,
      "h": 8590000166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000166),
//--TRIMMABLE-BOUNDARY-START(12884967462),
    {
      "p": [
        {
          "n": "cancel",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65574,
      "h": 12884967462,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967462)
  ],
  "h": 65574
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.CancelEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65574)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))
//--TRIMMABLE-BOUNDARY-END(38)
