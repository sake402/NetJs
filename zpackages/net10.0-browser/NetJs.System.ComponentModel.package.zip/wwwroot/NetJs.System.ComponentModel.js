
//--TRIMMABLE-BOUNDARY-START(38)
(function ($global, $, $$, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel", 
    {
  "h": 38,
  "f": "System.ComponentModel",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.ComponentModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131110)
        $asm.$cls("$scm.System.ComponentModel.IChangeTracking", ($self) => class IChangeTracking
        {
            static $h = 131110;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000294),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885032998,
        "f": 50331905
      },
      "n": "IsChanged",
      "o": "System$ComponentModel$IChangeTracking$IsChanged",
      "d": 131110,
      "h": 17180000294,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180000294)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098406),
    {
      "r": 65537,
      "n": "AcceptChanges",
      "o": "System$ComponentModel$IChangeTracking$AcceptChanges",
      "d": 131110,
      "h": 4295098406,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295098406)
  ],
  "h": 131110
}; }
            static get $fullName() { return `System.ComponentModel.IChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131110)
        
        
        //--TRIMMABLE-BOUNDARY-START(196646)
        $asm.$cls("$scm.System.ComponentModel.IEditableObject", ($self) => class IEditableObject
        {
            static $h = 196646;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163942),
    {
      "r": 65537,
      "n": "BeginEdit",
      "o": "System$ComponentModel$IEditableObject$BeginEdit",
      "d": 196646,
      "h": 4295163942,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295163942),
//--TRIMMABLE-BOUNDARY-START(12885098534),
    {
      "r": 65537,
      "n": "EndEdit",
      "o": "System$ComponentModel$IEditableObject$EndEdit",
      "d": 196646,
      "h": 12885098534,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885098534),
//--TRIMMABLE-BOUNDARY-START(8590131238),
    {
      "r": 65537,
      "n": "CancelEdit",
      "o": "System$ComponentModel$IEditableObject$CancelEdit",
      "d": 196646,
      "h": 8590131238,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590131238)
  ],
  "h": 196646
}; }
            static get $fullName() { return `System.ComponentModel.IEditableObject`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196646)
        
        
        //--TRIMMABLE-BOUNDARY-START(327718)
        $asm.$cls("$scm.System.IServiceProvider", ($self) => class IServiceProvider
        {
            static $h = 327718;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295295014),
    {
      "r": 131073,
      "p": [
        {
          "n": "serviceType",
          "p": 187629569
        }
      ],
      "n": "GetService",
      "o": "System$IServiceProvider$GetService",
      "d": 327718,
      "h": 4295295014,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295295014)
  ],
  "h": 327718
}; }
            static get $fullName() { return `System.IServiceProvider`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327718)
        
        
        //--TRIMMABLE-BOUNDARY-START(262182)
        $asm.$cls("$scm.System.ComponentModel.IRevertibleChangeTracking", ($self) => class IRevertibleChangeTracking
        {
            static $h = 262182;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295229478),
    {
      "r": 65537,
      "n": "RejectChanges",
      "o": "System$ComponentModel$IRevertibleChangeTracking$RejectChanges",
      "d": 262182,
      "h": 4295229478,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295229478)
  ],
  "i": [131110
  ],
  "h": 262182
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.ComponentModel.IChangeTracking ]; }
            static get $fullName() { return `System.ComponentModel.IRevertibleChangeTracking`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262182)
        
        
        //--TRIMMABLE-BOUNDARY-START(65574)
        $asm.$cls("$scm.System.ComponentModel.CancelEventArgs", ($self) => class CancelEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(17179934758)
            /*bool*/ Cancel = false;
            //--TRIMMABLE-BOUNDARY-END(17179934758)
            
            //--TRIMMABLE-BOUNDARY-START(4295032870)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032870);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032870)
            
            //--TRIMMABLE-BOUNDARY-START(8590000166)
            $ctor$3(/*bool*/ cancel)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Cancel = cancel;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000166)
            
            static $h = 65574;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17179934758),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869350,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359803942,
        "f": 83886081
      },
      "n": "Cancel",
      "d": 65574,
      "h": 17179934758,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934758)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032870),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65574,
      "h": 4295032870,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032870),
//--TRIMMABLE-BOUNDARY-START(8590000166),
    {
      "p": [
        {
          "n": "cancel",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65574,
      "h": 8590000166,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000166)
  ],
  "h": 65574
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.CancelEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65574)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))
//--TRIMMABLE-BOUNDARY-END(38)
