
(function ($global, $, $spc, $spu, $sr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.ComponentModel", 
    {"h":37,"f":"System.ComponentModel","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.ComponentModel","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.ComponentModel","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scm.System.ComponentModel.IChangeTracking", ($self) => class IChangeTracking
        {
            static $h = 131109;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590065701,"f":257},"n":"IsChanged","o":"System$ComponentModel$IChangeTracking$IsChanged","d":131109,"h":4295098405,"f":257}],"m":[{"r":65537,"n":"AcceptChanges","o":"System$ComponentModel$IChangeTracking$AcceptChanges","d":131109,"h":12885032997,"f":257}],"h":131109}; }
            static get $fullName() { return `System.ComponentModel.IChangeTracking`; }
        });
        
        $asm.$cls("$scm.System.IServiceProvider", ($self) => class IServiceProvider
        {
            static $h = 327717;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":131073,"p":[{"n":"serviceType","p":142606337}],"n":"GetService","o":"System$IServiceProvider$GetService","d":327717,"h":4295295013,"f":257}],"h":327717}; }
            static get $fullName() { return `System.IServiceProvider`; }
        });
        
        $asm.$cls("$scm.System.ComponentModel.IEditableObject", ($self) => class IEditableObject
        {
            static $h = 196645;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"BeginEdit","o":"System$ComponentModel$IEditableObject$BeginEdit","d":196645,"h":4295163941,"f":257},{"r":65537,"n":"EndEdit","o":"System$ComponentModel$IEditableObject$EndEdit","d":196645,"h":8590131237,"f":257},{"r":65537,"n":"CancelEdit","o":"System$ComponentModel$IEditableObject$CancelEdit","d":196645,"h":12885098533,"f":257}],"h":196645}; }
            static get $fullName() { return `System.ComponentModel.IEditableObject`; }
        });
        
        $asm.$cls("$scm.System.ComponentModel.IRevertibleChangeTracking", ($self) => class IRevertibleChangeTracking
        {
            static $h = 262181;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"n":"RejectChanges","o":"System$ComponentModel$IRevertibleChangeTracking$RejectChanges","d":262181,"h":4295229477,"f":257}],"i":[131109],"h":262181}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scm.System.ComponentModel.IChangeTracking ]; }
            static get $fullName() { return `System.ComponentModel.IRevertibleChangeTracking`; }
        });
        
        $asm.$cls("$scm.System.ComponentModel.CancelEventArgs", ($self) => class CancelEventArgs extends $.$spc.System.EventArgs
        {
            /*bool*/ Cancel = false;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ cancel)
            {
                super.$ctor$1();
                this.Cancel = cancel;
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Cancel = false;
            }
            static $h = 65573;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12884967461,"f":1},"s":{"r":0,"d":0,"h":17179934757,"f":1},"n":"Cancel","d":65573,"h":8590000165,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":65573,"h":21474902053,"f":1},{"p":[{"n":"cancel","p":262145}],"n":".ctor","o":"$ctor$3","d":65573,"h":25769869349,"f":1}],"h":65573}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ComponentModel.CancelEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Private.Uri", "NetJs.System.Runtime"))