
//--TRIMMABLE-BOUNDARY-START(42)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris, $stee) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Console", 
    {
  "h": 42,
  "f": "System.Console",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Console",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Console",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 127664129,
      "c": 4422631425
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1179690)
        $asm.$cls("$scsl.System.IO.ConsoleStream", ($self) => class ConsoleStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4296146986)
            /*bool*/ _canRead = false;
            //--TRIMMABLE-BOUNDARY-END(4296146986)
            
            //--TRIMMABLE-BOUNDARY-START(8591114282)
            /*bool*/ _canWrite = false;
            //--TRIMMABLE-BOUNDARY-END(8591114282)
            
            //--TRIMMABLE-BOUNDARY-START(12886081578)
            $ctor$3(/*FileAccess*/ access)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081578);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(access === 1/*FileAccess.Read*/ || access === 2/*FileAccess.Write*/, "access == FileAccess.Read || access == FileAccess.Write");
                    this._canRead = ((access & 1/*FileAccess.Read*/) === 1/*FileAccess.Read*/);
                    this._canWrite = ((access & 2/*FileAccess.Write*/) === 2/*FileAccess.Write*/);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081578)
            
            //--TRIMMABLE-BOUNDARY-START(124555231274)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555231274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateWrite(buffer, offset, count);
                this.Write$1(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(buffer, offset, count));
            }
            //--TRIMMABLE-BOUNDARY-END(124555231274)
            
            //--TRIMMABLE-BOUNDARY-START(128850198570)
            /*void */ WriteByte(/*byte*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128850198570);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Write$1(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$7($.$ref(() => value, undefined, $.$$.System.Byte)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128850198570)
            
            //--TRIMMABLE-BOUNDARY-START(90195492906)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195492906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ValidateRead(buffer, offset, count);
                return this.Read$1(new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$3(buffer, offset, count));
            }
            //--TRIMMABLE-BOUNDARY-END(90195492906)
            
            //--TRIMMABLE-BOUNDARY-START(94490460202)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490460202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte*/ let b = 0;
                /*int*/ let result = this.Read$1(new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$7($.$ref(() => b, ($v) => b = $v, $.$$.System.Byte)));
                return result !== 0 ? b : -1;
            }
            //--TRIMMABLE-BOUNDARY-END(94490460202)
            
            //--TRIMMABLE-BOUNDARY-START(30065950762)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._canRead = false;
                this._canWrite = false;
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950762)
            
            //--TRIMMABLE-BOUNDARY-START(17181048874)
            /*bool */ get CanRead()
            {
                return this._canRead;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048874)
            
            //--TRIMMABLE-BOUNDARY-START(25770983466)
            /*bool */ get CanWrite()
            {
                return this._canWrite;
            }
            //--TRIMMABLE-BOUNDARY-END(25770983466)
            
            //--TRIMMABLE-BOUNDARY-START(21476016170)
            /*bool */ get CanSeek()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(21476016170)
            
            //--TRIMMABLE-BOUNDARY-START(81605558314)
            /*long */ get Length()
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            //--TRIMMABLE-BOUNDARY-END(81605558314)
            
            //--TRIMMABLE-BOUNDARY-START(85900525610)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310591018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375362090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            //--TRIMMABLE-BOUNDARY-END(85900525610)
            
            //--TRIMMABLE-BOUNDARY-START(34360918058)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360918058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360918058)
            
            //--TRIMMABLE-BOUNDARY-START(111670329386)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111670329386);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$scsl.System.IO.Error.GetSeekNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670329386)
            
            //--TRIMMABLE-BOUNDARY-START(98785427498)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785427498);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$scsl.System.IO.Error.GetSeekNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785427498)
            
            //--TRIMMABLE-BOUNDARY-START(115965296682)
            /*void */ ValidateRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965296682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (!this._canRead)
                {
                    throw $.$scsl.System.IO.Error.GetReadNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965296682)
            
            //--TRIMMABLE-BOUNDARY-START(120260263978)
            /*void */ ValidateWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260263978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (!this._canWrite)
                {
                    throw $.$scsl.System.IO.Error.GetWriteNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260263978)
            
            static $h = 1179690;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94961665,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181048874),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950852650,
        "f": 50429953
      },
      "n": "CanRead",
      "d": 1179690,
      "h": 17181048874,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(17181048874),
//--TRIMMABLE-BOUNDARY-START(25770983466),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721834,
        "f": 50429953
      },
      "n": "CanWrite",
      "d": 1179690,
      "h": 25770983466,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(25770983466),
//--TRIMMABLE-BOUNDARY-START(21476016170),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540787242,
        "f": 50429953
      },
      "n": "CanSeek",
      "d": 1179690,
      "h": 21476016170,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(21476016170),
//--TRIMMABLE-BOUNDARY-START(81605558314),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656426,
        "f": 50429953
      },
      "n": "Length",
      "d": 1179690,
      "h": 81605558314,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(81605558314),
//--TRIMMABLE-BOUNDARY-START(85900525610),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310591018,
        "f": 50429953
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107375362090,
        "f": 83984385
      },
      "n": "Position",
      "d": 1179690,
      "h": 85900525610,
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(85900525610)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(124555231274),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1179690,
      "h": 124555231274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555231274),
//--TRIMMABLE-BOUNDARY-START(128850198570),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 1179690,
      "h": 128850198570,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850198570),
//--TRIMMABLE-BOUNDARY-START(90195492906),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1179690,
      "h": 90195492906,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195492906),
//--TRIMMABLE-BOUNDARY-START(94490460202),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 1179690,
      "h": 94490460202,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490460202),
//--TRIMMABLE-BOUNDARY-START(30065950762),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1179690,
      "h": 30065950762,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(30065950762),
//--TRIMMABLE-BOUNDARY-START(34360918058),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1179690,
      "h": 34360918058,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360918058),
//--TRIMMABLE-BOUNDARY-START(111670329386),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1179690,
      "h": 111670329386,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(111670329386),
//--TRIMMABLE-BOUNDARY-START(98785427498),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94502913
        }
      ],
      "n": "Seek",
      "d": 1179690,
      "h": 98785427498,
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(98785427498),
//--TRIMMABLE-BOUNDARY-START(115965296682),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateRead",
      "d": 1179690,
      "h": 115965296682,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(115965296682),
//--TRIMMABLE-BOUNDARY-START(120260263978),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ValidateWrite",
      "d": 1179690,
      "h": 120260263978,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(120260263978)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296146986),
    {
      "t": 262145,
      "n": "_canRead",
      "d": 1179690,
      "h": 4296146986,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146986),
//--TRIMMABLE-BOUNDARY-START(8591114282),
    {
      "t": 262145,
      "n": "_canWrite",
      "d": 1179690,
      "h": 8591114282,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114282)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081578),
    {
      "p": [
        {
          "n": "access",
          "p": 92536833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179690,
      "h": 12886081578,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886081578)
  ],
  "i": [90308609,89718785
  ],
  "h": 1179690
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.ConsoleStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179690)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114154)
        $asm.$cls("$scsl.System.IO.CachedConsoleStream", ($self) => class CachedConsoleStream extends $.$scsl.System.IO.ConsoleStream
        {
            //--TRIMMABLE-BOUNDARY-START(4296081450)
            /*StringBuilder*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4296081450)
            
            //--TRIMMABLE-BOUNDARY-START(12886016042)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(12886016042)
            
            //--TRIMMABLE-BOUNDARY-START(8591048746)
            /*Decoder*/ _decoder = null;
            //--TRIMMABLE-BOUNDARY-END(8591048746)
            
            //--TRIMMABLE-BOUNDARY-START(17180983338)
            $ctor$4(/*Encoding*/ encoding)
            {
                super.$ctor$3(2/*FileAccess.Write*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180983338);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._encoding = encoding;
                    this._decoder = this._encoding.GetDecoder();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983338)
            
            //--TRIMMABLE-BOUNDARY-START(25770917930)
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770917930);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$scsl.System.IO.Error.GetReadNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770917930)
            
            //--TRIMMABLE-BOUNDARY-START(30065885226)
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065885226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let maxCharCount = this._encoding.GetMaxCharCount(buffer.Length);
                /*char[]?*/ let pooledBuffer = null;
                /*Span<char>*/ let charSpan = (maxCharCount >>> 0) <= 512 ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 512, null) : ($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(pooledBuffer = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(maxCharCount)));
                try
                {
                    /*int*/ let count = this._decoder.GetChars$3(buffer, charSpan, false);
                    if (count > 0)
                    {
                        $.$scsl.System.IO.CachedConsoleStream.WriteOrCache(this, this._buffer, charSpan.Slice(0, count));
                    }
                }
                finally
                {
                    {
                        if (pooledBuffer !== null)
                        {
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(pooledBuffer, false);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065885226)
            
            //--TRIMMABLE-BOUNDARY-START(34360852522)
            static /*void */ WriteOrCache(/*CachedConsoleStream*/ stream, /*StringBuilder*/ cache, /*Span<char>*/ charBuffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let lastNewLine = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, $.$$.System.Span$$($.$$.System.Char).op_Implicit(charBuffer), /*\n*/ 10);
                if (lastNewLine !== -1)
                {
                    /*Span<char>*/ let lineSpan = charBuffer.Slice(0, lastNewLine);
                    if (cache.Length > 0)
                    {
                        stream.Print($.$$.System.String.op_Implicit($.$$.System.Text.StringBuilder.ToString.call(cache.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(lineSpan)))));
                        cache.Clear();
                    }
                    else 
                    {
                        stream.Print($.$$.System.Span$$($.$$.System.Char).op_Implicit(lineSpan));
                    }
                    if (((lastNewLine + 1) | 0) < charBuffer.Length)
                    {
                        cache.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(charBuffer.Slice$1(((lastNewLine + 1) | 0))));
                    }
                    return;
                }
                cache.Append$15($.$$.System.Span$$($.$$.System.Char).op_Implicit(charBuffer));
            }
            //--TRIMMABLE-BOUNDARY-END(34360852522)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296081450)
                this._buffer = new $.$$.System.Text.StringBuilder().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4296081450)
                
            }
            static $h = 1114154;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1179690,
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770917930),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 1114154,
      "h": 25770917930,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770917930),
//--TRIMMABLE-BOUNDARY-START(30065885226),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1114154,
      "h": 30065885226,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065885226),
//--TRIMMABLE-BOUNDARY-START(21475950634),
    {
      "r": 65537,
      "p": [
        {
          "n": "line",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Print",
      "d": 1114154,
      "h": 21475950634,
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(21475950634),
//--TRIMMABLE-BOUNDARY-START(34360852522),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 1114154
        },
        {
          "n": "cache",
          "p": 167051265
        },
        {
          "n": "charBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteOrCache",
      "d": 1114154,
      "h": 34360852522,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360852522)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081450),
    {
      "t": 167051265,
      "n": "_buffer",
      "d": 1114154,
      "h": 4296081450,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081450),
//--TRIMMABLE-BOUNDARY-START(12886016042),
    {
      "t": 165937153,
      "n": "_encoding",
      "d": 1114154,
      "h": 12886016042,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886016042),
//--TRIMMABLE-BOUNDARY-START(8591048746),
    {
      "t": 164626433,
      "n": "_decoder",
      "d": 1114154,
      "h": 8591048746,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048746)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983338),
    {
      "p": [
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1114154,
      "h": 17180983338,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983338)
  ],
  "i": [90308609,89718785
  ],
  "h": 1114154
}; }
            static get $b() { return $.$scsl.System.IO.ConsoleStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.CachedConsoleStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114154)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376298)
        $asm.$cls("$scsl.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(708670980138)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(708670980138)
            
            //--TRIMMABLE-BOUNDARY-START(700081045546)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(700081045546)
            
            //--TRIMMABLE-BOUNDARY-START(704376012842)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566937059370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$scsl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Console", $.$scsl.System.SR.$type.Assembly);
                    $.$scsl.System.SR.s_resourceManager = temp;
                }
                return $.$scsl.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(704376012842)
            
            //--TRIMMABLE-BOUNDARY-START(94490656810)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778629162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721555882026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490656810)
            
            //--TRIMMABLE-BOUNDARY-START(47246016554)
            static /*string */ get ArgumentOutOfRange_ConsoleWindowBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289348650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value must be less than the console's current maximum window size of {0} in that dimension. Note that this value depends on screen resolution and the console font.";
            }
            //--TRIMMABLE-BOUNDARY-END(47246016554)
            
            //--TRIMMABLE-BOUNDARY-START(146030264362)
            static /*string */ FormatArgumentOutOfRange_ConsoleWindowBufferSize(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030264362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The value must be less than the console's current maximum window size of {0} in that dimension. Note that this value depends on screen resolution and the console font.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(146030264362)
            
            //--TRIMMABLE-BOUNDARY-START(55835951146)
            static /*string */ get ArgumentOutOfRange_ConsoleWindowSize_Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469217834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The new console window size would force the console buffer size to be too large.";
            }
            //--TRIMMABLE-BOUNDARY-END(55835951146)
            
            //--TRIMMABLE-BOUNDARY-START(25771180074)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339675690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771180074)
            
            //--TRIMMABLE-BOUNDARY-START(64425885738)
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300649087018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Specified file length was too large for the file system.";
            }
            //--TRIMMABLE-BOUNDARY-END(64425885738)
            
            //--TRIMMABLE-BOUNDARY-START(678606209066)
            static /*string */ get NotSupported_UnseekableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523987386410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support seeking.";
            }
            //--TRIMMABLE-BOUNDARY-END(678606209066)
            
            //--TRIMMABLE-BOUNDARY-START(687196143658)
            static /*string */ get ObjectDisposed_FileClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541167255594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot access a closed file.";
            }
            //--TRIMMABLE-BOUNDARY-END(687196143658)
            
            //--TRIMMABLE-BOUNDARY-START(682901176362)
            static /*string */ get NotSupported_UnwritableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532577321002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support writing.";
            }
            //--TRIMMABLE-BOUNDARY-END(682901176362)
            
            //--TRIMMABLE-BOUNDARY-START(674311241770)
            static /*string */ get NotSupported_UnreadableStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397451818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Stream does not support reading.";
            }
            //--TRIMMABLE-BOUNDARY-END(674311241770)
            
            //--TRIMMABLE-BOUNDARY-START(618476666922)
            static /*string */ get IO_AlreadyExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728302122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(618476666922)
            
            //--TRIMMABLE-BOUNDARY-START(150325231658)
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325231658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(150325231658)
            
            //--TRIMMABLE-BOUNDARY-START(622771634218)
            static /*string */ get IO_FileExists_Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318236714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The file '{0}' already exists.";
            }
            //--TRIMMABLE-BOUNDARY-END(622771634218)
            
            //--TRIMMABLE-BOUNDARY-START(154620198954)
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620198954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The file '{0}' already exists.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(154620198954)
            
            //--TRIMMABLE-BOUNDARY-START(627066601514)
            static /*string */ get IO_FileNotFound()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429498105898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Unable to find the specified file.";
            }
            //--TRIMMABLE-BOUNDARY-END(627066601514)
            
            //--TRIMMABLE-BOUNDARY-START(631361568810)
            static /*string */ get IO_FileNotFound_FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908171306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find file '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(631361568810)
            
            //--TRIMMABLE-BOUNDARY-START(158915166250)
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915166250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find file '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(158915166250)
            
            //--TRIMMABLE-BOUNDARY-START(639951503402)
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677975082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path.";
            }
            //--TRIMMABLE-BOUNDARY-END(639951503402)
            
            //--TRIMMABLE-BOUNDARY-START(644246470698)
            static /*string */ get IO_PathNotFound_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267909674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Could not find a part of the path '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(644246470698)
            
            //--TRIMMABLE-BOUNDARY-START(163210133546)
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210133546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Could not find a part of the path '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(163210133546)
            
            //--TRIMMABLE-BOUNDARY-START(648541437994)
            static /*string */ get IO_PathTooLong()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472447778858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(648541437994)
            
            //--TRIMMABLE-BOUNDARY-START(725850849322)
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575526993962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(725850849322)
            
            //--TRIMMABLE-BOUNDARY-START(730145816618)
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584116928554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Access to the path '{0}' is denied.";
            }
            //--TRIMMABLE-BOUNDARY-END(730145816618)
            
            //--TRIMMABLE-BOUNDARY-START(180390002730)
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390002730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Access to the path '{0}' is denied.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(180390002730)
            
            //--TRIMMABLE-BOUNDARY-START(657131372586)
            static /*string */ get IO_SharingViolation_File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037713450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(657131372586)
            
            //--TRIMMABLE-BOUNDARY-START(171800068138)
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800068138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(171800068138)
            
            //--TRIMMABLE-BOUNDARY-START(661426339882)
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489627648042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The process cannot access the file because it is being used by another process.";
            }
            //--TRIMMABLE-BOUNDARY-END(661426339882)
            
            //--TRIMMABLE-BOUNDARY-START(8591310890)
            static /*string */ get Arg_InvalidConsoleColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979937322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The ConsoleColor enum value was not defined on that enum. Please use a defined color from the enum.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591310890)
            
            //--TRIMMABLE-BOUNDARY-START(635656536106)
            static /*string */ get IO_NoConsole()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438088040490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There is no console.";
            }
            //--TRIMMABLE-BOUNDARY-END(635656536106)
            
            //--TRIMMABLE-BOUNDARY-START(665721307178)
            static /*string */ get IO_TermInfoInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217582634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The terminfo database is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(665721307178)
            
            //--TRIMMABLE-BOUNDARY-START(609886732330)
            static /*string */ get InvalidOperation_PrintF()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548432938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The printf operation failed.";
            }
            //--TRIMMABLE-BOUNDARY-END(609886732330)
            
            //--TRIMMABLE-BOUNDARY-START(605591765034)
            static /*string */ get InvalidOperation_ConsoleReadKeyOnFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958498346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot read keys when either application does not have a console or when console input has been redirected. Try Console.Read.";
            }
            //--TRIMMABLE-BOUNDARY-END(605591765034)
            
            //--TRIMMABLE-BOUNDARY-START(614181699626)
            static /*string */ get InvalidOperation_SetWindowSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138367530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot set window size when console output has been redirected.";
            }
            //--TRIMMABLE-BOUNDARY-END(614181699626)
            
            //--TRIMMABLE-BOUNDARY-START(691491110954)
            static /*string */ get PersistedFiles_NoHomeDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549757190186);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The home directory of the current user could not be determined.";
            }
            //--TRIMMABLE-BOUNDARY-END(691491110954)
            
            //--TRIMMABLE-BOUNDARY-START(42951049258)
            static /*string */ get ArgumentOutOfRange_ConsoleKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699414058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Console key values must be between 0 and 255 inclusive.";
            }
            //--TRIMMABLE-BOUNDARY-END(42951049258)
            
            //--TRIMMABLE-BOUNDARY-START(34361114666)
            static /*string */ get ArgumentOutOfRange_ConsoleBufferBoundaries()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519544874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The value must be greater than or equal to zero and less than the console's buffer size in that dimension.";
            }
            //--TRIMMABLE-BOUNDARY-END(34361114666)
            
            //--TRIMMABLE-BOUNDARY-START(51540983850)
            static /*string */ get ArgumentOutOfRange_ConsoleWindowPos()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879283242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The window position must be set such that the current window size fits within the console's buffer, and the numbers must not be negative.";
            }
            //--TRIMMABLE-BOUNDARY-END(51540983850)
            
            //--TRIMMABLE-BOUNDARY-START(601296797738)
            static /*string */ get InvalidOperation_ConsoleKeyAvailableOnFile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368563754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot see if a key has been pressed when either application does not have a console or when console input has been redirected from a file. Try Console.In.Peek.";
            }
            //--TRIMMABLE-BOUNDARY-END(601296797738)
            
            //--TRIMMABLE-BOUNDARY-START(38656081962)
            static /*string */ get ArgumentOutOfRange_ConsoleBufferLessThanWindowSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109479466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The console buffer size must not be less than the current size and position of the console window, nor greater than or equal to short.MaxValue.";
            }
            //--TRIMMABLE-BOUNDARY-END(38656081962)
            
            //--TRIMMABLE-BOUNDARY-START(60130918442)
            static /*string */ get ArgumentOutOfRange_CursorSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059152426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The cursor size is invalid. It must be a percentage between 1 and 100.";
            }
            //--TRIMMABLE-BOUNDARY-END(60130918442)
            
            //--TRIMMABLE-BOUNDARY-START(30066147370)
            static /*string */ get ArgumentOutOfRange_BeepFrequency()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929610282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The frequency must be between {0} and {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066147370)
            
            //--TRIMMABLE-BOUNDARY-START(141735297066)
            static /*string */ FormatArgumentOutOfRange_BeepFrequency(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735297066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The frequency must be between {0} and {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(141735297066)
            
            //--TRIMMABLE-BOUNDARY-START(81605754922)
            static /*string */ get ArgumentOutOfRange_IndexCountBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008825386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index and count must refer to a location within the buffer.";
            }
            //--TRIMMABLE-BOUNDARY-END(81605754922)
            
            //--TRIMMABLE-BOUNDARY-START(77310787626)
            static /*string */ get ArgumentOutOfRange_IndexCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418890794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index and count must refer to a location within the string.";
            }
            //--TRIMMABLE-BOUNDARY-END(77310787626)
            
            //--TRIMMABLE-BOUNDARY-START(85900722218)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598759978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(85900722218)
            
            //--TRIMMABLE-BOUNDARY-START(90195689514)
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188694570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(90195689514)
            
            //--TRIMMABLE-BOUNDARY-START(12886278186)
            static /*string */ get Argument_EncodingConversionOverflowBytes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569871914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The output byte buffer is too small to contain the encoded data, encoding '{0}' fallback '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886278186)
            
            //--TRIMMABLE-BOUNDARY-START(133145362474)
            static /*string */ FormatArgument_EncodingConversionOverflowBytes(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145362474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The output byte buffer is too small to contain the encoded data, encoding '{0}' fallback '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(133145362474)
            
            //--TRIMMABLE-BOUNDARY-START(17181245482)
            static /*string */ get Argument_EncodingConversionOverflowChars()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159806506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The output char buffer is too small to contain the decoded characters, encoding '{0}' fallback '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181245482)
            
            //--TRIMMABLE-BOUNDARY-START(137440329770)
            static /*string */ FormatArgument_EncodingConversionOverflowChars(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440329770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The output char buffer is too small to contain the decoded characters, encoding '{0}' fallback '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(137440329770)
            
            //--TRIMMABLE-BOUNDARY-START(68720853034)
            static /*string */ get ArgumentOutOfRange_GetByteCountOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309239021610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Too many characters. The resulting number of bytes is larger than what can be returned as an int.";
            }
            //--TRIMMABLE-BOUNDARY-END(68720853034)
            
            //--TRIMMABLE-BOUNDARY-START(73015820330)
            static /*string */ get ArgumentOutOfRange_GetCharCountOverflow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828956202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Too many bytes. The resulting number of chars is larger than what can be returned as an int.";
            }
            //--TRIMMABLE-BOUNDARY-END(73015820330)
            
            //--TRIMMABLE-BOUNDARY-START(21476212778)
            static /*string */ get Argument_InvalidCharSequenceNoIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749741098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "String contains invalid Unicode code points.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476212778)
            
            //--TRIMMABLE-BOUNDARY-START(652836405290)
            static /*string */ get IO_PathTooLong_Path()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857844266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            //--TRIMMABLE-BOUNDARY-END(652836405290)
            
            //--TRIMMABLE-BOUNDARY-START(167505100842)
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505100842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(167505100842)
            
            //--TRIMMABLE-BOUNDARY-START(670016274474)
            static /*string */ get IO_TermInfoInvalidMagicNumber()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807517226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The terminfo database has an invalid magic number: '{0}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(670016274474)
            
            //--TRIMMABLE-BOUNDARY-START(176095035434)
            static /*string */ FormatIO_TermInfoInvalidMagicNumber(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095035434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The terminfo database has an invalid magic number: '{0}'.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(176095035434)
            
            //--TRIMMABLE-BOUNDARY-START(695786078250)
            static /*string */ get PlatformNotSupported_SystemConsole()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558347124778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "System.Console is not supported on this platform.";
            }
            //--TRIMMABLE-BOUNDARY-END(695786078250)
            
            //--TRIMMABLE-BOUNDARY-START(712965947434)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(712965947434)
            
            //--TRIMMABLE-BOUNDARY-START(597001830442)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(597001830442);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(597001830442)
            
            //--TRIMMABLE-BOUNDARY-START(734440783914)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(734440783914);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scsl.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(734440783914)
            
            //--TRIMMABLE-BOUNDARY-START(592706863146)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706863146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scsl.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(592706863146)
            
            //--TRIMMABLE-BOUNDARY-START(588411895850)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588411895850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$scsl.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(588411895850)
            
            //--TRIMMABLE-BOUNDARY-START(124555427882)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555427882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(124555427882)
            
            //--TRIMMABLE-BOUNDARY-START(120260460586)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260460586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(120260460586)
            
            //--TRIMMABLE-BOUNDARY-START(115965493290)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965493290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(115965493290)
            
            //--TRIMMABLE-BOUNDARY-START(128850395178)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850395178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scsl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(128850395178)
            
            //--TRIMMABLE-BOUNDARY-START(107375558698)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375558698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(107375558698)
            
            //--TRIMMABLE-BOUNDARY-START(103080591402)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080591402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(103080591402)
            
            //--TRIMMABLE-BOUNDARY-START(98785624106)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785624106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(98785624106)
            
            //--TRIMMABLE-BOUNDARY-START(111670525994)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670525994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$scsl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(111670525994)
            
            //--TRIMMABLE-BOUNDARY-START(4296343594)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(712965947434)
                    this.s_usingResourceKeys = $.$scsl.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(712965947434)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296343594)
            
            static $h = 1376298;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1376298
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376298)
        
        
        //--TRIMMABLE-BOUNDARY-START(65578)
        $asm.$cls("$scsl.Interop", ($self) => class Interop
        {
            //--TRIMMABLE-BOUNDARY-START(327722)
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$scsl.Interop.Sys", ($self) => class Sys
                {
                    //--TRIMMABLE-BOUNDARY-START(42950000682)
                    static /*int */ Write$1(/*SafeHandle*/ fd, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42950000682);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (fd.DangerousGetHandle() === 1)
                        {
                            /*var*/ let reff = buffer;
                            /*var*/ let array = reff.ToArray(bufferSize);
                            const uint8Array = new Uint8Array(array);
                            const decodedString = new TextDecoder().decode(uint8Array);
                            console.log(decodedString);
                            return bufferSize;
                        }
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(42950000682)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655033386)
                    static /*int */ Write(/*IntPtr*/ fd, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655033386);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return -1;
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655033386)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885229610)
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885229610);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$cast(platformErrno, $.$scsl.Interop.Error);
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885229610)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590262314)
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590262314);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return error;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590262314)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360066090)
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34360066090);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return null;
                    }
                    //--TRIMMABLE-BOUNDARY-END(34360066090)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475164202)
                    static /*Error */ GetLastError()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475164202);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$scsl.Interop.Sys.ConvertErrorPlatformToPal($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475164202)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770131498)
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770131498);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return new $.$scsl.Interop.ErrorInfo().$ctor$3($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770131498)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065098794)
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(30065098794);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$scsl.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUTF8$1($.$cast(message, $.$$.System.IntPtr));
                    }
                    //--TRIMMABLE-BOUNDARY-END(30065098794)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180196906)
                    static /*SafeFileHandle */ Dup(/*SafeFileHandle*/ oldfd)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180196906);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return oldfd;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180196906)
                    
                    //--TRIMMABLE-BOUNDARY-START(393258)
                    static $_FileDescriptors;
                    static get FileDescriptors()
                    {
                        let $cls = $.$scsl.Interop.Sys;
                        return $cls.$_FileDescriptors ??= $asm.$ncls("$scsl.Interop.Sys.FileDescriptors", ($self) => class FileDescriptors
                        {
                            //--TRIMMABLE-BOUNDARY-START(17180262442)
                            /*SafeFileHandle*/ static STDIN_FILENO = null;
                            //--TRIMMABLE-BOUNDARY-END(17180262442)
                            
                            //--TRIMMABLE-BOUNDARY-START(21475229738)
                            /*SafeFileHandle*/ static STDOUT_FILENO = null;
                            //--TRIMMABLE-BOUNDARY-END(21475229738)
                            
                            //--TRIMMABLE-BOUNDARY-START(12885295146)
                            /*SafeFileHandle*/ static STDERR_FILENO = null;
                            //--TRIMMABLE-BOUNDARY-END(12885295146)
                            
                            //--TRIMMABLE-BOUNDARY-START(8590327850)
                            static /*SafeFileHandle */ CreateFileHandle(/*int*/ fileNumber)
                            {
                                //--TRIMMABLE-BOUNDARY-START(TRACE)
                                $.$trace(8590327850);
                                //--TRIMMABLE-BOUNDARY-END(TRACE)
                                return new $.$$.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$6(fileNumber, false);
                            }
                            //--TRIMMABLE-BOUNDARY-END(8590327850)
                            
                            //--TRIMMABLE-BOUNDARY-START(4295360554)
                            //Static Initializer
                            static $sinit()
                            {
                                {
                                    //--TRIMMABLE-BOUNDARY-START(17180262442)
                                    this.STDIN_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(0);
                                    //--TRIMMABLE-BOUNDARY-END(17180262442)
                                    
                                }
                                {
                                    //--TRIMMABLE-BOUNDARY-START(21475229738)
                                    this.STDOUT_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(1);
                                    //--TRIMMABLE-BOUNDARY-END(21475229738)
                                    
                                }
                                {
                                    //--TRIMMABLE-BOUNDARY-START(12885295146)
                                    this.STDERR_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(2);
                                    //--TRIMMABLE-BOUNDARY-END(12885295146)
                                    
                                }
                            }
                            //--TRIMMABLE-BOUNDARY-END(4295360554)
                            
                            static $h = 393258;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": 327722,
  "h": 393258
}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileDescriptors`; }
                        }, $cls, ($v) => $cls.$_FileDescriptors = $v);
                    }
                    //--TRIMMABLE-BOUNDARY-END(393258)
                    
                    static $h = 327722;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": 65578,
  "h": 327722
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(327722)
            
            //--TRIMMABLE-BOUNDARY-START(262186)
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$scsl.Interop.Libraries", ($self) => class Libraries
                {
                    //--TRIMMABLE-BOUNDARY-START(25770065962)
                    /*string*/ static libc = null;
                    //--TRIMMABLE-BOUNDARY-END(25770065962)
                    
                    //--TRIMMABLE-BOUNDARY-START(34360000554)
                    /*string*/ static SystemNative = null;
                    //--TRIMMABLE-BOUNDARY-END(34360000554)
                    
                    //--TRIMMABLE-BOUNDARY-START(30065033258)
                    /*string*/ static NetSecurityNative = null;
                    //--TRIMMABLE-BOUNDARY-END(30065033258)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590196778)
                    /*string*/ static CryptoNative = null;
                    //--TRIMMABLE-BOUNDARY-END(8590196778)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295229482)
                    /*string*/ static CompressionNative = null;
                    //--TRIMMABLE-BOUNDARY-END(4295229482)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885164074)
                    /*string*/ static GlobalizationNative = null;
                    //--TRIMMABLE-BOUNDARY-END(12885164074)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098666)
                    /*string*/ static IOPortsNative = null;
                    //--TRIMMABLE-BOUNDARY-END(21475098666)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180131370)
                    /*string*/ static HostPolicy = null;
                    //--TRIMMABLE-BOUNDARY-END(17180131370)
                    
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(25770065962)
                            this.libc = "libc";
                            //--TRIMMABLE-BOUNDARY-END(25770065962)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(34360000554)
                            this.SystemNative = "libSystem.Native";
                            //--TRIMMABLE-BOUNDARY-END(34360000554)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30065033258)
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                            //--TRIMMABLE-BOUNDARY-END(30065033258)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8590196778)
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                            //--TRIMMABLE-BOUNDARY-END(8590196778)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(4295229482)
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                            //--TRIMMABLE-BOUNDARY-END(4295229482)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12885164074)
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                            //--TRIMMABLE-BOUNDARY-END(12885164074)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21475098666)
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                            //--TRIMMABLE-BOUNDARY-END(21475098666)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17180131370)
                            this.HostPolicy = "libhostpolicy";
                            //--TRIMMABLE-BOUNDARY-END(17180131370)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 262186;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "d": 65578,
  "h": 262186
}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262186)
            
            //--TRIMMABLE-BOUNDARY-START(51539673130)
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$$.System.Diagnostics.Debug.Assert$2(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$scsl.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            //--TRIMMABLE-BOUNDARY-END(51539673130)
            
            //--TRIMMABLE-BOUNDARY-START(34359803946)
            static /*void */ CheckIo$3(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803946)
            
            //--TRIMMABLE-BOUNDARY-START(25769869354)
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (result < 0n)
                {
                    $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869354)
            
            //--TRIMMABLE-BOUNDARY-START(55834640426)
            static /*void */ ThrowIOExceptionForLastError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            //--TRIMMABLE-BOUNDARY-END(55834640426)
            
            //--TRIMMABLE-BOUNDARY-START(21474902058)
            static /*int */ CheckIo(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902058)
            
            //--TRIMMABLE-BOUNDARY-START(30064836650)
            static /*IntPtr */ CheckIo$2(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.Interop.CheckIo$1($.$cast(result, $.$$.System.Int64), path, isDirError);
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836650)
            
            //--TRIMMABLE-BOUNDARY-START(38654771242)
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$scsl.Interop.GetExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771242)
            
            //--TRIMMABLE-BOUNDARY-START(42949738538)
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.FileNotFoundException().$ctor$18($.$scsl.System.SR.Format$6($.$scsl.System.SR.IO_FileNotFound_FileName, path), path) : new $.$$.System.IO.FileNotFoundException().$ctor$19($.$scsl.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$scsl.System.SR.Format$6($.$scsl.System.SR.IO_PathNotFound_Path, path)) : new $.$$.System.IO.DirectoryNotFoundException().$ctor$17($.$scsl.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$scsl.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.UnauthorizedAccessException().$ctor$11($.$scsl.System.SR.Format$6($.$scsl.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$$.System.UnauthorizedAccessException().$ctor$11($.$scsl.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.PathTooLongException().$ctor$17($.$scsl.System.SR.Format$6($.$scsl.System.SR.IO_PathTooLong_Path, path)) : new $.$$.System.IO.PathTooLongException().$ctor$17($.$scsl.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$$.System.String.IsNullOrEmpty(path) ? new $.$$.System.IO.IOException().$ctor$12($.$scsl.System.SR.Format$6($.$scsl.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$$.System.IO.IOException().$ctor$12($.$scsl.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$$.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$scsl.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$$.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$$.System.IO.IOException().$ctor$12($.$scsl.System.SR.Format$6($.$scsl.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$scsl.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$$.System.IO.Path.GetDirectoryName$1($.$$.System.IO.Path.TrimEndingDirectorySeparator$1(fullPath));
                            return $.$$.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949738538)
            
            //--TRIMMABLE-BOUNDARY-START(47244705834)
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$$.System.IO.IOException().$ctor$12($.$$.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705834)
            
            //--TRIMMABLE-BOUNDARY-START(131114)
            static $_Error;
            static get Error()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Error ??= $asm.$nstr("$scsl.Interop.Error", ($self) => class Error extends $.$$.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(131114);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 131114;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "d": 65578,
  "h": 131114
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(131114)
            
            //--TRIMMABLE-BOUNDARY-START(196650)
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$scsl.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163946)
                    /*Error*/  get _error() { return this.$getField(0, $.$scsl.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$scsl.Interop.Error, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295163946)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131242)
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$$.System.Int32, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590131242)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065834)
                    $ctor$3(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180065834);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._error = $.$scsl.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065834)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033130)
                    $ctor$4(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475033130);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033130)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000426)
                    /*Error */ get Error()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(34359935018);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._error;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000426)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804202)
                    /*int */ get RawErrno()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(42949869610);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this._rawErrno === -1 ? (this._rawErrno = $.$scsl.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804202)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836906)
                    /*string */ GetErrorMessage()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(47244836906);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return $.$scsl.Interop.Sys.StrError(this.RawErrno);
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244836906)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834771498)
                    static/*conventional*/ /*string */ ToString()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834771498);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$scsl.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //--TRIMMABLE-BOUNDARY-END(55834771498)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098538)
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098538)
                    
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(4295163946)
                        this._error = 0;
                        //--TRIMMABLE-BOUNDARY-END(4295163946)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590131242)
                        this._rawErrno = 0;
                        //--TRIMMABLE-BOUNDARY-END(8590131242)
                        
                    }
                    static $h = 196650;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "d": 65578,
  "h": 196650
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196650)
            
            static $h = 65578;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 65578
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65578)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245226)
        $asm.$cls("$scsl.System.IO.Error", ($self) => class Error
        {
            //--TRIMMABLE-BOUNDARY-START(4296212522)
            static /*Exception */ GetFileNotOpen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.ObjectDisposedException().$ctor$16(null, $.$scsl.System.SR.ObjectDisposed_FileClosed);
            }
            //--TRIMMABLE-BOUNDARY-END(4296212522)
            
            //--TRIMMABLE-BOUNDARY-START(8591179818)
            static /*Exception */ GetReadNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591179818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.NotSupportedException().$ctor$12($.$scsl.System.SR.NotSupported_UnreadableStream);
            }
            //--TRIMMABLE-BOUNDARY-END(8591179818)
            
            //--TRIMMABLE-BOUNDARY-START(12886147114)
            static /*Exception */ GetSeekNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886147114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.NotSupportedException().$ctor$12($.$scsl.System.SR.NotSupported_UnseekableStream);
            }
            //--TRIMMABLE-BOUNDARY-END(12886147114)
            
            //--TRIMMABLE-BOUNDARY-START(17181114410)
            static /*Exception */ GetWriteNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.NotSupportedException().$ctor$12($.$scsl.System.SR.NotSupported_UnwritableStream);
            }
            //--TRIMMABLE-BOUNDARY-END(17181114410)
            
            static $h = 1245226;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296212522),
    {
      "r": 80019457,
      "n": "GetFileNotOpen",
      "d": 1245226,
      "h": 4296212522,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296212522),
//--TRIMMABLE-BOUNDARY-START(8591179818),
    {
      "r": 80019457,
      "n": "GetReadNotSupported",
      "d": 1245226,
      "h": 8591179818,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8591179818),
//--TRIMMABLE-BOUNDARY-START(12886147114),
    {
      "r": 80019457,
      "n": "GetSeekNotSupported",
      "d": 1245226,
      "h": 12886147114,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12886147114),
//--TRIMMABLE-BOUNDARY-START(17181114410),
    {
      "r": 80019457,
      "n": "GetWriteNotSupported",
      "d": 1245226,
      "h": 17181114410,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17181114410)
  ],
  "h": 1245226
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IO.Error`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245226)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507370)
        $asm.$cls("$scsl.System.Text.EncodingExtensions", ($self) => class EncodingExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4296474666)
            static /*Encoding */ RemovePreamble(/*this Encoding*/ encoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296474666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (encoding.Preamble.Length === 0)
                {
                    return encoding;
                }
                return new $.$scsl.System.Text.ConsoleEncoding().$ctor$4(encoding);
            }
            //--TRIMMABLE-BOUNDARY-END(4296474666)
            
            static $h = 1507370;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296474666),
    {
      "r": 165937153,
      "p": [
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": "RemovePreamble",
      "d": 1507370,
      "h": 4296474666,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296474666)
  ],
  "h": 1507370
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.EncodingExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507370)
        
        
        //--TRIMMABLE-BOUNDARY-START(458794)
        $asm.$cls("$scsl.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295426090)
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scsl.Interop.ErrorInfo().$ctor$4(error);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426090)
            
            static $h = 458794;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295426090),
    {
      "r": 196650,
      "p": [
        {
          "n": "error",
          "p": 131114
        }
      ],
      "n": "Info",
      "d": 458794,
      "h": 4295426090,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295426090)
  ],
  "h": 458794
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458794)
        
        
        //--TRIMMABLE-BOUNDARY-START(524330)
        $asm.$cls("$scsl.System.Console", ($self) => class Console
        {
            //--TRIMMABLE-BOUNDARY-START(420907319338)
            /*int*/ static ReadBufferSize = 4096;
            //--TRIMMABLE-BOUNDARY-END(420907319338)
            
            //--TRIMMABLE-BOUNDARY-START(777389604906)
            /*int*/ static WriteBufferSize = 256;
            //--TRIMMABLE-BOUNDARY-END(777389604906)
            
            //--TRIMMABLE-BOUNDARY-START(493921763370)
            /*object*/ static s_syncObject = null;
            //--TRIMMABLE-BOUNDARY-END(493921763370)
            
            //--TRIMMABLE-BOUNDARY-START(459562025002)
            /*TextReader?*/ static s_in = null;
            //--TRIMMABLE-BOUNDARY-END(459562025002)
            
            //--TRIMMABLE-BOUNDARY-START(476741894186)
            /*TextWriter?*/ static s_out = null;
            //--TRIMMABLE-BOUNDARY-END(476741894186)
            
            //--TRIMMABLE-BOUNDARY-START(455267057706)
            /*TextWriter?*/ static s_error = null;
            //--TRIMMABLE-BOUNDARY-END(455267057706)
            
            //--TRIMMABLE-BOUNDARY-START(463856992298)
            /*Encoding?*/ static s_inputEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(463856992298)
            
            //--TRIMMABLE-BOUNDARY-START(481036861482)
            /*Encoding?*/ static s_outputEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(481036861482)
            
            //--TRIMMABLE-BOUNDARY-START(472446926890)
            /*bool*/ static s_isOutTextWriterRedirected = false;
            //--TRIMMABLE-BOUNDARY-END(472446926890)
            
            //--TRIMMABLE-BOUNDARY-START(468151959594)
            /*bool*/ static s_isErrorTextWriterRedirected = false;
            //--TRIMMABLE-BOUNDARY-END(468151959594)
            
            //--TRIMMABLE-BOUNDARY-START(450972090410)
            /*ConsoleCancelEventHandler?*/ static s_cancelCallbacks = null;
            //--TRIMMABLE-BOUNDARY-END(450972090410)
            
            //--TRIMMABLE-BOUNDARY-START(485331828778)
            /*PosixSignalRegistration?*/ static s_sigIntRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(485331828778)
            
            //--TRIMMABLE-BOUNDARY-START(489626796074)
            /*PosixSignalRegistration?*/ static s_sigQuitRegistration = null;
            //--TRIMMABLE-BOUNDARY-END(489626796074)
            
            //--TRIMMABLE-BOUNDARY-START(335007973418)
            static /*TextReader */ get In()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684118058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$$.System.IO.TextReader).$v ?? EnsureInitialized();
                /*static TextReader*/  function EnsureInitialized()
                {
                    $.$scsl.System.ConsolePal.EnsureConsoleInitialized();
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_in === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$$.System.IO.TextReader).$v = $.$scsl.System.ConsolePal.GetOrCreateReader();
                            }
                            return $.$scsl.System.Console.s_in;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(335007973418)
            
            //--TRIMMABLE-BOUNDARY-START(339302940714)
            static /*Encoding */ get InputEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274052650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Encoding?*/ let encoding = $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$$.System.Text.Encoding).$v;
                if (encoding === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_inputEncoding === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$$.System.Text.Encoding).$v = $.$scsl.System.ConsolePal.InputEncoding;
                            }
                            encoding = $.$scsl.System.Console.s_inputEncoding;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
                return encoding;
            }
            static /*Encoding */ set InputEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571231174698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.ConsolePal.SetConsoleInputEncoding(value);
                        $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$$.System.Text.Encoding).$v = $.$cast(value.Clone(), $.$$.System.Text.Encoding);
                        $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$$.System.IO.TextReader).$v = null;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(339302940714)
            
            //--TRIMMABLE-BOUNDARY-START(412317384746)
            static /*Encoding */ get OutputEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583463978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Encoding?*/ let encoding = $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$$.System.Text.Encoding).$v;
                if (encoding === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_outputEncoding === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$$.System.Text.Encoding).$v = $.$scsl.System.ConsolePal.OutputEncoding;
                            }
                            encoding = $.$scsl.System.Console.s_outputEncoding;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
                return encoding;
            }
            static /*Encoding */ set OutputEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821109290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.ConsolePal.SetConsoleOutputEncoding(value);
                        if ($.$scsl.System.Console.s_out !== null && !$.$scsl.System.Console.s_isOutTextWriterRedirected)
                        {
                            $.$scsl.System.Console.s_out.Flush();
                            $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$$.System.IO.TextWriter).$v = null;
                        }
                        if ($.$scsl.System.Console.s_error !== null && !$.$scsl.System.Console.s_isErrorTextWriterRedirected)
                        {
                            $.$scsl.System.Console.s_error.Flush();
                            $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$$.System.IO.TextWriter).$v = null;
                        }
                        $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$$.System.Text.Encoding).$v = $.$cast(value.Clone(), $.$$.System.Text.Encoding);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(412317384746)
            
            //--TRIMMABLE-BOUNDARY-START(356482809898)
            static /*bool */ get KeyAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633791018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$scsl.System.Console.IsInputRedirected)
                {
                    throw new $.$$.System.InvalidOperationException().$ctor$12($.$scsl.System.SR.InvalidOperation_ConsoleKeyAvailableOnFile);
                }
                return $.$scsl.System.ConsolePal.KeyAvailable;
            }
            //--TRIMMABLE-BOUNDARY-END(356482809898)
            
            //--TRIMMABLE-BOUNDARY-START(425202286634)
            static /*ConsoleKeyInfo */ ReadKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202286634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.ReadKey(false);
            }
            //--TRIMMABLE-BOUNDARY-END(425202286634)
            
            //--TRIMMABLE-BOUNDARY-START(429497253930)
            static /*ConsoleKeyInfo */ ReadKey$1(/*bool*/ intercept)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497253930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.ReadKey(intercept);
            }
            //--TRIMMABLE-BOUNDARY-END(429497253930)
            
            //--TRIMMABLE-BOUNDARY-START(408022417450)
            static /*TextWriter */ get Out()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993529386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.Threading.Monitor.IsEntered($.$scsl.System.Console.s_syncObject), "!Monitor.IsEntered(s_syncObject)");
                return $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$$.System.IO.TextWriter).$v ?? EnsureInitialized();
                /*static TextWriter*/  function EnsureInitialized()
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_out === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$$.System.IO.TextWriter).$v = $.$scsl.System.Console.CreateOutputWriter($.$scsl.System.ConsolePal.OpenStandardOutput());
                            }
                            return $.$scsl.System.Console.s_out;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022417450)
            
            //--TRIMMABLE-BOUNDARY-START(85899870250)
            static /*TextWriter */ get Error()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504248874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$$.System.IO.TextWriter).$v ?? EnsureInitialized();
                /*static TextWriter*/  function EnsureInitialized()
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_error === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$$.System.IO.TextWriter).$v = $.$scsl.System.Console.CreateOutputWriter($.$scsl.System.ConsolePal.OpenStandardError());
                            }
                            return $.$scsl.System.Console.s_error;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899870250)
            
            //--TRIMMABLE-BOUNDARY-START(64425033770)
            static /*TextWriter */ CreateOutputWriter(/*Stream*/ outputStream)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return outputStream === $.$$.System.IO.Stream.Null ? $.$$.System.IO.TextWriter.Null : $.$$.System.IO.TextWriter.Synchronized((() =>
                {
                    //new $.$$.System.IO.StreamWriter()
                    const $t1 = $.$$.System.IO.StreamWriter;
                    const $i1 = new $t1();
                    $i1.$ctor$5(outputStream, $.$scsl.System.Text.EncodingExtensions.RemovePreamble($.$scsl.System.Console.OutputEncoding), 256/*WriteBufferSize*/, true);
                    $i1.AutoFlush = true;
                    return $i1;
                })());
            }
            //--TRIMMABLE-BOUNDARY-END(64425033770)
            
            //--TRIMMABLE-BOUNDARY-START(8590458922)
            /*StrongBox<bool>?*/ static _isStdInRedirected = null;
            //--TRIMMABLE-BOUNDARY-END(8590458922)
            
            //--TRIMMABLE-BOUNDARY-START(12885426218)
            /*StrongBox<bool>?*/ static _isStdOutRedirected = null;
            //--TRIMMABLE-BOUNDARY-END(12885426218)
            
            //--TRIMMABLE-BOUNDARY-START(4295491626)
            /*StrongBox<bool>?*/ static _isStdErrRedirected = null;
            //--TRIMMABLE-BOUNDARY-END(4295491626)
            
            //--TRIMMABLE-BOUNDARY-START(347892875306)
            static /*bool */ get IsInputRedirected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453921834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdInRedirected, ($v) => $.$scsl.System.Console._isStdInRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdInRedirected, ($v) => $.$scsl.System.Console._isStdInRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsInputRedirectedCore());
                    return $.$scsl.System.Console._isStdInRedirected;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(347892875306)
            
            //--TRIMMABLE-BOUNDARY-START(352187842602)
            static /*bool */ get IsOutputRedirected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043856426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdOutRedirected, ($v) => $.$scsl.System.Console._isStdOutRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdOutRedirected, ($v) => $.$scsl.System.Console._isStdOutRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsOutputRedirectedCore());
                    return $.$scsl.System.Console._isStdOutRedirected;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(352187842602)
            
            //--TRIMMABLE-BOUNDARY-START(343597908010)
            static /*bool */ get IsErrorRedirected()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863987242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdErrRedirected, ($v) => $.$scsl.System.Console._isStdErrRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdErrRedirected, ($v) => $.$scsl.System.Console._isStdErrRedirected = $v, $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean)).$v = new ($.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsErrorRedirectedCore());
                    return $.$scsl.System.Console._isStdErrRedirected;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(343597908010)
            
            //--TRIMMABLE-BOUNDARY-START(73014968362)
            static /*int */ get CursorSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734445098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.CursorSize;
            }
            static /*int */ set CursorSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871436330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.CursorSize = value;
            }
            //--TRIMMABLE-BOUNDARY-END(73014968362)
            
            //--TRIMMABLE-BOUNDARY-START(377957646378)
            static /*bool */ get NumberLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403594794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.NumberLock;
            }
            //--TRIMMABLE-BOUNDARY-END(377957646378)
            
            //--TRIMMABLE-BOUNDARY-START(55835099178)
            static /*bool */ get CapsLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554575914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.CapsLock;
            }
            //--TRIMMABLE-BOUNDARY-END(55835099178)
            
            //--TRIMMABLE-BOUNDARY-START(674310389802)
            /*ConsoleColor*/ static UnknownColor = -1;
            //--TRIMMABLE-BOUNDARY-END(674310389802)
            
            //--TRIMMABLE-BOUNDARY-START(30065295402)
            static /*ConsoleColor */ get BackgroundColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784772138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.BackgroundColor;
            }
            static /*ConsoleColor */ set BackgroundColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511697962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.BackgroundColor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295402)
            
            //--TRIMMABLE-BOUNDARY-START(90194837546)
            static /*ConsoleColor */ get ForegroundColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094183466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.ForegroundColor;
            }
            static /*ConsoleColor */ set ForegroundColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641240106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.ForegroundColor = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90194837546)
            
            //--TRIMMABLE-BOUNDARY-START(446677123114)
            static /*void */ ResetColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677123114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.ResetColor();
            }
            //--TRIMMABLE-BOUNDARY-END(446677123114)
            
            //--TRIMMABLE-BOUNDARY-START(47245164586)
            static /*int */ get BufferWidth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.BufferWidth;
            }
            static /*int */ set BufferWidth(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691567146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.BufferWidth = value;
            }
            //--TRIMMABLE-BOUNDARY-END(47245164586)
            
            //--TRIMMABLE-BOUNDARY-START(42950197290)
            static /*int */ get BufferHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374706730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.BufferHeight;
            }
            static /*int */ set BufferHeight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101632554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.BufferHeight = value;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197290)
            
            //--TRIMMABLE-BOUNDARY-START(635655684138)
            static /*void */ SetBufferSize(/*int*/ width, /*int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635655684138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.SetBufferSize(width, height);
            }
            //--TRIMMABLE-BOUNDARY-END(635655684138)
            
            //--TRIMMABLE-BOUNDARY-START(682900324394)
            static /*int */ get WindowLeft()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943202346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.WindowLeft;
            }
            static /*int */ set WindowLeft(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614180847658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.WindowLeft = value;
            }
            //--TRIMMABLE-BOUNDARY-END(682900324394)
            
            //--TRIMMABLE-BOUNDARY-START(687195291690)
            static /*int */ get WindowTop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533136938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.WindowTop;
            }
            static /*int */ set WindowTop(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622770782250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.WindowTop = value;
            }
            //--TRIMMABLE-BOUNDARY-END(687195291690)
            
            //--TRIMMABLE-BOUNDARY-START(691490258986)
            static /*int */ get WindowWidth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123071530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.WindowWidth;
            }
            static /*int */ set WindowWidth(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631360716842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.WindowWidth = value;
            }
            //--TRIMMABLE-BOUNDARY-END(691490258986)
            
            //--TRIMMABLE-BOUNDARY-START(678605357098)
            static /*int */ get WindowHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353267754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.WindowHeight;
            }
            static /*int */ set WindowHeight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605590913066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.WindowHeight = value;
            }
            //--TRIMMABLE-BOUNDARY-END(678605357098)
            
            //--TRIMMABLE-BOUNDARY-START(657130520618)
            static /*void */ SetWindowPosition(/*int*/ left, /*int*/ top)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130520618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.SetWindowPosition(left, top);
            }
            //--TRIMMABLE-BOUNDARY-END(657130520618)
            
            //--TRIMMABLE-BOUNDARY-START(661425487914)
            static /*void */ SetWindowSize(/*int*/ width, /*int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425487914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.SetWindowSize(width, height);
            }
            //--TRIMMABLE-BOUNDARY-END(661425487914)
            
            //--TRIMMABLE-BOUNDARY-START(365072744490)
            static /*int */ get LargestWindowWidth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813660202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.LargestWindowWidth;
            }
            //--TRIMMABLE-BOUNDARY-END(365072744490)
            
            //--TRIMMABLE-BOUNDARY-START(360777777194)
            static /*int */ get LargestWindowHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223725610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.LargestWindowHeight;
            }
            //--TRIMMABLE-BOUNDARY-END(360777777194)
            
            //--TRIMMABLE-BOUNDARY-START(81604902954)
            static /*bool */ get CursorVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914314282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.CursorVisible;
            }
            static /*bool */ set CursorVisible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051305514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.CursorVisible = value;
            }
            //--TRIMMABLE-BOUNDARY-END(81604902954)
            
            //--TRIMMABLE-BOUNDARY-START(68720001066)
            static /*int */ get CursorLeft()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144510506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.GetCursorPosition().Item1;
            }
            static /*int */ set CursorLeft(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281501738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.SetCursorPosition(value, $.$scsl.System.Console.CursorTop);
            }
            //--TRIMMABLE-BOUNDARY-END(68720001066)
            
            //--TRIMMABLE-BOUNDARY-START(77309935658)
            static /*int */ get CursorTop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324379690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.GetCursorPosition().Item2;
            }
            static /*int */ set CursorTop(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461370922);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.SetCursorPosition($.$scsl.System.Console.CursorLeft, value);
            }
            //--TRIMMABLE-BOUNDARY-END(77309935658)
            
            //--TRIMMABLE-BOUNDARY-START(326418038826)
            static /*(int Left, int Top) */ GetCursorPosition()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418038826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.GetCursorPosition();
            }
            //--TRIMMABLE-BOUNDARY-END(326418038826)
            
            //--TRIMMABLE-BOUNDARY-START(665720455210)
            static /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173398570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.Title;
            }
            static /*string */ set Title(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588411043882);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                $.$scsl.System.ConsolePal.Title = value;
            }
            //--TRIMMABLE-BOUNDARY-END(665720455210)
            
            //--TRIMMABLE-BOUNDARY-START(34360262698)
            static /*void */ Beep()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.Beep();
            }
            //--TRIMMABLE-BOUNDARY-END(34360262698)
            
            //--TRIMMABLE-BOUNDARY-START(38655229994)
            static /*void */ Beep$1(/*int*/ frequency, /*int*/ duration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655229994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.Beep$1(frequency, duration);
            }
            //--TRIMMABLE-BOUNDARY-END(38655229994)
            
            //--TRIMMABLE-BOUNDARY-START(373662679082)
            static /*void */ MoveBufferArea$1(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662679082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.MoveBufferArea(sourceLeft, sourceTop, sourceWidth, sourceHeight, targetLeft, targetTop, /* */ 32, 0/*ConsoleColor.Black*/, $.$scsl.System.Console.BackgroundColor);
            }
            //--TRIMMABLE-BOUNDARY-END(373662679082)
            
            //--TRIMMABLE-BOUNDARY-START(369367711786)
            static /*void */ MoveBufferArea(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop, /*char*/ sourceChar, /*ConsoleColor*/ sourceForeColor, /*ConsoleColor*/ sourceBackColor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367711786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.MoveBufferArea(sourceLeft, sourceTop, sourceWidth, sourceHeight, targetLeft, targetTop, sourceChar, sourceForeColor, sourceBackColor);
            }
            //--TRIMMABLE-BOUNDARY-END(369367711786)
            
            //--TRIMMABLE-BOUNDARY-START(60130066474)
            static /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(60130066474)
            
            //--TRIMMABLE-BOUNDARY-START(639950651434)
            static /*void */ SetCursorPosition(/*int*/ left, /*int*/ top)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639950651434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (left < 0 || left >= 32767/*short.MaxValue*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("left", $.$box(left, $.$$.System.Int32), $.$scsl.System.SR.ArgumentOutOfRange_ConsoleBufferBoundaries);
                }
                if (top < 0 || top >= 32767/*short.MaxValue*/)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("top", $.$box(top, $.$$.System.Int32), $.$scsl.System.SR.ArgumentOutOfRange_ConsoleBufferBoundaries);
                }
                $.$scsl.System.ConsolePal.SetCursorPosition(left, top);
            }
            //--TRIMMABLE-BOUNDARY-END(639950651434)
            
            //--TRIMMABLE-BOUNDARY-START(51540131882)
            /*ConsoleCancelEventHandler?*/static  add_CancelKeyPress(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328106);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.EnsureConsoleInitialized();
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_cancelCallbacks = $.$$.System.Delegate.Combine($.$scsl.System.Console.s_cancelCallbacks, value);
                        if ($.$scsl.System.Console.s_sigIntRegistration === null)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2($.$scsl.System.Console.s_sigQuitRegistration === null, "s_sigQuitRegistration is null");
                            /*Action<PosixSignalContext>*/ let handler = new ($.$$.System.Action$$($.$$.System.Runtime.InteropServices.PosixSignalContext))().$ctor($.$scsl.System.Console, $.$scsl.System.Console.HandlePosixSignal);
                            $.$scsl.System.Console.s_sigIntRegistration = $.$$.System.Runtime.InteropServices.PosixSignalRegistration.Create(-2/*PosixSignal.SIGINT*/, handler);
                            $.$scsl.System.Console.s_sigQuitRegistration = $.$$.System.Runtime.InteropServices.PosixSignalRegistration.Create(-3/*PosixSignal.SIGQUIT*/, handler);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            /*ConsoleCancelEventHandler?*/static  remove_CancelKeyPress(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382155818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_cancelCallbacks = $.$$.System.Delegate.Remove($.$scsl.System.Console.s_cancelCallbacks, value);
                        if ($.$scsl.System.Console.s_cancelCallbacks === null)
                        {
                            $.$scsl.System.Console.s_sigIntRegistration?.Dispose();
                            $.$scsl.System.Console.s_sigQuitRegistration?.Dispose();
                            $.$scsl.System.Console.s_sigIntRegistration = $.$scsl.System.Console.s_sigQuitRegistration = null;
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131882)
            
            //--TRIMMABLE-BOUNDARY-START(670015422506)
            static /*bool */ get TreatControlCAsInput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763333162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.TreatControlCAsInput;
            }
            static /*bool */ set TreatControlCAsInput(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597000978474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.ConsolePal.TreatControlCAsInput = value;
            }
            //--TRIMMABLE-BOUNDARY-END(670015422506)
            
            //--TRIMMABLE-BOUNDARY-START(390842548266)
            static /*Stream */ OpenStandardInput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842548266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.OpenStandardInput();
            }
            //--TRIMMABLE-BOUNDARY-END(390842548266)
            
            //--TRIMMABLE-BOUNDARY-START(395137515562)
            static /*Stream */ OpenStandardInput$1(/*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137515562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardInput();
            }
            //--TRIMMABLE-BOUNDARY-END(395137515562)
            
            //--TRIMMABLE-BOUNDARY-START(399432482858)
            static /*Stream */ OpenStandardOutput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432482858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.OpenStandardOutput();
            }
            //--TRIMMABLE-BOUNDARY-END(399432482858)
            
            //--TRIMMABLE-BOUNDARY-START(403727450154)
            static /*Stream */ OpenStandardOutput$1(/*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727450154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardOutput();
            }
            //--TRIMMABLE-BOUNDARY-END(403727450154)
            
            //--TRIMMABLE-BOUNDARY-START(382252613674)
            static /*Stream */ OpenStandardError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252613674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.ConsolePal.OpenStandardError();
            }
            //--TRIMMABLE-BOUNDARY-END(382252613674)
            
            //--TRIMMABLE-BOUNDARY-START(386547580970)
            static /*Stream */ OpenStandardError$1(/*int*/ bufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547580970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardError();
            }
            //--TRIMMABLE-BOUNDARY-END(386547580970)
            
            //--TRIMMABLE-BOUNDARY-START(648540586026)
            static /*void */ SetIn(/*TextReader*/ newIn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(648540586026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(newIn, "newIn");
                newIn = $.$scsl.System.IO.SyncTextReader.GetSynchronizedTextReader(newIn);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$$.System.IO.TextReader).$v = newIn;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(648540586026)
            
            //--TRIMMABLE-BOUNDARY-START(652835553322)
            static /*void */ SetOut(/*TextWriter*/ newOut)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652835553322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(newOut, "newOut");
                if (newOut !== $.$$.System.IO.TextWriter.Null)
                {
                    newOut = $.$$.System.IO.TextWriter.Synchronized(newOut);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_isOutTextWriterRedirected = true;
                        $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$$.System.IO.TextWriter).$v = newOut;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(652835553322)
            
            //--TRIMMABLE-BOUNDARY-START(644245618730)
            static /*void */ SetError(/*TextWriter*/ newError)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644245618730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(newError, "newError");
                if (newError !== $.$$.System.IO.TextWriter.Null)
                {
                    newError = $.$$.System.IO.TextWriter.Synchronized(newError);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_isErrorTextWriterRedirected = true;
                        $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$$.System.IO.TextWriter).$v = newError;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(644245618730)
            
            //--TRIMMABLE-BOUNDARY-START(416612352042)
            static /*int */ Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612352042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.Console.In.Read();
            }
            //--TRIMMABLE-BOUNDARY-END(416612352042)
            
            //--TRIMMABLE-BOUNDARY-START(433792221226)
            static /*string? */ ReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792221226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$scsl.System.Console.In.ReadLine();
            }
            //--TRIMMABLE-BOUNDARY-END(433792221226)
            
            //--TRIMMABLE-BOUNDARY-START(781684572202)
            static /*void */ WriteLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781684572202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine();
            }
            //--TRIMMABLE-BOUNDARY-END(781684572202)
            
            //--TRIMMABLE-BOUNDARY-START(785979539498)
            static /*void */ WriteLine$1(/*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979539498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(785979539498)
            
            //--TRIMMABLE-BOUNDARY-START(790274506794)
            static /*void */ WriteLine$2(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790274506794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$2(value);
            }
            //--TRIMMABLE-BOUNDARY-END(790274506794)
            
            //--TRIMMABLE-BOUNDARY-START(798864441386)
            static /*void */ WriteLine$4(/*char[]?*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798864441386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$4(buffer);
            }
            //--TRIMMABLE-BOUNDARY-END(798864441386)
            
            //--TRIMMABLE-BOUNDARY-START(794569474090)
            static /*void */ WriteLine$3(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569474090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$3(buffer, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(794569474090)
            
            //--TRIMMABLE-BOUNDARY-START(803159408682)
            static /*void */ WriteLine$5(/*decimal*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159408682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$5(value);
            }
            //--TRIMMABLE-BOUNDARY-END(803159408682)
            
            //--TRIMMABLE-BOUNDARY-START(807454375978)
            static /*void */ WriteLine$6(/*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454375978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$6(value);
            }
            //--TRIMMABLE-BOUNDARY-END(807454375978)
            
            //--TRIMMABLE-BOUNDARY-START(828929212458)
            static /*void */ WriteLine$11(/*float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(828929212458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$11(value);
            }
            //--TRIMMABLE-BOUNDARY-END(828929212458)
            
            //--TRIMMABLE-BOUNDARY-START(811749343274)
            static /*void */ WriteLine$7(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811749343274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$7(value);
            }
            //--TRIMMABLE-BOUNDARY-END(811749343274)
            
            //--TRIMMABLE-BOUNDARY-START(858993983530)
            static /*void */ WriteLine$18(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858993983530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$19(value);
            }
            //--TRIMMABLE-BOUNDARY-END(858993983530)
            
            //--TRIMMABLE-BOUNDARY-START(816044310570)
            static /*void */ WriteLine$8(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816044310570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$8(value);
            }
            //--TRIMMABLE-BOUNDARY-END(816044310570)
            
            //--TRIMMABLE-BOUNDARY-START(863288950826)
            static /*void */ WriteLine$19(/*ulong*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(863288950826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$20(value);
            }
            //--TRIMMABLE-BOUNDARY-END(863288950826)
            
            //--TRIMMABLE-BOUNDARY-START(820339277866)
            static /*void */ WriteLine$9(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(820339277866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$9(value);
            }
            //--TRIMMABLE-BOUNDARY-END(820339277866)
            
            //--TRIMMABLE-BOUNDARY-START(854699016234)
            static /*void */ WriteLine$17(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(854699016234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$17(value);
            }
            //--TRIMMABLE-BOUNDARY-END(854699016234)
            
            //--TRIMMABLE-BOUNDARY-START(824634245162)
            static /*void */ WriteLine$10(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824634245162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$10(value);
            }
            //--TRIMMABLE-BOUNDARY-END(824634245162)
            
            //--TRIMMABLE-BOUNDARY-START(841814114346)
            static /*void */ WriteLine$14(/*string*/ format, /*object?*/ arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841814114346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$14(format, arg0);
            }
            //--TRIMMABLE-BOUNDARY-END(841814114346)
            
            //--TRIMMABLE-BOUNDARY-START(837519147050)
            static /*void */ WriteLine$13(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(837519147050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$13(format, arg0, arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(837519147050)
            
            //--TRIMMABLE-BOUNDARY-START(833224179754)
            static /*void */ WriteLine$12(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1, /*object?*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833224179754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$12(format, arg0, arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(833224179754)
            
            //--TRIMMABLE-BOUNDARY-START(846109081642)
            static /*void */ WriteLine$15(/*string*/ format, /*params object?[]?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(846109081642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (arg === null)
                {
                    $.$scsl.System.Console.Out.WriteLine$13(format, null, null);
                }
                else 
                {
                    $.$scsl.System.Console.Out.WriteLine$15(format, arg);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(846109081642)
            
            //--TRIMMABLE-BOUNDARY-START(850404048938)
            static /*void */ WriteLine$16(/*string*/ format, /*params ReadOnlySpan<object?>*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850404048938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.WriteLine$16(format, arg);
            }
            //--TRIMMABLE-BOUNDARY-END(850404048938)
            
            //--TRIMMABLE-BOUNDARY-START(751619801130)
            static /*void */ Write$13(/*string*/ format, /*object?*/ arg0)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751619801130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$13(format, arg0);
            }
            //--TRIMMABLE-BOUNDARY-END(751619801130)
            
            //--TRIMMABLE-BOUNDARY-START(747324833834)
            static /*void */ Write$12(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747324833834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$12(format, arg0, arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(747324833834)
            
            //--TRIMMABLE-BOUNDARY-START(743029866538)
            static /*void */ Write$11(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1, /*object?*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(743029866538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$11(format, arg0, arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(743029866538)
            
            //--TRIMMABLE-BOUNDARY-START(755914768426)
            static /*void */ Write$14(/*string*/ format, /*params object?[]?*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755914768426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (arg === null)
                {
                    $.$scsl.System.Console.Out.Write$12(format, null, null);
                }
                else 
                {
                    $.$scsl.System.Console.Out.Write$14(format, arg);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(755914768426)
            
            //--TRIMMABLE-BOUNDARY-START(760209735722)
            static /*void */ Write$15(/*string*/ format, /*params ReadOnlySpan<object?>*/ arg)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760209735722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$15(format, arg);
            }
            //--TRIMMABLE-BOUNDARY-END(760209735722)
            
            //--TRIMMABLE-BOUNDARY-START(695785226282)
            static /*void */ Write(/*bool*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695785226282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write(value);
            }
            //--TRIMMABLE-BOUNDARY-END(695785226282)
            
            //--TRIMMABLE-BOUNDARY-START(700080193578)
            static /*void */ Write$1(/*char*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700080193578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(700080193578)
            
            //--TRIMMABLE-BOUNDARY-START(708670128170)
            static /*void */ Write$3(/*char[]?*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(708670128170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$3(buffer);
            }
            //--TRIMMABLE-BOUNDARY-END(708670128170)
            
            //--TRIMMABLE-BOUNDARY-START(704375160874)
            static /*void */ Write$2(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704375160874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$2(buffer, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(704375160874)
            
            //--TRIMMABLE-BOUNDARY-START(717260062762)
            static /*void */ Write$5(/*double*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(717260062762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$5(value);
            }
            //--TRIMMABLE-BOUNDARY-END(717260062762)
            
            //--TRIMMABLE-BOUNDARY-START(712965095466)
            static /*void */ Write$4(/*decimal*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712965095466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$4(value);
            }
            //--TRIMMABLE-BOUNDARY-END(712965095466)
            
            //--TRIMMABLE-BOUNDARY-START(738734899242)
            static /*void */ Write$10(/*float*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738734899242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$10(value);
            }
            //--TRIMMABLE-BOUNDARY-END(738734899242)
            
            //--TRIMMABLE-BOUNDARY-START(721555030058)
            static /*void */ Write$6(/*int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721555030058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$6(value);
            }
            //--TRIMMABLE-BOUNDARY-END(721555030058)
            
            //--TRIMMABLE-BOUNDARY-START(768799670314)
            static /*void */ Write$17(/*uint*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799670314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$18(value);
            }
            //--TRIMMABLE-BOUNDARY-END(768799670314)
            
            //--TRIMMABLE-BOUNDARY-START(725849997354)
            static /*void */ Write$7(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725849997354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$7(value);
            }
            //--TRIMMABLE-BOUNDARY-END(725849997354)
            
            //--TRIMMABLE-BOUNDARY-START(773094637610)
            static /*void */ Write$18(/*ulong*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773094637610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$19(value);
            }
            //--TRIMMABLE-BOUNDARY-END(773094637610)
            
            //--TRIMMABLE-BOUNDARY-START(730144964650)
            static /*void */ Write$8(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730144964650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$8(value);
            }
            //--TRIMMABLE-BOUNDARY-END(730144964650)
            
            //--TRIMMABLE-BOUNDARY-START(764504703018)
            static /*void */ Write$16(/*string?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764504703018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$16(value);
            }
            //--TRIMMABLE-BOUNDARY-END(764504703018)
            
            //--TRIMMABLE-BOUNDARY-START(734439931946)
            static /*void */ Write$9(/*ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439931946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$scsl.System.Console.Out.Write$9(value);
            }
            //--TRIMMABLE-BOUNDARY-END(734439931946)
            
            //--TRIMMABLE-BOUNDARY-START(330713006122)
            static /*void */ HandlePosixSignal(/*PosixSignalContext*/ ctx)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713006122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(ctx.Signal === -2/*PosixSignal.SIGINT*/ || ctx.Signal === -3/*PosixSignal.SIGQUIT*/, "ctx.Signal == PosixSignal.SIGINT || ctx.Signal == PosixSignal.SIGQUIT");
                let handler;
                if ($.$is($.$scsl.System.Console.s_cancelCallbacks, $.$scsl.System.ConsoleCancelEventHandler, { set $v(v){ handler = v; } }))
                {
                    /*var*/ let args = new $.$scsl.System.ConsoleCancelEventArgs().$ctor$2(ctx.Signal === -2/*PosixSignal.SIGINT*/ ? 0/*ConsoleSpecialKey.ControlC*/ : 1/*ConsoleSpecialKey.ControlBreak*/);
                    args.Cancel = ctx.Cancel;
                    handler.Invoke(null, args);
                    ctx.Cancel = args.Cancel;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(330713006122)
            
            //--TRIMMABLE-BOUNDARY-START(17180393514)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(493921763370)
                    this.s_syncObject = new $.$$.System.Object().$ctor();
                    //--TRIMMABLE-BOUNDARY-END(493921763370)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393514)
            
            static $h = 524330;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(335007973418),
    {
      "p": 95682561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684118058,
        "f": 50331681
      },
      "n": "In",
      "d": 524330,
      "h": 335007973418,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(335007973418),
//--TRIMMABLE-BOUNDARY-START(339302940714),
    {
      "p": 165937153,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274052650,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 571231174698,
        "f": 83886113
      },
      "n": "InputEncoding",
      "d": 524330,
      "h": 339302940714,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(339302940714),
//--TRIMMABLE-BOUNDARY-START(412317384746),
    {
      "p": 165937153,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583463978,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 579821109290,
        "f": 83886113,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "OutputEncoding",
      "d": 524330,
      "h": 412317384746,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(412317384746),
//--TRIMMABLE-BOUNDARY-START(356482809898),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633791018,
        "f": 50331681
      },
      "n": "KeyAvailable",
      "d": 524330,
      "h": 356482809898,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(356482809898),
//--TRIMMABLE-BOUNDARY-START(408022417450),
    {
      "p": 95813633,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993529386,
        "f": 50331681
      },
      "n": "Out",
      "d": 524330,
      "h": 408022417450,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(408022417450),
//--TRIMMABLE-BOUNDARY-START(85899870250),
    {
      "p": 95813633,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504248874,
        "f": 50331681
      },
      "n": "Error",
      "d": 524330,
      "h": 85899870250,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(85899870250),
//--TRIMMABLE-BOUNDARY-START(347892875306),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453921834,
        "f": 50331681
      },
      "n": "IsInputRedirected",
      "d": 524330,
      "h": 347892875306,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(347892875306),
//--TRIMMABLE-BOUNDARY-START(352187842602),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043856426,
        "f": 50331681
      },
      "n": "IsOutputRedirected",
      "d": 524330,
      "h": 352187842602,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(352187842602),
//--TRIMMABLE-BOUNDARY-START(343597908010),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863987242,
        "f": 50331681
      },
      "n": "IsErrorRedirected",
      "d": 524330,
      "h": 343597908010,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(343597908010),
//--TRIMMABLE-BOUNDARY-START(73014968362),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734445098,
        "f": 50331681,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 536871436330,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "CursorSize",
      "d": 524330,
      "h": 73014968362,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73014968362),
//--TRIMMABLE-BOUNDARY-START(377957646378),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403594794,
        "f": 50331681
      },
      "n": "NumberLock",
      "d": 524330,
      "h": 377957646378,
      "f": 2097185,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377957646378),
//--TRIMMABLE-BOUNDARY-START(55835099178),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554575914,
        "f": 50331681
      },
      "n": "CapsLock",
      "d": 524330,
      "h": 55835099178,
      "f": 2097185,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835099178),
//--TRIMMABLE-BOUNDARY-START(30065295402),
    {
      "p": 720938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784772138,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 502511697962,
        "f": 83886113
      },
      "n": "BackgroundColor",
      "d": 524330,
      "h": 30065295402,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065295402),
//--TRIMMABLE-BOUNDARY-START(90194837546),
    {
      "p": 720938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094183466,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 562641240106,
        "f": 83886113
      },
      "n": "ForegroundColor",
      "d": 524330,
      "h": 90194837546,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194837546),
//--TRIMMABLE-BOUNDARY-START(47245164586),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964641322,
        "f": 50331681,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 519691567146,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "BufferWidth",
      "d": 524330,
      "h": 47245164586,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245164586),
//--TRIMMABLE-BOUNDARY-START(42950197290),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374706730,
        "f": 50331681,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 511101632554,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "BufferHeight",
      "d": 524330,
      "h": 42950197290,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950197290),
//--TRIMMABLE-BOUNDARY-START(682900324394),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943202346,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 614180847658,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "WindowLeft",
      "d": 524330,
      "h": 682900324394,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(682900324394),
//--TRIMMABLE-BOUNDARY-START(687195291690),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313533136938,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 622770782250,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "WindowTop",
      "d": 524330,
      "h": 687195291690,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(687195291690),
//--TRIMMABLE-BOUNDARY-START(691490258986),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322123071530,
        "f": 50331681,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 631360716842,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "WindowWidth",
      "d": 524330,
      "h": 691490258986,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(691490258986),
//--TRIMMABLE-BOUNDARY-START(678605357098),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353267754,
        "f": 50331681,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 605590913066,
        "f": 83886113,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "WindowHeight",
      "d": 524330,
      "h": 678605357098,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(678605357098),
//--TRIMMABLE-BOUNDARY-START(365072744490),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813660202,
        "f": 50331681
      },
      "n": "LargestWindowWidth",
      "d": 524330,
      "h": 365072744490,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(365072744490),
//--TRIMMABLE-BOUNDARY-START(360777777194),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223725610,
        "f": 50331681
      },
      "n": "LargestWindowHeight",
      "d": 524330,
      "h": 360777777194,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(360777777194),
//--TRIMMABLE-BOUNDARY-START(81604902954),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914314282,
        "f": 50331681,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 554051305514,
        "f": 83886113,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "CursorVisible",
      "d": 524330,
      "h": 81604902954,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(81604902954),
//--TRIMMABLE-BOUNDARY-START(68720001066),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144510506,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 528281501738,
        "f": 83886113
      },
      "n": "CursorLeft",
      "d": 524330,
      "h": 68720001066,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720001066),
//--TRIMMABLE-BOUNDARY-START(77309935658),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324379690,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 545461370922,
        "f": 83886113
      },
      "n": "CursorTop",
      "d": 524330,
      "h": 77309935658,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309935658),
//--TRIMMABLE-BOUNDARY-START(665720455210),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173398570,
        "f": 50331681,
        "a": [
          {
            "t": 159055873,
            "c": 4454023169,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 588411043882,
        "f": 83886113,
        "a": [
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "android",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "browser",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159383553,
            "c": 13044285441,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "Title",
      "d": 524330,
      "h": 665720455210,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(665720455210),
//--TRIMMABLE-BOUNDARY-START(670015422506),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763333162,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 597000978474,
        "f": 83886113
      },
      "n": "TreatControlCAsInput",
      "d": 524330,
      "h": 670015422506,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(670015422506)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(425202286634),
    {
      "r": 852010,
      "n": "ReadKey",
      "d": 524330,
      "h": 425202286634,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(425202286634),
//--TRIMMABLE-BOUNDARY-START(429497253930),
    {
      "r": 852010,
      "p": [
        {
          "n": "intercept",
          "p": 262145
        }
      ],
      "n": "ReadKey",
      "o": "@$1",
      "d": 524330,
      "h": 429497253930,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(429497253930),
//--TRIMMABLE-BOUNDARY-START(64425033770),
    {
      "r": 95813633,
      "p": [
        {
          "n": "outputStream",
          "p": 94961665
        }
      ],
      "n": "CreateOutputWriter",
      "d": 524330,
      "h": 64425033770,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64425033770),
//--TRIMMABLE-BOUNDARY-START(446677123114),
    {
      "r": 65537,
      "n": "ResetColor",
      "d": 524330,
      "h": 446677123114,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(446677123114),
//--TRIMMABLE-BOUNDARY-START(635655684138),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "SetBufferSize",
      "d": 524330,
      "h": 635655684138,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(635655684138),
//--TRIMMABLE-BOUNDARY-START(657130520618),
    {
      "r": 65537,
      "p": [
        {
          "n": "left",
          "p": 655361
        },
        {
          "n": "top",
          "p": 655361
        }
      ],
      "n": "SetWindowPosition",
      "d": 524330,
      "h": 657130520618,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(657130520618),
//--TRIMMABLE-BOUNDARY-START(661425487914),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "SetWindowSize",
      "d": 524330,
      "h": 661425487914,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(661425487914),
//--TRIMMABLE-BOUNDARY-START(326418038826),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h,
      "n": "GetCursorPosition",
      "d": 524330,
      "h": 326418038826,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(326418038826),
//--TRIMMABLE-BOUNDARY-START(34360262698),
    {
      "r": 65537,
      "n": "Beep",
      "d": 524330,
      "h": 34360262698,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360262698),
//--TRIMMABLE-BOUNDARY-START(38655229994),
    {
      "r": 65537,
      "p": [
        {
          "n": "frequency",
          "p": 655361
        },
        {
          "n": "duration",
          "p": 655361
        }
      ],
      "n": "Beep",
      "o": "@$1",
      "d": 524330,
      "h": 38655229994,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655229994),
//--TRIMMABLE-BOUNDARY-START(373662679082),
    {
      "r": 65537,
      "p": [
        {
          "n": "sourceLeft",
          "p": 655361
        },
        {
          "n": "sourceTop",
          "p": 655361
        },
        {
          "n": "sourceWidth",
          "p": 655361
        },
        {
          "n": "sourceHeight",
          "p": 655361
        },
        {
          "n": "targetLeft",
          "p": 655361
        },
        {
          "n": "targetTop",
          "p": 655361
        }
      ],
      "n": "MoveBufferArea",
      "o": "@$1",
      "d": 524330,
      "h": 373662679082,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(373662679082),
//--TRIMMABLE-BOUNDARY-START(369367711786),
    {
      "r": 65537,
      "p": [
        {
          "n": "sourceLeft",
          "p": 655361
        },
        {
          "n": "sourceTop",
          "p": 655361
        },
        {
          "n": "sourceWidth",
          "p": 655361
        },
        {
          "n": "sourceHeight",
          "p": 655361
        },
        {
          "n": "targetLeft",
          "p": 655361
        },
        {
          "n": "targetTop",
          "p": 655361
        },
        {
          "n": "sourceChar",
          "p": 458753
        },
        {
          "n": "sourceForeColor",
          "p": 720938
        },
        {
          "n": "sourceBackColor",
          "p": 720938
        }
      ],
      "n": "MoveBufferArea",
      "d": 524330,
      "h": 369367711786,
      "f": 16777249,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(369367711786),
//--TRIMMABLE-BOUNDARY-START(60130066474),
    {
      "r": 65537,
      "n": "Clear",
      "d": 524330,
      "h": 60130066474,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130066474),
//--TRIMMABLE-BOUNDARY-START(639950651434),
    {
      "r": 65537,
      "p": [
        {
          "n": "left",
          "p": 655361
        },
        {
          "n": "top",
          "p": 655361
        }
      ],
      "n": "SetCursorPosition",
      "d": 524330,
      "h": 639950651434,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(639950651434),
//--TRIMMABLE-BOUNDARY-START(390842548266),
    {
      "r": 94961665,
      "n": "OpenStandardInput",
      "d": 524330,
      "h": 390842548266,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(390842548266),
//--TRIMMABLE-BOUNDARY-START(395137515562),
    {
      "r": 94961665,
      "p": [
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "OpenStandardInput",
      "o": "@$1",
      "d": 524330,
      "h": 395137515562,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395137515562),
//--TRIMMABLE-BOUNDARY-START(399432482858),
    {
      "r": 94961665,
      "n": "OpenStandardOutput",
      "d": 524330,
      "h": 399432482858,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(399432482858),
//--TRIMMABLE-BOUNDARY-START(403727450154),
    {
      "r": 94961665,
      "p": [
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "OpenStandardOutput",
      "o": "@$1",
      "d": 524330,
      "h": 403727450154,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(403727450154),
//--TRIMMABLE-BOUNDARY-START(382252613674),
    {
      "r": 94961665,
      "n": "OpenStandardError",
      "d": 524330,
      "h": 382252613674,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(382252613674),
//--TRIMMABLE-BOUNDARY-START(386547580970),
    {
      "r": 94961665,
      "p": [
        {
          "n": "bufferSize",
          "p": 655361
        }
      ],
      "n": "OpenStandardError",
      "o": "@$1",
      "d": 524330,
      "h": 386547580970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(386547580970),
//--TRIMMABLE-BOUNDARY-START(648540586026),
    {
      "r": 65537,
      "p": [
        {
          "n": "newIn",
          "p": 95682561
        }
      ],
      "n": "SetIn",
      "d": 524330,
      "h": 648540586026,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(648540586026),
//--TRIMMABLE-BOUNDARY-START(652835553322),
    {
      "r": 65537,
      "p": [
        {
          "n": "newOut",
          "p": 95813633
        }
      ],
      "n": "SetOut",
      "d": 524330,
      "h": 652835553322,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(652835553322),
//--TRIMMABLE-BOUNDARY-START(644245618730),
    {
      "r": 65537,
      "p": [
        {
          "n": "newError",
          "p": 95813633
        }
      ],
      "n": "SetError",
      "d": 524330,
      "h": 644245618730,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(644245618730),
//--TRIMMABLE-BOUNDARY-START(416612352042),
    {
      "r": 655361,
      "n": "Read",
      "d": 524330,
      "h": 416612352042,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(416612352042),
//--TRIMMABLE-BOUNDARY-START(433792221226),
    {
      "r": 1310721,
      "n": "ReadLine",
      "d": 524330,
      "h": 433792221226,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(433792221226),
//--TRIMMABLE-BOUNDARY-START(781684572202),
    {
      "r": 65537,
      "n": "WriteLine",
      "d": 524330,
      "h": 781684572202,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(781684572202),
//--TRIMMABLE-BOUNDARY-START(785979539498),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "WriteLine",
      "o": "@$1",
      "d": 524330,
      "h": 785979539498,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(785979539498),
//--TRIMMABLE-BOUNDARY-START(790274506794),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "WriteLine",
      "o": "@$2",
      "d": 524330,
      "h": 790274506794,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(790274506794),
//--TRIMMABLE-BOUNDARY-START(798864441386),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        }
      ],
      "n": "WriteLine",
      "o": "@$4",
      "d": 524330,
      "h": 798864441386,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(798864441386),
//--TRIMMABLE-BOUNDARY-START(794569474090),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "WriteLine",
      "o": "@$3",
      "d": 524330,
      "h": 794569474090,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(794569474090),
//--TRIMMABLE-BOUNDARY-START(803159408682),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66125825
        }
      ],
      "n": "WriteLine",
      "o": "@$5",
      "d": 524330,
      "h": 803159408682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(803159408682),
//--TRIMMABLE-BOUNDARY-START(807454375978),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "WriteLine",
      "o": "@$6",
      "d": 524330,
      "h": 807454375978,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(807454375978),
//--TRIMMABLE-BOUNDARY-START(828929212458),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113
        }
      ],
      "n": "WriteLine",
      "o": "@$11",
      "d": 524330,
      "h": 828929212458,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(828929212458),
//--TRIMMABLE-BOUNDARY-START(811749343274),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "WriteLine",
      "o": "@$7",
      "d": 524330,
      "h": 811749343274,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(811749343274),
//--TRIMMABLE-BOUNDARY-START(858993983530),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "WriteLine",
      "o": "@$18",
      "d": 524330,
      "h": 858993983530,
      "f": 16777249,
      "a": [
        {
          "t": 54263809,
          "c": 8644198401,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(858993983530),
//--TRIMMABLE-BOUNDARY-START(816044310570),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "WriteLine",
      "o": "@$8",
      "d": 524330,
      "h": 816044310570,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(816044310570),
//--TRIMMABLE-BOUNDARY-START(863288950826),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 983041
        }
      ],
      "n": "WriteLine",
      "o": "@$19",
      "d": 524330,
      "h": 863288950826,
      "f": 16777249,
      "a": [
        {
          "t": 54263809,
          "c": 8644198401,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(863288950826),
//--TRIMMABLE-BOUNDARY-START(820339277866),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$9",
      "d": 524330,
      "h": 820339277866,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(820339277866),
//--TRIMMABLE-BOUNDARY-START(854699016234),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$17",
      "d": 524330,
      "h": 854699016234,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(854699016234),
//--TRIMMABLE-BOUNDARY-START(824634245162),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "WriteLine",
      "o": "@$10",
      "d": 524330,
      "h": 824634245162,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(824634245162),
//--TRIMMABLE-BOUNDARY-START(841814114346),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$14",
      "d": 524330,
      "h": 841814114346,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(841814114346),
//--TRIMMABLE-BOUNDARY-START(837519147050),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        },
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$13",
      "d": 524330,
      "h": 837519147050,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(837519147050),
//--TRIMMABLE-BOUNDARY-START(833224179754),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        },
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$12",
      "d": 524330,
      "h": 833224179754,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(833224179754),
//--TRIMMABLE-BOUNDARY-START(846109081642),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteLine",
      "o": "@$15",
      "d": 524330,
      "h": 846109081642,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(846109081642),
//--TRIMMABLE-BOUNDARY-START(850404048938),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "WriteLine",
      "o": "@$16",
      "d": 524330,
      "h": 850404048938,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(850404048938),
//--TRIMMABLE-BOUNDARY-START(751619801130),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$13",
      "d": 524330,
      "h": 751619801130,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(751619801130),
//--TRIMMABLE-BOUNDARY-START(747324833834),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        },
        {
          "n": "arg1",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$12",
      "d": 524330,
      "h": 747324833834,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(747324833834),
//--TRIMMABLE-BOUNDARY-START(743029866538),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg0",
          "p": 131073
        },
        {
          "n": "arg1",
          "p": 131073
        },
        {
          "n": "arg2",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$11",
      "d": 524330,
      "h": 743029866538,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(743029866538),
//--TRIMMABLE-BOUNDARY-START(755914768426),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg",
          "p": $.$typeArray($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Write",
      "o": "@$14",
      "d": 524330,
      "h": 755914768426,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(755914768426),
//--TRIMMABLE-BOUNDARY-START(760209735722),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "arg",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Object).$h,
          "f": 16
        }
      ],
      "n": "Write",
      "o": "@$15",
      "d": 524330,
      "h": 760209735722,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(760209735722),
//--TRIMMABLE-BOUNDARY-START(695785226282),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 262145
        }
      ],
      "n": "Write",
      "d": 524330,
      "h": 695785226282,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(695785226282),
//--TRIMMABLE-BOUNDARY-START(700080193578),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 458753
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 524330,
      "h": 700080193578,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(700080193578),
//--TRIMMABLE-BOUNDARY-START(708670128170),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        }
      ],
      "n": "Write",
      "o": "@$3",
      "d": 524330,
      "h": 708670128170,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(708670128170),
//--TRIMMABLE-BOUNDARY-START(704375160874),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 524330,
      "h": 704375160874,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(704375160874),
//--TRIMMABLE-BOUNDARY-START(717260062762),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1179649
        }
      ],
      "n": "Write",
      "o": "@$5",
      "d": 524330,
      "h": 717260062762,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(717260062762),
//--TRIMMABLE-BOUNDARY-START(712965095466),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 66125825
        }
      ],
      "n": "Write",
      "o": "@$4",
      "d": 524330,
      "h": 712965095466,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(712965095466),
//--TRIMMABLE-BOUNDARY-START(738734899242),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1114113
        }
      ],
      "n": "Write",
      "o": "@$10",
      "d": 524330,
      "h": 738734899242,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(738734899242),
//--TRIMMABLE-BOUNDARY-START(721555030058),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "@$6",
      "d": 524330,
      "h": 721555030058,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(721555030058),
//--TRIMMABLE-BOUNDARY-START(768799670314),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "Write",
      "o": "@$17",
      "d": 524330,
      "h": 768799670314,
      "f": 16777249,
      "a": [
        {
          "t": 54263809,
          "c": 8644198401,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(768799670314),
//--TRIMMABLE-BOUNDARY-START(725849997354),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "Write",
      "o": "@$7",
      "d": 524330,
      "h": 725849997354,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(725849997354),
//--TRIMMABLE-BOUNDARY-START(773094637610),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 983041
        }
      ],
      "n": "Write",
      "o": "@$18",
      "d": 524330,
      "h": 773094637610,
      "f": 16777249,
      "a": [
        {
          "t": 54263809,
          "c": 8644198401,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(773094637610),
//--TRIMMABLE-BOUNDARY-START(730144964650),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$8",
      "d": 524330,
      "h": 730144964650,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(730144964650),
//--TRIMMABLE-BOUNDARY-START(764504703018),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$16",
      "d": 524330,
      "h": 764504703018,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(764504703018),
//--TRIMMABLE-BOUNDARY-START(734439931946),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Write",
      "o": "@$9",
      "d": 524330,
      "h": 734439931946,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(734439931946),
//--TRIMMABLE-BOUNDARY-START(330713006122),
    {
      "r": 65537,
      "p": [
        {
          "n": "ctx",
          "p": 146472961
        }
      ],
      "n": "HandlePosixSignal",
      "d": 524330,
      "h": 330713006122,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(330713006122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(420907319338),
    {
      "t": 655361,
      "n": "ReadBufferSize",
      "d": 524330,
      "h": 420907319338,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907319338),
//--TRIMMABLE-BOUNDARY-START(777389604906),
    {
      "t": 655361,
      "n": "WriteBufferSize",
      "d": 524330,
      "h": 777389604906,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(777389604906),
//--TRIMMABLE-BOUNDARY-START(493921763370),
    {
      "t": 131073,
      "n": "s_syncObject",
      "d": 524330,
      "h": 493921763370,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(493921763370),
//--TRIMMABLE-BOUNDARY-START(459562025002),
    {
      "t": 95682561,
      "n": "s_in",
      "d": 524330,
      "h": 459562025002,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(459562025002),
//--TRIMMABLE-BOUNDARY-START(476741894186),
    {
      "t": 95813633,
      "n": "s_out",
      "d": 524330,
      "h": 476741894186,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(476741894186),
//--TRIMMABLE-BOUNDARY-START(455267057706),
    {
      "t": 95813633,
      "n": "s_error",
      "d": 524330,
      "h": 455267057706,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(455267057706),
//--TRIMMABLE-BOUNDARY-START(463856992298),
    {
      "t": 165937153,
      "n": "s_inputEncoding",
      "d": 524330,
      "h": 463856992298,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(463856992298),
//--TRIMMABLE-BOUNDARY-START(481036861482),
    {
      "t": 165937153,
      "n": "s_outputEncoding",
      "d": 524330,
      "h": 481036861482,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(481036861482),
//--TRIMMABLE-BOUNDARY-START(472446926890),
    {
      "t": 262145,
      "n": "s_isOutTextWriterRedirected",
      "d": 524330,
      "h": 472446926890,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(472446926890),
//--TRIMMABLE-BOUNDARY-START(468151959594),
    {
      "t": 262145,
      "n": "s_isErrorTextWriterRedirected",
      "d": 524330,
      "h": 468151959594,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(468151959594),
//--TRIMMABLE-BOUNDARY-START(450972090410),
    {
      "t": 655402,
      "n": "s_cancelCallbacks",
      "d": 524330,
      "h": 450972090410,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(450972090410),
//--TRIMMABLE-BOUNDARY-START(485331828778),
    {
      "t": 146538497,
      "n": "s_sigIntRegistration",
      "d": 524330,
      "h": 485331828778,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(485331828778),
//--TRIMMABLE-BOUNDARY-START(489626796074),
    {
      "t": 146538497,
      "n": "s_sigQuitRegistration",
      "d": 524330,
      "h": 489626796074,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(489626796074),
//--TRIMMABLE-BOUNDARY-START(8590458922),
    {
      "t": $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean).$h,
      "n": "_isStdInRedirected",
      "d": 524330,
      "h": 8590458922,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(8590458922),
//--TRIMMABLE-BOUNDARY-START(12885426218),
    {
      "t": $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean).$h,
      "n": "_isStdOutRedirected",
      "d": 524330,
      "h": 12885426218,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885426218),
//--TRIMMABLE-BOUNDARY-START(4295491626),
    {
      "t": $.$$.System.Runtime.CompilerServices.StrongBox$$($.$$.System.Boolean).$h,
      "n": "_isStdErrRedirected",
      "d": 524330,
      "h": 4295491626,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295491626),
//--TRIMMABLE-BOUNDARY-START(674310389802),
    {
      "t": 720938,
      "n": "UnknownColor",
      "d": 524330,
      "h": 674310389802,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(674310389802)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(51540131882),
    {
      "e": 655402,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 655402
          }
        ],
        "n": "add_CancelKeyPress",
        "d": 524330,
        "h": 25770328106,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 655402
          }
        ],
        "n": "remove_CancelKeyPress",
        "d": 524330,
        "h": 442382155818,
        "f": 285212705
      },
      "n": "CancelKeyPress",
      "d": 524330,
      "h": 51540131882,
      "f": 8388641,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540131882)
  ],
  "h": 524330
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Console`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524330)
        
        
        //--TRIMMABLE-BOUNDARY-START(983082)
        $asm.$cls("$scsl.System.ConsolePal", ($self) => class ConsolePal
        {
            //--TRIMMABLE-BOUNDARY-START(287763791914)
            /*Encoding?*/ static s_outputEncoding = null;
            //--TRIMMABLE-BOUNDARY-END(287763791914)
            
            //--TRIMMABLE-BOUNDARY-START(42950656042)
            static /*void */ EnsureConsoleInitialized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950656042)
            
            //--TRIMMABLE-BOUNDARY-START(266288955434)
            static /*Stream */ OpenStandardInput()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(266288955434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266288955434)
            
            //--TRIMMABLE-BOUNDARY-START(270583922730)
            static /*Stream */ OpenStandardOutput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583922730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scsl.System.WasmConsoleStream().$ctor$4($.$scsl.Interop.Sys.Dup($.$scsl.Interop.Sys.FileDescriptors.STDOUT_FILENO), 2/*FileAccess.Write*/);
            }
            //--TRIMMABLE-BOUNDARY-END(270583922730)
            
            //--TRIMMABLE-BOUNDARY-START(261993988138)
            static /*Stream */ OpenStandardError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993988138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$scsl.System.WasmConsoleStream().$ctor$4($.$scsl.Interop.Sys.Dup($.$scsl.Interop.Sys.FileDescriptors.STDERR_FILENO), 2/*FileAccess.Write*/);
            }
            //--TRIMMABLE-BOUNDARY-END(261993988138)
            
            //--TRIMMABLE-BOUNDARY-START(223339282474)
            static /*Encoding */ get InputEncoding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223339282474)
            
            //--TRIMMABLE-BOUNDARY-START(399432941610)
            static /*void */ SetConsoleInputEncoding(/*Encoding*/ enc)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(399432941610);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(399432941610)
            
            //--TRIMMABLE-BOUNDARY-START(274878890026)
            static /*Encoding */ get OutputEncoding()
            {
                return $.$scsl.System.ConsolePal.s_outputEncoding ?? $.$$.System.Text.Encoding.UTF8;
            }
            //--TRIMMABLE-BOUNDARY-END(274878890026)
            
            //--TRIMMABLE-BOUNDARY-START(403727908906)
            static /*void */ SetConsoleOutputEncoding(/*Encoding*/ enc)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(403727908906);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$scsl.System.ConsolePal.s_outputEncoding = enc;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(403727908906)
            
            //--TRIMMABLE-BOUNDARY-START(231929217066)
            static /*bool */ IsInputRedirectedCore()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231929217066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929217066)
            
            //--TRIMMABLE-BOUNDARY-START(236224184362)
            static /*bool */ IsOutputRedirectedCore()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236224184362);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224184362)
            
            //--TRIMMABLE-BOUNDARY-START(227634249770)
            static /*bool */ IsErrorRedirectedCore()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(227634249770);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634249770)
            
            //--TRIMMABLE-BOUNDARY-START(219044315178)
            static /*TextReader */ GetOrCreateReader()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219044315178);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044315178)
            
            //--TRIMMABLE-BOUNDARY-START(257699020842)
            static /*bool */ get NumberLock()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257699020842)
            
            //--TRIMMABLE-BOUNDARY-START(25770786858)
            static /*bool */ get CapsLock()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770786858)
            
            //--TRIMMABLE-BOUNDARY-START(240519151658)
            static /*bool */ get KeyAvailable()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(240519151658)
            
            //--TRIMMABLE-BOUNDARY-START(279173857322)
            static /*ConsoleKeyInfo */ ReadKey(/*bool*/ intercept)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(279173857322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(279173857322)
            
            //--TRIMMABLE-BOUNDARY-START(425202745386)
            static /*bool */ get TreatControlCAsInput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094642218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set TreatControlCAsInput(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483268650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(425202745386)
            
            //--TRIMMABLE-BOUNDARY-START(4295950378)
            static /*ConsoleColor */ get BackgroundColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ set BackgroundColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353726506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950378)
            
            //--TRIMMABLE-BOUNDARY-START(47245623338)
            static /*ConsoleColor */ get ForegroundColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ set ForegroundColor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303399466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245623338)
            
            //--TRIMMABLE-BOUNDARY-START(283468824618)
            static /*void */ ResetColor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(283468824618);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468824618)
            
            //--TRIMMABLE-BOUNDARY-START(34360721450)
            static /*int */ get CursorSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set CursorSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123530282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360721450)
            
            //--TRIMMABLE-BOUNDARY-START(38655688746)
            static /*bool */ get CursorVisible()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set CursorVisible(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713464874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655688746)
            
            //--TRIMMABLE-BOUNDARY-START(214749347882)
            static /*(int Left, int Top) */ GetCursorPosition()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214749347882);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749347882)
            
            //--TRIMMABLE-BOUNDARY-START(420907778090)
            static /*string */ get Title()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504707626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ set Title(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893334058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(420907778090)
            
            //--TRIMMABLE-BOUNDARY-START(8590917674)
            static /*void */ Beep()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917674);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590917674)
            
            //--TRIMMABLE-BOUNDARY-START(12885884970)
            static /*void */ Beep$1(/*int*/ frequency, /*int*/ duration)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885884970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885884970)
            
            //--TRIMMABLE-BOUNDARY-START(253404053546)
            static /*void */ MoveBufferArea(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop, /*char*/ sourceChar, /*ConsoleColor*/ sourceForeColor, /*ConsoleColor*/ sourceBackColor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253404053546);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404053546)
            
            //--TRIMMABLE-BOUNDARY-START(408022876202)
            static /*void */ SetCursorPosition(/*int*/ left, /*int*/ top)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(408022876202);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022876202)
            
            //--TRIMMABLE-BOUNDARY-START(21475819562)
            static /*int */ get BufferWidth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set BufferWidth(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533595690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475819562)
            
            //--TRIMMABLE-BOUNDARY-START(17180852266)
            static /*int */ get BufferHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set BufferHeight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943661098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180852266)
            
            //--TRIMMABLE-BOUNDARY-START(395137974314)
            static /*void */ SetBufferSize(/*int*/ width, /*int*/ height)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(395137974314);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(395137974314)
            
            //--TRIMMABLE-BOUNDARY-START(249109086250)
            static /*int */ get LargestWindowWidth()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249109086250)
            
            //--TRIMMABLE-BOUNDARY-START(244814118954)
            static /*int */ get LargestWindowHeight()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244814118954)
            
            //--TRIMMABLE-BOUNDARY-START(433792679978)
            static /*int */ get WindowLeft()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274511402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0;
            }
            static /*int */ set WindowLeft(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663137834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(433792679978)
            
            //--TRIMMABLE-BOUNDARY-START(438087647274)
            static /*int */ get WindowTop()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864445994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return 0;
            }
            static /*int */ set WindowTop(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253072426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(438087647274)
            
            //--TRIMMABLE-BOUNDARY-START(442382614570)
            static /*int */ get WindowWidth()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454380586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set WindowWidth(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843007018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(442382614570)
            
            //--TRIMMABLE-BOUNDARY-START(429497712682)
            static /*int */ get WindowHeight()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684576810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set WindowHeight(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073203242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(429497712682)
            
            //--TRIMMABLE-BOUNDARY-START(412317843498)
            static /*void */ SetWindowPosition(/*int*/ left, /*int*/ top)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(412317843498);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(412317843498)
            
            //--TRIMMABLE-BOUNDARY-START(416612810794)
            static /*void */ SetWindowSize(/*int*/ width, /*int*/ height)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(416612810794);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416612810794)
            
            static $h = 983082;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(223339282474),
    {
      "p": 165937153,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965100074,
        "f": 50331681
      },
      "n": "InputEncoding",
      "d": 983082,
      "h": 223339282474,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(223339282474),
//--TRIMMABLE-BOUNDARY-START(274878890026),
    {
      "p": 165937153,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914773034,
        "f": 50331681
      },
      "n": "OutputEncoding",
      "d": 983082,
      "h": 274878890026,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(274878890026),
//--TRIMMABLE-BOUNDARY-START(257699020842),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324838442,
        "f": 50331681
      },
      "n": "NumberLock",
      "d": 983082,
      "h": 257699020842,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(257699020842),
//--TRIMMABLE-BOUNDARY-START(25770786858),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361706,
        "f": 50331681
      },
      "n": "CapsLock",
      "d": 983082,
      "h": 25770786858,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770786858),
//--TRIMMABLE-BOUNDARY-START(240519151658),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555034666,
        "f": 50331681
      },
      "n": "KeyAvailable",
      "d": 983082,
      "h": 240519151658,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(240519151658),
//--TRIMMABLE-BOUNDARY-START(425202745386),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094642218,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356483268650,
        "f": 83886113
      },
      "n": "TreatControlCAsInput",
      "d": 983082,
      "h": 425202745386,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(425202745386),
//--TRIMMABLE-BOUNDARY-START(4295950378),
    {
      "p": 720938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557930,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353726506,
        "f": 83886113
      },
      "n": "BackgroundColor",
      "d": 983082,
      "h": 4295950378,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295950378),
//--TRIMMABLE-BOUNDARY-START(47245623338),
    {
      "p": 720938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375165482,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303399466,
        "f": 83886113
      },
      "n": "ForegroundColor",
      "d": 983082,
      "h": 47245623338,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245623338),
//--TRIMMABLE-BOUNDARY-START(34360721450),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195296298,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123530282,
        "f": 83886113
      },
      "n": "CursorSize",
      "d": 983082,
      "h": 34360721450,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360721450),
//--TRIMMABLE-BOUNDARY-START(38655688746),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785230890,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713464874,
        "f": 83886113
      },
      "n": "CursorVisible",
      "d": 983082,
      "h": 38655688746,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38655688746),
//--TRIMMABLE-BOUNDARY-START(420907778090),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504707626,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893334058,
        "f": 83886113
      },
      "n": "Title",
      "d": 983082,
      "h": 420907778090,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(420907778090),
//--TRIMMABLE-BOUNDARY-START(21475819562),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015427114,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533595690,
        "f": 83886113
      },
      "n": "BufferWidth",
      "d": 983082,
      "h": 21475819562,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475819562),
//--TRIMMABLE-BOUNDARY-START(17180852266),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425492522,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943661098,
        "f": 83886113
      },
      "n": "BufferHeight",
      "d": 983082,
      "h": 17180852266,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180852266),
//--TRIMMABLE-BOUNDARY-START(249109086250),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734903850,
        "f": 50331681
      },
      "n": "LargestWindowWidth",
      "d": 983082,
      "h": 249109086250,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(249109086250),
//--TRIMMABLE-BOUNDARY-START(244814118954),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144969258,
        "f": 50331681
      },
      "n": "LargestWindowHeight",
      "d": 983082,
      "h": 244814118954,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(244814118954),
//--TRIMMABLE-BOUNDARY-START(433792679978),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274511402,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373663137834,
        "f": 83886113
      },
      "n": "WindowLeft",
      "d": 983082,
      "h": 433792679978,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(433792679978),
//--TRIMMABLE-BOUNDARY-START(438087647274),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864445994,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382253072426,
        "f": 83886113
      },
      "n": "WindowTop",
      "d": 983082,
      "h": 438087647274,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(438087647274),
//--TRIMMABLE-BOUNDARY-START(442382614570),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454380586,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390843007018,
        "f": 83886113
      },
      "n": "WindowWidth",
      "d": 983082,
      "h": 442382614570,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(442382614570),
//--TRIMMABLE-BOUNDARY-START(429497712682),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684576810,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365073203242,
        "f": 83886113
      },
      "n": "WindowHeight",
      "d": 983082,
      "h": 429497712682,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(429497712682)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950656042),
    {
      "r": 65537,
      "n": "EnsureConsoleInitialized",
      "d": 983082,
      "h": 42950656042,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42950656042),
//--TRIMMABLE-BOUNDARY-START(266288955434),
    {
      "r": 94961665,
      "n": "OpenStandardInput",
      "d": 983082,
      "h": 266288955434,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266288955434),
//--TRIMMABLE-BOUNDARY-START(270583922730),
    {
      "r": 94961665,
      "n": "OpenStandardOutput",
      "d": 983082,
      "h": 270583922730,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583922730),
//--TRIMMABLE-BOUNDARY-START(261993988138),
    {
      "r": 94961665,
      "n": "OpenStandardError",
      "d": 983082,
      "h": 261993988138,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261993988138),
//--TRIMMABLE-BOUNDARY-START(399432941610),
    {
      "r": 65537,
      "p": [
        {
          "n": "enc",
          "p": 165937153
        }
      ],
      "n": "SetConsoleInputEncoding",
      "d": 983082,
      "h": 399432941610,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(399432941610),
//--TRIMMABLE-BOUNDARY-START(403727908906),
    {
      "r": 65537,
      "p": [
        {
          "n": "enc",
          "p": 165937153
        }
      ],
      "n": "SetConsoleOutputEncoding",
      "d": 983082,
      "h": 403727908906,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(403727908906),
//--TRIMMABLE-BOUNDARY-START(231929217066),
    {
      "r": 262145,
      "n": "IsInputRedirectedCore",
      "d": 983082,
      "h": 231929217066,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231929217066),
//--TRIMMABLE-BOUNDARY-START(236224184362),
    {
      "r": 262145,
      "n": "IsOutputRedirectedCore",
      "d": 983082,
      "h": 236224184362,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(236224184362),
//--TRIMMABLE-BOUNDARY-START(227634249770),
    {
      "r": 262145,
      "n": "IsErrorRedirectedCore",
      "d": 983082,
      "h": 227634249770,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227634249770),
//--TRIMMABLE-BOUNDARY-START(219044315178),
    {
      "r": 95682561,
      "n": "GetOrCreateReader",
      "d": 983082,
      "h": 219044315178,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(219044315178),
//--TRIMMABLE-BOUNDARY-START(279173857322),
    {
      "r": 852010,
      "p": [
        {
          "n": "intercept",
          "p": 262145
        }
      ],
      "n": "ReadKey",
      "d": 983082,
      "h": 279173857322,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(279173857322),
//--TRIMMABLE-BOUNDARY-START(283468824618),
    {
      "r": 65537,
      "n": "ResetColor",
      "d": 983082,
      "h": 283468824618,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(283468824618),
//--TRIMMABLE-BOUNDARY-START(214749347882),
    {
      "r": $.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h,
      "n": "GetCursorPosition",
      "d": 983082,
      "h": 214749347882,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214749347882),
//--TRIMMABLE-BOUNDARY-START(8590917674),
    {
      "r": 65537,
      "n": "Beep",
      "d": 983082,
      "h": 8590917674,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590917674),
//--TRIMMABLE-BOUNDARY-START(12885884970),
    {
      "r": 65537,
      "p": [
        {
          "n": "frequency",
          "p": 655361
        },
        {
          "n": "duration",
          "p": 655361
        }
      ],
      "n": "Beep",
      "o": "@$1",
      "d": 983082,
      "h": 12885884970,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885884970),
//--TRIMMABLE-BOUNDARY-START(253404053546),
    {
      "r": 65537,
      "p": [
        {
          "n": "sourceLeft",
          "p": 655361
        },
        {
          "n": "sourceTop",
          "p": 655361
        },
        {
          "n": "sourceWidth",
          "p": 655361
        },
        {
          "n": "sourceHeight",
          "p": 655361
        },
        {
          "n": "targetLeft",
          "p": 655361
        },
        {
          "n": "targetTop",
          "p": 655361
        },
        {
          "n": "sourceChar",
          "p": 458753
        },
        {
          "n": "sourceForeColor",
          "p": 720938
        },
        {
          "n": "sourceBackColor",
          "p": 720938
        }
      ],
      "n": "MoveBufferArea",
      "d": 983082,
      "h": 253404053546,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(253404053546),
//--TRIMMABLE-BOUNDARY-START(408022876202),
    {
      "r": 65537,
      "p": [
        {
          "n": "left",
          "p": 655361
        },
        {
          "n": "top",
          "p": 655361
        }
      ],
      "n": "SetCursorPosition",
      "d": 983082,
      "h": 408022876202,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(408022876202),
//--TRIMMABLE-BOUNDARY-START(395137974314),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "SetBufferSize",
      "d": 983082,
      "h": 395137974314,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(395137974314),
//--TRIMMABLE-BOUNDARY-START(412317843498),
    {
      "r": 65537,
      "p": [
        {
          "n": "left",
          "p": 655361
        },
        {
          "n": "top",
          "p": 655361
        }
      ],
      "n": "SetWindowPosition",
      "d": 983082,
      "h": 412317843498,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(412317843498),
//--TRIMMABLE-BOUNDARY-START(416612810794),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "SetWindowSize",
      "d": 983082,
      "h": 416612810794,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(416612810794)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(287763791914),
    {
      "t": 165937153,
      "n": "s_outputEncoding",
      "d": 983082,
      "h": 287763791914,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(287763791914)
  ],
  "h": 983082
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ConsolePal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983082)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572906)
        $asm.$str("$scsl.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(55836147754)
            /*void */ AppendSpanFormattable(T, /*T*/ value, /*string?*/ format, /*IFormatProvider?*/ provider)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836147754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, this._chars.Slice$1(this._pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), $.$$.System.String.op_Implicit(format), provider))
                {
                    this._pos += charsWritten;
                }
                else 
                {
                    this.Append$3($.$dsp(value, T, ($t) => $t.System$IFormattable$ToString, format, provider));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55836147754)
            
            //--TRIMMABLE-BOUNDARY-START(4296540202)
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296540202)
            
            //--TRIMMABLE-BOUNDARY-START(8591507498)
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            //--TRIMMABLE-BOUNDARY-END(8591507498)
            
            //--TRIMMABLE-BOUNDARY-START(12886474794)
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12886474794)
            
            //--TRIMMABLE-BOUNDARY-START(25771376682)
            $ctor$4(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771376682);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771376682)
            
            //--TRIMMABLE-BOUNDARY-START(21476409386)
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476409386);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._arrayToReturnToPool = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476409386)
            
            //--TRIMMABLE-BOUNDARY-START(150325428266)
            /*int */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670722602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._pos;
            }
            /*int */ set Length(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210330154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(value >= 0, "value >= 0");
                $.$$.System.Diagnostics.Debug.Assert$2(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            //--TRIMMABLE-BOUNDARY-END(150325428266)
            
            //--TRIMMABLE-BOUNDARY-START(77310984234)
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(77310984234)
            
            //--TRIMMABLE-BOUNDARY-START(85900918826)
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900918826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85900918826)
            
            //--TRIMMABLE-BOUNDARY-START(124555624490)
            /*ref char */ GetPinnableReference()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555624490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(124555624490)
            
            //--TRIMMABLE-BOUNDARY-START(128850591786)
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850591786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Char, this._chars);
            }
            //--TRIMMABLE-BOUNDARY-END(128850591786)
            
            //--TRIMMABLE-BOUNDARY-START(167505297450)
            /*ref char*/ get_Item$1(/*int*/ index)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            //--TRIMMABLE-BOUNDARY-END(167505297450)
            
            //--TRIMMABLE-BOUNDARY-START(171800264746)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800264746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let s = $.$$.System.Span$$($.$$.System.Char).ToString.call(this._chars.Slice(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scsl.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(171800264746)
            
            //--TRIMMABLE-BOUNDARY-START(154620395562)
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            //--TRIMMABLE-BOUNDARY-END(154620395562)
            
            //--TRIMMABLE-BOUNDARY-START(64426082346)
            /*ReadOnlySpan<char> */ AsSpan$1(/*bool*/ terminate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426082346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
            }
            //--TRIMMABLE-BOUNDARY-END(64426082346)
            
            //--TRIMMABLE-BOUNDARY-START(60131115050)
            /*ReadOnlySpan<char> */ AsSpan()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60131115050);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(0, this._pos));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131115050)
            
            //--TRIMMABLE-BOUNDARY-START(73016016938)
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73016016938);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, ((this._pos - start) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016016938)
            
            //--TRIMMABLE-BOUNDARY-START(68721049642)
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68721049642);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.Span$$($.$$.System.Char).op_Implicit(this._chars.Slice(start, length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68721049642)
            
            //--TRIMMABLE-BOUNDARY-START(176095232042)
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095232042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._chars.Slice(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095232042)
            
            //--TRIMMABLE-BOUNDARY-START(141735493674)
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735493674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                this._chars.Slice(index, count).Fill(value);
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(141735493674)
            
            //--TRIMMABLE-BOUNDARY-START(146030460970)
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030460970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice(index, remaining).CopyTo(this._chars.Slice$1(((index + count) | 0)));
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(index));
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(146030460970)
            
            //--TRIMMABLE-BOUNDARY-START(34361311274)
            /*void */ Append$1(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361311274)
            
            //--TRIMMABLE-BOUNDARY-START(42951245866)
            /*void */ Append$3(/*string?*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951245866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$$.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42951245866)
            
            //--TRIMMABLE-BOUNDARY-START(47246213162)
            /*void */ AppendSlow(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$$.System.String.CopyTo$1.call(s, this._chars.Slice$1(pos));
                this._pos += s.length;
            }
            //--TRIMMABLE-BOUNDARY-END(47246213162)
            
            //--TRIMMABLE-BOUNDARY-START(30066343978)
            /*void */ Append(/*char*/ c, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066343978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            //--TRIMMABLE-BOUNDARY-END(30066343978)
            
            //--TRIMMABLE-BOUNDARY-START(38656278570)
            /*void */ Append$2(/*scoped ReadOnlySpan<char>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656278570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice$1(this._pos));
                this._pos += value.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(38656278570)
            
            //--TRIMMABLE-BOUNDARY-START(51541180458)
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541180458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice(origPos, length);
            }
            //--TRIMMABLE-BOUNDARY-END(51541180458)
            
            //--TRIMMABLE-BOUNDARY-START(137440526378)
            /*void */ GrowAndAppend(/*char*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440526378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Grow(1);
                this.Append$1(c);
            }
            //--TRIMMABLE-BOUNDARY-END(137440526378)
            
            //--TRIMMABLE-BOUNDARY-START(133145559082)
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145559082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$$.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$$.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice(0, this._pos).CopyTo($.$$.System.Span$$($.$$.System.Char).op_Implicit$2(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133145559082)
            
            //--TRIMMABLE-BOUNDARY-START(81605951530)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605951530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$scsl.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(toReturn, false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605951530)
            
            //--TRIMMABLE-BOUNDARY-START(17181442090)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181442090)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296540202)
                this._arrayToReturnToPool = null;
                //--TRIMMABLE-BOUNDARY-END(4296540202)
                
                //--TRIMMABLE-BOUNDARY-START(8591507498)
                this._chars = $.$default($.$$.System.Span$$($.$$.System.Char));
                //--TRIMMABLE-BOUNDARY-END(8591507498)
                
                //--TRIMMABLE-BOUNDARY-START(12886474794)
                this._pos = 0;
                //--TRIMMABLE-BOUNDARY-END(12886474794)
                
            }
            static $h = 1572906;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(150325428266),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670722602,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163210330154,
        "f": 83886081
      },
      "n": "Length",
      "d": 1572906,
      "h": 150325428266,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325428266),
//--TRIMMABLE-BOUNDARY-START(77310984234),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490853418,
        "f": 50331649
      },
      "n": "Capacity",
      "d": 1572906,
      "h": 77310984234,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310984234),
//--TRIMMABLE-BOUNDARY-START(167505297450),
    {
      "p": 458753,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080788010,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$1",
      "d": 1572906,
      "h": 167505297450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167505297450),
//--TRIMMABLE-BOUNDARY-START(154620395562),
    {
      "p": $.$$.System.Span$$($.$$.System.Char).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260657194,
        "f": 50331649
      },
      "n": "RawChars",
      "d": 1572906,
      "h": 154620395562,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620395562)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55836147754),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": (T) => T.$h
        },
        {
          "n": "format",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "provider",
          "p": 90439681,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "AppendSpanFormattable",
      "d": 1572906,
      "h": 55836147754,
      "f": 16908296
    },
//--TRIMMABLE-BOUNDARY-END(55836147754),
//--TRIMMABLE-BOUNDARY-START(85900918826),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "EnsureCapacity",
      "d": 1572906,
      "h": 85900918826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900918826),
//--TRIMMABLE-BOUNDARY-START(124555624490),
    {
      "r": 458753,
      "n": "GetPinnableReference",
      "d": 1572906,
      "h": 124555624490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(124555624490),
//--TRIMMABLE-BOUNDARY-START(128850591786),
    {
      "r": 458753,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "GetPinnableReference",
      "o": "@$1",
      "d": 1572906,
      "h": 128850591786,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(128850591786),
//--TRIMMABLE-BOUNDARY-START(171800264746),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1572906,
      "h": 171800264746,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171800264746),
//--TRIMMABLE-BOUNDARY-START(64426082346),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "terminate",
          "p": 262145
        }
      ],
      "n": "AsSpan",
      "o": "@$1",
      "d": 1572906,
      "h": 64426082346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426082346),
//--TRIMMABLE-BOUNDARY-START(60131115050),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "n": "AsSpan",
      "d": 1572906,
      "h": 60131115050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60131115050),
//--TRIMMABLE-BOUNDARY-START(73016016938),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$3",
      "d": 1572906,
      "h": 73016016938,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016016938),
//--TRIMMABLE-BOUNDARY-START(68721049642),
    {
      "r": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AsSpan",
      "o": "@$2",
      "d": 1572906,
      "h": 68721049642,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721049642),
//--TRIMMABLE-BOUNDARY-START(176095232042),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        },
        {
          "n": "charsWritten",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryCopyTo",
      "d": 1572906,
      "h": 176095232042,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176095232042),
//--TRIMMABLE-BOUNDARY-START(141735493674),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "value",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Insert",
      "d": 1572906,
      "h": 141735493674,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141735493674),
//--TRIMMABLE-BOUNDARY-START(146030460970),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Insert",
      "o": "@$1",
      "d": 1572906,
      "h": 146030460970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146030460970),
//--TRIMMABLE-BOUNDARY-START(34361311274),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "Append",
      "o": "@$1",
      "d": 1572906,
      "h": 34361311274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361311274),
//--TRIMMABLE-BOUNDARY-START(42951245866),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "Append",
      "o": "@$3",
      "d": 1572906,
      "h": 42951245866,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951245866),
//--TRIMMABLE-BOUNDARY-START(47246213162),
    {
      "r": 65537,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "AppendSlow",
      "d": 1572906,
      "h": 47246213162,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47246213162),
//--TRIMMABLE-BOUNDARY-START(30066343978),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Append",
      "d": 1572906,
      "h": 30066343978,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066343978),
//--TRIMMABLE-BOUNDARY-START(38656278570),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Append",
      "o": "@$2",
      "d": 1572906,
      "h": 38656278570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38656278570),
//--TRIMMABLE-BOUNDARY-START(51541180458),
    {
      "r": $.$$.System.Span$$($.$$.System.Char).$h,
      "p": [
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "AppendSpan",
      "d": 1572906,
      "h": 51541180458,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541180458),
//--TRIMMABLE-BOUNDARY-START(137440526378),
    {
      "r": 65537,
      "p": [
        {
          "n": "c",
          "p": 458753
        }
      ],
      "n": "GrowAndAppend",
      "d": 1572906,
      "h": 137440526378,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(137440526378),
//--TRIMMABLE-BOUNDARY-START(133145559082),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalCapacityBeyondPos",
          "p": 655361
        }
      ],
      "n": "Grow",
      "d": 1572906,
      "h": 133145559082,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(133145559082),
//--TRIMMABLE-BOUNDARY-START(81605951530),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1572906,
      "h": 81605951530,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605951530)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540202),
    {
      "t": $.$typeArray($.$$.System.Char).$h,
      "n": "_arrayToReturnToPool",
      "d": 1572906,
      "h": 4296540202,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540202),
//--TRIMMABLE-BOUNDARY-START(8591507498),
    {
      "t": $.$$.System.Span$$($.$$.System.Char).$h,
      "n": "_chars",
      "d": 1572906,
      "h": 8591507498,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591507498),
//--TRIMMABLE-BOUNDARY-START(12886474794),
    {
      "t": 655361,
      "n": "_pos",
      "d": 1572906,
      "h": 12886474794,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886474794)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25771376682),
    {
      "p": [
        {
          "n": "initialBuffer",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1572906,
      "h": 25771376682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376682),
//--TRIMMABLE-BOUNDARY-START(21476409386),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572906,
      "h": 21476409386,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409386),
//--TRIMMABLE-BOUNDARY-START(17181442090),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1572906,
      "h": 17181442090,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442090)
  ],
  "h": 1572906
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572906)
        
        
        //--TRIMMABLE-BOUNDARY-START(852010)
        $asm.$str("$scsl.System.ConsoleKeyInfo", ($self) => class ConsoleKeyInfo extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590786602)
            /*char*/  get _keyChar() { return this.$getField(0, $.$$.System.Char); }
            /*char*/  set _keyChar(value) { this.$setField(0, $.$$.System.Char, value); }
            //--TRIMMABLE-BOUNDARY-END(8590786602)
            
            //--TRIMMABLE-BOUNDARY-START(4295819306)
            /*ConsoleKey*/  get _key() { return this.$getField(2, $.$scsl.System.ConsoleKey); }
            /*ConsoleKey*/  set _key(value) { this.$setField(2, $.$scsl.System.ConsoleKey, value); }
            //--TRIMMABLE-BOUNDARY-END(4295819306)
            
            //--TRIMMABLE-BOUNDARY-START(12885753898)
            /*ConsoleModifiers*/  get _mods() { return this.$getField(6, $.$scsl.System.ConsoleModifiers); }
            /*ConsoleModifiers*/  set _mods(value) { this.$setField(6, $.$scsl.System.ConsoleModifiers, value); }
            //--TRIMMABLE-BOUNDARY-END(12885753898)
            
            //--TRIMMABLE-BOUNDARY-START(21475688490)
            $ctor$3(/*char*/ keyChar, /*ConsoleKey*/ key, /*bool*/ shift, /*bool*/ alt, /*bool*/ control)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688490);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ((key) < 0 || (key) > 255)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("key", $.$scsl.System.SR.ArgumentOutOfRange_ConsoleKey);
                    }
                    this._keyChar = keyChar;
                    this._key = key;
                    this._mods = 0;
                    if (shift)
                    {
                        this._mods |= 2/*ConsoleModifiers.Shift*/;
                    }
                    if (alt)
                    {
                        this._mods |= 1/*ConsoleModifiers.Alt*/;
                    }
                    if (control)
                    {
                        this._mods |= 4/*ConsoleModifiers.Control*/;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688490)
            
            //--TRIMMABLE-BOUNDARY-START(68720328746)
            /*char */ get KeyChar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keyChar;
            }
            //--TRIMMABLE-BOUNDARY-END(68720328746)
            
            //--TRIMMABLE-BOUNDARY-START(64425361450)
            /*ConsoleKey */ get Key()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655557674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._key;
            }
            //--TRIMMABLE-BOUNDARY-END(64425361450)
            
            //--TRIMMABLE-BOUNDARY-START(73015296042)
            /*ConsoleModifiers */ get Modifiers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835426858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mods;
            }
            //--TRIMMABLE-BOUNDARY-END(73015296042)
            
            //--TRIMMABLE-BOUNDARY-START(25770655786)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770655786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let info;
                return $.$is(value, $.$scsl.System.ConsoleKeyInfo, { set $v(v){ info = v; } }) && this.Equals$2(info);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$scsl.System.ConsoleKeyInfo.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25770655786)
            
            //--TRIMMABLE-BOUNDARY-START(30065623082)
            /*bool */ Equals$2(/*ConsoleKeyInfo*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return obj._keyChar === this._keyChar && obj._key === this._key && obj._mods === this._mods;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623082)
            
            //--TRIMMABLE-BOUNDARY-START(77310263338)
            static /*bool */ op_Equality(/*ConsoleKeyInfo*/ a, /*ConsoleKeyInfo*/ b)
            {
                return a.Equals$2(b);
            }
            //--TRIMMABLE-BOUNDARY-END(77310263338)
            
            //--TRIMMABLE-BOUNDARY-START(81605230634)
            static /*bool */ op_Inequality(/*ConsoleKeyInfo*/ a, /*ConsoleKeyInfo*/ b)
            {
                return !($.$scsl.System.ConsoleKeyInfo.op_Equality(a, b));
            }
            //--TRIMMABLE-BOUNDARY-END(81605230634)
            
            //--TRIMMABLE-BOUNDARY-START(60130394154)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._keyChar | (this._key << 16) | (this._mods << 24);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scsl.System.ConsoleKeyInfo.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(60130394154)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.ConsoleKeyInfo>.Equals(System.ConsoleKeyInfo)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(17180721194)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721194)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._keyChar = this._keyChar;
                copy._key = this._key;
                copy._mods = this._mods;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590786602)
                this._keyChar = 0;
                //--TRIMMABLE-BOUNDARY-END(8590786602)
                
                //--TRIMMABLE-BOUNDARY-START(4295819306)
                this._key = 0;
                //--TRIMMABLE-BOUNDARY-END(4295819306)
                
                //--TRIMMABLE-BOUNDARY-START(12885753898)
                this._mods = 0;
                //--TRIMMABLE-BOUNDARY-END(12885753898)
                
            }
            static $h = 852010;
            static $z = 10;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720328746),
    {
      "p": 458753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245492266,
        "f": 50331649
      },
      "n": "KeyChar",
      "d": 852010,
      "h": 68720328746,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720328746),
//--TRIMMABLE-BOUNDARY-START(64425361450),
    {
      "p": 786474,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655557674,
        "f": 50331649
      },
      "n": "Key",
      "d": 852010,
      "h": 64425361450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425361450),
//--TRIMMABLE-BOUNDARY-START(73015296042),
    {
      "p": 917546,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835426858,
        "f": 50331649
      },
      "n": "Modifiers",
      "d": 852010,
      "h": 73015296042,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015296042)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770655786),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 852010,
      "h": 25770655786,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770655786),
//--TRIMMABLE-BOUNDARY-START(30065623082),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 852010
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 852010,
      "h": 30065623082,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623082),
//--TRIMMABLE-BOUNDARY-START(60130394154),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 852010,
      "h": 60130394154,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130394154)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590786602),
    {
      "t": 458753,
      "n": "_keyChar",
      "d": 852010,
      "h": 8590786602,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786602),
//--TRIMMABLE-BOUNDARY-START(4295819306),
    {
      "t": 786474,
      "n": "_key",
      "d": 852010,
      "h": 4295819306,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819306),
//--TRIMMABLE-BOUNDARY-START(12885753898),
    {
      "t": 917546,
      "n": "_mods",
      "d": 852010,
      "h": 12885753898,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753898)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475688490),
    {
      "p": [
        {
          "n": "keyChar",
          "p": 458753
        },
        {
          "n": "key",
          "p": 786474
        },
        {
          "n": "shift",
          "p": 262145
        },
        {
          "n": "alt",
          "p": 262145
        },
        {
          "n": "control",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852010,
      "h": 21475688490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688490),
//--TRIMMABLE-BOUNDARY-START(17180721194),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852010,
      "h": 17180721194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721194)
  ],
  "i": [$.$$.System.IEquatable$$($.$scsl.System.ConsoleKeyInfo).$h
  ],
  "h": 852010
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$scsl.System.ConsoleKeyInfo) ]; }
            static get $fullName() { return `System.ConsoleKeyInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852010)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441834)
        $asm.$cls("$scsl.System.Text.ConsoleEncoding", ($self) => class ConsoleEncoding extends $.$$.System.Text.Encoding
        {
            //--TRIMMABLE-BOUNDARY-START(4296409130)
            /*Encoding*/ _encoding = null;
            //--TRIMMABLE-BOUNDARY-END(4296409130)
            
            //--TRIMMABLE-BOUNDARY-START(8591376426)
            $ctor$4(/*Encoding*/ encoding)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376426);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._encoding = encoding;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376426)
            
            //--TRIMMABLE-BOUNDARY-START(146030329898)
            /*byte[] */ GetPreamble()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030329898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Array.Empty($.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(146030329898)
            
            //--TRIMMABLE-BOUNDARY-START(12886343722)
            /*int */ get CodePage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.CodePage;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343722)
            
            //--TRIMMABLE-BOUNDARY-START(158915231786)
            /*bool */ get IsSingleByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.IsSingleByte;
            }
            //--TRIMMABLE-BOUNDARY-END(158915231786)
            
            //--TRIMMABLE-BOUNDARY-START(17181311018)
            /*string */ get EncodingName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361180202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.EncodingName;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311018)
            
            //--TRIMMABLE-BOUNDARY-START(163210199082)
            /*string */ get WebName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.WebName;
            }
            //--TRIMMABLE-BOUNDARY-END(163210199082)
            
            //--TRIMMABLE-BOUNDARY-START(60130983978)
            /*int */ GetByteCount$1(/*char[]*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130983978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetByteCount$1(chars);
            }
            //--TRIMMABLE-BOUNDARY-END(60130983978)
            
            //--TRIMMABLE-BOUNDARY-START(64425951274)
            /*int */ GetByteCount$3(/*char**/ chars, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425951274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetByteCount$3(chars, count);
            }
            //--TRIMMABLE-BOUNDARY-END(64425951274)
            
            //--TRIMMABLE-BOUNDARY-START(55836016682)
            /*int */ GetByteCount(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836016682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetByteCount(chars, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(55836016682)
            
            //--TRIMMABLE-BOUNDARY-START(68720918570)
            /*int */ GetByteCount$6(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetByteCount$6(s);
            }
            //--TRIMMABLE-BOUNDARY-END(68720918570)
            
            //--TRIMMABLE-BOUNDARY-START(85900787754)
            /*int */ GetBytes$4(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes$4(chars, charCount, bytes, byteCount);
            }
            //--TRIMMABLE-BOUNDARY-END(85900787754)
            
            //--TRIMMABLE-BOUNDARY-START(81605820458)
            /*byte[] */ GetBytes$2(/*char[]*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605820458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes$2(chars);
            }
            //--TRIMMABLE-BOUNDARY-END(81605820458)
            
            //--TRIMMABLE-BOUNDARY-START(77310853162)
            /*byte[] */ GetBytes$1(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes$1(chars, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(77310853162)
            
            //--TRIMMABLE-BOUNDARY-START(73015885866)
            /*int */ GetBytes(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015885866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes(chars, charIndex, charCount, bytes, byteIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(73015885866)
            
            //--TRIMMABLE-BOUNDARY-START(94490722346)
            /*byte[] */ GetBytes$8(/*string*/ s)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490722346);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes$8(s);
            }
            //--TRIMMABLE-BOUNDARY-END(94490722346)
            
            //--TRIMMABLE-BOUNDARY-START(90195755050)
            /*int */ GetBytes$6(/*string*/ s, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195755050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetBytes$6(s, charIndex, charCount, bytes, byteIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(90195755050)
            
            //--TRIMMABLE-BOUNDARY-START(107375624234)
            /*int */ GetCharCount$3(/*byte**/ bytes, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375624234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetCharCount$3(bytes, count);
            }
            //--TRIMMABLE-BOUNDARY-END(107375624234)
            
            //--TRIMMABLE-BOUNDARY-START(103080656938)
            /*int */ GetCharCount$1(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080656938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetCharCount$1(bytes);
            }
            //--TRIMMABLE-BOUNDARY-END(103080656938)
            
            //--TRIMMABLE-BOUNDARY-START(98785689642)
            /*int */ GetCharCount(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785689642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetCharCount(bytes, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(98785689642)
            
            //--TRIMMABLE-BOUNDARY-START(124555493418)
            /*int */ GetChars$4(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555493418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetChars$4(bytes, byteCount, chars, charCount);
            }
            //--TRIMMABLE-BOUNDARY-END(124555493418)
            
            //--TRIMMABLE-BOUNDARY-START(120260526122)
            /*char[] */ GetChars$2(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260526122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetChars$2(bytes);
            }
            //--TRIMMABLE-BOUNDARY-END(120260526122)
            
            //--TRIMMABLE-BOUNDARY-START(115965558826)
            /*char[] */ GetChars$1(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965558826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetChars$1(bytes, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(115965558826)
            
            //--TRIMMABLE-BOUNDARY-START(111670591530)
            /*int */ GetChars(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670591530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetChars(bytes, byteIndex, byteCount, chars, charIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(111670591530)
            
            //--TRIMMABLE-BOUNDARY-START(128850460714)
            /*Decoder */ GetDecoder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850460714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetDecoder();
            }
            //--TRIMMABLE-BOUNDARY-END(128850460714)
            
            //--TRIMMABLE-BOUNDARY-START(133145428010)
            /*Encoder */ GetEncoder()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145428010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetEncoder();
            }
            //--TRIMMABLE-BOUNDARY-END(133145428010)
            
            //--TRIMMABLE-BOUNDARY-START(137440395306)
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440395306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetMaxByteCount(charCount);
            }
            //--TRIMMABLE-BOUNDARY-END(137440395306)
            
            //--TRIMMABLE-BOUNDARY-START(141735362602)
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735362602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetMaxCharCount(byteCount);
            }
            //--TRIMMABLE-BOUNDARY-END(141735362602)
            
            //--TRIMMABLE-BOUNDARY-START(154620264490)
            /*string */ GetString$1(/*byte[]*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620264490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetString$1(bytes);
            }
            //--TRIMMABLE-BOUNDARY-END(154620264490)
            
            //--TRIMMABLE-BOUNDARY-START(150325297194)
            /*string */ GetString(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325297194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._encoding.GetString(bytes, index, count);
            }
            //--TRIMMABLE-BOUNDARY-END(150325297194)
            
            static $h = 1441834;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 165937153,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12886343722),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771245610,
        "f": 50364417
      },
      "n": "CodePage",
      "d": 1441834,
      "h": 12886343722,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12886343722),
//--TRIMMABLE-BOUNDARY-START(158915231786),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951114794,
        "f": 50364417
      },
      "n": "IsSingleByte",
      "d": 1441834,
      "h": 158915231786,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(158915231786),
//--TRIMMABLE-BOUNDARY-START(17181311018),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361180202,
        "f": 50364417
      },
      "n": "EncodingName",
      "d": 1441834,
      "h": 17181311018,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17181311018),
//--TRIMMABLE-BOUNDARY-START(163210199082),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541049386,
        "f": 50364417
      },
      "n": "WebName",
      "d": 1441834,
      "h": 163210199082,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163210199082)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146030329898),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "n": "GetPreamble",
      "d": 1441834,
      "h": 146030329898,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146030329898),
//--TRIMMABLE-BOUNDARY-START(60130983978),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        }
      ],
      "n": "GetByteCount",
      "o": "@$1",
      "d": 1441834,
      "h": 60130983978,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130983978),
//--TRIMMABLE-BOUNDARY-START(64425951274),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "o": "@$3",
      "d": 1441834,
      "h": 64425951274,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425951274),
//--TRIMMABLE-BOUNDARY-START(55836016682),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetByteCount",
      "d": 1441834,
      "h": 55836016682,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55836016682),
//--TRIMMABLE-BOUNDARY-START(68720918570),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetByteCount",
      "o": "@$6",
      "d": 1441834,
      "h": 68720918570,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720918570),
//--TRIMMABLE-BOUNDARY-START(85900787754),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$4",
      "d": 1441834,
      "h": 85900787754,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(85900787754),
//--TRIMMABLE-BOUNDARY-START(81605820458),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        }
      ],
      "n": "GetBytes",
      "o": "@$2",
      "d": 1441834,
      "h": 81605820458,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605820458),
//--TRIMMABLE-BOUNDARY-START(77310853162),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$1",
      "d": 1441834,
      "h": 77310853162,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310853162),
//--TRIMMABLE-BOUNDARY-START(73015885866),
    {
      "r": 655361,
      "p": [
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "d": 1441834,
      "h": 73015885866,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015885866),
//--TRIMMABLE-BOUNDARY-START(94490722346),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "s",
          "p": 1310721
        }
      ],
      "n": "GetBytes",
      "o": "@$8",
      "d": 1441834,
      "h": 94490722346,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490722346),
//--TRIMMABLE-BOUNDARY-START(90195755050),
    {
      "r": 655361,
      "p": [
        {
          "n": "s",
          "p": 1310721
        },
        {
          "n": "charIndex",
          "p": 655361
        },
        {
          "n": "charCount",
          "p": 655361
        },
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        }
      ],
      "n": "GetBytes",
      "o": "@$6",
      "d": 1441834,
      "h": 90195755050,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(90195755050),
//--TRIMMABLE-BOUNDARY-START(107375624234),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "o": "@$3",
      "d": 1441834,
      "h": 107375624234,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(107375624234),
//--TRIMMABLE-BOUNDARY-START(103080656938),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "GetCharCount",
      "o": "@$1",
      "d": 1441834,
      "h": 103080656938,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(103080656938),
//--TRIMMABLE-BOUNDARY-START(98785689642),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetCharCount",
      "d": 1441834,
      "h": 98785689642,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(98785689642),
//--TRIMMABLE-BOUNDARY-START(124555493418),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typePointer($.$$.System.Char).$h
        },
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$4",
      "d": 1441834,
      "h": 124555493418,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555493418),
//--TRIMMABLE-BOUNDARY-START(120260526122),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "GetChars",
      "o": "@$2",
      "d": 1441834,
      "h": 120260526122,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(120260526122),
//--TRIMMABLE-BOUNDARY-START(115965558826),
    {
      "r": $.$typeArray($.$$.System.Char).$h,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "o": "@$1",
      "d": 1441834,
      "h": 115965558826,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115965558826),
//--TRIMMABLE-BOUNDARY-START(111670591530),
    {
      "r": 655361,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "byteIndex",
          "p": 655361
        },
        {
          "n": "byteCount",
          "p": 655361
        },
        {
          "n": "chars",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "charIndex",
          "p": 655361
        }
      ],
      "n": "GetChars",
      "d": 1441834,
      "h": 111670591530,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111670591530),
//--TRIMMABLE-BOUNDARY-START(128850460714),
    {
      "r": 164626433,
      "n": "GetDecoder",
      "d": 1441834,
      "h": 128850460714,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850460714),
//--TRIMMABLE-BOUNDARY-START(133145428010),
    {
      "r": 165216257,
      "n": "GetEncoder",
      "d": 1441834,
      "h": 133145428010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133145428010),
//--TRIMMABLE-BOUNDARY-START(137440395306),
    {
      "r": 655361,
      "p": [
        {
          "n": "charCount",
          "p": 655361
        }
      ],
      "n": "GetMaxByteCount",
      "d": 1441834,
      "h": 137440395306,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(137440395306),
//--TRIMMABLE-BOUNDARY-START(141735362602),
    {
      "r": 655361,
      "p": [
        {
          "n": "byteCount",
          "p": 655361
        }
      ],
      "n": "GetMaxCharCount",
      "d": 1441834,
      "h": 141735362602,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141735362602),
//--TRIMMABLE-BOUNDARY-START(154620264490),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "GetString",
      "o": "@$1",
      "d": 1441834,
      "h": 154620264490,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154620264490),
//--TRIMMABLE-BOUNDARY-START(150325297194),
    {
      "r": 1310721,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "GetString",
      "d": 1441834,
      "h": 150325297194,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150325297194)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296409130),
    {
      "t": 165937153,
      "n": "_encoding",
      "d": 1441834,
      "h": 4296409130,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296409130)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591376426),
    {
      "p": [
        {
          "n": "encoding",
          "p": 165937153
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1441834,
      "h": 8591376426,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591376426)
  ],
  "i": [89980929
  ],
  "h": 1441834
}; }
            static get $b() { return $.$$.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable ]; }
            static get $fullName() { return `System.Text.ConsoleEncoding`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441834)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310762)
        $asm.$cls("$scsl.System.IO.SyncTextReader", ($self) => class SyncTextReader extends $.$$.System.IO.TextReader
        {
            //--TRIMMABLE-BOUNDARY-START(4296278058)
            /*TextReader*/ _in = null;
            //--TRIMMABLE-BOUNDARY-END(4296278058)
            
            //--TRIMMABLE-BOUNDARY-START(17181179946)
            static /*SyncTextReader */ GetSynchronizedTextReader(/*TextReader*/ reader)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(reader !== null, "reader != null");
                return $.$as(reader, $.$scsl.System.IO.SyncTextReader) ?? new $.$scsl.System.IO.SyncTextReader().$ctor$3(reader);
            }
            //--TRIMMABLE-BOUNDARY-END(17181179946)
            
            //--TRIMMABLE-BOUNDARY-START(8591245354)
            $ctor$3(/*TextReader*/ t)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591245354);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._in = t;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245354)
            
            //--TRIMMABLE-BOUNDARY-START(12886212650)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            this._in.Dispose();
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886212650)
            
            //--TRIMMABLE-BOUNDARY-START(21476147242)
            /*int */ Peek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.Peek();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476147242)
            
            //--TRIMMABLE-BOUNDARY-START(25771114538)
            /*int */ Read()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.Read();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771114538)
            
            //--TRIMMABLE-BOUNDARY-START(30066081834)
            /*int */ Read$1(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.Read$1(buffer, index, count);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066081834)
            
            //--TRIMMABLE-BOUNDARY-START(38656016426)
            /*int */ ReadBlock(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.ReadBlock(buffer, index, count);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016426)
            
            //--TRIMMABLE-BOUNDARY-START(47245951018)
            /*string? */ ReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245951018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.ReadLine();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245951018)
            
            //--TRIMMABLE-BOUNDARY-START(60130852906)
            /*string */ ReadToEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130852906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this)
                    {
                        return this._in.ReadToEnd();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130852906)
            
            //--TRIMMABLE-BOUNDARY-START(51540918314)
            /*Task<string?> */ ReadLineAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.String, this.ReadLine());
            }
            //--TRIMMABLE-BOUNDARY-END(51540918314)
            
            //--TRIMMABLE-BOUNDARY-START(55835885610)
            /*ValueTask<string?> */ ReadLineAsync$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835885610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return cancellationToken.IsCancellationRequested ? $.$$.System.Threading.Tasks.ValueTask.FromCanceled$1($.$$.System.String, cancellationToken) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String))().$ctor$6(this.ReadLine());
            }
            //--TRIMMABLE-BOUNDARY-END(55835885610)
            
            //--TRIMMABLE-BOUNDARY-START(64425820202)
            /*Task<string> */ ReadToEndAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425820202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.String, this.ReadToEnd());
            }
            //--TRIMMABLE-BOUNDARY-END(64425820202)
            
            //--TRIMMABLE-BOUNDARY-START(68720787498)
            /*Task<string> */ ReadToEndAsync$1(/*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return cancellationToken.IsCancellationRequested ? $.$$.System.Threading.Tasks.Task.FromCanceled$3($.$$.System.String, cancellationToken) : $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.String, this.ReadToEnd());
            }
            //--TRIMMABLE-BOUNDARY-END(68720787498)
            
            //--TRIMMABLE-BOUNDARY-START(42950983722)
            /*Task<int> */ ReadBlockAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                if (((buffer.length - index) | 0) < count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scsl.System.SR.Argument_InvalidOffLen);
                }
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Int32, this.ReadBlock(buffer, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(42950983722)
            
            //--TRIMMABLE-BOUNDARY-START(34361049130)
            /*Task<int> */ ReadAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(buffer, "buffer");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, count, "count");
                if (((buffer.length - index) | 0) < count)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$scsl.System.SR.Argument_InvalidOffLen);
                }
                return $.$$.System.Threading.Tasks.Task.FromResult($.$$.System.Int32, this.Read$1(buffer, index, count));
            }
            //--TRIMMABLE-BOUNDARY-END(34361049130)
            
            static $h = 1310762;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 95682561,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181179946),
    {
      "r": 1310762,
      "p": [
        {
          "n": "reader",
          "p": 95682561
        }
      ],
      "n": "GetSynchronizedTextReader",
      "d": 1310762,
      "h": 17181179946,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181179946),
//--TRIMMABLE-BOUNDARY-START(12886212650),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1310762,
      "h": 12886212650,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886212650),
//--TRIMMABLE-BOUNDARY-START(21476147242),
    {
      "r": 655361,
      "n": "Peek",
      "d": 1310762,
      "h": 21476147242,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476147242),
//--TRIMMABLE-BOUNDARY-START(25771114538),
    {
      "r": 655361,
      "n": "Read",
      "d": 1310762,
      "h": 25771114538,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771114538),
//--TRIMMABLE-BOUNDARY-START(30066081834),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 1310762,
      "h": 30066081834,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066081834),
//--TRIMMABLE-BOUNDARY-START(38656016426),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ReadBlock",
      "d": 1310762,
      "h": 38656016426,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38656016426),
//--TRIMMABLE-BOUNDARY-START(47245951018),
    {
      "r": 1310721,
      "n": "ReadLine",
      "d": 1310762,
      "h": 47245951018,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245951018),
//--TRIMMABLE-BOUNDARY-START(60130852906),
    {
      "r": 1310721,
      "n": "ReadToEnd",
      "d": 1310762,
      "h": 60130852906,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130852906),
//--TRIMMABLE-BOUNDARY-START(51540918314),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "n": "ReadLineAsync",
      "d": 1310762,
      "h": 51540918314,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540918314),
//--TRIMMABLE-BOUNDARY-START(55835885610),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.String).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadLineAsync",
      "o": "@$1",
      "d": 1310762,
      "h": 55835885610,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835885610),
//--TRIMMABLE-BOUNDARY-START(64425820202),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "n": "ReadToEndAsync",
      "d": 1310762,
      "h": 64425820202,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425820202),
//--TRIMMABLE-BOUNDARY-START(68720787498),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.String).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170065921
        }
      ],
      "n": "ReadToEndAsync",
      "o": "@$1",
      "d": 1310762,
      "h": 68720787498,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720787498),
//--TRIMMABLE-BOUNDARY-START(42950983722),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ReadBlockAsync",
      "d": 1310762,
      "h": 42950983722,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950983722),
//--TRIMMABLE-BOUNDARY-START(34361049130),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Char).$h
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "ReadAsync",
      "d": 1310762,
      "h": 34361049130,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361049130)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296278058),
    {
      "t": 95682561,
      "n": "_in",
      "d": 1310762,
      "h": 4296278058,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4296278058)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591245354),
    {
      "p": [
        {
          "n": "t",
          "p": 95682561
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310762,
      "h": 8591245354,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591245354)
  ],
  "i": [90308609
  ],
  "h": 1310762
}; }
            static get $b() { return $.$$.System.IO.TextReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.IO.SyncTextReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310762)
        
        
        //--TRIMMABLE-BOUNDARY-START(655402)
        $asm.$cls("$scsl.System.ConsoleCancelEventHandler", ($self) => class ConsoleCancelEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /**/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 655402;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524586),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 589866
        }
      ],
      "n": "Invoke",
      "d": 655402,
      "h": 17180524586,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180524586),
//--TRIMMABLE-BOUNDARY-START(8590589994),
    {
      "r": 89784321,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 589866
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 655402,
      "h": 8590589994,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590589994),
//--TRIMMABLE-BOUNDARY-START(12885557290),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 655402,
      "h": 12885557290,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885557290)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622698),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655402,
      "h": 4295622698,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622698)
  ],
  "i": [89980929,157483009
  ],
  "h": 655402
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ConsoleCancelEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655402)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048618)
        $asm.$str("$scsl.System.ConsoleSpecialKey", ($self) => class ConsoleSpecialKey extends $.$$.System.Enum
        {
            static ControlC = 0;
            static ControlBreak = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ControlC": 0n,
                    "ControlBreak": 1n
                };
            }
            static $h = 1048618;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885950506),
    {
      "t": 1048618,
      "n": "ControlC",
      "d": 1048618,
      "h": 12885950506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950506),
//--TRIMMABLE-BOUNDARY-START(8590983210),
    {
      "t": 1048618,
      "n": "ControlBreak",
      "d": 1048618,
      "h": 8590983210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983210)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015914),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048618,
      "h": 4296015914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015914)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1048618
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleSpecialKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048618)
        
        
        //--TRIMMABLE-BOUNDARY-START(720938)
        $asm.$str("$scsl.System.ConsoleColor", ($self) => class ConsoleColor extends $.$$.System.Enum
        {
            static Black = 0;
            static DarkBlue = 1;
            static DarkGreen = 2;
            static DarkCyan = 3;
            static DarkRed = 4;
            static DarkMagenta = 5;
            static DarkYellow = 6;
            static Gray = 7;
            static DarkGray = 8;
            static Blue = 9;
            static Green = 10;
            static Cyan = 11;
            static Red = 12;
            static Magenta = 13;
            static Yellow = 14;
            static White = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Black": 0n,
                    "DarkBlue": 1n,
                    "DarkGreen": 2n,
                    "DarkCyan": 3n,
                    "DarkRed": 4n,
                    "DarkMagenta": 5n,
                    "DarkYellow": 6n,
                    "Gray": 7n,
                    "DarkGray": 8n,
                    "Blue": 9n,
                    "Green": 10n,
                    "Cyan": 11n,
                    "Red": 12n,
                    "Magenta": 13n,
                    "Yellow": 14n,
                    "White": 15n
                };
            }
            static $h = 720938;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590655530),
    {
      "t": 720938,
      "n": "Black",
      "d": 720938,
      "h": 8590655530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655530),
//--TRIMMABLE-BOUNDARY-START(21475557418),
    {
      "t": 720938,
      "n": "DarkBlue",
      "d": 720938,
      "h": 21475557418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557418),
//--TRIMMABLE-BOUNDARY-START(34360459306),
    {
      "t": 720938,
      "n": "DarkGreen",
      "d": 720938,
      "h": 34360459306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459306),
//--TRIMMABLE-BOUNDARY-START(25770524714),
    {
      "t": 720938,
      "n": "DarkCyan",
      "d": 720938,
      "h": 25770524714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524714),
//--TRIMMABLE-BOUNDARY-START(42950393898),
    {
      "t": 720938,
      "n": "DarkRed",
      "d": 720938,
      "h": 42950393898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950393898),
//--TRIMMABLE-BOUNDARY-START(38655426602),
    {
      "t": 720938,
      "n": "DarkMagenta",
      "d": 720938,
      "h": 38655426602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426602),
//--TRIMMABLE-BOUNDARY-START(47245361194),
    {
      "t": 720938,
      "n": "DarkYellow",
      "d": 720938,
      "h": 47245361194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361194),
//--TRIMMABLE-BOUNDARY-START(51540328490),
    {
      "t": 720938,
      "n": "Gray",
      "d": 720938,
      "h": 51540328490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328490),
//--TRIMMABLE-BOUNDARY-START(30065492010),
    {
      "t": 720938,
      "n": "DarkGray",
      "d": 720938,
      "h": 30065492010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492010),
//--TRIMMABLE-BOUNDARY-START(12885622826),
    {
      "t": 720938,
      "n": "Blue",
      "d": 720938,
      "h": 12885622826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622826),
//--TRIMMABLE-BOUNDARY-START(55835295786),
    {
      "t": 720938,
      "n": "Green",
      "d": 720938,
      "h": 55835295786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835295786),
//--TRIMMABLE-BOUNDARY-START(17180590122),
    {
      "t": 720938,
      "n": "Cyan",
      "d": 720938,
      "h": 17180590122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590122),
//--TRIMMABLE-BOUNDARY-START(64425230378),
    {
      "t": 720938,
      "n": "Red",
      "d": 720938,
      "h": 64425230378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425230378),
//--TRIMMABLE-BOUNDARY-START(60130263082),
    {
      "t": 720938,
      "n": "Magenta",
      "d": 720938,
      "h": 60130263082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130263082),
//--TRIMMABLE-BOUNDARY-START(73015164970),
    {
      "t": 720938,
      "n": "Yellow",
      "d": 720938,
      "h": 73015164970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015164970),
//--TRIMMABLE-BOUNDARY-START(68720197674),
    {
      "t": 720938,
      "n": "White",
      "d": 720938,
      "h": 68720197674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720197674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688234),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720938,
      "h": 4295688234,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688234)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 720938
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleColor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720938)
        
        
        //--TRIMMABLE-BOUNDARY-START(786474)
        $asm.$str("$scsl.System.ConsoleKey", ($self) => class ConsoleKey extends $.$$.System.Enum
        {
            static None = 0;
            static Backspace = 8;
            static Tab = 9;
            static Clear = 12;
            static Enter = 13;
            static Pause = 19;
            static Escape = 27;
            static Spacebar = 32;
            static PageUp = 33;
            static PageDown = 34;
            static End = 35;
            static Home = 36;
            static LeftArrow = 37;
            static UpArrow = 38;
            static RightArrow = 39;
            static DownArrow = 40;
            static Select = 41;
            static Print = 42;
            static Execute = 43;
            static PrintScreen = 44;
            static Insert = 45;
            static Delete = 46;
            static Help = 47;
            static D0 = 48;
            static D1 = 49;
            static D2 = 50;
            static D3 = 51;
            static D4 = 52;
            static D5 = 53;
            static D6 = 54;
            static D7 = 55;
            static D8 = 56;
            static D9 = 57;
            static A = 65;
            static B = 66;
            static C = 67;
            static D = 68;
            static E = 69;
            static F = 70;
            static G = 71;
            static H = 72;
            static I = 73;
            static J = 74;
            static K = 75;
            static L = 76;
            static M = 77;
            static N = 78;
            static O = 79;
            static P = 80;
            static Q = 81;
            static R = 82;
            static S = 83;
            static T = 84;
            static U = 85;
            static V = 86;
            static W = 87;
            static X = 88;
            static Y = 89;
            static Z = 90;
            static LeftWindows = 91;
            static RightWindows = 92;
            static Applications = 93;
            static Sleep = 95;
            static NumPad0 = 96;
            static NumPad1 = 97;
            static NumPad2 = 98;
            static NumPad3 = 99;
            static NumPad4 = 100;
            static NumPad5 = 101;
            static NumPad6 = 102;
            static NumPad7 = 103;
            static NumPad8 = 104;
            static NumPad9 = 105;
            static Multiply = 106;
            static Add = 107;
            static Separator = 108;
            static Subtract = 109;
            static Decimal = 110;
            static Divide = 111;
            static F1 = 112;
            static F2 = 113;
            static F3 = 114;
            static F4 = 115;
            static F5 = 116;
            static F6 = 117;
            static F7 = 118;
            static F8 = 119;
            static F9 = 120;
            static F10 = 121;
            static F11 = 122;
            static F12 = 123;
            static F13 = 124;
            static F14 = 125;
            static F15 = 126;
            static F16 = 127;
            static F17 = 128;
            static F18 = 129;
            static F19 = 130;
            static F20 = 131;
            static F21 = 132;
            static F22 = 133;
            static F23 = 134;
            static F24 = 135;
            static BrowserBack = 166;
            static BrowserForward = 167;
            static BrowserRefresh = 168;
            static BrowserStop = 169;
            static BrowserSearch = 170;
            static BrowserFavorites = 171;
            static BrowserHome = 172;
            static VolumeMute = 173;
            static VolumeDown = 174;
            static VolumeUp = 175;
            static MediaNext = 176;
            static MediaPrevious = 177;
            static MediaStop = 178;
            static MediaPlay = 179;
            static LaunchMail = 180;
            static LaunchMediaSelect = 181;
            static LaunchApp1 = 182;
            static LaunchApp2 = 183;
            static Oem1 = 186;
            static OemPlus = 187;
            static OemComma = 188;
            static OemMinus = 189;
            static OemPeriod = 190;
            static Oem2 = 191;
            static Oem3 = 192;
            static Oem4 = 219;
            static Oem5 = 220;
            static Oem6 = 221;
            static Oem7 = 222;
            static Oem8 = 223;
            static Oem102 = 226;
            static Process = 229;
            static Packet = 231;
            static Attention = 246;
            static CrSel = 247;
            static ExSel = 248;
            static EraseEndOfFile = 249;
            static Play = 250;
            static Zoom = 251;
            static NoName = 252;
            static Pa1 = 253;
            static OemClear = 254;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Backspace": 8n,
                    "Tab": 9n,
                    "Clear": 12n,
                    "Enter": 13n,
                    "Pause": 19n,
                    "Escape": 27n,
                    "Spacebar": 32n,
                    "PageUp": 33n,
                    "PageDown": 34n,
                    "End": 35n,
                    "Home": 36n,
                    "LeftArrow": 37n,
                    "UpArrow": 38n,
                    "RightArrow": 39n,
                    "DownArrow": 40n,
                    "Select": 41n,
                    "Print": 42n,
                    "Execute": 43n,
                    "PrintScreen": 44n,
                    "Insert": 45n,
                    "Delete": 46n,
                    "Help": 47n,
                    "D0": 48n,
                    "D1": 49n,
                    "D2": 50n,
                    "D3": 51n,
                    "D4": 52n,
                    "D5": 53n,
                    "D6": 54n,
                    "D7": 55n,
                    "D8": 56n,
                    "D9": 57n,
                    "A": 65n,
                    "B": 66n,
                    "C": 67n,
                    "D": 68n,
                    "E": 69n,
                    "F": 70n,
                    "G": 71n,
                    "H": 72n,
                    "I": 73n,
                    "J": 74n,
                    "K": 75n,
                    "L": 76n,
                    "M": 77n,
                    "N": 78n,
                    "O": 79n,
                    "P": 80n,
                    "Q": 81n,
                    "R": 82n,
                    "S": 83n,
                    "T": 84n,
                    "U": 85n,
                    "V": 86n,
                    "W": 87n,
                    "X": 88n,
                    "Y": 89n,
                    "Z": 90n,
                    "LeftWindows": 91n,
                    "RightWindows": 92n,
                    "Applications": 93n,
                    "Sleep": 95n,
                    "NumPad0": 96n,
                    "NumPad1": 97n,
                    "NumPad2": 98n,
                    "NumPad3": 99n,
                    "NumPad4": 100n,
                    "NumPad5": 101n,
                    "NumPad6": 102n,
                    "NumPad7": 103n,
                    "NumPad8": 104n,
                    "NumPad9": 105n,
                    "Multiply": 106n,
                    "Add": 107n,
                    "Separator": 108n,
                    "Subtract": 109n,
                    "Decimal": 110n,
                    "Divide": 111n,
                    "F1": 112n,
                    "F2": 113n,
                    "F3": 114n,
                    "F4": 115n,
                    "F5": 116n,
                    "F6": 117n,
                    "F7": 118n,
                    "F8": 119n,
                    "F9": 120n,
                    "F10": 121n,
                    "F11": 122n,
                    "F12": 123n,
                    "F13": 124n,
                    "F14": 125n,
                    "F15": 126n,
                    "F16": 127n,
                    "F17": 128n,
                    "F18": 129n,
                    "F19": 130n,
                    "F20": 131n,
                    "F21": 132n,
                    "F22": 133n,
                    "F23": 134n,
                    "F24": 135n,
                    "BrowserBack": 166n,
                    "BrowserForward": 167n,
                    "BrowserRefresh": 168n,
                    "BrowserStop": 169n,
                    "BrowserSearch": 170n,
                    "BrowserFavorites": 171n,
                    "BrowserHome": 172n,
                    "VolumeMute": 173n,
                    "VolumeDown": 174n,
                    "VolumeUp": 175n,
                    "MediaNext": 176n,
                    "MediaPrevious": 177n,
                    "MediaStop": 178n,
                    "MediaPlay": 179n,
                    "LaunchMail": 180n,
                    "LaunchMediaSelect": 181n,
                    "LaunchApp1": 182n,
                    "LaunchApp2": 183n,
                    "Oem1": 186n,
                    "OemPlus": 187n,
                    "OemComma": 188n,
                    "OemMinus": 189n,
                    "OemPeriod": 190n,
                    "Oem2": 191n,
                    "Oem3": 192n,
                    "Oem4": 219n,
                    "Oem5": 220n,
                    "Oem6": 221n,
                    "Oem7": 222n,
                    "Oem8": 223n,
                    "Oem102": 226n,
                    "Process": 229n,
                    "Packet": 231n,
                    "Attention": 246n,
                    "CrSel": 247n,
                    "ExSel": 248n,
                    "EraseEndOfFile": 249n,
                    "Play": 250n,
                    "Zoom": 251n,
                    "NoName": 252n,
                    "Pa1": 253n,
                    "OemClear": 254n
                };
            }
            static $h = 786474;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(377957908522),
    {
      "t": 786474,
      "n": "None",
      "d": 786474,
      "h": 377957908522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377957908522),
//--TRIMMABLE-BOUNDARY-START(30065557546),
    {
      "t": 786474,
      "n": "Backspace",
      "d": 786474,
      "h": 30065557546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065557546),
//--TRIMMABLE-BOUNDARY-START(579821371434),
    {
      "t": 786474,
      "n": "Tab",
      "d": 786474,
      "h": 579821371434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(579821371434),
//--TRIMMABLE-BOUNDARY-START(68720263210),
    {
      "t": 786474,
      "n": "Clear",
      "d": 786474,
      "h": 68720263210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720263210),
//--TRIMMABLE-BOUNDARY-START(150324641834),
    {
      "t": 786474,
      "n": "Enter",
      "d": 786474,
      "h": 150324641834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324641834),
//--TRIMMABLE-BOUNDARY-START(511101894698),
    {
      "t": 786474,
      "n": "Pause",
      "d": 786474,
      "h": 511101894698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(511101894698),
//--TRIMMABLE-BOUNDARY-START(158914576426),
    {
      "t": 786474,
      "n": "Escape",
      "d": 786474,
      "h": 158914576426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914576426),
//--TRIMMABLE-BOUNDARY-START(566936469546),
    {
      "t": 786474,
      "n": "Spacebar",
      "d": 786474,
      "h": 566936469546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(566936469546),
//--TRIMMABLE-BOUNDARY-START(506806927402),
    {
      "t": 786474,
      "n": "PageUp",
      "d": 786474,
      "h": 506806927402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(506806927402),
//--TRIMMABLE-BOUNDARY-START(502511960106),
    {
      "t": 786474,
      "n": "PageDown",
      "d": 786474,
      "h": 502511960106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(502511960106),
//--TRIMMABLE-BOUNDARY-START(146029674538),
    {
      "t": 786474,
      "n": "End",
      "d": 786474,
      "h": 146029674538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029674538),
//--TRIMMABLE-BOUNDARY-START(292058562602),
    {
      "t": 786474,
      "n": "Home",
      "d": 786474,
      "h": 292058562602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058562602),
//--TRIMMABLE-BOUNDARY-START(335008235562),
    {
      "t": 786474,
      "n": "LeftArrow",
      "d": 786474,
      "h": 335008235562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335008235562),
//--TRIMMABLE-BOUNDARY-START(588411306026),
    {
      "t": 786474,
      "n": "UpArrow",
      "d": 786474,
      "h": 588411306026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(588411306026),
//--TRIMMABLE-BOUNDARY-START(541166665770),
    {
      "t": 786474,
      "n": "RightArrow",
      "d": 786474,
      "h": 541166665770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(541166665770),
//--TRIMMABLE-BOUNDARY-START(137439739946),
    {
      "t": 786474,
      "n": "DownArrow",
      "d": 786474,
      "h": 137439739946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439739946),
//--TRIMMABLE-BOUNDARY-START(554051567658),
    {
      "t": 786474,
      "n": "Select",
      "d": 786474,
      "h": 554051567658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(554051567658),
//--TRIMMABLE-BOUNDARY-START(519691829290),
    {
      "t": 786474,
      "n": "Print",
      "d": 786474,
      "h": 519691829290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(519691829290),
//--TRIMMABLE-BOUNDARY-START(163209543722),
    {
      "t": 786474,
      "n": "Execute",
      "d": 786474,
      "h": 163209543722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209543722),
//--TRIMMABLE-BOUNDARY-START(523986796586),
    {
      "t": 786474,
      "n": "PrintScreen",
      "d": 786474,
      "h": 523986796586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(523986796586),
//--TRIMMABLE-BOUNDARY-START(300648497194),
    {
      "t": 786474,
      "n": "Insert",
      "d": 786474,
      "h": 300648497194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300648497194),
//--TRIMMABLE-BOUNDARY-START(128849805354),
    {
      "t": 786474,
      "n": "Delete",
      "d": 786474,
      "h": 128849805354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849805354),
//--TRIMMABLE-BOUNDARY-START(287763595306),
    {
      "t": 786474,
      "n": "Help",
      "d": 786474,
      "h": 287763595306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763595306),
//--TRIMMABLE-BOUNDARY-START(81605165098),
    {
      "t": 786474,
      "n": "D0",
      "d": 786474,
      "h": 81605165098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605165098),
//--TRIMMABLE-BOUNDARY-START(85900132394),
    {
      "t": 786474,
      "n": "D1",
      "d": 786474,
      "h": 85900132394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900132394),
//--TRIMMABLE-BOUNDARY-START(90195099690),
    {
      "t": 786474,
      "n": "D2",
      "d": 786474,
      "h": 90195099690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195099690),
//--TRIMMABLE-BOUNDARY-START(94490066986),
    {
      "t": 786474,
      "n": "D3",
      "d": 786474,
      "h": 94490066986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490066986),
//--TRIMMABLE-BOUNDARY-START(98785034282),
    {
      "t": 786474,
      "n": "D4",
      "d": 786474,
      "h": 98785034282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785034282),
//--TRIMMABLE-BOUNDARY-START(103080001578),
    {
      "t": 786474,
      "n": "D5",
      "d": 786474,
      "h": 103080001578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080001578),
//--TRIMMABLE-BOUNDARY-START(107374968874),
    {
      "t": 786474,
      "n": "D6",
      "d": 786474,
      "h": 107374968874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374968874),
//--TRIMMABLE-BOUNDARY-START(111669936170),
    {
      "t": 786474,
      "n": "D7",
      "d": 786474,
      "h": 111669936170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669936170),
//--TRIMMABLE-BOUNDARY-START(115964903466),
    {
      "t": 786474,
      "n": "D8",
      "d": 786474,
      "h": 115964903466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964903466),
//--TRIMMABLE-BOUNDARY-START(120259870762),
    {
      "t": 786474,
      "n": "D9",
      "d": 786474,
      "h": 120259870762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259870762),
//--TRIMMABLE-BOUNDARY-START(8590721066),
    {
      "t": 786474,
      "n": "A",
      "d": 786474,
      "h": 8590721066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721066),
//--TRIMMABLE-BOUNDARY-START(25770590250),
    {
      "t": 786474,
      "n": "B",
      "d": 786474,
      "h": 25770590250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770590250),
//--TRIMMABLE-BOUNDARY-START(64425295914),
    {
      "t": 786474,
      "n": "C",
      "d": 786474,
      "h": 64425295914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425295914),
//--TRIMMABLE-BOUNDARY-START(77310197802),
    {
      "t": 786474,
      "n": "D",
      "d": 786474,
      "h": 77310197802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310197802),
//--TRIMMABLE-BOUNDARY-START(141734707242),
    {
      "t": 786474,
      "n": "E",
      "d": 786474,
      "h": 141734707242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734707242),
//--TRIMMABLE-BOUNDARY-START(171799478314),
    {
      "t": 786474,
      "n": "F",
      "d": 786474,
      "h": 171799478314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799478314),
//--TRIMMABLE-BOUNDARY-START(279173660714),
    {
      "t": 786474,
      "n": "G",
      "d": 786474,
      "h": 279173660714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173660714),
//--TRIMMABLE-BOUNDARY-START(283468628010),
    {
      "t": 786474,
      "n": "H",
      "d": 786474,
      "h": 283468628010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468628010),
//--TRIMMABLE-BOUNDARY-START(296353529898),
    {
      "t": 786474,
      "n": "I",
      "d": 786474,
      "h": 296353529898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296353529898),
//--TRIMMABLE-BOUNDARY-START(304943464490),
    {
      "t": 786474,
      "n": "J",
      "d": 786474,
      "h": 304943464490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304943464490),
//--TRIMMABLE-BOUNDARY-START(309238431786),
    {
      "t": 786474,
      "n": "K",
      "d": 786474,
      "h": 309238431786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309238431786),
//--TRIMMABLE-BOUNDARY-START(313533399082),
    {
      "t": 786474,
      "n": "L",
      "d": 786474,
      "h": 313533399082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313533399082),
//--TRIMMABLE-BOUNDARY-START(343598170154),
    {
      "t": 786474,
      "n": "M",
      "d": 786474,
      "h": 343598170154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343598170154),
//--TRIMMABLE-BOUNDARY-START(369367973930),
    {
      "t": 786474,
      "n": "N",
      "d": 786474,
      "h": 369367973930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367973930),
//--TRIMMABLE-BOUNDARY-START(425202548778),
    {
      "t": 786474,
      "n": "O",
      "d": 786474,
      "h": 425202548778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(425202548778),
//--TRIMMABLE-BOUNDARY-START(489627058218),
    {
      "t": 786474,
      "n": "P",
      "d": 786474,
      "h": 489627058218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(489627058218),
//--TRIMMABLE-BOUNDARY-START(532576731178),
    {
      "t": 786474,
      "n": "Q",
      "d": 786474,
      "h": 532576731178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(532576731178),
//--TRIMMABLE-BOUNDARY-START(536871698474),
    {
      "t": 786474,
      "n": "R",
      "d": 786474,
      "h": 536871698474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(536871698474),
//--TRIMMABLE-BOUNDARY-START(549756600362),
    {
      "t": 786474,
      "n": "S",
      "d": 786474,
      "h": 549756600362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(549756600362),
//--TRIMMABLE-BOUNDARY-START(575526404138),
    {
      "t": 786474,
      "n": "T",
      "d": 786474,
      "h": 575526404138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(575526404138),
//--TRIMMABLE-BOUNDARY-START(584116338730),
    {
      "t": 786474,
      "n": "U",
      "d": 786474,
      "h": 584116338730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(584116338730),
//--TRIMMABLE-BOUNDARY-START(592706273322),
    {
      "t": 786474,
      "n": "V",
      "d": 786474,
      "h": 592706273322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(592706273322),
//--TRIMMABLE-BOUNDARY-START(609886142506),
    {
      "t": 786474,
      "n": "W",
      "d": 786474,
      "h": 609886142506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(609886142506),
//--TRIMMABLE-BOUNDARY-START(614181109802),
    {
      "t": 786474,
      "n": "X",
      "d": 786474,
      "h": 614181109802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(614181109802),
//--TRIMMABLE-BOUNDARY-START(618476077098),
    {
      "t": 786474,
      "n": "Y",
      "d": 786474,
      "h": 618476077098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(618476077098),
//--TRIMMABLE-BOUNDARY-START(622771044394),
    {
      "t": 786474,
      "n": "Z",
      "d": 786474,
      "h": 622771044394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(622771044394),
//--TRIMMABLE-BOUNDARY-START(339303202858),
    {
      "t": 786474,
      "n": "LeftWindows",
      "d": 786474,
      "h": 339303202858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339303202858),
//--TRIMMABLE-BOUNDARY-START(545461633066),
    {
      "t": 786474,
      "n": "RightWindows",
      "d": 786474,
      "h": 545461633066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(545461633066),
//--TRIMMABLE-BOUNDARY-START(17180655658),
    {
      "t": 786474,
      "n": "Applications",
      "d": 786474,
      "h": 17180655658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655658),
//--TRIMMABLE-BOUNDARY-START(562641502250),
    {
      "t": 786474,
      "n": "Sleep",
      "d": 786474,
      "h": 562641502250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(562641502250),
//--TRIMMABLE-BOUNDARY-START(382252875818),
    {
      "t": 786474,
      "n": "NumPad0",
      "d": 786474,
      "h": 382252875818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382252875818),
//--TRIMMABLE-BOUNDARY-START(386547843114),
    {
      "t": 786474,
      "n": "NumPad1",
      "d": 786474,
      "h": 386547843114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386547843114),
//--TRIMMABLE-BOUNDARY-START(390842810410),
    {
      "t": 786474,
      "n": "NumPad2",
      "d": 786474,
      "h": 390842810410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390842810410),
//--TRIMMABLE-BOUNDARY-START(395137777706),
    {
      "t": 786474,
      "n": "NumPad3",
      "d": 786474,
      "h": 395137777706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395137777706),
//--TRIMMABLE-BOUNDARY-START(399432745002),
    {
      "t": 786474,
      "n": "NumPad4",
      "d": 786474,
      "h": 399432745002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399432745002),
//--TRIMMABLE-BOUNDARY-START(403727712298),
    {
      "t": 786474,
      "n": "NumPad5",
      "d": 786474,
      "h": 403727712298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403727712298),
//--TRIMMABLE-BOUNDARY-START(408022679594),
    {
      "t": 786474,
      "n": "NumPad6",
      "d": 786474,
      "h": 408022679594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408022679594),
//--TRIMMABLE-BOUNDARY-START(412317646890),
    {
      "t": 786474,
      "n": "NumPad7",
      "d": 786474,
      "h": 412317646890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412317646890),
//--TRIMMABLE-BOUNDARY-START(416612614186),
    {
      "t": 786474,
      "n": "NumPad8",
      "d": 786474,
      "h": 416612614186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416612614186),
//--TRIMMABLE-BOUNDARY-START(420907581482),
    {
      "t": 786474,
      "n": "NumPad9",
      "d": 786474,
      "h": 420907581482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(420907581482),
//--TRIMMABLE-BOUNDARY-START(365073006634),
    {
      "t": 786474,
      "n": "Multiply",
      "d": 786474,
      "h": 365073006634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365073006634),
//--TRIMMABLE-BOUNDARY-START(12885688362),
    {
      "t": 786474,
      "n": "Add",
      "d": 786474,
      "h": 12885688362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688362),
//--TRIMMABLE-BOUNDARY-START(558346534954),
    {
      "t": 786474,
      "n": "Separator",
      "d": 786474,
      "h": 558346534954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(558346534954),
//--TRIMMABLE-BOUNDARY-START(571231436842),
    {
      "t": 786474,
      "n": "Subtract",
      "d": 786474,
      "h": 571231436842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(571231436842),
//--TRIMMABLE-BOUNDARY-START(124554838058),
    {
      "t": 786474,
      "n": "Decimal",
      "d": 786474,
      "h": 124554838058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554838058),
//--TRIMMABLE-BOUNDARY-START(133144772650),
    {
      "t": 786474,
      "n": "Divide",
      "d": 786474,
      "h": 133144772650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144772650),
//--TRIMMABLE-BOUNDARY-START(176094445610),
    {
      "t": 786474,
      "n": "F1",
      "d": 786474,
      "h": 176094445610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094445610),
//--TRIMMABLE-BOUNDARY-START(223339085866),
    {
      "t": 786474,
      "n": "F2",
      "d": 786474,
      "h": 223339085866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223339085866),
//--TRIMMABLE-BOUNDARY-START(249108889642),
    {
      "t": 786474,
      "n": "F3",
      "d": 786474,
      "h": 249108889642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108889642),
//--TRIMMABLE-BOUNDARY-START(253403856938),
    {
      "t": 786474,
      "n": "F4",
      "d": 786474,
      "h": 253403856938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403856938),
//--TRIMMABLE-BOUNDARY-START(257698824234),
    {
      "t": 786474,
      "n": "F5",
      "d": 786474,
      "h": 257698824234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698824234),
//--TRIMMABLE-BOUNDARY-START(261993791530),
    {
      "t": 786474,
      "n": "F6",
      "d": 786474,
      "h": 261993791530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993791530),
//--TRIMMABLE-BOUNDARY-START(266288758826),
    {
      "t": 786474,
      "n": "F7",
      "d": 786474,
      "h": 266288758826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288758826),
//--TRIMMABLE-BOUNDARY-START(270583726122),
    {
      "t": 786474,
      "n": "F8",
      "d": 786474,
      "h": 270583726122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583726122),
//--TRIMMABLE-BOUNDARY-START(274878693418),
    {
      "t": 786474,
      "n": "F9",
      "d": 786474,
      "h": 274878693418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878693418),
//--TRIMMABLE-BOUNDARY-START(180389412906),
    {
      "t": 786474,
      "n": "F10",
      "d": 786474,
      "h": 180389412906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389412906),
//--TRIMMABLE-BOUNDARY-START(184684380202),
    {
      "t": 786474,
      "n": "F11",
      "d": 786474,
      "h": 184684380202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684380202),
//--TRIMMABLE-BOUNDARY-START(188979347498),
    {
      "t": 786474,
      "n": "F12",
      "d": 786474,
      "h": 188979347498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979347498),
//--TRIMMABLE-BOUNDARY-START(193274314794),
    {
      "t": 786474,
      "n": "F13",
      "d": 786474,
      "h": 193274314794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274314794),
//--TRIMMABLE-BOUNDARY-START(197569282090),
    {
      "t": 786474,
      "n": "F14",
      "d": 786474,
      "h": 197569282090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569282090),
//--TRIMMABLE-BOUNDARY-START(201864249386),
    {
      "t": 786474,
      "n": "F15",
      "d": 786474,
      "h": 201864249386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864249386),
//--TRIMMABLE-BOUNDARY-START(206159216682),
    {
      "t": 786474,
      "n": "F16",
      "d": 786474,
      "h": 206159216682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159216682),
//--TRIMMABLE-BOUNDARY-START(210454183978),
    {
      "t": 786474,
      "n": "F17",
      "d": 786474,
      "h": 210454183978,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454183978),
//--TRIMMABLE-BOUNDARY-START(214749151274),
    {
      "t": 786474,
      "n": "F18",
      "d": 786474,
      "h": 214749151274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749151274),
//--TRIMMABLE-BOUNDARY-START(219044118570),
    {
      "t": 786474,
      "n": "F19",
      "d": 786474,
      "h": 219044118570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044118570),
//--TRIMMABLE-BOUNDARY-START(227634053162),
    {
      "t": 786474,
      "n": "F20",
      "d": 786474,
      "h": 227634053162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634053162),
//--TRIMMABLE-BOUNDARY-START(231929020458),
    {
      "t": 786474,
      "n": "F21",
      "d": 786474,
      "h": 231929020458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231929020458),
//--TRIMMABLE-BOUNDARY-START(236223987754),
    {
      "t": 786474,
      "n": "F22",
      "d": 786474,
      "h": 236223987754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223987754),
//--TRIMMABLE-BOUNDARY-START(240518955050),
    {
      "t": 786474,
      "n": "F23",
      "d": 786474,
      "h": 240518955050,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518955050),
//--TRIMMABLE-BOUNDARY-START(244813922346),
    {
      "t": 786474,
      "n": "F24",
      "d": 786474,
      "h": 244813922346,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813922346),
//--TRIMMABLE-BOUNDARY-START(34360524842),
    {
      "t": 786474,
      "n": "BrowserBack",
      "d": 786474,
      "h": 34360524842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524842),
//--TRIMMABLE-BOUNDARY-START(42950459434),
    {
      "t": 786474,
      "n": "BrowserForward",
      "d": 786474,
      "h": 42950459434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950459434),
//--TRIMMABLE-BOUNDARY-START(51540394026),
    {
      "t": 786474,
      "n": "BrowserRefresh",
      "d": 786474,
      "h": 51540394026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540394026),
//--TRIMMABLE-BOUNDARY-START(60130328618),
    {
      "t": 786474,
      "n": "BrowserStop",
      "d": 786474,
      "h": 60130328618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130328618),
//--TRIMMABLE-BOUNDARY-START(55835361322),
    {
      "t": 786474,
      "n": "BrowserSearch",
      "d": 786474,
      "h": 55835361322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835361322),
//--TRIMMABLE-BOUNDARY-START(38655492138),
    {
      "t": 786474,
      "n": "BrowserFavorites",
      "d": 786474,
      "h": 38655492138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655492138),
//--TRIMMABLE-BOUNDARY-START(47245426730),
    {
      "t": 786474,
      "n": "BrowserHome",
      "d": 786474,
      "h": 47245426730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245426730),
//--TRIMMABLE-BOUNDARY-START(601296207914),
    {
      "t": 786474,
      "n": "VolumeMute",
      "d": 786474,
      "h": 601296207914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(601296207914),
//--TRIMMABLE-BOUNDARY-START(597001240618),
    {
      "t": 786474,
      "n": "VolumeDown",
      "d": 786474,
      "h": 597001240618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(597001240618),
//--TRIMMABLE-BOUNDARY-START(605591175210),
    {
      "t": 786474,
      "n": "VolumeUp",
      "d": 786474,
      "h": 605591175210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(605591175210),
//--TRIMMABLE-BOUNDARY-START(347893137450),
    {
      "t": 786474,
      "n": "MediaNext",
      "d": 786474,
      "h": 347893137450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347893137450),
//--TRIMMABLE-BOUNDARY-START(356483072042),
    {
      "t": 786474,
      "n": "MediaPrevious",
      "d": 786474,
      "h": 356483072042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356483072042),
//--TRIMMABLE-BOUNDARY-START(360778039338),
    {
      "t": 786474,
      "n": "MediaStop",
      "d": 786474,
      "h": 360778039338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360778039338),
//--TRIMMABLE-BOUNDARY-START(352188104746),
    {
      "t": 786474,
      "n": "MediaPlay",
      "d": 786474,
      "h": 352188104746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352188104746),
//--TRIMMABLE-BOUNDARY-START(326418300970),
    {
      "t": 786474,
      "n": "LaunchMail",
      "d": 786474,
      "h": 326418300970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326418300970),
//--TRIMMABLE-BOUNDARY-START(330713268266),
    {
      "t": 786474,
      "n": "LaunchMediaSelect",
      "d": 786474,
      "h": 330713268266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330713268266),
//--TRIMMABLE-BOUNDARY-START(317828366378),
    {
      "t": 786474,
      "n": "LaunchApp1",
      "d": 786474,
      "h": 317828366378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317828366378),
//--TRIMMABLE-BOUNDARY-START(322123333674),
    {
      "t": 786474,
      "n": "LaunchApp2",
      "d": 786474,
      "h": 322123333674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322123333674),
//--TRIMMABLE-BOUNDARY-START(429497516074),
    {
      "t": 786474,
      "n": "Oem1",
      "d": 786474,
      "h": 429497516074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(429497516074),
//--TRIMMABLE-BOUNDARY-START(485332090922),
    {
      "t": 786474,
      "n": "OemPlus",
      "d": 786474,
      "h": 485332090922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(485332090922),
//--TRIMMABLE-BOUNDARY-START(472447189034),
    {
      "t": 786474,
      "n": "OemComma",
      "d": 786474,
      "h": 472447189034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(472447189034),
//--TRIMMABLE-BOUNDARY-START(476742156330),
    {
      "t": 786474,
      "n": "OemMinus",
      "d": 786474,
      "h": 476742156330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(476742156330),
//--TRIMMABLE-BOUNDARY-START(481037123626),
    {
      "t": 786474,
      "n": "OemPeriod",
      "d": 786474,
      "h": 481037123626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(481037123626),
//--TRIMMABLE-BOUNDARY-START(438087450666),
    {
      "t": 786474,
      "n": "Oem2",
      "d": 786474,
      "h": 438087450666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(438087450666),
//--TRIMMABLE-BOUNDARY-START(442382417962),
    {
      "t": 786474,
      "n": "Oem3",
      "d": 786474,
      "h": 442382417962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(442382417962),
//--TRIMMABLE-BOUNDARY-START(446677385258),
    {
      "t": 786474,
      "n": "Oem4",
      "d": 786474,
      "h": 446677385258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(446677385258),
//--TRIMMABLE-BOUNDARY-START(450972352554),
    {
      "t": 786474,
      "n": "Oem5",
      "d": 786474,
      "h": 450972352554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(450972352554),
//--TRIMMABLE-BOUNDARY-START(455267319850),
    {
      "t": 786474,
      "n": "Oem6",
      "d": 786474,
      "h": 455267319850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(455267319850),
//--TRIMMABLE-BOUNDARY-START(459562287146),
    {
      "t": 786474,
      "n": "Oem7",
      "d": 786474,
      "h": 459562287146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(459562287146),
//--TRIMMABLE-BOUNDARY-START(463857254442),
    {
      "t": 786474,
      "n": "Oem8",
      "d": 786474,
      "h": 463857254442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(463857254442),
//--TRIMMABLE-BOUNDARY-START(433792483370),
    {
      "t": 786474,
      "n": "Oem102",
      "d": 786474,
      "h": 433792483370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(433792483370),
//--TRIMMABLE-BOUNDARY-START(528281763882),
    {
      "t": 786474,
      "n": "Process",
      "d": 786474,
      "h": 528281763882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(528281763882),
//--TRIMMABLE-BOUNDARY-START(498216992810),
    {
      "t": 786474,
      "n": "Packet",
      "d": 786474,
      "h": 498216992810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(498216992810),
//--TRIMMABLE-BOUNDARY-START(21475622954),
    {
      "t": 786474,
      "n": "Attention",
      "d": 786474,
      "h": 21475622954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622954),
//--TRIMMABLE-BOUNDARY-START(73015230506),
    {
      "t": 786474,
      "n": "CrSel",
      "d": 786474,
      "h": 73015230506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015230506),
//--TRIMMABLE-BOUNDARY-START(167504511018),
    {
      "t": 786474,
      "n": "ExSel",
      "d": 786474,
      "h": 167504511018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504511018),
//--TRIMMABLE-BOUNDARY-START(154619609130),
    {
      "t": 786474,
      "n": "EraseEndOfFile",
      "d": 786474,
      "h": 154619609130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619609130),
//--TRIMMABLE-BOUNDARY-START(515396861994),
    {
      "t": 786474,
      "n": "Play",
      "d": 786474,
      "h": 515396861994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(515396861994),
//--TRIMMABLE-BOUNDARY-START(627066011690),
    {
      "t": 786474,
      "n": "Zoom",
      "d": 786474,
      "h": 627066011690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(627066011690),
//--TRIMMABLE-BOUNDARY-START(373662941226),
    {
      "t": 786474,
      "n": "NoName",
      "d": 786474,
      "h": 373662941226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373662941226),
//--TRIMMABLE-BOUNDARY-START(493922025514),
    {
      "t": 786474,
      "n": "Pa1",
      "d": 786474,
      "h": 493922025514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(493922025514),
//--TRIMMABLE-BOUNDARY-START(468152221738),
    {
      "t": 786474,
      "n": "OemClear",
      "d": 786474,
      "h": 468152221738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(468152221738)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753770),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786474,
      "h": 4295753770,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753770)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 786474
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleKey`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786474)
        
        
        //--TRIMMABLE-BOUNDARY-START(917546)
        $asm.$str("$scsl.System.ConsoleModifiers", ($self) => class ConsoleModifiers extends $.$$.System.Enum
        {
            static None = 0;
            static Alt = 1;
            static Shift = 2;
            static Control = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Alt": 1n,
                    "Shift": 2n,
                    "Control": 4n
                };
            }
            static $h = 917546;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786730),
    {
      "t": 917546,
      "n": "None",
      "d": 917546,
      "h": 17180786730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786730),
//--TRIMMABLE-BOUNDARY-START(8590852138),
    {
      "t": 917546,
      "n": "Alt",
      "d": 917546,
      "h": 8590852138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852138),
//--TRIMMABLE-BOUNDARY-START(21475754026),
    {
      "t": 917546,
      "n": "Shift",
      "d": 917546,
      "h": 21475754026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754026),
//--TRIMMABLE-BOUNDARY-START(12885819434),
    {
      "t": 917546,
      "n": "Control",
      "d": 917546,
      "h": 12885819434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819434)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884842),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917546,
      "h": 4295884842,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884842)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 917546,
  "a": [
    {
      "t": 80478209,
      "c": 4375445505
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleModifiers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917546)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638442)
        $asm.$cls("$scsl.System.WasmConsoleStream", ($self) => class WasmConsoleStream extends $.$scsl.System.IO.ConsoleStream
        {
            //--TRIMMABLE-BOUNDARY-START(4296605738)
            /*SafeFileHandle*/ _handle = null;
            //--TRIMMABLE-BOUNDARY-END(4296605738)
            
            //--TRIMMABLE-BOUNDARY-START(8591573034)
            $ctor$4(/*SafeFileHandle*/ handle, /*FileAccess*/ access)
            {
                super.$ctor$3(access);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573034);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._handle = handle;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573034)
            
            //--TRIMMABLE-BOUNDARY-START(12886540330)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (disposing)
                {
                    this._handle.Dispose();
                }
                super.Dispose$1(disposing);
            }
            //--TRIMMABLE-BOUNDARY-END(12886540330)
            
            //--TRIMMABLE-BOUNDARY-START(21476474922)
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476474922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$scsl.System.IO.Error.GetReadNotSupported();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476474922)
            
            //--TRIMMABLE-BOUNDARY-START(30066409514)
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066409514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = buffer.GetPinnableReference();
                    $.$scsl.System.WasmConsoleStream.Write$2(this._handle, bufPtr, buffer.Length);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066409514)
            
            //--TRIMMABLE-BOUNDARY-START(25771442218)
            static /*void */ Write$2(/*SafeFileHandle*/ fd, /*byte**/ bufPtr, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                while(count > 0)
                {
                    /*int*/ let bytesWritten = $.$scsl.Interop.Sys.Write$1(fd, bufPtr, count);
                    if (bytesWritten < 0)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$scsl.Interop.Sys.GetLastErrorInfo();
                        if (errorInfo.Error === 65603/*Interop.Error.EPIPE*/)
                        {
                            return;
                        }
                        else 
                        {
                            throw $.$scsl.Interop.GetIOException(errorInfo.Clone(), null);
                        }
                    }
                    count -= bytesWritten;
                    bufPtr = bufPtr.Add(bytesWritten);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771442218)
            
            //--TRIMMABLE-BOUNDARY-START(17181507626)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181507626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._handle.IsClosed)
                {
                    throw $.$scsl.System.IO.Error.GetFileNotOpen();
                }
                super.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(17181507626)
            
            static $h = 1638442;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1179690,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886540330),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1638442,
      "h": 12886540330,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(12886540330),
//--TRIMMABLE-BOUNDARY-START(21476474922),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 1638442,
      "h": 21476474922,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476474922),
//--TRIMMABLE-BOUNDARY-START(30066409514),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1638442,
      "h": 30066409514,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30066409514),
//--TRIMMABLE-BOUNDARY-START(25771442218),
    {
      "r": 65537,
      "p": [
        {
          "n": "fd",
          "p": 7733249
        },
        {
          "n": "bufPtr",
          "p": $.$typePointer($.$$.System.Byte).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 1638442,
      "h": 25771442218,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771442218),
//--TRIMMABLE-BOUNDARY-START(17181507626),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1638442,
      "h": 17181507626,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181507626)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296605738),
    {
      "t": 7733249,
      "n": "_handle",
      "d": 1638442,
      "h": 4296605738,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296605738)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591573034),
    {
      "p": [
        {
          "n": "handle",
          "p": 7733249
        },
        {
          "n": "access",
          "p": 92536833
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1638442,
      "h": 8591573034,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591573034)
  ],
  "i": [90308609,89718785
  ],
  "h": 1638442
}; }
            static get $b() { return $.$scsl.System.IO.ConsoleStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.WasmConsoleStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638442)
        
        
        //--TRIMMABLE-BOUNDARY-START(589866)
        $asm.$cls("$scsl.System.ConsoleCancelEventArgs", ($self) => class ConsoleCancelEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295557162)
            /*ConsoleSpecialKey*/ _type = 0;
            //--TRIMMABLE-BOUNDARY-END(4295557162)
            
            //--TRIMMABLE-BOUNDARY-START(12885491754)
            $ctor$2(/*ConsoleSpecialKey*/ type)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491754);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._type = type;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491754)
            
            //--TRIMMABLE-BOUNDARY-START(17180459050)
            /*bool*/ Cancel = false;
            //--TRIMMABLE-BOUNDARY-END(17180459050)
            
            //--TRIMMABLE-BOUNDARY-START(47245230122)
            /*ConsoleSpecialKey */ get SpecialKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230122)
            
            static $h = 589866;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79757313,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180459050),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770393642,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950262826,
        "f": 83886081
      },
      "n": "Cancel",
      "d": 589866,
      "h": 17180459050,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180459050),
//--TRIMMABLE-BOUNDARY-START(47245230122),
    {
      "p": 1048618,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328234,
        "f": 50331649
      },
      "n": "SpecialKey",
      "d": 589866,
      "h": 47245230122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295557162),
    {
      "t": 1048618,
      "n": "_type",
      "d": 589866,
      "h": 4295557162,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557162)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491754),
    {
      "p": [
        {
          "n": "type",
          "p": 1048618
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589866,
      "h": 12885491754,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885491754)
  ],
  "h": 589866
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.ConsoleCancelEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589866)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions"))
//--TRIMMABLE-BOUNDARY-END(42)
