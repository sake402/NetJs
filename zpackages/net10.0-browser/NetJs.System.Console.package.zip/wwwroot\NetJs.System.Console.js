
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $stee, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Console", 
    {"h":41,"f":"System.Console","v":"1.0.35.0","a":[{"t":90374145,"c":4385341441},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Console","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Console","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$scsl.System.IO.ConsoleStream", ($self) => class ConsoleStream extends $.$spc.System.IO.Stream
        {
            /*bool*/ _canRead = false;
            /*bool*/ _canWrite = false;
            $ctor$3(/*FileAccess*/ access)
            {
                super.$ctor$2();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(access === 1/*FileAccess.Read*/ || access === 2/*FileAccess.Write*/, "access == FileAccess.Read || access == FileAccess.Write");
                    this._canRead = ((access & 1/*FileAccess.Read*/) === 1/*FileAccess.Read*/);
                    this._canWrite = ((access & 2/*FileAccess.Write*/) === 2/*FileAccess.Write*/);
                }
                return this;
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ValidateWrite(buffer, offset, count);
                this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*void */ WriteByte(/*byte*/ value)
            {
                return this.Write$1(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$5($.$ref(() => value, undefined, $.$spc.System.Byte)));
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                this.ValidateRead(buffer, offset, count);
                return this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$3(buffer, offset, count));
            }
            /*int */ ReadByte()
            {
                /*byte*/ let b = 0;
                /*int*/ let result = this.Read$1(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$5($.$ref(() => b, ($v) => b = $v, $.$spc.System.Byte)));
                return result !== 0 ? b : -1;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                this._canRead = false;
                this._canWrite = false;
                super.Dispose$1(disposing);
            }
            /*bool */ get CanRead()
            {
                return this._canRead;
            }
            /*bool */ get CanWrite()
            {
                return this._canWrite;
            }
            /*bool */ get CanSeek()
            {
                return false;
            }
            /*long */ get Length()
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*long */ get Position()
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*long */ set Position(value)
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*void */ Flush()
            {
            }
            /*void */ SetLength(/*long*/ value)
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                throw $.$scsl.System.IO.Error.GetSeekNotSupported();
            }
            /*void */ ValidateRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (!this._canRead)
                {
                    throw $.$scsl.System.IO.Error.GetReadNotSupported();
                }
            }
            /*void */ ValidateWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                $.$spc.System.IO.Stream.ValidateBufferArguments(buffer, offset, count);
                if (!this._canWrite)
                {
                    throw $.$scsl.System.IO.Error.GetWriteNotSupported();
                }
            }
            static $h = 1179689;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":42950852649,"f":98305},"n":"CanRead","d":1179689,"h":38655885353,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":51540787241,"f":98305},"n":"CanWrite","d":1179689,"h":47245819945,"f":98305},{"p":262145,"g":{"r":0,"d":0,"h":60130721833,"f":98305},"n":"CanSeek","d":1179689,"h":55835754537,"f":98305},{"p":917505,"g":{"r":0,"d":0,"h":68720656425,"f":98305},"n":"Length","d":1179689,"h":64425689129,"f":98305},{"p":917505,"g":{"r":0,"d":0,"h":77310591017,"f":98305},"s":{"r":0,"d":0,"h":81605558313,"f":98305},"n":"Position","d":1179689,"h":73015623721,"f":98305}],"m":[{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1179689,"h":17181048873,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1179689,"h":21476016169,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1179689,"h":25770983465,"f":32769},{"r":655361,"n":"ReadByte","d":1179689,"h":30065950761,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1179689,"h":34360918057,"f":32772},{"r":65537,"n":"Flush","d":1179689,"h":85900525609,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1179689,"h":90195492905,"f":98305},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1179689,"h":94490460201,"f":98305},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ValidateRead","d":1179689,"h":98785427497,"f":4},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"ValidateWrite","d":1179689,"h":103080394793,"f":4}],"l":[{"t":262145,"n":"_canRead","d":1179689,"h":4296146985,"f":2},{"t":262145,"n":"_canWrite","d":1179689,"h":8591114281,"f":2}],"c":[{"p":[{"n":"access","p":59703297}],"n":".ctor","o":"$ctor$3","d":1179689,"h":12886081577,"f":8}],"i":[57475073,56885249],"h":1179689}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.ConsoleStream`; }
        });
        
        $asm.$cls("$scsl.System.IO.CachedConsoleStream", ($self) => class CachedConsoleStream extends $.$scsl.System.IO.ConsoleStream
        {
            /*StringBuilder*/ _buffer = null;
            /*Encoding*/ _encoding = null;
            /*Decoder*/ _decoder = null;
            $ctor$4(/*Encoding*/ encoding)
            {
                super.$ctor$3(2/*FileAccess.Write*/);
                {
                    this._encoding = encoding;
                    this._decoder = this._encoding.GetDecoder();
                }
                return this;
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                throw $.$scsl.System.IO.Error.GetReadNotSupported();
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*int*/ let maxCharCount = this._encoding.GetMaxCharCount(buffer.Length);
                /*char[]?*/ let pooledBuffer = null;
                /*Span<char>*/ let charSpan = (maxCharCount >>> 0) <= 512 ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512, null) : ($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(pooledBuffer = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(maxCharCount)));
                try
                {
                    /*int*/ let count = this._decoder.GetChars$3(buffer, charSpan, false);
                    if (count > 0)
                    {
                        $.$scsl.System.IO.CachedConsoleStream.WriteOrCache(this, this._buffer, charSpan.Slice$1(0, count));
                    }
                }
                finally
                {
                    {
                        if (pooledBuffer !== null)
                        {
                            $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(pooledBuffer, false);
                        }
                    }
                }
            }
            static /*void */ WriteOrCache(/*CachedConsoleStream*/ stream, /*StringBuilder*/ cache, /*Span<char>*/ charBuffer)
            {
                /*int*/ let lastNewLine = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(charBuffer), /*\n*/ 10);
                if (lastNewLine !== -1)
                {
                    /*Span<char>*/ let lineSpan = charBuffer.Slice$1(0, lastNewLine);
                    if (cache.Length > 0)
                    {
                        stream.Print($.$spc.System.String.op_Implicit($.$spc.System.Text.StringBuilder.ToString.call(cache.Append$21($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(lineSpan)))));
                        cache.Clear();
                    }
                    else 
                    {
                        stream.Print($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(lineSpan));
                    }
                    if (((lastNewLine + 1) | 0) < charBuffer.Length)
                    {
                        cache.Append$21($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(charBuffer.Slice(((lastNewLine + 1) | 0))));
                    }
                    return;
                }
                cache.Append$21($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(charBuffer));
            }
            //default member initializer
            constructor()
            {
                super();
                this._buffer = new $.$spc.System.Text.StringBuilder().$ctor$1();
            }
            static $h = 1114153;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1179689,"m":[{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1114153,"h":21475950633,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1114153,"h":25770917929,"f":32769},{"r":65537,"p":[{"n":"line","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Print","d":1114153,"h":30065885225,"f":260},{"r":65537,"p":[{"n":"stream","p":1114153},{"n":"cache","p":122945537},{"n":"charBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":"WriteOrCache","d":1114153,"h":34360852521,"f":34}],"l":[{"t":122945537,"n":"_buffer","d":1114153,"h":4296081449,"f":2},{"t":121831425,"n":"_encoding","d":1114153,"h":8591048745,"f":2},{"t":120520705,"n":"_decoder","d":1114153,"h":12886016041,"f":2}],"c":[{"p":[{"n":"encoding","p":121831425}],"n":".ctor","o":"$ctor$4","d":1114153,"h":17180983337,"f":1}],"i":[57475073,56885249],"h":1114153}; }
            static get $b() { return $.$scsl.System.IO.ConsoleStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.IO.CachedConsoleStream`; }
        });
        
        $asm.$cls("$scsl.System.Console", ($self) => class Console
        {
            /*int*/ static ReadBufferSize = 4096;
            /*int*/ static WriteBufferSize = 256;
            /*object*/ static s_syncObject = null;
            /*TextReader?*/ static s_in = null;
            /*TextWriter?*/ static s_out = null;
            /*TextWriter?*/ static s_error = null;
            /*Encoding?*/ static s_inputEncoding = null;
            /*Encoding?*/ static s_outputEncoding = null;
            /*bool*/ static s_isOutTextWriterRedirected = false;
            /*bool*/ static s_isErrorTextWriterRedirected = false;
            /*ConsoleCancelEventHandler?*/ static s_cancelCallbacks = null;
            /*PosixSignalRegistration?*/ static s_sigIntRegistration = null;
            /*PosixSignalRegistration?*/ static s_sigQuitRegistration = null;
            static /*TextReader */ get In()
            {
                return $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$spc.System.IO.TextReader).$v ?? EnsureInitialized();
                /*static TextReader*/  function EnsureInitialized()
                {
                    $.$scsl.System.ConsolePal.EnsureConsoleInitialized();
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_in === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$spc.System.IO.TextReader).$v = $.$scsl.System.ConsolePal.GetOrCreateReader();
                            }
                            return $.$scsl.System.Console.s_in;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            static /*Encoding */ get InputEncoding()
            {
                /*Encoding?*/ let encoding = $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$spc.System.Text.Encoding).$v;
                if (encoding === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_inputEncoding === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$spc.System.Text.Encoding).$v = $.$scsl.System.ConsolePal.InputEncoding;
                            }
                            encoding = $.$scsl.System.Console.s_inputEncoding;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
                return encoding;
            }
            static /*Encoding */ set InputEncoding(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.ConsolePal.SetConsoleInputEncoding(value);
                        $.$ref(() => $.$scsl.System.Console.s_inputEncoding, ($v) => $.$scsl.System.Console.s_inputEncoding = $v, $.$spc.System.Text.Encoding).$v = $.$cast(value.Clone(), $.$spc.System.Text.Encoding);
                        $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$spc.System.IO.TextReader).$v = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*Encoding */ get OutputEncoding()
            {
                /*Encoding?*/ let encoding = $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$spc.System.Text.Encoding).$v;
                if (encoding === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_outputEncoding === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$spc.System.Text.Encoding).$v = $.$scsl.System.ConsolePal.OutputEncoding;
                            }
                            encoding = $.$scsl.System.Console.s_outputEncoding;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
                return encoding;
            }
            static /*Encoding */ set OutputEncoding(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.ConsolePal.SetConsoleOutputEncoding(value);
                        if ($.$scsl.System.Console.s_out !== null && !$.$scsl.System.Console.s_isOutTextWriterRedirected)
                        {
                            $.$scsl.System.Console.s_out.Flush();
                            $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$spc.System.IO.TextWriter).$v = null;
                        }
                        if ($.$scsl.System.Console.s_error !== null && !$.$scsl.System.Console.s_isErrorTextWriterRedirected)
                        {
                            $.$scsl.System.Console.s_error.Flush();
                            $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$spc.System.IO.TextWriter).$v = null;
                        }
                        $.$ref(() => $.$scsl.System.Console.s_outputEncoding, ($v) => $.$scsl.System.Console.s_outputEncoding = $v, $.$spc.System.Text.Encoding).$v = $.$cast(value.Clone(), $.$spc.System.Text.Encoding);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*bool */ get KeyAvailable()
            {
                if ($.$scsl.System.Console.IsInputRedirected)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$scsl.System.SR.InvalidOperation_ConsoleKeyAvailableOnFile);
                }
                return $.$scsl.System.ConsolePal.KeyAvailable;
            }
            static /*ConsoleKeyInfo */ ReadKey()
            {
                return $.$scsl.System.ConsolePal.ReadKey(false);
            }
            static /*ConsoleKeyInfo */ ReadKey$1(/*bool*/ intercept)
            {
                return $.$scsl.System.ConsolePal.ReadKey(intercept);
            }
            static /*TextWriter */ get Out()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.Threading.Monitor.IsEntered($.$scsl.System.Console.s_syncObject), "!Monitor.IsEntered(s_syncObject)");
                return $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$spc.System.IO.TextWriter).$v ?? EnsureInitialized();
                /*static TextWriter*/  function EnsureInitialized()
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_out === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$spc.System.IO.TextWriter).$v = $.$scsl.System.Console.CreateOutputWriter($.$scsl.System.ConsolePal.OpenStandardOutput());
                            }
                            return $.$scsl.System.Console.s_out;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            static /*TextWriter */ get Error()
            {
                return $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$spc.System.IO.TextWriter).$v ?? EnsureInitialized();
                /*static TextWriter*/  function EnsureInitialized()
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                        {
                            if ($.$scsl.System.Console.s_error === null)
                            {
                                $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$spc.System.IO.TextWriter).$v = $.$scsl.System.Console.CreateOutputWriter($.$scsl.System.ConsolePal.OpenStandardError());
                            }
                            return $.$scsl.System.Console.s_error;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                    }
                }
            }
            static /*TextWriter */ CreateOutputWriter(/*Stream*/ outputStream)
            {
                return outputStream === $.$spc.System.IO.Stream.Null ? $.$spc.System.IO.TextWriter.Null : $.$spc.System.IO.TextWriter.Synchronized((() =>
                {
                    //new $.$spc.System.IO.StreamWriter()
                    const $t1 = $.$spc.System.IO.StreamWriter;
                    const $i1 = new $t1();
                    $i1.$ctor$7(outputStream, $.$scsl.System.Text.EncodingExtensions.RemovePreamble($.$scsl.System.Console.OutputEncoding), 256/*WriteBufferSize*/, true);
                    $i1.AutoFlush = true;
                    return $i1;
                })());
            }
            /*StrongBox<bool>?*/ static _isStdInRedirected = null;
            /*StrongBox<bool>?*/ static _isStdOutRedirected = null;
            /*StrongBox<bool>?*/ static _isStdErrRedirected = null;
            static /*bool */ get IsInputRedirected()
            {
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdInRedirected, ($v) => $.$scsl.System.Console._isStdInRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdInRedirected, ($v) => $.$scsl.System.Console._isStdInRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v = new ($.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsInputRedirectedCore());
                    return $.$scsl.System.Console._isStdInRedirected;
                }
            }
            static /*bool */ get IsOutputRedirected()
            {
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdOutRedirected, ($v) => $.$scsl.System.Console._isStdOutRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdOutRedirected, ($v) => $.$scsl.System.Console._isStdOutRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v = new ($.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsOutputRedirectedCore());
                    return $.$scsl.System.Console._isStdOutRedirected;
                }
            }
            static /*bool */ get IsErrorRedirected()
            {
                /*StrongBox<bool>*/ let redirected = $.$ref(() => $.$scsl.System.Console._isStdErrRedirected, ($v) => $.$scsl.System.Console._isStdErrRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v ?? EnsureInitialized();
                return redirected.Value;
                /*static StrongBox<bool>*/  function EnsureInitialized()
                {
                    $.$ref(() => $.$scsl.System.Console._isStdErrRedirected, ($v) => $.$scsl.System.Console._isStdErrRedirected = $v, $.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean)).$v = new ($.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean))().$ctor$2($.$scsl.System.ConsolePal.IsErrorRedirectedCore());
                    return $.$scsl.System.Console._isStdErrRedirected;
                }
            }
            static /*int */ get CursorSize()
            {
                return $.$scsl.System.ConsolePal.CursorSize;
            }
            static /*int */ set CursorSize(value)
            {
                $.$scsl.System.ConsolePal.CursorSize = value;
            }
            static /*bool */ get NumberLock()
            {
                return $.$scsl.System.ConsolePal.NumberLock;
            }
            static /*bool */ get CapsLock()
            {
                return $.$scsl.System.ConsolePal.CapsLock;
            }
            /*ConsoleColor*/ static UnknownColor = -1;
            static /*ConsoleColor */ get BackgroundColor()
            {
                return $.$scsl.System.ConsolePal.BackgroundColor;
            }
            static /*ConsoleColor */ set BackgroundColor(value)
            {
                $.$scsl.System.ConsolePal.BackgroundColor = value;
            }
            static /*ConsoleColor */ get ForegroundColor()
            {
                return $.$scsl.System.ConsolePal.ForegroundColor;
            }
            static /*ConsoleColor */ set ForegroundColor(value)
            {
                $.$scsl.System.ConsolePal.ForegroundColor = value;
            }
            static /*void */ ResetColor()
            {
                $.$scsl.System.ConsolePal.ResetColor();
            }
            static /*int */ get BufferWidth()
            {
                return $.$scsl.System.ConsolePal.BufferWidth;
            }
            static /*int */ set BufferWidth(value)
            {
                $.$scsl.System.ConsolePal.BufferWidth = value;
            }
            static /*int */ get BufferHeight()
            {
                return $.$scsl.System.ConsolePal.BufferHeight;
            }
            static /*int */ set BufferHeight(value)
            {
                $.$scsl.System.ConsolePal.BufferHeight = value;
            }
            static /*void */ SetBufferSize(/*int*/ width, /*int*/ height)
            {
                $.$scsl.System.ConsolePal.SetBufferSize(width, height);
            }
            static /*int */ get WindowLeft()
            {
                return $.$scsl.System.ConsolePal.WindowLeft;
            }
            static /*int */ set WindowLeft(value)
            {
                $.$scsl.System.ConsolePal.WindowLeft = value;
            }
            static /*int */ get WindowTop()
            {
                return $.$scsl.System.ConsolePal.WindowTop;
            }
            static /*int */ set WindowTop(value)
            {
                $.$scsl.System.ConsolePal.WindowTop = value;
            }
            static /*int */ get WindowWidth()
            {
                return $.$scsl.System.ConsolePal.WindowWidth;
            }
            static /*int */ set WindowWidth(value)
            {
                $.$scsl.System.ConsolePal.WindowWidth = value;
            }
            static /*int */ get WindowHeight()
            {
                return $.$scsl.System.ConsolePal.WindowHeight;
            }
            static /*int */ set WindowHeight(value)
            {
                $.$scsl.System.ConsolePal.WindowHeight = value;
            }
            static /*void */ SetWindowPosition(/*int*/ left, /*int*/ top)
            {
                $.$scsl.System.ConsolePal.SetWindowPosition(left, top);
            }
            static /*void */ SetWindowSize(/*int*/ width, /*int*/ height)
            {
                $.$scsl.System.ConsolePal.SetWindowSize(width, height);
            }
            static /*int */ get LargestWindowWidth()
            {
                return $.$scsl.System.ConsolePal.LargestWindowWidth;
            }
            static /*int */ get LargestWindowHeight()
            {
                return $.$scsl.System.ConsolePal.LargestWindowHeight;
            }
            static /*bool */ get CursorVisible()
            {
                return $.$scsl.System.ConsolePal.CursorVisible;
            }
            static /*bool */ set CursorVisible(value)
            {
                $.$scsl.System.ConsolePal.CursorVisible = value;
            }
            static /*int */ get CursorLeft()
            {
                return $.$scsl.System.ConsolePal.GetCursorPosition().Item1;
            }
            static /*int */ set CursorLeft(value)
            {
                $.$scsl.System.Console.SetCursorPosition(value, $.$scsl.System.Console.CursorTop);
            }
            static /*int */ get CursorTop()
            {
                return $.$scsl.System.ConsolePal.GetCursorPosition().Item2;
            }
            static /*int */ set CursorTop(value)
            {
                $.$scsl.System.Console.SetCursorPosition($.$scsl.System.Console.CursorLeft, value);
            }
            static /*(int Left, int Top) */ GetCursorPosition()
            {
                return $.$scsl.System.ConsolePal.GetCursorPosition();
            }
            static /*string */ get Title()
            {
                return $.$scsl.System.ConsolePal.Title;
            }
            static /*string */ set Title(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                $.$scsl.System.ConsolePal.Title = value;
            }
            static /*void */ Beep()
            {
                $.$scsl.System.ConsolePal.Beep();
            }
            static /*void */ Beep$1(/*int*/ frequency, /*int*/ duration)
            {
                $.$scsl.System.ConsolePal.Beep$1(frequency, duration);
            }
            static /*void */ MoveBufferArea(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop)
            {
                $.$scsl.System.ConsolePal.MoveBufferArea(sourceLeft, sourceTop, sourceWidth, sourceHeight, targetLeft, targetTop, /* */ 32, 0/*ConsoleColor.Black*/, $.$scsl.System.Console.BackgroundColor);
            }
            static /*void */ MoveBufferArea$1(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop, /*char*/ sourceChar, /*ConsoleColor*/ sourceForeColor, /*ConsoleColor*/ sourceBackColor)
            {
                $.$scsl.System.ConsolePal.MoveBufferArea(sourceLeft, sourceTop, sourceWidth, sourceHeight, targetLeft, targetTop, sourceChar, sourceForeColor, sourceBackColor);
            }
            static /*void */ Clear()
            {
                $.$scsl.System.ConsolePal.Clear();
            }
            static /*void */ SetCursorPosition(/*int*/ left, /*int*/ top)
            {
                if (left < 0 || left >= 32767/*short.MaxValue*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("left", $.$box(left, $.$spc.System.Int32), $.$scsl.System.SR.ArgumentOutOfRange_ConsoleBufferBoundaries);
                }
                if (top < 0 || top >= 32767/*short.MaxValue*/)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("top", $.$box(top, $.$spc.System.Int32), $.$scsl.System.SR.ArgumentOutOfRange_ConsoleBufferBoundaries);
                }
                $.$scsl.System.ConsolePal.SetCursorPosition(left, top);
            }
            /*ConsoleCancelEventHandler?*/static  CancelKeyPress$add(value)
            {
                $.$scsl.System.ConsolePal.EnsureConsoleInitialized();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_cancelCallbacks = $.$spc.System.Delegate.Combine($.$scsl.System.Console.s_cancelCallbacks, value);
                        if ($.$scsl.System.Console.s_sigIntRegistration === null)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$scsl.System.Console.s_sigQuitRegistration === null, "s_sigQuitRegistration is null");
                            /*Action<PosixSignalContext>*/ let handler = new ($.$spc.System.Action$$($.$spc.System.Runtime.InteropServices.PosixSignalContext))().$ctor(null, $.$scsl.System.Console.HandlePosixSignal);
                            $.$scsl.System.Console.s_sigIntRegistration = $.$spc.System.Runtime.InteropServices.PosixSignalRegistration.Create(-2/*PosixSignal.SIGINT*/, handler);
                            $.$scsl.System.Console.s_sigQuitRegistration = $.$spc.System.Runtime.InteropServices.PosixSignalRegistration.Create(-3/*PosixSignal.SIGQUIT*/, handler);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            /*ConsoleCancelEventHandler?*/static  CancelKeyPress$remove(value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_cancelCallbacks = $.$spc.System.Delegate.Remove($.$scsl.System.Console.s_cancelCallbacks, value);
                        if ($.$scsl.System.Console.s_cancelCallbacks === null)
                        {
                            $.$scsl.System.Console.s_sigIntRegistration?.Dispose();
                            $.$scsl.System.Console.s_sigQuitRegistration?.Dispose();
                            $.$scsl.System.Console.s_sigIntRegistration = $.$scsl.System.Console.s_sigQuitRegistration = null;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*bool */ get TreatControlCAsInput()
            {
                return $.$scsl.System.ConsolePal.TreatControlCAsInput;
            }
            static /*bool */ set TreatControlCAsInput(value)
            {
                $.$scsl.System.ConsolePal.TreatControlCAsInput = value;
            }
            static /*Stream */ OpenStandardInput()
            {
                return $.$scsl.System.ConsolePal.OpenStandardInput();
            }
            static /*Stream */ OpenStandardInput$1(/*int*/ bufferSize)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardInput();
            }
            static /*Stream */ OpenStandardOutput()
            {
                return $.$scsl.System.ConsolePal.OpenStandardOutput();
            }
            static /*Stream */ OpenStandardOutput$1(/*int*/ bufferSize)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardOutput();
            }
            static /*Stream */ OpenStandardError()
            {
                return $.$scsl.System.ConsolePal.OpenStandardError();
            }
            static /*Stream */ OpenStandardError$1(/*int*/ bufferSize)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, bufferSize, "bufferSize");
                return $.$scsl.System.ConsolePal.OpenStandardError();
            }
            static /*void */ SetIn(/*TextReader*/ newIn)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(newIn, "newIn");
                newIn = $.$scsl.System.IO.SyncTextReader.GetSynchronizedTextReader(newIn);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$ref(() => $.$scsl.System.Console.s_in, ($v) => $.$scsl.System.Console.s_in = $v, $.$spc.System.IO.TextReader).$v = newIn;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*void */ SetOut(/*TextWriter*/ newOut)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(newOut, "newOut");
                if (newOut !== $.$spc.System.IO.TextWriter.Null)
                {
                    newOut = $.$spc.System.IO.TextWriter.Synchronized(newOut);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_isOutTextWriterRedirected = true;
                        $.$ref(() => $.$scsl.System.Console.s_out, ($v) => $.$scsl.System.Console.s_out = $v, $.$spc.System.IO.TextWriter).$v = newOut;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*void */ SetError(/*TextWriter*/ newError)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(newError, "newError");
                if (newError !== $.$spc.System.IO.TextWriter.Null)
                {
                    newError = $.$spc.System.IO.TextWriter.Synchronized(newError);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$scsl.System.Console.s_syncObject)
                    {
                        $.$scsl.System.Console.s_isErrorTextWriterRedirected = true;
                        $.$ref(() => $.$scsl.System.Console.s_error, ($v) => $.$scsl.System.Console.s_error = $v, $.$spc.System.IO.TextWriter).$v = newError;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$scsl.System.Console.s_syncObject)
                }
            }
            static /*int */ Read()
            {
                return $.$scsl.System.Console.In.Read();
            }
            static /*string? */ ReadLine()
            {
                return $.$scsl.System.Console.In.ReadLine();
            }
            static /*void */ WriteLine()
            {
                $.$scsl.System.Console.Out.WriteLine();
            }
            static /*void */ WriteLine$1(/*bool*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$5(value);
            }
            static /*void */ WriteLine$2(/*char*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$1(value);
            }
            static /*void */ WriteLine$3(/*char[]?*/ buffer)
            {
                $.$scsl.System.Console.Out.WriteLine$2(buffer);
            }
            static /*void */ WriteLine$4(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$scsl.System.Console.Out.WriteLine$3(buffer, index, count);
            }
            static /*void */ WriteLine$5(/*decimal*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$12(value);
            }
            static /*void */ WriteLine$6(/*double*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$11(value);
            }
            static /*void */ WriteLine$7(/*float*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$10(value);
            }
            static /*void */ WriteLine$8(/*int*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$6(value);
            }
            static /*void */ WriteLine$9(/*uint*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$7(value);
            }
            static /*void */ WriteLine$10(/*long*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$8(value);
            }
            static /*void */ WriteLine$11(/*ulong*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$9(value);
            }
            static /*void */ WriteLine$12(/*object?*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$15(value);
            }
            static /*void */ WriteLine$13(/*string?*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$13(value);
            }
            static /*void */ WriteLine$14(/*ReadOnlySpan<char>*/ value)
            {
                $.$scsl.System.Console.Out.WriteLine$4(value);
            }
            static /*void */ WriteLine$15(/*string*/ format, /*object?*/ arg0)
            {
                $.$scsl.System.Console.Out.WriteLine$16(format, arg0);
            }
            static /*void */ WriteLine$16(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1)
            {
                $.$scsl.System.Console.Out.WriteLine$17(format, arg0, arg1);
            }
            static /*void */ WriteLine$17(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1, /*object?*/ arg2)
            {
                $.$scsl.System.Console.Out.WriteLine$18(format, arg0, arg1, arg2);
            }
            static /*void */ WriteLine$18(/*string*/ format, /*params object?[]?*/ arg)
            {
                if (arg === null)
                {
                    $.$scsl.System.Console.Out.WriteLine$17(format, null, null);
                }
                else 
                {
                    $.$scsl.System.Console.Out.WriteLine$19(format, arg);
                }
            }
            static /*void */ WriteLine$19(/*string*/ format, /*params ReadOnlySpan<object?>*/ arg)
            {
                $.$scsl.System.Console.Out.WriteLine$20(format, arg);
            }
            static /*void */ Write(/*string*/ format, /*object?*/ arg0)
            {
                $.$scsl.System.Console.Out.Write$15(format, arg0);
            }
            static /*void */ Write$1(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1)
            {
                $.$scsl.System.Console.Out.Write$16(format, arg0, arg1);
            }
            static /*void */ Write$2(/*string*/ format, /*object?*/ arg0, /*object?*/ arg1, /*object?*/ arg2)
            {
                $.$scsl.System.Console.Out.Write$17(format, arg0, arg1, arg2);
            }
            static /*void */ Write$3(/*string*/ format, /*params object?[]?*/ arg)
            {
                if (arg === null)
                {
                    $.$scsl.System.Console.Out.Write$16(format, null, null);
                }
                else 
                {
                    $.$scsl.System.Console.Out.Write$18(format, arg);
                }
            }
            static /*void */ Write$4(/*string*/ format, /*params ReadOnlySpan<object?>*/ arg)
            {
                $.$scsl.System.Console.Out.Write$19(format, arg);
            }
            static /*void */ Write$5(/*bool*/ value)
            {
                $.$scsl.System.Console.Out.Write$4(value);
            }
            static /*void */ Write$6(/*char*/ value)
            {
                $.$scsl.System.Console.Out.Write(value);
            }
            static /*void */ Write$7(/*char[]?*/ buffer)
            {
                $.$scsl.System.Console.Out.Write$1(buffer);
            }
            static /*void */ Write$8(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$scsl.System.Console.Out.Write$2(buffer, index, count);
            }
            static /*void */ Write$9(/*double*/ value)
            {
                $.$scsl.System.Console.Out.Write$10(value);
            }
            static /*void */ Write$10(/*decimal*/ value)
            {
                $.$scsl.System.Console.Out.Write$11(value);
            }
            static /*void */ Write$11(/*float*/ value)
            {
                $.$scsl.System.Console.Out.Write$9(value);
            }
            static /*void */ Write$12(/*int*/ value)
            {
                $.$scsl.System.Console.Out.Write$5(value);
            }
            static /*void */ Write$13(/*uint*/ value)
            {
                $.$scsl.System.Console.Out.Write$6(value);
            }
            static /*void */ Write$14(/*long*/ value)
            {
                $.$scsl.System.Console.Out.Write$7(value);
            }
            static /*void */ Write$15(/*ulong*/ value)
            {
                $.$scsl.System.Console.Out.Write$8(value);
            }
            static /*void */ Write$16(/*object?*/ value)
            {
                $.$scsl.System.Console.Out.Write$13(value);
            }
            static /*void */ Write$17(/*string?*/ value)
            {
                $.$scsl.System.Console.Out.Write$12(value);
            }
            static /*void */ Write$18(/*ReadOnlySpan<char>*/ value)
            {
                $.$scsl.System.Console.Out.Write$3(value);
            }
            static /*void */ HandlePosixSignal(/*PosixSignalContext*/ ctx)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(ctx.Signal === -2/*PosixSignal.SIGINT*/ || ctx.Signal === -3/*PosixSignal.SIGQUIT*/, "ctx.Signal == PosixSignal.SIGINT || ctx.Signal == PosixSignal.SIGQUIT");
                let handler;
                if ($.$is($.$scsl.System.Console.s_cancelCallbacks, $.$scsl.System.ConsoleCancelEventHandler, { set $v(v){ handler = v; } }))
                {
                    /*var*/ let args = new $.$scsl.System.ConsoleCancelEventArgs().$ctor$2(ctx.Signal === -2/*PosixSignal.SIGINT*/ ? 0/*ConsoleSpecialKey.ControlC*/ : 1/*ConsoleSpecialKey.ControlBreak*/);
                    args.Cancel = ctx.Cancel;
                    handler.Invoke(null, args);
                    ctx.Cancel = args.Cancel;
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_syncObject = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 524329;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":62849025,"g":{"r":0,"d":0,"h":64425033769,"f":33},"n":"In","d":524329,"h":60130066473,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":121831425,"g":{"r":0,"d":0,"h":73014968361,"f":33},"s":{"r":0,"d":0,"h":77309935657,"f":33},"n":"InputEncoding","d":524329,"h":68720001065,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":121831425,"g":{"r":0,"d":0,"h":85899870249,"f":33},"s":{"r":0,"d":0,"h":90194837545,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"n":"OutputEncoding","d":524329,"h":81604902953,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":98784772137,"f":33},"n":"KeyAvailable","d":524329,"h":94489804841,"f":33},{"p":62980097,"g":{"r":0,"d":0,"h":115964641321,"f":33},"n":"Out","d":524329,"h":111669674025,"f":33},{"p":62980097,"g":{"r":0,"d":0,"h":124554575913,"f":33},"n":"Error","d":524329,"h":120259608617,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":150324379689,"f":33},"n":"IsInputRedirected","d":524329,"h":146029412393,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":158914314281,"f":33},"n":"IsOutputRedirected","d":524329,"h":154619346985,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":167504248873,"f":33},"n":"IsErrorRedirected","d":524329,"h":163209281577,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":176094183465,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"s":{"r":0,"d":0,"h":180389150761,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"CursorSize","d":524329,"h":171799216169,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":188979085353,"f":33},"n":"NumberLock","d":524329,"h":184684118057,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":197569019945,"f":33},"n":"CapsLock","d":524329,"h":193274052649,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":720937,"g":{"r":0,"d":0,"h":210453921833,"f":33},"s":{"r":0,"d":0,"h":214748889129,"f":33},"n":"BackgroundColor","d":524329,"h":206158954537,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":720937,"g":{"r":0,"d":0,"h":223338823721,"f":33},"s":{"r":0,"d":0,"h":227633791017,"f":33},"n":"ForegroundColor","d":524329,"h":219043856425,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":240518692905,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"s":{"r":0,"d":0,"h":244813660201,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"BufferWidth","d":524329,"h":236223725609,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":253403594793,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"s":{"r":0,"d":0,"h":257698562089,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"BufferHeight","d":524329,"h":249108627497,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":270583463977,"f":33},"s":{"r":0,"d":0,"h":274878431273,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"WindowLeft","d":524329,"h":266288496681,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":283468365865,"f":33},"s":{"r":0,"d":0,"h":287763333161,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"WindowTop","d":524329,"h":279173398569,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":296353267753,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"s":{"r":0,"d":0,"h":300648235049,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"WindowWidth","d":524329,"h":292058300457,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":309238169641,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"s":{"r":0,"d":0,"h":313533136937,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"WindowHeight","d":524329,"h":304943202345,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":330713006121,"f":33},"n":"LargestWindowWidth","d":524329,"h":326418038825,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":339302940713,"f":33},"n":"LargestWindowHeight","d":524329,"h":335007973417,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":347892875305,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"s":{"r":0,"d":0,"h":352187842601,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"n":"CursorVisible","d":524329,"h":343597908009,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":360777777193,"f":33},"s":{"r":0,"d":0,"h":365072744489,"f":33},"n":"CursorLeft","d":524329,"h":356482809897,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":373662679081,"f":33},"s":{"r":0,"d":0,"h":377957646377,"f":33},"n":"CursorTop","d":524329,"h":369367711785,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":390842548265,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"s":{"r":0,"d":0,"h":395137515561,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},"n":"Title","d":524329,"h":386547580969,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":442382155817,"f":33},"s":{"r":0,"d":0,"h":446677123113,"f":33},"n":"TreatControlCAsInput","d":524329,"h":438087188521,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":852009,"n":"ReadKey","d":524329,"h":103079739433,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":852009,"p":[{"n":"intercept","p":262145}],"n":"ReadKey","o":"@$1","d":524329,"h":107374706729,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":62980097,"p":[{"n":"outputStream","p":62128129}],"n":"CreateOutputWriter","d":524329,"h":128849543209,"f":34},{"r":65537,"n":"ResetColor","d":524329,"h":231928758313,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"SetBufferSize","d":524329,"h":261993529385,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"left","p":655361},{"n":"top","p":655361}],"n":"SetWindowPosition","d":524329,"h":317828104233,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"SetWindowSize","d":524329,"h":322123071529,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h,"n":"GetCursorPosition","d":524329,"h":382252613673,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":65537,"n":"Beep","d":524329,"h":399432482857,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":65537,"p":[{"n":"frequency","p":655361},{"n":"duration","p":655361}],"n":"Beep","o":"@$1","d":524329,"h":403727450153,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"sourceLeft","p":655361},{"n":"sourceTop","p":655361},{"n":"sourceWidth","p":655361},{"n":"sourceHeight","p":655361},{"n":"targetLeft","p":655361},{"n":"targetTop","p":655361}],"n":"MoveBufferArea","d":524329,"h":408022417449,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"sourceLeft","p":655361},{"n":"sourceTop","p":655361},{"n":"sourceWidth","p":655361},{"n":"sourceHeight","p":655361},{"n":"targetLeft","p":655361},{"n":"targetTop","p":655361},{"n":"sourceChar","p":458753},{"n":"sourceForeColor","p":720937},{"n":"sourceBackColor","p":720937}],"n":"MoveBufferArea","o":"@$1","d":524329,"h":412317384745,"f":33,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"n":"Clear","d":524329,"h":416612352041,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":65537,"p":[{"n":"left","p":655361},{"n":"top","p":655361}],"n":"SetCursorPosition","d":524329,"h":420907319337,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":62128129,"n":"OpenStandardInput","d":524329,"h":450972090409,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":62128129,"p":[{"n":"bufferSize","p":655361}],"n":"OpenStandardInput","o":"@$1","d":524329,"h":455267057705,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":62128129,"n":"OpenStandardOutput","d":524329,"h":459562025001,"f":33},{"r":62128129,"p":[{"n":"bufferSize","p":655361}],"n":"OpenStandardOutput","o":"@$1","d":524329,"h":463856992297,"f":33},{"r":62128129,"n":"OpenStandardError","d":524329,"h":468151959593,"f":33},{"r":62128129,"p":[{"n":"bufferSize","p":655361}],"n":"OpenStandardError","o":"@$1","d":524329,"h":472446926889,"f":33},{"r":65537,"p":[{"n":"newIn","p":62849025}],"n":"SetIn","d":524329,"h":476741894185,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":65537,"p":[{"n":"newOut","p":62980097}],"n":"SetOut","d":524329,"h":481036861481,"f":33},{"r":65537,"p":[{"n":"newError","p":62980097}],"n":"SetError","d":524329,"h":485331828777,"f":33},{"r":655361,"n":"Read","d":524329,"h":489626796073,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":1310721,"n":"ReadLine","d":524329,"h":493921763369,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]}]},{"r":65537,"n":"WriteLine","d":524329,"h":498216730665,"f":33},{"r":65537,"p":[{"n":"value","p":262145}],"n":"WriteLine","o":"@$1","d":524329,"h":502511697961,"f":33},{"r":65537,"p":[{"n":"value","p":458753}],"n":"WriteLine","o":"@$2","d":524329,"h":506806665257,"f":33},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"WriteLine","o":"@$3","d":524329,"h":511101632553,"f":33},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"WriteLine","o":"@$4","d":524329,"h":515396599849,"f":33},{"r":65537,"p":[{"n":"value","p":34996225}],"n":"WriteLine","o":"@$5","d":524329,"h":519691567145,"f":33},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"WriteLine","o":"@$6","d":524329,"h":523986534441,"f":33},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"WriteLine","o":"@$7","d":524329,"h":528281501737,"f":33},{"r":65537,"p":[{"n":"value","p":655361}],"n":"WriteLine","o":"@$8","d":524329,"h":532576469033,"f":33},{"r":65537,"p":[{"n":"value","p":720897}],"n":"WriteLine","o":"@$9","d":524329,"h":536871436329,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":917505}],"n":"WriteLine","o":"@$10","d":524329,"h":541166403625,"f":33},{"r":65537,"p":[{"n":"value","p":983041}],"n":"WriteLine","o":"@$11","d":524329,"h":545461370921,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"WriteLine","o":"@$12","d":524329,"h":549756338217,"f":33},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"WriteLine","o":"@$13","d":524329,"h":554051305513,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"WriteLine","o":"@$14","d":524329,"h":558346272809,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073}],"n":"WriteLine","o":"@$15","d":524329,"h":562641240105,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073},{"n":"arg1","p":131073}],"n":"WriteLine","o":"@$16","d":524329,"h":566936207401,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073},{"n":"arg1","p":131073},{"n":"arg2","p":131073}],"n":"WriteLine","o":"@$17","d":524329,"h":571231174697,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg","p":0,"f":16}],"n":"WriteLine","o":"@$18","d":524329,"h":575526141993,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Object).$h,"f":16}],"n":"WriteLine","o":"@$19","d":524329,"h":579821109289,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073}],"n":"Write","d":524329,"h":584116076585,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073},{"n":"arg1","p":131073}],"n":"Write","o":"@$1","d":524329,"h":588411043881,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg0","p":131073},{"n":"arg1","p":131073},{"n":"arg2","p":131073}],"n":"Write","o":"@$2","d":524329,"h":592706011177,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg","p":0,"f":16}],"n":"Write","o":"@$3","d":524329,"h":597000978473,"f":33},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"arg","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Object).$h,"f":16}],"n":"Write","o":"@$4","d":524329,"h":601295945769,"f":33},{"r":65537,"p":[{"n":"value","p":262145}],"n":"Write","o":"@$5","d":524329,"h":605590913065,"f":33},{"r":65537,"p":[{"n":"value","p":458753}],"n":"Write","o":"@$6","d":524329,"h":609885880361,"f":33},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$7","d":524329,"h":614180847657,"f":33},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Write","o":"@$8","d":524329,"h":618475814953,"f":33},{"r":65537,"p":[{"n":"value","p":1179649}],"n":"Write","o":"@$9","d":524329,"h":622770782249,"f":33},{"r":65537,"p":[{"n":"value","p":34996225}],"n":"Write","o":"@$10","d":524329,"h":627065749545,"f":33},{"r":65537,"p":[{"n":"value","p":1114113}],"n":"Write","o":"@$11","d":524329,"h":631360716841,"f":33},{"r":65537,"p":[{"n":"value","p":655361}],"n":"Write","o":"@$12","d":524329,"h":635655684137,"f":33},{"r":65537,"p":[{"n":"value","p":720897}],"n":"Write","o":"@$13","d":524329,"h":639950651433,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":917505}],"n":"Write","o":"@$14","d":524329,"h":644245618729,"f":33},{"r":65537,"p":[{"n":"value","p":983041}],"n":"Write","o":"@$15","d":524329,"h":648540586025,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Write","o":"@$16","d":524329,"h":652835553321,"f":33},{"r":65537,"p":[{"n":"value","p":1310721}],"n":"Write","o":"@$17","d":524329,"h":657130520617,"f":33},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Write","o":"@$18","d":524329,"h":661425487913,"f":33},{"r":65537,"p":[{"n":"ctx","p":108986369}],"n":"HandlePosixSignal","d":524329,"h":665720455209,"f":34}],"l":[{"t":655361,"n":"ReadBufferSize","d":524329,"h":4295491625,"f":40},{"t":655361,"n":"WriteBufferSize","d":524329,"h":8590458921,"f":34},{"t":131073,"n":"s_syncObject","d":524329,"h":12885426217,"f":34},{"t":62849025,"n":"s_in","d":524329,"h":17180393513,"f":34},{"t":62980097,"n":"s_out","d":524329,"h":21475360809,"f":34},{"t":62980097,"n":"s_error","d":524329,"h":25770328105,"f":34},{"t":121831425,"n":"s_inputEncoding","d":524329,"h":30065295401,"f":34},{"t":121831425,"n":"s_outputEncoding","d":524329,"h":34360262697,"f":34},{"t":262145,"n":"s_isOutTextWriterRedirected","d":524329,"h":38655229993,"f":34},{"t":262145,"n":"s_isErrorTextWriterRedirected","d":524329,"h":42950197289,"f":34},{"t":655401,"n":"s_cancelCallbacks","d":524329,"h":47245164585,"f":34},{"t":109051905,"n":"s_sigIntRegistration","d":524329,"h":51540131881,"f":34},{"t":109051905,"n":"s_sigQuitRegistration","d":524329,"h":55835099177,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean).$h,"n":"_isStdInRedirected","d":524329,"h":133144510505,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean).$h,"n":"_isStdOutRedirected","d":524329,"h":137439477801,"f":34},{"t":$.$spc.System.Runtime.CompilerServices.StrongBox$$($.$spc.System.Boolean).$h,"n":"_isStdErrRedirected","d":524329,"h":141734445097,"f":34},{"t":720937,"n":"UnknownColor","d":524329,"h":201863987241,"f":40}],"e":[{"e":655401,"m":{"r":65537,"p":[{"n":"value","p":655401}],"n":"add_CancelKeyPress","d":524329,"h":429497253929,"f":33},"r":{"r":65537,"p":[{"n":"value","p":655401}],"n":"remove_CancelKeyPress","d":524329,"h":433792221225,"f":33},"n":"CancelKeyPress","d":524329,"h":425202286633,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"browser","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"h":524329}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Console`; }
        });
        
        $asm.$cls("$scsl.Interop", ($self) => class Interop
        {
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$scsl.Interop.Sys", ($self) => class Sys
                {
                    static /*int */ Write(/*SafeHandle*/ fd, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        if (fd.DangerousGetHandle() === 1)
                        {
                            /*var*/ let reff = buffer;
                            /*var*/ let array = reff.ToArray(bufferSize);
                            const uint8Array = new Uint8Array(array);
                            const decodedString = new TextDecoder().decode(uint8Array);
                            console.log(decodedString);
                            return bufferSize;
                        }
                        return -1;
                    }
                    static /*int */ Write$1(/*IntPtr*/ fd, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        return -1;
                    }
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$scsl.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        return null;
                    }
                    static /*Error */ GetLastError()
                    {
                        return $.$scsl.Interop.Sys.ConvertErrorPlatformToPal($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$scsl.Interop.ErrorInfo().$ctor$2($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$scsl.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8($.$cast(message, $.$spc.System.IntPtr));
                    }
                    static $_FileDescriptors;
                    static get FileDescriptors()
                    {
                        let $cls = $.$scsl.Interop.Sys;
                        return $cls.$_FileDescriptors ??= $asm.$ncls("$scsl.Interop.Sys.FileDescriptors", ($self) => class FileDescriptors
                        {
                            /*SafeFileHandle*/ static STDIN_FILENO = null;
                            /*SafeFileHandle*/ static STDOUT_FILENO = null;
                            /*SafeFileHandle*/ static STDERR_FILENO = null;
                            static /*SafeFileHandle */ CreateFileHandle(/*int*/ fileNumber)
                            {
                                return new $.$spc.Microsoft.Win32.SafeHandles.SafeFileHandle().$ctor$4(fileNumber, false);
                            }
                            //Static Initializer
                            static $sinit()
                            {
                                {
                                    this.STDIN_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(0);
                                }
                                {
                                    this.STDOUT_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(1);
                                }
                                {
                                    this.STDERR_FILENO = $.$scsl.Interop.Sys.FileDescriptors.CreateFileHandle(2);
                                }
                            }
                            static $h = 393257;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"d":327721,"h":393257}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `Interop.Sys.FileDescriptors`; }
                        }, $cls, ($v) => $cls.$_FileDescriptors = $v);
                    }
                    static /*SafeFileHandle */ Dup(/*SafeFileHandle*/ oldfd)
                    {
                        return oldfd;
                    }
                    static $h = 327721;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":65577,"h":327721}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$scsl.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 262185;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":65577,"h":262185}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_Error ??= $asm.$nstr("$scsl.Interop.Error", ($self) => class Error extends $.$spc.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 131113;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"d":65577,"h":131113}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$scsl.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$scsl.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$spc.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$scsl.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$scsl.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    $ctor$2(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$scsl.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$3(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$scsl.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$scsl.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$scsl.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 196649;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":65577,"h":196649}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static /*void */ ThrowExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 0/*Error.SUCCESS*/, "errorInfo.Error != Error.SUCCESS");
                $.$spc.System.Diagnostics.Debug.Assert$1(errorInfo.Error !== 65563/*Error.EINTR*/, "EINTR errors should be handled by the native shim and never bubble up to managed code");
                throw $.$scsl.Interop.GetExceptionForIoErrno(errorInfo.Clone(), path, isDirError);
            }
            static /*void */ CheckIo(/*Error*/ error, /*string?*/ path, /*bool*/ isDirError)
            {
                if (error !== 0/*Interop.Error.SUCCESS*/)
                {
                    $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.InteropErrorExtensions.Info(error), path, isDirError);
                }
            }
            static /*long */ CheckIo$1(/*long*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                if (result < 0n)
                {
                    $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                }
                return result;
            }
            static /*void */ ThrowIOExceptionForLastError()
            {
                $.$scsl.Interop.ThrowExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), null, false);
            }
            static /*int */ CheckIo$2(/*int*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$scsl.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*IntPtr */ CheckIo$3(/*IntPtr*/ result, /*string?*/ path, /*bool*/ isDirError)
            {
                $.$scsl.Interop.CheckIo$1($.$cast(result, $.$spc.System.Int64), path, isDirError);
                return result;
            }
            static /*TSafeHandle */ CheckIo$4(TSafeHandle, /*TSafeHandle*/ handle, /*string?*/ path, /*bool*/ isDirError)
            {
                if (handle.IsInvalid)
                {
                    /*Exception*/ let e = $.$scsl.Interop.GetExceptionForIoErrno($.$scsl.Interop.Sys.GetLastErrorInfo(), path, isDirError);
                    $.$dsp(handle, TSafeHandle, ($t) => $t.Dispose,);
                    throw e;
                }
                return handle;
            }
            static /*Exception */ GetExceptionForIoErrno(/*ErrorInfo*/ errorInfo, /*string?*/ path, /*bool*/ isDirError)
            {
                let $switchJumpState1;
                $switchJumpStart1: while(true)
                {
                    let $switch1 = $switchJumpState1 ?? (errorInfo.Error);
                    switch($switch1)
                    {
                        case 65581/*Error.ENOENT*/:
                        if (!isDirError && (path === null || ParentDirectoryExists(path)))
                        {
                            return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.FileNotFoundException().$ctor$17($.$scsl.System.SR.Format($.$scsl.System.SR.IO_FileNotFound_FileName, path), path) : new $.$spc.System.IO.FileNotFoundException().$ctor$15($.$scsl.System.SR.IO_FileNotFound);
                        }
                        $switchJumpState1 = 65593/*Error.ENOTDIR*/; /*goto case Error.ENOTDIR*/
                        continue $switchJumpStart1;
                        case 65593/*Error.ENOTDIR*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$scsl.System.SR.Format($.$scsl.System.SR.IO_PathNotFound_Path, path)) : new $.$spc.System.IO.DirectoryNotFoundException().$ctor$15($.$scsl.System.SR.IO_PathNotFound_NoPathName);
                        case 65538/*Error.EACCES*/:
                        case 65544/*Error.EBADF*/:
                        case 65602/*Error.EPERM*/:
                        /*Exception*/ let inner = $.$scsl.Interop.GetIOException(errorInfo.Clone(), null);
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$scsl.System.SR.Format($.$scsl.System.SR.UnauthorizedAccess_IODenied_Path, path), inner) : new $.$spc.System.UnauthorizedAccessException().$ctor$11($.$scsl.System.SR.UnauthorizedAccess_IODenied_NoPathName, inner);
                        case 65573/*Error.ENAMETOOLONG*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.PathTooLongException().$ctor$15($.$scsl.System.SR.Format($.$scsl.System.SR.IO_PathTooLong_Path, path)) : new $.$spc.System.IO.PathTooLongException().$ctor$15($.$scsl.System.SR.IO_PathTooLong);
                        case 65542/*Error.EWOULDBLOCK*/:
                        return !$.$spc.System.String.IsNullOrEmpty(path) ? new $.$spc.System.IO.IOException().$ctor$11($.$scsl.System.SR.Format($.$scsl.System.SR.IO_SharingViolation_File, path), errorInfo.RawErrno) : new $.$spc.System.IO.IOException().$ctor$11($.$scsl.System.SR.IO_SharingViolation_NoFileName, errorInfo.RawErrno);
                        case 65547/*Error.ECANCELED*/:
                        return new $.$spc.System.OperationCanceledException().$ctor$9();
                        case 65558/*Error.EFBIG*/:
                        return new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$scsl.System.SR.ArgumentOutOfRange_FileLengthTooBig);
                        case 65556/*Error.EEXIST*/:
                        if (!$.$spc.System.String.IsNullOrEmpty(path))
                        {
                            return new $.$spc.System.IO.IOException().$ctor$11($.$scsl.System.SR.Format($.$scsl.System.SR.IO_FileExists_Name, path), errorInfo.RawErrno);
                        }
                        $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                        continue $switchJumpStart1;
                        default:
                        return $.$scsl.Interop.GetIOException(errorInfo.Clone(), path);
                        /*static bool*/  function ParentDirectoryExists(/*string*/ fullPath)
                        {
                            /*string?*/ let parentPath = $.$spc.System.IO.Path.GetDirectoryName($.$spc.System.IO.Path.TrimEndingDirectorySeparator(fullPath));
                            return $.$spc.System.IO.Directory.Exists(parentPath);
                        }
                    }
                    break;
                }
            }
            static /*Exception */ GetIOException(/*Interop.ErrorInfo*/ errorInfo, /*string?*/ path)
            {
                /*string*/ let msg = errorInfo.GetErrorMessage();
                return new $.$spc.System.IO.IOException().$ctor$11($.$spc.System.String.IsNullOrEmpty(path) ? msg : `${msg} : '${path}'`, errorInfo.RawErrno);
            }
            static $h = 65577;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":65577}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$scsl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$scsl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Console", $.$scsl.System.SR.$type.Assembly);
                    $.$scsl.System.SR.s_resourceManager = temp;
                }
                return $.$scsl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$scsl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$scsl.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentOutOfRange_ConsoleWindowBufferSize()
            {
                return "The value must be less than the console's current maximum window size of {0} in that dimension. Note that this value depends on screen resolution and the console font.";
            }
            static /*string */ FormatArgumentOutOfRange_ConsoleWindowBufferSize(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The value must be less than the console's current maximum window size of {0} in that dimension. Note that this value depends on screen resolution and the console font.", arg1);
            }
            static /*string */ get ArgumentOutOfRange_ConsoleWindowSize_Size()
            {
                return "The new console window size would force the console buffer size to be too large.";
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get ArgumentOutOfRange_FileLengthTooBig()
            {
                return "Specified file length was too large for the file system.";
            }
            static /*string */ get NotSupported_UnseekableStream()
            {
                return "Stream does not support seeking.";
            }
            static /*string */ get ObjectDisposed_FileClosed()
            {
                return "Cannot access a closed file.";
            }
            static /*string */ get NotSupported_UnwritableStream()
            {
                return "Stream does not support writing.";
            }
            static /*string */ get NotSupported_UnreadableStream()
            {
                return "Stream does not support reading.";
            }
            static /*string */ get IO_AlreadyExists_Name()
            {
                return "Cannot create '{0}' because a file or directory with the same name already exists.";
            }
            static /*string */ FormatIO_AlreadyExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot create '{0}' because a file or directory with the same name already exists.", arg1);
            }
            static /*string */ get IO_FileExists_Name()
            {
                return "The file '{0}' already exists.";
            }
            static /*string */ FormatIO_FileExists_Name(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The file '{0}' already exists.", arg1);
            }
            static /*string */ get IO_FileNotFound()
            {
                return "Unable to find the specified file.";
            }
            static /*string */ get IO_FileNotFound_FileName()
            {
                return "Could not find file '{0}'.";
            }
            static /*string */ FormatIO_FileNotFound_FileName(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find file '{0}'.", arg1);
            }
            static /*string */ get IO_PathNotFound_NoPathName()
            {
                return "Could not find a part of the path.";
            }
            static /*string */ get IO_PathNotFound_Path()
            {
                return "Could not find a part of the path '{0}'.";
            }
            static /*string */ FormatIO_PathNotFound_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Could not find a part of the path '{0}'.", arg1);
            }
            static /*string */ get IO_PathTooLong()
            {
                return "The specified file name or path is too long, or a component of the specified path is too long.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_NoPathName()
            {
                return "Access to the path is denied.";
            }
            static /*string */ get UnauthorizedAccess_IODenied_Path()
            {
                return "Access to the path '{0}' is denied.";
            }
            static /*string */ FormatUnauthorizedAccess_IODenied_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Access to the path '{0}' is denied.", arg1);
            }
            static /*string */ get IO_SharingViolation_File()
            {
                return "The process cannot access the file '{0}' because it is being used by another process.";
            }
            static /*string */ FormatIO_SharingViolation_File(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The process cannot access the file '{0}' because it is being used by another process.", arg1);
            }
            static /*string */ get IO_SharingViolation_NoFileName()
            {
                return "The process cannot access the file because it is being used by another process.";
            }
            static /*string */ get Arg_InvalidConsoleColor()
            {
                return "The ConsoleColor enum value was not defined on that enum. Please use a defined color from the enum.";
            }
            static /*string */ get IO_NoConsole()
            {
                return "There is no console.";
            }
            static /*string */ get IO_TermInfoInvalid()
            {
                return "The terminfo database is invalid.";
            }
            static /*string */ get InvalidOperation_PrintF()
            {
                return "The printf operation failed.";
            }
            static /*string */ get InvalidOperation_ConsoleReadKeyOnFile()
            {
                return "Cannot read keys when either application does not have a console or when console input has been redirected. Try Console.Read.";
            }
            static /*string */ get InvalidOperation_SetWindowSize()
            {
                return "Cannot set window size when console output has been redirected.";
            }
            static /*string */ get PersistedFiles_NoHomeDirectory()
            {
                return "The home directory of the current user could not be determined.";
            }
            static /*string */ get ArgumentOutOfRange_ConsoleKey()
            {
                return "Console key values must be between 0 and 255 inclusive.";
            }
            static /*string */ get ArgumentOutOfRange_ConsoleBufferBoundaries()
            {
                return "The value must be greater than or equal to zero and less than the console's buffer size in that dimension.";
            }
            static /*string */ get ArgumentOutOfRange_ConsoleWindowPos()
            {
                return "The window position must be set such that the current window size fits within the console's buffer, and the numbers must not be negative.";
            }
            static /*string */ get InvalidOperation_ConsoleKeyAvailableOnFile()
            {
                return "Cannot see if a key has been pressed when either application does not have a console or when console input has been redirected from a file. Try Console.In.Peek.";
            }
            static /*string */ get ArgumentOutOfRange_ConsoleBufferLessThanWindowSize()
            {
                return "The console buffer size must not be less than the current size and position of the console window, nor greater than or equal to short.MaxValue.";
            }
            static /*string */ get ArgumentOutOfRange_CursorSize()
            {
                return "The cursor size is invalid. It must be a percentage between 1 and 100.";
            }
            static /*string */ get ArgumentOutOfRange_BeepFrequency()
            {
                return "The frequency must be between {0} and {1}.";
            }
            static /*string */ FormatArgumentOutOfRange_BeepFrequency(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The frequency must be between {0} and {1}.", arg1, arg2);
            }
            static /*string */ get ArgumentOutOfRange_IndexCountBuffer()
            {
                return "Index and count must refer to a location within the buffer.";
            }
            static /*string */ get ArgumentOutOfRange_IndexCount()
            {
                return "Index and count must refer to a location within the string.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLess()
            {
                return "Index was out of range. Must be non-negative and less than the size of the collection.";
            }
            static /*string */ get ArgumentOutOfRange_IndexMustBeLessOrEqual()
            {
                return "Index was out of range. Must be non-negative and less than or equal to the size of the collection.";
            }
            static /*string */ get Argument_EncodingConversionOverflowBytes()
            {
                return "The output byte buffer is too small to contain the encoded data, encoding '{0}' fallback '{1}'.";
            }
            static /*string */ FormatArgument_EncodingConversionOverflowBytes(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The output byte buffer is too small to contain the encoded data, encoding '{0}' fallback '{1}'.", arg1, arg2);
            }
            static /*string */ get Argument_EncodingConversionOverflowChars()
            {
                return "The output char buffer is too small to contain the decoded characters, encoding '{0}' fallback '{1}'.";
            }
            static /*string */ FormatArgument_EncodingConversionOverflowChars(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The output char buffer is too small to contain the decoded characters, encoding '{0}' fallback '{1}'.", arg1, arg2);
            }
            static /*string */ get ArgumentOutOfRange_GetByteCountOverflow()
            {
                return "Too many characters. The resulting number of bytes is larger than what can be returned as an int.";
            }
            static /*string */ get ArgumentOutOfRange_GetCharCountOverflow()
            {
                return "Too many bytes. The resulting number of chars is larger than what can be returned as an int.";
            }
            static /*string */ get Argument_InvalidCharSequenceNoIndex()
            {
                return "String contains invalid Unicode code points.";
            }
            static /*string */ get IO_PathTooLong_Path()
            {
                return "The path '{0}' is too long, or a component of the specified path is too long.";
            }
            static /*string */ FormatIO_PathTooLong_Path(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The path '{0}' is too long, or a component of the specified path is too long.", arg1);
            }
            static /*string */ get IO_TermInfoInvalidMagicNumber()
            {
                return "The terminfo database has an invalid magic number: '{0}'.";
            }
            static /*string */ FormatIO_TermInfoInvalidMagicNumber(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The terminfo database has an invalid magic number: '{0}'.", arg1);
            }
            static /*string */ get PlatformNotSupported_SystemConsole()
            {
                return "System.Console is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$scsl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$scsl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$scsl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scsl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$scsl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$scsl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$scsl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1376297;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1376297}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$scsl.System.IO.Error", ($self) => class Error
        {
            static /*Exception */ GetFileNotOpen()
            {
                return new $.$spc.System.ObjectDisposedException().$ctor$15(null, $.$scsl.System.SR.ObjectDisposed_FileClosed);
            }
            static /*Exception */ GetReadNotSupported()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$scsl.System.SR.NotSupported_UnreadableStream);
            }
            static /*Exception */ GetSeekNotSupported()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$scsl.System.SR.NotSupported_UnseekableStream);
            }
            static /*Exception */ GetWriteNotSupported()
            {
                return new $.$spc.System.NotSupportedException().$ctor$10($.$scsl.System.SR.NotSupported_UnwritableStream);
            }
            static $h = 1245225;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":47185921,"n":"GetFileNotOpen","d":1245225,"h":4296212521,"f":40},{"r":47185921,"n":"GetReadNotSupported","d":1245225,"h":8591179817,"f":40},{"r":47185921,"n":"GetSeekNotSupported","d":1245225,"h":12886147113,"f":40},{"r":47185921,"n":"GetWriteNotSupported","d":1245225,"h":17181114409,"f":40}],"h":1245225}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.IO.Error`; }
        });
        
        $asm.$cls("$scsl.System.Text.EncodingExtensions", ($self) => class EncodingExtensions
        {
            static /*Encoding */ RemovePreamble(/*this Encoding*/ encoding)
            {
                if (encoding.Preamble.Length === 0)
                {
                    return encoding;
                }
                return new $.$scsl.System.Text.ConsoleEncoding().$ctor$4(encoding);
            }
            static $h = 1507369;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":121831425,"p":[{"n":"encoding","p":121831425}],"n":"RemovePreamble","d":1507369,"h":4296474665,"f":33}],"h":1507369}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.EncodingExtensions`; }
        });
        
        $asm.$cls("$scsl.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$scsl.Interop.ErrorInfo().$ctor$3(error);
            }
            static $h = 458793;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":196649,"p":[{"n":"error","p":131113}],"n":"Info","d":458793,"h":4295426089,"f":33}],"h":458793}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$scsl.System.ConsolePal", ($self) => class ConsolePal
        {
            /*Encoding?*/ static s_outputEncoding = null;
            static /*void */ EnsureConsoleInitialized()
            {
            }
            static /*Stream */ OpenStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Stream */ OpenStandardOutput()
            {
                return new $.$scsl.System.WasmConsoleStream().$ctor$4($.$scsl.Interop.Sys.Dup($.$scsl.Interop.Sys.FileDescriptors.STDOUT_FILENO), 2/*FileAccess.Write*/);
            }
            static /*Stream */ OpenStandardError()
            {
                return new $.$scsl.System.WasmConsoleStream().$ctor$4($.$scsl.Interop.Sys.Dup($.$scsl.Interop.Sys.FileDescriptors.STDERR_FILENO), 2/*FileAccess.Write*/);
            }
            static /*Encoding */ get InputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetConsoleInputEncoding(/*Encoding*/ enc)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*Encoding */ get OutputEncoding()
            {
                return $.$scsl.System.ConsolePal.s_outputEncoding ?? $.$spc.System.Text.Encoding.UTF8;
            }
            static /*void */ SetConsoleOutputEncoding(/*Encoding*/ enc)
            {
                return $.$scsl.System.ConsolePal.s_outputEncoding = enc;
            }
            static /*bool */ IsInputRedirectedCore()
            {
                return false;
            }
            static /*bool */ IsOutputRedirectedCore()
            {
                return false;
            }
            static /*bool */ IsErrorRedirectedCore()
            {
                return false;
            }
            static /*TextReader */ GetOrCreateReader()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get NumberLock()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get CapsLock()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get KeyAvailable()
            {
                return false;
            }
            static /*ConsoleKeyInfo */ ReadKey(/*bool*/ intercept)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get TreatControlCAsInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set TreatControlCAsInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ get BackgroundColor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ set BackgroundColor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ get ForegroundColor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*ConsoleColor */ set ForegroundColor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ ResetColor()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get CursorSize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set CursorSize(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get CursorVisible()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set CursorVisible(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*(int Left, int Top) */ GetCursorPosition()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ get Title()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ set Title(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Beep()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Beep$1(/*int*/ frequency, /*int*/ duration)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ MoveBufferArea(/*int*/ sourceLeft, /*int*/ sourceTop, /*int*/ sourceWidth, /*int*/ sourceHeight, /*int*/ targetLeft, /*int*/ targetTop, /*char*/ sourceChar, /*ConsoleColor*/ sourceForeColor, /*ConsoleColor*/ sourceBackColor)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetCursorPosition(/*int*/ left, /*int*/ top)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get BufferWidth()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set BufferWidth(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get BufferHeight()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set BufferHeight(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetBufferSize(/*int*/ width, /*int*/ height)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LargestWindowWidth()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LargestWindowHeight()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get WindowLeft()
            {
                return 0;
            }
            static /*int */ set WindowLeft(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get WindowTop()
            {
                return 0;
            }
            static /*int */ set WindowTop(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get WindowWidth()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set WindowWidth(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get WindowHeight()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set WindowHeight(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetWindowPosition(/*int*/ left, /*int*/ top)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ SetWindowSize(/*int*/ width, /*int*/ height)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 983081;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":121831425,"g":{"r":0,"d":0,"h":34360721449,"f":33},"n":"InputEncoding","d":983081,"h":30065754153,"f":33},{"p":121831425,"g":{"r":0,"d":0,"h":47245623337,"f":33},"n":"OutputEncoding","d":983081,"h":42950656041,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":77310394409,"f":33},"n":"NumberLock","d":983081,"h":73015427113,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":85900329001,"f":33},"n":"CapsLock","d":983081,"h":81605361705,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":94490263593,"f":33},"n":"KeyAvailable","d":983081,"h":90195296297,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":107375165481,"f":33},"s":{"r":0,"d":0,"h":111670132777,"f":33},"n":"TreatControlCAsInput","d":983081,"h":103080198185,"f":33},{"p":720937,"g":{"r":0,"d":0,"h":120260067369,"f":33},"s":{"r":0,"d":0,"h":124555034665,"f":33},"n":"BackgroundColor","d":983081,"h":115965100073,"f":33},{"p":720937,"g":{"r":0,"d":0,"h":133144969257,"f":33},"s":{"r":0,"d":0,"h":137439936553,"f":33},"n":"ForegroundColor","d":983081,"h":128850001961,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":150324838441,"f":33},"s":{"r":0,"d":0,"h":154619805737,"f":33},"n":"CursorSize","d":983081,"h":146029871145,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":163209740329,"f":33},"s":{"r":0,"d":0,"h":167504707625,"f":33},"n":"CursorVisible","d":983081,"h":158914773033,"f":33},{"p":1310721,"g":{"r":0,"d":0,"h":180389609513,"f":33},"s":{"r":0,"d":0,"h":184684576809,"f":33},"n":"Title","d":983081,"h":176094642217,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":210454380585,"f":33},"s":{"r":0,"d":0,"h":214749347881,"f":33},"n":"BufferWidth","d":983081,"h":206159413289,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":223339282473,"f":33},"s":{"r":0,"d":0,"h":227634249769,"f":33},"n":"BufferHeight","d":983081,"h":219044315177,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":240519151657,"f":33},"n":"LargestWindowWidth","d":983081,"h":236224184361,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":249109086249,"f":33},"n":"LargestWindowHeight","d":983081,"h":244814118953,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":257699020841,"f":33},"s":{"r":0,"d":0,"h":261993988137,"f":33},"n":"WindowLeft","d":983081,"h":253404053545,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":270583922729,"f":33},"s":{"r":0,"d":0,"h":274878890025,"f":33},"n":"WindowTop","d":983081,"h":266288955433,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":283468824617,"f":33},"s":{"r":0,"d":0,"h":287763791913,"f":33},"n":"WindowWidth","d":983081,"h":279173857321,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":296353726505,"f":33},"s":{"r":0,"d":0,"h":300648693801,"f":33},"n":"WindowHeight","d":983081,"h":292058759209,"f":33}],"m":[{"r":65537,"n":"EnsureConsoleInitialized","d":983081,"h":12885884969,"f":40},{"r":62128129,"n":"OpenStandardInput","d":983081,"h":17180852265,"f":33},{"r":62128129,"n":"OpenStandardOutput","d":983081,"h":21475819561,"f":33},{"r":62128129,"n":"OpenStandardError","d":983081,"h":25770786857,"f":33},{"r":65537,"p":[{"n":"enc","p":121831425}],"n":"SetConsoleInputEncoding","d":983081,"h":38655688745,"f":33},{"r":65537,"p":[{"n":"enc","p":121831425}],"n":"SetConsoleOutputEncoding","d":983081,"h":51540590633,"f":33},{"r":262145,"n":"IsInputRedirectedCore","d":983081,"h":55835557929,"f":33},{"r":262145,"n":"IsOutputRedirectedCore","d":983081,"h":60130525225,"f":33},{"r":262145,"n":"IsErrorRedirectedCore","d":983081,"h":64425492521,"f":33},{"r":62849025,"n":"GetOrCreateReader","d":983081,"h":68720459817,"f":40},{"r":852009,"p":[{"n":"intercept","p":262145}],"n":"ReadKey","d":983081,"h":98785230889,"f":33},{"r":65537,"n":"ResetColor","d":983081,"h":141734903849,"f":33},{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h,"n":"GetCursorPosition","d":983081,"h":171799674921,"f":33},{"r":65537,"n":"Beep","d":983081,"h":188979544105,"f":33},{"r":65537,"p":[{"n":"frequency","p":655361},{"n":"duration","p":655361}],"n":"Beep","o":"@$1","d":983081,"h":193274511401,"f":33},{"r":65537,"p":[{"n":"sourceLeft","p":655361},{"n":"sourceTop","p":655361},{"n":"sourceWidth","p":655361},{"n":"sourceHeight","p":655361},{"n":"targetLeft","p":655361},{"n":"targetTop","p":655361},{"n":"sourceChar","p":458753},{"n":"sourceForeColor","p":720937},{"n":"sourceBackColor","p":720937}],"n":"MoveBufferArea","d":983081,"h":197569478697,"f":33},{"r":65537,"p":[{"n":"left","p":655361},{"n":"top","p":655361}],"n":"SetCursorPosition","d":983081,"h":201864445993,"f":33},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"SetBufferSize","d":983081,"h":231929217065,"f":33},{"r":65537,"p":[{"n":"left","p":655361},{"n":"top","p":655361}],"n":"SetWindowPosition","d":983081,"h":304943661097,"f":33},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"SetWindowSize","d":983081,"h":309238628393,"f":33}],"l":[{"t":121831425,"n":"s_outputEncoding","d":983081,"h":8590917673,"f":34}],"h":983081}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.ConsolePal`; }
        });
        
        $asm.$str("$scsl.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$scsl.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$scsl.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ AppendSpanFormattable(T, /*T*/ value, /*string?*/ format, /*IFormatProvider?*/ provider)
            {
                /*int*/ let charsWritten;
                if ($.$dsp(value, T, ($t) => $t.System$ISpanFormattable$TryFormat, this._chars.Slice(this._pos), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit(format), provider))
                {
                    this._pos += charsWritten;
                }
                else 
                {
                    this.Append$1($.$dsp(value, T, ($t) => $t.System$IFormattable$ToString, format, provider));
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 1572905;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":30066343977,"f":1},"s":{"r":0,"d":0,"h":34361311273,"f":1},"n":"Length","d":1572905,"h":25771376681,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":42951245865,"f":1},"n":"Capacity","d":1572905,"h":38656278569,"f":1},{"p":458753,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":64426082345,"f":1},"n":"Item","o":"@$2","d":1572905,"h":60131115049,"f":1},{"p":$.$spc.System.Span$$($.$spc.System.Char).$h,"g":{"r":0,"d":0,"h":77310984233,"f":1},"n":"RawChars","d":1572905,"h":73016016937,"f":1}],"m":[{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"EnsureCapacity","d":1572905,"h":47246213161,"f":1},{"r":458753,"n":"GetPinnableReference","d":1572905,"h":51541180457,"f":1},{"r":458753,"p":[{"n":"terminate","p":262145}],"n":"GetPinnableReference","o":"@$1","d":1572905,"h":55836147753,"f":1},{"r":1310721,"n":"ToString","d":1572905,"h":68721049641,"f":32769},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"terminate","p":262145}],"n":"AsSpan","d":1572905,"h":81605951529,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"n":"AsSpan","o":"@$1","d":1572905,"h":85900918825,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361}],"n":"AsSpan","o":"@$2","d":1572905,"h":90195886121,"f":1},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"AsSpan","o":"@$3","d":1572905,"h":94490853417,"f":1},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryCopyTo","d":1572905,"h":98785820713,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"value","p":458753},{"n":"count","p":655361}],"n":"Insert","d":1572905,"h":103080788009,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"s","p":1310721}],"n":"Insert","o":"@$1","d":1572905,"h":107375755305,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"Append","d":1572905,"h":111670722601,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"Append","o":"@$1","d":1572905,"h":115965689897,"f":1},{"r":65537,"p":[{"n":"s","p":1310721}],"n":"AppendSlow","d":1572905,"h":120260657193,"f":2},{"r":65537,"p":[{"n":"c","p":458753},{"n":"count","p":655361}],"n":"Append","o":"@$2","d":1572905,"h":124555624489,"f":1},{"r":65537,"p":[{"n":"value","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Append","o":"@$3","d":1572905,"h":128850591785,"f":1},{"r":$.$spc.System.Span$$($.$spc.System.Char).$h,"p":[{"n":"length","p":655361}],"n":"AppendSpan","d":1572905,"h":133145559081,"f":1},{"r":65537,"p":[{"n":"c","p":458753}],"n":"GrowAndAppend","d":1572905,"h":137440526377,"f":2},{"r":65537,"p":[{"n":"additionalCapacityBeyondPos","p":655361}],"n":"Grow","d":1572905,"h":141735493673,"f":2},{"r":65537,"n":"Dispose","d":1572905,"h":146030460969,"f":1},{"r":65537,"p":[{"n":"value","p":146032492544},{"n":"format","p":1310721,"f":65},{"n":"provider","p":57606145,"f":65}],"g":["T"],"n":"AppendSpanFormattable","d":1572905,"h":150325428265,"f":131080}],"l":[{"t":0,"n":"_arrayToReturnToPool","d":1572905,"h":4296540201,"f":2},{"t":$.$spc.System.Span$$($.$spc.System.Char).$h,"n":"_chars","d":1572905,"h":8591507497,"f":2},{"t":655361,"n":"_pos","d":1572905,"h":12886474793,"f":2}],"c":[{"p":[{"n":"initialBuffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h}],"n":".ctor","o":"$ctor$2","d":1572905,"h":17181442089,"f":1},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1572905,"h":21476409385,"f":1},{"n":".ctor","o":"$ctor$4","d":1572905,"h":154620395561,"f":1}],"h":1572905}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$str("$scsl.System.ConsoleKeyInfo", ($self) => class ConsoleKeyInfo extends $.$spc.System.ValueType
        {
            /*char*/  get _keyChar() { return this.$getField(0, $.$spc.System.Char); }
            /*char*/  set _keyChar(value) { this.$setField(0, $.$spc.System.Char, value); }
            /*ConsoleKey*/  get _key() { return this.$getField(2, $.$scsl.System.ConsoleKey); }
            /*ConsoleKey*/  set _key(value) { this.$setField(2, $.$scsl.System.ConsoleKey, value); }
            /*ConsoleModifiers*/  get _mods() { return this.$getField(6, $.$scsl.System.ConsoleModifiers); }
            /*ConsoleModifiers*/  set _mods(value) { this.$setField(6, $.$scsl.System.ConsoleModifiers, value); }
            $ctor$2(/*char*/ keyChar, /*ConsoleKey*/ key, /*bool*/ shift, /*bool*/ alt, /*bool*/ control)
            {
                super.$ctor$1();
                {
                    if ((key) < 0 || (key) > 255)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("key", $.$scsl.System.SR.ArgumentOutOfRange_ConsoleKey);
                    }
                    this._keyChar = keyChar;
                    this._key = key;
                    this._mods = 0;
                    if (shift)
                    {
                        this._mods |= 2/*ConsoleModifiers.Shift*/;
                    }
                    if (alt)
                    {
                        this._mods |= 1/*ConsoleModifiers.Alt*/;
                    }
                    if (control)
                    {
                        this._mods |= 4/*ConsoleModifiers.Control*/;
                    }
                }
                return this;
            }
            /*char */ get KeyChar()
            {
                return this._keyChar;
            }
            /*ConsoleKey */ get Key()
            {
                return this._key;
            }
            /*ConsoleModifiers */ get Modifiers()
            {
                return this._mods;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ value)
            {
                let info;
                return $.$is(value, $.$scsl.System.ConsoleKeyInfo, { set $v(v){ info = v; } }) && this.Equals$2(info);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$scsl.System.ConsoleKeyInfo.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*ConsoleKeyInfo*/ obj)
            {
                return obj._keyChar === this._keyChar && obj._key === this._key && obj._mods === this._mods;
            }
            static /*bool */ op_Equality(/*ConsoleKeyInfo*/ a, /*ConsoleKeyInfo*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*ConsoleKeyInfo*/ a, /*ConsoleKeyInfo*/ b)
            {
                return !($.$scsl.System.ConsoleKeyInfo.op_Equality(a, b));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._keyChar | (this._key << 16) | (this._mods << 24);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$scsl.System.ConsoleKeyInfo.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.ConsoleKeyInfo>.Equals(System.ConsoleKeyInfo)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._keyChar = this._keyChar;
                copy._key = this._key;
                copy._mods = this._mods;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._keyChar = 0;
                this._key = 0;
                this._mods = 0;
            }
            static $h = 852009;
            static $z = 10;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":458753,"g":{"r":0,"d":0,"h":25770655785,"f":1},"n":"KeyChar","d":852009,"h":21475688489,"f":1},{"p":786473,"g":{"r":0,"d":0,"h":34360590377,"f":1},"n":"Key","d":852009,"h":30065623081,"f":1},{"p":917545,"g":{"r":0,"d":0,"h":42950524969,"f":1},"n":"Modifiers","d":852009,"h":38655557673,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":131073}],"n":"Equals","d":852009,"h":47245492265,"f":32769},{"r":262145,"p":[{"n":"obj","p":852009}],"n":"Equals","o":"@$2","d":852009,"h":51540459561,"f":1},{"r":655361,"n":"GetHashCode","d":852009,"h":64425361449,"f":32769}],"l":[{"t":458753,"n":"_keyChar","d":852009,"h":4295819305,"f":2},{"t":786473,"n":"_key","d":852009,"h":8590786601,"f":2},{"t":917545,"n":"_mods","d":852009,"h":12885753897,"f":2}],"c":[{"p":[{"n":"keyChar","p":458753},{"n":"key","p":786473},{"n":"shift","p":262145},{"n":"alt","p":262145},{"n":"control","p":262145}],"n":".ctor","o":"$ctor$2","d":852009,"h":17180721193,"f":1},{"n":".ctor","o":"$ctor$3","d":852009,"h":68720328745,"f":1}],"i":[$.$spc.System.IEquatable$$($.$scsl.System.ConsoleKeyInfo).$h],"h":852009}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$scsl.System.ConsoleKeyInfo) ]; }
            static get $fullName() { return `System.ConsoleKeyInfo`; }
        });
        
        $asm.$cls("$scsl.System.Text.ConsoleEncoding", ($self) => class ConsoleEncoding extends $.$spc.System.Text.Encoding
        {
            /*Encoding*/ _encoding = null;
            $ctor$4(/*Encoding*/ encoding)
            {
                super.$ctor$1();
                {
                    this._encoding = encoding;
                }
                return this;
            }
            /*byte[] */ GetPreamble()
            {
                return $.$spc.System.Array.Empty($.$spc.System.Byte);
            }
            /*int */ get CodePage()
            {
                return this._encoding.CodePage;
            }
            /*bool */ get IsSingleByte()
            {
                return this._encoding.IsSingleByte;
            }
            /*string */ get EncodingName()
            {
                return this._encoding.EncodingName;
            }
            /*string */ get WebName()
            {
                return this._encoding.WebName;
            }
            /*int */ GetByteCount(/*char[]*/ chars)
            {
                return this._encoding.GetByteCount(chars);
            }
            /*int */ GetByteCount$4(/*char**/ chars, /*int*/ count)
            {
                return this._encoding.GetByteCount$4(chars, count);
            }
            /*int */ GetByteCount$2(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return this._encoding.GetByteCount$2(chars, index, count);
            }
            /*int */ GetByteCount$1(/*string*/ s)
            {
                return this._encoding.GetByteCount$1(s);
            }
            /*int */ GetBytes$6(/*char**/ chars, /*int*/ charCount, /*byte**/ bytes, /*int*/ byteCount)
            {
                return this._encoding.GetBytes$6(chars, charCount, bytes, byteCount);
            }
            /*byte[] */ GetBytes(/*char[]*/ chars)
            {
                return this._encoding.GetBytes(chars);
            }
            /*byte[] */ GetBytes$1(/*char[]*/ chars, /*int*/ index, /*int*/ count)
            {
                return this._encoding.GetBytes$1(chars, index, count);
            }
            /*int */ GetBytes$2(/*char[]*/ chars, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return this._encoding.GetBytes$2(chars, charIndex, charCount, bytes, byteIndex);
            }
            /*byte[] */ GetBytes$3(/*string*/ s)
            {
                return this._encoding.GetBytes$3(s);
            }
            /*int */ GetBytes$5(/*string*/ s, /*int*/ charIndex, /*int*/ charCount, /*byte[]*/ bytes, /*int*/ byteIndex)
            {
                return this._encoding.GetBytes$5(s, charIndex, charCount, bytes, byteIndex);
            }
            /*int */ GetCharCount$2(/*byte**/ bytes, /*int*/ count)
            {
                return this._encoding.GetCharCount$2(bytes, count);
            }
            /*int */ GetCharCount(/*byte[]*/ bytes)
            {
                return this._encoding.GetCharCount(bytes);
            }
            /*int */ GetCharCount$1(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                return this._encoding.GetCharCount$1(bytes, index, count);
            }
            /*int */ GetChars$3(/*byte**/ bytes, /*int*/ byteCount, /*char**/ chars, /*int*/ charCount)
            {
                return this._encoding.GetChars$3(bytes, byteCount, chars, charCount);
            }
            /*char[] */ GetChars(/*byte[]*/ bytes)
            {
                return this._encoding.GetChars(bytes);
            }
            /*char[] */ GetChars$1(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                return this._encoding.GetChars$1(bytes, index, count);
            }
            /*int */ GetChars$2(/*byte[]*/ bytes, /*int*/ byteIndex, /*int*/ byteCount, /*char[]*/ chars, /*int*/ charIndex)
            {
                return this._encoding.GetChars$2(bytes, byteIndex, byteCount, chars, charIndex);
            }
            /*Decoder */ GetDecoder()
            {
                return this._encoding.GetDecoder();
            }
            /*Encoder */ GetEncoder()
            {
                return this._encoding.GetEncoder();
            }
            /*int */ GetMaxByteCount(/*int*/ charCount)
            {
                return this._encoding.GetMaxByteCount(charCount);
            }
            /*int */ GetMaxCharCount(/*int*/ byteCount)
            {
                return this._encoding.GetMaxCharCount(byteCount);
            }
            /*string */ GetString$2(/*byte[]*/ bytes)
            {
                return this._encoding.GetString$2(bytes);
            }
            /*string */ GetString$3(/*byte[]*/ bytes, /*int*/ index, /*int*/ count)
            {
                return this._encoding.GetString$3(bytes, index, count);
            }
            static $h = 1441833;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":121831425,"p":[{"p":655361,"g":{"r":0,"d":0,"h":21476278313,"f":32769},"n":"CodePage","d":1441833,"h":17181311017,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30066212905,"f":32769},"n":"IsSingleByte","d":1441833,"h":25771245609,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":38656147497,"f":32769},"n":"EncodingName","d":1441833,"h":34361180201,"f":32769},{"p":1310721,"g":{"r":0,"d":0,"h":47246082089,"f":32769},"n":"WebName","d":1441833,"h":42951114793,"f":32769}],"m":[{"r":0,"n":"GetPreamble","d":1441833,"h":12886343721,"f":32769},{"r":655361,"p":[{"n":"chars","p":0}],"n":"GetByteCount","d":1441833,"h":51541049385,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$4","d":1441833,"h":55836016681,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetByteCount","o":"@$2","d":1441833,"h":60130983977,"f":32769},{"r":655361,"p":[{"n":"s","p":1310721}],"n":"GetByteCount","o":"@$1","d":1441833,"h":64425951273,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteCount","p":655361}],"n":"GetBytes","o":"@$6","d":1441833,"h":68720918569,"f":32769},{"r":0,"p":[{"n":"chars","p":0}],"n":"GetBytes","d":1441833,"h":73015885865,"f":32769},{"r":0,"p":[{"n":"chars","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetBytes","o":"@$1","d":1441833,"h":77310853161,"f":32769},{"r":655361,"p":[{"n":"chars","p":0},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteIndex","p":655361}],"n":"GetBytes","o":"@$2","d":1441833,"h":81605820457,"f":32769},{"r":0,"p":[{"n":"s","p":1310721}],"n":"GetBytes","o":"@$3","d":1441833,"h":85900787753,"f":32769},{"r":655361,"p":[{"n":"s","p":1310721},{"n":"charIndex","p":655361},{"n":"charCount","p":655361},{"n":"bytes","p":0},{"n":"byteIndex","p":655361}],"n":"GetBytes","o":"@$5","d":1441833,"h":90195755049,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$2","d":1441833,"h":94490722345,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0}],"n":"GetCharCount","d":1441833,"h":98785689641,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetCharCount","o":"@$1","d":1441833,"h":103080656937,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charCount","p":655361}],"n":"GetChars","o":"@$3","d":1441833,"h":107375624233,"f":32769},{"r":0,"p":[{"n":"bytes","p":0}],"n":"GetChars","d":1441833,"h":111670591529,"f":32769},{"r":0,"p":[{"n":"bytes","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetChars","o":"@$1","d":1441833,"h":115965558825,"f":32769},{"r":655361,"p":[{"n":"bytes","p":0},{"n":"byteIndex","p":655361},{"n":"byteCount","p":655361},{"n":"chars","p":0},{"n":"charIndex","p":655361}],"n":"GetChars","o":"@$2","d":1441833,"h":120260526121,"f":32769},{"r":120520705,"n":"GetDecoder","d":1441833,"h":124555493417,"f":32769},{"r":121110529,"n":"GetEncoder","d":1441833,"h":128850460713,"f":32769},{"r":655361,"p":[{"n":"charCount","p":655361}],"n":"GetMaxByteCount","d":1441833,"h":133145428009,"f":32769},{"r":655361,"p":[{"n":"byteCount","p":655361}],"n":"GetMaxCharCount","d":1441833,"h":137440395305,"f":32769},{"r":1310721,"p":[{"n":"bytes","p":0}],"n":"GetString","o":"@$2","d":1441833,"h":141735362601,"f":32769},{"r":1310721,"p":[{"n":"bytes","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"GetString","o":"@$3","d":1441833,"h":146030329897,"f":32769}],"l":[{"t":121831425,"n":"_encoding","d":1441833,"h":4296409129,"f":2}],"c":[{"p":[{"n":"encoding","p":121831425}],"n":".ctor","o":"$ctor$4","d":1441833,"h":8591376425,"f":8}],"i":[57147393],"h":1441833}; }
            static get $b() { return $.$spc.System.Text.Encoding; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable ]; }
            static get $fullName() { return `System.Text.ConsoleEncoding`; }
        });
        
        $asm.$cls("$scsl.System.IO.SyncTextReader", ($self) => class SyncTextReader extends $.$spc.System.IO.TextReader
        {
            /*TextReader*/ _in = null;
            static /*SyncTextReader */ GetSynchronizedTextReader(/*TextReader*/ reader)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(reader !== null, "reader != null");
                return $.$as(reader, $.$scsl.System.IO.SyncTextReader) ?? new $.$scsl.System.IO.SyncTextReader().$ctor$3(reader);
            }
            $ctor$3(/*TextReader*/ t)
            {
                super.$ctor$2();
                {
                    this._in = t;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            this._in.Dispose();
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
            }
            /*int */ Peek()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.Peek();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*int */ Read()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.Read();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*int */ Read$1(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.Read$1(buffer, index, count);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*int */ ReadBlock(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.ReadBlock(buffer, index, count);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*string? */ ReadLine()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.ReadLine();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*string */ ReadToEnd()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        return this._in.ReadToEnd();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*Task<string?> */ ReadLineAsync()
            {
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.String, this.ReadLine());
            }
            /*ValueTask<string?> */ ReadLineAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.ValueTask.FromCanceled$1($.$spc.System.String, cancellationToken) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.String))().$ctor$2(this.ReadLine());
            }
            /*Task<string> */ ReadToEndAsync()
            {
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.String, this.ReadToEnd());
            }
            /*Task<string> */ ReadToEndAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return cancellationToken.IsCancellationRequested ? $.$spc.System.Threading.Tasks.Task.FromCanceled$1($.$spc.System.String, cancellationToken) : $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.String, this.ReadToEnd());
            }
            /*Task<int> */ ReadBlockAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(buffer, "buffer");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, count, "count");
                if (((buffer.length - index) | 0) < count)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scsl.System.SR.Argument_InvalidOffLen);
                }
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Int32, this.ReadBlock(buffer, index, count));
            }
            /*Task<int> */ ReadAsync(/*char[]*/ buffer, /*int*/ index, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(buffer, "buffer");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, count, "count");
                if (((buffer.length - index) | 0) < count)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$scsl.System.SR.Argument_InvalidOffLen);
                }
                return $.$spc.System.Threading.Tasks.Task.FromResult($.$spc.System.Int32, this.Read$1(buffer, index, count));
            }
            static $h = 1310761;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62849025,"m":[{"r":1310761,"p":[{"n":"reader","p":62849025}],"n":"GetSynchronizedTextReader","d":1310761,"h":8591245353,"f":33},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1310761,"h":17181179945,"f":32772},{"r":655361,"n":"Peek","d":1310761,"h":21476147241,"f":32769},{"r":655361,"n":"Read","d":1310761,"h":25771114537,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"Read","o":"@$1","d":1310761,"h":30066081833,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ReadBlock","d":1310761,"h":34361049129,"f":32769},{"r":1310721,"n":"ReadLine","d":1310761,"h":38656016425,"f":32769},{"r":1310721,"n":"ReadToEnd","d":1310761,"h":42950983721,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.String).$h,"n":"ReadLineAsync","d":1310761,"h":47245951017,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.String).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadLineAsync","o":"@$1","d":1310761,"h":51540918313,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.String).$h,"n":"ReadToEndAsync","d":1310761,"h":55835885609,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.String).$h,"p":[{"n":"cancellationToken","p":125960193}],"n":"ReadToEndAsync","o":"@$1","d":1310761,"h":60130852905,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ReadBlockAsync","d":1310761,"h":64425820201,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"index","p":655361},{"n":"count","p":655361}],"n":"ReadAsync","d":1310761,"h":68720787497,"f":32769}],"l":[{"t":62849025,"n":"_in","d":1310761,"h":4296278057,"f":8}],"c":[{"p":[{"n":"t","p":62849025}],"n":".ctor","o":"$ctor$3","d":1310761,"h":12886212649,"f":8}],"i":[57475073],"h":1310761}; }
            static get $b() { return $.$spc.System.IO.TextReader; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.IO.SyncTextReader`; }
        });
        
        $asm.$str("$scsl.System.ConsoleColor", ($self) => class ConsoleColor extends $.$spc.System.Enum
        {
            static Black = 0;
            static DarkBlue = 1;
            static DarkGreen = 2;
            static DarkCyan = 3;
            static DarkRed = 4;
            static DarkMagenta = 5;
            static DarkYellow = 6;
            static Gray = 7;
            static DarkGray = 8;
            static Blue = 9;
            static Green = 10;
            static Cyan = 11;
            static Red = 12;
            static Magenta = 13;
            static Yellow = 14;
            static White = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Black": 0n,
                    "DarkBlue": 1n,
                    "DarkGreen": 2n,
                    "DarkCyan": 3n,
                    "DarkRed": 4n,
                    "DarkMagenta": 5n,
                    "DarkYellow": 6n,
                    "Gray": 7n,
                    "DarkGray": 8n,
                    "Blue": 9n,
                    "Green": 10n,
                    "Cyan": 11n,
                    "Red": 12n,
                    "Magenta": 13n,
                    "Yellow": 14n,
                    "White": 15n
                };
            }
            static $h = 720937;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":720937,"n":"Black","d":720937,"h":4295688233,"f":33},{"t":720937,"n":"DarkBlue","d":720937,"h":8590655529,"f":33},{"t":720937,"n":"DarkGreen","d":720937,"h":12885622825,"f":33},{"t":720937,"n":"DarkCyan","d":720937,"h":17180590121,"f":33},{"t":720937,"n":"DarkRed","d":720937,"h":21475557417,"f":33},{"t":720937,"n":"DarkMagenta","d":720937,"h":25770524713,"f":33},{"t":720937,"n":"DarkYellow","d":720937,"h":30065492009,"f":33},{"t":720937,"n":"Gray","d":720937,"h":34360459305,"f":33},{"t":720937,"n":"DarkGray","d":720937,"h":38655426601,"f":33},{"t":720937,"n":"Blue","d":720937,"h":42950393897,"f":33},{"t":720937,"n":"Green","d":720937,"h":47245361193,"f":33},{"t":720937,"n":"Cyan","d":720937,"h":51540328489,"f":33},{"t":720937,"n":"Red","d":720937,"h":55835295785,"f":33},{"t":720937,"n":"Magenta","d":720937,"h":60130263081,"f":33},{"t":720937,"n":"Yellow","d":720937,"h":64425230377,"f":33},{"t":720937,"n":"White","d":720937,"h":68720197673,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":720937,"h":73015164969,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":720937}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleColor`; }
        });
        
        $asm.$str("$scsl.System.ConsoleSpecialKey", ($self) => class ConsoleSpecialKey extends $.$spc.System.Enum
        {
            static ControlC = 0;
            static ControlBreak = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ControlC": 0n,
                    "ControlBreak": 1n
                };
            }
            static $h = 1048617;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1048617,"n":"ControlC","d":1048617,"h":4296015913,"f":33},{"t":1048617,"n":"ControlBreak","d":1048617,"h":8590983209,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1048617,"h":12885950505,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1048617}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleSpecialKey`; }
        });
        
        $asm.$str("$scsl.System.ConsoleKey", ($self) => class ConsoleKey extends $.$spc.System.Enum
        {
            static None = 0;
            static Backspace = 8;
            static Tab = 9;
            static Clear = 12;
            static Enter = 13;
            static Pause = 19;
            static Escape = 27;
            static Spacebar = 32;
            static PageUp = 33;
            static PageDown = 34;
            static End = 35;
            static Home = 36;
            static LeftArrow = 37;
            static UpArrow = 38;
            static RightArrow = 39;
            static DownArrow = 40;
            static Select = 41;
            static Print = 42;
            static Execute = 43;
            static PrintScreen = 44;
            static Insert = 45;
            static Delete = 46;
            static Help = 47;
            static D0 = 48;
            static D1 = 49;
            static D2 = 50;
            static D3 = 51;
            static D4 = 52;
            static D5 = 53;
            static D6 = 54;
            static D7 = 55;
            static D8 = 56;
            static D9 = 57;
            static A = 65;
            static B = 66;
            static C = 67;
            static D = 68;
            static E = 69;
            static F = 70;
            static G = 71;
            static H = 72;
            static I = 73;
            static J = 74;
            static K = 75;
            static L = 76;
            static M = 77;
            static N = 78;
            static O = 79;
            static P = 80;
            static Q = 81;
            static R = 82;
            static S = 83;
            static T = 84;
            static U = 85;
            static V = 86;
            static W = 87;
            static X = 88;
            static Y = 89;
            static Z = 90;
            static LeftWindows = 91;
            static RightWindows = 92;
            static Applications = 93;
            static Sleep = 95;
            static NumPad0 = 96;
            static NumPad1 = 97;
            static NumPad2 = 98;
            static NumPad3 = 99;
            static NumPad4 = 100;
            static NumPad5 = 101;
            static NumPad6 = 102;
            static NumPad7 = 103;
            static NumPad8 = 104;
            static NumPad9 = 105;
            static Multiply = 106;
            static Add = 107;
            static Separator = 108;
            static Subtract = 109;
            static Decimal = 110;
            static Divide = 111;
            static F1 = 112;
            static F2 = 113;
            static F3 = 114;
            static F4 = 115;
            static F5 = 116;
            static F6 = 117;
            static F7 = 118;
            static F8 = 119;
            static F9 = 120;
            static F10 = 121;
            static F11 = 122;
            static F12 = 123;
            static F13 = 124;
            static F14 = 125;
            static F15 = 126;
            static F16 = 127;
            static F17 = 128;
            static F18 = 129;
            static F19 = 130;
            static F20 = 131;
            static F21 = 132;
            static F22 = 133;
            static F23 = 134;
            static F24 = 135;
            static BrowserBack = 166;
            static BrowserForward = 167;
            static BrowserRefresh = 168;
            static BrowserStop = 169;
            static BrowserSearch = 170;
            static BrowserFavorites = 171;
            static BrowserHome = 172;
            static VolumeMute = 173;
            static VolumeDown = 174;
            static VolumeUp = 175;
            static MediaNext = 176;
            static MediaPrevious = 177;
            static MediaStop = 178;
            static MediaPlay = 179;
            static LaunchMail = 180;
            static LaunchMediaSelect = 181;
            static LaunchApp1 = 182;
            static LaunchApp2 = 183;
            static Oem1 = 186;
            static OemPlus = 187;
            static OemComma = 188;
            static OemMinus = 189;
            static OemPeriod = 190;
            static Oem2 = 191;
            static Oem3 = 192;
            static Oem4 = 219;
            static Oem5 = 220;
            static Oem6 = 221;
            static Oem7 = 222;
            static Oem8 = 223;
            static Oem102 = 226;
            static Process = 229;
            static Packet = 231;
            static Attention = 246;
            static CrSel = 247;
            static ExSel = 248;
            static EraseEndOfFile = 249;
            static Play = 250;
            static Zoom = 251;
            static NoName = 252;
            static Pa1 = 253;
            static OemClear = 254;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Backspace": 8n,
                    "Tab": 9n,
                    "Clear": 12n,
                    "Enter": 13n,
                    "Pause": 19n,
                    "Escape": 27n,
                    "Spacebar": 32n,
                    "PageUp": 33n,
                    "PageDown": 34n,
                    "End": 35n,
                    "Home": 36n,
                    "LeftArrow": 37n,
                    "UpArrow": 38n,
                    "RightArrow": 39n,
                    "DownArrow": 40n,
                    "Select": 41n,
                    "Print": 42n,
                    "Execute": 43n,
                    "PrintScreen": 44n,
                    "Insert": 45n,
                    "Delete": 46n,
                    "Help": 47n,
                    "D0": 48n,
                    "D1": 49n,
                    "D2": 50n,
                    "D3": 51n,
                    "D4": 52n,
                    "D5": 53n,
                    "D6": 54n,
                    "D7": 55n,
                    "D8": 56n,
                    "D9": 57n,
                    "A": 65n,
                    "B": 66n,
                    "C": 67n,
                    "D": 68n,
                    "E": 69n,
                    "F": 70n,
                    "G": 71n,
                    "H": 72n,
                    "I": 73n,
                    "J": 74n,
                    "K": 75n,
                    "L": 76n,
                    "M": 77n,
                    "N": 78n,
                    "O": 79n,
                    "P": 80n,
                    "Q": 81n,
                    "R": 82n,
                    "S": 83n,
                    "T": 84n,
                    "U": 85n,
                    "V": 86n,
                    "W": 87n,
                    "X": 88n,
                    "Y": 89n,
                    "Z": 90n,
                    "LeftWindows": 91n,
                    "RightWindows": 92n,
                    "Applications": 93n,
                    "Sleep": 95n,
                    "NumPad0": 96n,
                    "NumPad1": 97n,
                    "NumPad2": 98n,
                    "NumPad3": 99n,
                    "NumPad4": 100n,
                    "NumPad5": 101n,
                    "NumPad6": 102n,
                    "NumPad7": 103n,
                    "NumPad8": 104n,
                    "NumPad9": 105n,
                    "Multiply": 106n,
                    "Add": 107n,
                    "Separator": 108n,
                    "Subtract": 109n,
                    "Decimal": 110n,
                    "Divide": 111n,
                    "F1": 112n,
                    "F2": 113n,
                    "F3": 114n,
                    "F4": 115n,
                    "F5": 116n,
                    "F6": 117n,
                    "F7": 118n,
                    "F8": 119n,
                    "F9": 120n,
                    "F10": 121n,
                    "F11": 122n,
                    "F12": 123n,
                    "F13": 124n,
                    "F14": 125n,
                    "F15": 126n,
                    "F16": 127n,
                    "F17": 128n,
                    "F18": 129n,
                    "F19": 130n,
                    "F20": 131n,
                    "F21": 132n,
                    "F22": 133n,
                    "F23": 134n,
                    "F24": 135n,
                    "BrowserBack": 166n,
                    "BrowserForward": 167n,
                    "BrowserRefresh": 168n,
                    "BrowserStop": 169n,
                    "BrowserSearch": 170n,
                    "BrowserFavorites": 171n,
                    "BrowserHome": 172n,
                    "VolumeMute": 173n,
                    "VolumeDown": 174n,
                    "VolumeUp": 175n,
                    "MediaNext": 176n,
                    "MediaPrevious": 177n,
                    "MediaStop": 178n,
                    "MediaPlay": 179n,
                    "LaunchMail": 180n,
                    "LaunchMediaSelect": 181n,
                    "LaunchApp1": 182n,
                    "LaunchApp2": 183n,
                    "Oem1": 186n,
                    "OemPlus": 187n,
                    "OemComma": 188n,
                    "OemMinus": 189n,
                    "OemPeriod": 190n,
                    "Oem2": 191n,
                    "Oem3": 192n,
                    "Oem4": 219n,
                    "Oem5": 220n,
                    "Oem6": 221n,
                    "Oem7": 222n,
                    "Oem8": 223n,
                    "Oem102": 226n,
                    "Process": 229n,
                    "Packet": 231n,
                    "Attention": 246n,
                    "CrSel": 247n,
                    "ExSel": 248n,
                    "EraseEndOfFile": 249n,
                    "Play": 250n,
                    "Zoom": 251n,
                    "NoName": 252n,
                    "Pa1": 253n,
                    "OemClear": 254n
                };
            }
            static $h = 786473;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":786473,"n":"None","d":786473,"h":4295753769,"f":33},{"t":786473,"n":"Backspace","d":786473,"h":8590721065,"f":33},{"t":786473,"n":"Tab","d":786473,"h":12885688361,"f":33},{"t":786473,"n":"Clear","d":786473,"h":17180655657,"f":33},{"t":786473,"n":"Enter","d":786473,"h":21475622953,"f":33},{"t":786473,"n":"Pause","d":786473,"h":25770590249,"f":33},{"t":786473,"n":"Escape","d":786473,"h":30065557545,"f":33},{"t":786473,"n":"Spacebar","d":786473,"h":34360524841,"f":33},{"t":786473,"n":"PageUp","d":786473,"h":38655492137,"f":33},{"t":786473,"n":"PageDown","d":786473,"h":42950459433,"f":33},{"t":786473,"n":"End","d":786473,"h":47245426729,"f":33},{"t":786473,"n":"Home","d":786473,"h":51540394025,"f":33},{"t":786473,"n":"LeftArrow","d":786473,"h":55835361321,"f":33},{"t":786473,"n":"UpArrow","d":786473,"h":60130328617,"f":33},{"t":786473,"n":"RightArrow","d":786473,"h":64425295913,"f":33},{"t":786473,"n":"DownArrow","d":786473,"h":68720263209,"f":33},{"t":786473,"n":"Select","d":786473,"h":73015230505,"f":33},{"t":786473,"n":"Print","d":786473,"h":77310197801,"f":33},{"t":786473,"n":"Execute","d":786473,"h":81605165097,"f":33},{"t":786473,"n":"PrintScreen","d":786473,"h":85900132393,"f":33},{"t":786473,"n":"Insert","d":786473,"h":90195099689,"f":33},{"t":786473,"n":"Delete","d":786473,"h":94490066985,"f":33},{"t":786473,"n":"Help","d":786473,"h":98785034281,"f":33},{"t":786473,"n":"D0","d":786473,"h":103080001577,"f":33},{"t":786473,"n":"D1","d":786473,"h":107374968873,"f":33},{"t":786473,"n":"D2","d":786473,"h":111669936169,"f":33},{"t":786473,"n":"D3","d":786473,"h":115964903465,"f":33},{"t":786473,"n":"D4","d":786473,"h":120259870761,"f":33},{"t":786473,"n":"D5","d":786473,"h":124554838057,"f":33},{"t":786473,"n":"D6","d":786473,"h":128849805353,"f":33},{"t":786473,"n":"D7","d":786473,"h":133144772649,"f":33},{"t":786473,"n":"D8","d":786473,"h":137439739945,"f":33},{"t":786473,"n":"D9","d":786473,"h":141734707241,"f":33},{"t":786473,"n":"A","d":786473,"h":146029674537,"f":33},{"t":786473,"n":"B","d":786473,"h":150324641833,"f":33},{"t":786473,"n":"C","d":786473,"h":154619609129,"f":33},{"t":786473,"n":"D","d":786473,"h":158914576425,"f":33},{"t":786473,"n":"E","d":786473,"h":163209543721,"f":33},{"t":786473,"n":"F","d":786473,"h":167504511017,"f":33},{"t":786473,"n":"G","d":786473,"h":171799478313,"f":33},{"t":786473,"n":"H","d":786473,"h":176094445609,"f":33},{"t":786473,"n":"I","d":786473,"h":180389412905,"f":33},{"t":786473,"n":"J","d":786473,"h":184684380201,"f":33},{"t":786473,"n":"K","d":786473,"h":188979347497,"f":33},{"t":786473,"n":"L","d":786473,"h":193274314793,"f":33},{"t":786473,"n":"M","d":786473,"h":197569282089,"f":33},{"t":786473,"n":"N","d":786473,"h":201864249385,"f":33},{"t":786473,"n":"O","d":786473,"h":206159216681,"f":33},{"t":786473,"n":"P","d":786473,"h":210454183977,"f":33},{"t":786473,"n":"Q","d":786473,"h":214749151273,"f":33},{"t":786473,"n":"R","d":786473,"h":219044118569,"f":33},{"t":786473,"n":"S","d":786473,"h":223339085865,"f":33},{"t":786473,"n":"T","d":786473,"h":227634053161,"f":33},{"t":786473,"n":"U","d":786473,"h":231929020457,"f":33},{"t":786473,"n":"V","d":786473,"h":236223987753,"f":33},{"t":786473,"n":"W","d":786473,"h":240518955049,"f":33},{"t":786473,"n":"X","d":786473,"h":244813922345,"f":33},{"t":786473,"n":"Y","d":786473,"h":249108889641,"f":33},{"t":786473,"n":"Z","d":786473,"h":253403856937,"f":33},{"t":786473,"n":"LeftWindows","d":786473,"h":257698824233,"f":33},{"t":786473,"n":"RightWindows","d":786473,"h":261993791529,"f":33},{"t":786473,"n":"Applications","d":786473,"h":266288758825,"f":33},{"t":786473,"n":"Sleep","d":786473,"h":270583726121,"f":33},{"t":786473,"n":"NumPad0","d":786473,"h":274878693417,"f":33},{"t":786473,"n":"NumPad1","d":786473,"h":279173660713,"f":33},{"t":786473,"n":"NumPad2","d":786473,"h":283468628009,"f":33},{"t":786473,"n":"NumPad3","d":786473,"h":287763595305,"f":33},{"t":786473,"n":"NumPad4","d":786473,"h":292058562601,"f":33},{"t":786473,"n":"NumPad5","d":786473,"h":296353529897,"f":33},{"t":786473,"n":"NumPad6","d":786473,"h":300648497193,"f":33},{"t":786473,"n":"NumPad7","d":786473,"h":304943464489,"f":33},{"t":786473,"n":"NumPad8","d":786473,"h":309238431785,"f":33},{"t":786473,"n":"NumPad9","d":786473,"h":313533399081,"f":33},{"t":786473,"n":"Multiply","d":786473,"h":317828366377,"f":33},{"t":786473,"n":"Add","d":786473,"h":322123333673,"f":33},{"t":786473,"n":"Separator","d":786473,"h":326418300969,"f":33},{"t":786473,"n":"Subtract","d":786473,"h":330713268265,"f":33},{"t":786473,"n":"Decimal","d":786473,"h":335008235561,"f":33},{"t":786473,"n":"Divide","d":786473,"h":339303202857,"f":33},{"t":786473,"n":"F1","d":786473,"h":343598170153,"f":33},{"t":786473,"n":"F2","d":786473,"h":347893137449,"f":33},{"t":786473,"n":"F3","d":786473,"h":352188104745,"f":33},{"t":786473,"n":"F4","d":786473,"h":356483072041,"f":33},{"t":786473,"n":"F5","d":786473,"h":360778039337,"f":33},{"t":786473,"n":"F6","d":786473,"h":365073006633,"f":33},{"t":786473,"n":"F7","d":786473,"h":369367973929,"f":33},{"t":786473,"n":"F8","d":786473,"h":373662941225,"f":33},{"t":786473,"n":"F9","d":786473,"h":377957908521,"f":33},{"t":786473,"n":"F10","d":786473,"h":382252875817,"f":33},{"t":786473,"n":"F11","d":786473,"h":386547843113,"f":33},{"t":786473,"n":"F12","d":786473,"h":390842810409,"f":33},{"t":786473,"n":"F13","d":786473,"h":395137777705,"f":33},{"t":786473,"n":"F14","d":786473,"h":399432745001,"f":33},{"t":786473,"n":"F15","d":786473,"h":403727712297,"f":33},{"t":786473,"n":"F16","d":786473,"h":408022679593,"f":33},{"t":786473,"n":"F17","d":786473,"h":412317646889,"f":33},{"t":786473,"n":"F18","d":786473,"h":416612614185,"f":33},{"t":786473,"n":"F19","d":786473,"h":420907581481,"f":33},{"t":786473,"n":"F20","d":786473,"h":425202548777,"f":33},{"t":786473,"n":"F21","d":786473,"h":429497516073,"f":33},{"t":786473,"n":"F22","d":786473,"h":433792483369,"f":33},{"t":786473,"n":"F23","d":786473,"h":438087450665,"f":33},{"t":786473,"n":"F24","d":786473,"h":442382417961,"f":33},{"t":786473,"n":"BrowserBack","d":786473,"h":446677385257,"f":33},{"t":786473,"n":"BrowserForward","d":786473,"h":450972352553,"f":33},{"t":786473,"n":"BrowserRefresh","d":786473,"h":455267319849,"f":33},{"t":786473,"n":"BrowserStop","d":786473,"h":459562287145,"f":33},{"t":786473,"n":"BrowserSearch","d":786473,"h":463857254441,"f":33},{"t":786473,"n":"BrowserFavorites","d":786473,"h":468152221737,"f":33},{"t":786473,"n":"BrowserHome","d":786473,"h":472447189033,"f":33},{"t":786473,"n":"VolumeMute","d":786473,"h":476742156329,"f":33},{"t":786473,"n":"VolumeDown","d":786473,"h":481037123625,"f":33},{"t":786473,"n":"VolumeUp","d":786473,"h":485332090921,"f":33},{"t":786473,"n":"MediaNext","d":786473,"h":489627058217,"f":33},{"t":786473,"n":"MediaPrevious","d":786473,"h":493922025513,"f":33},{"t":786473,"n":"MediaStop","d":786473,"h":498216992809,"f":33},{"t":786473,"n":"MediaPlay","d":786473,"h":502511960105,"f":33},{"t":786473,"n":"LaunchMail","d":786473,"h":506806927401,"f":33},{"t":786473,"n":"LaunchMediaSelect","d":786473,"h":511101894697,"f":33},{"t":786473,"n":"LaunchApp1","d":786473,"h":515396861993,"f":33},{"t":786473,"n":"LaunchApp2","d":786473,"h":519691829289,"f":33},{"t":786473,"n":"Oem1","d":786473,"h":523986796585,"f":33},{"t":786473,"n":"OemPlus","d":786473,"h":528281763881,"f":33},{"t":786473,"n":"OemComma","d":786473,"h":532576731177,"f":33},{"t":786473,"n":"OemMinus","d":786473,"h":536871698473,"f":33},{"t":786473,"n":"OemPeriod","d":786473,"h":541166665769,"f":33},{"t":786473,"n":"Oem2","d":786473,"h":545461633065,"f":33},{"t":786473,"n":"Oem3","d":786473,"h":549756600361,"f":33},{"t":786473,"n":"Oem4","d":786473,"h":554051567657,"f":33},{"t":786473,"n":"Oem5","d":786473,"h":558346534953,"f":33},{"t":786473,"n":"Oem6","d":786473,"h":562641502249,"f":33},{"t":786473,"n":"Oem7","d":786473,"h":566936469545,"f":33},{"t":786473,"n":"Oem8","d":786473,"h":571231436841,"f":33},{"t":786473,"n":"Oem102","d":786473,"h":575526404137,"f":33},{"t":786473,"n":"Process","d":786473,"h":579821371433,"f":33},{"t":786473,"n":"Packet","d":786473,"h":584116338729,"f":33},{"t":786473,"n":"Attention","d":786473,"h":588411306025,"f":33},{"t":786473,"n":"CrSel","d":786473,"h":592706273321,"f":33},{"t":786473,"n":"ExSel","d":786473,"h":597001240617,"f":33},{"t":786473,"n":"EraseEndOfFile","d":786473,"h":601296207913,"f":33},{"t":786473,"n":"Play","d":786473,"h":605591175209,"f":33},{"t":786473,"n":"Zoom","d":786473,"h":609886142505,"f":33},{"t":786473,"n":"NoName","d":786473,"h":614181109801,"f":33},{"t":786473,"n":"Pa1","d":786473,"h":618476077097,"f":33},{"t":786473,"n":"OemClear","d":786473,"h":622771044393,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":786473,"h":627066011689,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":786473}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleKey`; }
        });
        
        $asm.$str("$scsl.System.ConsoleModifiers", ($self) => class ConsoleModifiers extends $.$spc.System.Enum
        {
            static None = 0;
            static Alt = 1;
            static Shift = 2;
            static Control = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Alt": 1n,
                    "Shift": 2n,
                    "Control": 4n
                };
            }
            static $h = 917545;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":917545,"n":"None","d":917545,"h":4295884841,"f":33},{"t":917545,"n":"Alt","d":917545,"h":8590852137,"f":33},{"t":917545,"n":"Shift","d":917545,"h":12885819433,"f":33},{"t":917545,"n":"Control","d":917545,"h":17180786729,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":917545,"h":21475754025,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":917545,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.ConsoleModifiers`; }
        });
        
        $asm.$cls("$scsl.System.WasmConsoleStream", ($self) => class WasmConsoleStream extends $.$scsl.System.IO.ConsoleStream
        {
            /*SafeFileHandle*/ _handle = null;
            $ctor$4(/*SafeFileHandle*/ handle, /*FileAccess*/ access)
            {
                super.$ctor$3(access);
                {
                    this._handle = handle;
                }
                return this;
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (disposing)
                {
                    this._handle.Dispose();
                }
                super.Dispose$1(disposing);
            }
            /*int */ Read$1(/*Span<byte>*/ buffer)
            {
                throw $.$scsl.System.IO.Error.GetReadNotSupported();
            }
            /*void */ Write$1(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*fixed*/ 
                {
                    /*byte**/ let bufPtr = buffer.GetPinnableReference();
                    $.$scsl.System.WasmConsoleStream.Write$2(this._handle, bufPtr, buffer.Length);
                }
            }
            static /*void */ Write$2(/*SafeFileHandle*/ fd, /*byte**/ bufPtr, /*int*/ count)
            {
                while(count > 0)
                {
                    /*int*/ let bytesWritten = $.$scsl.Interop.Sys.Write(fd, bufPtr, count);
                    if (bytesWritten < 0)
                    {
                        /*Interop.ErrorInfo*/ let errorInfo = $.$scsl.Interop.Sys.GetLastErrorInfo();
                        if (errorInfo.Error === 65603/*Interop.Error.EPIPE*/)
                        {
                            return;
                        }
                        else 
                        {
                            throw $.$scsl.Interop.GetIOException(errorInfo.Clone(), null);
                        }
                    }
                    count -= bytesWritten;
                    bufPtr = bufPtr.Add(bytesWritten);
                }
            }
            /*void */ Flush()
            {
                if (this._handle.IsClosed)
                {
                    throw $.$scsl.System.IO.Error.GetFileNotOpen();
                }
                super.Flush();
            }
            static $h = 1638441;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1179689,"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1638441,"h":12886540329,"f":32772},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1638441,"h":17181507625,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1638441,"h":21476474921,"f":32769},{"r":65537,"p":[{"n":"fd","p":7143425},{"n":"bufPtr","p":0},{"n":"count","p":655361}],"n":"Write","o":"@$2","d":1638441,"h":25771442217,"f":34},{"r":65537,"n":"Flush","d":1638441,"h":30066409513,"f":32769}],"l":[{"t":7143425,"n":"_handle","d":1638441,"h":4296605737,"f":2}],"c":[{"p":[{"n":"handle","p":7143425},{"n":"access","p":59703297}],"n":".ctor","o":"$ctor$4","d":1638441,"h":8591573033,"f":8}],"i":[57475073,56885249],"h":1638441}; }
            static get $b() { return $.$scsl.System.IO.ConsoleStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.WasmConsoleStream`; }
        });
        
        $asm.$cls("$scsl.System.ConsoleCancelEventArgs", ($self) => class ConsoleCancelEventArgs extends $.$spc.System.EventArgs
        {
            /*ConsoleSpecialKey*/ _type = 0;
            $ctor$2(/*ConsoleSpecialKey*/ type)
            {
                super.$ctor$1();
                {
                    this._type = type;
                }
                return this;
            }
            /*bool*/ Cancel = false;
            /*ConsoleSpecialKey */ get SpecialKey()
            {
                return this._type;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Cancel = false;
            }
            static $h = 589865;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21475426345,"f":1},"s":{"r":0,"d":0,"h":25770393641,"f":1},"n":"Cancel","d":589865,"h":17180459049,"f":1},{"p":1048617,"g":{"r":0,"d":0,"h":34360328233,"f":1},"n":"SpecialKey","d":589865,"h":30065360937,"f":1}],"l":[{"t":1048617,"n":"_type","d":589865,"h":4295557161,"f":2}],"c":[{"p":[{"n":"type","p":1048617}],"n":".ctor","o":"$ctor$2","d":589865,"h":8590524457,"f":8}],"h":589865}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.ConsoleCancelEventArgs`; }
        });
        
        $asm.$cls("$scsl.System.ConsoleCancelEventHandler", ($self) => class ConsoleCancelEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /**/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 655401;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":589865}],"n":"Invoke","d":655401,"h":8590589993,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":589865},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":655401,"h":12885557289,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":655401,"h":17180524585,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":655401,"h":4295622697,"f":1}],"i":[57147393,113377281],"h":655401}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.ConsoleCancelEventHandler`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))