
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $stt, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.DiagnosticSource", 
    {"h":44,"f":"System.Diagnostics.DiagnosticSource","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.DiagnosticSource","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.DiagnosticSource","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]},{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":96337921,"c":4391305217,"a":[{"v":92733441,"t":142606337}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.IAggregationStatistics", ($self) => class IAggregationStatistics
        {
            static $h = 5373996;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":5373996}; }
            static get $fullName() { return `System.Diagnostics.Metrics.IAggregationStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.IObjectSequence", ($self) => class IObjectSequence
        {
            static $h = 5832748;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":5832748}; }
            static get $fullName() { return `System.Diagnostics.Metrics.IObjectSequence`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.IStringSequence", ($self) => class IStringSequence
        {
            static $h = 5898284;
            static $f = 0b100100;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":5898284}; }
            static get $fullName() { return `System.Diagnostics.Metrics.IStringSequence`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.IMeterFactory", ($self) => class IMeterFactory
        {
            static $h = 5439532;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"h":5439532}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.IMeterFactory`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagnosticSource", ($self) => class DiagnosticSource extends $.$spc.System.Object
        {
            /*string*/ static WriteRequiresUnreferencedCode = null;
            /*string*/ static WriteOfTRequiresUnreferencedCode = null;
            /*void */ Write$1(T, /*string*/ name, /*T*/ value)
            {
                return this.Write(name, $.$box(value, T));
            }
            /*bool */ IsEnabled$1(/*string*/ name, /*object?*/ arg1, /*object?*/ arg2)
            {
                return this.IsEnabled(name);
            }
            /*Activity */ StartActivity(/*Activity*/ activity, /*object?*/ args)
            {
                activity.Start();
                this.Write(activity.OperationName + ".Start", args);
                return activity;
            }
            /*Activity */ StartActivity$1(T, /*Activity*/ activity, /*T*/ args)
            {
                return this.StartActivity(activity, $.$box(args, T));
            }
            /*void */ StopActivity(/*Activity*/ activity, /*object?*/ args)
            {
                if ($.$spc.System.TimeSpan.op_Equality(activity.Duration, $.$spc.System.TimeSpan.Zero))
                {
                    activity.SetEndTime($.$sdd.System.Diagnostics.Activity.GetUtcNow());
                }
                this.Write(activity.OperationName + ".Stop", args);
                activity.Stop();
            }
            /*void */ StopActivity$1(T, /*Activity*/ activity, /*T*/ args)
            {
                return this.StopActivity(activity, $.$box(args, T));
            }
            /*void */ OnActivityImport(/*Activity*/ activity, /*object?*/ payload)
            {
            }
            /*void */ OnActivityExport(/*Activity*/ activity, /*object?*/ payload)
            {
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.WriteRequiresUnreferencedCode = "The type of object being written to DiagnosticSource cannot be discovered statically.";
                }
                {
                    this.WriteOfTRequiresUnreferencedCode = "Only the properties of the T type will be preserved. Properties of referenced types and properties of derived types may be trimmed.";
                }
            }
            static $h = 2293804;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2293804}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticSource`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Aggregator", ($self) => class Aggregator extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 4325420;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4325420}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.Aggregator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DistributedContextPropagator", ($self) => class DistributedContextPropagator extends $.$spc.System.Object
        {
            /*DistributedContextPropagator*/ static s_current = null;
            static $_PropagatorGetterCallback;
            static get PropagatorGetterCallback()
            {
                let $cls = $.$sdd.System.Diagnostics.DistributedContextPropagator;
                return $cls.$_PropagatorGetterCallback ??= $asm.$ncls("$sdd.System.Diagnostics.DistributedContextPropagator.PropagatorGetterCallback", ($self) => class PropagatorGetterCallback extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ carrier, /*$.$spc.System.String*/ fieldName, /*$.$spc.System.Nullable$$*/ fieldValue, /**/ fieldValues)
                    {
                        return this.$nativeFunction.call(this.$target, carrier, fieldName, fieldValue, fieldValues);
                    }
                    static $h = 2555948;
                    static $f = 0b10000000010000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"d":2490412,"h":2555948}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Diagnostics.DistributedContextPropagator.PropagatorGetterCallback`; }
                }, $cls, ($v) => $cls.$_PropagatorGetterCallback = $v);
            }
            static $_PropagatorSetterCallback;
            static get PropagatorSetterCallback()
            {
                let $cls = $.$sdd.System.Diagnostics.DistributedContextPropagator;
                return $cls.$_PropagatorSetterCallback ??= $asm.$ncls("$sdd.System.Diagnostics.DistributedContextPropagator.PropagatorSetterCallback", ($self) => class PropagatorSetterCallback extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ carrier, /*$.$spc.System.String*/ fieldName, /*$.$spc.System.String*/ fieldValue)
                    {
                        return this.$nativeFunction.call(this.$target, carrier, fieldName, fieldValue);
                    }
                    static $h = 2621484;
                    static $f = 0b10000000010000001;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"d":2490412,"h":2621484}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Diagnostics.DistributedContextPropagator.PropagatorSetterCallback`; }
                }, $cls, ($v) => $cls.$_PropagatorSetterCallback = $v);
            }
            static /*DistributedContextPropagator */ get Current()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!($.$sdd.System.Diagnostics.DistributedContextPropagator.s_current === null), "s_current is not null");
                return $.$sdd.System.Diagnostics.DistributedContextPropagator.s_current;
            }
            static /*DistributedContextPropagator */ set Current(value)
            {
                $.$sdd.System.Diagnostics.DistributedContextPropagator.s_current = $.$firstOf(value, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("value") });
            }
            static /*DistributedContextPropagator */ CreateDefaultPropagator()
            {
                return $.$sdd.System.Diagnostics.W3CPropagator.Instance;
            }
            static /*DistributedContextPropagator */ CreatePassThroughPropagator()
            {
                return $.$sdd.System.Diagnostics.PassThroughPropagator.Instance;
            }
            static /*DistributedContextPropagator */ CreateW3CPropagator()
            {
                return $.$sdd.System.Diagnostics.W3CPropagator.Instance;
            }
            static /*DistributedContextPropagator */ CreatePreW3CPropagator()
            {
                return $.$sdd.System.Diagnostics.LegacyPropagator.Instance;
            }
            static /*DistributedContextPropagator */ CreateNoOutputPropagator()
            {
                return $.$sdd.System.Diagnostics.NoOutputPropagator.Instance;
            }
            static /*void */ InjectBaggage(/*object?*/ carrier, /*IEnumerable<KeyValuePair<string, string?>>*/ baggage, /*PropagatorSetterCallback*/ setter)
            {
                let e = null;
                try
                {
                    e = baggage.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]);
                    if (e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*StringBuilder*/ let baggageList = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        do
                        {
                            /*KeyValuePair<string, string?>*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                            baggageList.Append$2($.$spc.System.Net.WebUtility.UrlEncode(item.Key)).Append$7(/*=*/ 61).Append$2($.$spc.System.Net.WebUtility.UrlEncode(item.Value)).Append$2(", "/*CommaWithSpace*/);
                        }
                        while(e.System$Collections$IEnumerator$MoveNext());
                        setter.Invoke(carrier, "Correlation-Context"/*CorrelationContext*/, baggageList.ToString$1(0, ((baggageList.Length - 2) | 0)));
                    }
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            /*string*/ static TraceParent = null;
            /*string*/ static RequestId = null;
            /*string*/ static TraceState = null;
            /*string*/ static Baggage = null;
            /*string*/ static CorrelationContext = null;
            /*char*/ static Space = /* */ 32;
            /*char*/ static Tab = /*\t*/ 9;
            /*char*/ static Comma = /*,*/ 44;
            /*char*/ static Semicolon = /*;*/ 59;
            /*string*/ static CommaWithSpace = null;
            /*char []*/ static s_trimmingSpaceCharacters = null;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_current = $.$sdd.System.Diagnostics.DistributedContextPropagator.CreateDefaultPropagator();
                }
                {
                    this.TraceParent = "traceparent";
                }
                {
                    this.RequestId = "Request-Id";
                }
                {
                    this.TraceState = "tracestate";
                }
                {
                    this.Baggage = "baggage";
                }
                {
                    this.CorrelationContext = "Correlation-Context";
                }
                {
                    this.CommaWithSpace = ", ";
                }
                {
                    this.s_trimmingSpaceCharacters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/* */ 32, /*\t*/ 9], [-1], null);
                }
            }
            static $h = 2490412;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2490412}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DistributedContextPropagator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Instrument", ($self) => class Instrument extends $.$spc.System.Object
        {
            static /*KeyValuePair<string, object?>[] */ get EmptyTags()
            {
                return $.$spc.System.Array.Empty($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object));
            }
            /*object*/ static SyncObject = null;
            /*DiagLinkedList<ListenerSubscription>*/ _subscriptions = null;
            $ctor$1(/*Meter*/ meter, /*string*/ name)
            {
                this.$ctor$3(meter, name, null, null, null);
                {
                }
                return this;
            }
            $ctor$2(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$3(meter, name, null, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor();
                {
                    this.Meter = $.$firstOf(meter, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("meter") });
                    this.Name = $.$firstOf(name, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("name") });
                    this.Description = description;
                    this.Unit = unit;
                    if (!(tags === null))
                    {
                        /*var*/ let tagList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$3(tags);
                        tagList.Sort$3(new ($.$spc.System.Comparison$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor(this,  (/**/ left, /**/ right) =>
                        {
                            return $.$spc.System.String.Compare$2(left.Key, right.Key, 4/*StringComparison.Ordinal*/);
                        }, {"r":655361,"p":[{"n":"left","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h},{"n":"right","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h}],"n":"","d":5505068,"h":0,"f":1048578}));
                        this.Tags = tagList;
                    }
                }
                return this;
            }
            /*void */ Publish()
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                /*List<MeterListener>?*/ let allListeners = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (this.Meter.Disposed || !this.Meter.AddInstrument(this))
                        {
                            return;
                        }
                        allListeners = $.$sdd.System.Diagnostics.Metrics.MeterListener.GetAllListeners();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                if (!(allListeners === null))
                {
                    var $en3 = allListeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            listener.InstrumentPublished?.Invoke(this, listener);
                        }
                    }
                }
            }
            /*Meter*/ Meter = null;
            /*string*/ Name = null;
            /*string?*/ Description = null;
            /*string?*/ Unit = null;
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*bool */ get Enabled()
            {
                return !(this._subscriptions.First === null);
            }
            /*bool */ get IsObservable()
            {
                return false;
            }
            /*void */ NotifyForUnpublishedInstrument()
            {
                /*DiagNode<ListenerSubscription>?*/ let current = this._subscriptions.First;
                while(!(current === null))
                {
                    current.Value.Listener.DisableMeasurementEvents(this);
                    current = current.Next;
                }
                this._subscriptions.Clear();
            }
            static /*void */ ValidateTypeParameter(T)
            {
                /*Type*/ let type = T.$type;
                if ($.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Byte.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Int16.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Int32.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Int64.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Double.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Single.$type) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Decimal.$type))
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.Format($.$sdd.System.SR.UnsupportedType, type));
                }
            }
            /*object? */ EnableMeasurement(/*ListenerSubscription*/ subscription, /*out bool*/ oldStateStored)
            {
                oldStateStored.$v = false;
                if (!this._subscriptions.AddIfNotExist(subscription, new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$spc.System.Boolean))().$ctor(this,  (/**/ s1, /**/ s2) =>
                {
                    return $.$spc.System.Object.ReferenceEquals(s1.Listener, s2.Listener);
                }, {"r":262145,"p":[{"n":"s1","p":6357036},{"n":"s2","p":6357036}],"n":"","d":5505068,"h":0,"f":1048578})))
                {
                    /*ListenerSubscription*/ let oldSubscription = this._subscriptions.Remove(subscription, new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$spc.System.Boolean))().$ctor(this,  (/**/ s1, /**/ s2) =>
                    {
                        return $.$spc.System.Object.ReferenceEquals(s1.Listener, s2.Listener);
                    }, {"r":262145,"p":[{"n":"s1","p":6357036},{"n":"s2","p":6357036}],"n":"","d":5505068,"h":0,"f":1048578}));
                    this._subscriptions.AddIfNotExist(subscription, new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$spc.System.Boolean))().$ctor(this,  (/**/ s1, /**/ s2) =>
                    {
                        return $.$spc.System.Object.ReferenceEquals(s1.Listener, s2.Listener);
                    }, {"r":262145,"p":[{"n":"s1","p":6357036},{"n":"s2","p":6357036}],"n":"","d":5505068,"h":0,"f":1048578}));
                    oldStateStored.$v = $.$spc.System.Object.ReferenceEquals(oldSubscription.Listener, subscription.Listener);
                    return oldSubscription.State;
                }
                return $.$box(false, $.$spc.System.Boolean);
            }
            /*object? */ DisableMeasurements(/*MeterListener*/ listener)
            {
                return this._subscriptions.Remove(new $.$sdd.System.Diagnostics.Metrics.ListenerSubscription().$ctor$2(listener, null), new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$sdd.System.Diagnostics.Metrics.ListenerSubscription, $.$spc.System.Boolean))().$ctor(this,  (/*s1*/ s1, /*s2*/ s2) =>
                {
                    return $.$spc.System.Object.ReferenceEquals(s1.Listener, s2.Listener);
                }, {"r":262145,"p":[{"n":"s1","p":6357036},{"n":"s2","p":6357036}],"n":"","d":5505068,"h":0,"f":1048578})).State;
            }
            /*void */ Observe(/*MeterListener*/ listener)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(false, "false");
                throw new $.$spc.System.InvalidOperationException().$ctor$9();
            }
            /*object? */ GetSubscriptionState(/*MeterListener*/ listener)
            {
                /*DiagNode<ListenerSubscription>?*/ let current = this._subscriptions.First;
                while(!(current === null))
                {
                    if ($.$spc.System.Object.ReferenceEquals(listener, current.Value.Listener))
                    {
                        return current.Value.State;
                    }
                    current = current.Next;
                }
                return null;
            }
            //default member initializer
            constructor()
            {
                super();
                this._subscriptions = new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.Metrics.ListenerSubscription))().$ctor$1();
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SyncObject = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 5505068;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5505068}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.Instrument`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.InstrumentState", ($self) => class InstrumentState extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5701676;
            static $f = 0b110000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5701676}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.InstrumentState`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ObservableInstrument<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.ObservableInstrument<>", [T], ($self) => class ObservableInstrument$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument
        {
            $ctor$4(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$5(meter, name, unit, description, null);
                {
                }
                return this;
            }
            $ctor$5(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$3(meter, name, unit, description, tags);
                {
                    $.$sdd.System.Diagnostics.Metrics.Instrument.ValidateTypeParameter(T);
                }
                return this;
            }
            /*bool */ get IsObservable()
            {
                return true;
            }
            /*void */ Observe(/*MeterListener*/ listener)
            {
                /*object?*/ let state = this.GetSubscriptionState(listener);
                /*IEnumerable<Measurement<T>>*/ let measurements = this.Observe$1();
                if (measurements === null)
                {
                    return;
                }
                var $en2 = measurements.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var measurement = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        listener.NotifyMeasurement(T, this, measurement.Value, measurement.Tags, state);
                    }
                }
            }
            static /*IEnumerable<Measurement<T>> */ Observe$2(/*object*/ callback)
            {
                let valueOnlyFunc;
                if ($.$is(callback, $.$spc.System.Func$$(T), { set $v(v){ valueOnlyFunc = v; } }))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdd.System.Diagnostics.Metrics.Measurement$$(T)), [new ($.$sdd.System.Diagnostics.Metrics.Measurement$$(T))().$ctor$2(valueOnlyFunc.Invoke())], [1], null);
                }
                let measurementOnlyFunc;
                if ($.$is(callback, $.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Measurement$$(T)), { set $v(v){ measurementOnlyFunc = v; } }))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdd.System.Diagnostics.Metrics.Measurement$$(T)), [measurementOnlyFunc.Invoke()], [1], null);
                }
                let listOfMeasurementsFunc;
                if ($.$is(callback, $.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$($.$sdd.System.Diagnostics.Metrics.Measurement$$(T))), { set $v(v){ listOfMeasurementsFunc = v; } }))
                {
                    return listOfMeasurementsFunc.Invoke();
                }
                $.$spc.System.Diagnostics.Debug.Fail("Execution shouldn't reach this point");
                return null;
            }
            static $h = 7602220;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5505068,"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObservableInstrument<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Instrument<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.Instrument<>", [T], ($self) => class Instrument$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument
        {
            /*void */ RecordMeasurement(/*T*/ measurement, /*KeyValuePair<string, object?>*/ tag)
            {
                return this.RecordMeasurement$5(measurement, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [tag], null, null)));
            }
            /*void */ RecordMeasurement$1(/*T*/ measurement, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2)
            {
                return this.RecordMeasurement$5(measurement, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [tag1, tag2], null, null)));
            }
            /*void */ RecordMeasurement$2(/*T*/ measurement, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2, /*KeyValuePair<string, object?>*/ tag3)
            {
                return this.RecordMeasurement$5(measurement, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [tag1, tag2, tag3], null, null)));
            }
            /*void */ RecordMeasurement$3(/*T*/ measurement, /*in TagList*/ tagList)
            {
                return this.RecordMeasurement$5(measurement, tagList.$v.Tags);
            }
            /*InstrumentAdvice<T>?*/ Advice = null;
            $ctor$4(/*Meter*/ meter, /*string*/ name)
            {
                this.$ctor$7(meter, name, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$5(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$7(meter, name, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$6(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                this.$ctor$7(meter, name, null, null, null, null);
                {
                }
                return this;
            }
            $ctor$7(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*InstrumentAdvice<T>?*/ advice)
            {
                super.$ctor$3(meter, name, unit, description, tags);
                {
                    this.Advice = advice;
                    $.$sdd.System.Diagnostics.Metrics.Instrument.ValidateTypeParameter(T);
                }
                return this;
            }
            /*void */ RecordMeasurement$4(/*T*/ measurement)
            {
                return this.RecordMeasurement$5(measurement, $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.Instrument.EmptyTags)));
            }
            /*void */ RecordMeasurement$5(/*T*/ measurement, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                /*DiagNode<ListenerSubscription>?*/ let current = this._subscriptions.First;
                while(!(current === null))
                {
                    current.Value.Listener.NotifyMeasurement(T, this, measurement, tags, current.Value.State);
                    current = current.Next;
                }
            }
            static $h = 5570604;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5505068,"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument; }
            static get $fullName() { return `System.Diagnostics.Metrics.Instrument<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.ActivitySourceOptions", ($self) => class ActivitySourceOptions extends $.$spc.System.Object
        {
            /*string*/ _name = null;
            $ctor$1(/*string*/ name)
            {
                super.$ctor();
                {
                    this._name = $.$firstOf(name, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("name") });
                }
                return this;
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*string */ set Name(value)
            {
                this._name = $.$firstOf(value, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("value") });
            }
            /*string?*/ Version = null;
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*string?*/ TelemetrySchemaUrl = null;
            //default member initializer
            constructor()
            {
                super();
                this.Version = $.$spc.System.String.Empty;
            }
            static $h = 1245228;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1245228}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ActivitySourceOptions`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.ThisAssembly", ($self) => class ThisAssembly
        {
            /*string*/ static BuildAssemblyFileVersion = null;
            /*Version*/ static AssemblyFileVersion = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.BuildAssemblyFileVersion = "1.0";
                }
                {
                    this.AssemblyFileVersion = new $.$spc.System.Version().$ctor$4("1.0"/*BuildAssemblyFileVersion*/);
                }
            }
            static $h = 8978476;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":8978476}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `ThisAssembly`; }
        });
        
        $asm.$cls("$sdd.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdd.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Diagnostics.DiagnosticSource", $.$sdd.System.SR.$type.Assembly);
                    $.$sdd.System.SR.s_resourceManager = temp;
                }
                return $.$sdd.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdd.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdd.System.SR.resourceCulture = value;
            }
            static /*string */ get ActivityIdFormatInvalid()
            {
                return "\"Value must be a valid ActivityIdFormat value\"";
            }
            static /*string */ get ActivityNotRunning()
            {
                return "Trying to set an Activity that is not running";
            }
            static /*string */ get ActivityNotStarted()
            {
                return "\"Can not stop an Activity that was not started\"";
            }
            static /*string */ get ActivityStartAlreadyStarted()
            {
                return "\"Can not start an Activity that was already started\"";
            }
            static /*string */ get ActivitySetParentAlreadyStarted()
            {
                return "\"Can not set parent on already started Activity\"";
            }
            static /*string */ get EndTimeNotUtc()
            {
                return "\"EndTime is not UTC\"";
            }
            static /*string */ get OperationNameInvalid()
            {
                return "\"OperationName must not be null or empty\"";
            }
            static /*string */ get ParentIdAlreadySet()
            {
                return "\"ParentId is already set\"";
            }
            static /*string */ get ParentIdInvalid()
            {
                return "\"ParentId must not be null or empty\"";
            }
            static /*string */ get SetFormatOnStartedActivity()
            {
                return "\"Can not change format for an activity that was already started\"";
            }
            static /*string */ get SetParentIdOnActivityWithParent()
            {
                return "\"Can not set ParentId on activity which has parent\"";
            }
            static /*string */ get StartTimeNotUtc()
            {
                return "\"StartTime is not UTC\"";
            }
            static /*string */ get KeyAlreadyExist()
            {
                return "\"The collection already contains item with same key '{0}''\"";
            }
            static /*string */ FormatKeyAlreadyExist(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("\"The collection already contains item with same key '{0}''\"", arg1);
            }
            static /*string */ get InvalidTraceParent()
            {
                return "\"Invalid trace parent.\"";
            }
            static /*string */ get UnableAccessServicePointTable()
            {
                return "Unable to access the ServicePointTable field";
            }
            static /*string */ get UnableToInitialize()
            {
                return "Unable to initialize all required reflection objects";
            }
            static /*string */ get UnsupportedType()
            {
                return "{0} is unsupported type for this operation. The only supported types are byte, short, int, long, float, double, and decimal.  ";
            }
            static /*string */ FormatUnsupportedType(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0} is unsupported type for this operation. The only supported types are byte, short, int, long, float, double, and decimal.  ", arg1);
            }
            static /*string */ get Arg_BufferTooSmall()
            {
                return "Destination buffer is not long enough to copy all the items in the list.";
            }
            static /*string */ get InvalidInstrumentType()
            {
                return "The instrument is of different generic type.";
            }
            static /*string */ get InvalidHistogramExplicitBucketBoundaries()
            {
                return "Histogram explicit bucket boundaries must be specified in ascending order and cannot contain duplicate values.";
            }
            static /*string */ get InvalidHistogramScale()
            {
                return "Invalid scale value {0}. Scale must be greater than or equal to {1} and less than or equal to {2}.";
            }
            static /*string */ FormatInvalidHistogramScale(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("Invalid scale value {0}. Scale must be greater than or equal to {1} and less than or equal to {2}.", arg1, arg2, arg3);
            }
            static /*string */ get InvalidHistogramMaxBuckets()
            {
                return "Invalid Max buckets value {0}. Max buckets must be greater than or equal to {1}.";
            }
            static /*string */ FormatInvalidHistogramMaxBuckets(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("Invalid Max buckets value {0}. Max buckets must be greater than or equal to {1}.", arg1, arg2);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdd.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdd.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdd.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdd.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdd.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdd.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 9371692;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":9371692}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Helpers", ($self) => class Helpers
        {
            static /*string */ FormatTags(/*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                if (tags === null)
                {
                    return $.$spc.System.String.Empty;
                }
                /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                /*bool*/ let first = true;
                var $en2 = tags.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var tag = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (first)
                        {
                            first = false;
                        }
                        else 
                        {
                            sb.Append$7(/*,*/ 44);
                        }
                        sb.Append$2(tag.Key).Append$7(/*=*/ 61).Append$19(tag.Value);
                    }
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*string */ FormatTags$1(/*KeyValuePair<string, string>[]*/ labels)
            {
                if (labels === null || labels.length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                for(/*int*/ let i = 0; i < labels.length; i++)
                {
                    sb.Append$2($.$spc.System.Array.$ReadT1.call(labels, i).Key).Append$7(/*=*/ 61).Append$2($.$spc.System.Array.$ReadT1.call(labels, i).Value);
                    if (i !== ((labels.length - 1) | 0))
                    {
                        sb.Append$7(/*,*/ 44);
                    }
                }
                return $.$spc.System.Text.StringBuilder.ToString.call(sb);
            }
            static /*string */ FormatObjectHash(/*object?*/ obj)
            {
                return obj === null ? $.$spc.System.String.Empty : $.$spc.System.Int32.ToString$2.call($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.GetHashCode$1(obj), $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            static $h = 4128812;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4128812}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Helpers`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.RandomNumberGenerator", ($self) => class RandomNumberGenerator extends $.$spc.System.Object
        {
            /*RandomNumberGenerator?*/ static t_random = null;
            /*ulong*/ _s0 = 0n;
            /*ulong*/ _s1 = 0n;
            /*ulong*/ _s2 = 0n;
            /*ulong*/ _s3 = 0n;
            static /*RandomNumberGenerator */ get Current()
            {
                return $.$sdd.System.Diagnostics.RandomNumberGenerator.t_random ??= new $.$sdd.System.Diagnostics.RandomNumberGenerator().$ctor$1();
            }
            $ctor$1()
            {
                super.$ctor();
                {
                    do
                    {
                        /*Guid*/ let g1 = $.$spc.System.Guid.NewGuid();
                        /*Guid*/ let g2 = $.$spc.System.Guid.NewGuid();
                        $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Guid, () => g1, ($v) => g1 = $v, null));
                        /*ulong**/ let g1p = g1.$getFieldRefOrP($.$spc.System.UInt64, 0, true);
                        $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Guid, () => g2, ($v) => g2 = $v, null));
                        /*ulong**/ let g2p = g2.$getFieldRefOrP($.$spc.System.UInt64, 0, true);
                        this._s0 = g1p.$v;
                        this._s1 = (g1p.Add(1)).$v;
                        this._s2 = g2p.$v;
                        this._s3 = (g2p.Add(1)).$v;
                        this._s0 = (this._s0 & 1152921504606846975n) | (this._s1 & 17293822569102704640n);
                        this._s2 = (this._s2 & 1152921504606846975n) | (this._s3 & 17293822569102704640n);
                        this._s1 = (this._s1 & 18446744073709551423n) | (this._s0 & 192n);
                        this._s3 = (this._s3 & 18446744073709551423n) | (this._s2 & 192n);
                    }
                    while((this._s0 | this._s1 | this._s2 | this._s3) === 0n);
                }
                return this;
            }
            static /*ulong */ Rol64(/*ulong*/ x, /*int*/ k)
            {
                return (BigInt.asUintN(64, x << BigInt(k))) | (x >> BigInt((((64 - k) | 0))));
            }
            /*long */ Next()
            {
                /*ulong*/ let result = $.$sdd.System.Diagnostics.RandomNumberGenerator.Rol64(this._s1 * 5n, 7) * 9n;
                /*ulong*/ let t = BigInt.asUintN(64, this._s1 << 17n);
                this._s2 ^= this._s0;
                this._s3 ^= this._s1;
                this._s1 ^= this._s2;
                this._s0 ^= this._s3;
                this._s2 ^= t;
                this._s3 = $.$sdd.System.Diagnostics.RandomNumberGenerator.Rol64(this._s3, 45);
                return $.$cast(result, $.$spc.System.Int64);
            }
            static $h = 8519724;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":8519724}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.RandomNumberGenerator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.RateLimiter", ($self) => class RateLimiter extends $.$spc.System.Object
        {
            /*int*/ _maxOperationsPerSecond = 0;
            /*Stopwatch*/ _stopwatch = null;
            /*long*/ _ticksPerSecond = 0n;
            /*int*/ _currentOperationCount = 0;
            /*long*/ _intervalStartTicks = 0n;
            $ctor$1(/*int*/ maxOperationsPerSecond)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(maxOperationsPerSecond > 0, "maxOperationsPerSecond must be greater than 0");
                    this._maxOperationsPerSecond = maxOperationsPerSecond;
                    this._stopwatch = new $.$spc.System.Diagnostics.Stopwatch().$ctor$1();
                    this._stopwatch.Start();
                    this._intervalStartTicks = this._stopwatch.ElapsedTicks;
                    this._currentOperationCount = 0;
                    this._ticksPerSecond = $.$spc.System.Diagnostics.Stopwatch.Frequency;
                }
                return this;
            }
            /*bool */ TryAcquire()
            {
                do
                {
                    /*long*/ let currentTicks = this._stopwatch.ElapsedTicks;
                    /*long*/ let intervalStartTicks = $.$spc.System.Threading.Interlocked.Read($.$ref(() => this._intervalStartTicks, ($v) => this._intervalStartTicks = $v, $.$spc.System.Int64));
                    /*int*/ let currentOperationCount = $.$ref(() => this._currentOperationCount, ($v) => this._currentOperationCount = $v, $.$spc.System.Int32).$v;
                    /*long*/ let elapsedTicks = currentTicks - intervalStartTicks;
                    if (elapsedTicks >= this._ticksPerSecond)
                    {
                        if ($.$spc.System.Threading.Interlocked.CompareExchange($.$ref(() => this._currentOperationCount, ($v) => this._currentOperationCount = $v, $.$spc.System.Int32), 1, currentOperationCount) !== currentOperationCount)
                        {
                            continue;
                        }
                        $.$spc.System.Threading.Interlocked.CompareExchange$3($.$ref(() => this._intervalStartTicks, ($v) => this._intervalStartTicks = $v, $.$spc.System.Int64), currentTicks, intervalStartTicks);
                        return true;
                    }
                    return $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._currentOperationCount, ($v) => this._currentOperationCount = $v, $.$spc.System.Int32)) <= this._maxOperationsPerSecond;
                }
                while(true);
            }
            static $h = 8585260;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":8585260}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.RateLimiter`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.CircularBufferBuckets", ($self) => class CircularBufferBuckets extends $.$spc.System.Object
        {
            /*long[]?*/ _trait = null;
            /*int*/ _begin = 0;
            /*int*/ _end = -1;
            $ctor$1(/*int*/ capacity)
            {
                super.$ctor();
                {
                    if (capacity < 1)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("capacity", "Capacity must be greater than 0.");
                    }
                    this.Capacity = capacity;
                }
                return this;
            }
            /*int*/ Capacity = 0;
            /*int */ get Size()
            {
                return ((((this._end - this._begin) | 0) + 1) | 0);
            }
            /*long*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._trait === null), "trait was null");
                return $.$spc.System.Array.$ReadT1.call(this._trait, this.ModuloIndex(index));
            }
            /*int */ TryIncrement(/*int*/ index, /*long*/ value)
            {
                /*var*/ let capacity = this.Capacity;
                if (this._trait === null)
                {
                    this._trait = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [capacity], null);
                    this._begin = index;
                    this._end = index;
                    $.$spc.System.Array.$WriteT1.call(this._trait, $.$spc.System.Array.$ReadT1.call(this._trait, this.ModuloIndex(index)) + value, this.ModuloIndex(index));
                    return 0;
                }
                /*var*/ let begin = this._begin;
                /*var*/ let end = this._end;
                if (index > end)
                {
                    end = index;
                }
                else if (index < begin)
                {
                    begin = index;
                }
                else 
                {
                    $.$spc.System.Array.$WriteT1.call(this._trait, $.$spc.System.Array.$ReadT1.call(this._trait, this.ModuloIndex(index)) + value, this.ModuloIndex(index));
                    return 0;
                }
                /*var*/ let diff = ((end - begin) | 0);
                if (diff >= capacity || diff < 0)
                {
                    return CalculateScaleReduction(begin, end, capacity);
                }
                this._begin = begin;
                this._end = end;
                $.$spc.System.Array.$WriteT1.call(this._trait, $.$spc.System.Array.$ReadT1.call(this._trait, this.ModuloIndex(index)) + value, this.ModuloIndex(index));
                return 0;
                /*static int*/  function CalculateScaleReduction(/*int*/ begin, /*int*/ end, /*int*/ capacity)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 2, "The capacity must be at least 2.");
                    /*var*/ let retVal = 0;
                    /*var*/ let diff = ((end - begin) | 0);
                    while(diff >= capacity || diff < 0)
                    {
                        begin >>= 1;
                        end >>= 1;
                        diff = ((end - begin) | 0);
                        retVal++;
                    }
                    return retVal;
                }
            }
            /*void */ ScaleDown(/*int*/ level)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(level > 0, "The scale down level must be a positive integer.");
                if (this._trait === null)
                {
                    return;
                }
                /*uint*/ let capacity = (this.Capacity >>> 0);
                /*var*/ let offset = (this.ModuloIndex(this._begin) >>> 0);
                /*var*/ let currentBegin = this._begin;
                /*var*/ let currentEnd = this._end;
                for(/*int*/ let i = 0; i < level; i++)
                {
                    /*var*/ let newBegin = currentBegin >> 1;
                    /*var*/ let newEnd = currentEnd >> 1;
                    if (currentBegin !== currentEnd)
                    {
                        if (currentBegin % 2 === 0)
                        {
                            ScaleDownInternal(this._trait, offset, currentBegin, currentEnd, capacity);
                        }
                        else 
                        {
                            currentBegin++;
                            if (currentBegin !== currentEnd)
                            {
                                ScaleDownInternal(this._trait, ((offset + 1) >>> 0), currentBegin, currentEnd, capacity);
                            }
                        }
                    }
                    currentBegin = newBegin;
                    currentEnd = newEnd;
                }
                this._begin = currentBegin;
                this._end = currentEnd;
                if (capacity > 1)
                {
                    AdjustPosition(this._trait, offset, (this.ModuloIndex(currentBegin) >>> 0), ((((((currentEnd - currentBegin) | 0) + 1) | 0)) >>> 0), capacity);
                }
                return;
                /*static void*/  function ScaleDownInternal(/*long[]*/ array, /*uint*/ offset, /*int*/ begin, /*int*/ end, /*uint*/ capacity)
                {
                    for(/*var*/ let index = ((begin + 1) | 0); index < end; index++)
                    {
                        Consolidate(array, (((offset + ((((index - begin) | 0)) >>> 0)) >>> 0)) % capacity, (((offset + (((((index >> 1) - (begin >> 1)) | 0)) >>> 0)) >>> 0)) % capacity);
                    }
                    Consolidate(array, (((offset + ((((end - begin) | 0)) >>> 0)) >>> 0)) % capacity, (((offset + (((((end >> 1) - (begin >> 1)) | 0)) >>> 0)) >>> 0)) % capacity);
                }
                /*static void*/  function AdjustPosition(/*long[]*/ array, /*uint*/ src, /*uint*/ dst, /*uint*/ size, /*uint*/ capacity)
                {
                    /*var*/ let advancement = (((((dst + capacity) >>> 0) - src) >>> 0)) % capacity;
                    if (advancement === 0)
                    {
                        return;
                    }
                    if ((((size - 1) >>> 0) >>> 0) == advancement && (advancement << 1) >>> 0 === capacity)
                    {
                        Exchange(array, src++, dst++);
                        size -= 2;
                    }
                    else if (advancement < size)
                    {
                        src = ((((src + size) >>> 0) - 1) >>> 0);
                        dst = ((((dst + size) >>> 0) - 1) >>> 0);
                        while(size-- !== 0)
                        {
                            Move(array, src-- % capacity, dst-- % capacity);
                        }
                        return;
                    }
                    while(size-- !== 0)
                    {
                        Move(array, src++ % capacity, dst++ % capacity);
                    }
                }
                /*static void*/  function Consolidate(/*long[]*/ array, /*uint*/ src, /*uint*/ dst)
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$spc.System.Array.$ReadT1.call(array, dst) + $.$spc.System.Array.$ReadT1.call(array, src), dst);
                    $.$spc.System.Array.$WriteT1.call(array, 0n, src);
                }
                /*static void*/  function Exchange(/*long[]*/ array, /*uint*/ src, /*uint*/ dst)
                {
                    /*var*/ let value = $.$spc.System.Array.$ReadT1.call(array, dst);
                    $.$spc.System.Array.$WriteT1.call(array, $.$spc.System.Array.$ReadT1.call(array, src), dst);
                    $.$spc.System.Array.$WriteT1.call(array, value, src);
                }
                /*static void*/  function Move(/*long[]*/ array, /*uint*/ src, /*uint*/ dst)
                {
                    $.$spc.System.Array.$WriteT1.call(array, $.$spc.System.Array.$ReadT1.call(array, src), dst);
                    $.$spc.System.Array.$WriteT1.call(array, 0n, src);
                }
            }
            /*long[] */ ToArray()
            {
                /*var*/ let size = this.Size;
                if (this._trait === null || size <= 0)
                {
                    return $.$spc.System.Array.Empty($.$spc.System.Int64);
                }
                /*var*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int64), null, [size], null);
                for(/*var*/ let i = 0; i < size; ++i)
                {
                    $.$spc.System.Array.$WriteT1.call(result, $.$spc.System.Array.$ReadT1.call(this._trait, this.ModuloIndex(((this._begin + i) | 0))), i);
                }
                return result;
            }
            /*void */ Clear()
            {
                if (!(this._trait === null))
                {
                    $.$spc.System.Array.Clear(this._trait);
                }
                this._begin = 0;
                this._end = -1;
            }
            /*int */ ModuloIndex(/*int*/ value)
            {
                return $.$sdd.System.Diagnostics.Metrics.CircularBufferBuckets.PositiveModulo32(value, this.Capacity);
            }
            static /*int */ PositiveModulo32(/*int*/ value, /*int*/ divisor)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(divisor > 0, `${"divisor"} must be a positive integer.`);
                value %= divisor;
                if (value < 0)
                {
                    value += divisor;
                }
                return value;
            }
            static $h = 4653100;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4653100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.CircularBufferBuckets`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics", ($self) => class LabeledAggregationStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*IAggregationStatistics*/ stats, /*params KeyValuePair<string, string>[]*/ labels)
            {
                super.$ctor();
                {
                    this.AggregationStatistics = stats;
                    this.Labels = labels;
                }
                return this;
            }
            /*KeyValuePair<string, string>[]*/ Labels = null;
            /*IAggregationStatistics*/ AggregationStatistics = null;
            static $h = 5963820;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5963820}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.LabeledAggregationStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.QuantileAggregation", ($self) => class QuantileAggregation extends $.$spc.System.Object
        {
            $ctor$1(/*params double[]*/ quantiles)
            {
                super.$ctor();
                {
                    this.Quantiles = quantiles;
                    $.$spc.System.Array.Sort$8($.$spc.System.Double, this.Quantiles);
                }
                return this;
            }
            /*double[]*/ Quantiles = null;
            /*double*/ MaxRelativeError = 0;
            //default member initializer
            constructor()
            {
                super();
                this.MaxRelativeError = 0.001;
            }
            static $h = 7733292;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":7733292}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.QuantileAggregation`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.InstrumentAdvice<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.InstrumentAdvice<>", [T], ($self) => class InstrumentAdvice$$ extends $.$spc.System.Object
        {
            /*ReadOnlyCollection<T>?*/ _HistogramBucketBoundaries = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    $.$sdd.System.Diagnostics.Metrics.Instrument.ValidateTypeParameter(T);
                }
                return this;
            }
            /*IReadOnlyList<T>? */ get HistogramBucketBoundaries()
            {
                return this._HistogramBucketBoundaries;
            }
            /*IReadOnlyList<T>? */ set HistogramBucketBoundaries(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*List<T>*/ let bucketBoundariesCopy = new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$3(value);
                if (!$.$sdd.System.Diagnostics.Metrics.InstrumentAdvice$$(T).IsSortedAndDistinct(bucketBoundariesCopy))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sdd.System.SR.InvalidHistogramExplicitBucketBoundaries, "value");
                }
                this._HistogramBucketBoundaries = new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$(T))().$ctor$1(bucketBoundariesCopy);
            }
            static /*bool */ IsSortedAndDistinct(/*List<T>*/ values)
            {
                /*Comparer<T>*/ let comparer = $.$spc.System.Collections.Generic.Comparer$$(T).Default;
                for(/*int*/ let i = 1; i < values.Count; i++)
                {
                    if (comparer.Compare(values.get_Item(((i - 1) | 0)), values.get_Item(i)) >= 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            static $h = 5636140;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.InstrumentAdvice<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.DsesSamplerBuilder", ($self) => class DsesSamplerBuilder
        {
            static /*DsesSampleActivityFunc */ CreateParentRatioSampler(/*double*/ ratio)
            {
                /*long*/ let idUpperBound = ratio <= 0 ? -9223372036854775808n : ratio >= 1 ? 9223372036854775807n : $.$cast((ratio * Number(9223372036854775807n)), $.$spc.System.Int64);
                return new $.$sdd.System.Diagnostics.DsesSampleActivityFunc().$ctor(this,  (/*bool*/ hasActivityContext, /*ActivityCreationOptions<ActivityContext>*/ options) =>
                {
                    if (hasActivityContext && $.$sdd.System.Diagnostics.ActivityTraceId.op_Inequality(options.$v.TraceId, new $.$sdd.System.Diagnostics.ActivityTraceId()))
                    {
                        /*ActivityContext*/ let parentContext = options.$v.Parent;
                        /*ActivitySamplingResult*/ let samplingDecision = $.$sdd.System.Diagnostics.DsesSamplerBuilder.ParentRatioSampler(idUpperBound, $.$ref(() => parentContext, undefined, $.$sdd.System.Diagnostics.ActivityContext), options.$v.TraceId);
                        return samplingDecision === 0/*ActivitySamplingResult.None*/ && ($.$sdd.System.Diagnostics.ActivityContext.op_Equality(parentContext, new $.$sdd.System.Diagnostics.ActivityContext()) || parentContext.IsRemote) ? 1/*ActivitySamplingResult.PropagationData*/ : samplingDecision;
                    }
                    return 0/*ActivitySamplingResult.None*/;
                }, {"r":1048620,"p":[{"n":"hasActivityContext","p":262145},{"n":"options","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":3997740,"h":0,"f":1048578});
            }
            static /*ActivitySamplingResult */ ParentRatioSampler(/*long*/ idUpperBound, /*in ActivityContext*/ parentContext, /*ActivityTraceId*/ traceId)
            {
                if ($.$sdd.System.Diagnostics.ActivityTraceId.op_Inequality(parentContext.$v.TraceId, new $.$sdd.System.Diagnostics.ActivityTraceId()))
                {
                    return ((parentContext.$v.TraceFlags & (1/*ActivityTraceFlags.Recorded*/)) == (1/*ActivityTraceFlags.Recorded*/)) ? 3/*ActivitySamplingResult.AllDataAndRecorded*/ : 0/*ActivitySamplingResult.None*/;
                }
                /*Span<byte>*/ let traceIdBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16, null);
                traceId.CopyTo(traceIdBytes);
                return $.$spc.System.Math.Abs$2(GetLowerLong($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(traceIdBytes))) < idUpperBound ? 3/*ActivitySamplingResult.AllDataAndRecorded*/ : 0/*ActivitySamplingResult.None*/;
                /*static long*/  function GetLowerLong(/*ReadOnlySpan<byte>*/ bytes)
                {
                    /*long*/ let result = 0n;
                    for(/*int*/ let i = 0; i < 8; i++)
                    {
                        result <<= 8n;
                        result |= BigInt(bytes.get_Item(i).$v & 255);
                    }
                    return result;
                }
            }
            static /*DsesSampleActivityFunc */ CreateParentRateLimitingSampler(/*int*/ maximumRatePerSecond)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(maximumRatePerSecond > 0, "maximumRatePerSecond must be greater than 0");
                /*RateLimiter*/ let rateLimiter = new $.$sdd.System.Diagnostics.RateLimiter().$ctor$1(maximumRatePerSecond);
                return new $.$sdd.System.Diagnostics.DsesSampleActivityFunc().$ctor(this,  (/*bool*/ hasActivityContext, /*ActivityCreationOptions<ActivityContext>*/ options) =>
                {
                    if (hasActivityContext && $.$sdd.System.Diagnostics.ActivityTraceId.op_Inequality(options.$v.TraceId, new $.$sdd.System.Diagnostics.ActivityTraceId()))
                    {
                        /*ActivityContext*/ let parentContext = options.$v.Parent;
                        return $.$sdd.System.Diagnostics.ActivityContext.op_Equality(parentContext, new $.$sdd.System.Diagnostics.ActivityContext()) || parentContext.IsRemote ? (rateLimiter.TryAcquire() ? 3/*ActivitySamplingResult.AllDataAndRecorded*/ : 0/*ActivitySamplingResult.None*/) : ((parentContext.TraceFlags & (1/*ActivityTraceFlags.Recorded*/)) == (1/*ActivityTraceFlags.Recorded*/)) ? 3/*ActivitySamplingResult.AllDataAndRecorded*/ : 0/*ActivitySamplingResult.None*/;
                    }
                    return 0/*ActivitySamplingResult.None*/;
                }, {"r":1048620,"p":[{"n":"hasActivityContext","p":262145},{"n":"options","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":3997740,"h":0,"f":1048578});
            }
            static $h = 3997740;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":3997740}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `DsesSamplerBuilder`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MeterOptions", ($self) => class MeterOptions extends $.$spc.System.Object
        {
            /*string*/ _name = null;
            /*string */ get Name()
            {
                return this._name;
            }
            /*string */ set Name(value)
            {
                this._name = $.$firstOf(value, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("value") });
            }
            /*string?*/ Version = null;
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*object?*/ Scope = null;
            /*string?*/ TelemetrySchemaUrl = null;
            $ctor$1(/*string*/ name)
            {
                super.$ctor();
                {
                    this.Name = name;
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._name === null), "_name is not null");
                }
                return this;
            }
            static $h = 6750252;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6750252}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.MeterOptions`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MeterFactoryExtensions", ($self) => class MeterFactoryExtensions
        {
            static /*Meter */ Create(/*this IMeterFactory*/ meterFactory, /*string*/ name, /*string?*/ version, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(meterFactory, "meterFactory");
                return meterFactory.System$Diagnostics$Metrics$IMeterFactory$Create((() =>
                {
                    //new $.$sdd.System.Diagnostics.Metrics.MeterOptions()
                    const $t1 = $.$sdd.System.Diagnostics.Metrics.MeterOptions;
                    const $i1 = new $t1();
                    $i1.$ctor$1(name);
                    $i1.Version = version;
                    $i1.Tags = tags;
                    $i1.Scope = meterFactory;
                    return $i1;
                })());
            }
            static $h = 6619180;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6619180}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.MeterFactoryExtensions`; }
        });
        
        $asm.$cls("$sdd.System.LocalAppContextSwitches", ($self) => class LocalAppContextSwitches
        {
            /*bool*/ static DefaultActivityIdFormatIsHierarchial = false;
            static /*bool */ InitializeDefaultActivityIdFormat()
            {
                /*bool*/ let defaultActivityIdFormatIsHierarchial = false;
                if (!$.$sdd.System.LocalAppContextSwitches.GetSwitchValue("System.Diagnostics.DefaultActivityIdFormatIsHierarchial", $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Boolean, () => defaultActivityIdFormatIsHierarchial, ($v) => defaultActivityIdFormatIsHierarchial = $v, null)))
                {
                    /*string?*/ let switchValue = $.$spc.System.Environment.GetEnvironmentVariable("DOTNET_SYSTEM_DIAGNOSTICS_DEFAULTACTIVITYIDFORMATISHIERARCHIAL");
                    if ($.$spc.System.String.op_Inequality(switchValue, null))
                    {
                        defaultActivityIdFormatIsHierarchial = $.$spc.System.String.Equals$3.call(switchValue, "true", 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.String.Equals$2.call(switchValue, "1");
                    }
                }
                return defaultActivityIdFormatIsHierarchial;
            }
            static /*bool */ GetSwitchValue(/*string*/ switchName, /*ref bool*/ switchValue)
            {
                return $.$spc.System.AppContext.TryGetSwitch(switchName, switchValue);
            }
            static /*bool */ GetCachedSwitchValue(/*string*/ switchName, /*ref int*/ cachedSwitchValue)
            {
                if (cachedSwitchValue.$v < 0)
                {
                    return false;
                }
                if (cachedSwitchValue.$v > 0)
                {
                    return true;
                }
                return $.$sdd.System.LocalAppContextSwitches.GetCachedSwitchValueInternal(switchName, cachedSwitchValue);
            }
            static /*bool */ GetCachedSwitchValueInternal(/*string*/ switchName, /*ref int*/ cachedSwitchValue)
            {
                /*bool*/ let isSwitchEnabled;
                /*bool*/ let hasSwitch = $.$spc.System.AppContext.TryGetSwitch(switchName, $.$ref(() => isSwitchEnabled, ($v) => isSwitchEnabled = $v, $.$spc.System.Boolean));
                if (!hasSwitch)
                {
                    isSwitchEnabled = $.$sdd.System.LocalAppContextSwitches.GetSwitchDefaultValue(switchName);
                }
                /*bool*/ let disableCaching;
                $.$spc.System.AppContext.TryGetSwitch("TestSwitch.LocalAppContext.DisableCaching", $.$ref(() => disableCaching, ($v) => disableCaching = $v, $.$spc.System.Boolean));
                if (!disableCaching)
                {
                    cachedSwitchValue.$v = isSwitchEnabled ? 1 : -1;
                }
                return isSwitchEnabled;
            }
            static /*bool */ GetSwitchDefaultValue(/*string*/ switchName)
            {
                if ($.$spc.System.String.op_Equality(switchName, "Switch.System.Runtime.Serialization.SerializationGuard"))
                {
                    return true;
                }
                if ($.$spc.System.String.op_Equality(switchName, "System.Runtime.Serialization.EnableUnsafeBinaryFormatterSerialization"))
                {
                    return true;
                }
                if ($.$spc.System.String.op_Equality(switchName, "System.Xml.XmlResolver.IsNetworkingEnabledByDefault"))
                {
                    return true;
                }
                return false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultActivityIdFormatIsHierarchial = $.$sdd.System.LocalAppContextSwitches.InitializeDefaultActivityIdFormat();
                }
            }
            static $h = 9306156;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":9306156}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.LocalAppContextSwitches`; }
        });
        
        $asm.$cls("$sdd.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$sdd.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$sdd.System.HexConverter.Casing", ($self) => class Casing extends $.$spc.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 9175084;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"d":9109548,"h":9175084}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$spc.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$spc.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$sdd.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$sdd.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$sdd.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$sdd.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$spc.System.String.Create$8($.$sdd.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$sdd.System.HexConverter.SpanCasingPair))().$ctor($.$sdd.System.HexConverter, /*static*/ (/**/ chars, /**/ args) =>
                {
                    return $.$sdd.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"args","p":9240620}],"n":"","d":9109548,"h":0,"f":1048610}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$sdd.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$sdd.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 9240620;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":9109548,"h":9240620}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$sdd.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$sdd.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$sdd.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$sdd.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$sdd.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$sdd.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$sdd.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$sdd.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$sdd.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$sdd.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 9109548;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":9109548}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary<>", (TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary<>", [TAggregator], ($self) => class MultiSizeLabelNameDictionary$$ extends $.$spc.System.Object
        {
            /*TAggregator?*/ NoLabelAggregator = null;
            /*FixedSizeLabelNameDictionary<StringSequence1, ObjectSequence1, TAggregator>?*/ Label1 = null;
            /*FixedSizeLabelNameDictionary<StringSequence2, ObjectSequence2, TAggregator>?*/ Label2 = null;
            /*FixedSizeLabelNameDictionary<StringSequence3, ObjectSequence3, TAggregator>?*/ Label3 = null;
            /*FixedSizeLabelNameDictionary<StringSequenceMany, ObjectSequenceMany, TAggregator>?*/ LabelMany = null;
            $ctor$1(/*object*/ initialLabelNameDict)
            {
                super.$ctor();
                {
                    this.NoLabelAggregator = null;
                    this.Label1 = null;
                    this.Label2 = null;
                    this.Label3 = null;
                    this.LabelMany = null;
                    //switch (initialLabelNameDict)
                    {
                        let val0;
                        let val1;
                        let val2;
                        let val3;
                        let valMany;
                        $switchJumpStart1: 
                        //case TAggregator val0:
                        if ($.$is(initialLabelNameDict, TAggregator, { set $v(v){ val0 = v; } }))
                        {
                            this.NoLabelAggregator = val0;
                        }
                        //case FixedSizeLabelNameDictionary<StringSequence1, ObjectSequence1, TAggregator> val1:
                        else if ($.$is(initialLabelNameDict, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator), { set $v(v){ val1 = v; } }))
                        {
                            this.Label1 = val1;
                        }
                        //case FixedSizeLabelNameDictionary<StringSequence2, ObjectSequence2, TAggregator> val2:
                        else if ($.$is(initialLabelNameDict, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator), { set $v(v){ val2 = v; } }))
                        {
                            this.Label2 = val2;
                        }
                        //case FixedSizeLabelNameDictionary<StringSequence3, ObjectSequence3, TAggregator> val3:
                        else if ($.$is(initialLabelNameDict, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator), { set $v(v){ val3 = v; } }))
                        {
                            this.Label3 = val3;
                        }
                        //case FixedSizeLabelNameDictionary<StringSequenceMany, ObjectSequenceMany, TAggregator> valMany:
                        else if ($.$is(initialLabelNameDict, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator), { set $v(v){ valMany = v; } }))
                        {
                            this.LabelMany = valMany;
                        }
                    }
                }
                return this;
            }
            /*TAggregator? */ GetNoLabelAggregator(/*Func<TAggregator?>*/ createFunc)
            {
                if ($.$box(this.NoLabelAggregator, TAggregator) === null)
                {
                    /*TAggregator?*/ let aggregator = createFunc.Invoke();
                    if ($.$box(aggregator, TAggregator) !== null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14(TAggregator, $.$ref(() => this.NoLabelAggregator, ($v) => this.NoLabelAggregator = $v, TAggregator), aggregator, null);
                    }
                }
                return this.NoLabelAggregator;
            }
            /*FixedSizeLabelNameDictionary<TStringSequence, TObjectSequence, TAggregator> */ GetFixedSizeLabelNameDictionary(TStringSequence, TObjectSequence)
            {
                /*TStringSequence?*/ let seq = $.$default(TStringSequence);
                switch(seq)
                {
                    case $.$sdd.System.Diagnostics.Metrics.StringSequence1:
                    if (this.Label1 === null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator), $.$ref(() => this.Label1, ($v) => this.Label1 = $v, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator)), new ($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator))().$ctor$8(), null);
                    }
                    return $.$cast($.$cast(this.Label1, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator));
                    case $.$sdd.System.Diagnostics.Metrics.StringSequence2:
                    if (this.Label2 === null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator), $.$ref(() => this.Label2, ($v) => this.Label2 = $v, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator)), new ($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator))().$ctor$8(), null);
                    }
                    return $.$cast($.$cast(this.Label2, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator));
                    case $.$sdd.System.Diagnostics.Metrics.StringSequence3:
                    if (this.Label3 === null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator), $.$ref(() => this.Label3, ($v) => this.Label3 = $v, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator)), new ($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator))().$ctor$8(), null);
                    }
                    return $.$cast($.$cast(this.Label3, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator));
                    case $.$sdd.System.Diagnostics.Metrics.StringSequenceMany:
                    if (this.LabelMany === null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator), $.$ref(() => this.LabelMany, ($v) => this.LabelMany = $v, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator)), new ($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator))().$ctor$8(), null);
                    }
                    return $.$cast($.$cast(this.LabelMany, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator));
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail("Unexpected sequence type");
                    return null;
                }
            }
            /*void */ Collect(/*Action<LabeledAggregationStatistics>*/ visitFunc)
            {
                if ($.$box(this.NoLabelAggregator, TAggregator) !== null)
                {
                    /*IAggregationStatistics*/ let stats = $.$dsp(this.NoLabelAggregator, TAggregator, ($t) => $t.Collect,);
                    visitFunc.Invoke(new $.$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics().$ctor$1(stats, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)), [  ], null, null)));
                }
                this.Label1?.Collect(visitFunc);
                this.Label2?.Collect(visitFunc);
                this.Label3?.Collect(visitFunc);
                this.LabelMany?.Collect(visitFunc);
            }
            static $h = 7077932;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.MultiSizeLabelNameDictionary<${TAggregator?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.Internal.PaddingHelpers", ($self) => class PaddingHelpers
        {
            /*int*/ static CACHE_LINE_SIZE = 128;
            static $h = 131116;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":131116}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Internal.PaddingHelpers`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagnosticsHelper", ($self) => class DiagnosticsHelper
        {
            static /*bool */ CompareTags(/*IList<KeyValuePair<string, object?>>?*/ sortedTags, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags2)
            {
                if (sortedTags === tags2)
                {
                    return true;
                }
                if (sortedTags === null || tags2 === null)
                {
                    return false;
                }
                /*int*/ let count = sortedTags.System$Collections$Generic$ICollection$$$Count;
                /*int*/ let size = (($.trunc(count / ((($.$spc.System.UInt64.$z * 8) | 0))) + 1) | 0);
                /*BitMapper*/ let bitMapper = new $.$sdd.System.Diagnostics.BitMapper().$ctor$2((size >>> 0) <= 100 ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.UInt64, size, null) : $.$spc.System.Span$$($.$spc.System.UInt64).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt64), null, [size], null)));
                let tagsCol;
                if ($.$is(tags2, $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), { set $v(v){ tagsCol = v; } }))
                {
                    if (tagsCol.System$Collections$Generic$ICollection$$$Count !== count)
                    {
                        return false;
                    }
                    let secondList;
                    if ($.$is(tagsCol, $.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), { set $v(v){ secondList = v; } }))
                    {
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            /*KeyValuePair<string, object?>*/ let pair = secondList.System$Collections$Generic$IList$$$get_Item(i, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                            for(/*int*/ let j = 0; j < count; j++)
                            {
                                if (bitMapper.IsSet(j))
                                {
                                    continue;
                                }
                                /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                                /*int*/ let compareResult = $.$spc.System.String.CompareOrdinal(pair.Key, pair1.Key);
                                if (compareResult === 0 && $.$spc.System.Object.Equals$1(pair.Value, pair1.Value))
                                {
                                    bitMapper.SetBit(j);
                                    break;
                                }
                                if (compareResult < 0 || j === ((count - 1) | 0))
                                {
                                    return false;
                                }
                            }
                        }
                        return true;
                    }
                }
                /*int*/ let listCount = 0;
                let enumerator = null;
                try
                {
                    enumerator = tags2.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                    while(enumerator.System$Collections$IEnumerator$MoveNext())
                    {
                        listCount++;
                        if (listCount > sortedTags.System$Collections$Generic$ICollection$$$Count)
                        {
                            return false;
                        }
                        /*KeyValuePair<string, object?>*/ let pair = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                        for(/*int*/ let j = 0; j < count; j++)
                        {
                            if (bitMapper.IsSet(j))
                            {
                                continue;
                            }
                            /*KeyValuePair<string, object?>*/ let pair1 = sortedTags.System$Collections$Generic$IList$$$get_Item(j, [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                            /*int*/ let compareResult = $.$spc.System.String.CompareOrdinal(pair.Key, pair1.Key);
                            if (compareResult === 0 && $.$spc.System.Object.Equals$1(pair.Value, pair1.Value))
                            {
                                bitMapper.SetBit(j);
                                break;
                            }
                            if (compareResult < 0 || j === ((count - 1) | 0))
                            {
                                return false;
                            }
                        }
                    }
                    return listCount === sortedTags.System$Collections$Generic$ICollection$$$Count;
                }
                finally
                {
                    enumerator?.System$IDisposable$Dispose();
                }
            }
            static $h = 2228268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2228268}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticsHelper`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.LabelInstructionCompiler", ($self) => class LabelInstructionCompiler
        {
            static /*AggregatorLookupFunc<TAggregator> */ Create(TAggregator, /*ref AggregatorStore<TAggregator>*/ aggregatorStore, /*Func<TAggregator?>*/ createAggregatorFunc, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels)
            {
                /*LabelInstruction[]*/ let instructions = $.$sdd.System.Diagnostics.Metrics.LabelInstructionCompiler.Compile(labels);
                $.$spc.System.Array.Sort$16($.$sdd.System.Diagnostics.Metrics.LabelInstruction, instructions, new ($.$spc.System.Comparison$$($.$sdd.System.Diagnostics.Metrics.LabelInstruction))().$ctor(this,  (/*LabelInstruction*/ a, /*LabelInstruction*/ b) =>
                {
                    return $.$spc.System.String.CompareOrdinal(a.LabelName, b.LabelName);
                }, {"r":655361,"p":[{"n":"a","p":6029356},{"n":"b","p":6029356}],"n":"","d":6094892,"h":0,"f":1048578}));
                /*int*/ let expectedLabels = labels.Length;
                let $switch1 = instructions.length;
                switch($switch1)
                {
                    case 0:
                    /*TAggregator?*/ let defaultAggregator = aggregatorStore.$v.GetAggregator$1();
                    return new ($.$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc$$(TAggregator))().$ctor(this,  (/*ReadOnlySpan<KeyValuePair<string, object?>>*/ l, /*TAggregator?*/ aggregator) =>
                    {
                        if (l.Length !== expectedLabels)
                        {
                            aggregator.$v = null;
                            return false;
                        }
                        aggregator.$v = defaultAggregator;
                        return true;
                    }, {"r":262145,"p":[{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"aggregator","p":(TAggregator) => TAggregator.$h,"f":2}],"n":"","d":6094892,"h":0,"f":1048578});
                    case 1:
                    /*StringSequence1*/ let names1 = new $.$sdd.System.Diagnostics.Metrics.StringSequence1().$ctor$2($.$spc.System.Array.$ReadT1.call(instructions, 0).LabelName);
                    /*ConcurrentDictionary<ObjectSequence1, TAggregator>*/ let valuesDict1 = aggregatorStore.$v.GetLabelValuesDictionary($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, $.$ref(() => names1, ));
                    /*LabelInstructionInterpreter<ObjectSequence1, TAggregator>*/ let interpreter1 = new ($.$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter$$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator))().$ctor$1(expectedLabels, instructions, valuesDict1, createAggregatorFunc);
                    return new ($.$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc$$(TAggregator))().$ctor(interpreter1, interpreter1.GetAggregator);
                    case 2:
                    /*StringSequence2*/ let names2 = new $.$sdd.System.Diagnostics.Metrics.StringSequence2().$ctor$2($.$spc.System.Array.$ReadT1.call(instructions, 0).LabelName, $.$spc.System.Array.$ReadT1.call(instructions, 1).LabelName);
                    /*ConcurrentDictionary<ObjectSequence2, TAggregator>*/ let valuesDict2 = aggregatorStore.$v.GetLabelValuesDictionary($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, $.$ref(() => names2, ));
                    /*LabelInstructionInterpreter<ObjectSequence2, TAggregator>*/ let interpreter2 = new ($.$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter$$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator))().$ctor$1(expectedLabels, instructions, valuesDict2, createAggregatorFunc);
                    return new ($.$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc$$(TAggregator))().$ctor(interpreter2, interpreter2.GetAggregator);
                    case 3:
                    /*StringSequence3*/ let names3 = new $.$sdd.System.Diagnostics.Metrics.StringSequence3().$ctor$2($.$spc.System.Array.$ReadT1.call(instructions, 0).LabelName, $.$spc.System.Array.$ReadT1.call(instructions, 1).LabelName, $.$spc.System.Array.$ReadT1.call(instructions, 2).LabelName);
                    /*ConcurrentDictionary<ObjectSequence3, TAggregator>*/ let valuesDict3 = aggregatorStore.$v.GetLabelValuesDictionary($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, $.$ref(() => names3, ));
                    /*LabelInstructionInterpreter<ObjectSequence3, TAggregator>*/ let interpreter3 = new ($.$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter$$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator))().$ctor$1(expectedLabels, instructions, valuesDict3, createAggregatorFunc);
                    return new ($.$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc$$(TAggregator))().$ctor(interpreter3, interpreter3.GetAggregator);
                    default:
                    /*string[]*/ let labelNames = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [instructions.length], null);
                    for(/*int*/ let i = 0; i < instructions.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(labelNames, $.$spc.System.Array.$ReadT1.call(instructions, i).LabelName, i);
                    }
                    /*StringSequenceMany*/ let namesMany = new $.$sdd.System.Diagnostics.Metrics.StringSequenceMany().$ctor$2(labelNames);
                    /*ConcurrentDictionary<ObjectSequenceMany, TAggregator>*/ let valuesDictMany = aggregatorStore.$v.GetLabelValuesDictionary($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, $.$ref(() => namesMany, ));
                    /*LabelInstructionInterpreter<ObjectSequenceMany, TAggregator>*/ let interpreter4 = new ($.$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter$$$($.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator))().$ctor$1(expectedLabels, instructions, valuesDictMany, createAggregatorFunc);
                    return new ($.$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc$$(TAggregator))().$ctor(interpreter4, interpreter4.GetAggregator);
                }
            }
            static /*LabelInstruction[] */ Compile(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels)
            {
                /*LabelInstruction[]*/ let valueFetches = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdd.System.Diagnostics.Metrics.LabelInstruction), null, [labels.Length], null);
                for(/*int*/ let i = 0; i < labels.Length; i++)
                {
                    $.$spc.System.Array.$WriteT1.call(valueFetches, new $.$sdd.System.Diagnostics.Metrics.LabelInstruction().$ctor$2(i, labels.get_Item(i).$v.Key), i);
                }
                return valueFetches;
            }
            static $h = 6094892;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6094892}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.LabelInstructionCompiler`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagNode<>", (T) => $asm.$gt("$sdd.System.Diagnostics.DiagNode<>", [T], ($self) => class DiagNode$$ extends $.$spc.System.Object
        {
            $ctor$1(/*T*/ value)
            {
                super.$ctor();
                this.Value = value;
                return this;
            }
            /*T*/ Value = $.$default(T);
            /*DiagNode<T>?*/ Next = null;
            static $h = 1900588;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagNode<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.RuntimeMetrics", ($self) => class RuntimeMetrics
        {
            /*bool*/ static t_handlingFirstChanceException = false;
            /*string*/ static MeterName = null;
            /*Meter*/ static s_meter = null;
            /*string[]*/ static s_genNames = null;
            /*int*/ static s_maxGenerations = 0;
            /*Counter<long>*/ static s_exceptions = null;
            static /*void */ EnsureInitialized()
            {
            }
            /*Static constructor*/ static $cctor()
            {
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter$4($.$spc.System.Int64, "dotnet.gc.collections", new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))))().$ctor($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics, $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.GetGarbageCollectionCounts), "{collection}", "The number of garbage collections that have occurred since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter($.$spc.System.Int64, "dotnet.process.memory.working_set", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Environment.WorkingSet;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "By", "The number of bytes of physical memory mapped to the process context.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.gc.heap.total_allocated", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.GC.GetTotalAllocatedBytes(false);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "By", "The approximate number of bytes allocated on the managed GC heap since the process has started. The returned value does not include any native allocations.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter($.$spc.System.Int64, "dotnet.gc.last_collection.memory.committed_size", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.GC.GetGCMemoryInfo().TotalCommittedBytes;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "By", "The amount of committed virtual memory in use by the .NET GC, as observed during the latest garbage collection.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter$4($.$spc.System.Int64, "dotnet.gc.last_collection.heap.size", new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))))().$ctor($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics, $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.GetHeapSizes), "By", "The managed GC heap size (including fragmentation), as observed during the latest garbage collection.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter$4($.$spc.System.Int64, "dotnet.gc.last_collection.heap.fragmentation.size", new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))))().$ctor($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics, $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.GetHeapFragmentation), "By", "The heap fragmentation, as observed during the latest garbage collection.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Double, "dotnet.gc.pause.time", new ($.$spc.System.Func$$($.$spc.System.Double))().$ctor(this,  () =>
                {
                    return $.$spc.System.GC.GetTotalPauseDuration().TotalSeconds;
                }, {"r":1179649,"n":"","d":7864364,"h":0,"f":1048578}), "s", "The total amount of time paused in GC since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.jit.compiled_il.size", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Runtime.JitInfo.GetCompiledILBytes(false);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "By", "Count of bytes of intermediate language that have been compiled since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.jit.compiled_methods", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Runtime.JitInfo.GetCompiledMethodCount(false);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{method}", "The number of times the JIT compiler (re)compiled methods since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Double, "dotnet.jit.compilation.time", new ($.$spc.System.Func$$($.$spc.System.Double))().$ctor(this,  () =>
                {
                    return $.$spc.System.Runtime.JitInfo.GetCompilationTime(false).TotalSeconds;
                }, {"r":1179649,"n":"","d":7864364,"h":0,"f":1048578}), "s", "The number of times the JIT compiler (re)compiled methods since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.monitor.lock_contentions", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Threading.Monitor.LockContentionCount;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{contention}", "The number of times there was contention when trying to acquire a monitor lock since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.thread_pool.thread.count", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$cast($.$spc.System.Threading.ThreadPool.ThreadCount, $.$spc.System.Int64);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{thread}", "The number of thread pool threads that currently exist.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.thread_pool.work_item.count", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Threading.ThreadPool.CompletedWorkItemCount;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{work_item}", "The number of work items that the thread pool has completed since the process has started.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter($.$spc.System.Int64, "dotnet.thread_pool.queue.length", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Threading.ThreadPool.PendingWorkItemCount;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{work_item}", "The number of work items that are currently queued to be processed by the thread pool.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter($.$spc.System.Int64, "dotnet.timer.count", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$spc.System.Threading.Timer.ActiveCount;
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{timer}", "The number of timer instances that are currently active. An active timer is registered to tick at some point in the future and has not yet been canceled.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter($.$spc.System.Int64, "dotnet.assembly.count", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$cast($.$spc.System.AppDomain.CurrentDomain.GetAssemblies().length, $.$spc.System.Int64);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{assembly}", "The number of .NET assemblies that are currently loaded.");
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_exceptions = $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateCounter($.$spc.System.Int64, "dotnet.exceptions", "{exception}", "The number of exceptions that have been thrown in managed code.");
                $.$spc.System.AppDomain.CurrentDomain.add_FirstChanceException(new ($.$spc.System.EventHandler$$($.$spc.System.Runtime.ExceptionServices.FirstChanceExceptionEventArgs))().$ctor(this,  (/*source*/ source, /*e*/ e) =>
                {
                    if ($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.t_handlingFirstChanceException)
                    {
                        return this;
                    }
                    $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.t_handlingFirstChanceException = true;
                    $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_exceptions.Add$1(1n, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("error.type", e.Exception.GetType$1().Name));
                    $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.t_handlingFirstChanceException = false;
                }, {"r":65537,"p":[{"n":"source","p":131073},{"n":"e","p":97648641}],"n":"","d":7864364,"h":0,"f":1048578}));
                $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableUpDownCounter($.$spc.System.Int64, "dotnet.process.cpu.count", new ($.$spc.System.Func$$($.$spc.System.Int64))().$ctor(this,  () =>
                {
                    return $.$cast($.$spc.System.Environment.ProcessorCount, $.$spc.System.Int64);
                }, {"r":917505,"n":"","d":7864364,"h":0,"f":1048578}), "{cpu}", "The number of processors available to the process.");
                if (!$.$spc.System.OperatingSystem.IsBrowser() && !$.$spc.System.OperatingSystem.IsWasi() && !$.$spc.System.OperatingSystem.IsTvOS() && !($.$spc.System.OperatingSystem.IsIOS() && !$.$spc.System.OperatingSystem.IsMacCatalyst()))
                {
                    $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_meter.CreateObservableCounter$4($.$spc.System.Double, "dotnet.process.cpu.time", new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Double))))().$ctor($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics, $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.GetCpuTime), "s", "CPU time used by the process.");
                }
            }
            static /*IEnumerable<Measurement<long>> */ GetGarbageCollectionCounts()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*long*/ let collectionsFromHigherGeneration = 0n;
                    for(/*int*/ let gen = $.$spc.System.GC.MaxGeneration; gen >= 0; --gen)
                    {
                        /*long*/ let collectionsFromThisGeneration = BigInt($.$spc.System.GC.CollectionCount(gen));
                        yield new ($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))().$ctor$5(collectionsFromThisGeneration - collectionsFromHigherGeneration, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit([ new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("gc.heap.generation", $.$spc.System.Array.$ReadT1.call($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_genNames, gen)) ]));
                        collectionsFromHigherGeneration = collectionsFromThisGeneration;
                    }
                }.bind(this));
            }
            static /*IEnumerable<Measurement<double>> */ GetCpuTime()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.OperatingSystem.IsBrowser() && !$.$spc.System.OperatingSystem.IsWasi() && !$.$spc.System.OperatingSystem.IsTvOS() && !($.$spc.System.OperatingSystem.IsIOS() && !$.$spc.System.OperatingSystem.IsMacCatalyst()), "!OperatingSystem.IsBrowser() && !OperatingSystem.IsWasi() &&!OperatingSystem.IsTvOS() && !(OperatingSystem.IsIOS() && !OperatingSystem.IsMacCatalyst())");
                    /*Environment.ProcessCpuUsage*/ let processCpuUsage = $.$spc.System.Environment.CpuUsage;
                    yield new ($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Double))().$ctor$5(processCpuUsage.UserTime.TotalSeconds, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("cpu.mode", "user")], null, null)));
                    yield new ($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Double))().$ctor$5(processCpuUsage.PrivilegedTime.TotalSeconds, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), [new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("cpu.mode", "system")], null, null)));
                }.bind(this));
            }
            static /*IEnumerable<Measurement<long>> */ GetHeapSizes()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*GCMemoryInfo*/ let gcInfo = $.$spc.System.GC.GetGCMemoryInfo();
                    for(/*int*/ let i = 0; i < $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_maxGenerations; ++i)
                    {
                        yield new ($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))().$ctor$5(gcInfo.GenerationInfo.get_Item(i).$v.SizeAfterBytes, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit([ new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("gc.heap.generation", $.$spc.System.Array.$ReadT1.call($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_genNames, i)) ]));
                    }
                }.bind(this));
            }
            static /*IEnumerable<Measurement<long>> */ GetHeapFragmentation()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*GCMemoryInfo*/ let gcInfo = $.$spc.System.GC.GetGCMemoryInfo();
                    for(/*int*/ let i = 0; i < $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_maxGenerations; ++i)
                    {
                        yield new ($.$sdd.System.Diagnostics.Metrics.Measurement$$($.$spc.System.Int64))().$ctor$5(gcInfo.GenerationInfo.get_Item(i).$v.FragmentationAfterBytes, $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit([ new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2("gc.heap.generation", $.$spc.System.Array.$ReadT1.call($.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_genNames, i)) ]));
                    }
                }.bind(this));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MeterName = "System.Runtime";
                }
                {
                    this.s_meter = new $.$sdd.System.Diagnostics.Metrics.Meter().$ctor$2("System.Runtime"/*MeterName*/);
                }
                {
                    this.s_genNames = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.String.$type, [ "gen0", "gen1", "gen2", "loh", "poh" ], null, null);
                }
                {
                    this.s_maxGenerations = $.$spc.System.Math.Min$4($.$spc.System.GC.GetGCMemoryInfo().GenerationInfo.Length, $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.s_genNames.length);
                }
            }
            static $h = 7864364;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":7864364}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.RuntimeMetrics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter<,>", (TObjectSequence, TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.LabelInstructionInterpreter<,>", [TObjectSequence, TAggregator], ($self) => class LabelInstructionInterpreter$$$ extends $.$spc.System.Object
        {
            /*int*/ _expectedLabelCount = 0;
            /*LabelInstruction[]*/ _instructions = null;
            /*ConcurrentDictionary<TObjectSequence, TAggregator>*/ _valuesDict = null;
            /*Func<TObjectSequence, TAggregator?>*/ _createAggregator = null;
            $ctor$1(/*int*/ expectedLabelCount, /*LabelInstruction[]*/ instructions, /*ConcurrentDictionary<TObjectSequence, TAggregator>*/ valuesDict, /*Func<TAggregator?>*/ createAggregator)
            {
                super.$ctor();
                {
                    this._expectedLabelCount = expectedLabelCount;
                    this._instructions = instructions;
                    this._valuesDict = valuesDict;
                    this._createAggregator = new ($.$spc.System.Func$$$(TObjectSequence, TAggregator))().$ctor(this,  (/*_*/ _0) =>
                    {
                        return createAggregator.Invoke();
                    }, {"r":TAggregator?.$h??1572864,"p":[{"n":"_","p":TObjectSequence?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":1048578});
                }
                return this;
            }
            /*bool */ GetAggregator(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels, /*out TAggregator?*/ aggregator)
            {
                aggregator.$v = null;
                if (labels.Length !== this._expectedLabelCount)
                {
                    return false;
                }
                /*TObjectSequence*/ let values = $.$default(TObjectSequence);
                if ($.$is(values, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany))
                {
                    values = $.$cast($.$cast(new $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), null, [this._expectedLabelCount], null)), $.$spc.System.Object), TObjectSequence);
                }
                /*Span<object?>*/ let indexedValues = $.$dsp(values, TObjectSequence, ($t) => $t.System$Diagnostics$Metrics$IObjectSequence$AsSpan,);
                for(/*int*/ let i = 0; i < this._instructions.length; i++)
                {
                    /*LabelInstruction*/ let instr = $.$spc.System.Array.$ReadT1.call(this._instructions, i);
                    if ($.$spc.System.String.op_Inequality(instr.LabelName, labels.get_Item(instr.SourceIndex).$v.Key))
                    {
                        return false;
                    }
                    indexedValues.get_Item(i).$v = labels.get_Item(instr.SourceIndex).$v.Value;
                }
                if (!this._valuesDict.TryGetValue(values, aggregator))
                {
                    aggregator.$v = this._createAggregator.Invoke(values);
                    if (aggregator.$v === null)
                    {
                        return true;
                    }
                    aggregator.$v = this._valuesDict.GetOrAdd$2(values, aggregator.$v);
                }
                return true;
            }
            static $h = 6160428;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.LabelInstructionInterpreter<${TObjectSequence?.$fullName},${TAggregator?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.AggregationManager", ($self) => class AggregationManager extends $.$spc.System.Object
        {
            /*double*/ static MinCollectionTimeSecs = 0.1;
            /*QuantileAggregation*/ static s_defaultHistogramConfig = null;
            /*List<Predicate<Instrument>>*/ _instrumentConfigFuncs = null;
            /*TimeSpan*/ CollectionPeriod;
            /*int*/ MaxTimeSeries = 0;
            /*int*/ MaxHistograms = 0;
            /*Dictionary<Instrument, bool>*/ _instruments = null;
            /*ConcurrentDictionary<Instrument, InstrumentState>*/ _instrumentStates = null;
            /*CancellationTokenSource*/ _cts = null;
            /*Thread?*/ _collectThread = null;
            /*Timer?*/ _pollingTimer = null;
            /*MeterListener*/ _listener = null;
            /*int*/ _currentTimeSeries = 0;
            /*int*/ _currentHistograms = 0;
            /*Action<Instrument, LabeledAggregationStatistics, InstrumentState?>*/ _collectMeasurement = null;
            /*Action<DateTime, DateTime>*/ _beginCollection = null;
            /*Action<DateTime, DateTime>*/ _endCollection = null;
            /*Action<Instrument, InstrumentState>*/ _beginInstrumentMeasurements = null;
            /*Action<Instrument, InstrumentState>*/ _endInstrumentMeasurements = null;
            /*Action<Instrument, InstrumentState?>*/ _instrumentPublished = null;
            /*Action*/ _initialInstrumentEnumerationComplete = null;
            /*Action<Exception>*/ _collectionError = null;
            /*Action*/ _timeSeriesLimitReached = null;
            /*Action*/ _histogramLimitReached = null;
            /*Action<Exception>*/ _observableInstrumentCallbackError = null;
            /*DateTime*/ _startTime;
            /*DateTime*/ _intervalStartTime;
            /*DateTime*/ _nextIntervalStartTime;
            /*Func<Aggregator?>*/ _histogramAggregatorFactory = null;
            $ctor$1(/*int*/ maxTimeSeries, /*int*/ maxHistograms, /*Action<Instrument, LabeledAggregationStatistics, InstrumentState?>*/ collectMeasurement, /*Action<DateTime, DateTime>*/ beginCollection, /*Action<DateTime, DateTime>*/ endCollection, /*Action<Instrument, InstrumentState>*/ beginInstrumentMeasurements, /*Action<Instrument, InstrumentState>*/ endInstrumentMeasurements, /*Action<Instrument, InstrumentState?>*/ instrumentPublished, /*Action*/ initialInstrumentEnumerationComplete, /*Action<Exception>*/ collectionError, /*Action*/ timeSeriesLimitReached, /*Action*/ histogramLimitReached, /*Action<Exception>*/ observableInstrumentCallbackError)
            {
                super.$ctor();
                {
                    this.MaxTimeSeries = maxTimeSeries;
                    this.MaxHistograms = maxHistograms;
                    this._collectMeasurement = collectMeasurement;
                    this._beginCollection = beginCollection;
                    this._endCollection = endCollection;
                    this._beginInstrumentMeasurements = beginInstrumentMeasurements;
                    this._endInstrumentMeasurements = endInstrumentMeasurements;
                    this._instrumentPublished = instrumentPublished;
                    this._initialInstrumentEnumerationComplete = initialInstrumentEnumerationComplete;
                    this._collectionError = collectionError;
                    this._timeSeriesLimitReached = timeSeriesLimitReached;
                    this._histogramLimitReached = histogramLimitReached;
                    this._observableInstrumentCallbackError = observableInstrumentCallbackError;
                    this._listener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                    this._listener.InstrumentPublished(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this, this.PublishedInstrument));
                    this._listener.MeasurementsCompleted(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object))().$ctor(this, this.CompletedMeasurements));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Double, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Double))().$ctor(this,  (/**/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update(m, l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":1179649},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Single, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Single))().$ctor(this,  (/*i*/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$cast(m, $.$spc.System.Double), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":1114113},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Int64, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int64))().$ctor(this,  (/*i*/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$cast(m, $.$spc.System.Double), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":917505},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Int32, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int32))().$ctor(this,  (/*i*/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$cast(m, $.$spc.System.Double), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":655361},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Int16, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int16))().$ctor(this,  (/*i*/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$cast(m, $.$spc.System.Double), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":524289},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Byte, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Byte))().$ctor(this,  (/**/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$cast(m, $.$spc.System.Double), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":393217},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                    this._listener.SetMeasurementEventCallback($.$spc.System.Decimal, new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Decimal))().$ctor(this,  (/*i*/ i, /*m*/ m, /*l*/ l, /*c*/ c) =>
                    {
                        return ($.$cast(c, $.$sdd.System.Diagnostics.Metrics.InstrumentState)).Update($.$spc.System.Decimal.op_Explicit$12(m), l);
                    }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"m","p":35061761},{"n":"l","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"c","p":131073}],"n":"","d":4259884,"h":0,"f":1048578}));
                }
                return this;
            }
            /*void */ Include(/*string*/ meterName)
            {
                this.Include$2(new ($.$spc.System.Predicate$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$spc.System.String.Equals$3.call(i.Meter.Name, meterName, 5/*StringComparison.OrdinalIgnoreCase*/);
                }, {"r":262145,"p":[{"n":"i","p":5505068}],"n":"","d":4259884,"h":0,"f":1048578}));
            }
            /*void */ IncludeAll()
            {
                this.Include$2(new ($.$spc.System.Predicate$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  (/*i*/ i) =>
                {
                    return true;
                }, {"r":262145,"p":[{"n":"i","p":5505068}],"n":"","d":4259884,"h":0,"f":1048578}));
            }
            /*void */ IncludePrefix(/*string*/ meterNamePrefix)
            {
                this.Include$2(new ($.$spc.System.Predicate$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$spc.System.String.StartsWith$1.call(i.Meter.Name, meterNamePrefix, 5/*StringComparison.OrdinalIgnoreCase*/);
                }, {"r":262145,"p":[{"n":"i","p":5505068}],"n":"","d":4259884,"h":0,"f":1048578}));
            }
            /*void */ Include$1(/*string*/ meterName, /*string*/ instrumentName)
            {
                this.Include$2(new ($.$spc.System.Predicate$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  (/*i*/ i) =>
                {
                    return $.$spc.System.String.Equals$3.call(i.Meter.Name, meterName, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.Equals$3.call(i.Name, instrumentName, 5/*StringComparison.OrdinalIgnoreCase*/);
                }, {"r":262145,"p":[{"n":"i","p":5505068}],"n":"","d":4259884,"h":0,"f":1048578}));
            }
            /*void */ Include$2(/*Predicate<Instrument>*/ instrumentFilter)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this._instrumentConfigFuncs.Add(instrumentFilter);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*void */ SetHistogramAggregation(/*Func<Aggregator?>*/ histogramAggregatorFactory)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this._histogramAggregatorFactory = histogramAggregatorFactory;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*AggregationManager */ SetCollectionPeriod(/*TimeSpan*/ collectionPeriod)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(collectionPeriod.TotalSeconds >= 0.1/*MinCollectionTimeSecs*/, "collectionPeriod.TotalSeconds >= MinCollectionTimeSecs");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this.CollectionPeriod = collectionPeriod;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
                return this;
            }
            /*void */ CompletedMeasurements(/*Instrument*/ instrument, /*object?*/ cookie)
            {
                this._instruments.Remove(instrument);
                $.$spc.System.Diagnostics.Debug.Assert$1(!(cookie === null), "cookie is not null");
                this._endInstrumentMeasurements.Invoke(instrument, $.$cast(cookie, $.$sdd.System.Diagnostics.Metrics.InstrumentState));
                this.RemoveInstrumentState(instrument);
            }
            /*void */ PublishedInstrument(/*Instrument*/ instrument, /*MeterListener*/ _)
            {
                /*InstrumentState?*/ let state = this.GetInstrumentState(instrument);
                this._instrumentPublished.Invoke(instrument, state);
                if (state !== null)
                {
                    this._beginInstrumentMeasurements.Invoke(instrument, state);
                    if (!this._instruments.ContainsKey(instrument))
                    {
                        this._listener.EnableMeasurementEvents(instrument, state);
                        this._instruments.Add(instrument, true);
                    }
                }
            }
            /*void */ Start()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._collectThread === null && !this._cts.IsCancellationRequested, "_collectThread == null && !_cts.IsCancellationRequested");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.CollectionPeriod.TotalSeconds >= 0.1/*MinCollectionTimeSecs*/, "CollectionPeriod.TotalSeconds >= MinCollectionTimeSecs");
                this._intervalStartTime = this._nextIntervalStartTime = this._startTime = $.$spc.System.DateTime.UtcNow;
                if ($.$spc.System.OperatingSystem.IsBrowser())
                {
                    /*TimeSpan*/ let delayTime = this.CalculateDelayTime(this.CollectionPeriod.TotalSeconds);
                    this._pollingTimer = new $.$spc.System.Threading.Timer().$ctor$2(new $.$spc.System.Threading.TimerCallback().$ctor(this, this.CollectOnTimer), null, $.$cast(delayTime.TotalMilliseconds, $.$spc.System.Int32), 0);
                }
                else 
                {
                    this._collectThread = new $.$spc.System.Threading.Thread().$ctor$3(new $.$spc.System.Threading.ThreadStart().$ctor(this, this.CollectWorker));
                    this._collectThread.IsBackground = true;
                    this._collectThread.Name = "MetricsEventSource CollectWorker";
                    this._collectThread.Start$2();
                }
                this._listener.Start();
                this._initialInstrumentEnumerationComplete.Invoke();
            }
            /*void */ Update()
            {
                let tempListener = null;
                try
                {
                    tempListener = new $.$sdd.System.Diagnostics.Metrics.MeterListener().$ctor$1();
                    tempListener.InstrumentPublished(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor(this, this.PublishedInstrument));
                    tempListener.MeasurementsCompleted(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object))().$ctor(this, this.CompletedMeasurements));
                    tempListener.Start();
                }
                finally
                {
                    tempListener?.System$IDisposable$Dispose();
                }
                this._initialInstrumentEnumerationComplete.Invoke();
            }
            /*TimeSpan */ CalculateDelayTime(/*double*/ collectionIntervalSecs)
            {
                this._intervalStartTime = this._nextIntervalStartTime;
                /*DateTime*/ let now = $.$spc.System.DateTime.UtcNow;
                /*double*/ let secsSinceStart = ($.$spc.System.DateTime.op_Subtraction$1(now, this._startTime)).TotalSeconds;
                /*double*/ let alignUpSecsSinceStart = Math.ceil(secsSinceStart / collectionIntervalSecs) * collectionIntervalSecs;
                this._nextIntervalStartTime = this._startTime.AddSeconds(alignUpSecsSinceStart);
                /*DateTime*/ let minNextInterval = this._intervalStartTime.AddSeconds(collectionIntervalSecs);
                if ($.$spc.System.DateTime.op_LessThanOrEqual(this._nextIntervalStartTime, minNextInterval))
                {
                    this._nextIntervalStartTime = minNextInterval;
                }
                return $.$spc.System.DateTime.op_Subtraction$1(this._nextIntervalStartTime, now);
            }
            /*void */ CollectWorker()
            {
                try
                {
                    /*double*/ let collectionIntervalSecs = -1;
                    /*CancellationToken*/ let cancelToken;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            collectionIntervalSecs = this.CollectionPeriod.TotalSeconds;
                            cancelToken = this._cts.Token;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(collectionIntervalSecs >= 0.1/*MinCollectionTimeSecs*/, "collectionIntervalSecs >= MinCollectionTimeSecs");
                    /*DateTime*/ let startTime = $.$spc.System.DateTime.UtcNow;
                    /*DateTime*/ let intervalStartTime = startTime;
                    while(!this._cts.Token.IsCancellationRequested)
                    {
                        /*TimeSpan*/ let delayTime = this.CalculateDelayTime(collectionIntervalSecs);
                        if (cancelToken.WaitHandle.WaitOne$1(delayTime))
                        {
                            break;
                        }
                        this._beginCollection.Invoke(this._intervalStartTime, this._nextIntervalStartTime);
                        this.Collect();
                        this._endCollection.Invoke(this._intervalStartTime, this._nextIntervalStartTime);
                    }
                }
                catch(e)
                {
                    this._collectionError.Invoke(e);
                }
            }
            /*void */ CollectOnTimer(/*object?*/ _)
            {
                try
                {
                    /*CancellationToken*/ let cancelToken = this._cts.Token;
                    /*double*/ let collectionIntervalSecs = this.CollectionPeriod.TotalSeconds;
                    if (cancelToken.IsCancellationRequested)
                    {
                        return;
                    }
                    this._beginCollection.Invoke(this._intervalStartTime, this._nextIntervalStartTime);
                    this.Collect();
                    this._endCollection.Invoke(this._intervalStartTime, this._nextIntervalStartTime);
                    /*TimeSpan*/ let delayTime = this.CalculateDelayTime(collectionIntervalSecs);
                    this._pollingTimer.Change($.$cast(delayTime.TotalMilliseconds, $.$spc.System.Int32), 0);
                }
                catch(e)
                {
                    this._collectionError.Invoke(e);
                }
            }
            /*void */ Dispose()
            {
                this._cts.Cancel();
                if ($.$spc.System.OperatingSystem.IsBrowser())
                {
                    this._pollingTimer?.Dispose$1();
                    this._pollingTimer = null;
                }
                else 
                {
                    this._collectThread?.Join$1();
                    this._collectThread = null;
                }
                this._listener.Dispose();
            }
            /*void */ RemoveInstrumentState(/*Instrument*/ instrument)
            {
                this._instrumentStates.TryRemove(instrument, $.$discardRef());
            }
            /*InstrumentState? */ GetInstrumentState(/*Instrument*/ instrument)
            {
                /*InstrumentState?*/ let instrumentState;
                if (!this._instrumentStates.TryGetValue(instrument, $.$ref(() => instrumentState, ($v) => instrumentState = $v, $.$sdd.System.Diagnostics.Metrics.InstrumentState)))
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            var $en5 = this._instrumentConfigFuncs.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var filter = $en5.Current;
                                {
                                    if (filter.Invoke(instrument))
                                    {
                                        instrumentState = this.BuildInstrumentState(instrument);
                                        if (instrumentState !== null)
                                        {
                                            this._instrumentStates.TryAdd(instrument, instrumentState);
                                            this._instrumentStates.TryGetValue(instrument, $.$ref(() => instrumentState, ($v) => instrumentState = $v, $.$sdd.System.Diagnostics.Metrics.InstrumentState));
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                return instrumentState;
            }
            /*InstrumentState? */ BuildInstrumentState(/*Instrument*/ instrument)
            {
                /*Func<Aggregator?>?*/ let createAggregatorFunc = this.GetAggregatorFactory(instrument);
                if (createAggregatorFunc === null)
                {
                    return null;
                }
                /*Type*/ let aggregatorType = $.$spc.System.Array.$ReadT1.call($.$spc.System.Object.GetType.call(createAggregatorFunc).GenericTypeArguments, 0);
                /*Type*/ let instrumentStateType = $.$sdd.System.Diagnostics.Metrics.InstrumentState$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ aggregatorType ], null, null));
                return $.$cast($.$spc.System.Activator.CreateInstance$1(instrumentStateType, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ createAggregatorFunc ], null, null)), $.$sdd.System.Diagnostics.Metrics.InstrumentState);
            }
            /*Func<Aggregator?>? */ GetAggregatorFactory(/*Instrument*/ instrument)
            {
                /*Type*/ let type = $.$spc.System.Object.GetType.call(instrument);
                /*Type?*/ let genericDefType = null;
                genericDefType = type.IsGenericType ? type.GetGenericTypeDefinition() : null;
                if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.Counter$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.CounterAggregator().$ctor$2(true) : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.ObservableCounter$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.ObservableCounterAggregator().$ctor$2(true) : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.ObservableGauge$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.LastValue().$ctor$2() : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.Gauge$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.SynchronousLastValue().$ctor$2() : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.Histogram$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return (!this.CheckHistogramAllowed() || !this.CheckTimeSeriesAllowed()) ? null : this._histogramAggregatorFactory.Invoke();
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.UpDownCounter$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.CounterAggregator().$ctor$2(false) : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else if ($.$spc.System.Type.op_Equality$1(genericDefType, $.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$().$type))
                {
                    return new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                return this.CheckTimeSeriesAllowed() ? new $.$sdd.System.Diagnostics.Metrics.ObservableCounterAggregator().$ctor$2(false) : null;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
                }
                else 
                {
                    return null;
                }
            }
            /*bool */ CheckTimeSeriesAllowed()
            {
                if (this._currentTimeSeries < this.MaxTimeSeries)
                {
                    this._currentTimeSeries++;
                    return true;
                }
                else if (this._currentTimeSeries === this.MaxTimeSeries)
                {
                    this._currentTimeSeries++;
                    this._timeSeriesLimitReached.Invoke();
                    return false;
                }
                else 
                {
                    return false;
                }
            }
            /*bool */ CheckHistogramAllowed()
            {
                if (this._currentHistograms < this.MaxHistograms)
                {
                    this._currentHistograms++;
                    return true;
                }
                else if (this._currentHistograms === this.MaxHistograms)
                {
                    this._currentHistograms++;
                    this._histogramLimitReached.Invoke();
                    return false;
                }
                else 
                {
                    return false;
                }
            }
            /*void */ Collect()
            {
                try
                {
                    this._listener.RecordObservableInstruments();
                }
                catch(e)
                {
                    this._observableInstrumentCallbackError.Invoke(e);
                }
                var $en2 = this._instrumentStates.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kv = $en2.Current;
                    {
                        kv.Value.Collect(kv.Key, new ($.$spc.System.Action$$($.$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics))().$ctor(this,  (/*LabeledAggregationStatistics*/ labeledAggStats) =>
                        {
                            this._collectMeasurement.Invoke(kv.Key, labeledAggStats, kv.Value);
                        }, {"r":65537,"p":[{"n":"labeledAggStats","p":5963820}],"n":"","d":4259884,"h":0,"f":1048578}));
                    }
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._instrumentConfigFuncs = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Predicate$$($.$sdd.System.Diagnostics.Metrics.Instrument)))().$ctor$1();
                this.CollectionPeriod = $.$default($.$spc.System.TimeSpan);
                this._instruments = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Boolean))().$ctor$1();
                this._instrumentStates = new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.InstrumentState))().$ctor$1();
                this._cts = new $.$spc.System.Threading.CancellationTokenSource().$ctor$1();
                this._startTime = $.$default($.$spc.System.DateTime);
                this._intervalStartTime = $.$default($.$spc.System.DateTime);
                this._nextIntervalStartTime = $.$default($.$spc.System.DateTime);
                this._histogramAggregatorFactory = new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                {
                    return new $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator().$ctor$2($.$sdd.System.Diagnostics.Metrics.AggregationManager.s_defaultHistogramConfig);
                }, {"r":4325420,"n":"","d":4259884,"h":0,"f":1048578});
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultHistogramConfig = new $.$sdd.System.Diagnostics.Metrics.QuantileAggregation().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Double), [0.5, 0.95, 0.99], [-1], null));
                }
            }
            static $h = 4259884;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4259884}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Metrics.AggregationManager`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.SynchronizedList<>", (T) => $asm.$gt("$sdd.System.Diagnostics.SynchronizedList<>", [T], ($self) => class SynchronizedList$$ extends $.$spc.System.Object
        {
            /*object*/ _writeLock = null;
            /*T[]*/ _volatileArray = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._volatileArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [  ], null, null);
                    this._writeLock = new $.$spc.System.Object().$ctor();
                }
                return this;
            }
            /*void */ Add(/*T*/ item)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._writeLock)
                    {
                        /*T[]*/ let newArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((this._volatileArray.length + 1) | 0)], null);
                        $.$spc.System.Array.Copy(this._volatileArray, newArray, this._volatileArray.length);
                        $.$spc.System.Array.$WriteT1.call(newArray, item, this._volatileArray.length);
                        this._volatileArray = newArray;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._writeLock)
                }
            }
            /*bool */ AddIfNotExist(/*T*/ item)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._writeLock)
                    {
                        /*int*/ let index = $.$spc.System.Array.IndexOf$3(T, this._volatileArray, item);
                        if (index >= 0)
                        {
                            return false;
                        }
                        /*T[]*/ let newArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((this._volatileArray.length + 1) | 0)], null);
                        $.$spc.System.Array.Copy(this._volatileArray, newArray, this._volatileArray.length);
                        $.$spc.System.Array.$WriteT1.call(newArray, item, this._volatileArray.length);
                        this._volatileArray = newArray;
                        return true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._writeLock)
                }
            }
            /*bool */ Remove(/*T*/ item)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._writeLock)
                    {
                        /*int*/ let index = $.$spc.System.Array.IndexOf$3(T, this._volatileArray, item);
                        if (index < 0)
                        {
                            return false;
                        }
                        /*T[]*/ let newArray = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [((this._volatileArray.length - 1) | 0)], null);
                        $.$spc.System.Array.Copy(this._volatileArray, newArray, index);
                        $.$spc.System.Array.Copy$1(this._volatileArray, ((index + 1) | 0), newArray, index, ((((this._volatileArray.length - index) | 0) - 1) | 0));
                        this._volatileArray = newArray;
                        return true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._writeLock)
                }
            }
            /*int */ get Count()
            {
                return this._volatileArray.length;
            }
            /*void */ EnumWithFunc(TParent, /*ActivitySource.Function<T, TParent>*/ func, /*ref ActivityCreationOptions<TParent>*/ data, /*ref ActivitySamplingResult*/ samplingResult, /*ref ActivityCreationOptions<ActivityContext>*/ dataWithContext)
            {
                let $i1 = 0;
                let $arr1 = this._volatileArray;
                while ($i1 < $arr1.length)
                {
                    let item = $arr1[$i1++];
                    func.Invoke(item, data, samplingResult, dataWithContext);
                }
            }
            /*void */ EnumWithAction(/*Action<T, object>*/ action, /*object*/ arg)
            {
                let $i1 = 0;
                let $arr1 = this._volatileArray;
                while ($i1 < $arr1.length)
                {
                    let item = $arr1[$i1++];
                    action.Invoke(item, arg);
                }
            }
            /*void */ EnumWithExceptionNotification(/*Activity*/ activity, /*Exception*/ exception, /*ref TagList*/ tags)
            {
                if ($.$spc.System.Type.op_Inequality$1(T.$type, $.$sdd.System.Diagnostics.ActivityListener.$type))
                {
                    return;
                }
                let $i1 = 0;
                let $arr1 = this._volatileArray;
                while ($i1 < $arr1.length)
                {
                    let item = $arr1[$i1++];
                    ($.$as(item, $.$sdd.System.Diagnostics.ActivityListener)).ExceptionRecorder?.Invoke(activity, exception, tags);
                }
            }
            static $h = 8716332;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SynchronizedList<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.ActivityListener", ($self) => class ActivityListener extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Action<Activity>?*/ ActivityStarted = null;
            /*Action<Activity>?*/ ActivityStopped = null;
            /*ExceptionRecorder?*/ ExceptionRecorder = null;
            /*Func<ActivitySource, bool>?*/ ShouldListenTo = null;
            /*SampleActivity<string>?*/ SampleUsingParentId = null;
            /*SampleActivity<ActivityContext>?*/ Sample = null;
            /*void */ Dispose()
            {
                return $.$sdd.System.Diagnostics.ActivitySource.DetachListener(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 983084;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":983084}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ActivityListener`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.HistogramStatistics", ($self) => class HistogramStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*QuantileValue[]*/ quantiles, /*int*/ count, /*double*/ sum)
            {
                super.$ctor();
                {
                    this.Quantiles = quantiles;
                    this.Count = count;
                    this.Sum = sum;
                }
                return this;
            }
            /*QuantileValue[]*/ Quantiles = null;
            /*int*/ Count = 0;
            /*double*/ Sum = 0;
            static $h = 5308460;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5308460}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IAggregationStatistics ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.HistogramStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramStatistics", ($self) => class Base2ExponentialHistogramStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*int*/ scale, /*long*/ zeroCount, /*double*/ sum, /*long*/ count, /*double*/ min, /*double*/ max, /*long[]*/ buckets)
            {
                super.$ctor();
                {
                    this.Scale = scale;
                    this.ZeroCount = zeroCount;
                    this.Sum = sum;
                    this.Count = count;
                    this.Minimum = min;
                    this.Maximum = max;
                    this.PositiveBuckets = buckets;
                }
                return this;
            }
            /*int*/ Scale = 0;
            /*long*/ ZeroCount = 0n;
            /*double*/ Sum = 0;
            /*long*/ Count = 0n;
            /*double*/ Minimum = 0;
            /*double*/ Maximum = 0;
            /*long[]*/ PositiveBuckets = null;
            static $h = 4587564;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4587564}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IAggregationStatistics ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.Base2ExponentialHistogramStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DsesActivitySourceListener", ($self) => class DsesActivitySourceListener extends $.$spc.System.Object
        {
            /*DiagnosticSourceEventSource*/ _eventSource = null;
            /*DsesFilterAndTransform?*/ _wildcardSpec = null;
            /*Dictionary<SpecLookupKey, DsesFilterAndTransform>?*/ _specsBySourceNameAndActivityName = null;
            /*HashSet<string>?*/ _listenToActivitySourceNames = null;
            /*bool*/ _hasActivityNameSpecDefined = false;
            /*ActivityListener?*/ _activityListener = null;
            static /*DsesActivitySourceListener */ Create(/*DiagnosticSourceEventSource*/ eventSource, /*DsesFilterAndTransform*/ activitySourceSpecs)
            {
                /*var*/ let listener = new $.$sdd.System.Diagnostics.DsesActivitySourceListener().$ctor$1(eventSource);
                listener.NormalizeActivitySourceSpecsList(activitySourceSpecs);
                listener.CreateActivityListener();
                return listener;
            }
            $ctor$1(/*DiagnosticSourceEventSource*/ eventSource)
            {
                super.$ctor();
                {
                    this._eventSource = eventSource;
                }
                return this;
            }
            /*void */ Dispose()
            {
                this._activityListener?.Dispose();
                this._activityListener = null;
                this._wildcardSpec = null;
                this._specsBySourceNameAndActivityName = null;
                this._listenToActivitySourceNames = null;
            }
            /*void */ NormalizeActivitySourceSpecsList(/*DsesFilterAndTransform?*/ activitySourceSpecs)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(activitySourceSpecs !== null, "activitySourceSpecs != null");
                while(activitySourceSpecs !== null)
                {
                    /*DsesFilterAndTransform?*/ let currentActivitySourceSpec = activitySourceSpecs;
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(currentActivitySourceSpec.SourceName, null), "currentActivitySourceSpec.SourceName != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(currentActivitySourceSpec.SampleFunc !== null, "currentActivitySourceSpec.SampleFunc != null");
                    activitySourceSpecs = activitySourceSpecs.Next;
                    if ($.$spc.System.String.op_Equality(currentActivitySourceSpec.SourceName, "*"))
                    {
                        if (this._wildcardSpec !== null)
                        {
                            if (this._eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                            {
                                this._eventSource.Message("DiagnosticSource: Ignoring wildcard activity source filterAndPayloadSpec rule because a previous rule was defined");
                            }
                            continue;
                        }
                        this._wildcardSpec = currentActivitySourceSpec;
                    }
                    else 
                    {
                        /*var*/ let specs = this._specsBySourceNameAndActivityName ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey, $.$sdd.System.Diagnostics.DsesFilterAndTransform))().$ctor$3($.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKeyComparer.Instance);
                        /*var*/ let allSources = this._listenToActivitySourceNames ??= new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$2($.$spc.System.StringComparer.OrdinalIgnoreCase);
                        /*SpecLookupKey*/ let key = new $.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey().$ctor$2(currentActivitySourceSpec.SourceName, currentActivitySourceSpec.ActivityName);
                        if (!specs.TryAdd(key, currentActivitySourceSpec))
                        {
                            LogIgnoredSpecRule.call(this, currentActivitySourceSpec.SourceName, currentActivitySourceSpec.ActivityName);
                            continue;
                        }
                        allSources.Add(key.activitySourceName);
                        if ($.$spc.System.String.op_Inequality(key.activityName, null))
                        {
                            this._hasActivityNameSpecDefined = true;
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(this._wildcardSpec !== null || this._specsBySourceNameAndActivityName !== null, "_wildcardSpec != null || _specsBySourceNameAndActivityName != null");
                /*void*/  function LogIgnoredSpecRule(/*string*/ activitySourceName, /*string?*/ activityName)
                {
                    if (this._eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                    {
                        if ($.$spc.System.String.op_Equality(activityName, null))
                        {
                            this._eventSource.Message(`DiagnosticSource: Ignoring filterAndPayloadSpec rule for '[AS]${activitySourceName}' because a previous rule was defined`);
                        }
                        else 
                        {
                            this._eventSource.Message(`DiagnosticSource: Ignoring filterAndPayloadSpec rule for '[AS]${activitySourceName}+${activityName}' because a previous rule was defined`);
                        }
                    }
                }
            }
            /*void */ CreateActivityListener()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._activityListener === null, "_activityListener == null");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._wildcardSpec !== null || this._specsBySourceNameAndActivityName !== null, "_wildcardSpec != null\r\n            || _specsBySourceNameAndActivityName != null");
                this._activityListener = new $.$sdd.System.Diagnostics.ActivityListener().$ctor$1();
                this._activityListener.SampleUsingParentId = new ($.$sdd.System.Diagnostics.SampleActivity$$($.$spc.System.String))().$ctor(this, this.OnSampleUsingParentId);
                this._activityListener.Sample = new ($.$sdd.System.Diagnostics.SampleActivity$$($.$sdd.System.Diagnostics.ActivityContext))().$ctor(this, this.OnSample);
                this._activityListener.ShouldListenTo = new ($.$spc.System.Func$$$($.$sdd.System.Diagnostics.ActivitySource, $.$spc.System.Boolean))().$ctor(this,  (/*activitySource*/ activitySource) =>
                {
                    return this._wildcardSpec !== null || (this._listenToActivitySourceNames !== null && this._listenToActivitySourceNames.Contains(activitySource.Name));
                }, {"r":262145,"p":[{"n":"activitySource","p":1114156}],"n":"","d":2752556,"h":0,"f":1048578});
                this._activityListener.ActivityStarted = new ($.$spc.System.Action$$($.$sdd.System.Diagnostics.Activity))().$ctor(this, this.OnActivityStarted);
                this._activityListener.ActivityStopped = new ($.$spc.System.Action$$($.$sdd.System.Diagnostics.Activity))().$ctor(this, this.OnActivityStopped);
                $.$sdd.System.Diagnostics.ActivitySource.AddActivityListener(this._activityListener);
            }
            /*bool */ TryFindSpecForActivity(/*string*/ activitySourceName, /*string*/ activityName, /*out DsesFilterAndTransform?*/ spec)
            {
                if (this._specsBySourceNameAndActivityName !== null)
                {
                    if (this._hasActivityNameSpecDefined && this._specsBySourceNameAndActivityName.TryGetValue(new $.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey().$ctor$2(activitySourceName, activityName), spec))
                    {
                        return true;
                    }
                    if (this._specsBySourceNameAndActivityName.TryGetValue(new $.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey().$ctor$2(activitySourceName, null), spec))
                    {
                        return true;
                    }
                }
                return (spec.$v = this._wildcardSpec).$v !== null;
            }
            /*void */ OnActivityStarted(/*Activity*/ activity)
            {
                /*var*/ let spec;
                if (this.TryFindSpecForActivity(activity.Source.Name, activity.OperationName, $.$ref(() => spec, ($v) => spec = $v, $.$sdd.System.Diagnostics.DsesFilterAndTransform)) && (spec.Events & 1/*DsesActivityEvents.ActivityStart*/) !== 0)
                {
                    this._eventSource.ActivityStart(activity.Source.Name, activity.OperationName, spec.Morph(activity));
                }
            }
            /*void */ OnActivityStopped(/*Activity*/ activity)
            {
                /*var*/ let spec;
                if (this.TryFindSpecForActivity(activity.Source.Name, activity.OperationName, $.$ref(() => spec, ($v) => spec = $v, $.$sdd.System.Diagnostics.DsesFilterAndTransform)) && (spec.Events & 2/*DsesActivityEvents.ActivityStop*/) !== 0)
                {
                    this._eventSource.ActivityStop(activity.Source.Name, activity.OperationName, spec.Morph(activity));
                }
            }
            /*ActivitySamplingResult */ OnSampleUsingParentId(/*ref ActivityCreationOptions<string>*/ options)
            {
                /*ActivityCreationOptions<ActivityContext>*/ let activityContextOptions = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext))();
                return this.OnSample$1(options.$v.Source.Name, options.$v.Name, false, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext), () => activityContextOptions, ($v) => activityContextOptions = $v, null));
            }
            /*ActivitySamplingResult */ OnSample(/*ref ActivityCreationOptions<ActivityContext>*/ options)
            {
                return this.OnSample$1(options.$v.Source.Name, options.$v.Name, true, options);
            }
            /*ActivitySamplingResult */ OnSample$1(/*string*/ activitySourceName, /*string*/ activityName, /*bool*/ hasActivityContext, /*ref ActivityCreationOptions<ActivityContext>*/ options)
            {
                /*var*/ let spec;
                return this.TryFindSpecForActivity(activitySourceName, activityName, $.$ref(() => spec, ($v) => spec = $v, $.$sdd.System.Diagnostics.DsesFilterAndTransform)) ? spec.SampleFunc.Invoke(hasActivityContext, options) : 0/*ActivitySamplingResult.None*/;
            }
            static $_SpecLookupKey;
            static get SpecLookupKey()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesActivitySourceListener;
                return $cls.$_SpecLookupKey ??= $asm.$nstr("$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey", ($self) => class SpecLookupKey extends $.$spc.System.ValueType
                {
                    $ctor$2(/*string*/ activitySourceName, /*string?*/ activityName)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(activitySourceName, null), "activitySourceName != null");
                            this.activitySourceName = activitySourceName;
                            this.activityName = activityName;
                        }
                        return this;
                    }
                    /*string*/  get activitySourceName() { return this.$getField(0, 4); }
                    /*string*/  set activitySourceName(value) { this.$setField(0, 4, value); }
                    /*string?*/  get activityName() { return this.$getField(4, 4); }
                    /*string?*/  set activityName(value) { this.$setField(4, 4, value); }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.activitySourceName = this.activitySourceName;
                        copy.activityName = this.activityName;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.activitySourceName = null;
                        this.activityName = null;
                    }
                    static $h = 2818092;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":2752556,"h":2818092}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `DsesActivitySourceListener.SpecLookupKey`; }
                }, $cls, ($v) => $cls.$_SpecLookupKey = $v);
            }
            static $_SpecLookupKeyComparer;
            static get SpecLookupKeyComparer()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesActivitySourceListener;
                return $cls.$_SpecLookupKeyComparer ??= $asm.$ncls("$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKeyComparer", ($self) => class SpecLookupKeyComparer extends $.$spc.System.Object
                {
                    /*SpecLookupKeyComparer*/ static Instance = null;
                    /*bool */ Equals$2(/*SpecLookupKey*/ x, /*SpecLookupKey*/ y)
                    {
                        return $.$spc.System.String.Equals$5(x.activitySourceName, y.activitySourceName, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.Equals$5(x.activityName, y.activityName, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                    /*int */ GetHashCode$1(/*SpecLookupKey*/ obj)
                    {
                        /*int*/ let hash = 5381;
                        hash = ((((((hash << 5) + hash) | 0)) + $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(obj.activitySourceName)) | 0);
                        hash = ((((((hash << 5) + hash) | 0)) + ($.$spc.System.String.op_Equality(obj.activityName, null) ? 0 : $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(obj.activityName))) | 0);
                        return hash;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Diagnostics.DsesActivitySourceListener.SpecLookupKey>.Equals(System.Diagnostics.DsesActivitySourceListener.SpecLookupKey, System.Diagnostics.DsesActivitySourceListener.SpecLookupKey)
                    System$Collections$Generic$IEqualityComparer$$$Equals()
                    {
                        return this.Equals$2(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEqualityComparer<System.Diagnostics.DsesActivitySourceListener.SpecLookupKey>.GetHashCode(System.Diagnostics.DsesActivitySourceListener.SpecLookupKey)
                    System$Collections$Generic$IEqualityComparer$$$GetHashCode()
                    {
                        return this.GetHashCode$1(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.Instance = new $.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKeyComparer().$ctor$1();
                        }
                    }
                    static $h = 2883628;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2752556,"h":2883628}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEqualityComparer$$($.$sdd.System.Diagnostics.DsesActivitySourceListener.SpecLookupKey) ]; }
                    static get $fullName() { return `DsesActivitySourceListener.SpecLookupKeyComparer`; }
                }, $cls, ($v) => $cls.$_SpecLookupKeyComparer = $v);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 2752556;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2752556}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `DsesActivitySourceListener`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Meter", ($self) => class Meter extends $.$spc.System.Object
        {
            /*List<Meter>*/ static s_allMeters = null;
            /*List<Instrument>*/ _instruments = null;
            /*Dictionary<string, List<Instrument>>*/ _nonObservableInstrumentsCache = null;
            /*bool*/ Disposed = false;
            /*bool*/ static IsSupported = false;
            static /*bool */ InitializeIsSupported()
            {
                /*bool*/ let isSupported;
                return $.$spc.System.AppContext.TryGetSwitch("System.Diagnostics.Metrics.Meter.IsSupported", $.$ref(() => isSupported, ($v) => isSupported = $v, $.$spc.System.Boolean)) ? isSupported : true;
            }
            $ctor$1(/*MeterOptions*/ options)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(options, "options");
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(options.Name === null), "options.Name is not null");
                    this.Initialize(options.Name, options.Version, options.Tags, options.Scope, options.TelemetrySchemaUrl);
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this.Name === null), "Name is not null");
                }
                return this;
            }
            $ctor$2(/*string*/ name)
            {
                this.$ctor$4(name, null, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*string?*/ version)
            {
                this.$ctor$4(name, version, null, null);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ name, /*string?*/ version, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*object?*/ scope)
            {
                super.$ctor();
                {
                    this.Initialize(name, version, tags, null, null);
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this.Name === null), "Name is not null");
                }
                return this;
            }
            /*void */ Initialize(/*string*/ name, /*string?*/ version, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*object?*/ scope, /*string?*/ telemetrySchemaUrl)
            {
                this.Name = $.$firstOf(name, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("name") });
                this.Version = version;
                if (!(tags === null))
                {
                    /*var*/ let tagList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$3(tags);
                    tagList.Sort$3(new ($.$spc.System.Comparison$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor(this,  (/*left*/ left, /*right*/ right) =>
                    {
                        return $.$spc.System.String.Compare$2(left.Key, right.Key, 4/*StringComparison.Ordinal*/);
                    }, {"r":655361,"p":[{"n":"left","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h},{"n":"right","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h}],"n":"","d":6553644,"h":0,"f":1048578}));
                    this.Tags = tagList.AsReadOnly();
                }
                this.Scope = scope;
                this.TelemetrySchemaUrl = telemetrySchemaUrl;
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        $.$sdd.System.Diagnostics.Metrics.Meter.s_allMeters.Add(this);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                $.$spc.System.GC.KeepAlive($.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log);
            }
            /*string*/ Name = null;
            /*string?*/ Version = null;
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*object?*/ Scope = null;
            /*string?*/ TelemetrySchemaUrl = null;
            /*Counter<T> */ CreateCounter(T, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                return this.CreateCounter$1(T, name, unit, description, null);
            }
            /*Counter<T> */ CreateCounter$1(T, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return $.$cast(this.GetOrCreateInstrument(T, $.$sdd.System.Diagnostics.Metrics.Counter$$(T).$type, name, unit, description, tags, new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  () =>
                {
                    return new ($.$sdd.System.Diagnostics.Metrics.Counter$$(T))().$ctor$9(this, name, unit, description, tags);
                }, {"r":5505068,"n":"","d":6553644,"h":0,"f":1048578})), $.$sdd.System.Diagnostics.Metrics.Counter$$(T));
            }
            /*Gauge<T> */ CreateGauge(T, /*string*/ name)
            {
                return this.CreateGauge$1(T, name, null, null, null);
            }
            /*Gauge<T> */ CreateGauge$1(T, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return $.$cast(this.GetOrCreateInstrument(T, $.$sdd.System.Diagnostics.Metrics.Gauge$$(T).$type, name, unit, description, tags, new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  () =>
                {
                    return new ($.$sdd.System.Diagnostics.Metrics.Gauge$$(T))().$ctor$9(this, name, unit, description, tags);
                }, {"r":5505068,"n":"","d":6553644,"h":0,"f":1048578})), $.$sdd.System.Diagnostics.Metrics.Gauge$$(T));
            }
            /*Histogram<T> */ CreateHistogram(T, /*string*/ name)
            {
                return this.CreateHistogram$3(T, name, null, null, null, null);
            }
            /*Histogram<T> */ CreateHistogram$1(T, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                return this.CreateHistogram$3(T, name, null, null, null, null);
            }
            /*Histogram<T> */ CreateHistogram$2(T, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return this.CreateHistogram$3(T, name, null, null, null, null);
            }
            /*Histogram<T> */ CreateHistogram$3(T, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*InstrumentAdvice<T>?*/ advice)
            {
                return $.$cast(this.GetOrCreateInstrument(T, $.$sdd.System.Diagnostics.Metrics.Histogram$$(T).$type, name, unit, description, tags, new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  () =>
                {
                    return new ($.$sdd.System.Diagnostics.Metrics.Histogram$$(T))().$ctor$9(this, name, unit, description, tags, advice);
                }, {"r":5505068,"n":"","d":6553644,"h":0,"f":1048578})), $.$sdd.System.Diagnostics.Metrics.Histogram$$(T));
            }
            /*UpDownCounter<T> */ CreateUpDownCounter(T, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                return this.CreateUpDownCounter$1(T, name, unit, description, null);
            }
            /*UpDownCounter<T> */ CreateUpDownCounter$1(T, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return $.$cast(this.GetOrCreateInstrument(T, $.$sdd.System.Diagnostics.Metrics.UpDownCounter$$(T).$type, name, unit, description, tags, new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor(this,  () =>
                {
                    return new ($.$sdd.System.Diagnostics.Metrics.UpDownCounter$$(T))().$ctor$9(this, name, unit, description, tags);
                }, {"r":5505068,"n":"","d":6553644,"h":0,"f":1048578})), $.$sdd.System.Diagnostics.Metrics.UpDownCounter$$(T));
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$7(this, name, observeValue, unit, description, null);
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter$1(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$7(this, name, observeValue, unit, description, tags);
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter$2(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$9(this, name, observeValue, unit, description, null);
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter$3(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$9(this, name, observeValue, unit, description, tags);
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter$4(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$11(this, name, observeValues, unit, description, null);
            }
            /*ObservableUpDownCounter<T> */ CreateObservableUpDownCounter$5(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter$$(T))().$ctor$11(this, name, observeValues, unit, description, tags);
            }
            /*ObservableCounter<T> */ CreateObservableCounter(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$7(this, name, observeValue, unit, description, null);
            }
            /*ObservableCounter<T> */ CreateObservableCounter$1(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$7(this, name, observeValue, unit, description, tags);
            }
            /*ObservableCounter<T> */ CreateObservableCounter$2(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$9(this, name, observeValue, unit, description, null);
            }
            /*ObservableCounter<T> */ CreateObservableCounter$3(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$9(this, name, observeValue, unit, description, tags);
            }
            /*ObservableCounter<T> */ CreateObservableCounter$4(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$11(this, name, observeValues, unit, description, null);
            }
            /*ObservableCounter<T> */ CreateObservableCounter$5(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableCounter$$(T))().$ctor$11(this, name, observeValues, unit, description, tags);
            }
            /*ObservableGauge<T> */ CreateObservableGauge(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$7(this, name, observeValue, unit, description, null);
            }
            /*ObservableGauge<T> */ CreateObservableGauge$1(T, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$7(this, name, observeValue, unit, description, tags);
            }
            /*ObservableGauge<T> */ CreateObservableGauge$2(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$9(this, name, observeValue, unit, description, null);
            }
            /*ObservableGauge<T> */ CreateObservableGauge$3(T, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$9(this, name, observeValue, unit, description, tags);
            }
            /*ObservableGauge<T> */ CreateObservableGauge$4(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$11(this, name, observeValues, unit, description, null);
            }
            /*ObservableGauge<T> */ CreateObservableGauge$5(T, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                return new ($.$sdd.System.Diagnostics.Metrics.ObservableGauge$$(T))().$ctor$11(this, name, observeValues, unit, description, tags);
            }
            /*void */ Dispose()
            {
                return this.Dispose$1(true);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                if (!disposing)
                {
                    return;
                }
                /*List<Instrument>?*/ let instruments = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (this.Disposed)
                        {
                            return;
                        }
                        this.Disposed = true;
                        $.$sdd.System.Diagnostics.Metrics.Meter.s_allMeters.Remove(this);
                        instruments = this._instruments;
                        this._instruments = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor$1();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._nonObservableInstrumentsCache)
                    {
                        this._nonObservableInstrumentsCache.Clear();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._nonObservableInstrumentsCache)
                }
                if (!(instruments === null))
                {
                    var $en3 = instruments.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var instrument = $en3.Current;
                        {
                            instrument.NotifyForUnpublishedInstrument();
                        }
                    }
                }
            }
            static /*Instrument? */ GetCachedInstrument(/*List<Instrument>*/ instrumentList, /*Type*/ instrumentType, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(instrumentList === null), "instrumentList is not null");
                var $en2 = instrumentList.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var instrument = $en2.Current;
                    {
                        if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(instrument), instrumentType) && $.$spc.System.String.op_Equality(instrument.Unit, unit) && $.$spc.System.String.op_Equality(instrument.Description, description) && $.$sdd.System.Diagnostics.DiagnosticsHelper.CompareTags($.$as(instrument.Tags, $.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))), tags))
                        {
                            return instrument;
                        }
                    }
                }
                return null;
            }
            /*Instrument */ GetOrCreateInstrument(T, /*Type*/ instrumentType, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*Func<Instrument>*/ instrumentCreator)
            {
                /*List<Instrument>?*/ let instrumentList;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._nonObservableInstrumentsCache)
                    {
                        if (!this._nonObservableInstrumentsCache.TryGetValue(name, $.$ref(() => instrumentList, ($v) => instrumentList = $v, $.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument))))
                        {
                            instrumentList = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor$1();
                            this._nonObservableInstrumentsCache.Add(name, instrumentList);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._nonObservableInstrumentsCache)
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(instrumentList === null), "instrumentList is not null");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(instrumentList)
                    {
                        /*Instrument?*/ let cachedInstrument = $.$sdd.System.Diagnostics.Metrics.Meter.GetCachedInstrument(instrumentList, instrumentType, unit, description, tags);
                        if (!(cachedInstrument === null))
                        {
                            return cachedInstrument;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(instrumentList)
                }
                /*Instrument*/ let newInstrument = instrumentCreator.Invoke();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(instrumentList)
                    {
                        /*Instrument?*/ let cachedInstrument = $.$sdd.System.Diagnostics.Metrics.Meter.GetCachedInstrument(instrumentList, instrumentType, unit, description, tags);
                        if (!(cachedInstrument === null))
                        {
                            return cachedInstrument;
                        }
                        instrumentList.Add(newInstrument);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(instrumentList)
                }
                return newInstrument;
            }
            /*bool */ AddInstrument(/*Instrument*/ instrument)
            {
                if (!this._instruments.Contains(instrument))
                {
                    this._instruments.Add(instrument);
                    return true;
                }
                return false;
            }
            static /*List<Instrument>? */ GetPublishedInstruments()
            {
                /*List<Instrument>?*/ let instruments = null;
                if ($.$sdd.System.Diagnostics.Metrics.Meter.s_allMeters.Count > 0)
                {
                    instruments = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor$1();
                    var $en3 = $.$sdd.System.Diagnostics.Metrics.Meter.s_allMeters.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var meter = $en3.Current;
                        {
                            var $en5 = meter._instruments.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var instrument = $en5.Current;
                                {
                                    instruments.Add(instrument);
                                }
                            }
                        }
                    }
                }
                return instruments;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._instruments = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor$1();
                this._nonObservableInstrumentsCache = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Instrument)))().$ctor$1();
                this.Disposed = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_allMeters = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.Meter))().$ctor$1();
                }
                {
                    this.IsSupported = $.$sdd.System.Diagnostics.Metrics.Meter.InitializeIsSupported();
                }
            }
            static $h = 6553644;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6553644}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.Meter`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.CounterStatistics", ($self) => class CounterStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*double?*/ delta, /*bool*/ isMonotonic, /*double*/ value)
            {
                super.$ctor();
                {
                    this.Delta = delta;
                    this.IsMonotonic = isMonotonic;
                    this.Value = value;
                }
                return this;
            }
            /*double?*/ Delta = null;
            /*bool*/ IsMonotonic = false;
            /*double*/ Value = 0;
            //default member initializer
            constructor()
            {
                super();
                this.Delta = null;
                this.IsMonotonic = false;
            }
            static $h = 4915244;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4915244}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IAggregationStatistics ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.CounterStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Activity", ($self) => class Activity extends $.$spc.System.Object
        {
            /*IEnumerable<KeyValuePair<string, string?>>*/ static s_emptyBaggageTags = null;
            /*IEnumerable<KeyValuePair<string, object?>>*/ static s_emptyTagObjects = null;
            /*IEnumerable<ActivityLink>*/ static s_emptyLinks = null;
            /*IEnumerable<ActivityEvent>*/ static s_emptyEvents = null;
            /*ActivitySource*/ static s_defaultSource = null;
            /*AsyncLocal<Activity?>*/ static s_current = null;
            /*byte*/ static ActivityTraceFlagsIsSet = 128;
            /*int*/ static RequestIdMaxLength = 1024;
            /*string*/ static s_uniqSuffix = null;
            /*long*/ static s_currentRootId = 0n;
            /*ActivityIdFormat*/ static s_defaultIdFormat = 0;
            /*EventHandler<ActivityChangedEventArgs>?*/ static CurrentChanged = null;
            static add_CurrentChanged(/*EventHandler<ActivityChangedEventArgs>?*/ value)
            {
                $.$sdd.System.Diagnostics.Activity.CurrentChanged = $.$spc.System.Delegate.Combine($.$sdd.System.Diagnostics.Activity.CurrentChanged, value);
            }
            static remove_CurrentChanged(/*EventHandler<ActivityChangedEventArgs>?*/ value)
            {
                $.$sdd.System.Diagnostics.Activity.CurrentChanged = $.$spc.System.Delegate.Remove($.$sdd.System.Diagnostics.Activity.CurrentChanged, value);
            }
            /*bool*/ static ForceDefaultIdFormat = false;
            /*string?*/ _traceState = null;
            /*State*/ _state = 0;
            /*int*/ _currentChildId = 0;
            /*string?*/ _id = null;
            /*string?*/ _rootId = null;
            /*string?*/ _parentId = null;
            /*string?*/ _parentSpanId = null;
            /*string?*/ _traceId = null;
            /*string?*/ _spanId = null;
            /*byte*/ _w3CIdFlags = 0;
            /*byte*/ _parentTraceFlags = 0;
            /*TagsLinkedList?*/ _tags = null;
            /*BaggageLinkedList?*/ _baggage = null;
            /*DiagLinkedList<ActivityLink>?*/ _links = null;
            /*DiagLinkedList<ActivityEvent>?*/ _events = null;
            /*Dictionary<string, object>?*/ _customProperties = null;
            /*string?*/ _displayName = null;
            /*ActivityStatusCode*/ _statusCode = 0;
            /*string?*/ _statusDescription = null;
            /*Activity?*/ _previousActiveActivity = null;
            /*ActivityStatusCode */ get Status()
            {
                return this._statusCode;
            }
            /*string? */ get StatusDescription()
            {
                return this._statusDescription;
            }
            /*bool*/ HasRemoteParent = false;
            static /*Activity? */ get Current()
            {
                return $.$sdd.System.Diagnostics.Activity.s_current.Value;
            }
            static /*Activity? */ set Current(value)
            {
                if ($.$sdd.System.Diagnostics.Activity.ValidateSetCurrent(value))
                {
                    $.$sdd.System.Diagnostics.Activity.SetCurrent(value);
                }
            }
            /*Activity */ SetStatus(/*ActivityStatusCode*/ code, /*string?*/ description)
            {
                this._statusCode = code;
                this._statusDescription = code === 2/*ActivityStatusCode.Error*/ ? description : null;
                return this;
            }
            /*ActivityKind*/ Kind = 0;
            /*string*/ OperationName = null;
            /*string */ get DisplayName()
            {
                return this._displayName ?? this.OperationName;
            }
            /*string */ set DisplayName(value)
            {
                this._displayName = $.$firstOf(value, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("value") });
            }
            /*ActivitySource*/ Source = null;
            /*Activity?*/ Parent = null;
            /*TimeSpan*/ Duration;
            /*DateTime*/ StartTimeUtc;
            /*string? */ get Id()
            {
                if ($.$spc.System.String.op_Equality(this._id, null) && $.$spc.System.String.op_Inequality(this._spanId, null))
                {
                    /*Span<char>*/ let flagsChars = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 2, null);
                    $.$sdd.System.HexConverter.ToCharsBuffer($.$cast(((~128/*ActivityTraceFlagsIsSet*/) & this._w3CIdFlags), $.$spc.System.Byte), flagsChars, 0, 8224/*HexConverter.Casing.Lower*/);
                    /*string*/ let id = $.$spc.System.String.Create$10(null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null), `00-${this._traceId}-${this._spanId}-${$.$spc.System.Span$$($.$spc.System.Char).ToString.call($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(flagsChars))}`);
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._id, ($v) => this._id = $v, $.$spc.System.String), id, null);
                }
                return this._id;
            }
            /*string? */ get ParentId()
            {
                if ($.$spc.System.String.op_Equality(this._parentId, null))
                {
                    if ($.$spc.System.String.op_Inequality(this._parentSpanId, null))
                    {
                        /*Span<char>*/ let flagsChars = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 2, null);
                        $.$sdd.System.HexConverter.ToCharsBuffer($.$cast(((~128/*ActivityTraceFlagsIsSet*/) & this._parentTraceFlags), $.$spc.System.Byte), flagsChars, 0, 8224/*HexConverter.Casing.Lower*/);
                        /*string*/ let parentId = $.$spc.System.String.Create$10(null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null), `00-${this._traceId}-${this._parentSpanId}-${$.$spc.System.Span$$($.$spc.System.Char).ToString.call($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(flagsChars))}`);
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._parentId, ($v) => this._parentId = $v, $.$spc.System.String), parentId, null);
                    }
                    else if (this.Parent !== null)
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._parentId, ($v) => this._parentId = $v, $.$spc.System.String), this.Parent.Id, null);
                    }
                }
                return this._parentId;
            }
            /*string? */ get RootId()
            {
                if ($.$spc.System.String.op_Equality(this._rootId, null))
                {
                    /*string?*/ let rootId = null;
                    if ($.$spc.System.String.op_Inequality(this.Id, null))
                    {
                        rootId = this.GetRootId(this.Id);
                    }
                    else if ($.$spc.System.String.op_Inequality(this.ParentId, null))
                    {
                        rootId = this.GetRootId(this.ParentId);
                    }
                    if ($.$spc.System.String.op_Inequality(rootId, null))
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._rootId, ($v) => this._rootId = $v, $.$spc.System.String), rootId, null);
                    }
                }
                return this._rootId;
            }
            /*IEnumerable<KeyValuePair<string, string?>> */ get Tags()
            {
                return (this._tags?.EnumerateStringValues() ?? null) ?? $.$sdd.System.Diagnostics.Activity.s_emptyBaggageTags;
            }
            /*IEnumerable<KeyValuePair<string, object?>> */ get TagObjects()
            {
                return this._tags ?? $.$sdd.System.Diagnostics.Activity.s_emptyTagObjects;
            }
            /*IEnumerable<ActivityEvent> */ get Events()
            {
                return this._events ?? $.$sdd.System.Diagnostics.Activity.s_emptyEvents;
            }
            /*IEnumerable<ActivityLink> */ get Links()
            {
                return this._links ?? $.$sdd.System.Diagnostics.Activity.s_emptyLinks;
            }
            /*IEnumerable<KeyValuePair<string, string?>> */ get Baggage()
            {
                for(/*Activity?*/ let activity = this; activity !== null; activity = activity.Parent)
                {
                    if (activity._baggage !== null)
                    {
                        return Iterate(activity);
                    }
                }
                return $.$sdd.System.Diagnostics.Activity.s_emptyBaggageTags;
                /*static IEnumerable<KeyValuePair<string, string?>>*/  function Iterate(/*Activity?*/ activity)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(activity !== null, "activity != null");
                        do
                        {
                            if (activity._baggage !== null)
                            {
                                for(/*DiagNode<KeyValuePair<string, string?>>?*/ let current = activity._baggage.First; current !== null; current = current.Next)
                                {
                                    yield current.Value;
                                }
                            }
                            activity = activity.Parent;
                        }
                        while(activity !== null);
                    }.bind(this));
                }
            }
            /*Enumerator<KeyValuePair<string, object?>> */ EnumerateTagObjects()
            {
                return new ($.$sdd.System.Diagnostics.Activity.Enumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$2((this._tags?.First ?? null));
            }
            /*Enumerator<ActivityEvent> */ EnumerateEvents()
            {
                return new ($.$sdd.System.Diagnostics.Activity.Enumerator$$($.$sdd.System.Diagnostics.ActivityEvent))().$ctor$2((this._events?.First ?? null));
            }
            /*Enumerator<ActivityLink> */ EnumerateLinks()
            {
                return new ($.$sdd.System.Diagnostics.Activity.Enumerator$$($.$sdd.System.Diagnostics.ActivityLink))().$ctor$2((this._links?.First ?? null));
            }
            /*string? */ GetBaggageItem(/*string*/ key)
            {
                var $en2 = this.Baggage.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var keyValue = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ($.$spc.System.String.op_Equality(key, keyValue.Key))
                        {
                            return keyValue.Value;
                        }
                    }
                }
                return null;
            }
            /*object? */ GetTagItem(/*string*/ key)
            {
                return (this._tags?.Get(key) ?? null) ?? null;
            }
            $ctor$1(/*string*/ operationName)
            {
                super.$ctor();
                {
                    this.Source = $.$sdd.System.Diagnostics.Activity.s_defaultSource;
                    this.IsAllDataRequested = true;
                    if ($.$spc.System.String.IsNullOrEmpty(operationName))
                    {
                        $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.ArgumentException().$ctor$10($.$sdd.System.SR.OperationNameInvalid));
                    }
                    this.OperationName = operationName ?? $.$spc.System.String.Empty;
                }
                return this;
            }
            /*Activity */ AddTag(/*string*/ key, /*string?*/ value)
            {
                return this.AddTag$1(key, value);
            }
            /*Activity */ AddTag$1(/*string*/ key, /*object?*/ value)
            {
                /*KeyValuePair<string, object?>*/ let kvp = new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value);
                if (this._tags !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Activity.TagsLinkedList, $.$ref(() => this._tags, ($v) => this._tags = $v, $.$sdd.System.Diagnostics.Activity.TagsLinkedList), new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$1(kvp, false), null) !== null)
                {
                    this._tags.Add$1(kvp);
                }
                return this;
            }
            /*Activity */ SetTag(/*string*/ key, /*object?*/ value)
            {
                /*KeyValuePair<string, object?>*/ let kvp = new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value);
                if (this._tags !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Activity.TagsLinkedList, $.$ref(() => this._tags, ($v) => this._tags = $v, $.$sdd.System.Diagnostics.Activity.TagsLinkedList), new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$1(kvp, true), null) !== null)
                {
                    this._tags.Set(kvp);
                }
                return this;
            }
            /*Activity */ AddEvent(/*ActivityEvent*/ e)
            {
                if (this._events !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityEvent), $.$ref(() => this._events, ($v) => this._events = $v, $.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityEvent)), new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityEvent))().$ctor$2(e), null) !== null)
                {
                    this._events.Add(e);
                }
                return this;
            }
            /*Activity */ AddException(/*Exception*/ exception, /*in TagList*/ tags, /*DateTimeOffset*/ timestamp)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(exception, "exception");
                /*TagList*/ let exceptionTags = tags.$v;
                this.Source.NotifyActivityAddException(this, exception, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.TagList, () => exceptionTags, ($v) => exceptionTags = $v, null));
                /*string*/ let ExceptionEventName = "exception";
                /*string*/ let ExceptionMessageTag = "exception.message";
                /*string*/ let ExceptionStackTraceTag = "exception.stacktrace";
                /*string*/ let ExceptionTypeTag = "exception.type";
                /*bool*/ let hasMessage = false;
                /*bool*/ let hasStackTrace = false;
                /*bool*/ let hasType = false;
                for(/*int*/ let i = 0; i < exceptionTags.Count; i++)
                {
                    if ($.$spc.System.String.op_Equality(exceptionTags.get_Item(i).Key, ExceptionMessageTag))
                    {
                        hasMessage = true;
                    }
                    else if ($.$spc.System.String.op_Equality(exceptionTags.get_Item(i).Key, ExceptionStackTraceTag))
                    {
                        hasStackTrace = true;
                    }
                    else if ($.$spc.System.String.op_Equality(exceptionTags.get_Item(i).Key, ExceptionTypeTag))
                    {
                        hasType = true;
                    }
                }
                if (!hasMessage)
                {
                    exceptionTags.Add$1(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(ExceptionMessageTag, exception.Message));
                }
                if (!hasStackTrace)
                {
                    exceptionTags.Add$1(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(ExceptionStackTraceTag, $.$spc.System.Exception.ToString.call(exception)));
                }
                if (!hasType)
                {
                    exceptionTags.Add$1(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(ExceptionTypeTag, $.$spc.System.Type.ToString.call(exception.GetType$1())));
                }
                return this.AddEvent(new $.$sdd.System.Diagnostics.ActivityEvent().$ctor$4(ExceptionEventName, timestamp, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.TagList, () => exceptionTags, ($v) => exceptionTags = $v, null)));
            }
            /*Activity */ AddLink(/*ActivityLink*/ link)
            {
                if (this._links !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityLink), $.$ref(() => this._links, ($v) => this._links = $v, $.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityLink)), new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityLink))().$ctor$2(link), null) !== null)
                {
                    this._links.Add(link);
                }
                return this;
            }
            /*Activity */ AddBaggage(/*string*/ key, /*string?*/ value)
            {
                /*KeyValuePair<string, string?>*/ let kvp = new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(key, value);
                if (this._baggage !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Activity.BaggageLinkedList, $.$ref(() => this._baggage, ($v) => this._baggage = $v, $.$sdd.System.Diagnostics.Activity.BaggageLinkedList), new $.$sdd.System.Diagnostics.Activity.BaggageLinkedList().$ctor$1(kvp, false), null) !== null)
                {
                    this._baggage.Add(kvp);
                }
                return this;
            }
            /*Activity */ SetBaggage(/*string*/ key, /*string?*/ value)
            {
                /*KeyValuePair<string, string?>*/ let kvp = new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(key, value);
                if (this._baggage !== null || $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Activity.BaggageLinkedList, $.$ref(() => this._baggage, ($v) => this._baggage = $v, $.$sdd.System.Diagnostics.Activity.BaggageLinkedList), new $.$sdd.System.Diagnostics.Activity.BaggageLinkedList().$ctor$1(kvp, true), null) !== null)
                {
                    this._baggage.Set(kvp);
                }
                return this;
            }
            /*Activity */ SetParentId(/*string*/ parentId)
            {
                if ($.$spc.System.String.op_Inequality(this._id, null) || $.$spc.System.String.op_Inequality(this._spanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ActivitySetParentAlreadyStarted));
                }
                else if (this.Parent !== null)
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.SetParentIdOnActivityWithParent));
                }
                else if ($.$spc.System.String.op_Inequality(this.ParentId, null) || $.$spc.System.String.op_Inequality(this._parentSpanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ParentIdAlreadySet));
                }
                else if ($.$spc.System.String.IsNullOrEmpty(parentId))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.ArgumentException().$ctor$10($.$sdd.System.SR.ParentIdInvalid));
                }
                else 
                {
                    this._parentId = parentId;
                }
                return this;
            }
            /*Activity */ SetParentId$1(/*ActivityTraceId*/ traceId, /*ActivitySpanId*/ spanId, /*ActivityTraceFlags*/ activityTraceFlags)
            {
                if ($.$spc.System.String.op_Inequality(this._id, null) || $.$spc.System.String.op_Inequality(this._spanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ActivitySetParentAlreadyStarted));
                }
                else if (this.Parent !== null)
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.SetParentIdOnActivityWithParent));
                }
                else if ($.$spc.System.String.op_Inequality(this.ParentId, null) || $.$spc.System.String.op_Inequality(this._parentSpanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ParentIdAlreadySet));
                }
                else 
                {
                    this._traceId = traceId.ToHexString();
                    this._parentSpanId = spanId.ToHexString();
                    this.ActivityTraceFlags = activityTraceFlags;
                    this._parentTraceFlags = $.$cast(activityTraceFlags, $.$spc.System.Byte);
                }
                return this;
            }
            /*Activity */ SetStartTime(/*DateTime*/ startTimeUtc)
            {
                if (startTimeUtc.Kind !== 1/*DateTimeKind.Utc*/)
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.StartTimeNotUtc));
                }
                else 
                {
                    this.StartTimeUtc = startTimeUtc;
                }
                return this;
            }
            /*Activity */ SetEndTime(/*DateTime*/ endTimeUtc)
            {
                if (endTimeUtc.Kind !== 1/*DateTimeKind.Utc*/)
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.EndTimeNotUtc));
                }
                else 
                {
                    this.Duration = $.$spc.System.DateTime.op_Subtraction$1(endTimeUtc, this.StartTimeUtc);
                    if (this.Duration.Ticks <= 0n)
                    {
                        this.Duration = new $.$spc.System.TimeSpan().$ctor$2(1n);
                    }
                }
                return this;
            }
            /*ActivityContext */ get Context()
            {
                return new $.$sdd.System.Diagnostics.ActivityContext().$ctor$2(this.TraceId, this.SpanId, this.ActivityTraceFlags, this.TraceStateString, false);
            }
            /*Activity */ Start()
            {
                if ($.$spc.System.String.op_Inequality(this._id, null) || $.$spc.System.String.op_Inequality(this._spanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ActivityStartAlreadyStarted));
                }
                else 
                {
                    this._previousActiveActivity = $.$sdd.System.Diagnostics.Activity.Current;
                    if ($.$spc.System.String.op_Equality(this._parentId, null) && this._parentSpanId === null)
                    {
                        if (this._previousActiveActivity !== null)
                        {
                            this.Parent = this._previousActiveActivity;
                        }
                    }
                    if ($.$spc.System.DateTime.op_Equality(this.StartTimeUtc, new $.$spc.System.DateTime()))
                    {
                        this.StartTimeUtc = $.$sdd.System.Diagnostics.Activity.GetUtcNow();
                    }
                    if (this.IdFormat === 0/*ActivityIdFormat.Unknown*/)
                    {
                        this.IdFormat = $.$sdd.System.Diagnostics.Activity.ForceDefaultIdFormat ? $.$sdd.System.Diagnostics.Activity.DefaultIdFormat : this.Parent !== null ? this.Parent.IdFormat : $.$spc.System.String.op_Inequality(this._parentSpanId, null) ? 2/*ActivityIdFormat.W3C*/ : $.$spc.System.String.op_Equality(this._parentId, null) ? $.$sdd.System.Diagnostics.Activity.DefaultIdFormat : $.$sdd.System.Diagnostics.Activity.IsW3CId(this._parentId) ? 2/*ActivityIdFormat.W3C*/ : 1/*ActivityIdFormat.Hierarchical*/;
                    }
                    if (this.IdFormat === 2/*ActivityIdFormat.W3C*/)
                    {
                        this.GenerateW3CId();
                    }
                    else 
                    {
                        this._id = this.GenerateHierarchicalId();
                    }
                    $.$sdd.System.Diagnostics.Activity.SetCurrent(this);
                    this.Source.NotifyActivityStart(this);
                }
                return this;
            }
            /*void */ Stop()
            {
                if ($.$spc.System.String.op_Equality(this._id, null) && $.$spc.System.String.op_Equality(this._spanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ActivityNotStarted));
                    return;
                }
                if (!this.IsStopped)
                {
                    this.IsStopped = true;
                    if ($.$spc.System.TimeSpan.op_Equality(this.Duration, $.$spc.System.TimeSpan.Zero))
                    {
                        this.SetEndTime($.$sdd.System.Diagnostics.Activity.GetUtcNow());
                    }
                    this.Source.NotifyActivityStop(this);
                    $.$sdd.System.Diagnostics.Activity.SetCurrent(this._previousActiveActivity);
                }
            }
            /*string? */ get TraceStateString()
            {
                for(/*Activity?*/ let activity = this; activity !== null; activity = activity.Parent)
                {
                    /*string?*/ let val = activity._traceState;
                    if ($.$spc.System.String.op_Inequality(val, null))
                    {
                        return val;
                    }
                }
                return null;
            }
            /*string? */ set TraceStateString(value)
            {
                this._traceState = value;
            }
            /*ActivitySpanId */ get SpanId()
            {
                if (this._spanId === null)
                {
                    if ($.$spc.System.String.op_Inequality(this._id, null) && this.IdFormat === 2/*ActivityIdFormat.W3C*/)
                    {
                        /*ActivitySpanId*/ let activitySpanId = $.$sdd.System.Diagnostics.ActivitySpanId.CreateFromString($.$spc.System.MemoryExtensions.AsSpan$7(this._id, 36, 16));
                        /*string*/ let spanId = activitySpanId.ToHexString();
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._spanId, ($v) => this._spanId = $v, $.$spc.System.String), spanId, null);
                    }
                }
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2(this._spanId);
            }
            /*ActivityTraceId */ get TraceId()
            {
                if (this._traceId === null)
                {
                    this.TrySetTraceIdFromParent();
                }
                return new $.$sdd.System.Diagnostics.ActivityTraceId().$ctor$2(this._traceId);
            }
            /*bool */ get Recorded()
            {
                return (this.ActivityTraceFlags & 1/*ActivityTraceFlags.Recorded*/) !== 0;
            }
            /*bool*/ IsAllDataRequested = false;
            /*ActivityTraceFlags */ get ActivityTraceFlags()
            {
                if (!this.W3CIdFlagsSet)
                {
                    this.TrySetTraceFlagsFromParent();
                }
                return $.$cast(((~128/*ActivityTraceFlagsIsSet*/) & this._w3CIdFlags), $.$sdd.System.Diagnostics.ActivityTraceFlags);
            }
            /*ActivityTraceFlags */ set ActivityTraceFlags(value)
            {
                this._w3CIdFlags = $.$cast((128/*ActivityTraceFlagsIsSet*/ | $.$cast(value, $.$spc.System.Byte)), $.$spc.System.Byte);
            }
            /*ActivitySpanId */ get ParentSpanId()
            {
                if (this._parentSpanId === null)
                {
                    /*string?*/ let parentSpanId = null;
                    if ($.$spc.System.String.op_Inequality(this._parentId, null) && $.$sdd.System.Diagnostics.Activity.IsW3CId(this._parentId))
                    {
                        try
                        {
                            parentSpanId = $.$sdd.System.Diagnostics.ActivitySpanId.CreateFromString($.$spc.System.MemoryExtensions.AsSpan$7(this._parentId, 36, 16)).ToHexString();
                        }
                        catch($e)
                        {
                        }
                    }
                    else if (this.Parent !== null && this.Parent.IdFormat === 2/*ActivityIdFormat.W3C*/)
                    {
                        parentSpanId = this.Parent.SpanId.ToHexString();
                    }
                    if ($.$spc.System.String.op_Inequality(parentSpanId, null))
                    {
                        $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.String, $.$ref(() => this._parentSpanId, ($v) => this._parentSpanId = $v, $.$spc.System.String), parentSpanId, null);
                    }
                }
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2(this._parentSpanId);
            }
            /*Func<ActivityTraceId>?*/ static TraceIdGenerator = null;
            static /*ActivityIdFormat */ get DefaultIdFormat()
            {
                if ($.$sdd.System.Diagnostics.Activity.s_defaultIdFormat === 0/*ActivityIdFormat.Unknown*/)
                {
                    $.$sdd.System.Diagnostics.Activity.s_defaultIdFormat = $.$sdd.System.LocalAppContextSwitches.DefaultActivityIdFormatIsHierarchial ? 1/*ActivityIdFormat.Hierarchical*/ : 2/*ActivityIdFormat.W3C*/;
                }
                return $.$sdd.System.Diagnostics.Activity.s_defaultIdFormat;
            }
            static /*ActivityIdFormat */ set DefaultIdFormat(value)
            {
                if (!(1/*ActivityIdFormat.Hierarchical*/ <= value && value <= 2/*ActivityIdFormat.W3C*/))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdd.System.SR.ActivityIdFormatInvalid);
                }
                $.$sdd.System.Diagnostics.Activity.s_defaultIdFormat = value;
            }
            /*Activity */ SetIdFormat(/*ActivityIdFormat*/ format)
            {
                if ($.$spc.System.String.op_Inequality(this._id, null) || $.$spc.System.String.op_Inequality(this._spanId, null))
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.SetFormatOnStartedActivity));
                }
                else 
                {
                    this.IdFormat = format;
                }
                return this;
            }
            static /*bool */ IsW3CId(/*string*/ id)
            {
                return id.length === 55 && (/*0*/ 48 <= $.$spc.System.String.get_Chars.call(id, 0) && $.$spc.System.String.get_Chars.call(id, 0) <= /*9*/ 57 || /*a*/ 97 <= $.$spc.System.String.get_Chars.call(id, 0) && $.$spc.System.String.get_Chars.call(id, 0) <= /*f*/ 102) && (/*0*/ 48 <= $.$spc.System.String.get_Chars.call(id, 1) && $.$spc.System.String.get_Chars.call(id, 1) <= /*9*/ 57 || /*a*/ 97 <= $.$spc.System.String.get_Chars.call(id, 1) && $.$spc.System.String.get_Chars.call(id, 1) <= /*f*/ 102) && ($.$spc.System.String.get_Chars.call(id, 0) !== /*f*/ 102 || $.$spc.System.String.get_Chars.call(id, 1) !== /*f*/ 102);
            }
            static /*bool */ TryConvertIdToContext(/*string*/ traceParent, /*string?*/ traceState, /*bool*/ isRemote, /*out ActivityContext*/ context)
            {
                context.$v = new $.$sdd.System.Diagnostics.ActivityContext();
                if (!$.$sdd.System.Diagnostics.Activity.IsW3CId(traceParent))
                {
                    return false;
                }
                /*ReadOnlySpan<char>*/ let traceIdSpan = $.$spc.System.MemoryExtensions.AsSpan$7(traceParent, 3, 32);
                /*ReadOnlySpan<char>*/ let spanIdSpan = $.$spc.System.MemoryExtensions.AsSpan$7(traceParent, 36, 16);
                if (!$.$sdd.System.Diagnostics.ActivityTraceId.IsLowerCaseHexAndNotAllZeros(traceIdSpan) || !$.$sdd.System.Diagnostics.ActivityTraceId.IsLowerCaseHexAndNotAllZeros(spanIdSpan) || !$.$sdd.System.HexConverter.IsHexLowerChar($.$spc.System.String.get_Chars.call(traceParent, 53)) || !$.$sdd.System.HexConverter.IsHexLowerChar($.$spc.System.String.get_Chars.call(traceParent, 54)))
                {
                    return false;
                }
                context.$v = new $.$sdd.System.Diagnostics.ActivityContext().$ctor$2(new $.$sdd.System.Diagnostics.ActivityTraceId().$ctor$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(traceIdSpan)), new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(spanIdSpan)), $.$cast($.$sdd.System.Diagnostics.ActivityTraceId.HexByteFromChars($.$spc.System.String.get_Chars.call(traceParent, 53), $.$spc.System.String.get_Chars.call(traceParent, 54)), $.$sdd.System.Diagnostics.ActivityTraceFlags), traceState, isRemote);
                return true;
            }
            /*void */ Dispose()
            {
                if (!this.IsStopped)
                {
                    this.Stop();
                }
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ SetCustomProperty(/*string*/ propertyName, /*object?*/ propertyValue)
            {
                if (this._customProperties === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object), $.$ref(() => this._customProperties, ($v) => this._customProperties = $v, $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object)), new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$1(), null);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._customProperties)
                    {
                        if (propertyValue === null)
                        {
                            this._customProperties.Remove(propertyName);
                        }
                        else 
                        {
                            this._customProperties.set_Item(propertyName, propertyValue);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._customProperties)
                }
            }
            /*object? */ GetCustomProperty(/*string*/ propertyName)
            {
                if (this._customProperties === null)
                {
                    return null;
                }
                /*object?*/ let ret;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this._customProperties)
                    {
                        /*object?*/ let o;
                        ret = this._customProperties.TryGetValue(propertyName, $.$ref(() => o, ($v) => o = $v, $.$spc.System.Object)) ? o : null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this._customProperties)
                }
                return ret;
            }
            static /*Activity */ Create(/*ActivitySource*/ source, /*string*/ name, /*ActivityKind*/ kind, /*string?*/ parentId, /*ActivityContext*/ parentContext, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*DateTimeOffset*/ startTime, /*ActivityTagsCollection?*/ samplerTags, /*ActivitySamplingResult*/ request, /*bool*/ startIt, /*ActivityIdFormat*/ idFormat, /*string?*/ traceState)
            {
                /*Activity*/ let activity = new $.$sdd.System.Diagnostics.Activity().$ctor$1(name);
                activity.Source = source;
                activity.Kind = kind;
                activity.IdFormat = idFormat;
                activity._traceState = traceState;
                if (links !== null)
                {
                    let enumerator = null;
                    try
                    {
                        enumerator = links.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$sdd.System.Diagnostics.ActivityLink]);
                        if (enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            activity._links = new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityLink))().$ctor$3(enumerator);
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }
                if (tags !== null)
                {
                    let enumerator = null;
                    try
                    {
                        enumerator = tags.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                        if (enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            activity._tags = new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$2(enumerator);
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }
                if (samplerTags !== null)
                {
                    if (activity._tags === null)
                    {
                        activity._tags = new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$3(samplerTags);
                    }
                    else 
                    {
                        activity._tags.Add(samplerTags);
                    }
                }
                if ($.$spc.System.String.op_Inequality(parentId, null))
                {
                    activity._parentId = parentId;
                }
                else if ($.$sdd.System.Diagnostics.ActivityContext.op_Inequality(parentContext, new $.$sdd.System.Diagnostics.ActivityContext()))
                {
                    activity._traceId = $.$sdd.System.Diagnostics.ActivityTraceId.ToString.call(parentContext.TraceId);
                    if ($.$sdd.System.Diagnostics.ActivitySpanId.op_Inequality(parentContext.SpanId, new $.$sdd.System.Diagnostics.ActivitySpanId()))
                    {
                        activity._parentSpanId = $.$sdd.System.Diagnostics.ActivitySpanId.ToString.call(parentContext.SpanId);
                    }
                    activity.ActivityTraceFlags = parentContext.TraceFlags & ~1/*ActivityTraceFlags.Recorded*/;
                    activity._parentTraceFlags = $.$cast(parentContext.TraceFlags, $.$spc.System.Byte);
                    activity.HasRemoteParent = parentContext.IsRemote;
                }
                activity.IsAllDataRequested = request === 2/*ActivitySamplingResult.AllData*/ || request === 3/*ActivitySamplingResult.AllDataAndRecorded*/;
                if (request === 3/*ActivitySamplingResult.AllDataAndRecorded*/)
                {
                    activity.ActivityTraceFlags |= 1/*ActivityTraceFlags.Recorded*/;
                }
                if ($.$spc.System.DateTimeOffset.op_Inequality(startTime, new $.$spc.System.DateTimeOffset()))
                {
                    activity.StartTimeUtc = startTime.UtcDateTime;
                }
                if (startIt)
                {
                    activity.Start();
                }
                return activity;
            }
            static /*void */ SetCurrent(/*Activity?*/ activity)
            {
                /*EventHandler<ActivityChangedEventArgs>?*/ let handler = $.$sdd.System.Diagnostics.Activity.CurrentChanged;
                if (handler === null)
                {
                    $.$sdd.System.Diagnostics.Activity.s_current.Value = activity;
                }
                else 
                {
                    /*Activity?*/ let previous = $.$sdd.System.Diagnostics.Activity.s_current.Value;
                    $.$sdd.System.Diagnostics.Activity.s_current.Value = activity;
                    handler.Invoke(null, new $.$sdd.System.Diagnostics.ActivityChangedEventArgs().$ctor$2(previous, activity));
                }
            }
            /*void */ GenerateW3CId()
            {
                if (this._traceId === null)
                {
                    if (!this.TrySetTraceIdFromParent())
                    {
                        /*Func<ActivityTraceId>?*/ let traceIdGenerator = $.$sdd.System.Diagnostics.Activity.TraceIdGenerator;
                        /*ActivityTraceId*/ let id = traceIdGenerator === null ? $.$sdd.System.Diagnostics.ActivityTraceId.CreateRandom() : traceIdGenerator.Invoke();
                        this._traceId = id.ToHexString();
                    }
                }
                if (!this.W3CIdFlagsSet)
                {
                    this.TrySetTraceFlagsFromParent();
                }
                this._spanId = $.$sdd.System.Diagnostics.ActivitySpanId.CreateRandom().ToHexString();
            }
            static /*void */ NotifyError(/*Exception*/ exception)
            {
                try
                {
                    throw exception;
                }
                catch($e)
                {
                }
            }
            /*string */ GenerateHierarchicalId()
            {
                /*string*/ let ret;
                if (this.Parent !== null)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.String.IsNullOrEmpty(this.Parent.Id), "!string.IsNullOrEmpty(Parent.Id)");
                    ret = this.AppendSuffix(this.Parent.Id, $.$spc.System.Int32.ToString.call($.$spc.System.Threading.Interlocked.Increment($.$ref(() => this.Parent._currentChildId, ($v) => this.Parent._currentChildId = $v, $.$spc.System.Int32))), /*.*/ 46);
                }
                else if ($.$spc.System.String.op_Inequality(this.ParentId, null))
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this.ParentId.length !== 0, "ParentId.Length != 0");
                    /*string*/ let parentId = $.$spc.System.String.get_Chars.call(this.ParentId, 0) === /*|*/ 124 ? this.ParentId : /*|*/ 124 + this.ParentId;
                    /*char*/ let lastChar = $.$spc.System.String.get_Chars.call(parentId, ((parentId.length - 1) | 0));
                    if (lastChar !== /*.*/ 46 && lastChar !== /*_*/ 95)
                    {
                        parentId = $.$spc.System.String.op_Addition(parentId, $.$box(/*.*/ 46, $.$spc.System.Char));
                    }
                    ret = this.AppendSuffix(parentId, $.$spc.System.Int64.ToString$2.call($.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => $.$sdd.System.Diagnostics.Activity.s_currentRootId, ($v) => $.$sdd.System.Diagnostics.Activity.s_currentRootId = $v, $.$spc.System.Int64)), "x"), /*_*/ 95);
                }
                else 
                {
                    ret = $.$sdd.System.Diagnostics.Activity.GenerateRootId();
                }
                return ret;
            }
            /*string */ GetRootId(/*string*/ id)
            {
                if (this.IdFormat === 2/*ActivityIdFormat.W3C*/)
                {
                    return $.$spc.System.String.Substring$1.call(id, 3, 32);
                }
                /*int*/ let rootEnd = $.$spc.System.String.IndexOf.call(id, /*.*/ 46);
                if (rootEnd < 0)
                {
                    rootEnd = id.length;
                }
                /*int*/ let rootStart = $.$spc.System.String.get_Chars.call(id, 0) === /*|*/ 124 ? 1 : 0;
                return $.$spc.System.String.Substring$1.call(id, rootStart, ((rootEnd - rootStart) | 0));
            }
            /*string */ AppendSuffix(/*string*/ parentId, /*string*/ suffix, /*char*/ delimiter)
            {
                suffix = $.$spc.System.String.Replace$2.call(this.OperationName, /*.*/ 46, /*-*/ 45) + "-" + suffix;
                if (((parentId.length + suffix.length) | 0) < 1024/*RequestIdMaxLength*/)
                {
                    return parentId + suffix + delimiter;
                }
                /*int*/ let trimPosition = ((1024/*RequestIdMaxLength*/ - 9) | 0);
                while(trimPosition > 1)
                {
                    if ($.$spc.System.String.get_Chars.call(parentId, ((trimPosition - 1) | 0)) === /*.*/ 46 || $.$spc.System.String.get_Chars.call(parentId, ((trimPosition - 1) | 0)) === /*_*/ 95)
                    {
                        break;
                    }
                    trimPosition--;
                }
                if (trimPosition === 1)
                {
                    return $.$sdd.System.Diagnostics.Activity.GenerateRootId();
                }
                /*string*/ let overflowSuffix = $.$spc.System.Int32.ToString$1.call(($.$cast($.$sdd.System.Diagnostics.Activity.GetRandomNumber(), $.$spc.System.Int32)), "x8");
                return $.$spc.System.String.Substring$1.call(parentId, 0, trimPosition) + overflowSuffix + /*#*/ 35;
            }
            static /*long */ GetRandomNumber()
            {
                /*Guid*/ let g = $.$spc.System.Guid.NewGuid();
                $.$spc.System.Runtime.CompilerServices.Unsafe.SkipInit($.$spc.System.Guid, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Guid, () => g, ($v) => g = $v, null));
                return (g.$getFieldRefOrP($.$spc.System.Int64, 0, true)).$v;
            }
            static /*bool */ ValidateSetCurrent(/*Activity?*/ activity)
            {
                /*bool*/ let canSet = activity === null || ($.$spc.System.String.op_Inequality(activity.Id, null) && !activity.IsStopped);
                if (!canSet)
                {
                    $.$sdd.System.Diagnostics.Activity.NotifyError(new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.ActivityNotRunning));
                }
                return canSet;
            }
            /*bool */ TrySetTraceIdFromParent()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._traceId === null, "_traceId is null");
                if (this.Parent !== null && this.Parent.IdFormat === 2/*ActivityIdFormat.W3C*/)
                {
                    this._traceId = this.Parent.TraceId.ToHexString();
                }
                else if ($.$spc.System.String.op_Inequality(this._parentId, null) && $.$sdd.System.Diagnostics.Activity.IsW3CId(this._parentId))
                {
                    try
                    {
                        this._traceId = $.$sdd.System.Diagnostics.ActivityTraceId.CreateFromString($.$spc.System.MemoryExtensions.AsSpan$7(this._parentId, 3, 32)).ToHexString();
                    }
                    catch($e)
                    {
                    }
                }
                return $.$spc.System.String.op_Inequality(this._traceId, null);
            }
            /*void */ TrySetTraceFlagsFromParent()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!this.W3CIdFlagsSet, "!W3CIdFlagsSet");
                if (!this.W3CIdFlagsSet)
                {
                    if (this.Parent !== null)
                    {
                        this.ActivityTraceFlags = this.Parent.ActivityTraceFlags;
                    }
                    else if ($.$spc.System.String.op_Inequality(this._parentId, null) && $.$sdd.System.Diagnostics.Activity.IsW3CId(this._parentId))
                    {
                        if ($.$sdd.System.HexConverter.IsHexLowerChar($.$spc.System.String.get_Chars.call(this._parentId, 53)) && $.$sdd.System.HexConverter.IsHexLowerChar($.$spc.System.String.get_Chars.call(this._parentId, 54)))
                        {
                            this._w3CIdFlags = $.$cast(($.$sdd.System.Diagnostics.ActivityTraceId.HexByteFromChars($.$spc.System.String.get_Chars.call(this._parentId, 53), $.$spc.System.String.get_Chars.call(this._parentId, 54)) | 128/*ActivityTraceFlagsIsSet*/), $.$spc.System.Byte);
                        }
                        else 
                        {
                            this._w3CIdFlags = 128/*ActivityTraceFlagsIsSet*/;
                        }
                    }
                }
            }
            /*bool */ get W3CIdFlagsSet()
            {
                return (this._w3CIdFlags & 128/*ActivityTraceFlagsIsSet*/) !== 0;
            }
            /*bool */ get IsStopped()
            {
                return (this._state & 128/*State.IsStopped*/) !== 0;
            }
            /*bool */ set IsStopped(value)
            {
                if (value)
                {
                    this._state |= 128/*State.IsStopped*/;
                }
                else 
                {
                    this._state &= ~128/*State.IsStopped*/;
                }
            }
            /*ActivityIdFormat */ get IdFormat()
            {
                return $.$cast((this._state & 3/*State.FormatFlags*/), $.$sdd.System.Diagnostics.ActivityIdFormat);
            }
            /*ActivityIdFormat */ set IdFormat(value)
            {
                this._state = (this._state & ~3/*State.FormatFlags*/) | $.$cast(($.$cast(value, $.$spc.System.Byte) & 3/*State.FormatFlags*/), $.$sdd.System.Diagnostics.Activity.State);
            }
            static $_Enumerator$$;
            static Enumerator$$(T)
            {
                let $cls = $.$sdd.System.Diagnostics.Activity;
                return ($cls.$_Enumerator$$ ??= $asm.$nstr("$sdd.System.Diagnostics.Activity.Enumerator<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Activity.Enumerator<>", [T], ($self) => class Enumerator$$ extends $.$spc.System.ValueType
                {
                    /*DiagNode<T>*/ static s_Empty = null;
                    /*DiagNode<T>?*/  get _nextNode() { return this.$getField(0, 4); }
                    /*DiagNode<T>?*/  set _nextNode(value) { this.$setField(0, 4, value); }
                    /*DiagNode<T>*/  get _currentNode() { return this.$getField(4, 4); }
                    /*DiagNode<T>*/  set _currentNode(value) { this.$setField(4, 4, value); }
                    $ctor$2(/*DiagNode<T>?*/ head)
                    {
                        super.$ctor$1();
                        {
                            this._nextNode = head;
                            this._currentNode = $.$sdd.System.Diagnostics.Activity.Enumerator$$(T).s_Empty;
                        }
                        return this;
                    }
                    /*Enumerator<T> */ GetEnumerator()
                    {
                        return this;
                    }
                    /*ref T */ get Current()
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT(T, () => this._currentNode.Value, ($v) => this._currentNode.Value = $v, null);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._nextNode === null)
                        {
                            this._currentNode = $.$sdd.System.Diagnostics.Activity.Enumerator$$(T).s_Empty;
                            return false;
                        }
                        this._currentNode = this._nextNode;
                        this._nextNode = this._nextNode.Next;
                        return true;
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._nextNode = this._nextNode;
                        copy._currentNode = this._currentNode;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._nextNode = null;
                        this._currentNode = null;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_Empty = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1($.$default(T));
                        }
                    }
                    static $h = 327724;
                    static $g = 1;
                    static $z = 8;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"r":1,"d":196652,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Diagnostics.Activity.Enumerator<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Enumerator$$ = $v))(T);
            }
            static $_BaggageLinkedList;
            static get BaggageLinkedList()
            {
                let $cls = $.$sdd.System.Diagnostics.Activity;
                return $cls.$_BaggageLinkedList ??= $asm.$ncls("$sdd.System.Diagnostics.Activity.BaggageLinkedList", ($self) => class BaggageLinkedList extends $.$spc.System.Object
                {
                    /*DiagNode<KeyValuePair<string, string?>>?*/ _first = null;
                    $ctor$1(/*KeyValuePair<string, string?>*/ firstValue, /*bool*/ set)
                    {
                        super.$ctor();
                        this._first = ((set && $.$spc.System.String.op_Equality(firstValue.Value, null)) ? null : new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1(firstValue));
                        return this;
                    }
                    /*DiagNode<KeyValuePair<string, string?>>? */ get First()
                    {
                        return this._first;
                    }
                    /*void */ Add(/*KeyValuePair<string, string?>*/ value)
                    {
                        /*DiagNode<KeyValuePair<string, string?>>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1(value);
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                newNode.Next = this._first;
                                this._first = newNode;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*void */ Set(/*KeyValuePair<string, string?>*/ value)
                    {
                        if ($.$spc.System.String.op_Equality(value.Value, null))
                        {
                            this.Remove(value.Key);
                            return;
                        }
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                /*DiagNode<KeyValuePair<string, string?>>?*/ let current = this._first;
                                while(current !== null)
                                {
                                    if ($.$spc.System.String.op_Equality(current.Value.Key, value.Key))
                                    {
                                        current.Value = value;
                                        return;
                                    }
                                    current = current.Next;
                                }
                                /*DiagNode<KeyValuePair<string, string?>>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1(value);
                                newNode.Next = this._first;
                                this._first = newNode;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*void */ Remove(/*string*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                if (this._first === null)
                                {
                                    return;
                                }
                                if ($.$spc.System.String.op_Equality(this._first.Value.Key, key))
                                {
                                    this._first = this._first.Next;
                                    return;
                                }
                                /*DiagNode<KeyValuePair<string, string?>>*/ let previous = this._first;
                                while(previous.Next !== null)
                                {
                                    if ($.$spc.System.String.op_Equality(previous.Next.Value.Key, key))
                                    {
                                        previous.Next = previous.Next.Next;
                                        return;
                                    }
                                    previous = previous.Next;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*DiagEnumerator<KeyValuePair<string, string?>> */ GetEnumerator()
                    {
                        return new ($.$sdd.System.Diagnostics.DiagEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$2(this._first);
                    }
                    /*IEnumerator<KeyValuePair<string, string?>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    static $h = 262188;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":196652,"h":262188}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Diagnostics.Activity.BaggageLinkedList`; }
                }, $cls, ($v) => $cls.$_BaggageLinkedList = $v);
            }
            static $_TagsLinkedList;
            static get TagsLinkedList()
            {
                let $cls = $.$sdd.System.Diagnostics.Activity;
                return $cls.$_TagsLinkedList ??= $asm.$ncls("$sdd.System.Diagnostics.Activity.TagsLinkedList", ($self) => class TagsLinkedList extends $.$spc.System.Object
                {
                    /*DiagNode<KeyValuePair<string, object?>>?*/ _first = null;
                    /*DiagNode<KeyValuePair<string, object?>>?*/ _last = null;
                    /*StringBuilder?*/ _stringBuilder = null;
                    $ctor$1(/*KeyValuePair<string, object?>*/ firstValue, /*bool*/ set)
                    {
                        super.$ctor();
                        this._last = this._first = ((set && firstValue.Value === null) ? null : new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(firstValue));
                        return this;
                    }
                    $ctor$2(/*IEnumerator<KeyValuePair<string, object?>>*/ e)
                    {
                        super.$ctor();
                        {
                            this._last = this._first = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                this._last.Next = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                                this._last = this._last.Next;
                            }
                        }
                        return this;
                    }
                    /*DiagNode<KeyValuePair<string, object?>>? */ get First()
                    {
                        return this._first;
                    }
                    $ctor$3(/*IEnumerable<KeyValuePair<string, object?>>*/ list)
                    {
                        super.$ctor();
                        this.Add(list);
                        return this;
                    }
                    /*void */ Add(/*IEnumerable<KeyValuePair<string, object?>>*/ list)
                    {
                        /*IEnumerator<KeyValuePair<string, object?>>*/ let e = list.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return;
                        }
                        if (this._first === null)
                        {
                            this._last = this._first = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                        }
                        else 
                        {
                            this._last.Next = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                            this._last = this._last.Next;
                        }
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            this._last.Next = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                            this._last = this._last.Next;
                        }
                    }
                    /*void */ Add$1(/*KeyValuePair<string, object?>*/ value)
                    {
                        /*DiagNode<KeyValuePair<string, object?>>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(value);
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                if (this._first === null)
                                {
                                    this._first = this._last = newNode;
                                    return;
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._last !== null, "_last != null");
                                this._last.Next = newNode;
                                this._last = newNode;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*object? */ Get(/*string*/ key)
                    {
                        /*DiagNode<KeyValuePair<string, object?>>?*/ let current = this._first;
                        while(current !== null)
                        {
                            if ($.$spc.System.String.op_Equality(current.Value.Key, key))
                            {
                                return current.Value.Value;
                            }
                            current = current.Next;
                        }
                        return null;
                    }
                    /*void */ Remove(/*string*/ key)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                if (this._first === null)
                                {
                                    return;
                                }
                                if ($.$spc.System.String.op_Equality(this._first.Value.Key, key))
                                {
                                    this._first = this._first.Next;
                                    if (this._first === null)
                                    {
                                        this._last = null;
                                    }
                                    return;
                                }
                                /*DiagNode<KeyValuePair<string, object?>>*/ let previous = this._first;
                                while(previous.Next !== null)
                                {
                                    if ($.$spc.System.String.op_Equality(previous.Next.Value.Key, key))
                                    {
                                        if ($.$spc.System.Object.ReferenceEquals(this._last, previous.Next))
                                        {
                                            this._last = previous;
                                        }
                                        previous.Next = previous.Next.Next;
                                        return;
                                    }
                                    previous = previous.Next;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*void */ Set(/*KeyValuePair<string, object?>*/ value)
                    {
                        if (value.Value === null)
                        {
                            this.Remove(value.Key);
                            return;
                        }
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                /*DiagNode<KeyValuePair<string, object?>>?*/ let current = this._first;
                                while(current !== null)
                                {
                                    if ($.$spc.System.String.op_Equality(current.Value.Key, value.Key))
                                    {
                                        current.Value = value;
                                        return;
                                    }
                                    current = current.Next;
                                }
                                /*DiagNode<KeyValuePair<string, object?>>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(value);
                                if (this._first === null)
                                {
                                    this._first = this._last = newNode;
                                    return;
                                }
                                $.$spc.System.Diagnostics.Debug.Assert$1(this._last !== null, "_last != null");
                                this._last.Next = newNode;
                                this._last = newNode;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    /*DiagEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
                    {
                        return new ($.$sdd.System.Diagnostics.DiagEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$2(this._first);
                    }
                    /*IEnumerator<KeyValuePair<string, object?>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*IEnumerable<KeyValuePair<string, string?>> */ EnumerateStringValues()
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                        {
                            /*DiagNode<KeyValuePair<string, object?>>?*/ let current = this._first;
                            while(current !== null)
                            {
                                if ($.$is(current.Value.Value, $.$spc.System.String) || current.Value.Value === null)
                                {
                                    yield new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(current.Value.Key, $.$cast(current.Value.Value, $.$spc.System.String));
                                }
                                current = current.Next;
                            }
                        }.bind(this));
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this)
                            {
                                if (this._first === null)
                                {
                                    return $.$spc.System.String.Empty;
                                }
                                this._stringBuilder ??= new $.$spc.System.Text.StringBuilder().$ctor$1();
                                this._stringBuilder.Append$2(this._first.Value.Key);
                                this._stringBuilder.Append$7(/*:*/ 58);
                                this._stringBuilder.Append$19(this._first.Value.Value);
                                /*DiagNode<KeyValuePair<string, object?>>?*/ let current = this._first.Next;
                                while(current !== null)
                                {
                                    this._stringBuilder.Append$2(", ");
                                    this._stringBuilder.Append$2(current.Value.Key);
                                    this._stringBuilder.Append$7(/*:*/ 58);
                                    this._stringBuilder.Append$19(current.Value.Value);
                                    current = current.Next;
                                }
                                /*string*/ let result = $.$spc.System.Text.StringBuilder.ToString.call(this._stringBuilder);
                                this._stringBuilder.Clear();
                                return result;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this)
                        }
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sdd.System.Diagnostics.Activity.TagsLinkedList.ToString.apply(this, arguments); }
                    static $h = 458796;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":196652,"h":458796}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Diagnostics.Activity.TagsLinkedList`; }
                }, $cls, ($v) => $cls.$_TagsLinkedList = $v);
            }
            static $_State;
            static get State()
            {
                let $cls = $.$sdd.System.Diagnostics.Activity;
                return $cls.$_State ??= $asm.$nstr("$sdd.System.Diagnostics.Activity.State", ($self) => class State extends $.$spc.System.Enum
                {
                    static None = 0;
                    static FormatUnknown = 0;
                    static FormatHierarchical = 1;
                    static FormatW3C = 2;
                    static FormatFlags = 3;
                    static IsStopped = 128;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "None": 0n,
                            "FormatUnknown": 0n,
                            "FormatHierarchical": 1n,
                            "FormatW3C": 2n,
                            "FormatFlags": 3n,
                            "IsStopped": 128n
                        };
                    }
                    static $h = 393260;
                    static $z = 1;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Byte; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":393217,"d":196652,"h":393260}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Diagnostics.Activity.State`; }
                }, $cls, ($v) => $cls.$_State = $v);
            }
            static /*DateTime */ GetUtcNow()
            {
                return $.$spc.System.DateTime.UtcNow;
            }
            static /*string */ GenerateRootId()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdd.System.Diagnostics.Activity.s_uniqSuffix.length < 50, "s_uniqSuffix.Length < 50");
                /*Span<char>*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, ((((1 + 16) | 0) + $.$sdd.System.Diagnostics.Activity.s_uniqSuffix.length) | 0), null);
                result.get_Item(0).$v = /*|*/ 124;
                /*int*/ let charsWritten;
                /*bool*/ let formatted = $.$spc.System.Int64.TryFormat.call($.$spc.System.Threading.Interlocked.Increment$1($.$ref(() => $.$sdd.System.Diagnostics.Activity.s_currentRootId, ($v) => $.$sdd.System.Diagnostics.Activity.s_currentRootId = $v, $.$spc.System.Int64)), result.Slice(1), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), $.$spc.System.String.op_Implicit("x"), null);
                $.$spc.System.Diagnostics.Debug.Assert$1(formatted, "formatted");
                $.$spc.System.MemoryExtensions.AsSpan$3($.$sdd.System.Diagnostics.Activity.s_uniqSuffix).CopyTo(result.Slice(((1 + charsWritten) | 0)));
                return $.$spc.System.String.Create($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(result.Slice$1(0, ((((1 + charsWritten) | 0) + $.$sdd.System.Diagnostics.Activity.s_uniqSuffix.length) | 0))));
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.HasRemoteParent = false;
                this.Kind = 0;
                this.Duration = $.$default($.$spc.System.TimeSpan);
                this.StartTimeUtc = $.$default($.$spc.System.DateTime);
                this.IsAllDataRequested = false;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_emptyBaggageTags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)), null, [0], null);
                }
                {
                    this.s_emptyTagObjects = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [0], null);
                }
                {
                    this.s_emptyLinks = new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityLink))().$ctor$1();
                }
                {
                    this.s_emptyEvents = new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.ActivityEvent))().$ctor$1();
                }
                {
                    this.s_defaultSource = new $.$sdd.System.Diagnostics.ActivitySource().$ctor$1($.$spc.System.String.Empty);
                }
                {
                    this.s_current = new ($.$spc.System.Threading.AsyncLocal$$($.$sdd.System.Diagnostics.Activity))().$ctor$1();
                }
                {
                    this.s_uniqSuffix = (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(2, 1);
                        $handler.AppendLiteral("-");
                        $handler.AppendFormatted$8($.$box($.$sdd.System.Diagnostics.Activity.GetRandomNumber(), $.$spc.System.Int64), null, "x");
                        $handler.AppendLiteral(".");
                        return $handler.ToStringAndClear();
                    })();
                }
                {
                    this.s_currentRootId = BigInt($.$cast($.$sdd.System.Diagnostics.Activity.GetRandomNumber(), $.$spc.System.UInt32));
                }
                {
                    this.ForceDefaultIdFormat = false;
                }
            }
            static $h = 196652;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":196652}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Activity`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MeterListener", ($self) => class MeterListener extends $.$spc.System.Object
        {
            /*List<MeterListener>*/ static s_allStartedListeners = null;
            /*DiagLinkedList<Instrument>*/ _enabledMeasurementInstruments = null;
            /*bool*/ _disposed = false;
            /*MeasurementCallback<byte>*/ _byteMeasurementCallback = null;
            /*MeasurementCallback<short>*/ _shortMeasurementCallback = null;
            /*MeasurementCallback<int>*/ _intMeasurementCallback = null;
            /*MeasurementCallback<long>*/ _longMeasurementCallback = null;
            /*MeasurementCallback<float>*/ _floatMeasurementCallback = null;
            /*MeasurementCallback<double>*/ _doubleMeasurementCallback = null;
            /*MeasurementCallback<decimal>*/ _decimalMeasurementCallback = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    $.$sdd.System.Diagnostics.Metrics.RuntimeMetrics.EnsureInitialized();
                }
                return this;
            }
            /*Action<Instrument, MeterListener>?*/ InstrumentPublished = null;
            /*Action<Instrument, object?>?*/ MeasurementsCompleted = null;
            /*void */ EnableMeasurementEvents(/*Instrument*/ instrument, /*object?*/ state)
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                /*bool*/ let oldStateStored = false;
                /*bool*/ let enabled = false;
                /*object?*/ let oldState = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (!(instrument === null) && !this._disposed && !instrument.Meter.Disposed)
                        {
                            this._enabledMeasurementInstruments.AddIfNotExist(instrument, new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Boolean))().$ctor($.$spc.System.Object, $.$spc.System.Object.ReferenceEquals));
                            oldState = instrument.EnableMeasurement(new $.$sdd.System.Diagnostics.Metrics.ListenerSubscription().$ctor$2(this, state), $.$ref(() => oldStateStored, ($v) => oldStateStored = $v, $.$spc.System.Boolean));
                            enabled = true;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                if (enabled)
                {
                    if (oldStateStored && !(this.MeasurementsCompleted === null))
                    {
                        this.MeasurementsCompleted?.Invoke(instrument, oldState);
                    }
                }
                else 
                {
                    this.MeasurementsCompleted?.Invoke(instrument, state);
                }
            }
            /*object? */ DisableMeasurementEvents(/*Instrument*/ instrument)
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return null;
                }
                /*object?*/ let state = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (instrument === null || this._enabledMeasurementInstruments.Remove(instrument, new ($.$spc.System.Func$$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Boolean))().$ctor($.$spc.System.Object, $.$spc.System.Object.ReferenceEquals)) === null)
                        {
                            return null;
                        }
                        state = instrument.DisableMeasurements(this);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                this.MeasurementsCompleted?.Invoke(instrument, state);
                return state;
            }
            /*void */ SetMeasurementEventCallback(T, /*MeasurementCallback<T>?*/ measurementCallback)
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                measurementCallback ??= new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$(T))().$ctor(this,  (/**/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":(T) => T.$h},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Byte.$type))
                {
                    this._byteMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Byte));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int32.$type))
                {
                    this._intMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int32));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Single.$type))
                {
                    this._floatMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Single));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Double.$type))
                {
                    this._doubleMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Double));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Decimal.$type))
                {
                    this._decimalMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Decimal));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int16.$type))
                {
                    this._shortMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int16));
                }
                else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int64.$type))
                {
                    this._longMeasurementCallback = $.$cast($.$cast(measurementCallback, $.$spc.System.Object), $.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int64));
                }
                else 
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.Format($.$sdd.System.SR.UnsupportedType, T.$type));
                }
            }
            /*void */ Start()
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                /*List<Instrument>?*/ let publishedInstruments = null;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        if (!$.$sdd.System.Diagnostics.Metrics.MeterListener.s_allStartedListeners.Contains(this))
                        {
                            $.$sdd.System.Diagnostics.Metrics.MeterListener.s_allStartedListeners.Add(this);
                            publishedInstruments = $.$sdd.System.Diagnostics.Metrics.Meter.GetPublishedInstruments();
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                if (!(publishedInstruments === null))
                {
                    var $en3 = publishedInstruments.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var instrument = $en3.Current;
                        {
                            this.InstrumentPublished?.Invoke(instrument, this);
                        }
                    }
                }
            }
            /*void */ RecordObservableInstruments()
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                /*List<Exception>?*/ let exceptionsList = null;
                /*DiagNode<Instrument>?*/ let current = this._enabledMeasurementInstruments.First;
                while(!(current === null))
                {
                    if (current.Value.IsObservable)
                    {
                        try
                        {
                            current.Value.Observe(this);
                        }
                        catch(e)
                        {
                            exceptionsList ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Exception))().$ctor$1();
                            exceptionsList.Add(e);
                        }
                    }
                    current = current.Next;
                }
                if (!(exceptionsList === null))
                {
                    throw new $.$spc.System.AggregateException().$ctor$8(exceptionsList);
                }
            }
            /*void */ Dispose()
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Meter.IsSupported)
                {
                    return;
                }
                /*Dictionary<Instrument, object?>?*/ let callbacksArguments = null;
                /*Action<Instrument, object?>?*/ let measurementsCompleted = this.MeasurementsCompleted;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        $.$sdd.System.Diagnostics.Metrics.MeterListener.s_allStartedListeners.Remove(this);
                        /*DiagNode<Instrument>?*/ let current = this._enabledMeasurementInstruments.First;
                        if (!(current === null))
                        {
                            if (!(measurementsCompleted === null))
                            {
                                callbacksArguments = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$spc.System.Object))().$ctor$1();
                            }
                            do
                            {
                                /*object?*/ let state = current.Value.DisableMeasurements(this);
                                callbacksArguments?.Add(current.Value, state);
                                current = current.Next;
                            }
                            while(!(current === null));
                            this._enabledMeasurementInstruments.Clear();
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.Metrics.Instrument.SyncObject)
                }
                if (!(callbacksArguments === null))
                {
                    var $en3 = callbacksArguments.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current;
                        {
                            measurementsCompleted?.Invoke(kvp.Key, kvp.Value);
                        }
                    }
                }
            }
            static /*List<MeterListener>? */ GetAllListeners()
            {
                return $.$sdd.System.Diagnostics.Metrics.MeterListener.s_allStartedListeners.Count === 0 ? null : new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor$3($.$sdd.System.Diagnostics.Metrics.MeterListener.s_allStartedListeners);
            }
            /*void */ NotifyMeasurement(T, /*Instrument*/ instrument, /*T*/ measurement, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ tags, /*object?*/ state)
            {
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Byte.$type))
                {
                    this._byteMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Byte), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int16.$type))
                {
                    this._shortMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Int16), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int32.$type))
                {
                    this._intMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Int32), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int64.$type))
                {
                    this._longMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Int64), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Single.$type))
                {
                    this._floatMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Single), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Double.$type))
                {
                    this._doubleMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Double), tags, state);
                }
                if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Decimal.$type))
                {
                    this._decimalMeasurementCallback.Invoke(instrument, $.$cast($.$box(measurement, T), $.$spc.System.Decimal), tags, state);
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._enabledMeasurementInstruments = new ($.$sdd.System.Diagnostics.DiagLinkedList$$($.$sdd.System.Diagnostics.Metrics.Instrument))().$ctor$1();
                this._byteMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Byte))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":393217},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._shortMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int16))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":524289},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._intMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int32))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":655361},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._longMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Int64))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":917505},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._floatMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Single))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":1114113},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._doubleMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Double))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":1179649},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
                this._decimalMeasurementCallback = new ($.$sdd.System.Diagnostics.Metrics.MeasurementCallback$$($.$spc.System.Decimal))().$ctor(this,  (/*instrument*/ instrument, /*measurement*/ measurement, /*tags*/ tags, /*state*/ state) =>
                {
                }, {"r":65537,"p":[{"n":"instrument","p":5505068},{"n":"measurement","p":35061761},{"n":"tags","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).$h},{"n":"state","p":131073}],"n":"","d":6684716,"h":0,"f":1048578});
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_allStartedListeners = new ($.$spc.System.Collections.Generic.List$$($.$sdd.System.Diagnostics.Metrics.MeterListener))().$ctor$1();
                }
            }
            static $h = 6684716;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6684716}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.MeterListener`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.LastValueStatistics", ($self) => class LastValueStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*double?*/ lastValue)
            {
                super.$ctor();
                {
                    this.LastValue = lastValue;
                }
                return this;
            }
            /*double?*/ LastValue = null;
            //default member initializer
            constructor()
            {
                super();
                this.LastValue = null;
            }
            static $h = 6291500;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":6291500}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IAggregationStatistics ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.LastValueStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.SynchronousLastValueStatistics", ($self) => class SynchronousLastValueStatistics extends $.$spc.System.Object
        {
            $ctor$1(/*double*/ lastValue)
            {
                super.$ctor();
                {
                    this.LastValue = lastValue;
                }
                return this;
            }
            /*double*/ LastValue = 0;
            static $h = 8257580;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":8257580}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sdd.System.Diagnostics.Metrics.IAggregationStatistics ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.SynchronousLastValueStatistics`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DsesFilterAndTransform", ($self) => class DsesFilterAndTransform extends $.$spc.System.Object
        {
            /*string*/ static c_ActivitySourcePrefix = null;
            /*string*/ static c_ParentRatioSamplerPrefix = null;
            /*string*/ static c_ParentRateLimitingSamplerPrefix = null;
            static /*IDisposable */ ParseFilterAndPayloadSpecs(/*DiagnosticSourceEventSource*/ eventSource, /*string?*/ filterAndPayloadSpecs)
            {
                filterAndPayloadSpecs ??= "";
                /*DsesFilterAndTransform?*/ let specList = null;
                /*DsesFilterAndTransform?*/ let activitySourceSpecList = null;
                /*int*/ let endIdx = filterAndPayloadSpecs.length;
                while(true)
                {
                    while(0 < endIdx && $.$spc.System.Char.IsWhiteSpace($.$spc.System.String.get_Chars.call(filterAndPayloadSpecs, ((endIdx - 1) | 0))))
                    {
                        --endIdx;
                    }
                    /*int*/ let newlineIdx = $.$spc.System.String.LastIndexOf$2.call(filterAndPayloadSpecs, /*\n*/ 10, ((endIdx - 1) | 0), endIdx);
                    /*int*/ let startIdx = 0;
                    if (0 <= newlineIdx)
                    {
                        startIdx = ((newlineIdx + 1) | 0);
                    }
                    while(startIdx < endIdx && $.$spc.System.Char.IsWhiteSpace($.$spc.System.String.get_Chars.call(filterAndPayloadSpecs, startIdx)))
                    {
                        startIdx++;
                    }
                    if ($.$sdd.System.Diagnostics.DsesFilterAndTransform.IsActivitySourceEntry(filterAndPayloadSpecs, startIdx, endIdx))
                    {
                        activitySourceSpecList = $.$sdd.System.Diagnostics.DsesFilterAndTransform.CreateActivitySourceTransform(eventSource, filterAndPayloadSpecs, startIdx, endIdx, activitySourceSpecList);
                    }
                    else 
                    {
                        specList = $.$sdd.System.Diagnostics.DsesFilterAndTransform.CreateTransform(eventSource, filterAndPayloadSpecs, startIdx, endIdx, specList);
                    }
                    endIdx = newlineIdx;
                    if (endIdx < 0)
                    {
                        break;
                    }
                }
                /*DsesActivitySourceListener?*/ let activitySourceListener = activitySourceSpecList !== null ? $.$sdd.System.Diagnostics.DsesActivitySourceListener.Create(eventSource, activitySourceSpecList) : null;
                return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.ParsedFilterAndPayloadSpecs().$ctor$1(specList, activitySourceListener);
            }
            static /*bool */ IsActivitySourceEntry(/*string*/ filterAndPayloadSpec, /*int*/ startIdx, /*int*/ endIdx)
            {
                return $.$spc.System.MemoryExtensions.StartsWith$5($.$spc.System.MemoryExtensions.AsSpan$7(filterAndPayloadSpec, startIdx, ((endIdx - startIdx) | 0)), $.$spc.System.MemoryExtensions.AsSpan$3("[AS]"/*c_ActivitySourcePrefix*/), 4/*StringComparison.Ordinal*/);
            }
            static /*DsesFilterAndTransform? */ CreateTransform(/*DiagnosticSourceEventSource*/ eventSource, /*string*/ filterAndPayloadSpec, /*int*/ startIdx, /*int*/ endIdx, /*DsesFilterAndTransform?*/ next)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(filterAndPayloadSpec, null) && startIdx >= 0 && startIdx <= endIdx && endIdx <= filterAndPayloadSpec.length, "filterAndPayloadSpec != null && startIdx >= 0 && startIdx <= endIdx && endIdx <= filterAndPayloadSpec.Length");
                /*string?*/ let listenerNameFilter = null;
                /*string?*/ let eventNameFilter = null;
                /*string?*/ let activityName = null;
                /*bool*/ let noImplicitTransforms = false;
                /*TransformSpec?*/ let explicitTransforms = null;
                /*var*/ let startTransformIdx = startIdx;
                /*var*/ let endEventNameIdx = endIdx;
                /*var*/ let colonIdx = $.$spc.System.String.IndexOf$3.call(filterAndPayloadSpec, /*:*/ 58, startIdx, ((endIdx - startIdx) | 0));
                if (0 <= colonIdx)
                {
                    endEventNameIdx = colonIdx;
                    startTransformIdx = ((colonIdx + 1) | 0);
                }
                /*var*/ let slashIdx = $.$spc.System.String.IndexOf$3.call(filterAndPayloadSpec, /*/*/ 47, startIdx, ((endEventNameIdx - startIdx) | 0));
                if (0 <= slashIdx)
                {
                    listenerNameFilter = $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, startIdx, ((slashIdx - startIdx) | 0));
                    /*var*/ let atIdx = $.$spc.System.String.IndexOf$3.call(filterAndPayloadSpec, /*@*/ 64, ((slashIdx + 1) | 0), ((((endEventNameIdx - slashIdx) | 0) - 1) | 0));
                    if (0 <= atIdx)
                    {
                        activityName = $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, ((atIdx + 1) | 0), ((((endEventNameIdx - atIdx) | 0) - 1) | 0));
                        eventNameFilter = $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, ((slashIdx + 1) | 0), ((((atIdx - slashIdx) | 0) - 1) | 0));
                    }
                    else 
                    {
                        eventNameFilter = $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, ((slashIdx + 1) | 0), ((((endEventNameIdx - slashIdx) | 0) - 1) | 0));
                    }
                }
                else if (startIdx < endEventNameIdx)
                {
                    listenerNameFilter = $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, startIdx, ((endEventNameIdx - startIdx) | 0));
                }
                eventSource.Message("DiagnosticSource: Enabling '" + (listenerNameFilter ?? "*") + "/" + (eventNameFilter ?? "*") + "'");
                if (startTransformIdx < endIdx && $.$spc.System.String.get_Chars.call(filterAndPayloadSpec, startTransformIdx) === /*-*/ 45)
                {
                    eventSource.Message("DiagnosticSource: suppressing implicit transforms.");
                    noImplicitTransforms = true;
                    startTransformIdx++;
                }
                if (startTransformIdx < endIdx)
                {
                    while(true)
                    {
                        /*int*/ let specStartIdx = startTransformIdx;
                        /*int*/ let semiColonIdx = $.$spc.System.String.LastIndexOf$2.call(filterAndPayloadSpec, /*;*/ 59, ((endIdx - 1) | 0), ((endIdx - startTransformIdx) | 0));
                        if (0 <= semiColonIdx)
                        {
                            specStartIdx = ((semiColonIdx + 1) | 0);
                        }
                        if (specStartIdx < endIdx)
                        {
                            if (eventSource.IsEnabled$1(4/*EventLevel.Informational*/, 1n))
                            {
                                eventSource.Message("DiagnosticSource: Parsing Explicit Transform '" + $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, specStartIdx, ((endIdx - specStartIdx) | 0)) + "'");
                            }
                            explicitTransforms = new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec().$ctor$1(eventSource, filterAndPayloadSpec, specStartIdx, endIdx, explicitTransforms);
                        }
                        if (startTransformIdx === specStartIdx)
                        {
                            break;
                        }
                        endIdx = semiColonIdx;
                    }
                }
                /*var*/ let transform = new $.$sdd.System.Diagnostics.DsesFilterAndTransform().$ctor$1(eventSource, next, noImplicitTransforms, explicitTransforms, null, null, 0, null);
                transform.SetupDiagnosticListenerSubscription(listenerNameFilter, eventNameFilter, activityName);
                return transform;
            }
            static /*DsesFilterAndTransform? */ CreateActivitySourceTransform(/*DiagnosticSourceEventSource*/ eventSource, /*string*/ filterAndPayloadSpec, /*int*/ startIdx, /*int*/ endIdx, /*DsesFilterAndTransform?*/ next)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(((endIdx - startIdx) | 0) >= 4, "endIdx - startIdx >= 4");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdd.System.Diagnostics.DsesFilterAndTransform.IsActivitySourceEntry(filterAndPayloadSpec, startIdx, endIdx), "IsActivitySourceEntry(filterAndPayloadSpec, startIdx, endIdx)");
                /*bool*/ let noImplicitTransforms = false;
                /*TransformSpec?*/ let explicitTransforms = null;
                /*ReadOnlySpan<char>*/ let eventName;
                /*ReadOnlySpan<char>*/ let activitySourceName;
                /*DsesActivityEvents*/ let supportedEvent = 3/*DsesActivityEvents.All*/;
                /*DsesSampleActivityFunc*/ let sampleFunc = new $.$sdd.System.Diagnostics.DsesSampleActivityFunc().$ctor($.$sdd.System.Diagnostics.DsesFilterAndTransform, /*static*/ (/*bool*/ hasActivityContext, /*ActivityCreationOptions<ActivityContext>*/ options) =>
                {
                    return 3/*ActivitySamplingResult.AllDataAndRecorded*/;
                }, {"r":1048620,"p":[{"n":"hasActivityContext","p":262145},{"n":"options","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":2949164,"h":0,"f":1048610});
                /*int*/ let colonIdx = $.$spc.System.String.IndexOf$3.call(filterAndPayloadSpec, /*:*/ 58, ((startIdx + "[AS]"/*c_ActivitySourcePrefix*/.length) | 0), ((((endIdx - startIdx) | 0) - "[AS]"/*c_ActivitySourcePrefix*/.length) | 0));
                /*ReadOnlySpan<char>*/ let entry = $.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$7(filterAndPayloadSpec, ((startIdx + "[AS]"/*c_ActivitySourcePrefix*/.length) | 0), (((((colonIdx >= 0 ? colonIdx : endIdx) - startIdx) | 0) - "[AS]"/*c_ActivitySourcePrefix*/.length) | 0)));
                /*int*/ let eventNameIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, entry, /*/*/ 47);
                if (eventNameIndex >= 0)
                {
                    activitySourceName = $.$spc.System.MemoryExtensions.Trim$10(entry.Slice$1(0, eventNameIndex));
                    /*ReadOnlySpan<char>*/ let suffixPart = $.$spc.System.MemoryExtensions.Trim$10(entry.Slice(((eventNameIndex + 1) | 0)));
                    /*int*/ let samplingResultIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, suffixPart, /*-*/ 45);
                    if (samplingResultIndex >= 0)
                    {
                        eventName = $.$spc.System.MemoryExtensions.Trim$10(suffixPart.Slice$1(0, samplingResultIndex));
                        suffixPart = $.$spc.System.MemoryExtensions.Trim$10(suffixPart.Slice(((samplingResultIndex + 1) | 0)));
                        if (suffixPart.Length > 0)
                        {
                            if ($.$spc.System.MemoryExtensions.Equals$2(suffixPart, $.$spc.System.MemoryExtensions.AsSpan$3("Propagate"), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                sampleFunc = new $.$sdd.System.Diagnostics.DsesSampleActivityFunc().$ctor($.$sdd.System.Diagnostics.DsesFilterAndTransform, /*static*/ (/*bool*/ hasActivityContext, /*ActivityCreationOptions<ActivityContext>*/ options) =>
                                {
                                    return 1/*ActivitySamplingResult.PropagationData*/;
                                }, {"r":1048620,"p":[{"n":"hasActivityContext","p":262145},{"n":"options","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":2949164,"h":0,"f":1048610});
                            }
                            else if ($.$spc.System.MemoryExtensions.Equals$2(suffixPart, $.$spc.System.MemoryExtensions.AsSpan$3("Record"), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                sampleFunc = new $.$sdd.System.Diagnostics.DsesSampleActivityFunc().$ctor($.$sdd.System.Diagnostics.DsesFilterAndTransform, /*static*/ (/*bool*/ hasActivityContext, /*ActivityCreationOptions<ActivityContext>*/ options) =>
                                {
                                    return 2/*ActivitySamplingResult.AllData*/;
                                }, {"r":1048620,"p":[{"n":"hasActivityContext","p":262145},{"n":"options","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":2949164,"h":0,"f":1048610});
                            }
                            else if ($.$spc.System.MemoryExtensions.StartsWith$5(suffixPart, $.$spc.System.MemoryExtensions.AsSpan$3("ParentRatioSampler("/*c_ParentRatioSamplerPrefix*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                /*int*/ let endingLocation = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, suffixPart, /*)*/ 41);
                                /*double*/ let ratio;
                                if (endingLocation < 0 || !$.$spc.System.Double.TryParse$4(suffixPart.Slice$1("ParentRatioSampler("/*c_ParentRatioSamplerPrefix*/.length, ((endingLocation - "ParentRatioSampler("/*c_ParentRatioSamplerPrefix*/.length) | 0)), 167/*NumberStyles.Float*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => ratio, ($v) => ratio = $v, $.$spc.System.Double)))
                                {
                                    if (eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                                    {
                                        eventSource.Message("DiagnosticSource: Ignoring filterAndPayloadSpec '[AS]" + $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(entry) + "' because sampling ratio was invalid");
                                    }
                                    return next;
                                }
                                sampleFunc = $.$sdd.System.Diagnostics.DsesSamplerBuilder.CreateParentRatioSampler(ratio);
                            }
                            else if ($.$spc.System.MemoryExtensions.StartsWith$5(suffixPart, $.$spc.System.MemoryExtensions.AsSpan$3("ParentRateLimitingSampler("/*c_ParentRateLimitingSamplerPrefix*/), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                /*int*/ let endingLocation = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, suffixPart, /*)*/ 41);
                                /*int*/ let maximumRatePerSecond;
                                if (endingLocation < 0 || !$.$spc.System.Int32.TryParse$4(suffixPart.Slice$1("ParentRateLimitingSampler("/*c_ParentRateLimitingSamplerPrefix*/.length, ((endingLocation - "ParentRateLimitingSampler("/*c_ParentRateLimitingSamplerPrefix*/.length) | 0)), 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => maximumRatePerSecond, ($v) => maximumRatePerSecond = $v, $.$spc.System.Int32)) || maximumRatePerSecond <= 0)
                                {
                                    if (eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                                    {
                                        eventSource.Message("DiagnosticSource: Ignoring filterAndPayloadSpec '[AS]" + $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(entry) + "' because rate limiting sampling was invalid");
                                    }
                                    return next;
                                }
                                sampleFunc = $.$sdd.System.Diagnostics.DsesSamplerBuilder.CreateParentRateLimitingSampler(maximumRatePerSecond);
                            }
                            else 
                            {
                                if (eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                                {
                                    eventSource.Message("DiagnosticSource: Ignoring filterAndPayloadSpec '[AS]" + $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(entry) + "' because sampling method was invalid");
                                }
                                return next;
                            }
                        }
                    }
                    else 
                    {
                        eventName = suffixPart;
                    }
                    if (eventName.Length > 0)
                    {
                        if ($.$spc.System.MemoryExtensions.Equals$2(eventName, $.$spc.System.MemoryExtensions.AsSpan$3("Start"), 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            supportedEvent = 1/*DsesActivityEvents.ActivityStart*/;
                        }
                        else if ($.$spc.System.MemoryExtensions.Equals$2(eventName, $.$spc.System.MemoryExtensions.AsSpan$3("Stop"), 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            supportedEvent = 2/*DsesActivityEvents.ActivityStop*/;
                        }
                        else 
                        {
                            if (eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                            {
                                eventSource.Message("DiagnosticSource: Ignoring filterAndPayloadSpec '[AS]" + $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(entry) + "' because event name was invalid");
                            }
                            return next;
                        }
                    }
                }
                else 
                {
                    activitySourceName = entry;
                }
                /*string?*/ let activityName = null;
                /*int*/ let plusSignIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, activitySourceName, /*+*/ 43);
                if (plusSignIndex >= 0)
                {
                    activityName = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.MemoryExtensions.Trim$10(activitySourceName.Slice(((plusSignIndex + 1) | 0))));
                    activitySourceName = $.$spc.System.MemoryExtensions.Trim$10(activitySourceName.Slice$1(0, plusSignIndex));
                    if (activityName.length > 0 && activitySourceName.Length === 1 && activitySourceName.get_Item(0).$v === /***/ 42)
                    {
                        if (eventSource.IsEnabled$1(3/*EventLevel.Warning*/, 1n))
                        {
                            eventSource.Message("DiagnosticSource: Ignoring filterAndPayloadSpec '[AS]" + $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(entry) + "' because activity name cannot be specified for wildcard activity sources");
                        }
                        return next;
                    }
                }
                if (colonIdx >= 0)
                {
                    /*int*/ let startTransformIdx = ((colonIdx + 1) | 0);
                    if (startTransformIdx < endIdx && $.$spc.System.String.get_Chars.call(filterAndPayloadSpec, startTransformIdx) === /*-*/ 45)
                    {
                        eventSource.Message("DiagnosticSource: suppressing implicit transforms.");
                        noImplicitTransforms = true;
                        startTransformIdx++;
                    }
                    if (startTransformIdx < endIdx)
                    {
                        while(true)
                        {
                            /*int*/ let specStartIdx = startTransformIdx;
                            /*int*/ let semiColonIdx = $.$spc.System.String.LastIndexOf$2.call(filterAndPayloadSpec, /*;*/ 59, ((endIdx - 1) | 0), ((endIdx - startTransformIdx) | 0));
                            if (0 <= semiColonIdx)
                            {
                                specStartIdx = ((semiColonIdx + 1) | 0);
                            }
                            if (specStartIdx < endIdx)
                            {
                                if (eventSource.IsEnabled$1(4/*EventLevel.Informational*/, 1n))
                                {
                                    eventSource.Message("DiagnosticSource: Parsing Explicit Transform '" + $.$spc.System.String.Substring$1.call(filterAndPayloadSpec, specStartIdx, ((endIdx - specStartIdx) | 0)) + "'");
                                }
                                explicitTransforms = new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec().$ctor$1(eventSource, filterAndPayloadSpec, specStartIdx, endIdx, explicitTransforms);
                            }
                            if (startTransformIdx === specStartIdx)
                            {
                                break;
                            }
                            endIdx = semiColonIdx;
                        }
                    }
                }
                return new $.$sdd.System.Diagnostics.DsesFilterAndTransform().$ctor$1(eventSource, next, noImplicitTransforms, explicitTransforms, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(activitySourceName), activityName, supportedEvent, sampleFunc);
            }
            $ctor$1(/*DiagnosticSourceEventSource*/ eventSource, /*DsesFilterAndTransform?*/ next, /*bool*/ noImplicitTransforms, /*TransformSpec?*/ explicitTransforms, /*string?*/ sourceName, /*string?*/ activityName, /*DsesActivityEvents*/ activityEvents, /*DsesSampleActivityFunc?*/ sampleFunc)
            {
                super.$ctor();
                {
                    this._eventSource = eventSource;
                    this._noImplicitTransforms = noImplicitTransforms;
                    this._explicitTransforms = explicitTransforms;
                    this.Next = next;
                    this.SourceName = sourceName;
                    this.ActivityName = activityName;
                    this.Events = activityEvents;
                    this.SampleFunc = sampleFunc;
                }
                return this;
            }
            /*void */ Dispose()
            {
                if (this._diagnosticsListenersSubscription !== null)
                {
                    this._diagnosticsListenersSubscription.System$IDisposable$Dispose();
                    this._diagnosticsListenersSubscription = null;
                }
                if (this._liveSubscriptions !== null)
                {
                    /*Subscriptions?*/ let subscr = this._liveSubscriptions;
                    this._liveSubscriptions = null;
                    while(subscr !== null)
                    {
                        subscr.Subscription.System$IDisposable$Dispose();
                        subscr = subscr.Next;
                    }
                }
            }
            /*List<KeyValuePair<string, string?>> */ Morph(/*object?*/ args)
            {
                /*var*/ let outputArgs = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1();
                if (args !== null)
                {
                    if (!this._noImplicitTransforms)
                    {
                        /*Type*/ let argType = $.$spc.System.Object.GetType.call(args);
                        /*TransformSpec?*/ let implicitTransforms;
                        /*ImplicitTransformEntry?*/ let cacheEntry = this._firstImplicitTransformsEntry;
                        if (cacheEntry !== null && $.$spc.System.Type.op_Equality$1(cacheEntry.Type, argType))
                        {
                            implicitTransforms = cacheEntry.Transforms;
                        }
                        else if (cacheEntry === null)
                        {
                            implicitTransforms = $.$sdd.System.Diagnostics.DsesFilterAndTransform.MakeImplicitTransforms(this._eventSource, argType);
                            $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DsesFilterAndTransform.ImplicitTransformEntry, $.$ref(() => this._firstImplicitTransformsEntry, ($v) => this._firstImplicitTransformsEntry = $v, $.$sdd.System.Diagnostics.DsesFilterAndTransform.ImplicitTransformEntry), (() =>
                            {
                                //new $.$sdd.System.Diagnostics.DsesFilterAndTransform.ImplicitTransformEntry()
                                const $t2 = $.$sdd.System.Diagnostics.DsesFilterAndTransform.ImplicitTransformEntry;
                                const $i2 = new $t2();
                                $i2.Type = argType;
                                $i2.Transforms = implicitTransforms;
                                return $i2;
                            })(), null);
                        }
                        else 
                        {
                            if (this._implicitTransformsTable === null)
                            {
                                $.$spc.System.Threading.Interlocked.CompareExchange$14($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec), $.$ref(() => this._implicitTransformsTable, ($v) => this._implicitTransformsTable = $v, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec)), new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$($.$spc.System.Type, $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec))().$ctor$2(1, 8), null);
                            }
                            implicitTransforms = this._implicitTransformsTable.GetOrAdd(argType, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec))().$ctor(this,  (/*t*/ t) =>
                            {
                                return $.$sdd.System.Diagnostics.DsesFilterAndTransform.MakeImplicitTransforms(this._eventSource, t);
                            }, {"r":3276844,"p":[{"n":"t","p":142606337}],"n":"","d":2949164,"h":0,"f":1048578}));
                        }
                        if (implicitTransforms !== null)
                        {
                            for(/*TransformSpec?*/ let serializableArg = implicitTransforms; serializableArg !== null; serializableArg = serializableArg.Next)
                            {
                                outputArgs.Add(serializableArg.Morph(args));
                            }
                        }
                    }
                    if (this._explicitTransforms !== null)
                    {
                        for(/*TransformSpec?*/ let explicitTransform = this._explicitTransforms; explicitTransform !== null; explicitTransform = explicitTransform.Next)
                        {
                            /*var*/ let keyValue = explicitTransform.Morph(args);
                            if ($.$spc.System.String.op_Inequality(keyValue.Value, null))
                            {
                                outputArgs.Add(keyValue);
                            }
                        }
                    }
                }
                return outputArgs;
            }
            /*void */ SetupDiagnosticListenerSubscription(/*string?*/ listenerNameFilter, /*string?*/ eventNameFilter, /*string?*/ activityName)
            {
                /*Action<string, string, IEnumerable<KeyValuePair<string, string?>>>?*/ let writeEvent = null;
                if ($.$spc.System.String.op_Inequality(activityName, null) && $.$spc.System.String.Contains.call(activityName, "Activity"))
                {
                    writeEvent = (() =>
                    {
                        if (activityName === "Activity1Start")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.Activity1Start);
                        }
                        if (activityName === "Activity1Stop")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.Activity1Stop);
                        }
                        if (activityName === "Activity2Start")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.Activity2Start);
                        }
                        if (activityName === "Activity2Stop")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.Activity2Stop);
                        }
                        if (activityName === "RecursiveActivity1Start")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.RecursiveActivity1Start);
                        }
                        if (activityName === "RecursiveActivity1Stop")
                        {
                            return new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.RecursiveActivity1Stop);
                        }
                        return null;
                    })();
                    if (writeEvent === null)
                    {
                        this._eventSource.Message("DiagnosticSource: Could not find Event to log Activity " + activityName);
                    }
                }
                writeEvent ??= new ($.$spc.System.Action$$$$($.$spc.System.String, $.$spc.System.String, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))))().$ctor(this._eventSource, this._eventSource.Event);
                this._diagnosticsListenersSubscription = $.$sdd.System.Diagnostics.DiagnosticListener.AllListeners.System$IObservable$$$Subscribe(new ($.$sdd.System.Diagnostics.DsesFilterAndTransform.CallbackObserver$$($.$sdd.System.Diagnostics.DiagnosticListener))().$ctor$1(new ($.$spc.System.Action$$($.$sdd.System.Diagnostics.DiagnosticListener))().$ctor(this,  (/*DiagnosticListener*/ newListener) =>
                {
                    if ($.$spc.System.String.op_Equality(listenerNameFilter, null) || $.$spc.System.String.op_Equality(listenerNameFilter, newListener.Name))
                    {
                        this._eventSource.NewDiagnosticListener(newListener.Name);
                        /*Predicate<string>?*/ let eventNameFilterPredicate = null;
                        if ($.$spc.System.String.op_Inequality(eventNameFilter, null))
                        {
                            eventNameFilterPredicate = new ($.$spc.System.Predicate$$($.$spc.System.String))().$ctor(this,  (/*string*/ eventName) =>
                            {
                                return $.$spc.System.String.op_Equality(eventNameFilter, eventName);
                            }, {"r":262145,"p":[{"n":"eventName","p":1310721}],"n":"","d":2949164,"h":0,"f":1048578});
                        }
                        /*void*/  function OnEventWritten(/*KeyValuePair<string, object?>*/ evnt)
                        {
                            if ($.$spc.System.String.op_Inequality(eventNameFilter, null) && $.$spc.System.String.op_Inequality(eventNameFilter, evnt.Key))
                            {
                                return;
                            }
                            /*var*/ let outputArgs = this.Morph(evnt.Value);
                            /*var*/ let eventName = evnt.Key;
                            writeEvent.Invoke(newListener.Name, eventName, outputArgs);
                        }
                        /*var*/ let subscription = newListener.Subscribe$1(new ($.$sdd.System.Diagnostics.DsesFilterAndTransform.CallbackObserver$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1(new ($.$spc.System.Action$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor(this, OnEventWritten.bind(this))), eventNameFilterPredicate);
                        this._liveSubscriptions = new $.$sdd.System.Diagnostics.DsesFilterAndTransform.Subscriptions().$ctor$1(subscription, this._liveSubscriptions);
                    }
                }, {"r":65537,"p":[{"n":"newListener","p":1966124}],"n":"","d":2949164,"h":0,"f":1048578})), [$.$sdd.System.Diagnostics.DiagnosticListener]);
            }
            /*DsesFilterAndTransform?*/ Next = null;
            /*string?*/ SourceName = null;
            /*string?*/ ActivityName = null;
            /*DsesActivityEvents*/ Events = 0;
            /*DsesSampleActivityFunc?*/ SampleFunc = null;
            static $_ParsedFilterAndPayloadSpecs;
            static get ParsedFilterAndPayloadSpecs()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform;
                return $cls.$_ParsedFilterAndPayloadSpecs ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.ParsedFilterAndPayloadSpecs", ($self) => class ParsedFilterAndPayloadSpecs extends $.$spc.System.Object
                {
                    /*DsesFilterAndTransform?*/ _specList = null;
                    /*DsesActivitySourceListener?*/ _activitySourceListener = null;
                    $ctor$1(/*DsesFilterAndTransform?*/ specList, /*DsesActivitySourceListener?*/ activitySourceListener)
                    {
                        super.$ctor();
                        {
                            this._specList = specList;
                            this._activitySourceListener = activitySourceListener;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        this._activitySourceListener?.Dispose();
                        this._activitySourceListener = null;
                        /*var*/ let curSpec = this._specList;
                        this._specList = null;
                        while(curSpec !== null)
                        {
                            curSpec.Dispose();
                            curSpec = curSpec.Next;
                        }
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 3145772;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2949164,"h":3145772}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `DsesFilterAndTransform.ParsedFilterAndPayloadSpecs`; }
                }, $cls, ($v) => $cls.$_ParsedFilterAndPayloadSpecs = $v);
            }
            static $_ImplicitTransformEntry;
            static get ImplicitTransformEntry()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform;
                return $cls.$_ImplicitTransformEntry ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.ImplicitTransformEntry", ($self) => class ImplicitTransformEntry extends $.$spc.System.Object
                {
                    /*Type?*/ Type = null;
                    /*TransformSpec?*/ Transforms = null;
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 3080236;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2949164,"h":3080236}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `DsesFilterAndTransform.ImplicitTransformEntry`; }
                }, $cls, ($v) => $cls.$_ImplicitTransformEntry = $v);
            }
            static $_TransformSpec;
            static get TransformSpec()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform;
                return $cls.$_TransformSpec ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec", ($self) => class TransformSpec extends $.$spc.System.Object
                {
                    $ctor$1(/*DiagnosticSourceEventSource*/ eventSource, /*string*/ transformSpec, /*int*/ startIdx, /*int*/ endIdx, /*TransformSpec?*/ next)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(transformSpec, null) && startIdx >= 0 && startIdx < endIdx && endIdx <= transformSpec.length, "transformSpec != null && startIdx >= 0 && startIdx < endIdx && endIdx <= transformSpec.Length");
                            this.Next = next;
                            /*int*/ let equalsIdx = $.$spc.System.String.IndexOf$3.call(transformSpec, /*=*/ 61, startIdx, ((endIdx - startIdx) | 0));
                            if (0 <= equalsIdx)
                            {
                                this._outputName = $.$spc.System.String.Substring$1.call(transformSpec, startIdx, ((equalsIdx - startIdx) | 0));
                                startIdx = ((equalsIdx + 1) | 0);
                            }
                            while(startIdx < endIdx)
                            {
                                /*int*/ let dotIdx = $.$spc.System.String.LastIndexOf$2.call(transformSpec, /*.*/ 46, ((endIdx - 1) | 0), ((endIdx - startIdx) | 0));
                                /*int*/ let idIdx = startIdx;
                                if (0 <= dotIdx)
                                {
                                    idIdx = ((dotIdx + 1) | 0);
                                }
                                /*string*/ let propertyName = $.$spc.System.String.Substring$1.call(transformSpec, idIdx, ((endIdx - idIdx) | 0));
                                this._fetches = new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec().$ctor$1(eventSource, propertyName, this._fetches);
                                this._outputName ??= propertyName;
                                endIdx = dotIdx;
                            }
                        }
                        return this;
                    }
                    /*KeyValuePair<string, string?> */ Morph(/*object?*/ obj)
                    {
                        for(/*PropertySpec?*/ let cur = this._fetches; cur !== null; cur = cur.Next)
                        {
                            if (obj !== null || cur.IsStatic)
                            {
                                obj = cur.Fetch(obj);
                            }
                        }
                        const $t1 = obj;
                        return new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(this._outputName, $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t)));
                    }
                    /*TransformSpec?*/ Next = null;
                    static $_PropertySpec;
                    static get PropertySpec()
                    {
                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec;
                        return $cls.$_PropertySpec ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec", ($self) => class PropertySpec extends $.$spc.System.Object
                        {
                            /*string*/ static CurrentActivityPropertyName = null;
                            /*string*/ static EnumeratePropertyName = null;
                            $ctor$1(/*DiagnosticSourceEventSource*/ eventSource, /*string*/ propertyName, /*PropertySpec?*/ next)
                            {
                                super.$ctor();
                                {
                                    this._eventSource = eventSource;
                                    this._propertyName = propertyName;
                                    this.Next = next;
                                    if ($.$spc.System.String.op_Equality(this._propertyName, "*Activity"/*CurrentActivityPropertyName*/))
                                    {
                                        this.IsStatic = true;
                                    }
                                }
                                return this;
                            }
                            /*bool*/ IsStatic = false;
                            /*PropertySpec?*/ Next = null;
                            /*object? */ Fetch(/*object?*/ obj)
                            {
                                /*PropertyFetch?*/ let fetch = this._fetchForExpectedType;
                                $.$spc.System.Diagnostics.Debug.Assert$1(obj !== null || this.IsStatic, "obj != null || IsStatic");
                                const $t1 = obj;
                                /*Type?*/ let objType = $.$ifnn($t1, ($t) => $.$spc.System.Object.GetType.call($t));
                                if (fetch === null || $.$spc.System.Type.op_Inequality$1(fetch.Type, objType))
                                {
                                    this._fetchForExpectedType = fetch = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.FetcherForProperty(this._eventSource, objType, this._propertyName);
                                }
                                /*object?*/ let ret = null;
                                try
                                {
                                    ret = fetch.Fetch(obj);
                                }
                                catch(e)
                                {
                                    this._eventSource.Message(`Property ${$.$spc.System.Type.ToString.call(objType)}.${this._propertyName} threw the exception ${$.$spc.System.Exception.ToString.call(e)}`);
                                }
                                return ret;
                            }
                            static $_PropertyFetch;
                            static get PropertyFetch()
                            {
                                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec;
                                return $cls.$_PropertyFetch ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch", ($self) => class PropertyFetch extends $.$spc.System.Object
                                {
                                    $ctor$1(/*Type?*/ type)
                                    {
                                        super.$ctor();
                                        {
                                            this.Type = type;
                                        }
                                        return this;
                                    }
                                    /*Type?*/ Type = null;
                                    static /*PropertyFetch */ FetcherForProperty(/*DiagnosticSourceEventSource*/ eventSource, /*Type?*/ type, /*string*/ propertyName)
                                    {
                                        if ($.$spc.System.String.op_Equality(propertyName, null))
                                        {
                                            return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch().$ctor$1(type);
                                        }
                                        if ($.$spc.System.String.op_Equality(propertyName, "*Activity"/*CurrentActivityPropertyName*/))
                                        {
                                            return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.CurrentActivityPropertyFetch().$ctor$2();
                                        }
                                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Inequality$1(type, null), "Type should only be null for the well-known static fetchers already checked");
                                        /*TypeInfo*/ let typeInfo = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(type);
                                        if ($.$spc.System.String.op_Equality(propertyName, "*Enumerate"/*EnumeratePropertyName*/))
                                        {
                                            let $i1 = 0;
                                            let $arr1 = typeInfo.GetInterfaces();
                                            while ($i1 < $arr1.length)
                                            {
                                                let iFaceType = $arr1[$i1++];
                                                /*TypeInfo*/ let iFaceTypeInfo = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(iFaceType);
                                                if (!iFaceTypeInfo.IsGenericType || $.$spc.System.Type.op_Inequality$1(iFaceTypeInfo.GetGenericTypeDefinition(), $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                                                {
                                                    continue;
                                                }
                                                return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.CreateEnumeratePropertyFetch(type, iFaceTypeInfo);
                                            }
                                            eventSource.Message(`*Enumerate applied to non-enumerable type ${$.$spc.System.Type.ToString.call(type)}`);
                                            return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch().$ctor$1(type);
                                        }
                                        else 
                                        {
                                            /*PropertyInfo?*/ let propertyInfo = typeInfo.GetDeclaredProperty(propertyName);
                                            if ($.$spc.System.Reflection.PropertyInfo.op_Equality$1(propertyInfo, null))
                                            {
                                                let $i1 = 0;
                                                let $arr1 = typeInfo.GetProperties$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/);
                                                while ($i1 < $arr1.length)
                                                {
                                                    let pi = $arr1[$i1++];
                                                    if ($.$spc.System.String.op_Equality(pi.Name, propertyName))
                                                    {
                                                        propertyInfo = pi;
                                                        break;
                                                    }
                                                }
                                            }
                                            if ($.$spc.System.Reflection.PropertyInfo.op_Equality$1(propertyInfo, null))
                                            {
                                                eventSource.Message(`Property ${propertyName} not found on ${$.$spc.System.Type.ToString.call(type)}. Ensure the name is spelled correctly. If you published the application with PublishTrimmed=true, ensure the property was not trimmed away.`);
                                                return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch().$ctor$1(type);
                                            }
                                            else if ((propertyInfo.GetMethod?.IsStatic$1 ?? null) === true || (propertyInfo.SetMethod?.IsStatic$1 ?? null) === true)
                                            {
                                                eventSource.Message(`Property ${propertyName} is static.`);
                                                return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch().$ctor$1(type);
                                            }
                                            return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.CreatePropertyFetch(typeInfo, propertyInfo);
                                        }
                                    }
                                    static /*PropertyFetch */ CreateEnumeratePropertyFetch(/*Type*/ type, /*TypeInfo*/ enumerableOfTType)
                                    {
                                        /*Type*/ let elemType = $.$spc.System.Array.$ReadT1.call(enumerableOfTType.GetGenericArguments(), 0);
                                        if (!$.$spc.System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported && elemType.IsValueType)
                                        {
                                            return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch().$ctor$2(type);
                                        }
                                        /*Type*/ let instantiatedTypedPropertyFetcher = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo($.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch$$().$type).MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ elemType ], null, null));
                                        return $.$cast($.$spc.System.Activator.CreateInstance$1(instantiatedTypedPropertyFetcher, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ type ], null, null)), $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch);
                                    }
                                    static /*PropertyFetch */ CreatePropertyFetch(/*Type*/ type, /*PropertyInfo*/ propertyInfo)
                                    {
                                        if (!$.$spc.System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported && (propertyInfo.DeclaringType.IsValueType || propertyInfo.PropertyType.IsValueType))
                                        {
                                            return new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ReflectionPropertyFetch().$ctor$2(type, propertyInfo);
                                        }
                                        /*Type*/ let typedPropertyFetcher = type.IsValueType ? $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ValueTypedFetchProperty$$$().$type : $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.RefTypedFetchProperty$$$().$type;
                                        /*Type*/ let instantiatedTypedPropertyFetcher = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(typedPropertyFetcher).MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ propertyInfo.DeclaringType, propertyInfo.PropertyType ], null, null));
                                        return $.$cast($.$spc.System.Activator.CreateInstance$1(instantiatedTypedPropertyFetcher, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ type, propertyInfo ], null, null)), $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch);
                                    }
                                    /*object? */ Fetch(/*object?*/ obj)
                                    {
                                        return null;
                                    }
                                    static $_RefTypedFetchProperty$$$;
                                    static RefTypedFetchProperty$$$(TObject, TProperty)
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return ($cls.$_RefTypedFetchProperty$$$ ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.RefTypedFetchProperty<,>", (TObject, TProperty) => $asm.$gt("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.RefTypedFetchProperty<,>", [TObject, TProperty], ($self) => class RefTypedFetchProperty$$$ extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            $ctor$2(/*Type*/ type, /*PropertyInfo*/ property)
                                            {
                                                super.$ctor$1(type);
                                                {
                                                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(TObject.$type).IsAssignableFrom$1($.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(type)), "typeof(TObject).GetTypeInfo().IsAssignableFrom(type.GetTypeInfo())");
                                                    this._propertyFetch = $.$cast(property.GetMethod.CreateDelegate($.$spc.System.Func$$$(TObject, TProperty).$type), $.$spc.System.Func$$$(TObject, TProperty));
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(obj, TObject), "obj is TObject");
                                                return $.$box(this._propertyFetch.Invoke($.$cast(obj, TObject)), TProperty);
                                            }
                                            /*Func<TObject, TProperty>*/ _propertyFetch = null;
                                            static $h = 3735596;
                                            static $g = 2;
                                            static $f = 0b10000000011010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"r":2,"d":3407916,"h":this.$h}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.RefTypedFetchProperty<${TObject?.$fullName},${TProperty?.$fullName}>`; }
                                        }), $cls, ($v) => $cls.$_RefTypedFetchProperty$$$ = $v))(TObject, TProperty);
                                    }
                                    static $_StructFunc$$$;
                                    static StructFunc$$$(TStruct, TProperty)
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return ($cls.$_StructFunc$$$ ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.StructFunc<,>", (TStruct, TProperty) => $asm.$gt("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.StructFunc<,>", [TStruct, TProperty], ($self) => class StructFunc$$$ extends $.$spc.System.MulticastDelegate
                                        {
                                            $ctor(/*object*/ target, fn, anmodel)
                                            {
                                                this.$target = target;
                                                this.$nativeFunction = fn;
                                                if (anmodel) this.$nfmodel = anmodel;
                                                if (typeof(target) === 'object') this._target = target;
                                                return this;
                                            }
                                            /*TProperty*/ Invoke(/**/ thisArg)
                                            {
                                                return this.$nativeFunction.call(this.$target, thisArg);
                                            }
                                            static $h = 3801132;
                                            static $g = 2;
                                            static $f = 0b10000000011000000;
                                            static $k = 5;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":66191361,"r":2,"d":3407916,"h":this.$h}; }
                                            static get $b() { return $.$spc.System.MulticastDelegate; }
                                            static $$i;
                                            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.StructFunc<${TStruct?.$fullName},${TProperty?.$fullName}>`; }
                                        }), $cls, ($v) => $cls.$_StructFunc$$$ = $v))(TStruct, TProperty);
                                    }
                                    static $_ValueTypedFetchProperty$$$;
                                    static ValueTypedFetchProperty$$$(TStruct, TProperty)
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return ($cls.$_ValueTypedFetchProperty$$$ ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ValueTypedFetchProperty<,>", (TStruct, TProperty) => $asm.$gt("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ValueTypedFetchProperty<,>", [TStruct, TProperty], ($self) => class ValueTypedFetchProperty$$$ extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            $ctor$2(/*Type*/ type, /*PropertyInfo*/ property)
                                            {
                                                super.$ctor$1(type);
                                                {
                                                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TStruct.$type, type), "typeof(TStruct) == type");
                                                    this._propertyFetch = $.$cast(property.GetMethod.CreateDelegate($.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.StructFunc$$$(TStruct, TProperty).$type), $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.StructFunc$$$(TStruct, TProperty));
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(obj, TStruct), "obj is TStruct");
                                                /*TStruct*/ let structObj = $.$cast(obj, TStruct);
                                                return $.$box(this._propertyFetch.Invoke($.$ref(() => structObj, ($v) => structObj = $v, TStruct)), TProperty);
                                            }
                                            /*StructFunc<TStruct, TProperty>*/ _propertyFetch = null;
                                            static $h = 3866668;
                                            static $g = 2;
                                            static $f = 0b10000000011010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"r":2,"d":3407916,"h":this.$h}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ValueTypedFetchProperty<${TStruct?.$fullName},${TProperty?.$fullName}>`; }
                                        }), $cls, ($v) => $cls.$_ValueTypedFetchProperty$$$ = $v))(TStruct, TProperty);
                                    }
                                    static $_ReflectionPropertyFetch;
                                    static get ReflectionPropertyFetch()
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return $cls.$_ReflectionPropertyFetch ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ReflectionPropertyFetch", ($self) => class ReflectionPropertyFetch extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            /*MethodInvoker*/ _getterInvoker = null;
                                            $ctor$2(/*Type*/ type, /*PropertyInfo*/ property)
                                            {
                                                super.$ctor$1(type);
                                                {
                                                    this._getterInvoker = $.$spc.System.Reflection.MethodInvoker.Create(property.GetMethod);
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                return this._getterInvoker.Invoke(obj);
                                            }
                                            static $h = 3670060;
                                            static $f = 0b10000000010010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"d":3407916,"h":3670060}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.ReflectionPropertyFetch`; }
                                        }, $cls, ($v) => $cls.$_ReflectionPropertyFetch = $v);
                                    }
                                    static $_EnumeratePropertyFetch;
                                    static get EnumeratePropertyFetch()
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return $cls.$_EnumeratePropertyFetch ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch", ($self) => class EnumeratePropertyFetch extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            $ctor$2(/*Type*/ type)
                                            {
                                                super.$ctor$1(type);
                                                {
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                /*IEnumerable?*/ let enumerable = $.$as(obj, $.$spc.System.Collections.IEnumerable);
                                                $.$spc.System.Diagnostics.Debug.Assert$1(!(enumerable === null), "enumerable is not null");
                                                /*IEnumerator*/ let en = enumerable.System$Collections$IEnumerable$GetEnumerator();
                                                let disposable = null;
                                                try
                                                {
                                                    disposable = $.$as(en, $.$spc.System.IDisposable);
                                                    if (!en.System$Collections$IEnumerator$MoveNext())
                                                    {
                                                        return $.$spc.System.String.Empty;
                                                    }
                                                    /*object?*/ let currentValue = en.System$Collections$IEnumerator$Current;
                                                    const $t1 = currentValue;
                                                    /*string?*/ let firstString = $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t));
                                                    if (!en.System$Collections$IEnumerator$MoveNext())
                                                    {
                                                        return firstString ?? $.$spc.System.String.Empty;
                                                    }
                                                    /*var*/ let result = new $.$sdd.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null));
                                                    result.Append$1(firstString);
                                                    do
                                                    {
                                                        currentValue = en.System$Collections$IEnumerator$Current;
                                                        result.Append$1(",");
                                                        if (currentValue !== null)
                                                        {
                                                            result.Append$1($.$spc.System.Object.ToString.call(currentValue));
                                                        }
                                                    }
                                                    while(en.System$Collections$IEnumerator$MoveNext());
                                                    return $.$sdd.System.Text.ValueStringBuilder.ToString.call(result);
                                                }
                                                finally
                                                {
                                                    disposable?.Dispose()
                                                }
                                            }
                                            static $h = 3538988;
                                            static $f = 0b10000000010010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"d":3407916,"h":3538988}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch`; }
                                        }, $cls, ($v) => $cls.$_EnumeratePropertyFetch = $v);
                                    }
                                    static $_CurrentActivityPropertyFetch;
                                    static get CurrentActivityPropertyFetch()
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return $cls.$_CurrentActivityPropertyFetch ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.CurrentActivityPropertyFetch", ($self) => class CurrentActivityPropertyFetch extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            $ctor$2()
                                            {
                                                super.$ctor$1(null);
                                                {
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                return $.$sdd.System.Diagnostics.Activity.Current;
                                            }
                                            static $h = 3473452;
                                            static $f = 0b10000000010010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"d":3407916,"h":3473452}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.CurrentActivityPropertyFetch`; }
                                        }, $cls, ($v) => $cls.$_CurrentActivityPropertyFetch = $v);
                                    }
                                    static $_EnumeratePropertyFetch$$;
                                    static EnumeratePropertyFetch$$(ElementType)
                                    {
                                        let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch;
                                        return ($cls.$_EnumeratePropertyFetch$$ ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch<>", (ElementType) => $asm.$gt("$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch<>", [ElementType], ($self) => class EnumeratePropertyFetch$$ extends $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch
                                        {
                                            $ctor$2(/*Type*/ type)
                                            {
                                                super.$ctor$1(type);
                                                {
                                                }
                                                return this;
                                            }
                                            /*object? */ Fetch(/*object?*/ obj)
                                            {
                                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(obj, $.$spc.System.Collections.Generic.IEnumerable$$(ElementType)), "obj is IEnumerable<ElementType>");
                                                return $.$spc.System.String.Join$12(ElementType, ",", $.$cast(obj, $.$spc.System.Collections.Generic.IEnumerable$$(ElementType)));
                                            }
                                            static $h = 3604524;
                                            static $g = 1;
                                            static $f = 0b10000000011010000;
                                            static $k = 1;
                                            static $$md;
                                            static get $md() { return this.$$md ??= {"b":3407916,"r":1,"d":3407916,"h":this.$h}; }
                                            static get $b() { return $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch; }
                                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch.EnumeratePropertyFetch<${ElementType?.$fullName}>`; }
                                        }), $cls, ($v) => $cls.$_EnumeratePropertyFetch$$ = $v))(ElementType);
                                    }
                                    static $h = 3407916;
                                    static $f = 0b10000000000010000;
                                    static $k = 1;
                                    static $$md;
                                    static get $md() { return this.$$md ??= {"b":131073,"d":3342380,"h":3407916}; }
                                    static get $b() { return $.$spc.System.Object; }
                                    static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec.PropertyFetch`; }
                                }, $cls, ($v) => $cls.$_PropertyFetch = $v);
                            }
                            /*DiagnosticSourceEventSource*/ _eventSource = null;
                            /*string*/ _propertyName = null;
                            /*PropertyFetch?*/ _fetchForExpectedType = null;
                            //default member initializer
                            constructor()
                            {
                                super();
                                this.IsStatic = false;
                            }
                            //Static Initializer
                            static $sinit()
                            {
                                {
                                    this.CurrentActivityPropertyName = "*Activity";
                                }
                                {
                                    this.EnumeratePropertyName = "*Enumerate";
                                }
                            }
                            static $h = 3342380;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"d":3276844,"h":3342380}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `DsesFilterAndTransform.TransformSpec.PropertySpec`; }
                        }, $cls, ($v) => $cls.$_PropertySpec = $v);
                    }
                    /*string*/ _outputName = null;
                    /*PropertySpec?*/ _fetches = null;
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._outputName = null;
                    }
                    static $h = 3276844;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2949164,"h":3276844}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `DsesFilterAndTransform.TransformSpec`; }
                }, $cls, ($v) => $cls.$_TransformSpec = $v);
            }
            static $_CallbackObserver$$;
            static CallbackObserver$$(T)
            {
                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform;
                return ($cls.$_CallbackObserver$$ ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.CallbackObserver<>", (T) => $asm.$gt("$sdd.System.Diagnostics.DsesFilterAndTransform.CallbackObserver<>", [T], ($self) => class CallbackObserver$$ extends $.$spc.System.Object
                {
                    $ctor$1(/*Action<T>*/ callback)
                    {
                        super.$ctor();
                        {
                            this._callback = callback;
                        }
                        return this;
                    }
                    /*void */ OnCompleted()
                    {
                    }
                    /*void */ OnError(/*Exception*/ error)
                    {
                    }
                    /*void */ OnNext(/*T*/ value)
                    {
                        this._callback.Invoke(value);
                    }
                    /*Action<T>*/ _callback = null;
                    //Generated interface implemetation for System.IObserver<T>.OnNext(T)
                    System$IObserver$$$OnNext()
                    {
                        return this.OnNext(...arguments);
                    }
                    //Generated interface implemetation for System.IObserver<T>.OnError(System.Exception)
                    System$IObserver$$$OnError()
                    {
                        return this.OnError(...arguments);
                    }
                    //Generated interface implemetation for System.IObserver<T>.OnCompleted()
                    System$IObserver$$$OnCompleted()
                    {
                        return this.OnCompleted(...arguments);
                    }
                    static $h = 3014700;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"r":1,"d":2949164,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IObserver$$(T) ]; }
                    static get $fullName() { return `DsesFilterAndTransform.CallbackObserver<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_CallbackObserver$$ = $v))(T);
            }
            static $_Subscriptions;
            static get Subscriptions()
            {
                let $cls = $.$sdd.System.Diagnostics.DsesFilterAndTransform;
                return $cls.$_Subscriptions ??= $asm.$ncls("$sdd.System.Diagnostics.DsesFilterAndTransform.Subscriptions", ($self) => class Subscriptions extends $.$spc.System.Object
                {
                    $ctor$1(/*IDisposable*/ subscription, /*Subscriptions?*/ next)
                    {
                        super.$ctor();
                        {
                            this.Subscription = subscription;
                            this.Next = next;
                        }
                        return this;
                    }
                    /*IDisposable*/ Subscription = null;
                    /*Subscriptions?*/ Next = null;
                    static $h = 3211308;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2949164,"h":3211308}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `DsesFilterAndTransform.Subscriptions`; }
                }, $cls, ($v) => $cls.$_Subscriptions = $v);
            }
            static /*TransformSpec? */ MakeImplicitTransforms(/*DiagnosticSourceEventSource*/ eventSource, /*Type*/ type)
            {
                /*TransformSpec?*/ let newSerializableArgs = null;
                /*TypeInfo*/ let curTypeInfo = $.$spc.System.Reflection.IntrospectionExtensions.GetTypeInfo(type);
                let $i1 = 0;
                let $arr1 = curTypeInfo.GetProperties$1(8/*BindingFlags.Static*/ | 4/*BindingFlags.Instance*/ | 16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/);
                while ($i1 < $arr1.length)
                {
                    let property = $arr1[$i1++];
                    if ($.$spc.System.Reflection.MethodInfo.op_Equality$2(property.GetMethod, null) || property.GetMethod.GetParameters().length > 0)
                    {
                        continue;
                    }
                    newSerializableArgs = new $.$sdd.System.Diagnostics.DsesFilterAndTransform.TransformSpec().$ctor$1(eventSource, property.Name, 0, property.Name.length, newSerializableArgs);
                }
                return $.$sdd.System.Diagnostics.DsesFilterAndTransform.Reverse(newSerializableArgs);
            }
            static /*TransformSpec? */ Reverse(/*TransformSpec?*/ list)
            {
                /*TransformSpec?*/ let ret = null;
                while(list !== null)
                {
                    /*var*/ let next = list.Next;
                    list.Next = ret;
                    ret = list;
                    list = next;
                }
                return ret;
            }
            /*DiagnosticSourceEventSource*/ _eventSource = null;
            /*IDisposable?*/ _diagnosticsListenersSubscription = null;
            /*Subscriptions?*/ _liveSubscriptions = null;
            /*bool*/ _noImplicitTransforms = false;
            /*ImplicitTransformEntry?*/ _firstImplicitTransformsEntry = null;
            /*ConcurrentDictionary<Type, TransformSpec?>?*/ _implicitTransformsTable = null;
            /*TransformSpec?*/ _explicitTransforms = null;
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.Events = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.c_ActivitySourcePrefix = "[AS]";
                }
                {
                    this.c_ParentRatioSamplerPrefix = "ParentRatioSampler(";
                }
                {
                    this.c_ParentRateLimitingSamplerPrefix = "ParentRateLimitingSampler(";
                }
            }
            static $h = 2949164;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":2949164}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `DsesFilterAndTransform`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.ActivitySource", ($self) => class ActivitySource extends $.$spc.System.Object
        {
            /*SynchronizedList<ActivitySource>*/ static s_activeSources = null;
            /*SynchronizedList<ActivityListener>*/ static s_allListeners = null;
            /*SynchronizedList<ActivityListener>?*/ _listeners = null;
            $ctor$1(/*string*/ name)
            {
                this.$ctor$5(name, "", null, null);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*string?*/ version)
            {
                this.$ctor$5(name, version, null, null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*string?*/ version, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                this.$ctor$5(name, version, tags, null);
                {
                }
                return this;
            }
            $ctor$4(/*ActivitySourceOptions*/ options)
            {
                this.$ctor$5(($.$firstOf(options, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("options") })).Name, options.Version, options.Tags, options.TelemetrySchemaUrl);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ name, /*string?*/ version, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*string?*/ telemetrySchemaUrl)
            {
                super.$ctor();
                {
                    this.Name = $.$firstOf(name, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("name") });
                    this.Version = version;
                    this.TelemetrySchemaUrl = telemetrySchemaUrl;
                    if (!(tags === null))
                    {
                        /*var*/ let tagList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$3(tags);
                        tagList.Sort$3(new ($.$spc.System.Comparison$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor(this,  (/*left*/ left, /*right*/ right) =>
                        {
                            return $.$spc.System.String.Compare$2(left.Key, right.Key, 4/*StringComparison.Ordinal*/);
                        }, {"r":655361,"p":[{"n":"left","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h},{"n":"right","p":$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object).$h}],"n":"","d":1114156,"h":0,"f":1048578}));
                        this.Tags = tagList.AsReadOnly();
                    }
                    $.$sdd.System.Diagnostics.ActivitySource.s_activeSources.Add(this);
                    $.$sdd.System.Diagnostics.ActivitySource.s_allListeners.EnumWithAction(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.ActivityListener, $.$spc.System.Object))().$ctor(this,  (/*listener*/ listener, /*source*/ source) =>
                    {
                        /*Func<ActivitySource, bool>?*/ let shouldListenTo = listener.ShouldListenTo;
                        if (shouldListenTo !== null)
                        {
                            /*var*/ let activitySource = $.$cast(source, $.$sdd.System.Diagnostics.ActivitySource);
                            if (shouldListenTo.Invoke(activitySource))
                            {
                                activitySource.AddListener(listener);
                            }
                        }
                    }, {"r":65537,"p":[{"n":"listener","p":983084},{"n":"source","p":131073}],"n":"","d":1114156,"h":0,"f":1048578}), this);
                    $.$spc.System.GC.KeepAlive($.$sdd.System.Diagnostics.DiagnosticSourceEventSource.Log);
                }
                return this;
            }
            /*string*/ Name = null;
            /*string?*/ Version = null;
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*string?*/ TelemetrySchemaUrl = null;
            /*bool */ HasListeners()
            {
                /*SynchronizedList<ActivityListener>?*/ let listeners = this._listeners;
                return listeners !== null && listeners.Count > 0;
            }
            /*Activity? */ CreateActivity(/*string*/ name, /*ActivityKind*/ kind)
            {
                return this.CreateActivity$3(name, kind, new $.$sdd.System.Diagnostics.ActivityContext(), null, null, null, new $.$spc.System.DateTimeOffset(), false, 0);
            }
            /*Activity? */ CreateActivity$1(/*string*/ name, /*ActivityKind*/ kind, /*ActivityContext*/ parentContext, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*ActivityIdFormat*/ idFormat)
            {
                return this.CreateActivity$3(name, kind, parentContext, null, tags, links, new $.$spc.System.DateTimeOffset(), false, 0);
            }
            /*Activity? */ CreateActivity$2(/*string*/ name, /*ActivityKind*/ kind, /*string?*/ parentId, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*ActivityIdFormat*/ idFormat)
            {
                return this.CreateActivity$3(name, kind, new $.$sdd.System.Diagnostics.ActivityContext(), parentId, tags, links, new $.$spc.System.DateTimeOffset(), false, 0);
            }
            /*Activity? */ StartActivity(/*string*/ name, /*ActivityKind*/ kind)
            {
                return this.CreateActivity$3(name, kind, new $.$sdd.System.Diagnostics.ActivityContext(), null, null, null, new $.$spc.System.DateTimeOffset(), true, 0);
            }
            /*Activity? */ StartActivity$1(/*string*/ name, /*ActivityKind*/ kind, /*ActivityContext*/ parentContext, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*DateTimeOffset*/ startTime)
            {
                return this.CreateActivity$3(name, kind, parentContext, null, tags, links, startTime, true, 0);
            }
            /*Activity? */ StartActivity$2(/*string*/ name, /*ActivityKind*/ kind, /*string?*/ parentId, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*DateTimeOffset*/ startTime)
            {
                return this.CreateActivity$3(name, kind, new $.$sdd.System.Diagnostics.ActivityContext(), parentId, tags, links, startTime, true, 0);
            }
            /*Activity? */ StartActivity$3(/*ActivityKind*/ kind, /*ActivityContext*/ parentContext, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*DateTimeOffset*/ startTime, /*string*/ name)
            {
                return this.CreateActivity$3(name, kind, parentContext, null, tags, links, startTime, true, 0);
            }
            /*Activity? */ CreateActivity$3(/*string*/ name, /*ActivityKind*/ kind, /*ActivityContext*/ context, /*string?*/ parentId, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*DateTimeOffset*/ startTime, /*bool*/ startIt, /*ActivityIdFormat*/ idFormat)
            {
                /*SynchronizedList<ActivityListener>?*/ let listeners = this._listeners;
                if (listeners === null || listeners.Count === 0)
                {
                    return null;
                }
                /*Activity?*/ let activity = null;
                /*ActivityTagsCollection?*/ let samplerTags;
                /*string?*/ let traceState;
                /*ActivitySamplingResult*/ let samplingResult = 0/*ActivitySamplingResult.None*/;
                if ($.$spc.System.String.op_Inequality(parentId, null))
                {
                    /*ActivityCreationOptions<string>*/ let aco = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$spc.System.String))();
                    /*ActivityCreationOptions<ActivityContext>*/ let acoContext = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext))();
                    aco = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$spc.System.String))().$ctor$2(this, name, parentId, kind, tags, links, idFormat);
                    if (aco.IdFormat === 2/*ActivityIdFormat.W3C*/)
                    {
                        acoContext = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext))().$ctor$2(this, name, aco.GetContext(), kind, tags, links, 2/*ActivityIdFormat.W3C*/);
                    }
                    listeners.EnumWithFunc($.$spc.System.String, new ($.$sdd.System.Diagnostics.ActivitySource.Function$$$($.$sdd.System.Diagnostics.ActivityListener, $.$spc.System.String))().$ctor(this,  (/*ActivityListener*/ listener, /*ActivityCreationOptions<string>*/ data, /*ActivitySamplingResult*/ result, /*ActivityCreationOptions<ActivityContext>*/ dataWithContext) =>
                    {
                        /*SampleActivity<string>?*/ let sampleUsingParentId = listener.SampleUsingParentId;
                        if (sampleUsingParentId !== null)
                        {
                            /*ActivitySamplingResult*/ let sr = sampleUsingParentId.Invoke(data);
                            dataWithContext.$v.SetTraceState(data.$v.TraceState);
                            if (sr > result.$v)
                            {
                                result.$v = sr;
                            }
                        }
                        else if (data.$v.IdFormat === 2/*ActivityIdFormat.W3C*/)
                        {
                            /*SampleActivity<ActivityContext>?*/ let sample = listener.Sample;
                            if (sample !== null)
                            {
                                /*ActivitySamplingResult*/ let sr = sample.Invoke(dataWithContext);
                                data.$v.SetTraceState(dataWithContext.$v.TraceState);
                                if (sr > result.$v)
                                {
                                    result.$v = sr;
                                }
                            }
                        }
                    }, {"r":65537,"p":[{"n":"listener","p":983084},{"n":"data","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$spc.System.String).$h,"f":4},{"n":"result","p":1048620,"f":4},{"n":"dataWithContext","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":1114156,"h":0,"f":1048578}), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$spc.System.String), () => aco, ($v) => aco = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivitySamplingResult, () => samplingResult, ($v) => samplingResult = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext), () => acoContext, ($v) => acoContext = $v, null));
                    if ($.$sdd.System.Diagnostics.ActivityContext.op_Equality(context, new $.$sdd.System.Diagnostics.ActivityContext()))
                    {
                        if ($.$sdd.System.Diagnostics.ActivityContext.op_Inequality(aco.GetContext(), new $.$sdd.System.Diagnostics.ActivityContext()))
                        {
                            context = aco.GetContext();
                            parentId = null;
                        }
                        else if ($.$sdd.System.Diagnostics.ActivityContext.op_Inequality(acoContext.GetContext(), new $.$sdd.System.Diagnostics.ActivityContext()))
                        {
                            context = acoContext.GetContext();
                            parentId = null;
                        }
                    }
                    samplerTags = aco.GetSamplingTags();
                    /*ActivityTagsCollection?*/ let atc = acoContext.GetSamplingTags();
                    if (atc !== null)
                    {
                        if (samplerTags === null)
                        {
                            samplerTags = atc;
                        }
                        else 
                        {
                            var $en5 = atc.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var tag = $en5.Current;
                                {
                                    samplerTags.Add$1(tag);
                                }
                            }
                        }
                    }
                    idFormat = aco.IdFormat;
                    traceState = aco.TraceState;
                }
                else 
                {
                    /*bool*/ let useCurrentActivityContext = $.$sdd.System.Diagnostics.ActivityContext.op_Equality(context, new $.$sdd.System.Diagnostics.ActivityContext()) && $.$sdd.System.Diagnostics.Activity.Current !== null;
                    /*var*/ let aco = new ($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext))().$ctor$2(this, name, useCurrentActivityContext ? $.$sdd.System.Diagnostics.Activity.Current.Context : context, kind, tags, links, idFormat);
                    listeners.EnumWithFunc($.$sdd.System.Diagnostics.ActivityContext, new ($.$sdd.System.Diagnostics.ActivitySource.Function$$$($.$sdd.System.Diagnostics.ActivityListener, $.$sdd.System.Diagnostics.ActivityContext))().$ctor(this,  (/*ActivityListener*/ listener, /*ActivityCreationOptions<ActivityContext>*/ data, /*ActivitySamplingResult*/ result, /*ActivityCreationOptions<ActivityContext>*/ unused) =>
                    {
                        /*SampleActivity<ActivityContext>?*/ let sample = listener.Sample;
                        if (sample !== null)
                        {
                            /*ActivitySamplingResult*/ let dr = sample.Invoke(data);
                            if (dr > result.$v)
                            {
                                result.$v = dr;
                            }
                        }
                    }, {"r":65537,"p":[{"n":"listener","p":983084},{"n":"data","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4},{"n":"result","p":1048620,"f":4},{"n":"unused","p":$.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext).$h,"f":4}],"n":"","d":1114156,"h":0,"f":1048578}), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext), () => aco, ($v) => aco = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivitySamplingResult, () => samplingResult, ($v) => samplingResult = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityCreationOptions$$($.$sdd.System.Diagnostics.ActivityContext), () => aco, ($v) => aco = $v, null));
                    if (!useCurrentActivityContext)
                    {
                        context = aco.GetContext();
                    }
                    samplerTags = aco.GetSamplingTags();
                    idFormat = aco.IdFormat;
                    traceState = aco.TraceState;
                }
                if (samplingResult !== 0/*ActivitySamplingResult.None*/)
                {
                    activity = $.$sdd.System.Diagnostics.Activity.Create(this, name, kind, parentId, context, tags, links, startTime, samplerTags, samplingResult, startIt, idFormat, traceState);
                }
                return activity;
            }
            /*void */ Dispose()
            {
                this._listeners = null;
                $.$sdd.System.Diagnostics.ActivitySource.s_activeSources.Remove(this);
            }
            static /*void */ AddActivityListener(/*ActivityListener*/ listener)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(listener, "listener");
                if ($.$sdd.System.Diagnostics.ActivitySource.s_allListeners.AddIfNotExist(listener))
                {
                    $.$sdd.System.Diagnostics.ActivitySource.s_activeSources.EnumWithAction(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.ActivitySource, $.$spc.System.Object))().$ctor(this,  (/*source*/ source, /*obj*/ obj) =>
                    {
                        /*var*/ let shouldListenTo = ($.$cast(obj, $.$sdd.System.Diagnostics.ActivityListener)).ShouldListenTo;
                        if (shouldListenTo !== null && shouldListenTo.Invoke(source))
                        {
                            source.AddListener($.$cast(obj, $.$sdd.System.Diagnostics.ActivityListener));
                        }
                    }, {"r":65537,"p":[{"n":"source","p":1114156},{"n":"obj","p":131073}],"n":"","d":1114156,"h":0,"f":1048578}), listener);
                }
            }
            static $_Function$$$;
            static Function$$$(T, TParent)
            {
                let $cls = $.$sdd.System.Diagnostics.ActivitySource;
                return ($cls.$_Function$$$ ??= $asm.$ncls("$sdd.System.Diagnostics.ActivitySource.Function<,>", (T, TParent) => $asm.$gt("$sdd.System.Diagnostics.ActivitySource.Function<,>", [T, TParent], ($self) => class Function$$$ extends $.$spc.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*void*/ Invoke(/**/ item, /**/ data, /**/ samplingResult, /**/ dataWithContext)
                    {
                        return this.$nativeFunction.call(this.$target, item, data, samplingResult, dataWithContext);
                    }
                    static $h = 1179692;
                    static $g = 2;
                    static $f = 0b10000000011000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":66191361,"r":2,"d":1114156,"h":this.$h}; }
                    static get $b() { return $.$spc.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.Diagnostics.ActivitySource.Function<${T?.$fullName},${TParent?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Function$$$ = $v))(T, TParent);
            }
            /*void */ AddListener(/*ActivityListener*/ listener)
            {
                if (this._listeners === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.SynchronizedList$$($.$sdd.System.Diagnostics.ActivityListener), $.$ref(() => this._listeners, ($v) => this._listeners = $v, $.$sdd.System.Diagnostics.SynchronizedList$$($.$sdd.System.Diagnostics.ActivityListener)), new ($.$sdd.System.Diagnostics.SynchronizedList$$($.$sdd.System.Diagnostics.ActivityListener))().$ctor$1(), null);
                }
                this._listeners.AddIfNotExist(listener);
            }
            static /*void */ DetachListener(/*ActivityListener*/ listener)
            {
                $.$sdd.System.Diagnostics.ActivitySource.s_allListeners.Remove(listener);
                $.$sdd.System.Diagnostics.ActivitySource.s_activeSources.EnumWithAction(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.ActivitySource, $.$spc.System.Object))().$ctor(this,  (/*source*/ source, /*obj*/ obj) =>
                {
                    return (source._listeners?.Remove($.$cast(obj, $.$sdd.System.Diagnostics.ActivityListener)) ?? null);
                }, {"r":65537,"p":[{"n":"source","p":1114156},{"n":"obj","p":131073}],"n":"","d":1114156,"h":0,"f":1048578}), listener);
            }
            /*void */ NotifyActivityStart(/*Activity*/ activity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(activity !== null, "activity != null");
                /*SynchronizedList<ActivityListener>?*/ let listeners = this._listeners;
                if (listeners !== null && listeners.Count > 0)
                {
                    listeners.EnumWithAction(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.ActivityListener, $.$spc.System.Object))().$ctor(this,  (/*listener*/ listener, /*obj*/ obj) =>
                    {
                        return (listener.ActivityStarted?.Invoke($.$cast(obj, $.$sdd.System.Diagnostics.Activity)) ?? null);
                    }, {"r":65537,"p":[{"n":"listener","p":983084},{"n":"obj","p":131073}],"n":"","d":1114156,"h":0,"f":1048578}), activity);
                }
            }
            /*void */ NotifyActivityStop(/*Activity*/ activity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(activity !== null, "activity != null");
                /*SynchronizedList<ActivityListener>?*/ let listeners = this._listeners;
                if (listeners !== null && listeners.Count > 0)
                {
                    listeners.EnumWithAction(new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.ActivityListener, $.$spc.System.Object))().$ctor(this,  (/*listener*/ listener, /*obj*/ obj) =>
                    {
                        return (listener.ActivityStopped?.Invoke($.$cast(obj, $.$sdd.System.Diagnostics.Activity)) ?? null);
                    }, {"r":65537,"p":[{"n":"listener","p":983084},{"n":"obj","p":131073}],"n":"","d":1114156,"h":0,"f":1048578}), activity);
                }
            }
            /*void */ NotifyActivityAddException(/*Activity*/ activity, /*Exception*/ exception, /*ref TagList*/ tags)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(activity !== null, "activity != null");
                /*SynchronizedList<ActivityListener>?*/ let listeners = this._listeners;
                if (listeners !== null && listeners.Count > 0)
                {
                    listeners.EnumWithExceptionNotification(activity, exception, tags);
                }
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_activeSources = new ($.$sdd.System.Diagnostics.SynchronizedList$$($.$sdd.System.Diagnostics.ActivitySource))().$ctor$1();
                }
                {
                    this.s_allListeners = new ($.$sdd.System.Diagnostics.SynchronizedList$$($.$sdd.System.Diagnostics.ActivityListener))().$ctor$1();
                }
            }
            static $h = 1114156;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1114156}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ActivitySource`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagLinkedList<>", (T) => $asm.$gt("$sdd.System.Diagnostics.DiagLinkedList<>", [T], ($self) => class DiagLinkedList$$ extends $.$spc.System.Object
        {
            /*DiagNode<T>?*/ _first = null;
            /*DiagNode<T>?*/ _last = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*T*/ firstValue)
            {
                super.$ctor();
                this._last = this._first = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(firstValue);
                return this;
            }
            $ctor$3(/*IEnumerator<T>*/ e)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(e === null), "e is not null");
                    this._last = this._first = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        this._last.Next = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(e.System$Collections$Generic$IEnumerator$$$Current);
                        this._last = this._last.Next;
                    }
                }
                return this;
            }
            /*DiagNode<T>? */ get First()
            {
                return this._first;
            }
            /*void */ Clear()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this._first = this._last = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*void */ UnsafeAdd(/*DiagNode<T>*/ newNode)
            {
                if (this._first === null)
                {
                    this._first = this._last = newNode;
                    return;
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._first === null), "_first is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._last === null), "_last is not null");
                this._last.Next = newNode;
                this._last = newNode;
            }
            /*void */ Add(/*T*/ value)
            {
                /*DiagNode<T>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(value);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this.UnsafeAdd(newNode);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*bool */ AddIfNotExist(/*T*/ value, /*Func<T, T, bool>*/ compare)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*DiagNode<T>?*/ let current = this._first;
                        while(!(current === null))
                        {
                            if (compare.Invoke(value, current.Value))
                            {
                                return false;
                            }
                            current = current.Next;
                        }
                        /*DiagNode<T>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(value);
                        this.UnsafeAdd(newNode);
                        return true;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*T? */ Remove(/*T*/ value, /*Func<T, T, bool>*/ compare)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*DiagNode<T>?*/ let previous = this._first;
                        if (previous === null)
                        {
                            return $.$default(T);
                        }
                        if (compare.Invoke(previous.Value, value))
                        {
                            this._first = previous.Next;
                            if (this._first === null)
                            {
                                this._last = null;
                            }
                            return previous.Value;
                        }
                        /*DiagNode<T>?*/ let current = previous.Next;
                        while(!(current === null))
                        {
                            if (compare.Invoke(current.Value, value))
                            {
                                previous.Next = current.Next;
                                if ($.$spc.System.Object.ReferenceEquals(this._last, current))
                                {
                                    this._last = previous;
                                }
                                return current.Value;
                            }
                            previous = current;
                            current = current.Next;
                        }
                        return $.$default(T);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*void */ AddFront(/*T*/ value)
            {
                /*DiagNode<T>*/ let newNode = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1(value);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        newNode.Next = this._first;
                        this._first = newNode;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*DiagEnumerator<T> */ GetEnumerator()
            {
                return new ($.$sdd.System.Diagnostics.DiagEnumerator$$(T))().$ctor$2(this._first);
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            static /*void */ ActivityLinkToString(/*ref ActivityLink*/ al, /*ref ValueStringBuilder*/ vsb)
            {
                /*ActivityContext*/ let ac = al.$v.Context;
                vsb.$v.Append$1("(");
                vsb.$v.Append$1(ac.TraceId.ToHexString());
                vsb.$v.Append$1(",\u200B");
                vsb.$v.Append$1(ac.SpanId.ToHexString());
                vsb.$v.Append$1(",\u200B");
                vsb.$v.Append$1($.$spc.System.Enum.ToStringT($.$sdd.System.Diagnostics.ActivityTraceFlags, $.$spc.System.UInt32, ac.TraceFlags));
                vsb.$v.Append$1(",\u200B");
                vsb.$v.Append$1(ac.TraceState ?? "null");
                vsb.$v.Append$1(",\u200B");
                vsb.$v.Append$1(ac.IsRemote ? "true" : "false");
                if (!(al.$v.Tags === null))
                {
                    vsb.$v.Append$1(",\u200B[");
                    /*string*/ let sep = "";
                    var $en3 = al.$v.EnumerateTagObjects().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current.$v;
                        {
                            vsb.$v.Append$1(sep);
                            vsb.$v.Append$1(kvp.Key);
                            vsb.$v.Append$1(":\u200B");
                            const $t1 = () => kvp.Value;
                            vsb.$v.Append$1($.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t)) ?? "null");
                            sep = ",\u200B";
                        }
                    }
                    vsb.$v.Append$1("]");
                }
                vsb.$v.Append$1(")");
            }
            static /*void */ ActivityEventToString(/*ref ActivityEvent*/ ae, /*ref ValueStringBuilder*/ vsb)
            {
                vsb.$v.Append$1("(");
                vsb.$v.Append$1(ae.$v.Name);
                vsb.$v.Append$1(",\u200B");
                vsb.$v.Append$1(ae.$v.Timestamp.ToString$1("o"));
                if (!(ae.$v.Tags === null))
                {
                    vsb.$v.Append$1(",\u200B[");
                    /*string*/ let sep = "";
                    var $en3 = ae.$v.EnumerateTagObjects().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var kvp = $en3.Current.$v;
                        {
                            vsb.$v.Append$1(sep);
                            vsb.$v.Append$1(kvp.Key);
                            vsb.$v.Append$1(":\u200B");
                            const $t1 = () => kvp.Value;
                            vsb.$v.Append$1($.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t)) ?? "null");
                            sep = ",\u200B";
                        }
                    }
                    vsb.$v.Append$1("]");
                }
                vsb.$v.Append$1(")");
            }
            static/*conventional*/ /*string */ ToString()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*DiagNode<T>?*/ let current = this._first;
                        if (current === null)
                        {
                            return "[]";
                        }
                        /*var*/ let vsb = new $.$sdd.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null));
                        vsb.Append$1("[");
                        if ($.$spc.System.Type.op_Equality$1(T.$type, $.$sdd.System.Diagnostics.ActivityLink.$type))
                        {
                            while(!(current === null))
                            {
                                /*ActivityLink*/ let al = $.$cast($.$box(current.Value, T), $.$sdd.System.Diagnostics.ActivityLink);
                                $.$sdd.System.Diagnostics.DiagLinkedList$$(T).ActivityLinkToString($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityLink, () => al, ($v) => al = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null));
                                current = current.Next;
                                if (!(current === null))
                                {
                                    vsb.Append$1(",\u200B");
                                }
                            }
                        }
                        else if ($.$spc.System.Type.op_Equality$1(T.$type, $.$sdd.System.Diagnostics.ActivityEvent.$type))
                        {
                            while(!(current === null))
                            {
                                /*ActivityEvent*/ let ae = $.$cast($.$box(current.Value, T), $.$sdd.System.Diagnostics.ActivityEvent);
                                $.$sdd.System.Diagnostics.DiagLinkedList$$(T).ActivityEventToString($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityEvent, () => ae, ($v) => ae = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Text.ValueStringBuilder, () => vsb, ($v) => vsb = $v, null));
                                current = current.Next;
                                if (!(current === null))
                                {
                                    vsb.Append$1(",\u200B");
                                }
                            }
                        }
                        else 
                        {
                            while(!(current === null))
                            {
                                const $t1 = () => current.Value;
                                vsb.Append$1($.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t)) ?? "null");
                                current = current.Next;
                                if (!(current === null))
                                {
                                    vsb.Append$1(",\u200B");
                                }
                            }
                        }
                        vsb.Append$1("]");
                        return $.$sdd.System.Text.ValueStringBuilder.ToString.call(vsb);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdd.System.Diagnostics.DiagLinkedList$$(T).ToString.apply(this, arguments); }
            static $h = 1835052;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.DiagLinkedList<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sdd.System.Diagnostics.ActivityCreationOptions<>", (T) => $asm.$gt("$sdd.System.Diagnostics.ActivityCreationOptions<>", [T], ($self) => class ActivityCreationOptions$$ extends $.$spc.System.ValueType
        {
            /*ActivityTagsCollection?*/  get _samplerTags() { return this.$getField(0, 4); }
            /*ActivityTagsCollection?*/  set _samplerTags(value) { this.$setField(0, 4, value); }
            /*ActivityContext*/  get _context() { return this.$getField(4, 17); }
            /*ActivityContext*/  set _context(value) { this.$setField(4, 17, value); }
            /*string?*/  get _traceState() { return this.$getField(21, 4); }
            /*string?*/  set _traceState(value) { this.$setField(21, 4, value); }
            $ctor$2(/*ActivitySource*/ source, /*string*/ name, /*T*/ parent, /*ActivityKind*/ kind, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*IEnumerable<ActivityLink>?*/ links, /*ActivityIdFormat*/ idFormat)
            {
                super.$ctor$1();
                {
                    this.Source = source;
                    this.Name = name;
                    this.Kind = kind;
                    this.Parent = parent;
                    this.Tags = tags;
                    this.Links = links;
                    this.IdFormat = idFormat;
                    if (this.IdFormat === 0/*ActivityIdFormat.Unknown*/ && $.$sdd.System.Diagnostics.Activity.ForceDefaultIdFormat)
                    {
                        this.IdFormat = $.$sdd.System.Diagnostics.Activity.DefaultIdFormat;
                    }
                    this._samplerTags = null;
                    this._traceState = null;
                    let ac;
                    let p;
                    if ($.$is(parent, $.$sdd.System.Diagnostics.ActivityContext, { set $v(v){ ac = v; } }) && $.$sdd.System.Diagnostics.ActivityContext.op_Inequality(ac, new $.$sdd.System.Diagnostics.ActivityContext()))
                    {
                        this._context = ac;
                        if (this.IdFormat === 0/*ActivityIdFormat.Unknown*/)
                        {
                            this.IdFormat = 2/*ActivityIdFormat.W3C*/;
                        }
                        this._traceState = ac.TraceState;
                    }
                    else if ($.$is(parent, $.$spc.System.String, { set $v(v){ p = v; } }))
                    {
                        if (this.IdFormat !== 1/*ActivityIdFormat.Hierarchical*/)
                        {
                            if ($.$sdd.System.Diagnostics.ActivityContext.TryParse$1(p, null, $.$ref(() => this._context, ($v) => this._context = $v, $.$sdd.System.Diagnostics.ActivityContext)))
                            {
                                this.IdFormat = 2/*ActivityIdFormat.W3C*/;
                            }
                            if (this.IdFormat === 0/*ActivityIdFormat.Unknown*/)
                            {
                                this.IdFormat = 1/*ActivityIdFormat.Hierarchical*/;
                            }
                        }
                        else 
                        {
                            this._context = new $.$sdd.System.Diagnostics.ActivityContext();
                        }
                    }
                    else 
                    {
                        this._context = new $.$sdd.System.Diagnostics.ActivityContext();
                        if (this.IdFormat === 0/*ActivityIdFormat.Unknown*/)
                        {
                            this.IdFormat = $.$sdd.System.Diagnostics.Activity.Current !== null ? $.$sdd.System.Diagnostics.Activity.Current.IdFormat : $.$sdd.System.Diagnostics.Activity.DefaultIdFormat;
                        }
                    }
                }
                return this;
            }
            /*ActivitySource*/ Source = null;
            /*string*/ Name = null;
            /*ActivityKind*/ Kind = 0;
            /*T*/ Parent = $.$default(T);
            /*IEnumerable<KeyValuePair<string, object?>>?*/ Tags = null;
            /*IEnumerable<ActivityLink>?*/ Links = null;
            /*ActivityTagsCollection */ get SamplingTags()
            {
                if (this._samplerTags === null)
                {
                    $.$ref(() => this._samplerTags, undefined, $.$sdd.System.Diagnostics.ActivityTagsCollection).$v = new $.$sdd.System.Diagnostics.ActivityTagsCollection().$ctor$1();
                }
                return this._samplerTags;
            }
            /*ActivityTraceId */ get TraceId()
            {
                if ($.$is(this.Parent, $.$sdd.System.Diagnostics.ActivityContext) && this.IdFormat === 2/*ActivityIdFormat.W3C*/ && $.$sdd.System.Diagnostics.ActivityContext.op_Equality(this._context, new $.$sdd.System.Diagnostics.ActivityContext()))
                {
                    /*Func<ActivityTraceId>?*/ let traceIdGenerator = $.$sdd.System.Diagnostics.Activity.TraceIdGenerator;
                    /*ActivityTraceId*/ let id = traceIdGenerator === null ? $.$sdd.System.Diagnostics.ActivityTraceId.CreateRandom() : traceIdGenerator.Invoke();
                    $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.ActivityContext, () => this._context, ($v) => this._context = $v, null).$v = new $.$sdd.System.Diagnostics.ActivityContext().$ctor$2(id, new $.$sdd.System.Diagnostics.ActivitySpanId(), 0/*ActivityTraceFlags.None*/, null, false);
                }
                return this._context.TraceId;
            }
            /*string? */ get TraceState()
            {
                return this._traceState;
            }
            /*string? */ set TraceState(value)
            {
                this._traceState = value;
            }
            /*void */ SetTraceState(/*string?*/ traceState)
            {
                return $.$ref(() => this._traceState, undefined, $.$spc.System.String).$v = traceState;
            }
            /*ActivityIdFormat*/ IdFormat = 0;
            /*ActivityTagsCollection? */ GetSamplingTags()
            {
                return this._samplerTags;
            }
            /*ActivityContext */ GetContext()
            {
                return this._context;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._samplerTags = this._samplerTags;
                copy._context = this._context.Clone();
                copy._traceState = this._traceState;
                copy.Source = this.Source;
                copy.Name = this.Name;
                copy.Kind = this.Kind;
                copy.Parent = this.Parent;
                copy.Tags = this.Tags;
                copy.Links = this.Links;
                copy.IdFormat = this.IdFormat;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._samplerTags = null;
                this._context = $.$default($.$sdd.System.Diagnostics.ActivityContext);
                this._traceState = null;
                this.Kind = 0;
                this.IdFormat = 0;
            }
            static $h = 655404;
            static $g = 1;
            static $z = 53;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.ActivityCreationOptions<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sdd.System.Diagnostics.ActivityEvent", ($self) => class ActivityEvent extends $.$spc.System.ValueType
        {
            /*IEnumerable<KeyValuePair<string, object?>>*/ static s_emptyTags = null;
            /*Activity.TagsLinkedList?*/  get _tags() { return this.$getField(0, 4); }
            /*Activity.TagsLinkedList?*/  set _tags(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string*/ name)
            {
                this.$ctor$3(name, new $.$spc.System.DateTimeOffset(), null);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*DateTimeOffset*/ timestamp, /*ActivityTagsCollection?*/ tags)
            {
                this.$ctor$5(name, timestamp, tags, tags === null ? 0 : tags.Count);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ name, /*DateTimeOffset*/ timestamp, /*ref TagList*/ tags)
            {
                this.$ctor$5(name, timestamp, tags.$v, tags.$v.Count);
                {
                }
                return this;
            }
            $ctor$5(/*string*/ name, /*DateTimeOffset*/ timestamp, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*int*/ tagsCount)
            {
                super.$ctor$1();
                {
                    this.Name = name ?? $.$spc.System.String.Empty;
                    this.Timestamp = $.$spc.System.DateTimeOffset.op_Inequality(timestamp, new $.$spc.System.DateTimeOffset()) ? timestamp : $.$spc.System.DateTimeOffset.UtcNow;
                    this._tags = tagsCount > 0 ? new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$3(tags) : null;
                }
                return this;
            }
            /*string*/ Name = null;
            /*DateTimeOffset*/ Timestamp;
            /*IEnumerable<KeyValuePair<string, object?>> */ get Tags()
            {
                return this._tags ?? $.$sdd.System.Diagnostics.ActivityEvent.s_emptyTags;
            }
            /*Activity.Enumerator<KeyValuePair<string, object?>> */ EnumerateTagObjects()
            {
                return new ($.$sdd.System.Diagnostics.Activity.Enumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$2((this._tags?.First ?? null));
            }
            //default value type constructor
            $ctor$6()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._tags = this._tags;
                copy.Name = this.Name;
                copy.Timestamp = this.Timestamp.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tags = null;
                this.Timestamp = $.$default($.$spc.System.DateTimeOffset);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_emptyTags = $.$spc.System.Array.Empty($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object));
                }
            }
            static $h = 720940;
            static $z = 13;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":720940}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.ActivityEvent`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.NoOutputPropagator", ($self) => class NoOutputPropagator extends $.$sdd.System.Diagnostics.DistributedContextPropagator
        {
            /*DistributedContextPropagator*/ static Instance = null;
            /*IReadOnlyCollection<string>*/ Fields = null;
            /*void */ Inject(/*Activity?*/ activity, /*object?*/ carrier, /*PropagatorSetterCallback?*/ setter)
            {
            }
            /*void */ ExtractTraceIdAndState(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter, /*out string?*/ traceId, /*out string?*/ traceState)
            {
                return $.$sdd.System.Diagnostics.LegacyPropagator.Instance.ExtractTraceIdAndState(carrier, getter, traceId, traceState);
            }
            /*IEnumerable<KeyValuePair<string, string?>>? */ ExtractBaggage(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter)
            {
                return $.$sdd.System.Diagnostics.LegacyPropagator.Instance.ExtractBaggage(carrier, getter);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Fields = $.$sdd.System.Diagnostics.LegacyPropagator.Instance.Fields;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sdd.System.Diagnostics.NoOutputPropagator().$ctor$2();
                }
            }
            static $h = 8388652;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2490412,"h":8388652}; }
            static get $b() { return $.$sdd.System.Diagnostics.DistributedContextPropagator; }
            static get $fullName() { return `System.Diagnostics.NoOutputPropagator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.PassThroughPropagator", ($self) => class PassThroughPropagator extends $.$sdd.System.Diagnostics.DistributedContextPropagator
        {
            /*DistributedContextPropagator*/ static Instance = null;
            /*IReadOnlyCollection<string>*/ Fields = null;
            /*void */ Inject(/*Activity?*/ activity, /*object?*/ carrier, /*PropagatorSetterCallback?*/ setter)
            {
                if (setter === null)
                {
                    return;
                }
                /*string?*/ let parentId;
                /*string?*/ let traceState;
                /*bool*/ let isW3c;
                /*IEnumerable<KeyValuePair<string, string?>>?*/ let baggage;
                $.$sdd.System.Diagnostics.PassThroughPropagator.GetRootId($.$ref(() => parentId, ($v) => parentId = $v, $.$spc.System.String), $.$ref(() => traceState, ($v) => traceState = $v, $.$spc.System.String), $.$ref(() => isW3c, ($v) => isW3c = $v, $.$spc.System.Boolean), $.$ref(() => baggage, ($v) => baggage = $v, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))));
                if (parentId === null)
                {
                    return;
                }
                setter.Invoke(carrier, isW3c ? "traceparent"/*TraceParent*/ : "Request-Id"/*RequestId*/, parentId);
                if (!$.$spc.System.String.IsNullOrEmpty(traceState))
                {
                    setter.Invoke(carrier, "tracestate"/*TraceState*/, traceState);
                }
                if (!(baggage === null))
                {
                    $.$sdd.System.Diagnostics.DistributedContextPropagator.InjectBaggage(carrier, baggage, setter);
                }
            }
            /*void */ ExtractTraceIdAndState(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter, /*out string?*/ traceId, /*out string?*/ traceState)
            {
                return $.$sdd.System.Diagnostics.LegacyPropagator.Instance.ExtractTraceIdAndState(carrier, getter, traceId, traceState);
            }
            /*IEnumerable<KeyValuePair<string, string?>>? */ ExtractBaggage(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter)
            {
                return $.$sdd.System.Diagnostics.LegacyPropagator.Instance.ExtractBaggage(carrier, getter);
            }
            static /*void */ GetRootId(/*out string?*/ parentId, /*out string?*/ traceState, /*out bool*/ isW3c, /*out IEnumerable<KeyValuePair<string, string?>>?*/ baggage)
            {
                /*Activity?*/ let activity = $.$sdd.System.Diagnostics.Activity.Current;
                let parent;
                while($.$is((activity?.Parent ?? null), $.$sdd.System.Diagnostics.Activity, { set $v(v){ parent = v; } }))
                {
                    activity = parent;
                }
                traceState.$v = (activity?.TraceStateString ?? null);
                parentId.$v = (activity?.ParentId ?? null) ?? (activity?.Id ?? null);
                isW3c.$v = !(parentId.$v === null) ? $.$sdd.System.Diagnostics.Activity.TryConvertIdToContext(parentId.$v, traceState.$v, false, $.$discardRef()) : false;
                baggage.$v = (activity?.Baggage ?? null);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Fields = $.$sdd.System.Diagnostics.LegacyPropagator.Instance.Fields;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sdd.System.Diagnostics.PassThroughPropagator().$ctor$2();
                }
            }
            static $h = 8454188;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2490412,"h":8454188}; }
            static get $b() { return $.$sdd.System.Diagnostics.DistributedContextPropagator; }
            static get $fullName() { return `System.Diagnostics.PassThroughPropagator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.LegacyPropagator", ($self) => class LegacyPropagator extends $.$sdd.System.Diagnostics.DistributedContextPropagator
        {
            /*DistributedContextPropagator*/ static Instance = null;
            /*IReadOnlyCollection<string>*/ Fields = null;
            /*void */ Inject(/*Activity?*/ activity, /*object?*/ carrier, /*PropagatorSetterCallback?*/ setter)
            {
                if (activity === null || setter === null)
                {
                    return;
                }
                /*string?*/ let id = activity.Id;
                if (id === null)
                {
                    return;
                }
                if (activity.IdFormat === 2/*ActivityIdFormat.W3C*/)
                {
                    setter.Invoke(carrier, "traceparent"/*TraceParent*/, id);
                    if (!$.$spc.System.String.IsNullOrEmpty(activity.TraceStateString))
                    {
                        setter.Invoke(carrier, "tracestate"/*TraceState*/, activity.TraceStateString);
                    }
                }
                else 
                {
                    setter.Invoke(carrier, "Request-Id"/*RequestId*/, id);
                }
                $.$sdd.System.Diagnostics.DistributedContextPropagator.InjectBaggage(carrier, activity.Baggage, setter);
            }
            /*void */ ExtractTraceIdAndState(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter, /*out string?*/ traceId, /*out string?*/ traceState)
            {
                if (getter === null)
                {
                    traceId.$v = null;
                    traceState.$v = null;
                    return;
                }
                getter.Invoke(carrier, "traceparent"/*TraceParent*/, traceId, $.$discardRef());
                if (traceId.$v === null)
                {
                    getter.Invoke(carrier, "Request-Id"/*RequestId*/, traceId, $.$discardRef());
                }
                getter.Invoke(carrier, "tracestate"/*TraceState*/, traceState, $.$discardRef());
            }
            /*IEnumerable<KeyValuePair<string, string?>>? */ ExtractBaggage(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter)
            {
                if (getter === null)
                {
                    return null;
                }
                /*string?*/ let theBaggage;
                getter.Invoke(carrier, "baggage"/*Baggage*/, $.$ref(() => theBaggage, ($v) => theBaggage = $v, $.$spc.System.String), $.$discardRef());
                /*IEnumerable<KeyValuePair<string, string?>>?*/ let baggage = null;
                if (theBaggage === null || !$.$sdd.System.Diagnostics.LegacyPropagator.TryExtractBaggage(theBaggage, $.$ref(() => baggage, ($v) => baggage = $v, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))))
                {
                    getter.Invoke(carrier, "Correlation-Context"/*CorrelationContext*/, $.$ref(() => theBaggage, ($v) => theBaggage = $v, $.$spc.System.String), $.$discardRef());
                    if (!(theBaggage === null))
                    {
                        $.$sdd.System.Diagnostics.LegacyPropagator.TryExtractBaggage(theBaggage, $.$ref(() => baggage, ($v) => baggage = $v, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))));
                    }
                }
                return baggage;
            }
            static /*bool */ TryExtractBaggage(/*string*/ baggageString, /*out IEnumerable<KeyValuePair<string, string?>>?*/ baggage)
            {
                baggage.$v = null;
                /*List<KeyValuePair<string, string?>>?*/ let baggageList = null;
                if ($.$spc.System.String.IsNullOrEmpty(baggageString))
                {
                    return true;
                }
                /*int*/ let currentIndex = 0;
                do
                {
                    while(currentIndex < baggageString.length && ($.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /* */ 32 || $.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /*\t*/ 9))
                    {
                        currentIndex++;
                    }
                    if (currentIndex >= baggageString.length)
                    {
                        break;
                    }
                    /*int*/ let keyStart = currentIndex;
                    while(currentIndex < baggageString.length && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /* */ 32 && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*\t*/ 9 && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*=*/ 61)
                    {
                        currentIndex++;
                    }
                    if (currentIndex >= baggageString.length)
                    {
                        break;
                    }
                    /*int*/ let keyEnd = currentIndex;
                    if ($.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*=*/ 61)
                    {
                        while(currentIndex < baggageString.length && ($.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /* */ 32 || $.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /*\t*/ 9))
                        {
                            currentIndex++;
                        }
                        if (currentIndex >= baggageString.length)
                        {
                            break;
                        }
                        if ($.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*=*/ 61)
                        {
                            break;
                        }
                    }
                    currentIndex++;
                    while(currentIndex < baggageString.length && ($.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /* */ 32 || $.$spc.System.String.get_Chars.call(baggageString, currentIndex) === /*\t*/ 9))
                    {
                        currentIndex++;
                    }
                    if (currentIndex >= baggageString.length)
                    {
                        break;
                    }
                    /*int*/ let valueStart = currentIndex;
                    while(currentIndex < baggageString.length && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /* */ 32 && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*\t*/ 9 && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*,*/ 44 && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*;*/ 59)
                    {
                        currentIndex++;
                    }
                    if (keyStart < keyEnd && valueStart < currentIndex)
                    {
                        baggageList ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1();
                        baggageList.Insert(0, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2($.$spc.System.String.Trim$2.call($.$spc.System.Net.WebUtility.UrlDecode($.$spc.System.String.Substring$1.call(baggageString, keyStart, ((keyEnd - keyStart) | 0))), $.$sdd.System.Diagnostics.DistributedContextPropagator.s_trimmingSpaceCharacters), $.$spc.System.String.Trim$2.call($.$spc.System.Net.WebUtility.UrlDecode($.$spc.System.String.Substring$1.call(baggageString, valueStart, ((currentIndex - valueStart) | 0))), $.$sdd.System.Diagnostics.DistributedContextPropagator.s_trimmingSpaceCharacters)));
                    }
                    while(currentIndex < baggageString.length && $.$spc.System.String.get_Chars.call(baggageString, currentIndex) !== /*,*/ 44)
                    {
                        currentIndex++;
                    }
                    currentIndex++;
                }
                while(currentIndex < baggageString.length);
                baggage.$v = baggageList;
                return baggageList !== null;
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Fields = new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$spc.System.String))().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["traceparent"/*TraceParent*/, "Request-Id"/*RequestId*/, "tracestate"/*TraceState*/, "baggage"/*Baggage*/, "Correlation-Context"/*CorrelationContext*/], null, null));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sdd.System.Diagnostics.LegacyPropagator().$ctor$2();
                }
            }
            static $h = 4194348;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2490412,"h":4194348}; }
            static get $b() { return $.$sdd.System.Diagnostics.DistributedContextPropagator; }
            static get $fullName() { return `System.Diagnostics.LegacyPropagator`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.QuantileValue", ($self) => class QuantileValue extends $.$spc.System.ValueType
        {
            $ctor$2(/*double*/ quantile, /*double*/ value)
            {
                super.$ctor$1();
                {
                    this.Quantile = quantile;
                    this.Value = value;
                }
                return this;
            }
            /*double*/ Quantile = 0;
            /*double*/ Value = 0;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Quantile = this.Quantile;
                copy.Value = this.Value;
                return copy;
            }
            static $h = 7798828;
            static $z = 16;
            static $f = 0b10000000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7798828}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.Metrics.QuantileValue`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator", ($self) => class Base2ExponentialHistogramAggregator extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*int*/ static MinScale = -11;
            /*int*/ static MaxScale = 20;
            /*int*/ static MinBuckets = 2;
            /*long*/ static FractionMask = 0xFFFFFFFFFFFFFn;
            /*long*/ static ExponentMask = 0x7FF0000000000000n;
            /*int*/ static FractionWidth = 52;
            /*int*/ _scale = 0;
            /*double*/ _maxMeasurement = 0;
            /*double*/ _minMeasurement = 0;
            /*double*/ _sum = 0;
            /*long*/ _count = 0n;
            /*bool*/ _reportDeltas = false;
            /*double*/ _scalingFactor = 0;
            $ctor$2(/*int*/ maxBuckets, /*int*/ scale, /*bool*/ reportDeltas)
            {
                super.$ctor$1();
                {
                    if (scale < -11/*MinScale*/ || scale > 20/*MaxScale*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("scale", $.$sdd.System.SR.Format$2($.$sdd.System.SR.InvalidHistogramScale, $.$box(scale, $.$spc.System.Int32), $.$box(-11/*MinScale*/, $.$spc.System.Int32), $.$box(20/*MaxScale*/, $.$spc.System.Int32)));
                    }
                    if (maxBuckets < 2/*MinBuckets*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("maxBuckets", $.$sdd.System.SR.Format$1($.$sdd.System.SR.InvalidHistogramMaxBuckets, $.$box(maxBuckets, $.$spc.System.Int32), $.$box(2/*MinBuckets*/, $.$spc.System.Int32)));
                    }
                    this.Scale = scale;
                    this._reportDeltas = reportDeltas;
                    this._minMeasurement = 1.7976931348623157E+308/*double.MaxValue*/;
                    this._maxMeasurement = -1.7976931348623157E+308/*double.MinValue*/;
                    this.PositiveBuckets = new $.$sdd.System.Diagnostics.Metrics.CircularBufferBuckets().$ctor$1(maxBuckets);
                }
                return this;
            }
            /*CircularBufferBuckets*/ PositiveBuckets = null;
            /*int */ get Scale()
            {
                return this._scale;
            }
            /*int */ set Scale(value)
            {
                this._scale = value;
                this._scalingFactor = $.$spc.System.BitConverter.Int64BitsToDouble(0x71547652B82FEn | (BigInt.asIntN(64, (0x3FFn + BigInt(value)) << BigInt(52/*FractionWidth*/))));
            }
            /*long */ get Count()
            {
                return this._count;
            }
            /*double */ get Sum()
            {
                return this._sum;
            }
            /*double */ get MinMeasurement()
            {
                return this._minMeasurement;
            }
            /*double */ get MaxMeasurement()
            {
                return this._maxMeasurement;
            }
            /*double */ get ScalingFactor()
            {
                return this._scalingFactor;
            }
            /*long*/ ZeroCount = 0n;
            /*IAggregationStatistics */ Collect()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*var*/ let newStats = new $.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramStatistics().$ctor$1(this.Scale, this.ZeroCount, this._sum, this._count, this._minMeasurement, this._maxMeasurement, this.PositiveBuckets.ToArray());
                        if (this._reportDeltas)
                        {
                            this._sum = 0;
                            this._minMeasurement = 1.7976931348623157E+308/*double.MaxValue*/;
                            this._maxMeasurement = -1.7976931348623157E+308/*double.MinValue*/;
                            this.ZeroCount = 0n;
                            this._count = 0n;
                            this.PositiveBuckets.Clear();
                        }
                        return newStats;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*void */ Update(/*double*/ measurement)
            {
                if (!$.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator.IsFinite(measurement))
                {
                    return;
                }
                /*var*/ let c = $.$spc.System.Double.CompareTo$1.call(measurement, 0);
                if (c < 0)
                {
                    return;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this._maxMeasurement = $.$spc.System.Math.Max$2(this._maxMeasurement, measurement);
                        this._minMeasurement = $.$spc.System.Math.Min$2(this._minMeasurement, measurement);
                        this._count++;
                        if (c === 0)
                        {
                            this.ZeroCount++;
                            return;
                        }
                        this._sum += measurement;
                        /*var*/ let index = this.MapToIndex(measurement);
                        /*var*/ let n = this.PositiveBuckets.TryIncrement(index, 1n);
                        if (n === 0)
                        {
                            return;
                        }
                        this.PositiveBuckets.ScaleDown(n);
                        this.Scale -= n;
                        if (this.Scale < -11/*MinScale*/)
                        {
                            this.Scale = -11/*MinScale*/;
                        }
                        else if (this.Scale > 20/*MaxScale*/)
                        {
                            this.Scale = 20/*MaxScale*/;
                        }
                        n = this.PositiveBuckets.TryIncrement(index >> n, 1n);
                        $.$spc.System.Diagnostics.Debug.Assert$1(n === 0, "Increment should always succeed after scale down.");
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            /*int */ MapToIndex(/*double*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator.IsFinite(value), "IEEE-754 +Inf, -Inf and NaN should be filtered out before calling this method.");
                $.$spc.System.Diagnostics.Debug.Assert$1(value !== 0, "IEEE-754 zero values should be handled by ZeroCount.");
                $.$spc.System.Diagnostics.Debug.Assert$1(value > 0, "IEEE-754 negative values should be normalized before calling this method.");
                /*var*/ let bits = $.$spc.System.BitConverter.DoubleToInt64Bits(value);
                /*var*/ let fraction = bits & 4503599627370495n;
                if (this.Scale > 0)
                {
                    if (fraction === 0n)
                    {
                        /*var*/ let exp = $.$cast(((bits & 9218868437227405312n) >> BigInt(52/*FractionWidth*/)), $.$spc.System.Int32);
                        return ((((((exp - 1023) | 0)) << this.Scale) - 1) | 0);
                    }
                    return (($.$cast(Math.ceil(Math.log(value) * this._scalingFactor), $.$spc.System.Int32) - 1) | 0);
                }
                else 
                {
                    /*var*/ let exp = $.$cast(((bits & 9218868437227405312n) >> BigInt(52/*FractionWidth*/)), $.$spc.System.Int32);
                    if (exp === 0)
                    {
                        exp -= (($.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator.LeadingZero64(fraction - 1n) - 12) | 0);
                    }
                    else if (fraction === 0n)
                    {
                        exp--;
                    }
                    return (((exp - 1023) | 0)) >> -this.Scale;
                }
            }
            static /*bool */ IsFinite(/*double*/ value)
            {
                return $.$spc.System.Double.IsFinite(value);
            }
            static /*int */ LeadingZero64(/*long*/ value)
            {
                return $.$spc.System.Numerics.BitOperations.LeadingZeroCount$1($.$cast(value, $.$spc.System.UInt64));
            }
            static $h = 4522028;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":4522028}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator", ($self) => class ExponentialHistogramAggregator extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*int*/ static ExponentArraySize = 4096;
            /*int*/ static ExponentShift = 52;
            /*double*/ static MinRelativeError = 0.0001;
            /*int*/ static PositiveIntAndNan = 2047;
            /*int*/ static NegativeIntAndNan = 4095;
            /*QuantileAggregation*/ _config = null;
            /*int[]?[]*/ _counters = null;
            /*int*/ _count = 0;
            /*double*/ _sum = 0;
            /*int*/ _mantissaMax = 0;
            /*int*/ _mantissaMask = 0;
            /*int*/ _mantissaShift = 0;
            static $_Bucket;
            static get Bucket()
            {
                let $cls = $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator;
                return $cls.$_Bucket ??= $asm.$nstr("$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator.Bucket", ($self) => class Bucket extends $.$spc.System.ValueType
                {
                    $ctor$2(/*double*/ value, /*int*/ count)
                    {
                        super.$ctor$1();
                        {
                            this.Value = value;
                            this.Count = count;
                        }
                        return this;
                    }
                    /*double*/  get Value() { return this.$getField(0, $.$spc.System.Double); }
                    /*double*/  set Value(value) { this.$setField(0, $.$spc.System.Double, value); }
                    /*int*/  get Count() { return this.$getField(8, $.$spc.System.Int32); }
                    /*int*/  set Count(value) { this.$setField(8, $.$spc.System.Int32, value); }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Value = this.Value;
                        copy.Count = this.Count;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Value = 0;
                        this.Count = 0;
                    }
                    static $h = 5046316;
                    static $z = 12;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":4980780,"h":5046316}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Diagnostics.Metrics.ExponentialHistogramAggregator.Bucket`; }
                }, $cls, ($v) => $cls.$_Bucket = $v);
            }
            $ctor$2(/*QuantileAggregation*/ config)
            {
                super.$ctor$1();
                {
                    this._config = config;
                    this._counters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Int32)), null, [4096/*ExponentArraySize*/], null);
                    if (this._config.MaxRelativeError < 0.0001/*MinRelativeError*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$9();
                    }
                    /*int*/ let mantissaBits = (($.$cast(Math.ceil($.$spc.System.Math.Log(1 / this._config.MaxRelativeError, 2)), $.$spc.System.Int32) - 1) | 0);
                    this._mantissaShift = ((52 - mantissaBits) | 0);
                    this._mantissaMax = 1 << mantissaBits;
                    this._mantissaMask = ((this._mantissaMax - 1) | 0);
                }
                return this;
            }
            /*IAggregationStatistics */ Collect()
            {
                /*int[]?[]*/ let counters;
                /*int*/ let count;
                /*double*/ let sum;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        counters = this._counters;
                        count = this._count;
                        sum = this._sum;
                        this._counters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$typeArray($.$spc.System.Int32)), null, [4096/*ExponentArraySize*/], null);
                        this._count = 0;
                        this._sum = 0;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
                /*QuantileValue[]*/ let quantiles = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdd.System.Diagnostics.Metrics.QuantileValue), null, [this._config.Quantiles.length], null);
                /*int*/ let nextQuantileIndex = 0;
                if (nextQuantileIndex === this._config.Quantiles.length)
                {
                    return new $.$sdd.System.Diagnostics.Metrics.HistogramStatistics().$ctor$1(quantiles, count, sum);
                }
                /*int*/ let target = $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator.QuantileToRank($.$spc.System.Array.$ReadT1.call(this._config.Quantiles, nextQuantileIndex), count);
                /*int*/ let cur = 0;
                var $en2 = this.IterateBuckets(counters).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var b = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        cur += b.Count;
                        while(cur > target)
                        {
                            $.$spc.System.Array.$WriteT1.call(quantiles, new $.$sdd.System.Diagnostics.Metrics.QuantileValue().$ctor$2($.$spc.System.Array.$ReadT1.call(this._config.Quantiles, nextQuantileIndex), b.Value), nextQuantileIndex);
                            nextQuantileIndex++;
                            if (nextQuantileIndex === this._config.Quantiles.length)
                            {
                                return new $.$sdd.System.Diagnostics.Metrics.HistogramStatistics().$ctor$1(quantiles, count, sum);
                            }
                            target = $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator.QuantileToRank($.$spc.System.Array.$ReadT1.call(this._config.Quantiles, nextQuantileIndex), count);
                        }
                    }
                }
                $.$spc.System.Diagnostics.Debug.Assert$1(count === 0, "count == 0");
                return new $.$sdd.System.Diagnostics.Metrics.HistogramStatistics().$ctor$1($.$spc.System.Array.Empty($.$sdd.System.Diagnostics.Metrics.QuantileValue), count, sum);
            }
            /*IEnumerable<Bucket> */ IterateBuckets(/*int[]?[]*/ counters)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let LowestNegativeOffset = $.trunc(4096/*ExponentArraySize*/ / 2);
                    for(/*int*/ let exponent = ((4096/*ExponentArraySize*/ - 2) | 0); exponent >= LowestNegativeOffset; exponent--)
                    {
                        /*int[]?*/ let mantissaCounts = $.$spc.System.Array.$ReadT1.call(counters, exponent);
                        if (mantissaCounts === null)
                        {
                            continue;
                        }
                        for(/*int*/ let mantissa = ((this._mantissaMax - 1) | 0); mantissa >= 0; mantissa--)
                        {
                            /*int*/ let count = $.$spc.System.Array.$ReadT1.call(mantissaCounts, mantissa);
                            if (count > 0)
                            {
                                yield new $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator.Bucket().$ctor$2(this.GetBucketCanonicalValue(exponent, mantissa), count);
                            }
                        }
                    }
                    for(/*int*/ let exponent = 0; exponent < ((LowestNegativeOffset - 1) | 0); exponent++)
                    {
                        /*int[]?*/ let mantissaCounts = $.$spc.System.Array.$ReadT1.call(counters, exponent);
                        if (mantissaCounts === null)
                        {
                            continue;
                        }
                        for(/*int*/ let mantissa = 0; mantissa < this._mantissaMax; mantissa++)
                        {
                            /*int*/ let count = $.$spc.System.Array.$ReadT1.call(mantissaCounts, mantissa);
                            if (count > 0)
                            {
                                yield new $.$sdd.System.Diagnostics.Metrics.ExponentialHistogramAggregator.Bucket().$ctor$2(this.GetBucketCanonicalValue(exponent, mantissa), count);
                            }
                        }
                    }
                }.bind(this));
            }
            /*void */ Update(/*double*/ measurement)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*ulong*/ let bits = $.$cast($.$spc.System.BitConverter.DoubleToInt64Bits(measurement), $.$spc.System.UInt64);
                        /*int*/ let exponent = $.$cast((bits >> BigInt(52/*ExponentShift*/)), $.$spc.System.Int32);
                        /*int*/ let mantissa = $.$cast((bits >> BigInt(this._mantissaShift)), $.$spc.System.Int32) & this._mantissaMask;
                        /*ref int[]?*/ let mantissaCounts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$typeArray($.$spc.System.Int32), this._counters, exponent, false, true);
                        mantissaCounts.$v ??= $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [this._mantissaMax], null);
                        (() =>
                        {
                            let $old = $.$spc.System.Array.$ReadT1.call(mantissaCounts.$v, mantissa);
                            $.$spc.System.Array.$WriteT1.call(mantissaCounts.$v, $old + 1, mantissa);
                            return $old;
                        })();
                        if (exponent !== 2047/*PositiveIntAndNan*/ && exponent !== 4095/*NegativeIntAndNan*/)
                        {
                            this._count++;
                            this._sum += measurement;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            static /*int */ QuantileToRank(/*double*/ quantile, /*int*/ count)
            {
                return $.$spc.System.Math.Min$4($.$spc.System.Math.Max$4(0, $.$cast((quantile * count), $.$spc.System.Int32)), ((count - 1) | 0));
            }
            /*double */ GetBucketCanonicalValue(/*int*/ exponent, /*int*/ mantissa)
            {
                /*long*/ let bits = (BigInt.asIntN(64, $.$cast(exponent, $.$spc.System.Int64) << BigInt(52/*ExponentShift*/))) | (BigInt.asIntN(64, $.$cast(mantissa, $.$spc.System.Int64) << BigInt(this._mantissaShift)));
                return $.$spc.System.BitConverter.Int64BitsToDouble(bits);
            }
            static $h = 4980780;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":4980780}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.ExponentialHistogramAggregator`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.W3CPropagator", ($self) => class W3CPropagator extends $.$sdd.System.Diagnostics.DistributedContextPropagator
        {
            /*DistributedContextPropagator*/ static Instance = null;
            /*int*/ static MaxBaggageEntriesToEmit = 64;
            /*int*/ static MaxBaggageEncodedLength = 8192;
            /*int*/ static MaxTraceStateEncodedLength = 256;
            /*char*/ static Equal = /*=*/ 61;
            /*char*/ static Percent = /*%*/ 37;
            /*char*/ static Replacement = /*\uFFFD*/ 65533;
            /*IReadOnlyCollection<string>*/ Fields = null;
            /*void */ Inject(/*Activity?*/ activity, /*object?*/ carrier, /*PropagatorSetterCallback?*/ setter)
            {
                if (activity === null || setter === null || activity.IdFormat !== 2/*ActivityIdFormat.W3C*/)
                {
                    return;
                }
                /*string?*/ let id = activity.Id;
                if (id === null)
                {
                    return;
                }
                setter.Invoke(carrier, "traceparent"/*TraceParent*/, id);
                let traceState;
                if (activity.TraceStateString !== null && ((traceState = activity.TraceStateString, traceState != null && activity.TraceStateString.length > 0)))
                {
                    $.$sdd.System.Diagnostics.W3CPropagator.InjectTraceState(traceState, carrier, setter);
                }
                $.$sdd.System.Diagnostics.W3CPropagator.InjectW3CBaggage(carrier, activity.Baggage, setter);
            }
            /*void */ ExtractTraceIdAndState(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter, /*out string?*/ traceId, /*out string?*/ traceState)
            {
                if (getter === null)
                {
                    traceId.$v = null;
                    traceState.$v = null;
                    return;
                }
                getter.Invoke(carrier, "traceparent"/*TraceParent*/, traceId, $.$discardRef());
                if ($.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParent(traceId.$v))
                {
                    traceId.$v = null;
                }
                /*string?*/ let traceStateValue;
                getter.Invoke(carrier, "tracestate"/*TraceState*/, $.$ref(() => traceStateValue, ($v) => traceStateValue = $v, $.$spc.System.String), $.$discardRef());
                traceState.$v = $.$sdd.System.Diagnostics.W3CPropagator.ValidateTraceState(traceStateValue);
            }
            /*IEnumerable<KeyValuePair<string, string?>>? */ ExtractBaggage(/*object?*/ carrier, /*PropagatorGetterCallback?*/ getter)
            {
                if (getter === null)
                {
                    return null;
                }
                /*string?*/ let theBaggage;
                getter.Invoke(carrier, "baggage"/*Baggage*/, $.$ref(() => theBaggage, ($v) => theBaggage = $v, $.$spc.System.String), $.$discardRef());
                if (theBaggage === null)
                {
                    getter.Invoke(carrier, "Correlation-Context"/*CorrelationContext*/, $.$ref(() => theBaggage, ($v) => theBaggage = $v, $.$spc.System.String), $.$discardRef());
                }
                /*IEnumerable<KeyValuePair<string, string?>>?*/ let baggage;
                $.$sdd.System.Diagnostics.W3CPropagator.TryExtractBaggage(theBaggage, $.$ref(() => baggage, ($v) => baggage = $v, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))));
                return baggage;
            }
            static /*bool */ TryExtractBaggage(/*string?*/ baggageString, /*out IEnumerable<KeyValuePair<string, string?>>?*/ baggage)
            {
                baggage.$v = null;
                /*List<KeyValuePair<string, string?>>?*/ let baggageList = null;
                if ($.$spc.System.String.IsNullOrEmpty(baggageString))
                {
                    return true;
                }
                /*ReadOnlySpan<char>*/ let baggageSpan = $.$spc.System.String.op_Implicit(baggageString);
                do
                {
                    /*int*/ let entrySeparator = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, baggageSpan, /*,*/ 44);
                    /*ReadOnlySpan<char>*/ let currentEntry = entrySeparator >= 0 ? baggageSpan.Slice$1(0, entrySeparator) : baggageSpan;
                    /*int*/ let keyValueSeparator = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, currentEntry, /*=*/ 61);
                    if (keyValueSeparator <= 0 || keyValueSeparator >= ((currentEntry.Length - 1) | 0))
                    {
                        break;
                    }
                    /*ReadOnlySpan<char>*/ let keySpan = currentEntry.Slice$1(0, keyValueSeparator);
                    /*ReadOnlySpan<char>*/ let valueSpan = currentEntry.Slice(((keyValueSeparator + 1) | 0));
                    /*string?*/ let key;
                    /*string*/ let value;
                    if ($.$sdd.System.Diagnostics.W3CPropagator.TryDecodeBaggageKey(keySpan, $.$ref(() => key, ($v) => key = $v, $.$spc.System.String)) && $.$sdd.System.Diagnostics.W3CPropagator.TryDecodeBaggageValue(valueSpan, $.$ref(() => value, ($v) => value = $v, $.$spc.System.String)))
                    {
                        baggageList ??= new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)))().$ctor$1();
                        baggageList.Add(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(key, value));
                    }
                    baggageSpan = entrySeparator >= 0 ? baggageSpan.Slice(((entrySeparator + 1) | 0)) : $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).Empty;
                }
                while(baggageSpan.Length > 0);
                baggageList?.Reverse();
                baggage.$v = baggageList;
                return baggageList !== null;
            }
            static /*string? */ ValidateTraceState(/*string?*/ traceState)
            {
                if ($.$spc.System.String.IsNullOrEmpty(traceState))
                {
                    return null;
                }
                /*int*/ let processed = 0;
                while(processed < traceState.length)
                {
                    /*ReadOnlySpan<char>*/ let traceStateSpan = $.$spc.System.MemoryExtensions.AsSpan$4(traceState, processed);
                    /*int*/ let commaIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, traceStateSpan, /*,*/ 44);
                    /*ReadOnlySpan<char>*/ let entry = commaIndex >= 0 ? traceStateSpan.Slice$1(0, commaIndex) : traceStateSpan;
                    /*int*/ let delta = ((entry.Length + (commaIndex >= 0 ? 1 : 0)) | 0);
                    if (((processed + delta) | 0) > 256/*MaxTraceStateEncodedLength*/)
                    {
                        break;
                    }
                    /*int*/ let equalIndex = $.$spc.System.MemoryExtensions.IndexOf$2($.$spc.System.Char, entry, /*=*/ 61);
                    if (equalIndex <= 0 || equalIndex >= ((entry.Length - 1) | 0))
                    {
                        break;
                    }
                    if ($.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceStateKey($.$sdd.System.Diagnostics.W3CPropagator.Trim(entry.Slice$1(0, equalIndex))) || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceStateValue($.$sdd.System.Diagnostics.W3CPropagator.TrimSpaceOnly(entry.Slice(((equalIndex + 1) | 0)))))
                    {
                        break;
                    }
                    processed += delta;
                }
                if (processed > 0)
                {
                    if ($.$spc.System.String.get_Chars.call(traceState, ((processed - 1) | 0)) === /*,*/ 44)
                    {
                        processed--;
                    }
                    if (processed > 0)
                    {
                        return processed >= traceState.length ? traceState : $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.MemoryExtensions.AsSpan$7(traceState, 0, processed));
                    }
                }
                return null;
            }
            static /*void */ InjectTraceState(/*string*/ traceState, /*object?*/ carrier, /*PropagatorSetterCallback*/ setter)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(traceState, null), "traceState cannot be null");
                $.$spc.System.Diagnostics.Debug.Assert$1(setter !== null, "setter cannot be null");
                /*string?*/ let traceStateValue = $.$sdd.System.Diagnostics.W3CPropagator.ValidateTraceState(traceState);
                if (!(traceStateValue === null))
                {
                    setter.Invoke(carrier, "tracestate"/*TraceState*/, traceStateValue);
                }
            }
            static /*void */ InjectW3CBaggage(/*object?*/ carrier, /*IEnumerable<KeyValuePair<string, string?>>*/ baggage, /*PropagatorSetterCallback*/ setter)
            {
                let e = null;
                try
                {
                    e = baggage.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)]);
                    if (e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*ValueStringBuilder*/ let encodedBaggage = new $.$sdd.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null));
                        /*int*/ let entriesCount = 0;
                        /*int*/ let lastGoodLength = 0;
                        do
                        {
                            /*KeyValuePair<string, string?>*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                            if ($.$sdd.System.Diagnostics.W3CPropagator.EncodeBaggageKey($.$spc.System.String.op_Implicit(item.Key), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Text.ValueStringBuilder, () => encodedBaggage, ($v) => encodedBaggage = $v, null)))
                            {
                                encodedBaggage.Append(/* */ 32);
                                encodedBaggage.Append(/*=*/ 61);
                                encodedBaggage.Append(/* */ 32);
                                if (!$.$spc.System.String.IsNullOrEmpty(item.Value))
                                {
                                    $.$sdd.System.Diagnostics.W3CPropagator.EncodeBaggageValue($.$spc.System.String.op_Implicit(item.Value), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Text.ValueStringBuilder, () => encodedBaggage, ($v) => encodedBaggage = $v, null));
                                }
                                encodedBaggage.Append$1(", "/*CommaWithSpace*/);
                                entriesCount++;
                                if (encodedBaggage.Length < 8192/*MaxBaggageEncodedLength*/)
                                {
                                    lastGoodLength = encodedBaggage.Length;
                                }
                            }
                        }
                        while(e.System$Collections$IEnumerator$MoveNext() && entriesCount < 64/*MaxBaggageEntriesToEmit*/ && encodedBaggage.Length < 8192/*MaxBaggageEncodedLength*/);
                        if (((lastGoodLength - 2) | 0) > 0)
                        {
                            setter.Invoke(carrier, "baggage"/*Baggage*/, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(encodedBaggage.AsSpan$3(0, ((lastGoodLength - 2) | 0))));
                        }
                        encodedBaggage.Dispose();
                    }
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*bool */ TryDecodeBaggageKey(/*ReadOnlySpan<char>*/ keySpan, /*out string*/ key)
            {
                key.$v = null;
                keySpan = $.$sdd.System.Diagnostics.W3CPropagator.Trim(keySpan);
                if (keySpan.IsEmpty || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidBaggageKey(keySpan))
                {
                    return false;
                }
                key.$v = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(keySpan);
                return true;
            }
            static /*bool */ TryDecodeBaggageValue(/*ReadOnlySpan<char>*/ valueSpan, /*out string*/ value)
            {
                value.$v = null;
                valueSpan = $.$sdd.System.Diagnostics.W3CPropagator.Trim(valueSpan);
                /*ValueStringBuilder*/ let vsb = new $.$sdd.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null));
                try
                {
                    for(/*int*/ let i = 0; i < valueSpan.Length; i++)
                    {
                        /*char*/ let c = valueSpan.get_Item(i).$v;
                        if (c > 127)
                        {
                            return false;
                        }
                        if (c !== /*%*/ 37)
                        {
                            vsb.Append(c);
                            continue;
                        }
                        /*byte*/ let b0;
                        if (!$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(i), $.$ref(() => b0, ($v) => b0 = $v, $.$spc.System.Byte)))
                        {
                            return false;
                        }
                        if (b0 <= 127)
                        {
                            vsb.Append(b0);
                            i += 2;
                            continue;
                        }
                        if (((((b0 - 194) | 0)) >>> 0) <= (((223 - 194) | 0)))
                        {
                            /*byte*/ let b1;
                            if (((i + 5) | 0) >= valueSpan.Length || valueSpan.get_Item(((i + 3) | 0)).$v !== /*%*/ 37 || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 3) | 0)), $.$ref(() => b1, ($v) => b1 = $v, $.$spc.System.Byte)) || (b1 & 192) !== 128)
                            {
                                vsb.Append(/*\uFFFD*/ 65533);
                                i += 2;
                                continue;
                            }
                            vsb.Append($.$cast((((b0 & 31) << 6) | (b1 & 63)), $.$spc.System.Char));
                            i += 5;
                            continue;
                        }
                        if (((((b0 - 224) | 0)) >>> 0) <= (((239 - 224) | 0)))
                        {
                            /*byte*/ let b1;
                            /*byte*/ let b2;
                            if (((i + 8) | 0) >= valueSpan.Length || valueSpan.get_Item(((i + 3) | 0)).$v !== /*%*/ 37 || valueSpan.get_Item(((i + 6) | 0)).$v !== /*%*/ 37 || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 3) | 0)), $.$ref(() => b1, ($v) => b1 = $v, $.$spc.System.Byte)) || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 6) | 0)), $.$ref(() => b2, ($v) => b2 = $v, $.$spc.System.Byte)) || (b0 === 224 && b1 < 160) || (b0 === 237 && b1 >= 160))
                            {
                                vsb.Append(/*\uFFFD*/ 65533);
                                i += 2;
                                continue;
                            }
                            vsb.Append($.$cast((((b0 & 15) << 12) | ((b1 & 63) << 6) | (b2 & 63)), $.$spc.System.Char));
                            i += 8;
                            continue;
                        }
                        if (((((b0 - 240) | 0)) >>> 0) <= (((244 - 240) | 0)))
                        {
                            /*byte*/ let b1;
                            /*byte*/ let b2;
                            /*byte*/ let b3;
                            if (((i + 11) | 0) >= valueSpan.Length || valueSpan.get_Item(((i + 3) | 0)).$v !== /*%*/ 37 || valueSpan.get_Item(((i + 6) | 0)).$v !== /*%*/ 37 || valueSpan.get_Item(((i + 9) | 0)).$v !== /*%*/ 37 || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 3) | 0)), $.$ref(() => b1, ($v) => b1 = $v, $.$spc.System.Byte)) || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 6) | 0)), $.$ref(() => b2, ($v) => b2 = $v, $.$spc.System.Byte)) || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeEscapedByte(valueSpan.Slice(((i + 9) | 0)), $.$ref(() => b3, ($v) => b3 = $v, $.$spc.System.Byte)) || (b1 & 192) !== 128 || (b2 & 192) !== 128 || (b3 & 192) !== 128)
                            {
                                vsb.Append(/*\uFFFD*/ 65533);
                                i += 2;
                                continue;
                            }
                            /*int*/ let cp = (((b0 & 7) << 18) | ((b1 & 63) << 12) | ((b2 & 63) << 6) | ((b3 & 63)));
                            if (cp < 65536 || cp > 1114111)
                            {
                                vsb.Append(/*\uFFFD*/ 65533);
                                i += 2;
                                continue;
                            }
                            cp -= 65536;
                            vsb.Append($.$cast(((((cp >> 10) + 55296) | 0)), $.$spc.System.Char));
                            vsb.Append($.$cast(((((cp & 1023) + 56320) | 0)), $.$spc.System.Char));
                            i += 11;
                            continue;
                        }
                        vsb.Append(/*\uFFFD*/ 65533);
                        i += 2;
                    }
                    value.$v = $.$sdd.System.Text.ValueStringBuilder.ToString.call(vsb);
                    return true;
                }
                finally
                {
                    vsb?.Dispose()
                }
            }
            static /*bool */ TryDecodeEscapedByte(/*ReadOnlySpan<char>*/ span, /*out byte*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(span.Length > 0 && span.get_Item(0).$v === /*%*/ 37, "span.Length > 0 && span[0] == Percent");
                /*byte*/ let byte1;
                /*byte*/ let byte2;
                if (span.Length < 3 || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeHexDigit(span.get_Item(1).$v, $.$ref(() => byte1, ($v) => byte1 = $v, $.$spc.System.Byte)) || !$.$sdd.System.Diagnostics.W3CPropagator.TryDecodeHexDigit(span.get_Item(2).$v, $.$ref(() => byte2, ($v) => byte2 = $v, $.$spc.System.Byte)))
                {
                    value.$v = 0;
                    return false;
                }
                value.$v = $.$cast((((((byte1 << 4) >>> 0) + byte2) >>> 0)), $.$spc.System.Byte);
                return true;
            }
            static /*bool */ TryDecodeHexDigit(/*char*/ c, /*out byte*/ value)
            {
                value.$v = $.$cast($.$sdd.System.HexConverter.FromChar($.$cast(c, $.$spc.System.Int32)), $.$spc.System.Byte);
                return value.$v !== 255;
            }
            /*string*/ static BaggageKeyValidCharacters = null;
            /*SearchValues<char>*/ static s_validBaggageKeyChars = null;
            static /*bool */ IsInvalidBaggageKey(/*ReadOnlySpan<char>*/ span)
            {
                return $.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, span, $.$sdd.System.Diagnostics.W3CPropagator.s_validBaggageKeyChars);
            }
            /*string*/ static TraceStateKeyValidChars = null;
            /*SearchValues<char>*/ static s_validTraceStateChars = null;
            static /*bool */ IsInvalidTraceStateKey(/*ReadOnlySpan<char>*/ key)
            {
                return key.IsEmpty || (((/*z*/ 122 - key.get_Item(0).$v) >>> 0) > (/*z*/ 122 - /*a*/ 97) && ((/*9*/ 57 - key.get_Item(0).$v) >>> 0) > (/*9*/ 57 - /*0*/ 48)) || $.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, key, $.$sdd.System.Diagnostics.W3CPropagator.s_validTraceStateChars);
            }
            /*string*/ static TraceStateValueValidChars = null;
            /*SearchValues<char>*/ static s_validTraceStateValueChars = null;
            static /*bool */ IsInvalidTraceStateValue(/*ReadOnlySpan<char>*/ value)
            {
                return value.IsEmpty || $.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, value, $.$sdd.System.Diagnostics.W3CPropagator.s_validTraceStateValueChars);
            }
            static /*bool */ EncodeBaggageKey(/*ReadOnlySpan<char>*/ key, /*ref ValueStringBuilder*/ vsb)
            {
                key = $.$sdd.System.Diagnostics.W3CPropagator.Trim(key);
                if (key.IsEmpty || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidBaggageKey(key))
                {
                    return false;
                }
                vsb.$v.Append$3(key);
                return true;
            }
            static /*void */ EncodeBaggageValue(/*ReadOnlySpan<char>*/ value, /*ref ValueStringBuilder*/ vsb)
            {
                value = $.$sdd.System.Diagnostics.W3CPropagator.Trim(value);
                for(/*int*/ let i = 0; i < value.Length; i++)
                {
                    /*char*/ let c = value.get_Item(i).$v;
                    if (!$.$sdd.System.Diagnostics.W3CPropagator.NeedToEscapeBaggageValueCharacter(c))
                    {
                        vsb.$v.Append(c);
                        continue;
                    }
                    if (c <= 127)
                    {
                        $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(c, $.$spc.System.Byte), vsb);
                        continue;
                    }
                    if (c <= 2047)
                    {
                        $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((((c + ((6 << 11) >>> 0)) >>> 0)) >>> 6), $.$spc.System.Byte), vsb);
                        $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((((c & 63) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                        continue;
                    }
                    if ($.$spc.System.Char.IsSurrogate(c))
                    {
                        if (i < ((value.Length - 1) | 0) && $.$spc.System.Char.IsSurrogatePair$1(c, value.get_Item(((i + 1) | 0)).$v))
                        {
                            /*uint*/ let v = ($.$spc.System.Char.ConvertToUtf32(c, value.get_Item(((i + 1) | 0)).$v) >>> 0);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((v + (30 << 21)) >>> 18), $.$spc.System.Byte), vsb);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast((((((v & ((63 << 12) >>> 0)) >>> 12) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast((((((v & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((((v & 63) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                            i++;
                        }
                        else 
                        {
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte(239, vsb);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte(191, vsb);
                            $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte(189, vsb);
                        }
                        continue;
                    }
                    $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((((c + (14 << 16)) | 0)) >> 12), $.$spc.System.Byte), vsb);
                    $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast((((((c & ((63 << 6) >>> 0)) >>> 6) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                    $.$sdd.System.Diagnostics.W3CPropagator.EmitEscapedByte($.$cast(((((c & 63) + 128) >>> 0)), $.$spc.System.Byte), vsb);
                }
            }
            /*ulong[]*/ static s_baggageOctet = null;
            static /*bool */ NeedToEscapeBaggageValueCharacter(/*char*/ c)
            {
                if (c >= 127)
                {
                    return true;
                }
                return ($.$spc.System.Array.$ReadT1.call($.$sdd.System.Diagnostics.W3CPropagator.s_baggageOctet, c >>> 6) & (BigInt.asUintN(64, $.$cast(1n, $.$spc.System.UInt64) << BigInt(($.$cast(c, $.$spc.System.Int32) & 63))))) === 0n;
            }
            static /*bool */ IsInvalidTraceParent(/*string?*/ traceParent)
            {
                if ($.$spc.System.String.IsNullOrEmpty(traceParent) || traceParent.length < 55)
                {
                    return true;
                }
                if (($.$spc.System.String.get_Chars.call(traceParent, 0) === /*f*/ 102 && $.$spc.System.String.get_Chars.call(traceParent, 1) === /*f*/ 102) || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, 0)) || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, 1)))
                {
                    return true;
                }
                if ($.$spc.System.String.get_Chars.call(traceParent, 0) === /*0*/ 48 && $.$spc.System.String.get_Chars.call(traceParent, 1) === /*0*/ 48)
                {
                    if (traceParent.length !== 55)
                    {
                        return true;
                    }
                }
                else 
                {
                    if (traceParent.length > 55 && $.$spc.System.String.get_Chars.call(traceParent, 55) !== /*-*/ 45)
                    {
                        return true;
                    }
                }
                if ($.$spc.System.String.get_Chars.call(traceParent, 2) !== /*-*/ 45 || $.$spc.System.String.get_Chars.call(traceParent, 35) !== /*-*/ 45 || $.$spc.System.String.get_Chars.call(traceParent, 52) !== /*-*/ 45)
                {
                    return true;
                }
                /*bool*/ let isAllZeroes = true;
                for(/*int*/ let i = 3; i < 35; i++)
                {
                    if ($.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, i)))
                    {
                        return true;
                    }
                    isAllZeroes = $.$spc.System.Boolean.op_BitwiseAnd(isAllZeroes, $.$spc.System.String.get_Chars.call(traceParent, i) === /*0*/ 48);
                }
                if (isAllZeroes)
                {
                    return true;
                }
                isAllZeroes = true;
                for(/*int*/ let i = 36; i < 52; i++)
                {
                    if ($.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, i)))
                    {
                        return true;
                    }
                    isAllZeroes = $.$spc.System.Boolean.op_BitwiseAnd(isAllZeroes, $.$spc.System.String.get_Chars.call(traceParent, i) === /*0*/ 48);
                }
                if (isAllZeroes)
                {
                    return true;
                }
                if ($.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, 53)) || $.$sdd.System.Diagnostics.W3CPropagator.IsInvalidTraceParentCharacter($.$spc.System.String.get_Chars.call(traceParent, 54)))
                {
                    return true;
                }
                return false;
            }
            /*ulong[]*/ static s_traceParentMask = null;
            static /*bool */ IsInvalidTraceParentCharacter(/*char*/ c)
            {
                if (c >= 127)
                {
                    return true;
                }
                return ($.$spc.System.Array.$ReadT1.call($.$sdd.System.Diagnostics.W3CPropagator.s_traceParentMask, c >>> 6) & (BigInt.asUintN(64, $.$cast(1n, $.$spc.System.UInt64) << BigInt(($.$cast(c, $.$spc.System.Int32) & 63))))) === 0n;
            }
            static /*void */ EmitEscapedByte(/*byte*/ b, /*ref ValueStringBuilder*/ vsb)
            {
                /*string*/ let hexChars = "0123456789ABCDEF";
                vsb.$v.Append(/*%*/ 37);
                vsb.$v.Append($.$spc.System.String.get_Chars.call(hexChars, (b >>> 4) & 15));
                vsb.$v.Append($.$spc.System.String.get_Chars.call(hexChars, b & 15));
            }
            static /*ReadOnlySpan<char> */ TrimSpaceOnly(/*ReadOnlySpan<char>*/ span)
            {
                return $.$spc.System.MemoryExtensions.Trim$11(span, /* */ 32);
            }
            static /*ReadOnlySpan<char> */ Trim(/*ReadOnlySpan<char>*/ span)
            {
                return $.$spc.System.MemoryExtensions.Trim$12(span, $.$spc.System.String.op_Implicit(" \t"));
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Fields = new ($.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$spc.System.String))().$ctor$1($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["traceparent"/*TraceParent*/, "tracestate"/*TraceState*/, "baggage"/*Baggage*/, "Correlation-Context"/*CorrelationContext*/], null, null));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new $.$sdd.System.Diagnostics.W3CPropagator().$ctor$2();
                }
                {
                    this.BaggageKeyValidCharacters = "!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~";
                }
                {
                    this.s_validBaggageKeyChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("!#$%&'*+-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ^_`abcdefghijklmnopqrstuvwxyz|~"/*BaggageKeyValidCharacters*/));
                }
                {
                    this.TraceStateKeyValidChars = "*-/0123456789@_abcdefghijklmnopqrstuvwxyz";
                }
                {
                    this.s_validTraceStateChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("*-/0123456789@_abcdefghijklmnopqrstuvwxyz"/*TraceStateKeyValidChars*/));
                }
                {
                    this.TraceStateValueValidChars = "!\"#$%&'()*+-./0123456789:;<>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~";
                }
                {
                    this.s_validTraceStateValueChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("!\"#$%&'()*+-./0123456789:;<>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"/*TraceStateValueValidChars*/));
                }
                {
                    this.s_baggageOctet = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt64.$type, [ 17870265566011326464n, 9223372036586340351n ], null, null);
                }
                {
                    this.s_traceParentMask = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt64.$type, [ 287948901175001088n, 541165879296n ], null, null);
                }
            }
            static $h = 9044012;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2490412,"h":9044012}; }
            static get $b() { return $.$sdd.System.Diagnostics.DistributedContextPropagator; }
            static get $fullName() { return `System.Diagnostics.W3CPropagator`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.AggregatorStore<>", (TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.AggregatorStore<>", [TAggregator], ($self) => class AggregatorStore$$ extends $.$spc.System.ValueType
        {
            /*object?*/  get _stateUnion() { return this.$getField(0, 4); }
            /*object?*/  set _stateUnion(value) { this.$setField(0, 4, value); }
            /*AggregatorLookupFunc<TAggregator>?*/  get _cachedLookupFunc() { return this.$getField(4, 4); }
            /*AggregatorLookupFunc<TAggregator>?*/  set _cachedLookupFunc(value) { this.$setField(4, 4, value); }
            /*Func<TAggregator?>*/  get _createAggregatorFunc() { return this.$getField(8, 4); }
            /*Func<TAggregator?>*/  set _createAggregatorFunc(value) { this.$setField(8, 4, value); }
            $ctor$2(/*Func<TAggregator?>*/ createAggregator)
            {
                super.$ctor$1();
                {
                    this._stateUnion = null;
                    this._cachedLookupFunc = null;
                    this._createAggregatorFunc = createAggregator;
                }
                return this;
            }
            /*TAggregator? */ GetAggregator(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels)
            {
                /*AggregatorLookupFunc<TAggregator>?*/ let lookupFunc = this._cachedLookupFunc;
                if (lookupFunc !== null)
                {
                    /*TAggregator?*/ let aggregator;
                    if (lookupFunc.Invoke(labels, $.$ref(() => aggregator, ($v) => aggregator = $v, TAggregator)))
                    {
                        return aggregator;
                    }
                }
                return this.GetAggregatorSlow(labels);
            }
            /*TAggregator? */ GetAggregatorSlow(/*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels)
            {
                /*AggregatorLookupFunc<TAggregator>*/ let lookupFunc = $.$sdd.System.Diagnostics.Metrics.LabelInstructionCompiler.Create(TAggregator, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.Metrics.AggregatorStore$$(TAggregator), () => this, ($v) => $v.Clone(this), null), this._createAggregatorFunc, labels);
                this._cachedLookupFunc = lookupFunc;
                /*TAggregator?*/ let aggregator;
                /*bool*/ let match = lookupFunc.Invoke(labels, $.$ref(() => aggregator, ($v) => aggregator = $v, TAggregator));
                $.$spc.System.Diagnostics.Debug.Assert$1(match, "match");
                return aggregator;
            }
            /*void */ Collect(/*Action<LabeledAggregationStatistics>*/ visitFunc)
            {
                /*object?*/ let stateUnion = this._stateUnion;
                //switch (_stateUnion)
                {
                    let agg;
                    let aggs1;
                    let aggs2;
                    let aggs3;
                    let aggsMany;
                    let aggsMultiSize;
                    $switchJumpStart1: 
                    //case TAggregator agg:
                    if ($.$is(this._stateUnion, TAggregator, { set $v(v){ agg = v; } }))
                    {
                        /*IAggregationStatistics*/ let stats = $.$dsp(agg, TAggregator, ($t) => $t.Collect,);
                        visitFunc.Invoke(new $.$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics().$ctor$1(stats, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)), [  ], null, null)));
                    }
                    //case FixedSizeLabelNameDictionary<StringSequence1, ObjectSequence1, TAggregator> aggs1:
                    else if ($.$is(this._stateUnion, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence1, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, TAggregator), { set $v(v){ aggs1 = v; } }))
                    {
                        aggs1.Collect(visitFunc);
                    }
                    //case FixedSizeLabelNameDictionary<StringSequence2, ObjectSequence2, TAggregator> aggs2:
                    else if ($.$is(this._stateUnion, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence2, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, TAggregator), { set $v(v){ aggs2 = v; } }))
                    {
                        aggs2.Collect(visitFunc);
                    }
                    //case FixedSizeLabelNameDictionary<StringSequence3, ObjectSequence3, TAggregator> aggs3:
                    else if ($.$is(this._stateUnion, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequence3, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, TAggregator), { set $v(v){ aggs3 = v; } }))
                    {
                        aggs3.Collect(visitFunc);
                    }
                    //case FixedSizeLabelNameDictionary<StringSequenceMany, ObjectSequenceMany, TAggregator> aggsMany:
                    else if ($.$is(this._stateUnion, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, TAggregator), { set $v(v){ aggsMany = v; } }))
                    {
                        aggsMany.Collect(visitFunc);
                    }
                    //case MultiSizeLabelNameDictionary<TAggregator> aggsMultiSize:
                    else if ($.$is(this._stateUnion, $.$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary$$(TAggregator), { set $v(v){ aggsMultiSize = v; } }))
                    {
                        aggsMultiSize.Collect(visitFunc);
                    }
                }
            }
            /*TAggregator? */ GetAggregator$1()
            {
                while(true)
                {
                    /*object?*/ let state = this._stateUnion;
                    let aggState;
                    let multiSizeState;
                    if (state === null)
                    {
                        /*TAggregator?*/ let newState = this._createAggregatorFunc.Invoke();
                        if ($.$box(newState, TAggregator) === null)
                        {
                            return newState;
                        }
                        if ($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._stateUnion, ($v) => this._stateUnion = $v, $.$spc.System.Object), $.$box(newState, TAggregator), null) === null)
                        {
                            return newState;
                        }
                        continue;
                    }
                    else if ($.$is(state, TAggregator, { set $v(v){ aggState = v; } }))
                    {
                        return aggState;
                    }
                    else if ($.$is(state, $.$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary$$(TAggregator), { set $v(v){ multiSizeState = v; } }))
                    {
                        return multiSizeState.GetNoLabelAggregator(this._createAggregatorFunc);
                    }
                    else 
                    {
                        /*MultiSizeLabelNameDictionary<TAggregator>*/ let newState = new ($.$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary$$(TAggregator))().$ctor$1(state);
                        if ($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._stateUnion, ($v) => this._stateUnion = $v, $.$spc.System.Object), newState, state) === state)
                        {
                            return newState.GetNoLabelAggregator(this._createAggregatorFunc);
                        }
                        continue;
                    }
                }
            }
            /*ConcurrentDictionary<TObjectSequence, TAggregator> */ GetLabelValuesDictionary(TStringSequence, TObjectSequence, /*in TStringSequence*/ names)
            {
                while(true)
                {
                    /*object?*/ let state = this._stateUnion;
                    let fixedState;
                    let multiSizeState;
                    if (state === null)
                    {
                        /*FixedSizeLabelNameDictionary<TStringSequence, TObjectSequence, TAggregator>*/ let newState = new ($.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator))().$ctor$8();
                        if ($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._stateUnion, ($v) => this._stateUnion = $v, $.$spc.System.Object), newState, null) === null)
                        {
                            return newState.GetValuesDictionary(names);
                        }
                        continue;
                    }
                    else if ($.$is(state, $.$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary$$$$(TStringSequence, TObjectSequence, TAggregator), { set $v(v){ fixedState = v; } }))
                    {
                        return fixedState.GetValuesDictionary(names);
                    }
                    else if ($.$is(state, $.$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary$$(TAggregator), { set $v(v){ multiSizeState = v; } }))
                    {
                        return multiSizeState.GetFixedSizeLabelNameDictionary(TStringSequence, TObjectSequence).GetValuesDictionary(names);
                    }
                    else 
                    {
                        /*MultiSizeLabelNameDictionary<TAggregator>*/ let newState = new ($.$sdd.System.Diagnostics.Metrics.MultiSizeLabelNameDictionary$$(TAggregator))().$ctor$1(state);
                        if ($.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this._stateUnion, ($v) => this._stateUnion = $v, $.$spc.System.Object), newState, state) === state)
                        {
                            return newState.GetFixedSizeLabelNameDictionary(TStringSequence, TObjectSequence).GetValuesDictionary(names);
                        }
                        continue;
                    }
                }
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._stateUnion = this._stateUnion;
                copy._cachedLookupFunc = this._cachedLookupFunc;
                copy._createAggregatorFunc = this._createAggregatorFunc;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._stateUnion = null;
                this._cachedLookupFunc = null;
                this._createAggregatorFunc = null;
            }
            static $h = 4456492;
            static $g = 1;
            static $z = 12;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.Metrics.AggregatorStore<${TAggregator?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.CounterAggregator", ($self) => class CounterAggregator extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*bool*/ _isMonotonic = false;
            /*double*/ _aggregatedValue = 0;
            /*PaddedDouble[]*/ _deltas = null;
            $ctor$2(/*bool*/ isMonotonic)
            {
                super.$ctor$1();
                {
                    this._isMonotonic = isMonotonic;
                }
                return this;
            }
            /*void */ Update(/*double*/ value)
            {
                /*PaddedDouble[]*/ let deltas = this._deltas;
                /*ref PaddedDouble*/ let delta = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$sdd.System.Diagnostics.Metrics.CounterAggregator.PaddedDouble, deltas, $.$spc.System.Threading.Thread.GetCurrentProcessorId() % deltas.length, false, true);
                /*double*/ let currentValue;
                do
                {
                    currentValue = delta.$v.Value;
                }
                while($.$spc.System.Threading.Interlocked.CompareExchange$11($.$ref(() => delta.$v.Value, ($v) => delta.$v.Value = $v, $.$spc.System.Double), currentValue + value, currentValue) !== currentValue);
            }
            /*IAggregationStatistics */ Collect()
            {
                /*double*/ let delta, aggregatedValue;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        delta = 0;
                        var $en4 = $.$spc.System.MemoryExtensions.AsSpan$8($.$sdd.System.Diagnostics.Metrics.CounterAggregator.PaddedDouble, this._deltas).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var paddedDelta = $en4.Current;
                            {
                                delta += $.$spc.System.Threading.Interlocked.Exchange$11($.$ref(() => paddedDelta.$v.Value, ($v) => paddedDelta.$v.Value = $v, $.$spc.System.Double), 0);
                            }
                        }
                        this._aggregatedValue += delta;
                        aggregatedValue = this._aggregatedValue;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
                return new $.$sdd.System.Diagnostics.Metrics.CounterStatistics().$ctor$1(delta, this._isMonotonic, aggregatedValue);
            }
            static $_PaddedDouble;
            static get PaddedDouble()
            {
                let $cls = $.$sdd.System.Diagnostics.Metrics.CounterAggregator;
                return $cls.$_PaddedDouble ??= $asm.$nstr("$sdd.System.Diagnostics.Metrics.CounterAggregator.PaddedDouble", ($self) => class PaddedDouble extends $.$spc.System.ValueType
                {
                    /*double*/  get Value() { return this.$getField(0, $.$spc.System.Double); }
                    /*double*/  set Value(value) { this.$setField(0, $.$spc.System.Double, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Value = this.Value;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Value = 0;
                    }
                    static $h = 4849708;
                    static $z = 64;
                    static $f = 0b10100010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":4784172,"h":4849708}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Diagnostics.Metrics.CounterAggregator.PaddedDouble`; }
                }, $cls, ($v) => $cls.$_PaddedDouble = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._deltas = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdd.System.Diagnostics.Metrics.CounterAggregator.PaddedDouble), null, [$.$spc.System.Math.Min$4($.$spc.System.Environment.ProcessorCount, 8)], null);
            }
            static $h = 4784172;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":4784172}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.CounterAggregator`; }
        });
        
        $asm.$str("$sdd.System.Text.ValueStringBuilder", ($self) => class ValueStringBuilder extends $.$spc.System.ValueType
        {
            /*char[]?*/  get _arrayToReturnToPool() { return this.$getField(0, 4); }
            /*char[]?*/  set _arrayToReturnToPool(value) { this.$setField(0, 4, value); }
            /*Span<char>*/  get _chars() { return this.$getField(4, 6); }
            /*Span<char>*/  set _chars(value) { this.$setField(4, 6, value); }
            /*int*/  get _pos() { return this.$getField(10, 4); }
            /*int*/  set _pos(value) { this.$setField(10, 4, value); }
            $ctor$2(/*Span<char>*/ initialBuffer)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = null;
                    this._chars = initialBuffer;
                    this._pos = 0;
                }
                return this;
            }
            $ctor$3(/*int*/ initialCapacity)
            {
                super.$ctor$1();
                {
                    this._arrayToReturnToPool = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(initialCapacity);
                    this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool);
                    this._pos = 0;
                }
                return this;
            }
            /*int */ get Length()
            {
                return this._pos;
            }
            /*int */ set Length(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(value >= 0, "value >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(value <= this._chars.Length, "value <= _chars.Length");
                this._pos = value;
            }
            /*int */ get Capacity()
            {
                return this._chars.Length;
            }
            /*void */ EnsureCapacity(/*int*/ capacity)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(capacity >= 0, "capacity >= 0");
                if ((capacity >>> 0) > (this._chars.Length >>> 0))
                {
                    this.Grow(((capacity - this._pos) | 0));
                }
            }
            /*ref char */ GetPinnableReference()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char */ GetPinnableReference$1(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Char, this._chars);
            }
            /*ref char*/ get_Item(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._pos, "index < _pos");
                return this._chars.get_Item(index);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let s = $.$spc.System.Span$$($.$spc.System.Char).ToString.call(this._chars.Slice$1(0, this._pos));
                this.Dispose();
                return s;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdd.System.Text.ValueStringBuilder.ToString.apply(this, arguments); }
            /*Span<char> */ get RawChars()
            {
                return this._chars;
            }
            /*ReadOnlySpan<char> */ AsSpan(/*bool*/ terminate)
            {
                if (terminate)
                {
                    this.EnsureCapacity(((this.Length + 1) | 0));
                    this._chars.get_Item(this.Length).$v = /*\u0000*/ 0;
                }
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$1()
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(0, this._pos));
            }
            /*ReadOnlySpan<char> */ AsSpan$2(/*int*/ start)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, ((this._pos - start) | 0)));
            }
            /*ReadOnlySpan<char> */ AsSpan$3(/*int*/ start, /*int*/ length)
            {
                return $.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(this._chars.Slice$1(start, length));
            }
            /*bool */ TryCopyTo(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                if (this._chars.Slice$1(0, this._pos).TryCopyTo(destination))
                {
                    charsWritten.$v = this._pos;
                    this.Dispose();
                    return true;
                }
                else 
                {
                    charsWritten.$v = 0;
                    this.Dispose();
                    return false;
                }
            }
            /*void */ Insert(/*int*/ index, /*char*/ value, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                this._chars.Slice$1(index, count).Fill(value);
                this._pos += count;
            }
            /*void */ Insert$1(/*int*/ index, /*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let count = s.length;
                if (this._pos > (((this._chars.Length - count) | 0)))
                {
                    this.Grow(count);
                }
                /*int*/ let remaining = ((this._pos - index) | 0);
                this._chars.Slice$1(index, remaining).CopyTo(this._chars.Slice(((index + count) | 0)));
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(index));
                this._pos += count;
            }
            /*void */ Append(/*char*/ c)
            {
                /*int*/ let pos = this._pos;
                /*Span<char>*/ let chars = this._chars;
                if ((pos >>> 0) < (chars.Length >>> 0))
                {
                    chars.get_Item(pos).$v = c;
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.GrowAndAppend(c);
                }
            }
            /*void */ Append$1(/*string?*/ s)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    return;
                }
                /*int*/ let pos = this._pos;
                if (s.length === 1 && (pos >>> 0) < (this._chars.Length >>> 0))
                {
                    this._chars.get_Item(pos).$v = $.$spc.System.String.get_Chars.call(s, 0);
                    this._pos = ((pos + 1) | 0);
                }
                else 
                {
                    this.AppendSlow(s);
                }
            }
            /*void */ AppendSlow(/*string*/ s)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - s.length) | 0))
                {
                    this.Grow(s.length);
                }
                $.$spc.System.String.CopyTo$1.call(s, this._chars.Slice(pos));
                this._pos += s.length;
            }
            /*void */ Append$2(/*char*/ c, /*int*/ count)
            {
                if (this._pos > ((this._chars.Length - count) | 0))
                {
                    this.Grow(count);
                }
                /*Span<char>*/ let dst = this._chars.Slice$1(this._pos, count);
                for(/*int*/ let i = 0; i < dst.Length; i++)
                {
                    dst.get_Item(i).$v = c;
                }
                this._pos += count;
            }
            /*void */ Append$3(/*scoped ReadOnlySpan<char>*/ value)
            {
                /*int*/ let pos = this._pos;
                if (pos > ((this._chars.Length - value.Length) | 0))
                {
                    this.Grow(value.Length);
                }
                value.CopyTo(this._chars.Slice(this._pos));
                this._pos += value.Length;
            }
            /*Span<char> */ AppendSpan(/*int*/ length)
            {
                /*int*/ let origPos = this._pos;
                if (origPos > ((this._chars.Length - length) | 0))
                {
                    this.Grow(length);
                }
                this._pos = ((origPos + length) | 0);
                return this._chars.Slice$1(origPos, length);
            }
            /*void */ GrowAndAppend(/*char*/ c)
            {
                this.Grow(1);
                this.Append(c);
            }
            /*void */ Grow(/*int*/ additionalCapacityBeyondPos)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(additionalCapacityBeyondPos > 0, "additionalCapacityBeyondPos > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this._pos > ((this._chars.Length - additionalCapacityBeyondPos) | 0), "Grow called incorrectly, no resize is needed.");
                /*uint*/ let ArrayMaxLength = 2147483591;
                /*int*/ let newCapacity = ($.$spc.System.Math.Max$10(((((this._pos + additionalCapacityBeyondPos) | 0)) >>> 0), $.$spc.System.Math.Min$10((((this._chars.Length >>> 0) * 2) >>> 0), ArrayMaxLength)) | 0);
                /*char[]*/ let poolArray = $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Rent(newCapacity);
                this._chars.Slice$1(0, this._pos).CopyTo($.$spc.System.Span$$($.$spc.System.Char).op_Implicit(poolArray));
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                this._chars = $.$spc.System.Span$$($.$spc.System.Char).op_Implicit(this._arrayToReturnToPool = poolArray);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            /*void */ Dispose()
            {
                /*char[]?*/ let toReturn = this._arrayToReturnToPool;
                new $.$sdd.System.Text.ValueStringBuilder().Clone(this);
                if (toReturn !== null)
                {
                    $.$spc.System.Buffers.ArrayPool$$($.$spc.System.Char).Shared.Return(toReturn, false);
                }
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._arrayToReturnToPool = this._arrayToReturnToPool;
                copy._chars = this._chars.Clone();
                copy._pos = this._pos;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._arrayToReturnToPool = null;
                this._chars = $.$default($.$spc.System.Span$$($.$spc.System.Char));
                this._pos = 0;
            }
            static $h = 9437228;
            static $z = 14;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":9437228}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Text.ValueStringBuilder`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ObservableCounterAggregator", ($self) => class ObservableCounterAggregator extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*bool*/ _isMonotonic = false;
            /*double?*/ _prevValue = null;
            /*double*/ _currValue = 0;
            $ctor$2(/*bool*/ isMonotonic)
            {
                super.$ctor$1();
                {
                    this._isMonotonic = isMonotonic;
                }
                return this;
            }
            /*void */ Update(/*double*/ value)
            {
                $.$ref(() => this._currValue, ($v) => this._currValue = $v, $.$spc.System.Double).$v = value;
            }
            /*IAggregationStatistics */ Collect()
            {
                /*double?*/ let delta = null;
                /*double*/ let currentValue;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        currentValue = $.$ref(() => this._currValue, ($v) => this._currValue = $v, $.$spc.System.Double).$v;
                        if ($.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(this._prevValue))
                        {
                            delta = currentValue - $.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(this._prevValue);
                        }
                        this._prevValue = currentValue;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
                return new $.$sdd.System.Diagnostics.Metrics.CounterStatistics().$ctor$1(delta, this._isMonotonic, currentValue);
            }
            static $h = 7471148;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":7471148}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObservableCounterAggregator`; }
        });
        
        $asm.$str("$sdd.Internal.PaddingFor32", ($self) => class PaddingFor32 extends $.$spc.System.ValueType
        {
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            static $h = 65580;
            static $z = 124;
            static $f = 0b100000000001010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":65580}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `Internal.PaddingFor32`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.LabelInstruction", ($self) => class LabelInstruction extends $.$spc.System.ValueType
        {
            $ctor$2(/*int*/ sourceIndex, /*string*/ labelName)
            {
                super.$ctor$1();
                {
                    this.SourceIndex = sourceIndex;
                    this.LabelName = labelName;
                }
                return this;
            }
            /*int*/ SourceIndex = 0;
            /*string*/ LabelName = null;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.SourceIndex = this.SourceIndex;
                copy.LabelName = this.LabelName;
                return copy;
            }
            static $h = 6029356;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":6029356}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.Metrics.LabelInstruction`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.InstrumentState<>", (TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.InstrumentState<>", [TAggregator], ($self) => class InstrumentState$$ extends $.$sdd.System.Diagnostics.Metrics.InstrumentState
        {
            /*AggregatorStore<TAggregator>*/ _aggregatorStore;
            /*int*/ static s_idCounter = 0;
            $ctor$2(/*Func<TAggregator?>*/ createAggregatorFunc)
            {
                super.$ctor$1();
                {
                    this.ID = $.$spc.System.Threading.Interlocked.Increment($.$ref(() => $.$sdd.System.Diagnostics.Metrics.InstrumentState$$(TAggregator).s_idCounter, ($v) => $.$sdd.System.Diagnostics.Metrics.InstrumentState$$(TAggregator).s_idCounter = $v, $.$spc.System.Int32));
                    this._aggregatorStore = new ($.$sdd.System.Diagnostics.Metrics.AggregatorStore$$(TAggregator))().$ctor$2(createAggregatorFunc);
                }
                return this;
            }
            /*void */ Collect(/*Instrument*/ instrument, /*Action<LabeledAggregationStatistics>*/ aggregationVisitFunc)
            {
                this._aggregatorStore.Collect(aggregationVisitFunc);
            }
            /*void */ Update(/*double*/ measurement, /*ReadOnlySpan<KeyValuePair<string, object?>>*/ labels)
            {
                /*TAggregator?*/ let aggregator = this._aggregatorStore.GetAggregator(labels);
                $.$dsp(aggregator, TAggregator, ($t) => $t.Update, measurement);
            }
            /*int*/ ID = 0;
            //default member initializer
            constructor()
            {
                super();
                this._aggregatorStore = $.$default($.$sdd.System.Diagnostics.Metrics.AggregatorStore$$(TAggregator));
            }
            static $h = 5767212;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":5701676,"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.InstrumentState; }
            static get $fullName() { return `System.Diagnostics.Metrics.InstrumentState<${TAggregator?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.LastValue", ($self) => class LastValue extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*double?*/ _lastValue = null;
            /*void */ Update(/*double*/ value)
            {
                this._lastValue = value;
            }
            /*IAggregationStatistics */ Collect()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        /*LastValueStatistics*/ let stats = new $.$sdd.System.Diagnostics.Metrics.LastValueStatistics().$ctor$1(this._lastValue);
                        this._lastValue = null;
                        return stats;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 6225964;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":6225964}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.LastValue`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.SynchronousLastValue", ($self) => class SynchronousLastValue extends $.$sdd.System.Diagnostics.Metrics.Aggregator
        {
            /*double*/ _lastValue = 0;
            /*void */ Update(/*double*/ value)
            {
                return $.$ref(() => this._lastValue, ($v) => this._lastValue = $v, $.$spc.System.Double).$v = value;
            }
            /*IAggregationStatistics */ Collect()
            {
                return new $.$sdd.System.Diagnostics.Metrics.SynchronousLastValueStatistics().$ctor$1($.$ref(() => this._lastValue, ($v) => this._lastValue = $v, $.$spc.System.Double).$v);
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 8192044;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":4325420,"h":8192044}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Aggregator; }
            static get $fullName() { return `System.Diagnostics.Metrics.SynchronousLastValue`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.Measurement<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.Measurement<>", [T], ($self) => class Measurement$$ extends $.$spc.System.ValueType
        {
            /*KeyValuePair<string, object?>[]*/  get _tags() { return this.$getField(0, 4); }
            /*KeyValuePair<string, object?>[]*/  set _tags(value) { this.$setField(0, 4, value); }
            $ctor$2(/*T*/ value)
            {
                super.$ctor$1();
                {
                    this._tags = $.$sdd.System.Diagnostics.Metrics.Instrument.EmptyTags;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*T*/ value, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$1();
                {
                    /*System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>?*/ let __ca1__;
                    this._tags = ((__ca1__ = tags) !== null ? $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), __ca1__) : $.$sdd.System.Diagnostics.Metrics.Instrument.EmptyTags);
                    this.Value = value;
                }
                return this;
            }
            $ctor$4(/*T*/ value, /*params KeyValuePair<string, object?>[]?*/ tags)
            {
                super.$ctor$1();
                {
                    if (!(tags === null))
                    {
                        this._tags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [tags.length], null);
                        tags.CopyTo(this._tags, 0);
                    }
                    else 
                    {
                        this._tags = $.$sdd.System.Diagnostics.Metrics.Instrument.EmptyTags;
                    }
                    this.Value = value;
                }
                return this;
            }
            $ctor$5(/*T*/ value, /*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                super.$ctor$1();
                {
                    this._tags = tags.ToArray();
                    this.Value = value;
                }
                return this;
            }
            $ctor$6(/*T*/ value, /*in TagList*/ tags)
            {
                super.$ctor$1();
                {
                    if (tags.$v.Count > 0)
                    {
                        this._tags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [tags.$v.Count], null);
                        tags.$v.CopyTo($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), this._tags));
                    }
                    else 
                    {
                        this._tags = $.$sdd.System.Diagnostics.Metrics.Instrument.EmptyTags;
                    }
                    this.Value = value;
                }
                return this;
            }
            /*ReadOnlySpan<KeyValuePair<string, object?>> */ get Tags()
            {
                return $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), this._tags));
            }
            /*T*/ Value = $.$default(T);
            //default value type constructor
            $ctor$7()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._tags = this._tags;
                copy.Value = this.Value.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tags = null;
                this.Value = $.$default(T);
            }
            static $h = 6422572;
            static $g = 1;
            static $z = 5;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.Metrics.Measurement<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sdd.System.Diagnostics.BitMapper", ($self) => class BitMapper extends $.$spc.System.ValueType
        {
            /*int*/  get _maxIndex() { return this.$getField(0, 4); }
            /*int*/  set _maxIndex(value) { this.$setField(0, 4, value); }
            /*Span<ulong>*/  get _bitMap() { return this.$getField(4, 12); }
            /*Span<ulong>*/  set _bitMap(value) { this.$setField(4, 12, value); }
            $ctor$2(/*Span<ulong>*/ bitMap)
            {
                super.$ctor$1();
                {
                    this._bitMap = bitMap;
                    this._bitMap.Clear();
                    this._maxIndex = ((((bitMap.Length * $.$spc.System.UInt64.$z) | 0) * 8) | 0);
                }
                return this;
            }
            /*int */ get MaxIndex()
            {
                return this._maxIndex;
            }
            static /*void */ GetIndexAndMask(/*int*/ index, /*out int*/ bitIndex, /*out ulong*/ mask)
            {
                bitIndex.$v = index >> 6;
                /*int*/ let bit = index & ((((($.$spc.System.UInt64.$z * 8) | 0) - 1) | 0));
                mask.$v = BigInt.asUintN(64, 1n << BigInt(bit));
            }
            /*bool */ SetBit(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$sdd.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$spc.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$spc.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                this._bitMap.get_Item(bitIndex).$v = value | mask;
                return true;
            }
            /*bool */ IsSet(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(index < this._maxIndex, "index < _maxIndex");
                /*int*/ let bitIndex;
                /*ulong*/ let mask;
                $.$sdd.System.Diagnostics.BitMapper.GetIndexAndMask(index, $.$ref(() => bitIndex, ($v) => bitIndex = $v, $.$spc.System.Int32), $.$ref(() => mask, ($v) => mask = $v, $.$spc.System.UInt64));
                /*ulong*/ let value = this._bitMap.get_Item(bitIndex).$v;
                return ((value & mask) !== 0n);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._maxIndex = this._maxIndex;
                copy._bitMap = this._bitMap.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._maxIndex = 0;
                this._bitMap = $.$default($.$spc.System.Span$$($.$spc.System.UInt64));
            }
            static $h = 1703980;
            static $z = 16;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":1703980}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.BitMapper`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityChangedEventArgs", ($self) => class ActivityChangedEventArgs extends $.$spc.System.ValueType
        {
            $ctor$2(/*Activity?*/ previous, /*Activity?*/ current)
            {
                super.$ctor$1();
                {
                    this.Previous = previous;
                    this.Current = current;
                }
                return this;
            }
            /*Activity?*/ Previous = null;
            /*Activity?*/ Current = null;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Previous = this.Previous;
                copy.Current = this.Current;
                return copy;
            }
            static $h = 524332;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":524332}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.ActivityChangedEventArgs`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.ListenerSubscription", ($self) => class ListenerSubscription extends $.$spc.System.ValueType
        {
            $ctor$2(/*MeterListener*/ listener, /*object?*/ state)
            {
                super.$ctor$1();
                {
                    this.Listener = listener;
                    this.State = state;
                }
                return this;
            }
            /*MeterListener*/ Listener = null;
            /*object?*/ State = null;
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Listener = this.Listener;
                copy.State = this.State;
                return copy;
            }
            static $h = 6357036;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":6357036}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Diagnostics.Metrics.ListenerSubscription`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityContext", ($self) => class ActivityContext extends $.$spc.System.ValueType
        {
            $ctor$2(/*ActivityTraceId*/ traceId, /*ActivitySpanId*/ spanId, /*ActivityTraceFlags*/ traceFlags, /*string?*/ traceState, /*bool*/ isRemote)
            {
                super.$ctor$1();
                {
                    this.TraceId = traceId;
                    this.SpanId = spanId;
                    this.TraceFlags = traceFlags;
                    this.TraceState = traceState;
                    this.IsRemote = isRemote;
                }
                return this;
            }
            /*ActivityTraceId*/ TraceId;
            /*ActivitySpanId*/ SpanId;
            /*ActivityTraceFlags*/ TraceFlags = 0;
            /*string?*/ TraceState = null;
            /*bool*/ IsRemote = false;
            static /*bool */ TryParse(/*string?*/ traceParent, /*string?*/ traceState, /*bool*/ isRemote, /*out ActivityContext*/ context)
            {
                if (traceParent === null)
                {
                    context.$v = new $.$sdd.System.Diagnostics.ActivityContext();
                    return false;
                }
                return $.$sdd.System.Diagnostics.Activity.TryConvertIdToContext(traceParent, traceState, isRemote, context);
            }
            static /*bool */ TryParse$1(/*string?*/ traceParent, /*string?*/ traceState, /*out ActivityContext*/ context)
            {
                return $.$sdd.System.Diagnostics.ActivityContext.TryParse(traceParent, traceState, false, context);
            }
            static /*ActivityContext */ Parse(/*string*/ traceParent, /*string?*/ traceState)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(traceParent, "traceParent");
                /*ActivityContext*/ let context;
                if (!$.$sdd.System.Diagnostics.Activity.TryConvertIdToContext(traceParent, traceState, false, $.$ref(() => context, ($v) => context = $v, $.$sdd.System.Diagnostics.ActivityContext)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdd.System.SR.InvalidTraceParent);
                }
                return context;
            }
            /*bool */ Equals$2(/*ActivityContext*/ value)
            {
                return this.SpanId.Equals$2(value.SpanId) && this.TraceId.Equals$2(value.TraceId) && this.TraceFlags === value.TraceFlags && $.$spc.System.String.op_Equality(this.TraceState, value.TraceState) && this.IsRemote === value.IsRemote;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let context;
                return ($.$is(obj, $.$sdd.System.Diagnostics.ActivityContext, { set $v(v){ context = v; } })) ? this.Equals$2(context) : false;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.ActivityContext.Equals.apply(this, arguments); }
            static /*bool */ op_Equality(/*ActivityContext*/ left, /*ActivityContext*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*ActivityContext*/ left, /*ActivityContext*/ right)
            {
                return !($.$sdd.System.Diagnostics.ActivityContext.op_Equality(left, right));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$sdd.System.Diagnostics.ActivityTraceId, $.$sdd.System.Diagnostics.ActivitySpanId, $.$sdd.System.Diagnostics.ActivityTraceFlags, $.$spc.System.String, this.TraceId, this.SpanId, this.TraceFlags, this.TraceState);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.ActivityContext.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.ActivityContext>.Equals(System.Diagnostics.ActivityContext)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.TraceId = this.TraceId.Clone();
                copy.SpanId = this.SpanId.Clone();
                copy.TraceFlags = this.TraceFlags;
                copy.TraceState = this.TraceState;
                copy.IsRemote = this.IsRemote;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.TraceId = $.$default($.$sdd.System.Diagnostics.ActivityTraceId);
                this.SpanId = $.$default($.$sdd.System.Diagnostics.ActivitySpanId);
                this.TraceFlags = 0;
                this.IsRemote = false;
            }
            static $h = 589868;
            static $z = 17;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":589868}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.ActivityContext) ]; }
            static get $fullName() { return `System.Diagnostics.ActivityContext`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityLink", ($self) => class ActivityLink extends $.$spc.System.ValueType
        {
            /*Activity.TagsLinkedList?*/  get _tags() { return this.$getField(0, 4); }
            /*Activity.TagsLinkedList?*/  set _tags(value) { this.$setField(0, 4, value); }
            $ctor$2(/*ActivityContext*/ context, /*ActivityTagsCollection?*/ tags)
            {
                super.$ctor$1();
                {
                    this.Context = context;
                    this._tags = $.$spc.System.Int32.op_GreaterThan$1((tags?.Count ?? null), 0) ? new $.$sdd.System.Diagnostics.Activity.TagsLinkedList().$ctor$3(tags) : null;
                }
                return this;
            }
            /*ActivityContext*/ Context;
            /*IEnumerable<KeyValuePair<string, object?>>? */ get Tags()
            {
                return this._tags;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let link;
                return ($.$is(obj, $.$sdd.System.Diagnostics.ActivityLink, { set $v(v){ link = v; } })) && this.Equals$2(link);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.ActivityLink.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*ActivityLink*/ value)
            {
                return $.$sdd.System.Diagnostics.ActivityContext.op_Equality(this.Context, value.Context) && value.Tags === this.Tags;
            }
            static /*bool */ op_Equality(/*ActivityLink*/ left, /*ActivityLink*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*ActivityLink*/ left, /*ActivityLink*/ right)
            {
                return !left.Equals$2(right);
            }
            /*Activity.Enumerator<KeyValuePair<string, object?>> */ EnumerateTagObjects()
            {
                return new ($.$sdd.System.Diagnostics.Activity.Enumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$2((this._tags?.First ?? null));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*HashCode*/ let hashCode = new $.$spc.System.HashCode();
                hashCode.Add($.$sdd.System.Diagnostics.ActivityContext, this.Context);
                if (this.Tags !== null)
                {
                    var $en3 = this.Tags.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            hashCode.Add($.$spc.System.String, kvp.Key);
                            hashCode.Add($.$spc.System.Object, kvp.Value);
                        }
                    }
                }
                return hashCode.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.ActivityLink.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.ActivityLink>.Equals(System.Diagnostics.ActivityLink)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._tags = this._tags;
                copy.Context = this.Context.Clone();
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tags = null;
                this.Context = $.$default($.$sdd.System.Diagnostics.ActivityContext);
            }
            static $h = 917548;
            static $z = 21;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":917548}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.ActivityLink) ]; }
            static get $fullName() { return `System.Diagnostics.ActivityLink`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityTraceId", ($self) => class ActivityTraceId extends $.$spc.System.ValueType
        {
            /*string?*/  get _hexString() { return this.$getField(0, 4); }
            /*string?*/  set _hexString(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string?*/ hexString)
            {
                super.$ctor$1();
                this._hexString = hexString;
                return this;
            }
            static /*ActivityTraceId */ CreateRandom()
            {
                /*Span<byte>*/ let span = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, (($.$spc.System.UInt64.$z * 2) | 0), null);
                $.$sdd.System.Diagnostics.ActivityTraceId.SetToRandomBytes(span);
                return $.$sdd.System.Diagnostics.ActivityTraceId.CreateFromBytes($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(span));
            }
            static /*ActivityTraceId */ CreateFromBytes(/*ReadOnlySpan<byte>*/ idData)
            {
                if (idData.Length !== 16)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                }
                return new $.$sdd.System.Diagnostics.ActivityTraceId().$ctor$2($.$spc.System.Convert.ToHexStringLower$2(idData));
            }
            static /*ActivityTraceId */ CreateFromUtf8String(/*ReadOnlySpan<byte>*/ idData)
            {
                return new $.$sdd.System.Diagnostics.ActivityTraceId().$ctor$3(idData);
            }
            static /*ActivityTraceId */ CreateFromString(/*ReadOnlySpan<char>*/ idData)
            {
                if (idData.Length !== 32 || !$.$sdd.System.Diagnostics.ActivityTraceId.IsLowerCaseHexAndNotAllZeros(idData))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                }
                return new $.$sdd.System.Diagnostics.ActivityTraceId().$ctor$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(idData));
            }
            /*string */ ToHexString()
            {
                return this._hexString ?? "00000000000000000000000000000000";
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.ToHexString();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdd.System.Diagnostics.ActivityTraceId.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*ActivityTraceId*/ traceId1, /*ActivityTraceId*/ traceId2)
            {
                return $.$spc.System.String.op_Equality(traceId1._hexString, traceId2._hexString);
            }
            static /*bool */ op_Inequality(/*ActivityTraceId*/ traceId1, /*ActivityTraceId*/ traceId2)
            {
                return $.$spc.System.String.op_Inequality(traceId1._hexString, traceId2._hexString);
            }
            /*bool */ Equals$2(/*ActivityTraceId*/ traceId)
            {
                return $.$spc.System.String.op_Equality(this._hexString, traceId._hexString);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let traceId;
                if ($.$is(obj, $.$sdd.System.Diagnostics.ActivityTraceId, { set $v(v){ traceId = v; } }))
                {
                    return $.$spc.System.String.op_Equality(this._hexString, traceId._hexString);
                }
                return false;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.ActivityTraceId.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.ToHexString());
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.ActivityTraceId.GetHashCode.apply(this, arguments); }
            $ctor$3(/*ReadOnlySpan<byte>*/ idData)
            {
                super.$ctor$1();
                {
                    if (idData.Length !== 32)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                    }
                    /*Span<ulong>*/ let span = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt64, 2, null);
                    if (!$.$spc.System.Buffers.Text.Utf8Parser.TryParse$15(idData.Slice$1(0, 16), span.get_Item(0), $.$discardRef(), /*x*/ 120))
                    {
                        this._hexString = $.$sdd.System.Diagnostics.ActivityTraceId.CreateRandom()._hexString;
                        return this;
                    }
                    if (!$.$spc.System.Buffers.Text.Utf8Parser.TryParse$15(idData.Slice$1(16, 16), span.get_Item(1), $.$discardRef(), /*x*/ 120))
                    {
                        this._hexString = $.$sdd.System.Diagnostics.ActivityTraceId.CreateRandom()._hexString;
                        return this;
                    }
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        span.get_Item(0).$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(span.get_Item(0).$v);
                        span.get_Item(1).$v = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(span.get_Item(1).$v);
                    }
                    this._hexString = $.$spc.System.Convert.ToHexStringLower$2($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt64, span)));
                }
                return this;
            }
            /*void */ CopyTo(/*Span<byte>*/ destination)
            {
                $.$sdd.System.Diagnostics.ActivityTraceId.SetSpanFromHexChars($.$spc.System.MemoryExtensions.AsSpan$3(this.ToHexString()), destination);
            }
            static /*void */ SetToRandomBytes(/*Span<byte>*/ outBytes)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(outBytes.Length === 16 || outBytes.Length === 8, "outBytes.Length == 16 || outBytes.Length == 8");
                /*RandomNumberGenerator*/ let r = $.$sdd.System.Diagnostics.RandomNumberGenerator.Current;
                $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.Int64, outBytes.get_Item(0), r.Next());
                if (outBytes.Length === 16)
                {
                    $.$spc.System.Runtime.CompilerServices.Unsafe.WriteUnaligned$1($.$spc.System.Int64, outBytes.get_Item(8), r.Next());
                }
            }
            static /*void */ SetSpanFromHexChars(/*ReadOnlySpan<char>*/ charData, /*Span<byte>*/ outBytes)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(((outBytes.Length * 2) | 0) === charData.Length, "outBytes.Length * 2 == charData.Length");
                for(/*int*/ let i = 0; i < outBytes.Length; i++)
                {
                    outBytes.get_Item(i).$v = $.$sdd.System.Diagnostics.ActivityTraceId.HexByteFromChars(charData.get_Item(((i * 2) | 0)).$v, charData.get_Item(((((i * 2) | 0) + 1) | 0)).$v);
                }
            }
            static /*byte */ HexByteFromChars(/*char*/ char1, /*char*/ char2)
            {
                /*int*/ let hi = $.$sdd.System.HexConverter.FromLowerChar(char1);
                /*int*/ let lo = $.$sdd.System.HexConverter.FromLowerChar(char2);
                if ((hi | lo) === 255)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                }
                return $.$cast(((hi << 4) | lo), $.$spc.System.Byte);
            }
            static /*bool */ IsLowerCaseHexAndNotAllZeros(/*ReadOnlySpan<char>*/ idData)
            {
                /*bool*/ let isNonZero = false;
                /*int*/ let i = 0;
                for(; i < idData.Length; i++)
                {
                    /*char*/ let c = idData.get_Item(i).$v;
                    if (!$.$sdd.System.HexConverter.IsHexLowerChar(c))
                    {
                        return false;
                    }
                    if (c !== /*0*/ 48)
                    {
                        isNonZero = true;
                    }
                }
                return isNonZero;
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.ActivityTraceId>.Equals(System.Diagnostics.ActivityTraceId)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._hexString = this._hexString;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._hexString = null;
            }
            static $h = 1638444;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":1638444}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.ActivityTraceId) ]; }
            static get $fullName() { return `System.Diagnostics.ActivityTraceId`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivitySpanId", ($self) => class ActivitySpanId extends $.$spc.System.ValueType
        {
            /*string?*/  get _hexString() { return this.$getField(0, 4); }
            /*string?*/  set _hexString(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string?*/ hexString)
            {
                super.$ctor$1();
                this._hexString = hexString;
                return this;
            }
            static /*ActivitySpanId */ CreateRandom()
            {
                /*ulong*/ let id;
                $.$sdd.System.Diagnostics.ActivityTraceId.SetToRandomBytes(new ($.$spc.System.Span$$($.$spc.System.Byte))().$ctor$4($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt64, () => id, ($v) => id = $v, null), $.$spc.System.UInt64.$z));
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2($.$spc.System.Convert.ToHexStringLower$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt64, () => id, ($v) => id = $v, null), $.$spc.System.UInt64.$z)));
            }
            static /*ActivitySpanId */ CreateFromBytes(/*ReadOnlySpan<byte>*/ idData)
            {
                if (idData.Length !== 8)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                }
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2($.$spc.System.Convert.ToHexStringLower$2(idData));
            }
            static /*ActivitySpanId */ CreateFromUtf8String(/*ReadOnlySpan<byte>*/ idData)
            {
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$3(idData);
            }
            static /*ActivitySpanId */ CreateFromString(/*ReadOnlySpan<char>*/ idData)
            {
                if (idData.Length !== 16 || !$.$sdd.System.Diagnostics.ActivityTraceId.IsLowerCaseHexAndNotAllZeros(idData))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                }
                return new $.$sdd.System.Diagnostics.ActivitySpanId().$ctor$2($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(idData));
            }
            /*string */ ToHexString()
            {
                return this._hexString ?? "0000000000000000";
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.ToHexString();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdd.System.Diagnostics.ActivitySpanId.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*ActivitySpanId*/ spanId1, /*ActivitySpanId*/ spandId2)
            {
                return $.$spc.System.String.op_Equality(spanId1._hexString, spandId2._hexString);
            }
            static /*bool */ op_Inequality(/*ActivitySpanId*/ spanId1, /*ActivitySpanId*/ spandId2)
            {
                return $.$spc.System.String.op_Inequality(spanId1._hexString, spandId2._hexString);
            }
            /*bool */ Equals$2(/*ActivitySpanId*/ spanId)
            {
                return $.$spc.System.String.op_Equality(this._hexString, spanId._hexString);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let spanId;
                if ($.$is(obj, $.$sdd.System.Diagnostics.ActivitySpanId, { set $v(v){ spanId = v; } }))
                {
                    return $.$spc.System.String.op_Equality(this._hexString, spanId._hexString);
                }
                return false;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.ActivitySpanId.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.ToHexString());
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.ActivitySpanId.GetHashCode.apply(this, arguments); }
            $ctor$3(/*ReadOnlySpan<byte>*/ idData)
            {
                super.$ctor$1();
                {
                    if (idData.Length !== 16)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("idData");
                    }
                    /*ulong*/ let id;
                    if (!$.$spc.System.Buffers.Text.Utf8Parser.TryParse$15(idData, $.$ref(() => id, ($v) => id = $v, $.$spc.System.UInt64), $.$discardRef(), /*x*/ 120))
                    {
                        this._hexString = $.$sdd.System.Diagnostics.ActivitySpanId.CreateRandom()._hexString;
                        return this;
                    }
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        id = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$10(id);
                    }
                    this._hexString = $.$spc.System.Convert.ToHexStringLower$2(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt64, () => id, ($v) => id = $v, null), $.$spc.System.UInt64.$z));
                }
                return this;
            }
            /*void */ CopyTo(/*Span<byte>*/ destination)
            {
                $.$sdd.System.Diagnostics.ActivityTraceId.SetSpanFromHexChars($.$spc.System.MemoryExtensions.AsSpan$3(this.ToHexString()), destination);
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.ActivitySpanId>.Equals(System.Diagnostics.ActivitySpanId)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._hexString = this._hexString;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._hexString = null;
            }
            static $h = 1310764;
            static $z = 4;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":1310764}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.ActivitySpanId) ]; }
            static get $fullName() { return `System.Diagnostics.ActivitySpanId`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.ObjectSequence1", ($self) => class ObjectSequence1 extends $.$spc.System.ValueType
        {
            /*object?*/  get Value1() { return this.$getField(0, 4); }
            /*object?*/  set Value1(value) { this.$setField(0, 4, value); }
            $ctor$2(/*object?*/ value1)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this.Value1;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetHashCode.call($t)) ?? 0;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence1.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*ObjectSequence1*/ other)
            {
                return this.Value1 === null ? other.Value1 === null : $.$spc.System.Object.Equals.call(this.Value1, other.Value1);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let os1;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.ObjectSequence1, { set $v(v){ os1 = v; } }) && this.Equals$2(os1.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence1.Equals.apply(this, arguments); }
            /*Span<object?> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.Object, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.Object), 1);
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.ObjectSequence1>.Equals(System.Diagnostics.Metrics.ObjectSequence1)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IObjectSequence.AsSpan()
            System$Diagnostics$Metrics$IObjectSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
            }
            static $h = 7143468;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7143468}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence1), $.$sdd.System.Diagnostics.Metrics.IObjectSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObjectSequence1`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.ObjectSequence2", ($self) => class ObjectSequence2 extends $.$spc.System.ValueType
        {
            /*object?*/  get Value1() { return this.$getField(0, 4); }
            /*object?*/  set Value1(value) { this.$setField(0, 4, value); }
            /*object?*/  get Value2() { return this.$getField(4, 4); }
            /*object?*/  set Value2(value) { this.$setField(4, 4, value); }
            $ctor$2(/*object?*/ value1, /*object?*/ value2)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                    this.Value2 = value2;
                }
                return this;
            }
            /*bool */ Equals$2(/*ObjectSequence2*/ other)
            {
                return (this.Value1 === null ? other.Value1 === null : $.$spc.System.Object.Equals.call(this.Value1, other.Value1)) && (this.Value2 === null ? other.Value2 === null : $.$spc.System.Object.Equals.call(this.Value2, other.Value2));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let os2;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.ObjectSequence2, { set $v(v){ os2 = v; } }) && this.Equals$2(os2.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence2.Equals.apply(this, arguments); }
            /*Span<object?> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.Object, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.Object), 2);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Object, $.$spc.System.Object, this.Value1, this.Value2);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence2.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.ObjectSequence2>.Equals(System.Diagnostics.Metrics.ObjectSequence2)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IObjectSequence.AsSpan()
            System$Diagnostics$Metrics$IObjectSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                copy.Value2 = this.Value2;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
                this.Value2 = null;
            }
            static $h = 7209004;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7209004}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence2), $.$sdd.System.Diagnostics.Metrics.IObjectSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObjectSequence2`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.ObjectSequence3", ($self) => class ObjectSequence3 extends $.$spc.System.ValueType
        {
            /*object?*/  get Value1() { return this.$getField(0, 4); }
            /*object?*/  set Value1(value) { this.$setField(0, 4, value); }
            /*object?*/  get Value2() { return this.$getField(4, 4); }
            /*object?*/  set Value2(value) { this.$setField(4, 4, value); }
            /*object?*/  get Value3() { return this.$getField(8, 4); }
            /*object?*/  set Value3(value) { this.$setField(8, 4, value); }
            $ctor$2(/*object?*/ value1, /*object?*/ value2, /*object?*/ value3)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                    this.Value2 = value2;
                    this.Value3 = value3;
                }
                return this;
            }
            /*bool */ Equals$2(/*ObjectSequence3*/ other)
            {
                return (this.Value1 === null ? other.Value1 === null : $.$spc.System.Object.Equals.call(this.Value1, other.Value1)) && (this.Value2 === null ? other.Value2 === null : $.$spc.System.Object.Equals.call(this.Value2, other.Value2)) && (this.Value3 === null ? other.Value3 === null : $.$spc.System.Object.Equals.call(this.Value3, other.Value3));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let os3;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.ObjectSequence3, { set $v(v){ os3 = v; } }) && this.Equals$2(os3.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence3.Equals.apply(this, arguments); }
            /*Span<object?> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.Object, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.Object), 3);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Object, $.$spc.System.Object, $.$spc.System.Object, this.Value1, this.Value2, this.Value3);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequence3.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.ObjectSequence3>.Equals(System.Diagnostics.Metrics.ObjectSequence3)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IObjectSequence.AsSpan()
            System$Diagnostics$Metrics$IObjectSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                copy.Value2 = this.Value2;
                copy.Value3 = this.Value3;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
                this.Value2 = null;
                this.Value3 = null;
            }
            static $h = 7274540;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7274540}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.ObjectSequence3), $.$sdd.System.Diagnostics.Metrics.IObjectSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObjectSequence3`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.ObjectSequenceMany", ($self) => class ObjectSequenceMany extends $.$spc.System.ValueType
        {
            /*object?[]*/  get _values() { return this.$getField(0, 4); }
            /*object?[]*/  set _values(value) { this.$setField(0, 4, value); }
            $ctor$2(/*object[]*/ values)
            {
                super.$ctor$1();
                {
                    this._values = values;
                }
                return this;
            }
            /*bool */ Equals$2(/*ObjectSequenceMany*/ other)
            {
                if (this._values.length !== other._values.length)
                {
                    return false;
                }
                for(/*int*/ let i = 0; i < this._values.length; i++)
                {
                    /*object?*/ let value = $.$spc.System.Array.$ReadT1.call(this._values, i), otherValue = $.$spc.System.Array.$ReadT1.call(other._values, i);
                    if (value === null)
                    {
                        if (!(otherValue === null))
                        {
                            return false;
                        }
                    }
                    else if (!$.$spc.System.Object.Equals.call(value, otherValue))
                    {
                        return false;
                    }
                }
                return true;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let osm;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany, { set $v(v){ osm = v; } }) && this.Equals$2(osm);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany.Equals.apply(this, arguments); }
            /*Span<object?> */ AsSpan()
            {
                return $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Object, this._values);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*HashCode*/ let h = new $.$spc.System.HashCode();
                for(/*int*/ let i = 0; i < this._values.length; i++)
                {
                    h.Add($.$spc.System.Object, $.$spc.System.Array.$ReadT1.call(this._values, i));
                }
                return h.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.ObjectSequenceMany>.Equals(System.Diagnostics.Metrics.ObjectSequenceMany)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IObjectSequence.AsSpan()
            System$Diagnostics$Metrics$IObjectSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._values = this._values;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._values = null;
            }
            static $h = 7340076;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7340076}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.ObjectSequenceMany), $.$sdd.System.Diagnostics.Metrics.IObjectSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.ObjectSequenceMany`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.StringSequence1", ($self) => class StringSequence1 extends $.$spc.System.ValueType
        {
            /*string*/  get Value1() { return this.$getField(0, 4); }
            /*string*/  set Value1(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string*/ value1)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.String.GetHashCode.call(this.Value1);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.StringSequence1.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*StringSequence1*/ other)
            {
                return $.$spc.System.String.op_Equality(this.Value1, other.Value1);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let ss1;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.StringSequence1, { set $v(v){ ss1 = v; } }) && this.Equals$2(ss1.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.StringSequence1.Equals.apply(this, arguments); }
            /*Span<string> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.String, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.String), 1);
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.StringSequence1>.Equals(System.Diagnostics.Metrics.StringSequence1)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IStringSequence.AsSpan()
            System$Diagnostics$Metrics$IStringSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
            }
            static $h = 7929900;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7929900}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.StringSequence1), $.$sdd.System.Diagnostics.Metrics.IStringSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.StringSequence1`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.StringSequence2", ($self) => class StringSequence2 extends $.$spc.System.ValueType
        {
            /*string*/  get Value1() { return this.$getField(0, 4); }
            /*string*/  set Value1(value) { this.$setField(0, 4, value); }
            /*string*/  get Value2() { return this.$getField(4, 4); }
            /*string*/  set Value2(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ value1, /*string*/ value2)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                    this.Value2 = value2;
                }
                return this;
            }
            /*bool */ Equals$2(/*StringSequence2*/ other)
            {
                return $.$spc.System.String.op_Equality(this.Value1, other.Value1) && $.$spc.System.String.op_Equality(this.Value2, other.Value2);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let ss2;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.StringSequence2, { set $v(v){ ss2 = v; } }) && this.Equals$2(ss2.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.StringSequence2.Equals.apply(this, arguments); }
            /*Span<string> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.String, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.String), 2);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.String, $.$spc.System.String, this.Value1, this.Value2);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.StringSequence2.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.StringSequence2>.Equals(System.Diagnostics.Metrics.StringSequence2)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IStringSequence.AsSpan()
            System$Diagnostics$Metrics$IStringSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                copy.Value2 = this.Value2;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
                this.Value2 = null;
            }
            static $h = 7995436;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":7995436}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.StringSequence2), $.$sdd.System.Diagnostics.Metrics.IStringSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.StringSequence2`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.StringSequence3", ($self) => class StringSequence3 extends $.$spc.System.ValueType
        {
            /*string*/  get Value1() { return this.$getField(0, 4); }
            /*string*/  set Value1(value) { this.$setField(0, 4, value); }
            /*string*/  get Value2() { return this.$getField(4, 4); }
            /*string*/  set Value2(value) { this.$setField(4, 4, value); }
            /*string*/  get Value3() { return this.$getField(8, 4); }
            /*string*/  set Value3(value) { this.$setField(8, 4, value); }
            $ctor$2(/*string*/ value1, /*string*/ value2, /*string*/ value3)
            {
                super.$ctor$1();
                {
                    this.Value1 = value1;
                    this.Value2 = value2;
                    this.Value3 = value3;
                }
                return this;
            }
            /*bool */ Equals$2(/*StringSequence3*/ other)
            {
                return $.$spc.System.String.op_Equality(this.Value1, other.Value1) && $.$spc.System.String.op_Equality(this.Value2, other.Value2) && $.$spc.System.String.op_Equality(this.Value3, other.Value3);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let ss3;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.StringSequence3, { set $v(v){ ss3 = v; } }) && this.Equals$2(ss3.Clone());
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.StringSequence3.Equals.apply(this, arguments); }
            /*Span<string> */ AsSpan()
            {
                return $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateSpan($.$spc.System.String, $.$ref(() => this.Value1, ($v) => this.Value1 = $v, $.$spc.System.String), 3);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$2($.$spc.System.String, $.$spc.System.String, $.$spc.System.String, this.Value1, this.Value2, this.Value3);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.StringSequence3.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.StringSequence3>.Equals(System.Diagnostics.Metrics.StringSequence3)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IStringSequence.AsSpan()
            System$Diagnostics$Metrics$IStringSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Value1 = this.Value1;
                copy.Value2 = this.Value2;
                copy.Value3 = this.Value3;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Value1 = null;
                this.Value2 = null;
                this.Value3 = null;
            }
            static $h = 8060972;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":8060972}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.StringSequence3), $.$sdd.System.Diagnostics.Metrics.IStringSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.StringSequence3`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.Metrics.StringSequenceMany", ($self) => class StringSequenceMany extends $.$spc.System.ValueType
        {
            /*string[]*/  get _values() { return this.$getField(0, 4); }
            /*string[]*/  set _values(value) { this.$setField(0, 4, value); }
            $ctor$2(/*string[]*/ values)
            {
                super.$ctor$1();
                this._values = values;
                return this;
            }
            /*Span<string> */ AsSpan()
            {
                return $.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.String, this._values);
            }
            /*bool */ Equals$2(/*StringSequenceMany*/ other)
            {
                return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.String, $.$spc.System.Span$$($.$spc.System.String).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.String, this._values)), $.$spc.System.Span$$($.$spc.System.String).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.String, other._values)));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let ssm;
                return $.$is(obj, $.$sdd.System.Diagnostics.Metrics.StringSequenceMany, { set $v(v){ ssm = v; } }) && this.Equals$2(ssm);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdd.System.Diagnostics.Metrics.StringSequenceMany.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*HashCode*/ let h = new $.$spc.System.HashCode();
                for(/*int*/ let i = 0; i < this._values.length; i++)
                {
                    h.Add($.$spc.System.String, $.$spc.System.Array.$ReadT1.call(this._values, i));
                }
                return h.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdd.System.Diagnostics.Metrics.StringSequenceMany.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.Metrics.StringSequenceMany>.Equals(System.Diagnostics.Metrics.StringSequenceMany)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Generated interface implemetation for System.Diagnostics.Metrics.IStringSequence.AsSpan()
            System$Diagnostics$Metrics$IStringSequence$AsSpan()
            {
                return this.AsSpan(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._values = this._values;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._values = null;
            }
            static $h = 8126508;
            static $z = 4;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":8126508}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdd.System.Diagnostics.Metrics.StringSequenceMany), $.$sdd.System.Diagnostics.Metrics.IStringSequence ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.StringSequenceMany`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.DiagEnumerator<>", (T) => $asm.$gt("$sdd.System.Diagnostics.DiagEnumerator<>", [T], ($self) => class DiagEnumerator$$ extends $.$spc.System.ValueType
        {
            /*DiagNode<T>*/ static s_Empty = null;
            /*DiagNode<T>?*/  get _nextNode() { return this.$getField(0, 4); }
            /*DiagNode<T>?*/  set _nextNode(value) { this.$setField(0, 4, value); }
            /*DiagNode<T>*/  get _currentNode() { return this.$getField(4, 4); }
            /*DiagNode<T>*/  set _currentNode(value) { this.$setField(4, 4, value); }
            $ctor$2(/*DiagNode<T>?*/ head)
            {
                super.$ctor$1();
                {
                    this._nextNode = head;
                    this._currentNode = $.$sdd.System.Diagnostics.DiagEnumerator$$(T).s_Empty;
                }
                return this;
            }
            /*T */ get Current()
            {
                return this._currentNode.Value;
            }
            /*object? */ get System$Collections$IEnumerator$Current()
            {
                return $.$box(this.Current, T);
            }
            /*bool */ MoveNext()
            {
                if (this._nextNode === null)
                {
                    this._currentNode = $.$sdd.System.Diagnostics.DiagEnumerator$$(T).s_Empty;
                    return false;
                }
                this._currentNode = this._nextNode;
                this._nextNode = this._nextNode.Next;
                return true;
            }
            /*void */ Reset()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Dispose()
            {
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
            get System$Collections$Generic$IEnumerator$$$Current()
            {
                return this.Current;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._nextNode = this._nextNode;
                copy._currentNode = this._currentNode;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._nextNode = null;
                this._currentNode = null;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_Empty = new ($.$sdd.System.Diagnostics.DiagNode$$(T))().$ctor$1($.$default(T));
                }
            }
            static $h = 1769516;
            static $g = 1;
            static $z = 8;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(T), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Diagnostics.DiagEnumerator<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Counter<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.Counter<>", [T], ($self) => class Counter$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument$$(T)
        {
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$6(meter, name, unit, description, tags);
                {
                    this.Publish();
                }
                return this;
            }
            /*void */ Add(/*T*/ delta)
            {
                return this.RecordMeasurement$4(delta);
            }
            /*void */ Add$1(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag)
            {
                return this.RecordMeasurement(delta, tag);
            }
            /*void */ Add$2(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2)
            {
                return this.RecordMeasurement$1(delta, tag1, tag2);
            }
            /*void */ Add$3(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2, /*KeyValuePair<string, object?>*/ tag3)
            {
                return this.RecordMeasurement$2(delta, tag1, tag2, tag3);
            }
            /*void */ Add$4(/*T*/ delta, /*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                return this.RecordMeasurement$5(delta, tags);
            }
            /*void */ Add$5(/*T*/ delta, /*params KeyValuePair<string, object?>[]*/ tags)
            {
                return this.RecordMeasurement$5(delta, $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), tags)));
            }
            /*void */ Add$6(/*T*/ delta, /*in TagList*/ tagList)
            {
                return this.RecordMeasurement$3(delta, tagList);
            }
            static $h = 4718636;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.Counter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Histogram<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.Histogram<>", [T], ($self) => class Histogram$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument$$(T)
        {
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, unit, description, null, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags, /*InstrumentAdvice<T>?*/ advice)
            {
                super.$ctor$7(meter, name, unit, description, tags, advice);
                {
                    this.Publish();
                }
                return this;
            }
            /*void */ Record(/*T*/ value)
            {
                return this.RecordMeasurement$4(value);
            }
            /*void */ Record$1(/*T*/ value, /*KeyValuePair<string, object?>*/ tag)
            {
                return this.RecordMeasurement(value, tag);
            }
            /*void */ Record$2(/*T*/ value, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2)
            {
                return this.RecordMeasurement$1(value, tag1, tag2);
            }
            /*void */ Record$3(/*T*/ value, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2, /*KeyValuePair<string, object?>*/ tag3)
            {
                return this.RecordMeasurement$2(value, tag1, tag2, tag3);
            }
            /*void */ Record$4(/*T*/ value, /*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                return this.RecordMeasurement$5(value, tags);
            }
            /*void */ Record$5(/*T*/ value, /*params KeyValuePair<string, object?>[]*/ tags)
            {
                return this.RecordMeasurement$5(value, $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), tags)));
            }
            /*void */ Record$6(/*T*/ value, /*in TagList*/ tagList)
            {
                return this.RecordMeasurement$3(value, tagList);
            }
            static $h = 5242924;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.Histogram<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ObservableCounter<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.ObservableCounter<>", [T], ($self) => class ObservableCounter$$ extends $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T)
        {
            /*object*/ _callback = null;
            $ctor$6(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$7(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$7(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$10(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$11(meter, name, observeValues, unit, description, null);
                {
                }
                return this;
            }
            $ctor$11(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValues, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValues") });
                    this.Publish();
                }
                return this;
            }
            /*IEnumerable<Measurement<T>> */ Observe$1()
            {
                return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T).Observe$2(this._callback);
            }
            static $h = 7405612;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.ObservableCounter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.Gauge<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.Gauge<>", [T], ($self) => class Gauge$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument$$(T)
        {
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$6(meter, name, unit, description, tags);
                {
                    this.Publish();
                }
                return this;
            }
            /*void */ Record(/*T*/ value)
            {
                return this.RecordMeasurement$4(value);
            }
            /*void */ Record$1(/*T*/ value, /*KeyValuePair<string, object?>*/ tag)
            {
                return this.RecordMeasurement(value, tag);
            }
            /*void */ Record$2(/*T*/ value, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2)
            {
                return this.RecordMeasurement$1(value, tag1, tag2);
            }
            /*void */ Record$3(/*T*/ value, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2, /*KeyValuePair<string, object?>*/ tag3)
            {
                return this.RecordMeasurement$2(value, tag1, tag2, tag3);
            }
            /*void */ Record$4(/*T*/ value, /*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                return this.RecordMeasurement$5(value, tags);
            }
            /*void */ Record$5(/*T*/ value, /*params KeyValuePair<string, object?>[]*/ tags)
            {
                return this.RecordMeasurement$5(value, $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), tags)));
            }
            /*void */ Record$6(/*T*/ value, /*in TagList*/ tagList)
            {
                return this.RecordMeasurement$3(value, tagList);
            }
            static $h = 5177388;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.Gauge<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.ObservableUpDownCounter<>", [T], ($self) => class ObservableUpDownCounter$$ extends $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T)
        {
            /*object*/ _callback = null;
            $ctor$6(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$7(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$7(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$10(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$11(meter, name, observeValues, unit, description, null);
                {
                }
                return this;
            }
            $ctor$11(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValues, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValues") });
                    this.Publish();
                }
                return this;
            }
            /*IEnumerable<Measurement<T>> */ Observe$1()
            {
                return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T).Observe$2(this._callback);
            }
            static $h = 7667756;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.ObservableUpDownCounter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.UpDownCounter<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.UpDownCounter<>", [T], ($self) => class UpDownCounter$$ extends $.$sdd.System.Diagnostics.Metrics.Instrument$$(T)
        {
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$6(meter, name, unit, description, tags);
                {
                    this.Publish();
                }
                return this;
            }
            /*void */ Add(/*T*/ delta)
            {
                return this.RecordMeasurement$4(delta);
            }
            /*void */ Add$1(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag)
            {
                return this.RecordMeasurement(delta, tag);
            }
            /*void */ Add$2(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2)
            {
                return this.RecordMeasurement$1(delta, tag1, tag2);
            }
            /*void */ Add$3(/*T*/ delta, /*KeyValuePair<string, object?>*/ tag1, /*KeyValuePair<string, object?>*/ tag2, /*KeyValuePair<string, object?>*/ tag3)
            {
                return this.RecordMeasurement$2(delta, tag1, tag2, tag3);
            }
            /*void */ Add$4(/*T*/ delta, /*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tags)
            {
                return this.RecordMeasurement$5(delta, tags);
            }
            /*void */ Add$5(/*T*/ delta, /*params KeyValuePair<string, object?>[]*/ tags)
            {
                return this.RecordMeasurement$5(delta, $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$8($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), tags)));
            }
            /*void */ Add$6(/*T*/ delta, /*in TagList*/ tagList)
            {
                return this.RecordMeasurement$3(delta, tagList);
            }
            static $h = 8323116;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.Instrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.UpDownCounter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.ObservableGauge<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.ObservableGauge<>", [T], ($self) => class ObservableGauge$$ extends $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T)
        {
            /*object*/ _callback = null;
            $ctor$6(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$7(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$7(/*Meter*/ meter, /*string*/ name, /*Func<T>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$8(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$9(meter, name, observeValue, unit, description, null);
                {
                }
                return this;
            }
            $ctor$9(/*Meter*/ meter, /*string*/ name, /*Func<Measurement<T>>*/ observeValue, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValue, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValue") });
                    this.Publish();
                }
                return this;
            }
            $ctor$10(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description)
            {
                this.$ctor$11(meter, name, observeValues, unit, description, null);
                {
                }
                return this;
            }
            $ctor$11(/*Meter*/ meter, /*string*/ name, /*Func<IEnumerable<Measurement<T>>>*/ observeValues, /*string?*/ unit, /*string?*/ description, /*IEnumerable<KeyValuePair<string, object?>>?*/ tags)
            {
                super.$ctor$5(meter, name, unit, description, tags);
                {
                    this._callback = $.$firstOf(observeValues, () => { throw new $.$spc.System.ArgumentNullException().$ctor$16("observeValues") });
                    this.Publish();
                }
                return this;
            }
            /*IEnumerable<Measurement<T>> */ Observe$1()
            {
                return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T).Observe$2(this._callback);
            }
            static $h = 7536684;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static get $b() { return $.$sdd.System.Diagnostics.Metrics.ObservableInstrument$$(T); }
            static get $fullName() { return `System.Diagnostics.Metrics.ObservableGauge<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.SampleActivity<>", (T) => $asm.$gt("$sdd.System.Diagnostics.SampleActivity<>", [T], ($self) => class SampleActivity$$ extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ActivitySamplingResult*/ Invoke(/**/ options)
            {
                return this.$nativeFunction.call(this.$target, options);
            }
            static $h = 8650796;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.SampleActivity<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.ExceptionRecorder", ($self) => class ExceptionRecorder extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ activity, /**/ exception, /**/ tags)
            {
                return this.$nativeFunction.call(this.$target, activity, exception, tags);
            }
            static $h = 4063276;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"h":4063276}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.ExceptionRecorder`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DsesSampleActivityFunc", ($self) => class DsesSampleActivityFunc extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*ActivitySamplingResult*/ Invoke(/*$.$spc.System.Boolean*/ hasActivityContext, /**/ options)
            {
                return this.$nativeFunction.call(this.$target, hasActivityContext, options);
            }
            static $h = 3932204;
            static $f = 0b10000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"h":3932204}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `DsesSampleActivityFunc`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MeasurementCallback<>", (T) => $asm.$gt("$sdd.System.Diagnostics.Metrics.MeasurementCallback<>", [T], ($self) => class MeasurementCallback$$ extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/**/ instrument, /**/ measurement, /**/ tags, /*$.$spc.System.Nullable$$*/ state)
            {
                return this.$nativeFunction.call(this.$target, instrument, measurement, tags, state);
            }
            static $h = 6488108;
            static $g = 1;
            static $f = 0b11000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.MeasurementCallback<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc<>", (TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.AggregatorLookupFunc<>", [TAggregator], ($self) => class AggregatorLookupFunc$$ extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/**/ labels, /**/ aggregator)
            {
                return this.$nativeFunction.call(this.$target, labels, aggregator);
            }
            static $h = 4390956;
            static $g = 1;
            static $f = 0b11000000;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.AggregatorLookupFunc<${TAggregator?.$fullName}>`; }
        }));
        
        $asm.$str("$sdd.System.Diagnostics.ActivityStatusCode", ($self) => class ActivityStatusCode extends $.$spc.System.Enum
        {
            static Unset = 0;
            static Ok = 1;
            static Error = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unset": 0n,
                    "Ok": 1n,
                    "Error": 2n
                };
            }
            static $h = 1376300;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":1376300}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ActivityStatusCode`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityKind", ($self) => class ActivityKind extends $.$spc.System.Enum
        {
            static Internal = 0;
            static Server = 1;
            static Client = 2;
            static Producer = 3;
            static Consumer = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Internal": 0n,
                    "Server": 1n,
                    "Client": 2n,
                    "Producer": 3n,
                    "Consumer": 4n
                };
            }
            static $h = 852012;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":852012}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ActivityKind`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivitySamplingResult", ($self) => class ActivitySamplingResult extends $.$spc.System.Enum
        {
            static None = 0;
            static PropagationData = 1;
            static AllData = 2;
            static AllDataAndRecorded = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "PropagationData": 1n,
                    "AllData": 2n,
                    "AllDataAndRecorded": 3n
                };
            }
            static $h = 1048620;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":1048620}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ActivitySamplingResult`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.DsesActivityEvents", ($self) => class DsesActivityEvents extends $.$spc.System.Enum
        {
            static None = 0;
            static ActivityStart = 1;
            static ActivityStop = 2;
            static All = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "ActivityStart": 1n,
                    "ActivityStop": 2n,
                    "All": 3n
                };
            }
            static $h = 2687020;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":2687020}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `DsesActivityEvents`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityTraceFlags", ($self) => class ActivityTraceFlags extends $.$spc.System.Enum
        {
            static None = 0;
            static Recorded = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Recorded": 1n
                };
            }
            static $h = 1572908;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":1572908}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ActivityTraceFlags`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.ActivityIdFormat", ($self) => class ActivityIdFormat extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Hierarchical = 1;
            static W3C = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Hierarchical": 1n,
                    "W3C": 2n
                };
            }
            static $h = 786476;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":786476}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ActivityIdFormat`; }
        });
        
        $asm.$str("$sdd.System.Diagnostics.TagList", ($self) => class TagList extends $.$spc.System.ValueType
        {
            /*int*/ static OverflowAdditionalCapacity = 8;
            /*InlineTags*/  get _tags() { return this.$getField(0, $.$sdd.System.Diagnostics.TagList.InlineTags); }
            /*InlineTags*/  set _tags(value) { this.$setField(0, $.$sdd.System.Diagnostics.TagList.InlineTags, value); }
            /*KeyValuePair<string, object?>[]?*/  get _overflowTags() { return this.$getField(8, 4); }
            /*KeyValuePair<string, object?>[]?*/  set _overflowTags(value) { this.$setField(8, 4, value); }
            /*int*/  get _tagsCount() { return this.$getField(12, 4); }
            /*int*/  set _tagsCount(value) { this.$setField(12, 4, value); }
            $ctor$2(/*params ReadOnlySpan<KeyValuePair<string, object?>>*/ tagList)
            {
                this.$ctor$3();
                {
                    this._tagsCount = tagList.Length;
                    /*scoped Span<KeyValuePair<string, object?>>*/ let tags = this._tagsCount <= 8/*InlineTags.Length*/ ? $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields) : $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._overflowTags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [((this._tagsCount + 8/*OverflowAdditionalCapacity*/) | 0)], null));
                    tagList.CopyTo(tags);
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._tagsCount;
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*KeyValuePair<string, object?>*/ get_Item(/*int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.UInt32, (index >>> 0), (this._tagsCount >>> 0), "index");
                return this._overflowTags === null ? this._tags.$fields[index] : $.$spc.System.Array.$ReadT1.call(this._overflowTags, index);
            }
            /*void*/ set_Item(/*int*/ index, /*KeyValuePair<string, object?>*/ value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.UInt32, (index >>> 0), (this._tagsCount >>> 0), "index");
                if (this._overflowTags === null)
                {
                    this._tags.$fields[index] = value;
                }
                else 
                {
                    $.$spc.System.Array.$WriteT1.call(this._overflowTags, value, index);
                }
            }
            /*void */ Add(/*string*/ key, /*object?*/ value)
            {
                return this.Add$1(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value));
            }
            /*void */ Add$1(/*KeyValuePair<string, object?>*/ tag)
            {
                /*int*/ let count = this._tagsCount;
                if (this._overflowTags === null && (count >>> 0) < 8/*InlineTags.Length*/)
                {
                    this._tags.$fields[count] = tag;
                    this._tagsCount++;
                }
                else 
                {
                    this.AddToOverflow(tag);
                }
            }
            /*void */ AddToOverflow(/*KeyValuePair<string, object?>*/ tag)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._overflowTags === null) || this._tagsCount === 8/*InlineTags.Length*/, "_overflowTags is not null || _tagsCount == InlineTags.Length");
                if (this._overflowTags === null)
                {
                    this._overflowTags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [((8/*InlineTags.Length*/ + 8/*OverflowAdditionalCapacity*/) | 0)], null);
                    ($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields)).CopyTo($.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._overflowTags));
                }
                else if (this._tagsCount === this._overflowTags.length)
                {
                    $.$spc.System.Array.Resize($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$ref(() => this._overflowTags, ($v) => this._overflowTags = $v, $.$typeArray($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))), ((this._tagsCount + 8/*OverflowAdditionalCapacity*/) | 0));
                }
                $.$spc.System.Array.$WriteT1.call(this._overflowTags, tag, this._tagsCount);
                this._tagsCount++;
            }
            /*void */ CopyTo(/*Span<KeyValuePair<string, object?>>*/ tags)
            {
                if (tags.Length < this._tagsCount)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdd.System.SR.Arg_BufferTooSmall);
                }
                this.Tags.CopyTo(tags);
            }
            /*void */ CopyTo$1(/*KeyValuePair<string, object?>[]*/ array, /*int*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.UInt32, (arrayIndex >>> 0), (array.length >>> 0), "arrayIndex");
                this.CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), array, arrayIndex));
            }
            /*void */ Insert(/*int*/ index, /*KeyValuePair<string, object?>*/ item)
            {
                if (index === this._tagsCount)
                {
                    this.Add$1(item);
                    return;
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.UInt32, (index >>> 0), (this._tagsCount >>> 0), "index");
                if (this._tagsCount === 8/*InlineTags.Length*/ && this._overflowTags === null)
                {
                    this._overflowTags = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, [((8/*InlineTags.Length*/ + 8/*OverflowAdditionalCapacity*/) | 0)], null);
                    ($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields)).CopyTo($.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._overflowTags));
                }
                if (!(this._overflowTags === null))
                {
                    if (this._tagsCount === this._overflowTags.length)
                    {
                        $.$spc.System.Array.Resize($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), $.$ref(() => this._overflowTags, ($v) => this._overflowTags = $v, $.$typeArray($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))), ((this._tagsCount + 8/*OverflowAdditionalCapacity*/) | 0));
                    }
                    $.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), this._overflowTags, index, ((this._tagsCount - index) | 0)).CopyTo($.$spc.System.MemoryExtensions.AsSpan($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), this._overflowTags, ((index + 1) | 0)));
                    $.$spc.System.Array.$WriteT1.call(this._overflowTags, item, index);
                }
                else 
                {
                    /*Span<KeyValuePair<string, object?>>*/ let tags = $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields);
                    tags.Slice$1(index, ((this._tagsCount - index) | 0)).CopyTo(tags.Slice(((index + 1) | 0)));
                    tags.get_Item(index).$v = item;
                }
                this._tagsCount++;
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.UInt32, (index >>> 0), (this._tagsCount >>> 0), "index");
                /*Span<KeyValuePair<string, object?>>*/ let tags = !(this._overflowTags === null) ? $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._overflowTags) : $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields);
                tags.Slice$1(((index + 1) | 0), ((((this._tagsCount - index) | 0) - 1) | 0)).CopyTo(tags.Slice(index));
                this._tagsCount--;
            }
            /*void */ Clear()
            {
                return this._tagsCount = 0;
            }
            /*bool */ Contains(/*KeyValuePair<string, object?>*/ item)
            {
                return this.IndexOf(item) >= 0;
            }
            /*bool */ Remove(/*KeyValuePair<string, object?>*/ item)
            {
                /*int*/ let index = this.IndexOf(item);
                if (index >= 0)
                {
                    this.RemoveAt(index);
                    return true;
                }
                return false;
            }
            /*IEnumerator<KeyValuePair<string, object?>> */ GetEnumerator()
            {
                return new $.$sdd.System.Diagnostics.TagList.Enumerator().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.TagList, () => this, ($v) => $v.Clone(this), null));
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return new $.$sdd.System.Diagnostics.TagList.Enumerator().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sdd.System.Diagnostics.TagList, () => this, ($v) => $v.Clone(this), null));
            }
            /*int */ IndexOf(/*KeyValuePair<string, object?>*/ item)
            {
                /*ReadOnlySpan<KeyValuePair<string, object?>>*/ let tags = !(this._overflowTags === null) ? $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._overflowTags) : $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields);
                tags = tags.Slice$1(0, this._tagsCount);
                if (!(item.Value === null))
                {
                    for(/*int*/ let i = 0; i < tags.Length; i++)
                    {
                        if ($.$spc.System.String.op_Equality(item.Key, tags.get_Item(i).$v.Key) && $.$spc.System.Object.Equals.call(item.Value, tags.get_Item(i).$v.Value))
                        {
                            return i;
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < tags.Length; i++)
                    {
                        if ($.$spc.System.String.op_Equality(item.Key, tags.get_Item(i).$v.Key) && tags.get_Item(i).$v.Value === null)
                        {
                            return i;
                        }
                    }
                }
                return -1;
            }
            /*ReadOnlySpan<KeyValuePair<string, object?>> */ get Tags()
            {
                return !(this._overflowTags === null) ? $.$spc.System.Span$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object), this._overflowTags, 0, this._tagsCount)) : ($.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).op_Implicit(this._tags.$fields)).Slice$1(0, this._tagsCount);
            }
            static $_InlineTags;
            static get InlineTags()
            {
                let $cls = $.$sdd.System.Diagnostics.TagList;
                return $cls.$_InlineTags ??= $asm.$nstr("$sdd.System.Diagnostics.TagList.InlineTags", ($self) => class InlineTags extends $.$spc.System.ValueType
                {
                    /*KeyValuePair<string, object?>*/  get _first() { return this.$getField(0, 8); }
                    /*KeyValuePair<string, object?>*/  set _first(value) { this.$setField(0, 8, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(8)
                        copy.$fields = [...this.$fields];
                        $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(System.Collections.Generic.KeyValuePair<string, object?>, 8)
                        for (let $i = 7; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))());
                        }
                        $.$spc.System.Array.AddMetadata(this.$fields, $.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), null, null)
                    }
                    static $h = 8912940;
                    static $z = 32;
                    static $f = 0b1000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":8781868,"h":8912940}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Diagnostics.TagList.InlineTags`; }
                }, $cls, ($v) => $cls.$_InlineTags = $v);
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sdd.System.Diagnostics.TagList;
                return $cls.$_Enumerator ??= $asm.$nstr("$sdd.System.Diagnostics.TagList.Enumerator", ($self) => class Enumerator extends $.$spc.System.ValueType
                {
                    /*TagList*/  get _tagList() { return this.$getField(0, 16); }
                    /*TagList*/  set _tagList(value) { this.$setField(0, 16, value); }
                    /*int*/  get _index() { return this.$getField(16, 4); }
                    /*int*/  set _index(value) { this.$setField(16, 4, value); }
                    $ctor$2(/*in TagList*/ tagList)
                    {
                        super.$ctor$1();
                        {
                            this._index = -1;
                            this._tagList = tagList.$v;
                        }
                        return this;
                    }
                    /*KeyValuePair<string, object?> */ get Current()
                    {
                        return this._tagList.get_Item(this._index);
                    }
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return this._tagList.get_Item(this._index);
                    }
                    /*void */ Dispose()
                    {
                        this._index = this._tagList.Count;
                    }
                    /*bool */ MoveNext()
                    {
                        this._index++;
                        return this._index < this._tagList.Count;
                    }
                    /*void */ Reset()
                    {
                        return this._index = -1;
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<string, object?>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._tagList = this._tagList.Clone();
                        copy._index = this._index;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._tagList = $.$default($.$sdd.System.Diagnostics.TagList);
                        this._index = 0;
                    }
                    static $h = 8847404;
                    static $z = 20;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":8781868,"h":8847404}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Diagnostics.TagList.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
            System$Collections$Generic$IList$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].set
            System$Collections$Generic$IList$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<string, object?>>.IndexOf(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$IList$$$IndexOf()
            {
                return this.IndexOf(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<string, object?>>.Insert(int, System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$IList$$$Insert()
            {
                return this.Insert(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IList<System.Collections.Generic.KeyValuePair<string, object?>>.RemoveAt(int)
            System$Collections$Generic$IList$$$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Add(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Contains(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.CopyTo(System.Collections.Generic.KeyValuePair<string, object?>[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Remove(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<System.Collections.Generic.KeyValuePair<string, object?>>.this[int].get
            System$Collections$Generic$IReadOnlyList$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object?>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(8)
                copy.$fields = [...this.$fields];
                $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                copy._overflowTags = this._overflowTags;
                copy._tagsCount = this._tagsCount;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tags = $.$default($.$sdd.System.Diagnostics.TagList.InlineTags);
                this._overflowTags = null;
                this._tagsCount = 0;
            }
            static $h = 8781868;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"h":8781868}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyList$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.TagList`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagnosticListener", ($self) => class DiagnosticListener extends $.$sdd.System.Diagnostics.DiagnosticSource
        {
            /*void */ OnActivityImport(/*Activity*/ activity, /*object?*/ payload)
            {
                for(/*DiagnosticSubscription?*/ let curSubscription = this._subscriptions; curSubscription !== null; curSubscription = curSubscription.Next)
                {
                    curSubscription.OnActivityImport?.Invoke(activity, payload);
                }
            }
            /*void */ OnActivityExport(/*Activity*/ activity, /*object?*/ payload)
            {
                for(/*DiagnosticSubscription?*/ let curSubscription = this._subscriptions; curSubscription !== null; curSubscription = curSubscription.Next)
                {
                    curSubscription.OnActivityExport?.Invoke(activity, payload);
                }
            }
            /*IDisposable */ Subscribe(/*IObserver<KeyValuePair<string, object?>>*/ observer, /*Func<string, object?, object?, bool>?*/ isEnabled, /*Action<Activity, object?>?*/ onActivityImport, /*Action<Activity, object?>?*/ onActivityExport)
            {
                return isEnabled === null ? this.SubscribeInternal(observer, null, null, onActivityImport, onActivityExport) : this.SubscribeInternal(observer, new ($.$spc.System.Predicate$$($.$spc.System.String))().$ctor(this,  (/*name*/ name) =>
                {
                    return this.IsEnabled$1(name, null, null);
                }, {"r":262145,"p":[{"n":"name","p":1310721}],"n":"","d":1966124,"h":0,"f":1048578}), isEnabled, onActivityImport, onActivityExport);
            }
            static /*IObservable<DiagnosticListener> */ get AllListeners()
            {
                return $.$sdd.System.Diagnostics.DiagnosticListener.s_allListenerObservable ?? $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable, $.$ref(() => $.$sdd.System.Diagnostics.DiagnosticListener.s_allListenerObservable, ($v) => $.$sdd.System.Diagnostics.DiagnosticListener.s_allListenerObservable = $v, $.$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable), new $.$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable().$ctor$1(), null) ?? $.$sdd.System.Diagnostics.DiagnosticListener.s_allListenerObservable;
            }
            /*IDisposable */ Subscribe$1(/*IObserver<KeyValuePair<string, object?>>*/ observer, /*Predicate<string>?*/ isEnabled)
            {
                /*IDisposable*/ let subscription;
                if (isEnabled === null)
                {
                    subscription = this.SubscribeInternal(observer, null, null, null, null);
                }
                else 
                {
                    /*Predicate<string>*/ let localIsEnabled = isEnabled;
                    subscription = this.SubscribeInternal(observer, isEnabled, new ($.$spc.System.Func$$$$$($.$spc.System.String, $.$spc.System.Object, $.$spc.System.Object, $.$spc.System.Boolean))().$ctor(this,  (/**/ name, /*arg1*/ arg1, /*arg2*/ arg2) =>
                    {
                        return localIsEnabled.Invoke(name);
                    }, {"r":262145,"p":[{"n":"name","p":1310721},{"n":"arg1","p":131073},{"n":"arg2","p":131073}],"n":"","d":1966124,"h":0,"f":1048578}), null, null);
                }
                return subscription;
            }
            /*IDisposable */ Subscribe$2(/*IObserver<KeyValuePair<string, object?>>*/ observer, /*Func<string, object?, object?, bool>?*/ isEnabled)
            {
                return isEnabled === null ? this.SubscribeInternal(observer, null, null, null, null) : this.SubscribeInternal(observer, new ($.$spc.System.Predicate$$($.$spc.System.String))().$ctor(this,  (/*name*/ name) =>
                {
                    return this.IsEnabled$1(name, null, null);
                }, {"r":262145,"p":[{"n":"name","p":1310721}],"n":"","d":1966124,"h":0,"f":1048578}), isEnabled, null, null);
            }
            /*IDisposable */ Subscribe$3(/*IObserver<KeyValuePair<string, object?>>*/ observer)
            {
                return this.SubscribeInternal(observer, null, null, null, null);
            }
            $ctor$2(/*string*/ name)
            {
                super.$ctor$1();
                {
                    this.Name = name;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                        {
                            $.$sdd.System.Diagnostics.DiagnosticListener.s_allListenerObservable?.OnNewDiagnosticListener(this);
                            this._next = $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners;
                            $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners = this;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                    }
                    $.$spc.System.GC.KeepAlive($.$sdd.System.Diagnostics.DiagnosticSourceEventSource.Log);
                }
                return this;
            }
            /*void */ Dispose()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                    {
                        if (this._disposed)
                        {
                            return;
                        }
                        this._disposed = true;
                        if ($.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners === this)
                        {
                            $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners = $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners._next;
                        }
                        else 
                        {
                            /*var*/ let cur = $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners;
                            while(cur !== null)
                            {
                                if (cur._next === this)
                                {
                                    cur._next = this._next;
                                    break;
                                }
                                cur = cur._next;
                            }
                        }
                        this._next = null;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                }
                /*DiagnosticSubscription?*/ let subscriber = null;
                subscriber = $.$spc.System.Threading.Interlocked.Exchange$14($.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription, $.$ref(() => this._subscriptions, ($v) => this._subscriptions = $v, $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription), subscriber);
                while(subscriber !== null)
                {
                    subscriber.Observer.System$IObserver$$$OnCompleted([$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                    subscriber = subscriber.Next;
                }
            }
            /*string*/ Name = null;
            static/*conventional*/ /*string */ ToString()
            {
                return this.Name ?? $.$spc.System.String.Empty;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdd.System.Diagnostics.DiagnosticListener.ToString.apply(this, arguments); }
            /*bool */ IsEnabled$2()
            {
                return this._subscriptions !== null;
            }
            /*bool */ IsEnabled(/*string*/ name)
            {
                for(/*DiagnosticSubscription?*/ let curSubscription = this._subscriptions; curSubscription !== null; curSubscription = curSubscription.Next)
                {
                    if (curSubscription.IsEnabled1Arg === null || curSubscription.IsEnabled1Arg.Invoke(name))
                    {
                        return true;
                    }
                }
                return false;
            }
            /*bool */ IsEnabled$1(/*string*/ name, /*object?*/ arg1, /*object?*/ arg2)
            {
                for(/*DiagnosticSubscription?*/ let curSubscription = this._subscriptions; curSubscription !== null; curSubscription = curSubscription.Next)
                {
                    if (curSubscription.IsEnabled3Arg === null || curSubscription.IsEnabled3Arg.Invoke(name, arg1, arg2))
                    {
                        return true;
                    }
                }
                return false;
            }
            /*void */ Write(/*string*/ name, /*object?*/ value)
            {
                for(/*DiagnosticSubscription?*/ let curSubscription = this._subscriptions; curSubscription !== null; curSubscription = curSubscription.Next)
                {
                    curSubscription.Observer.System$IObserver$$$OnNext(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(name, value), [$.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)]);
                }
            }
            static $_DiagnosticSubscription;
            static get DiagnosticSubscription()
            {
                let $cls = $.$sdd.System.Diagnostics.DiagnosticListener;
                return $cls.$_DiagnosticSubscription ??= $asm.$ncls("$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription", ($self) => class DiagnosticSubscription extends $.$spc.System.Object
                {
                    /*IObserver<KeyValuePair<string, object?>>*/ Observer = null;
                    /*Predicate<string>?*/ IsEnabled1Arg = null;
                    /*Func<string, object?, object?, bool>?*/ IsEnabled3Arg = null;
                    /*Action<Activity, object?>?*/ OnActivityImport = null;
                    /*Action<Activity, object?>?*/ OnActivityExport = null;
                    /*DiagnosticListener*/ Owner = null;
                    /*DiagnosticSubscription?*/ Next = null;
                    /*void */ Dispose()
                    {
                        while(true)
                        {
                            /*DiagnosticSubscription?*/ let subscriptions = this.Owner._subscriptions;
                            /*DiagnosticSubscription?*/ let newSubscriptions = $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription.Remove(subscriptions, this);
                            if ($.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription, $.$ref(() => this.Owner._subscriptions, ($v) => this.Owner._subscriptions = $v, $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription), newSubscriptions, subscriptions) === subscriptions)
                            {
                                /*var*/ let cur = newSubscriptions;
                                while(cur !== null)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(cur.Observer === this.Observer && cur.IsEnabled1Arg === this.IsEnabled1Arg && cur.IsEnabled3Arg === this.IsEnabled3Arg), "Did not remove subscription!");
                                    cur = cur.Next;
                                }
                                break;
                            }
                        }
                    }
                    static /*DiagnosticSubscription? */ Remove(/*DiagnosticSubscription?*/ subscriptions, /*DiagnosticSubscription*/ subscription)
                    {
                        if (subscriptions === null)
                        {
                            return null;
                        }
                        if (subscriptions.Observer === subscription.Observer && subscriptions.IsEnabled1Arg === subscription.IsEnabled1Arg && subscriptions.IsEnabled3Arg === subscription.IsEnabled3Arg)
                        {
                            return subscriptions.Next;
                        }
                        for(/*int*/ let i = 0; i < 100; i++)
                        {
                            $.$spc.System.GC.KeepAlive("");
                        }
                        return (() =>
                        {
                            //new $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription()
                            const $t1 = $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription;
                            const $i1 = new $t1();
                            $i1.Observer = subscriptions.Observer;
                            $i1.Owner = subscriptions.Owner;
                            $i1.IsEnabled1Arg = subscriptions.IsEnabled1Arg;
                            $i1.IsEnabled3Arg = subscriptions.IsEnabled3Arg;
                            $i1.Next = $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription.Remove(subscriptions.Next, subscription);
                            return $i1;
                        })();
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Observer = null;
                        this.Owner = null;
                    }
                    static $h = 2162732;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":1966124,"h":2162732}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                    static get $fullName() { return `System.Diagnostics.DiagnosticListener.DiagnosticSubscription`; }
                }, $cls, ($v) => $cls.$_DiagnosticSubscription = $v);
            }
            static $_AllListenerObservable;
            static get AllListenerObservable()
            {
                let $cls = $.$sdd.System.Diagnostics.DiagnosticListener;
                return $cls.$_AllListenerObservable ??= $asm.$ncls("$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable", ($self) => class AllListenerObservable extends $.$spc.System.Object
                {
                    /*IDisposable */ Subscribe(/*IObserver<DiagnosticListener>*/ observer)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                            {
                                for(/*DiagnosticListener?*/ let cur = $.$sdd.System.Diagnostics.DiagnosticListener.s_allListeners; cur !== null; cur = cur._next)
                                {
                                    observer.System$IObserver$$$OnNext(cur, [$.$sdd.System.Diagnostics.DiagnosticListener]);
                                }
                                this._subscriptions = new $.$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable.AllListenerSubscription().$ctor$1(this, observer, this._subscriptions);
                                return this._subscriptions;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                        }
                    }
                    /*void */ OnNewDiagnosticListener(/*DiagnosticListener*/ diagnosticListener)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Threading.Monitor.IsEntered($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock), "Monitor.IsEntered(s_allListenersLock)");
                        for(/*var*/ let cur = this._subscriptions; cur !== null; cur = cur.Next)
                        {
                            cur.Subscriber.System$IObserver$$$OnNext(diagnosticListener, [$.$sdd.System.Diagnostics.DiagnosticListener]);
                        }
                    }
                    /*bool */ Remove(/*AllListenerSubscription*/ subscription)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                            {
                                if (this._subscriptions === subscription)
                                {
                                    this._subscriptions = subscription.Next;
                                    return true;
                                }
                                else if (this._subscriptions !== null)
                                {
                                    for(/*var*/ let cur = this._subscriptions; cur.Next !== null; cur = cur.Next)
                                    {
                                        if (cur.Next === subscription)
                                        {
                                            cur.Next = cur.Next.Next;
                                            return true;
                                        }
                                    }
                                }
                                return false;
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdd.System.Diagnostics.DiagnosticListener.s_allListenersLock)
                        }
                    }
                    static $_AllListenerSubscription;
                    static get AllListenerSubscription()
                    {
                        let $cls = $.$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable;
                        return $cls.$_AllListenerSubscription ??= $asm.$ncls("$sdd.System.Diagnostics.DiagnosticListener.AllListenerObservable.AllListenerSubscription", ($self) => class AllListenerSubscription extends $.$spc.System.Object
                        {
                            $ctor$1(/*AllListenerObservable*/ owner, /*IObserver<DiagnosticListener>*/ subscriber, /*AllListenerSubscription?*/ next)
                            {
                                super.$ctor();
                                {
                                    this._owner = owner;
                                    this.Subscriber = subscriber;
                                    this.Next = next;
                                }
                                return this;
                            }
                            /*void */ Dispose()
                            {
                                if (this._owner.Remove(this))
                                {
                                    this.Subscriber.System$IObserver$$$OnCompleted([$.$sdd.System.Diagnostics.DiagnosticListener]);
                                }
                            }
                            /*AllListenerObservable*/ _owner = null;
                            /*IObserver<DiagnosticListener>*/ Subscriber = null;
                            /*AllListenerSubscription?*/ Next = null;
                            //Generated interface implemetation for System.IDisposable.Dispose()
                            System$IDisposable$Dispose()
                            {
                                return this.Dispose(...arguments);
                            }
                            static $h = 2097196;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"d":2031660,"h":2097196}; }
                            static get $b() { return $.$spc.System.Object; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
                            static get $fullName() { return `System.Diagnostics.DiagnosticListener.AllListenerObservable.AllListenerSubscription`; }
                        }, $cls, ($v) => $cls.$_AllListenerSubscription = $v);
                    }
                    /*AllListenerSubscription?*/ _subscriptions = null;
                    //Generated interface implemetation for System.IObservable<System.Diagnostics.DiagnosticListener>.Subscribe(System.IObserver<System.Diagnostics.DiagnosticListener>)
                    System$IObservable$$$Subscribe()
                    {
                        return this.Subscribe(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 2031660;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":1966124,"h":2031660}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IObservable$$($.$sdd.System.Diagnostics.DiagnosticListener) ]; }
                    static get $fullName() { return `System.Diagnostics.DiagnosticListener.AllListenerObservable`; }
                }, $cls, ($v) => $cls.$_AllListenerObservable = $v);
            }
            /*DiagnosticSubscription */ SubscribeInternal(/*IObserver<KeyValuePair<string, object?>>*/ observer, /*Predicate<string>?*/ isEnabled1Arg, /*Func<string, object?, object?, bool>?*/ isEnabled3Arg, /*Action<Activity, object?>?*/ onActivityImport, /*Action<Activity, object?>?*/ onActivityExport)
            {
                if (this._disposed)
                {
                    return (() =>
                    {
                        //new $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription()
                        const $t1 = $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription;
                        const $i1 = new $t1();
                        $i1.Owner = this;
                        return $i1;
                    })();
                }
                /*DiagnosticSubscription*/ let newSubscription = (() =>
                {
                    //new $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription()
                    const $t1 = $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription;
                    const $i1 = new $t1();
                    $i1.Observer = observer;
                    $i1.IsEnabled1Arg = isEnabled1Arg;
                    $i1.IsEnabled3Arg = isEnabled3Arg;
                    $i1.OnActivityImport = onActivityImport;
                    $i1.OnActivityExport = onActivityExport;
                    $i1.Owner = this;
                    $i1.Next = this._subscriptions;
                    return $i1;
                })();
                while($.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription, $.$ref(() => this._subscriptions, ($v) => this._subscriptions = $v, $.$sdd.System.Diagnostics.DiagnosticListener.DiagnosticSubscription), newSubscription, newSubscription.Next) !== newSubscription.Next)
                {
                    newSubscription.Next = this._subscriptions;
                }
                return newSubscription;
            }
            /*DiagnosticSubscription?*/ _subscriptions = null;
            /*DiagnosticListener?*/ _next = null;
            /*bool*/ _disposed = false;
            /*DiagnosticListener?*/ static s_allListeners = null;
            /*AllListenerObservable?*/ static s_allListenerObservable = null;
            /*object*/ static s_allListenersLock = null;
            //Generated interface implemetation for System.IObservable<System.Collections.Generic.KeyValuePair<string, object?>>.Subscribe(System.IObserver<System.Collections.Generic.KeyValuePair<string, object?>>)
            System$IObservable$$$Subscribe()
            {
                return this.Subscribe$3(...arguments);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_allListenersLock = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1966124;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2293804,"h":1966124}; }
            static get $b() { return $.$sdd.System.Diagnostics.DiagnosticSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IObservable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.DiagnosticListener`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.ActivityTagsCollection", ($self) => class ActivityTagsCollection extends $.$spc.System.Object
        {
            /*List<KeyValuePair<string, object?>>*/ _list = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*IEnumerable<KeyValuePair<string, object?>>*/ list)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(list, "list");
                    var $en3 = list.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var kvp = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if ($.$spc.System.String.op_Inequality(kvp.Key, null))
                            {
                                this.set_Item(kvp.Key, kvp.Value);
                            }
                        }
                    }
                }
                return this;
            }
            /*object?*/ get_Item(/*string*/ key)
            {
                /*int*/ let index = this.FindIndex(key);
                return index < 0 ? null : this._list.get_Item(index).Value;
            }
            /*void*/ set_Item(/*string*/ key, /*object?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let index = this.FindIndex(key);
                if (value === null)
                {
                    if (index >= 0)
                    {
                        this._list.RemoveAt(index);
                    }
                    return;
                }
                if (index >= 0)
                {
                    this._list.set_Item(index, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value));
                }
                else 
                {
                    this._list.Add(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value));
                }
            }
            /*ICollection<string> */ get Keys()
            {
                /*List<string>*/ let list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$2(this._list.Count);
                var $en2 = this._list.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        list.Add(kvp.Key);
                    }
                }
                return list;
            }
            /*ICollection<object?> */ get Values()
            {
                /*List<object?>*/ let list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$2(this._list.Count);
                var $en2 = this._list.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvp = $en2.Current;
                    {
                        list.Add(kvp.Value);
                    }
                }
                return list;
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*int */ get Count()
            {
                return this._list.Count;
            }
            /*void */ Add(/*string*/ key, /*object?*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let index = this.FindIndex(key);
                if (index >= 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.Format($.$sdd.System.SR.KeyAlreadyExist, key));
                }
                this._list.Add(new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object))().$ctor$2(key, value));
            }
            /*void */ Add$1(/*KeyValuePair<string, object?>*/ item)
            {
                if ($.$spc.System.String.op_Equality(item.Key, null))
                {
                    throw new $.$spc.System.ArgumentNullException().$ctor$16("item");
                }
                /*int*/ let index = this.FindIndex(item.Key);
                if (index >= 0)
                {
                    throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sdd.System.SR.Format($.$sdd.System.SR.KeyAlreadyExist, item.Key));
                }
                this._list.Add(item);
            }
            /*void */ Clear()
            {
                return this._list.Clear();
            }
            /*bool */ Contains(/*KeyValuePair<string, object?>*/ item)
            {
                return this._list.Contains(item);
            }
            /*bool */ ContainsKey(/*string*/ key)
            {
                return this.FindIndex(key) >= 0;
            }
            /*void */ CopyTo(/*KeyValuePair<string, object?>[]*/ array, /*int*/ arrayIndex)
            {
                return this._list.CopyTo$2(array, arrayIndex);
            }
            /*IEnumerator<KeyValuePair<string, object?>> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return new $.$sdd.System.Diagnostics.ActivityTagsCollection.Enumerator().$ctor$2(this._list);
            }
            /*Enumerator */ GetEnumerator()
            {
                return new $.$sdd.System.Diagnostics.ActivityTagsCollection.Enumerator().$ctor$2(this._list);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return new $.$sdd.System.Diagnostics.ActivityTagsCollection.Enumerator().$ctor$2(this._list);
            }
            /*bool */ Remove(/*string*/ key)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(key, "key");
                /*int*/ let index = this.FindIndex(key);
                if (index >= 0)
                {
                    this._list.RemoveAt(index);
                    return true;
                }
                return false;
            }
            /*bool */ Remove$1(/*KeyValuePair<string, object?>*/ item)
            {
                return this._list.Remove(item);
            }
            /*bool */ TryGetValue(/*string*/ key, /*out object?*/ value)
            {
                /*int*/ let index = this.FindIndex(key);
                if (index >= 0)
                {
                    value.$v = this._list.get_Item(index).Value;
                    return true;
                }
                value.$v = null;
                return false;
            }
            /*int */ FindIndex(/*string*/ key)
            {
                for(/*int*/ let i = 0; i < this._list.Count; i++)
                {
                    if ($.$spc.System.String.op_Equality(this._list.get_Item(i).Key, key))
                    {
                        return i;
                    }
                }
                return -1;
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sdd.System.Diagnostics.ActivityTagsCollection;
                return $cls.$_Enumerator ??= $asm.$nstr("$sdd.System.Diagnostics.ActivityTagsCollection.Enumerator", ($self) => class Enumerator extends $.$spc.System.ValueType
                {
                    /*List<KeyValuePair<string, object?>>.Enumerator*/  get _enumerator() { return this.$getField(0, 20); }
                    /*List<KeyValuePair<string, object?>>.Enumerator*/  set _enumerator(value) { this.$setField(0, 20, value); }
                    $ctor$2(/*List<KeyValuePair<string, object?>>*/ list)
                    {
                        super.$ctor$1();
                        this._enumerator = list.GetEnumerator();
                        return this;
                    }
                    /*KeyValuePair<string, object?> */ get Current()
                    {
                        return this._enumerator.Current;
                    }
                    /*object */ get System$Collections$IEnumerator$Current()
                    {
                        return (this._enumerator).System$Collections$IEnumerator$Current;
                    }
                    /*void */ Dispose()
                    {
                        return this._enumerator.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        return this._enumerator.MoveNext();
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        return (this._enumerator).System$Collections$IEnumerator$Reset();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<string, object?>>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._enumerator = this._enumerator.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._enumerator = $.$default($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)).Enumerator);
                    }
                    static $h = 1507372;
                    static $z = 20;
                    static $f = 0b10000001010000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":1441836,"h":1507372}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Diagnostics.ActivityTagsCollection.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.this[string].get
            System$Collections$Generic$IDictionary$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.this[string].set
            System$Collections$Generic$IDictionary$$$$set_Item()
            {
                return this.set_Item(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.Keys.get
            get System$Collections$Generic$IDictionary$$$$Keys()
            {
                return this.Keys;
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.Values.get
            get System$Collections$Generic$IDictionary$$$$Values()
            {
                return this.Values;
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.ContainsKey(string)
            System$Collections$Generic$IDictionary$$$$ContainsKey()
            {
                return this.ContainsKey(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.Add(string, object?)
            System$Collections$Generic$IDictionary$$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.Remove(string)
            System$Collections$Generic$IDictionary$$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IDictionary<string, object?>.TryGetValue(string, out object?)
            System$Collections$Generic$IDictionary$$$$TryGetValue()
            {
                return this.TryGetValue(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Add(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Contains(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.CopyTo(System.Collections.Generic.KeyValuePair<string, object?>[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<string, object?>>.Remove(System.Collections.Generic.KeyValuePair<string, object?>)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._list = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)))().$ctor$1();
            }
            static $h = 1441836;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1441836}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.Object), $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.Object)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ActivityTagsCollection`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.MetricsEventSource", ($self) => class MetricsEventSource extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*MetricsEventSource*/ static Log = null;
            static /*MetricsEventSource */ GetInstance()
            {
                return $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log;
            }
            /*string*/ static SharedSessionId = null;
            /*string*/ static ClientIdKey = null;
            /*string*/ static MaxHistogramsKey = null;
            /*string*/ static MaxTimeSeriesKey = null;
            /*string*/ static RefreshIntervalKey = null;
            /*string*/ static DefaultValueDescription = null;
            /*string*/ static SharedValueDescription = null;
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$sdd.System.Diagnostics.Metrics.MetricsEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$sdd.System.Diagnostics.Metrics.MetricsEventSource.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static Messages = 1n;
                    /*EventKeywords*/ static TimeSeriesValues = 2n;
                    /*EventKeywords*/ static InstrumentPublishing = 4n;
                    static $h = 6946860;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":6815788,"h":6946860}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Diagnostics.Metrics.MetricsEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            /*CommandHandler?*/ _handler = null;
            /*CommandHandler */ get Handler()
            {
                if (this._handler === null)
                {
                    $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler, $.$ref(() => this._handler, ($v) => this._handler = $v, $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler), new $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler().$ctor$1(this), null);
                }
                return this._handler;
            }
            $ctor$8()
            {
                super.$ctor$4();
                {
                }
                return this;
            }
            /*void */ Message(/*string?*/ Message)
            {
                this.WriteEvent$7(1, Message);
            }
            /*void */ CollectionStart(/*string*/ sessionId, /*DateTime*/ intervalStartTime, /*DateTime*/ intervalEndTime)
            {
                this.WriteEvent$17(2, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$16(intervalStartTime), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$16(intervalEndTime) ], null, null));
            }
            /*void */ CollectionStop(/*string*/ sessionId, /*DateTime*/ intervalStartTime, /*DateTime*/ intervalEndTime)
            {
                this.WriteEvent$17(3, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$16(intervalStartTime), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$16(intervalEndTime) ], null, null));
            }
            /*void */ CounterRateValuePublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string?*/ unit, /*string*/ tags, /*string*/ rate, /*string*/ value, /*int*/ instrumentId)
            {
                this.WriteEvent$17(4, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(tags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(rate), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(value), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId) ], null, null));
            }
            /*void */ GaugeValuePublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string?*/ unit, /*string*/ tags, /*string*/ lastValue, /*int*/ instrumentId)
            {
                this.WriteEvent$17(5, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(tags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(lastValue), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId) ], null, null));
            }
            /*void */ HistogramValuePublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string?*/ unit, /*string*/ tags, /*string*/ quantiles, /*int*/ count, /*double*/ sum, /*int*/ instrumentId)
            {
                this.WriteEvent$17(6, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(tags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(quantiles), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(count), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$11(sum), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId) ], null, null));
            }
            /*void */ BeginInstrumentReporting(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string*/ instrumentType, /*string?*/ unit, /*string?*/ description, /*string*/ instrumentTags, /*string*/ meterTags, /*string*/ meterScopeHash, /*int*/ instrumentId, /*string?*/ meterTelemetrySchemaUrl)
            {
                this.WriteEvent$17(7, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(description ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterScopeHash), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTelemetrySchemaUrl ?? "") ], null, null));
            }
            /*void */ EndInstrumentReporting(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string*/ instrumentType, /*string?*/ unit, /*string?*/ description, /*string*/ instrumentTags, /*string*/ meterTags, /*string*/ meterScopeHash, /*int*/ instrumentId, /*string?*/ meterTelemetrySchemaUrl)
            {
                this.WriteEvent$17(8, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(description ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterScopeHash), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTelemetrySchemaUrl ?? "") ], null, null));
            }
            /*void */ Error(/*string*/ sessionId, /*string*/ errorMessage)
            {
                this.WriteEvent$8(9, sessionId, errorMessage);
            }
            /*void */ InitialInstrumentEnumerationComplete(/*string*/ sessionId)
            {
                this.WriteEvent$7(10, sessionId);
            }
            /*void */ InstrumentPublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string*/ instrumentType, /*string?*/ unit, /*string?*/ description, /*string*/ instrumentTags, /*string*/ meterTags, /*string*/ meterScopeHash, /*int*/ instrumentId, /*string?*/ meterTelemetrySchemaUrl)
            {
                this.WriteEvent$17(11, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentType), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(description ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterScopeHash), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterTelemetrySchemaUrl ?? "") ], null, null));
            }
            /*void */ TimeSeriesLimitReached(/*string*/ sessionId)
            {
                this.WriteEvent$7(12, sessionId);
            }
            /*void */ HistogramLimitReached(/*string*/ sessionId)
            {
                this.WriteEvent$7(13, sessionId);
            }
            /*void */ ObservableInstrumentCallbackError(/*string*/ sessionId, /*string*/ errorMessage)
            {
                this.WriteEvent$8(14, sessionId, errorMessage);
            }
            /*void */ MultipleSessionsNotSupportedError(/*string*/ runningSessionId)
            {
                this.WriteEvent$7(15, runningSessionId);
            }
            /*void */ UpDownCounterRateValuePublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*string?*/ unit, /*string*/ tags, /*string*/ rate, /*string*/ value, /*int*/ instrumentId)
            {
                this.WriteEvent$17(16, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(tags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(rate), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(value), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId) ], null, null));
            }
            /*void */ MultipleSessionsConfiguredIncorrectlyError(/*string*/ clientId, /*string*/ expectedMaxHistograms, /*string*/ actualMaxHistograms, /*string*/ expectedMaxTimeSeries, /*string*/ actualMaxTimeSeries, /*string*/ expectedRefreshInterval, /*string*/ actualRefreshInterval)
            {
                this.WriteEvent$17(17, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(clientId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(expectedMaxHistograms), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(actualMaxHistograms), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(expectedMaxTimeSeries), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(actualMaxTimeSeries), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(expectedRefreshInterval), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(actualRefreshInterval) ], null, null));
            }
            /*void */ Version(/*int*/ Major, /*int*/ Minor, /*int*/ Patch)
            {
                this.WriteEvent$3(18, Major, Minor, Patch);
            }
            /*void */ Base2ExponentialHistogramValuePublished(/*string*/ sessionId, /*string*/ meterName, /*string?*/ meterVersion, /*string*/ instrumentName, /*int*/ instrumentId, /*string?*/ unit, /*string*/ tags, /*int*/ scale, /*double*/ sum, /*long*/ count, /*long*/ zeroCount, /*double*/ minimum, /*double*/ maximum, /*string*/ buckets)
            {
                this.WriteEvent$17(19, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive), [ $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(sessionId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(meterVersion ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(instrumentName), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(instrumentId), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(unit ?? ""), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(tags), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$3(scale), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$11(sum), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$4(count), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$4(zeroCount), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$11(minimum), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$11(maximum), $.$spc.System.Diagnostics.Tracing.EventSource.EventSourcePrimitive.op_Implicit$13(buckets) ], null, null));
            }
            /*void */ OnEventCommand(/*EventCommandEventArgs*/ command)
            {
                if (command.Command === -2/*EventCommand.Enable*/)
                {
                    this.Version($.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Major, $.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Minor, $.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Build);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        this.Handler.OnEventCommand(command);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            static $_CommandHandler;
            static get CommandHandler()
            {
                let $cls = $.$sdd.System.Diagnostics.Metrics.MetricsEventSource;
                return $cls.$_CommandHandler ??= $asm.$ncls("$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler", ($self) => class CommandHandler extends $.$spc.System.Object
                {
                    /*AggregationManager?*/ _aggregationManager = null;
                    /*string*/ _sessionId = null;
                    /*HashSet<string>*/ _sharedSessionClientIds = null;
                    /*int*/ _sharedSessionRefCount = 0;
                    /*bool*/ _disabledRefCount = false;
                    $ctor$1(/*MetricsEventSource*/ parent)
                    {
                        super.$ctor();
                        {
                            this.Parent = parent;
                        }
                        return this;
                    }
                    /*MetricsEventSource*/ Parent = null;
                    /*bool */ IsSharedSession(/*string*/ commandSessionId)
                    {
                        return $.$spc.System.String.Equals$2.call(this._sessionId, "SHARED"/*SharedSessionId*/) && ($.$spc.System.String.IsNullOrEmpty(commandSessionId) || $.$spc.System.String.Equals$2.call(commandSessionId, "SHARED"/*SharedSessionId*/));
                    }
                    /*void */ OnEventCommand(/*EventCommandEventArgs*/ command)
                    {
                        try
                        {
                            if ($.$spc.System.OperatingSystem.IsWasi())
                            {
                                this.Parent.Error("", "System.Diagnostics.Metrics EventSource not supported on wasi");
                                return;
                            }
                            /*string*/ let commandSessionId = this.GetSessionId(command);
                            if ((command.Command === 0/*EventCommand.Update*/ || command.Command === -3/*EventCommand.Disable*/ || command.Command === -2/*EventCommand.Enable*/) && this._aggregationManager !== null)
                            {
                                if (command.Command === 0/*EventCommand.Update*/ || command.Command === -2/*EventCommand.Enable*/)
                                {
                                    this.IncrementRefCount(commandSessionId, command);
                                }
                                if (this.IsSharedSession(commandSessionId))
                                {
                                    if (this.ShouldDisable(command.Command))
                                    {
                                        this.Parent.Message(`Previous session with id ${this._sessionId} is stopped`);
                                        this._aggregationManager.Dispose();
                                        this._aggregationManager = null;
                                        this._sessionId = $.$spc.System.String.Empty;
                                        this._sharedSessionClientIds.Clear();
                                        return;
                                    }
                                    /*bool*/ let validShared = true;
                                    /*double*/ let refreshInterval;
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(this._aggregationManager)
                                        {
                                            validShared = this.SetSharedRefreshIntervalSecs(command.Arguments, this._aggregationManager.CollectionPeriod.TotalSeconds, $.$ref(() => refreshInterval, ($v) => refreshInterval = $v, $.$spc.System.Double)) ? validShared : false;
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(this._aggregationManager)
                                    }
                                    /*int*/ let maxHistograms;
                                    validShared = this.SetSharedMaxHistograms(command.Arguments, this._aggregationManager.MaxHistograms, $.$ref(() => maxHistograms, ($v) => maxHistograms = $v, $.$spc.System.Int32)) ? validShared : false;
                                    /*int*/ let maxTimeSeries;
                                    validShared = this.SetSharedMaxTimeSeries(command.Arguments, this._aggregationManager.MaxTimeSeries, $.$ref(() => maxTimeSeries, ($v) => maxTimeSeries = $v, $.$spc.System.Int32)) ? validShared : false;
                                    if (command.Command !== -3/*EventCommand.Disable*/)
                                    {
                                        if (validShared)
                                        {
                                            /*string?*/ let metricsSpecs;
                                            if (this.ParseMetrics(command.Arguments, $.$ref(() => metricsSpecs, ($v) => metricsSpecs = $v, $.$spc.System.String)))
                                            {
                                                this.ParseSpecs(metricsSpecs);
                                                this._aggregationManager.Update();
                                            }
                                            /*string?*/ let base2ExponentialHistogramSpec;
                                            if (this.ParseBase2ExponentialHistogramSpecs(command.Arguments, $.$ref(() => base2ExponentialHistogramSpec, ($v) => base2ExponentialHistogramSpec = $v, $.$spc.System.String)))
                                            {
                                                this.ParseBase2ExponentialHistogram(base2ExponentialHistogramSpec);
                                            }
                                            return;
                                        }
                                        else 
                                        {
                                            /*string?*/ let clientId;
                                            if (command.Arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("ClientId"/*ClientIdKey*/, $.$ref(() => clientId, ($v) => clientId = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]))
                                            {
                                                //lock
                                                try
                                                {
                                                    $.$spc.System.Threading.Monitor.Enter(this._aggregationManager)
                                                    {
                                                        this.Parent.MultipleSessionsConfiguredIncorrectlyError(clientId, $.$spc.System.Int32.ToString.call(this._aggregationManager.MaxHistograms), $.$spc.System.Int32.ToString.call(maxHistograms), $.$spc.System.Int32.ToString.call(this._aggregationManager.MaxTimeSeries), $.$spc.System.Int32.ToString.call(maxTimeSeries), $.$spc.System.Double.ToString.call(this._aggregationManager.CollectionPeriod.TotalSeconds), $.$spc.System.Double.ToString.call(refreshInterval));
                                                    }
                                                }
                                                finally
                                                {
                                                    $.$spc.System.Threading.Monitor.Exit(this._aggregationManager)
                                                }
                                            }
                                            return;
                                        }
                                    }
                                }
                                else 
                                {
                                    if (command.Command === -2/*EventCommand.Enable*/ || command.Command === 0/*EventCommand.Update*/)
                                    {
                                        this.Parent.MultipleSessionsNotSupportedError(this._sessionId);
                                        return;
                                    }
                                    else if (this.ShouldDisable(command.Command))
                                    {
                                        this.Parent.Message(`Previous session with id ${this._sessionId} is stopped`);
                                        this._aggregationManager.Dispose();
                                        this._aggregationManager = null;
                                        this._sessionId = $.$spc.System.String.Empty;
                                        this._sharedSessionClientIds.Clear();
                                        return;
                                    }
                                }
                            }
                            if ((command.Command === 0/*EventCommand.Update*/ || command.Command === -2/*EventCommand.Enable*/) && command.Arguments !== null)
                            {
                                this.IncrementRefCount(commandSessionId, command);
                                this._sessionId = commandSessionId;
                                /*double*/ let defaultIntervalSecs = 1;
                                $.$spc.System.Diagnostics.Debug.Assert$1(0.1/*AggregationManager.MinCollectionTimeSecs*/ <= defaultIntervalSecs, "AggregationManager.MinCollectionTimeSecs <= defaultIntervalSecs");
                                /*double*/ let refreshIntervalSecs;
                                this.SetRefreshIntervalSecs(command.Arguments, 0.1/*AggregationManager.MinCollectionTimeSecs*/, defaultIntervalSecs, $.$ref(() => refreshIntervalSecs, ($v) => refreshIntervalSecs = $v, $.$spc.System.Double));
                                /*int*/ let defaultMaxTimeSeries = 1000;
                                /*int*/ let maxTimeSeries;
                                this.SetUniqueMaxTimeSeries(command.Arguments, defaultMaxTimeSeries, $.$ref(() => maxTimeSeries, ($v) => maxTimeSeries = $v, $.$spc.System.Int32));
                                /*int*/ let defaultMaxHistograms = 20;
                                /*int*/ let maxHistograms;
                                this.SetUniqueMaxHistograms(command.Arguments, defaultMaxHistograms, $.$ref(() => maxHistograms, ($v) => maxHistograms = $v, $.$spc.System.Int32));
                                /*string*/ let sessionId = this._sessionId;
                                this._aggregationManager = new $.$sdd.System.Diagnostics.Metrics.AggregationManager().$ctor$1(maxTimeSeries, maxHistograms, new ($.$spc.System.Action$$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics, $.$sdd.System.Diagnostics.Metrics.InstrumentState))().$ctor(this,  (/*i*/ i, /*s*/ s, /*state*/ state) =>
                                {
                                    return $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler.TransmitMetricValue(i, s, sessionId, state);
                                }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"s","p":5963820},{"n":"state","p":5701676}],"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$$($.$spc.System.DateTime, $.$spc.System.DateTime))().$ctor(this,  (/*startIntervalTime*/ startIntervalTime, /*endIntervalTime*/ endIntervalTime) =>
                                {
                                    return this.Parent.CollectionStart(sessionId, startIntervalTime, endIntervalTime);
                                }, {"r":65537,"p":[{"n":"startIntervalTime","p":34209793},{"n":"endIntervalTime","p":34209793}],"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$$($.$spc.System.DateTime, $.$spc.System.DateTime))().$ctor(this,  (/*startIntervalTime*/ startIntervalTime, /*endIntervalTime*/ endIntervalTime) =>
                                {
                                    return this.Parent.CollectionStop(sessionId, startIntervalTime, endIntervalTime);
                                }, {"r":65537,"p":[{"n":"startIntervalTime","p":34209793},{"n":"endIntervalTime","p":34209793}],"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.InstrumentState))().$ctor(this,  (/*i*/ i, /*state*/ state) =>
                                {
                                    return this.Parent.BeginInstrumentReporting(sessionId, i.Meter.Name, i.Meter.Version, i.Name, $.$spc.System.Object.GetType.call(i).Name, i.Unit, i.Description, $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Tags), $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Meter.Tags), $.$sdd.System.Diagnostics.Helpers.FormatObjectHash(i.Meter.Scope), state.ID, i.Meter.TelemetrySchemaUrl);
                                }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"state","p":5701676}],"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.InstrumentState))().$ctor(this,  (/*i*/ i, /*state*/ state) =>
                                {
                                    return this.Parent.EndInstrumentReporting(sessionId, i.Meter.Name, i.Meter.Version, i.Name, $.$spc.System.Object.GetType.call(i).Name, i.Unit, i.Description, $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Tags), $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Meter.Tags), $.$sdd.System.Diagnostics.Helpers.FormatObjectHash(i.Meter.Scope), state.ID, i.Meter.TelemetrySchemaUrl);
                                }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"state","p":5701676}],"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$$($.$sdd.System.Diagnostics.Metrics.Instrument, $.$sdd.System.Diagnostics.Metrics.InstrumentState))().$ctor(this,  (/*i*/ i, /*state*/ state) =>
                                {
                                    return this.Parent.InstrumentPublished(sessionId, i.Meter.Name, i.Meter.Version, i.Name, $.$spc.System.Object.GetType.call(i).Name, i.Unit, i.Description, $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Tags), $.$sdd.System.Diagnostics.Helpers.FormatTags(i.Meter.Tags), $.$sdd.System.Diagnostics.Helpers.FormatObjectHash(i.Meter.Scope), state === null ? 0 : state.ID, i.Meter.TelemetrySchemaUrl);
                                }, {"r":65537,"p":[{"n":"i","p":5505068},{"n":"state","p":5701676}],"n":"","d":6881324,"h":0,"f":1048578}), new $.$spc.System.Action().$ctor(this,  () =>
                                {
                                    return this.Parent.InitialInstrumentEnumerationComplete(sessionId);
                                }, {"r":65537,"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$($.$spc.System.Exception))().$ctor(this,  (/*e*/ e) =>
                                {
                                    return this.Parent.Error(sessionId, $.$spc.System.Exception.ToString.call(e));
                                }, {"r":65537,"p":[{"n":"e","p":47251457}],"n":"","d":6881324,"h":0,"f":1048578}), new $.$spc.System.Action().$ctor(this,  () =>
                                {
                                    return this.Parent.TimeSeriesLimitReached(sessionId);
                                }, {"r":65537,"n":"","d":6881324,"h":0,"f":1048578}), new $.$spc.System.Action().$ctor(this,  () =>
                                {
                                    return this.Parent.HistogramLimitReached(sessionId);
                                }, {"r":65537,"n":"","d":6881324,"h":0,"f":1048578}), new ($.$spc.System.Action$$($.$spc.System.Exception))().$ctor(this,  (/*e*/ e) =>
                                {
                                    return this.Parent.ObservableInstrumentCallbackError(sessionId, $.$spc.System.Exception.ToString.call(e));
                                }, {"r":65537,"p":[{"n":"e","p":47251457}],"n":"","d":6881324,"h":0,"f":1048578}));
                                this._aggregationManager.SetCollectionPeriod($.$spc.System.TimeSpan.FromSeconds$2(refreshIntervalSecs));
                                /*string?*/ let metricsSpecs;
                                if (this.ParseMetrics(command.Arguments, $.$ref(() => metricsSpecs, ($v) => metricsSpecs = $v, $.$spc.System.String)))
                                {
                                    this.ParseSpecs(metricsSpecs);
                                }
                                /*string?*/ let base2ExponentialHistogramSpec;
                                if (this.ParseBase2ExponentialHistogramSpecs(command.Arguments, $.$ref(() => base2ExponentialHistogramSpec, ($v) => base2ExponentialHistogramSpec = $v, $.$spc.System.String)))
                                {
                                    this.ParseBase2ExponentialHistogram(base2ExponentialHistogramSpec);
                                }
                                this._aggregationManager.Start();
                            }
                        }
                        catch(e)
                        {
                        }
                    }
                    /*bool */ ShouldDisable(/*EventCommand*/ command)
                    {
                        return command === -3/*EventCommand.Disable*/ && ((!this._disabledRefCount && $.$spc.System.Threading.Interlocked.Decrement($.$ref(() => this._sharedSessionRefCount, ($v) => this._sharedSessionRefCount = $v, $.$spc.System.Int32)) === 0) || !this.Parent.IsEnabled());
                    }
                    /*bool */ ParseMetrics(/*IDictionary<string, string>*/ $arguments, /*out string?*/ metricsSpecs)
                    {
                        if ($arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("Metrics", metricsSpecs, [$.$spc.System.String, $.$spc.System.String]))
                        {
                            this.Parent.Message(`Metrics argument received: ${metricsSpecs.$v}`);
                            return true;
                        }
                        this.Parent.Message("No Metrics argument received");
                        return false;
                    }
                    /*bool */ ParseBase2ExponentialHistogramSpecs(/*IDictionary<string, string>*/ $arguments, /*out string?*/ base2ExponentialHistogramSpec)
                    {
                        if ($arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("Base2ExponentialHistogram", base2ExponentialHistogramSpec, [$.$spc.System.String, $.$spc.System.String]))
                        {
                            this.Parent.Message(`Histogram Aggregation argument received: ${base2ExponentialHistogramSpec.$v}`);
                            return true;
                        }
                        this.Parent.Message("No Histogram Aggregation argument received");
                        return false;
                    }
                    /*void */ InvalidateRefCounting()
                    {
                        this._disabledRefCount = true;
                        this.Parent.Message(`${"ClientId"/*ClientIdKey*/} not provided; session will remain active indefinitely.`);
                    }
                    /*void */ IncrementRefCount(/*string*/ clientId, /*EventCommandEventArgs*/ command)
                    {
                        if ($.$spc.System.String.Equals$2.call(clientId, "SHARED"/*SharedSessionId*/))
                        {
                            /*string?*/ let clientIdArg;
                            if (command.Arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("ClientId"/*ClientIdKey*/, $.$ref(() => clientIdArg, ($v) => clientIdArg = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]) && !$.$spc.System.String.IsNullOrEmpty(clientIdArg))
                            {
                                clientId = clientIdArg;
                            }
                            else 
                            {
                                this.InvalidateRefCounting();
                            }
                        }
                        if (this._sharedSessionClientIds.Add(clientId))
                        {
                            $.$spc.System.Threading.Interlocked.Increment($.$ref(() => this._sharedSessionRefCount, ($v) => this._sharedSessionRefCount = $v, $.$spc.System.Int32));
                        }
                    }
                    /*bool */ SetSharedMaxTimeSeries(/*IDictionary<string, string>*/ $arguments, /*int*/ sharedValue, /*out int*/ maxTimeSeries)
                    {
                        return this.SetMaxValue($arguments, "MaxTimeSeries"/*MaxTimeSeriesKey*/, "shared value"/*SharedValueDescription*/, sharedValue, maxTimeSeries);
                    }
                    /*void */ SetUniqueMaxTimeSeries(/*IDictionary<string, string>*/ $arguments, /*int*/ defaultValue, /*out int*/ maxTimeSeries)
                    {
                        _ = this.SetMaxValue($arguments, "MaxTimeSeries"/*MaxTimeSeriesKey*/, "default"/*DefaultValueDescription*/, defaultValue, maxTimeSeries);
                    }
                    /*bool */ SetSharedMaxHistograms(/*IDictionary<string, string>*/ $arguments, /*int*/ sharedValue, /*out int*/ maxHistograms)
                    {
                        return this.SetMaxValue($arguments, "MaxHistograms"/*MaxHistogramsKey*/, "shared value"/*SharedValueDescription*/, sharedValue, maxHistograms);
                    }
                    /*void */ SetUniqueMaxHistograms(/*IDictionary<string, string>*/ $arguments, /*int*/ defaultValue, /*out int*/ maxHistograms)
                    {
                        _ = this.SetMaxValue($arguments, "MaxHistograms"/*MaxHistogramsKey*/, "default"/*DefaultValueDescription*/, defaultValue, maxHistograms);
                    }
                    /*bool */ SetMaxValue(/*IDictionary<string, string>*/ $arguments, /*string*/ argumentsKey, /*string*/ valueDescriptor, /*int*/ defaultValue, /*out int*/ maxValue)
                    {
                        /*string?*/ let maxString;
                        if ($arguments.System$Collections$Generic$IDictionary$$$$TryGetValue(argumentsKey, $.$ref(() => maxString, ($v) => maxString = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]))
                        {
                            this.Parent.Message(`${argumentsKey} argument received: ${maxString}`);
                            if (!$.$spc.System.Int32.TryParse(maxString, maxValue))
                            {
                                this.Parent.Message(`Failed to parse ${argumentsKey}. Using ${valueDescriptor} ${defaultValue}`);
                                maxValue.$v = defaultValue;
                            }
                            else if (maxValue.$v !== defaultValue)
                            {
                                return false;
                            }
                        }
                        else 
                        {
                            this.Parent.Message(`No ${argumentsKey} argument received. Using ${valueDescriptor} ${defaultValue}`);
                            maxValue.$v = defaultValue;
                        }
                        return true;
                    }
                    /*void */ SetRefreshIntervalSecs(/*IDictionary<string, string>*/ $arguments, /*double*/ minValue, /*double*/ defaultValue, /*out double*/ refreshIntervalSeconds)
                    {
                        if (this.GetRefreshIntervalSecs($arguments, "default"/*DefaultValueDescription*/, defaultValue, refreshIntervalSeconds) && refreshIntervalSeconds.$v < minValue)
                        {
                            this.Parent.Message(`${"RefreshInterval"/*RefreshIntervalKey*/} too small. Using minimum interval ${minValue} seconds.`);
                            refreshIntervalSeconds.$v = minValue;
                        }
                    }
                    /*bool */ SetSharedRefreshIntervalSecs(/*IDictionary<string, string>*/ $arguments, /*double*/ sharedValue, /*out double*/ refreshIntervalSeconds)
                    {
                        if (this.GetRefreshIntervalSecs($arguments, "shared value"/*SharedValueDescription*/, sharedValue, refreshIntervalSeconds) && refreshIntervalSeconds.$v !== sharedValue)
                        {
                            return false;
                        }
                        return true;
                    }
                    /*bool */ GetRefreshIntervalSecs(/*IDictionary<string, string>*/ $arguments, /*string*/ valueDescriptor, /*double*/ defaultValue, /*out double*/ refreshIntervalSeconds)
                    {
                        /*string?*/ let refreshInterval;
                        if ($arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("RefreshInterval"/*RefreshIntervalKey*/, $.$ref(() => refreshInterval, ($v) => refreshInterval = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]))
                        {
                            this.Parent.Message(`${"RefreshInterval"/*RefreshIntervalKey*/} argument received: ${refreshInterval}`);
                            if (!$.$spc.System.Double.TryParse(refreshInterval, refreshIntervalSeconds))
                            {
                                this.Parent.Message(`Failed to parse ${"RefreshInterval"/*RefreshIntervalKey*/}. Using ${valueDescriptor} ${defaultValue}s.`);
                                refreshIntervalSeconds.$v = defaultValue;
                                return false;
                            }
                        }
                        else 
                        {
                            this.Parent.Message(`No ${"RefreshInterval"/*RefreshIntervalKey*/} argument received. Using ${valueDescriptor} ${defaultValue}s.`);
                            refreshIntervalSeconds.$v = defaultValue;
                            return false;
                        }
                        return true;
                    }
                    /*string */ GetSessionId(/*EventCommandEventArgs*/ command)
                    {
                        /*string?*/ let id;
                        if (command.Arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("SessionId", $.$ref(() => id, ($v) => id = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]))
                        {
                            this.Parent.Message(`SessionId argument received: ${id}`);
                            return id;
                        }
                        /*string*/ let sessionId = $.$spc.System.String.Empty;
                        if (command.Command !== -3/*EventCommand.Disable*/)
                        {
                            sessionId = $.$spc.System.Guid.ToString.call($.$spc.System.Guid.NewGuid());
                            this.Parent.Message(`New session started. SessionId auto-generated: ${sessionId}`);
                        }
                        return sessionId;
                    }
                    /*bool */ LogError(/*Exception*/ e)
                    {
                        this.Parent.Error(this._sessionId, $.$spc.System.Exception.ToString.call(e));
                        return false;
                    }
                    /*char[]*/ static s_instrumentSeparators = null;
                    /*char[]*/ Base2ExponentialHistogramSpecSeparators = null;
                    /*char*/ static HistogramPartSeparator = /*=*/ 61;
                    /*void */ ParseSpecs(/*string?*/ metricsSpecs)
                    {
                        if ($.$spc.System.String.op_Equality(metricsSpecs, null))
                        {
                            return;
                        }
                        /*string[]*/ let specStrings = $.$spc.System.String.Split$5.call(metricsSpecs, $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler.s_instrumentSeparators, 1/*StringSplitOptions.RemoveEmptyEntries*/);
                        let $i1 = 0;
                        let $arr1 = specStrings;
                        while ($i1 < $arr1.length)
                        {
                            let specString = $arr1[$i1++];
                            /*MetricSpec*/ let spec = $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec.Parse(specString);
                            this.Parent.Message(`Parsed metric: ${$.$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec.ToString.call(spec)}`);
                            if ($.$spc.System.String.op_Inequality(spec.InstrumentName, null))
                            {
                                this._aggregationManager.Include$1(spec.MeterName, spec.InstrumentName);
                            }
                            else if (spec.MeterName.length > 0 && $.$spc.System.String.get_Chars.call(spec.MeterName, ((spec.MeterName.length - 1) | 0)) === /***/ 42)
                            {
                                if (spec.MeterName.length === 1)
                                {
                                    this._aggregationManager.IncludeAll();
                                }
                                else 
                                {
                                    this._aggregationManager.IncludePrefix($.$spc.System.String.Substring$1.call(spec.MeterName, 0, ((spec.MeterName.length - 1) | 0)));
                                }
                            }
                            else 
                            {
                                this._aggregationManager.Include(spec.MeterName);
                            }
                        }
                    }
                    /*void */ ParseBase2ExponentialHistogram(/*string?*/ base2ExponentialHistogramSpec)
                    {
                        if ($.$spc.System.String.op_Equality(base2ExponentialHistogramSpec, null))
                        {
                            return;
                        }
                        /*string[]*/ let specStrings = $.$spc.System.String.Split$5.call(base2ExponentialHistogramSpec, this.Base2ExponentialHistogramSpecSeparators, 1/*StringSplitOptions.RemoveEmptyEntries*/);
                        if (specStrings.length === 0)
                        {
                            this.Parent.Message("No histogram aggregation spec is provided");
                            return;
                        }
                        /*int*/ let scale = 20;
                        /*int*/ let maxBuckets = 160;
                        /*bool*/ let reportDeltas = false;
                        let $i1 = 0;
                        let $arr1 = specStrings;
                        while ($i1 < $arr1.length)
                        {
                            let specString = $arr1[$i1++];
                            /*int*/ let index = $.$spc.System.String.IndexOf.call(specString, /*=*/ 61);
                            if (index < 0)
                            {
                                this.Parent.Message(`Invalid histogram aggregation spec: ${specString}`);
                                continue;
                            }
                            /*ReadOnlySpan<char>*/ let spec = $.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$7(specString, 0, index));
                            /*ReadOnlySpan<char>*/ let value = $.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$4(specString, ((index + 1) | 0)));
                            if ($.$spc.System.MemoryExtensions.Equals$2(spec, $.$spc.System.String.op_Implicit("scale"), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                /*int*/ let s;
                                if (!$.$spc.System.Int32.TryParse$4(value, 7/*NumberStyles.Integer*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => s, ($v) => s = $v, $.$spc.System.Int32)) || s < -11 || s > 20)
                                {
                                    this.Parent.Message(`Invalid scale value: ${specString}`);
                                    continue;
                                }
                                else 
                                {
                                    scale = s;
                                }
                            }
                            else if ($.$spc.System.MemoryExtensions.Equals$2(spec, $.$spc.System.String.op_Implicit("maxBuckets"), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                /*int*/ let m;
                                if (!$.$spc.System.Int32.TryParse$4(value, 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => m, ($v) => m = $v, $.$spc.System.Int32)) || m < 2)
                                {
                                    this.Parent.Message(`Invalid maxBuckets value: ${specString}`);
                                    continue;
                                }
                                else 
                                {
                                    maxBuckets = m;
                                }
                            }
                            else if ($.$spc.System.MemoryExtensions.Equals$2(spec, $.$spc.System.String.op_Implicit("reportDeltas"), 5/*StringComparison.OrdinalIgnoreCase*/))
                            {
                                if ($.$spc.System.MemoryExtensions.Equals$2(value, $.$spc.System.String.op_Implicit("true"), 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    reportDeltas = true;
                                }
                                else if ($.$spc.System.MemoryExtensions.Equals$2(value, $.$spc.System.String.op_Implicit("false"), 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    reportDeltas = false;
                                }
                                else 
                                {
                                    this.Parent.Message(`Invalid reportDeltas value: ${specString}`);
                                    continue;
                                }
                            }
                        }
                        this._aggregationManager.SetHistogramAggregation(new ($.$spc.System.Func$$($.$sdd.System.Diagnostics.Metrics.Aggregator))().$ctor(this,  () =>
                        {
                            return new $.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramAggregator().$ctor$2(maxBuckets, scale, reportDeltas);
                        }, {"r":4325420,"n":"","d":6881324,"h":0,"f":1048578}));
                    }
                    static /*void */ TransmitMetricValue(/*Instrument*/ instrument, /*LabeledAggregationStatistics*/ stats, /*string*/ sessionId, /*InstrumentState?*/ instrumentState)
                    {
                        /*int*/ let instrumentId = (instrumentState?.ID ?? null) ?? 0;
                        let rateStats;
                        let lastValueStats;
                        let synchronousLastValueStats;
                        let histogramStats;
                        let base2ExponentialHistogramStats;
                        if ($.$is(stats.AggregationStatistics, $.$sdd.System.Diagnostics.Metrics.CounterStatistics, { set $v(v){ rateStats = v; } }))
                        {
                            if (rateStats.IsMonotonic)
                            {
                                $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.CounterRateValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), $.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(rateStats.Delta) ? $.$spc.System.Double.ToString$2.call($.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(rateStats.Delta), $.$spc.System.Globalization.CultureInfo.InvariantCulture) : "", $.$spc.System.Double.ToString$2.call(rateStats.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture), instrumentId);
                            }
                            else 
                            {
                                $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.UpDownCounterRateValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), $.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(rateStats.Delta) ? $.$spc.System.Double.ToString$2.call($.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(rateStats.Delta), $.$spc.System.Globalization.CultureInfo.InvariantCulture) : "", $.$spc.System.Double.ToString$2.call(rateStats.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture), instrumentId);
                            }
                        }
                        else if ($.$is(stats.AggregationStatistics, $.$sdd.System.Diagnostics.Metrics.LastValueStatistics, { set $v(v){ lastValueStats = v; } }))
                        {
                            $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.GaugeValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), $.$spc.System.Nullable$$($.$spc.System.Double).HasValue$get.call(lastValueStats.LastValue) ? $.$spc.System.Double.ToString$2.call($.$spc.System.Nullable$$($.$spc.System.Double).Value$get.call(lastValueStats.LastValue), $.$spc.System.Globalization.CultureInfo.InvariantCulture) : "", instrumentId);
                        }
                        else if ($.$is(stats.AggregationStatistics, $.$sdd.System.Diagnostics.Metrics.SynchronousLastValueStatistics, { set $v(v){ synchronousLastValueStats = v; } }))
                        {
                            $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.GaugeValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), $.$spc.System.Double.ToString$2.call(synchronousLastValueStats.LastValue, $.$spc.System.Globalization.CultureInfo.InvariantCulture), instrumentId);
                        }
                        else if ($.$is(stats.AggregationStatistics, $.$sdd.System.Diagnostics.Metrics.HistogramStatistics, { set $v(v){ histogramStats = v; } }))
                        {
                            $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.HistogramValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler.FormatQuantiles(histogramStats.Quantiles), histogramStats.Count, histogramStats.Sum, instrumentId);
                        }
                        else if ($.$is(stats.AggregationStatistics, $.$sdd.System.Diagnostics.Metrics.Base2ExponentialHistogramStatistics, { set $v(v){ base2ExponentialHistogramStats = v; } }))
                        {
                            $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.Log.Base2ExponentialHistogramValuePublished(sessionId, instrument.Meter.Name, instrument.Meter.Version, instrument.Name, instrumentId, instrument.Unit, $.$sdd.System.Diagnostics.Helpers.FormatTags$1(stats.Labels), base2ExponentialHistogramStats.Scale, base2ExponentialHistogramStats.Sum, base2ExponentialHistogramStats.Count, base2ExponentialHistogramStats.ZeroCount, base2ExponentialHistogramStats.Minimum, base2ExponentialHistogramStats.Maximum, $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.CommandHandler.FormatBuckets(base2ExponentialHistogramStats.PositiveBuckets));
                        }
                    }
                    static /*string */ FormatBuckets(/*long[]*/ buckets)
                    {
                        /*ValueStringBuilder*/ let sb = new $.$sdd.System.Text.ValueStringBuilder().$ctor$2($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 512, null));
                        if (buckets.length > 0)
                        {
                            sb.Append$1(`${$.$spc.System.Array.$ReadT1.call(buckets, 0)}`);
                        }
                        for(/*int*/ let i = 1; i < buckets.length; i++)
                        {
                            sb.Append$1(`, ${$.$spc.System.Array.$ReadT1.call(buckets, i)}`);
                        }
                        return $.$sdd.System.Text.ValueStringBuilder.ToString.call(sb);
                    }
                    static /*string */ FormatQuantiles(/*QuantileValue[]*/ quantiles)
                    {
                        /*StringBuilder*/ let sb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                        for(/*int*/ let i = 0; i < quantiles.length; i++)
                        {
                            sb.Append$24($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$spc.System.Array.$ReadT1.call(quantiles, i).Quantile}=${$.$spc.System.Array.$ReadT1.call(quantiles, i).Value}`);
                            if (i !== ((quantiles.length - 1) | 0))
                            {
                                sb.Append$7(/*;*/ 59);
                            }
                        }
                        return $.$spc.System.Text.StringBuilder.ToString.call(sb);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._sessionId = "";
                        this._sharedSessionClientIds = new ($.$spc.System.Collections.Generic.HashSet$$($.$spc.System.String))().$ctor$1();
                        this.Base2ExponentialHistogramSpecSeparators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Char.$type, [ /*;*/ 59 ], null, null);
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.s_instrumentSeparators = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/*\r*/ 13, /*\n*/ 10, /*,*/ 44, /*;*/ 59], [-1], null);
                        }
                    }
                    static $h = 6881324;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":6815788,"h":6881324}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Diagnostics.Metrics.MetricsEventSource.CommandHandler`; }
                }, $cls, ($v) => $cls.$_CommandHandler = $v);
            }
            static $_MetricSpec;
            static get MetricSpec()
            {
                let $cls = $.$sdd.System.Diagnostics.Metrics.MetricsEventSource;
                return $cls.$_MetricSpec ??= $asm.$ncls("$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec", ($self) => class MetricSpec extends $.$spc.System.Object
                {
                    /*char*/ static MeterInstrumentSeparator = /*\\*/ 92;
                    /*string*/ MeterName = null;
                    /*string?*/ InstrumentName = null;
                    $ctor$1(/*string*/ meterName, /*string?*/ instrumentName)
                    {
                        super.$ctor();
                        {
                            this.MeterName = meterName;
                            this.InstrumentName = instrumentName;
                        }
                        return this;
                    }
                    static /*MetricSpec */ Parse(/*string*/ text)
                    {
                        /*int*/ let slashIdx = $.$spc.System.String.IndexOf.call(text, /*\\*/ 92);
                        if (slashIdx < 0)
                        {
                            return new $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec().$ctor$1($.$spc.System.String.Trim.call(text), null);
                        }
                        else 
                        {
                            /*string*/ let meterName = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$7(text, 0, slashIdx)));
                            /*string?*/ let instrumentName = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$4(text, ((slashIdx + 1) | 0))));
                            return new $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec().$ctor$1(meterName, instrumentName);
                        }
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return $.$spc.System.String.op_Inequality(this.InstrumentName, null) ? this.MeterName + /*\\*/ 92 + this.InstrumentName : this.MeterName;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$sdd.System.Diagnostics.Metrics.MetricsEventSource.MetricSpec.ToString.apply(this, arguments); }
                    static $h = 7012396;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":6815788,"h":7012396}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Diagnostics.Metrics.MetricsEventSource.MetricSpec`; }
                }, $cls, ($v) => $cls.$_MetricSpec = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$sdd.System.Diagnostics.Metrics.MetricsEventSource().$ctor$8();
                }
                {
                    this.SharedSessionId = "SHARED";
                }
                {
                    this.ClientIdKey = "ClientId";
                }
                {
                    this.MaxHistogramsKey = "MaxHistograms";
                }
                {
                    this.MaxTimeSeriesKey = "MaxTimeSeries";
                }
                {
                    this.RefreshIntervalKey = "RefreshInterval";
                }
                {
                    this.DefaultValueDescription = "default";
                }
                {
                    this.SharedValueDescription = "shared value";
                }
            }
            static $h = 6815788;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"h":6815788}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.MetricsEventSource`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.DiagnosticSourceEventSource", ($self) => class DiagnosticSourceEventSource extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*DiagnosticSourceEventSource*/ static Log = null;
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$sdd.System.Diagnostics.DiagnosticSourceEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$sdd.System.Diagnostics.DiagnosticSourceEventSource.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static Messages = 1n;
                    /*EventKeywords*/ static Events = 2n;
                    /*EventKeywords*/ static IgnoreShortCutKeywords = 2048n;
                    /*EventKeywords*/ static AspNetCoreHosting = 4096n;
                    /*EventKeywords*/ static EntityFrameworkCoreCommands = 8192n;
                    static $h = 2424876;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"d":2359340,"h":2424876}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Diagnostics.DiagnosticSourceEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            /*string*/ AspNetCoreHostingKeywordValue = null;
            /*string*/ EntityFrameworkCoreCommandsKeywordValue = null;
            /*void */ Message(/*string?*/ Message)
            {
                this.WriteEvent$7(1, Message);
            }
            /*void */ Event(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>?*/ Arguments)
            {
                this.WriteEvent$18(2, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ EventJson(/*string*/ SourceName, /*string*/ EventName, /*string*/ ArgmentsJson)
            {
                this.WriteEvent$9(3, SourceName, EventName, ArgmentsJson);
            }
            /*void */ Activity1Start(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(4, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ Activity1Stop(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(5, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ Activity2Start(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(6, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ Activity2Stop(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(7, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ RecursiveActivity1Start(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(8, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ RecursiveActivity1Stop(/*string*/ SourceName, /*string*/ EventName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                this.WriteEvent$18(9, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, EventName, Arguments ], null, null));
            }
            /*void */ NewDiagnosticListener(/*string*/ SourceName)
            {
                this.WriteEvent$7(10, SourceName);
            }
            /*void */ ActivityStart(/*string*/ SourceName, /*string*/ ActivityName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                return this.WriteEvent$18(11, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, ActivityName, Arguments ], null, null));
            }
            /*void */ ActivityStop(/*string*/ SourceName, /*string*/ ActivityName, /*IEnumerable<KeyValuePair<string, string?>>*/ Arguments)
            {
                return this.WriteEvent$18(12, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ SourceName, ActivityName, Arguments ], null, null));
            }
            /*void */ Version(/*int*/ Major, /*int*/ Minor, /*int*/ Patch)
            {
                this.WriteEvent$3(13, Major, Minor, Patch);
            }
            /*void */ OnEventCommand(/*EventCommandEventArgs*/ command)
            {
                if (command.Command === -2/*EventCommand.Enable*/)
                {
                    this.Version($.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Major, $.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Minor, $.$sdd.System.Diagnostics.ThisAssembly.AssemblyFileVersion.Build);
                }
                this.BreakPointWithDebuggerFuncEval();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this)
                    {
                        if ((command.Command === 0/*EventCommand.Update*/ || command.Command === -2/*EventCommand.Enable*/) && this.IsEnabled$1(4/*EventLevel.Informational*/, 2n))
                        {
                            /*string?*/ let filterAndPayloadSpecs = null;
                            command.Arguments.System$Collections$Generic$IDictionary$$$$TryGetValue("FilterAndPayloadSpecs", $.$ref(() => filterAndPayloadSpecs, ($v) => filterAndPayloadSpecs = $v, $.$spc.System.String), [$.$spc.System.String, $.$spc.System.String]);
                            if (!this.IsEnabled$1(4/*EventLevel.Informational*/, 2048n))
                            {
                                if (this.IsEnabled$1(4/*EventLevel.Informational*/, 4096n))
                                {
                                    filterAndPayloadSpecs = $.$sdd.System.Diagnostics.DiagnosticSourceEventSource.NewLineSeparate(filterAndPayloadSpecs, this.AspNetCoreHostingKeywordValue);
                                }
                                if (this.IsEnabled$1(4/*EventLevel.Informational*/, 8192n))
                                {
                                    filterAndPayloadSpecs = $.$sdd.System.Diagnostics.DiagnosticSourceEventSource.NewLineSeparate(filterAndPayloadSpecs, this.EntityFrameworkCoreCommandsKeywordValue);
                                }
                            }
                            this._listener?.System$IDisposable$Dispose();
                            this._listener = $.$sdd.System.Diagnostics.DsesFilterAndTransform.ParseFilterAndPayloadSpecs(this, filterAndPayloadSpecs);
                        }
                        else if (command.Command === 0/*EventCommand.Update*/ || command.Command === -3/*EventCommand.Disable*/)
                        {
                            this._listener?.System$IDisposable$Dispose();
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this)
                }
            }
            $ctor$8()
            {
                super.$ctor$6(8/*EventSourceSettings.EtwSelfDescribingEventFormat*/);
                {
                }
                return this;
            }
            static /*string */ NewLineSeparate(/*string?*/ str1, /*string*/ str2)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(str2, null), "str2 != null");
                if ($.$spc.System.String.IsNullOrEmpty(str1))
                {
                    return str2;
                }
                return str1 + "\n" + str2;
            }
            /*IDisposable?*/ _listener = null;
            /*bool*/ _false = false;
            /*void */ BreakPointWithDebuggerFuncEval()
            {
                new $.$spc.System.Object().$ctor();
                while(this._false)
                {
                    this._false = false;
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this.AspNetCoreHostingKeywordValue = "Microsoft.AspNetCore/Microsoft.AspNetCore.Hosting.BeginRequest@Activity1Start:-httpContext.Request.Method;httpContext.Request.Host;httpContext.Request.Path;httpContext.Request.QueryString\nMicrosoft.AspNetCore/Microsoft.AspNetCore.Hosting.EndRequest@Activity1Stop:-httpContext.TraceIdentifier;httpContext.Response.StatusCode";
                this.EntityFrameworkCoreCommandsKeywordValue = "Microsoft.EntityFrameworkCore/Microsoft.EntityFrameworkCore.BeforeExecuteCommand@Activity2Start:-Command.Connection.DataSource;Command.Connection.Database;Command.CommandText\nMicrosoft.EntityFrameworkCore/Microsoft.EntityFrameworkCore.AfterExecuteCommand@Activity2Stop:-";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Log = new $.$sdd.System.Diagnostics.DiagnosticSourceEventSource().$ctor$8();
                }
            }
            static $h = 2359340;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"h":2359340}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.DiagnosticSourceEventSource`; }
        });
        
        $asm.$cls("$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary<,,>", (TStringSequence, TObjectSequence, TAggregator) => $asm.$gt("$sdd.System.Diagnostics.Metrics.FixedSizeLabelNameDictionary<,,>", [TStringSequence, TObjectSequence, TAggregator], ($self) => class FixedSizeLabelNameDictionary$$$$ extends $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator))
        {
            /*void */ Collect(/*Action<LabeledAggregationStatistics>*/ visitFunc)
            {
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var kvName = $en2.Current;
                    {
                        /*Span<string>*/ let indexedNames = $.$dsp(kvName.Key, TStringSequence, ($t) => $t.System$Diagnostics$Metrics$IStringSequence$AsSpan,);
                        var $en4 = kvName.Value.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var kvValue = $en4.Current;
                            {
                                /*Span<object?>*/ let indexedValues = $.$dsp(kvValue.Key, TObjectSequence, ($t) => $t.System$Diagnostics$Metrics$IObjectSequence$AsSpan,);
                                /*KeyValuePair<string, string>[]*/ let labels = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String)), null, [indexedNames.Length], null);
                                for(/*int*/ let i = 0; i < labels.length; i++)
                                {
                                    const $t1 = () => indexedValues.get_Item(i).$v;
                                    $.$spc.System.Array.$WriteT1.call(labels, new ($.$spc.System.Collections.Generic.KeyValuePair$$$($.$spc.System.String, $.$spc.System.String))().$ctor$2(indexedNames.get_Item(i).$v, $.$ifnn($t1, ($t) => $.$spc.System.Object.ToString.call($t)) ?? ""), i);
                                }
                                /*IAggregationStatistics*/ let stats = $.$dsp(kvValue.Value, TAggregator, ($t) => $t.Collect,);
                                visitFunc.Invoke(new $.$sdd.System.Diagnostics.Metrics.LabeledAggregationStatistics().$ctor$1(stats, labels));
                            }
                        }
                    }
                }
            }
            /*ConcurrentDictionary<TObjectSequence, TAggregator> */ GetValuesDictionary(/*in TStringSequence*/ names)
            {
                return this.GetOrAdd(names.$v, new ($.$spc.System.Func$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator)))().$ctor(this,  (/**/ _0) =>
                {
                    return new ($.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator))().$ctor$1();
                }, {"r":$.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator).$h,"p":[{"n":"_","p":TStringSequence?.$h??1507328}],"n":"","d":this.$h,"h":0,"f":1048578}));
            }
            //default reference type constructor overload
            $ctor$8()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 5111852;
            static $g = 3;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":3,"h":this.$h}; }
            static get $b() { return $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator)); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IDictionary$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator)), $.$spc.System.Collections.Generic.ICollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator))), $.$spc.System.Collections.IDictionary, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.Generic.IReadOnlyDictionary$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator))), $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TStringSequence, $.$scc.System.Collections.Concurrent.ConcurrentDictionary$$$(TObjectSequence, TAggregator))), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.Metrics.FixedSizeLabelNameDictionary<${TStringSequence?.$fullName},${TObjectSequence?.$fullName},${TAggregator?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool"))