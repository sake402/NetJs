
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":42254,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 107790;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885009678,"f":1},"n":"Comments","d":107790,"h":8590042382,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474944270,"f":1},"n":"CompanyName","d":107790,"h":17179976974,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064878862,"f":1},"n":"FileBuildPart","d":107790,"h":25769911566,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654813454,"f":1},"n":"FileDescription","d":107790,"h":34359846158,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244748046,"f":1},"n":"FileMajorPart","d":107790,"h":42949780750,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834682638,"f":1},"n":"FileMinorPart","d":107790,"h":51539715342,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424617230,"f":1},"n":"FileName","d":107790,"h":60129649934,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014551822,"f":1},"n":"FilePrivatePart","d":107790,"h":68719584526,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604486414,"f":1},"n":"FileVersion","d":107790,"h":77309519118,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194421006,"f":1},"n":"InternalName","d":107790,"h":85899453710,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784355598,"f":1},"n":"IsDebug","d":107790,"h":94489388302,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374290190,"f":1},"n":"IsPatched","d":107790,"h":103079322894,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964224782,"f":1},"n":"IsPreRelease","d":107790,"h":111669257486,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554159374,"f":1},"n":"IsPrivateBuild","d":107790,"h":120259192078,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144093966,"f":1},"n":"IsSpecialBuild","d":107790,"h":128849126670,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734028558,"f":1},"n":"Language","d":107790,"h":137439061262,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323963150,"f":1},"n":"LegalCopyright","d":107790,"h":146028995854,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913897742,"f":1},"n":"LegalTrademarks","d":107790,"h":154618930446,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503832334,"f":1},"n":"OriginalFilename","d":107790,"h":163208865038,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093766926,"f":1},"n":"PrivateBuild","d":107790,"h":171798799630,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683701518,"f":1},"n":"ProductBuildPart","d":107790,"h":180388734222,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273636110,"f":1},"n":"ProductMajorPart","d":107790,"h":188978668814,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863570702,"f":1},"n":"ProductMinorPart","d":107790,"h":197568603406,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453505294,"f":1},"n":"ProductName","d":107790,"h":206158537998,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043439886,"f":1},"n":"ProductPrivatePart","d":107790,"h":214748472590,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633374478,"f":1},"n":"ProductVersion","d":107790,"h":223338407182,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223309070,"f":1},"n":"SpecialBuild","d":107790,"h":231928341774,"f":1}],"m":[{"r":107790,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":107790,"h":240518276366,"f":33},{"r":1310721,"n":"ToString","d":107790,"h":244813243662,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":107790,"h":4295075086,"f":8}],"h":107790}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))