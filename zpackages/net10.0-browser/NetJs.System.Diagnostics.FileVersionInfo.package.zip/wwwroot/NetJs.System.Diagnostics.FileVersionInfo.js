
//--TRIMMABLE-BOUNDARY-START(78)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {
  "h": 78,
  "f": "System.Diagnostics.FileVersionInfo",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.FileVersionInfo",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.FileVersionInfo",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65614)
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032910)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032910)
            
            //--TRIMMABLE-BOUNDARY-START(8590000206)
            /*string? */ get Comments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673166);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000206)
            
            //--TRIMMABLE-BOUNDARY-START(12884967502)
            /*string? */ get CompanyName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967502)
            
            //--TRIMMABLE-BOUNDARY-START(17179934798)
            /*int */ get FileBuildPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542350);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934798)
            
            //--TRIMMABLE-BOUNDARY-START(21474902094)
            /*string? */ get FileDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476942);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21474902094)
            
            //--TRIMMABLE-BOUNDARY-START(25769869390)
            /*int */ get FileMajorPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411534);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25769869390)
            
            //--TRIMMABLE-BOUNDARY-START(30064836686)
            /*int */ get FileMinorPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346126);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064836686)
            
            //--TRIMMABLE-BOUNDARY-START(34359803982)
            /*string */ get FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079280718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359803982)
            
            //--TRIMMABLE-BOUNDARY-START(38654771278)
            /*int */ get FilePrivatePart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215310);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654771278)
            
            //--TRIMMABLE-BOUNDARY-START(42949738574)
            /*string? */ get FileVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259149902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949738574)
            
            //--TRIMMABLE-BOUNDARY-START(283467907150)
            /*string? */ get InternalName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849084494);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(283467907150)
            
            //--TRIMMABLE-BOUNDARY-START(287762874446)
            /*bool */ get IsDebug()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439019086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(287762874446)
            
            //--TRIMMABLE-BOUNDARY-START(292057841742)
            /*bool */ get IsPatched()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146028953678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292057841742)
            
            //--TRIMMABLE-BOUNDARY-START(296352809038)
            /*bool */ get IsPreRelease()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154618888270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296352809038)
            
            //--TRIMMABLE-BOUNDARY-START(300647776334)
            /*bool */ get IsPrivateBuild()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163208822862);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(300647776334)
            
            //--TRIMMABLE-BOUNDARY-START(304942743630)
            /*bool */ get IsSpecialBuild()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798757454);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(304942743630)
            
            //--TRIMMABLE-BOUNDARY-START(309237710926)
            /*string? */ get Language()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388692046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(309237710926)
            
            //--TRIMMABLE-BOUNDARY-START(313532678222)
            /*string? */ get LegalCopyright()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978626638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(313532678222)
            
            //--TRIMMABLE-BOUNDARY-START(317827645518)
            /*string? */ get LegalTrademarks()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(317827645518)
            
            //--TRIMMABLE-BOUNDARY-START(322122612814)
            /*string? */ get OriginalFilename()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158495822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(322122612814)
            
            //--TRIMMABLE-BOUNDARY-START(326417580110)
            /*string? */ get PrivateBuild()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748430414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(326417580110)
            
            //--TRIMMABLE-BOUNDARY-START(330712547406)
            /*int */ get ProductBuildPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338365006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(330712547406)
            
            //--TRIMMABLE-BOUNDARY-START(335007514702)
            /*int */ get ProductMajorPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(335007514702)
            
            //--TRIMMABLE-BOUNDARY-START(339302481998)
            /*int */ get ProductMinorPart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518234190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(339302481998)
            
            //--TRIMMABLE-BOUNDARY-START(343597449294)
            /*string? */ get ProductName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108168782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(343597449294)
            
            //--TRIMMABLE-BOUNDARY-START(347892416590)
            /*int */ get ProductPrivatePart()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698103374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(347892416590)
            
            //--TRIMMABLE-BOUNDARY-START(352187383886)
            /*string? */ get ProductVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288037966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(352187383886)
            
            //--TRIMMABLE-BOUNDARY-START(356482351182)
            /*string? */ get SpecialBuild()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274877972558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(356482351182)
            
            //--TRIMMABLE-BOUNDARY-START(279172939854)
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279172939854);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279172939854)
            
            //--TRIMMABLE-BOUNDARY-START(360777318478)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777318478);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(360777318478)
            
            static $h = 65614;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590000206),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539673166,
        "f": 50331649
      },
      "n": "Comments",
      "d": 65614,
      "h": 8590000206,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590000206),
//--TRIMMABLE-BOUNDARY-START(12884967502),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129607758,
        "f": 50331649
      },
      "n": "CompanyName",
      "d": 65614,
      "h": 12884967502,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12884967502),
//--TRIMMABLE-BOUNDARY-START(17179934798),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719542350,
        "f": 50331649
      },
      "n": "FileBuildPart",
      "d": 65614,
      "h": 17179934798,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934798),
//--TRIMMABLE-BOUNDARY-START(21474902094),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309476942,
        "f": 50331649
      },
      "n": "FileDescription",
      "d": 65614,
      "h": 21474902094,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474902094),
//--TRIMMABLE-BOUNDARY-START(25769869390),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899411534,
        "f": 50331649
      },
      "n": "FileMajorPart",
      "d": 65614,
      "h": 25769869390,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25769869390),
//--TRIMMABLE-BOUNDARY-START(30064836686),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489346126,
        "f": 50331649
      },
      "n": "FileMinorPart",
      "d": 65614,
      "h": 30064836686,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064836686),
//--TRIMMABLE-BOUNDARY-START(34359803982),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079280718,
        "f": 50331649
      },
      "n": "FileName",
      "d": 65614,
      "h": 34359803982,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34359803982),
//--TRIMMABLE-BOUNDARY-START(38654771278),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669215310,
        "f": 50331649
      },
      "n": "FilePrivatePart",
      "d": 65614,
      "h": 38654771278,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654771278),
//--TRIMMABLE-BOUNDARY-START(42949738574),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259149902,
        "f": 50331649
      },
      "n": "FileVersion",
      "d": 65614,
      "h": 42949738574,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949738574),
//--TRIMMABLE-BOUNDARY-START(283467907150),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849084494,
        "f": 50331649
      },
      "n": "InternalName",
      "d": 65614,
      "h": 283467907150,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283467907150),
//--TRIMMABLE-BOUNDARY-START(287762874446),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439019086,
        "f": 50331649
      },
      "n": "IsDebug",
      "d": 65614,
      "h": 287762874446,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287762874446),
//--TRIMMABLE-BOUNDARY-START(292057841742),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146028953678,
        "f": 50331649
      },
      "n": "IsPatched",
      "d": 65614,
      "h": 292057841742,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292057841742),
//--TRIMMABLE-BOUNDARY-START(296352809038),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154618888270,
        "f": 50331649
      },
      "n": "IsPreRelease",
      "d": 65614,
      "h": 296352809038,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352809038),
//--TRIMMABLE-BOUNDARY-START(300647776334),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163208822862,
        "f": 50331649
      },
      "n": "IsPrivateBuild",
      "d": 65614,
      "h": 300647776334,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300647776334),
//--TRIMMABLE-BOUNDARY-START(304942743630),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171798757454,
        "f": 50331649
      },
      "n": "IsSpecialBuild",
      "d": 65614,
      "h": 304942743630,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304942743630),
//--TRIMMABLE-BOUNDARY-START(309237710926),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180388692046,
        "f": 50331649
      },
      "n": "Language",
      "d": 65614,
      "h": 309237710926,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309237710926),
//--TRIMMABLE-BOUNDARY-START(313532678222),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978626638,
        "f": 50331649
      },
      "n": "LegalCopyright",
      "d": 65614,
      "h": 313532678222,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313532678222),
//--TRIMMABLE-BOUNDARY-START(317827645518),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568561230,
        "f": 50331649
      },
      "n": "LegalTrademarks",
      "d": 65614,
      "h": 317827645518,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(317827645518),
//--TRIMMABLE-BOUNDARY-START(322122612814),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158495822,
        "f": 50331649
      },
      "n": "OriginalFilename",
      "d": 65614,
      "h": 322122612814,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322122612814),
//--TRIMMABLE-BOUNDARY-START(326417580110),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748430414,
        "f": 50331649
      },
      "n": "PrivateBuild",
      "d": 65614,
      "h": 326417580110,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326417580110),
//--TRIMMABLE-BOUNDARY-START(330712547406),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338365006,
        "f": 50331649
      },
      "n": "ProductBuildPart",
      "d": 65614,
      "h": 330712547406,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(330712547406),
//--TRIMMABLE-BOUNDARY-START(335007514702),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928299598,
        "f": 50331649
      },
      "n": "ProductMajorPart",
      "d": 65614,
      "h": 335007514702,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(335007514702),
//--TRIMMABLE-BOUNDARY-START(339302481998),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518234190,
        "f": 50331649
      },
      "n": "ProductMinorPart",
      "d": 65614,
      "h": 339302481998,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(339302481998),
//--TRIMMABLE-BOUNDARY-START(343597449294),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108168782,
        "f": 50331649
      },
      "n": "ProductName",
      "d": 65614,
      "h": 343597449294,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(343597449294),
//--TRIMMABLE-BOUNDARY-START(347892416590),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698103374,
        "f": 50331649
      },
      "n": "ProductPrivatePart",
      "d": 65614,
      "h": 347892416590,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347892416590),
//--TRIMMABLE-BOUNDARY-START(352187383886),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288037966,
        "f": 50331649
      },
      "n": "ProductVersion",
      "d": 65614,
      "h": 352187383886,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(352187383886),
//--TRIMMABLE-BOUNDARY-START(356482351182),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274877972558,
        "f": 50331649
      },
      "n": "SpecialBuild",
      "d": 65614,
      "h": 356482351182,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482351182)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(279172939854),
    {
      "r": 65614,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "GetVersionInfo",
      "d": 65614,
      "h": 279172939854,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(279172939854),
//--TRIMMABLE-BOUNDARY-START(360777318478),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65614,
      "h": 360777318478,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(360777318478)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032910),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65614,
      "h": 4295032910,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295032910)
  ],
  "h": 65614
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65614)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))
//--TRIMMABLE-BOUNDARY-END(78)
