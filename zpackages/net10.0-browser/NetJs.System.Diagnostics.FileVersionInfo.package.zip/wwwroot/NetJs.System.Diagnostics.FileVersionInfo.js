
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":51058,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 116594;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885018482,"f":50331649},"n":"Comments","d":116594,"h":8590051186,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":21474953074,"f":50331649},"n":"CompanyName","d":116594,"h":17179985778,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30064887666,"f":50331649},"n":"FileBuildPart","d":116594,"h":25769920370,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38654822258,"f":50331649},"n":"FileDescription","d":116594,"h":34359854962,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47244756850,"f":50331649},"n":"FileMajorPart","d":116594,"h":42949789554,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":55834691442,"f":50331649},"n":"FileMinorPart","d":116594,"h":51539724146,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":64424626034,"f":50331649},"n":"FileName","d":116594,"h":60129658738,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":73014560626,"f":50331649},"n":"FilePrivatePart","d":116594,"h":68719593330,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":81604495218,"f":50331649},"n":"FileVersion","d":116594,"h":77309527922,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":90194429810,"f":50331649},"n":"InternalName","d":116594,"h":85899462514,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":98784364402,"f":50331649},"n":"IsDebug","d":116594,"h":94489397106,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":107374298994,"f":50331649},"n":"IsPatched","d":116594,"h":103079331698,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":115964233586,"f":50331649},"n":"IsPreRelease","d":116594,"h":111669266290,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":124554168178,"f":50331649},"n":"IsPrivateBuild","d":116594,"h":120259200882,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":133144102770,"f":50331649},"n":"IsSpecialBuild","d":116594,"h":128849135474,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":141734037362,"f":50331649},"n":"Language","d":116594,"h":137439070066,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":150323971954,"f":50331649},"n":"LegalCopyright","d":116594,"h":146029004658,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":158913906546,"f":50331649},"n":"LegalTrademarks","d":116594,"h":154618939250,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":167503841138,"f":50331649},"n":"OriginalFilename","d":116594,"h":163208873842,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":176093775730,"f":50331649},"n":"PrivateBuild","d":116594,"h":171798808434,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":184683710322,"f":50331649},"n":"ProductBuildPart","d":116594,"h":180388743026,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":193273644914,"f":50331649},"n":"ProductMajorPart","d":116594,"h":188978677618,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":201863579506,"f":50331649},"n":"ProductMinorPart","d":116594,"h":197568612210,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":210453514098,"f":50331649},"n":"ProductName","d":116594,"h":206158546802,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":219043448690,"f":50331649},"n":"ProductPrivatePart","d":116594,"h":214748481394,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":227633383282,"f":50331649},"n":"ProductVersion","d":116594,"h":223338415986,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":236223317874,"f":50331649},"n":"SpecialBuild","d":116594,"h":231928350578,"f":2097153}],"m":[{"r":116594,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":116594,"h":240518285170,"f":16777249},{"r":1310721,"n":"ToString","d":116594,"h":244813252466,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$1","d":116594,"h":4295083890,"f":16777224}],"h":116594}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))