
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":37386,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 102922;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885004810,"f":1},"n":"Comments","d":102922,"h":8590037514,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474939402,"f":1},"n":"CompanyName","d":102922,"h":17179972106,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064873994,"f":1},"n":"FileBuildPart","d":102922,"h":25769906698,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654808586,"f":1},"n":"FileDescription","d":102922,"h":34359841290,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244743178,"f":1},"n":"FileMajorPart","d":102922,"h":42949775882,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834677770,"f":1},"n":"FileMinorPart","d":102922,"h":51539710474,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424612362,"f":1},"n":"FileName","d":102922,"h":60129645066,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014546954,"f":1},"n":"FilePrivatePart","d":102922,"h":68719579658,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604481546,"f":1},"n":"FileVersion","d":102922,"h":77309514250,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194416138,"f":1},"n":"InternalName","d":102922,"h":85899448842,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784350730,"f":1},"n":"IsDebug","d":102922,"h":94489383434,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374285322,"f":1},"n":"IsPatched","d":102922,"h":103079318026,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964219914,"f":1},"n":"IsPreRelease","d":102922,"h":111669252618,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554154506,"f":1},"n":"IsPrivateBuild","d":102922,"h":120259187210,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144089098,"f":1},"n":"IsSpecialBuild","d":102922,"h":128849121802,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734023690,"f":1},"n":"Language","d":102922,"h":137439056394,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323958282,"f":1},"n":"LegalCopyright","d":102922,"h":146028990986,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913892874,"f":1},"n":"LegalTrademarks","d":102922,"h":154618925578,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503827466,"f":1},"n":"OriginalFilename","d":102922,"h":163208860170,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093762058,"f":1},"n":"PrivateBuild","d":102922,"h":171798794762,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683696650,"f":1},"n":"ProductBuildPart","d":102922,"h":180388729354,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273631242,"f":1},"n":"ProductMajorPart","d":102922,"h":188978663946,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863565834,"f":1},"n":"ProductMinorPart","d":102922,"h":197568598538,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453500426,"f":1},"n":"ProductName","d":102922,"h":206158533130,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043435018,"f":1},"n":"ProductPrivatePart","d":102922,"h":214748467722,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633369610,"f":1},"n":"ProductVersion","d":102922,"h":223338402314,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223304202,"f":1},"n":"SpecialBuild","d":102922,"h":231928336906,"f":1}],"m":[{"r":102922,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":102922,"h":240518271498,"f":33},{"r":1310721,"n":"ToString","d":102922,"h":244813238794,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":102922,"h":4295070218,"f":8}],"h":102922}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))