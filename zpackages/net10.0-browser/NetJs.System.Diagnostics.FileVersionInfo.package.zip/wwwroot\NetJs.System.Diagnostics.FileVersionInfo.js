
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":58408,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 123944;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885025832,"f":1},"n":"Comments","d":123944,"h":8590058536,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474960424,"f":1},"n":"CompanyName","d":123944,"h":17179993128,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064895016,"f":1},"n":"FileBuildPart","d":123944,"h":25769927720,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654829608,"f":1},"n":"FileDescription","d":123944,"h":34359862312,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244764200,"f":1},"n":"FileMajorPart","d":123944,"h":42949796904,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834698792,"f":1},"n":"FileMinorPart","d":123944,"h":51539731496,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424633384,"f":1},"n":"FileName","d":123944,"h":60129666088,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014567976,"f":1},"n":"FilePrivatePart","d":123944,"h":68719600680,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604502568,"f":1},"n":"FileVersion","d":123944,"h":77309535272,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194437160,"f":1},"n":"InternalName","d":123944,"h":85899469864,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784371752,"f":1},"n":"IsDebug","d":123944,"h":94489404456,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374306344,"f":1},"n":"IsPatched","d":123944,"h":103079339048,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964240936,"f":1},"n":"IsPreRelease","d":123944,"h":111669273640,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554175528,"f":1},"n":"IsPrivateBuild","d":123944,"h":120259208232,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144110120,"f":1},"n":"IsSpecialBuild","d":123944,"h":128849142824,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734044712,"f":1},"n":"Language","d":123944,"h":137439077416,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323979304,"f":1},"n":"LegalCopyright","d":123944,"h":146029012008,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913913896,"f":1},"n":"LegalTrademarks","d":123944,"h":154618946600,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503848488,"f":1},"n":"OriginalFilename","d":123944,"h":163208881192,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093783080,"f":1},"n":"PrivateBuild","d":123944,"h":171798815784,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683717672,"f":1},"n":"ProductBuildPart","d":123944,"h":180388750376,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273652264,"f":1},"n":"ProductMajorPart","d":123944,"h":188978684968,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863586856,"f":1},"n":"ProductMinorPart","d":123944,"h":197568619560,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453521448,"f":1},"n":"ProductName","d":123944,"h":206158554152,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043456040,"f":1},"n":"ProductPrivatePart","d":123944,"h":214748488744,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633390632,"f":1},"n":"ProductVersion","d":123944,"h":223338423336,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223325224,"f":1},"n":"SpecialBuild","d":123944,"h":231928357928,"f":1}],"m":[{"r":123944,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":123944,"h":240518292520,"f":33},{"r":1310721,"n":"ToString","d":123944,"h":244813259816,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":123944,"h":4295091240,"f":8}],"h":123944}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))