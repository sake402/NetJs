
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":39000,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 104536;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885006424,"f":1},"n":"Comments","d":104536,"h":8590039128,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474941016,"f":1},"n":"CompanyName","d":104536,"h":17179973720,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064875608,"f":1},"n":"FileBuildPart","d":104536,"h":25769908312,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654810200,"f":1},"n":"FileDescription","d":104536,"h":34359842904,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244744792,"f":1},"n":"FileMajorPart","d":104536,"h":42949777496,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834679384,"f":1},"n":"FileMinorPart","d":104536,"h":51539712088,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424613976,"f":1},"n":"FileName","d":104536,"h":60129646680,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014548568,"f":1},"n":"FilePrivatePart","d":104536,"h":68719581272,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604483160,"f":1},"n":"FileVersion","d":104536,"h":77309515864,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194417752,"f":1},"n":"InternalName","d":104536,"h":85899450456,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784352344,"f":1},"n":"IsDebug","d":104536,"h":94489385048,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374286936,"f":1},"n":"IsPatched","d":104536,"h":103079319640,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964221528,"f":1},"n":"IsPreRelease","d":104536,"h":111669254232,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554156120,"f":1},"n":"IsPrivateBuild","d":104536,"h":120259188824,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144090712,"f":1},"n":"IsSpecialBuild","d":104536,"h":128849123416,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734025304,"f":1},"n":"Language","d":104536,"h":137439058008,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323959896,"f":1},"n":"LegalCopyright","d":104536,"h":146028992600,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913894488,"f":1},"n":"LegalTrademarks","d":104536,"h":154618927192,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503829080,"f":1},"n":"OriginalFilename","d":104536,"h":163208861784,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093763672,"f":1},"n":"PrivateBuild","d":104536,"h":171798796376,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683698264,"f":1},"n":"ProductBuildPart","d":104536,"h":180388730968,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273632856,"f":1},"n":"ProductMajorPart","d":104536,"h":188978665560,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863567448,"f":1},"n":"ProductMinorPart","d":104536,"h":197568600152,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453502040,"f":1},"n":"ProductName","d":104536,"h":206158534744,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043436632,"f":1},"n":"ProductPrivatePart","d":104536,"h":214748469336,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633371224,"f":1},"n":"ProductVersion","d":104536,"h":223338403928,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223305816,"f":1},"n":"SpecialBuild","d":104536,"h":231928338520,"f":1}],"m":[{"r":104536,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":104536,"h":240518273112,"f":33},{"r":1310721,"n":"ToString","d":104536,"h":244813240408,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":104536,"h":4295071832,"f":8}],"h":104536}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))