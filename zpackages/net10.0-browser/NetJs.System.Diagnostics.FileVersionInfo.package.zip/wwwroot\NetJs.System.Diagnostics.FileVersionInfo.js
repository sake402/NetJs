
(function ($global, $, $spc, $sc, $sdt, $sm, $spu, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":47045,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 112581;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885014469,"f":1},"n":"Comments","d":112581,"h":8590047173,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474949061,"f":1},"n":"CompanyName","d":112581,"h":17179981765,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064883653,"f":1},"n":"FileBuildPart","d":112581,"h":25769916357,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654818245,"f":1},"n":"FileDescription","d":112581,"h":34359850949,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244752837,"f":1},"n":"FileMajorPart","d":112581,"h":42949785541,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834687429,"f":1},"n":"FileMinorPart","d":112581,"h":51539720133,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424622021,"f":1},"n":"FileName","d":112581,"h":60129654725,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014556613,"f":1},"n":"FilePrivatePart","d":112581,"h":68719589317,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604491205,"f":1},"n":"FileVersion","d":112581,"h":77309523909,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194425797,"f":1},"n":"InternalName","d":112581,"h":85899458501,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784360389,"f":1},"n":"IsDebug","d":112581,"h":94489393093,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374294981,"f":1},"n":"IsPatched","d":112581,"h":103079327685,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964229573,"f":1},"n":"IsPreRelease","d":112581,"h":111669262277,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554164165,"f":1},"n":"IsPrivateBuild","d":112581,"h":120259196869,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144098757,"f":1},"n":"IsSpecialBuild","d":112581,"h":128849131461,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734033349,"f":1},"n":"Language","d":112581,"h":137439066053,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323967941,"f":1},"n":"LegalCopyright","d":112581,"h":146029000645,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913902533,"f":1},"n":"LegalTrademarks","d":112581,"h":154618935237,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503837125,"f":1},"n":"OriginalFilename","d":112581,"h":163208869829,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093771717,"f":1},"n":"PrivateBuild","d":112581,"h":171798804421,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683706309,"f":1},"n":"ProductBuildPart","d":112581,"h":180388739013,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273640901,"f":1},"n":"ProductMajorPart","d":112581,"h":188978673605,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863575493,"f":1},"n":"ProductMinorPart","d":112581,"h":197568608197,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453510085,"f":1},"n":"ProductName","d":112581,"h":206158542789,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043444677,"f":1},"n":"ProductPrivatePart","d":112581,"h":214748477381,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633379269,"f":1},"n":"ProductVersion","d":112581,"h":223338411973,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223313861,"f":1},"n":"SpecialBuild","d":112581,"h":231928346565,"f":1}],"m":[{"r":112581,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":112581,"h":240518281157,"f":33},{"r":1310721,"n":"ToString","d":112581,"h":244813248453,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":112581,"h":4295079877,"f":8}],"h":112581}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))