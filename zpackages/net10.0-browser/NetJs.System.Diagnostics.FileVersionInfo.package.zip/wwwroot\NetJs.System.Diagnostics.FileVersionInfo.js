
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.FileVersionInfo", 
    {"h":51132,"f":"System.Diagnostics.FileVersionInfo","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.FileVersionInfo","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdf.System.Diagnostics.FileVersionInfo", ($self) => class FileVersionInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string? */ get Comments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get CompanyName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileDescription()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FileMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get FilePrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FileVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get InternalName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsDebug()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPatched()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPreRelease()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsPrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get Language()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalCopyright()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get LegalTrademarks()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get OriginalFilename()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PrivateBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductBuildPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMajorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductMinorPart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ProductPrivatePart()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get ProductVersion()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get SpecialBuild()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.FileVersionInfo */ GetVersionInfo(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdf.System.Diagnostics.FileVersionInfo.ToString.apply(this, arguments); }
            static $h = 116668;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885018556,"f":1},"n":"Comments","d":116668,"h":8590051260,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":21474953148,"f":1},"n":"CompanyName","d":116668,"h":17179985852,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30064887740,"f":1},"n":"FileBuildPart","d":116668,"h":25769920444,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654822332,"f":1},"n":"FileDescription","d":116668,"h":34359855036,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47244756924,"f":1},"n":"FileMajorPart","d":116668,"h":42949789628,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55834691516,"f":1},"n":"FileMinorPart","d":116668,"h":51539724220,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":64424626108,"f":1},"n":"FileName","d":116668,"h":60129658812,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":73014560700,"f":1},"n":"FilePrivatePart","d":116668,"h":68719593404,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":81604495292,"f":1},"n":"FileVersion","d":116668,"h":77309527996,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194429884,"f":1},"n":"InternalName","d":116668,"h":85899462588,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":98784364476,"f":1},"n":"IsDebug","d":116668,"h":94489397180,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":107374299068,"f":1},"n":"IsPatched","d":116668,"h":103079331772,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115964233660,"f":1},"n":"IsPreRelease","d":116668,"h":111669266364,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124554168252,"f":1},"n":"IsPrivateBuild","d":116668,"h":120259200956,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":133144102844,"f":1},"n":"IsSpecialBuild","d":116668,"h":128849135548,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":141734037436,"f":1},"n":"Language","d":116668,"h":137439070140,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":150323972028,"f":1},"n":"LegalCopyright","d":116668,"h":146029004732,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":158913906620,"f":1},"n":"LegalTrademarks","d":116668,"h":154618939324,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":167503841212,"f":1},"n":"OriginalFilename","d":116668,"h":163208873916,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":176093775804,"f":1},"n":"PrivateBuild","d":116668,"h":171798808508,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":184683710396,"f":1},"n":"ProductBuildPart","d":116668,"h":180388743100,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":193273644988,"f":1},"n":"ProductMajorPart","d":116668,"h":188978677692,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":201863579580,"f":1},"n":"ProductMinorPart","d":116668,"h":197568612284,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210453514172,"f":1},"n":"ProductName","d":116668,"h":206158546876,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":219043448764,"f":1},"n":"ProductPrivatePart","d":116668,"h":214748481468,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":227633383356,"f":1},"n":"ProductVersion","d":116668,"h":223338416060,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":236223317948,"f":1},"n":"SpecialBuild","d":116668,"h":231928350652,"f":1}],"m":[{"r":116668,"p":[{"n":"fileName","p":1310721}],"n":"GetVersionInfo","d":116668,"h":240518285244,"f":33},{"r":1310721,"n":"ToString","d":116668,"h":244813252540,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":116668,"h":4295083964,"f":8}],"h":116668}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.FileVersionInfo`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices"))