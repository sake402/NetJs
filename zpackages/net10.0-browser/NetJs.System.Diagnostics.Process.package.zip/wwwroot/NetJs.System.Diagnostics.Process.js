
(function ($global, $, $spc, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $scm, $so, $scp, $scs, $sdf, $sifd, $sto, $sip, $stee, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":33879,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 623703;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25770427479,"f":1},"n":"ArgumentList","d":623703,"h":21475460183,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360362071,"f":1},"s":{"r":0,"d":0,"h":38655329367,"f":1},"n":"Arguments","d":623703,"h":30065394775,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245263959,"f":1},"s":{"r":0,"d":0,"h":51540231255,"f":1},"n":"CreateNewProcessGroup","d":623703,"h":42950296663,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130165847,"f":1},"s":{"r":0,"d":0,"h":64425133143,"f":1},"n":"CreateNoWindow","d":623703,"h":55835198551,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015067735,"f":1},"s":{"r":0,"d":0,"h":77310035031,"f":1},"n":"Domain","d":623703,"h":68720100439,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":85899969623,"f":1},"n":"Environment","d":623703,"h":81605002327,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94489904215,"f":1},"n":"EnvironmentVariables","d":623703,"h":90194936919,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079838807,"f":1},"s":{"r":0,"d":0,"h":107374806103,"f":1},"n":"ErrorDialog","d":623703,"h":98784871511,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115964740695,"f":1},"s":{"r":0,"d":0,"h":120259707991,"f":1},"n":"ErrorDialogParentHandle","d":623703,"h":111669773399,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849642583,"f":1},"s":{"r":0,"d":0,"h":133144609879,"f":1},"n":"FileName","d":623703,"h":124554675287,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734544471,"f":1},"s":{"r":0,"d":0,"h":146029511767,"f":1},"n":"LoadUserProfile","d":623703,"h":137439577175,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619446359,"f":1},"s":{"r":0,"d":0,"h":158914413655,"f":1},"n":"UseCredentialsForNetworkingOnly","d":623703,"h":150324479063,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":117309441,"g":{"r":0,"d":0,"h":167504348247,"f":1},"s":{"r":0,"d":0,"h":171799315543,"f":1},"n":"Password","d":623703,"h":163209380951,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389250135,"f":1},"s":{"r":0,"d":0,"h":184684217431,"f":1},"n":"PasswordInClearText","d":623703,"h":176094282839,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274152023,"f":1},"s":{"r":0,"d":0,"h":197569119319,"f":1},"n":"RedirectStandardError","d":623703,"h":188979184727,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":206159053911,"f":1},"s":{"r":0,"d":0,"h":210454021207,"f":1},"n":"RedirectStandardInput","d":623703,"h":201864086615,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":219043955799,"f":1},"s":{"r":0,"d":0,"h":223338923095,"f":1},"n":"RedirectStandardOutput","d":623703,"h":214748988503,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":231928857687,"f":1},"s":{"r":0,"d":0,"h":236223824983,"f":1},"n":"StandardErrorEncoding","d":623703,"h":227633890391,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":244813759575,"f":1},"s":{"r":0,"d":0,"h":249108726871,"f":1},"n":"StandardInputEncoding","d":623703,"h":240518792279,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":257698661463,"f":1},"s":{"r":0,"d":0,"h":261993628759,"f":1},"n":"StandardOutputEncoding","d":623703,"h":253403694167,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":270583563351,"f":1},"s":{"r":0,"d":0,"h":274878530647,"f":1},"n":"UserName","d":623703,"h":266288596055,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":283468465239,"f":1},"s":{"r":0,"d":0,"h":287763432535,"f":1},"n":"UseShellExecute","d":623703,"h":279173497943,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":296353367127,"f":1},"s":{"r":0,"d":0,"h":300648334423,"f":1},"n":"Verb","d":623703,"h":292058399831,"f":1,"a":[{"t":33161217,"c":60162703361,"a":[{"v":"","t":1310721}]}]},{"p":0,"g":{"r":0,"d":0,"h":309238269015,"f":1},"n":"Verbs","d":623703,"h":304943301719,"f":1},{"p":820311,"g":{"r":0,"d":0,"h":317828203607,"f":1},"s":{"r":0,"d":0,"h":322123170903,"f":1},"n":"WindowStyle","d":623703,"h":313533236311,"f":1,"a":[{"t":33161217,"c":64457670657,"a":[{"v":0,"t":820311}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713105495,"f":1},"s":{"r":0,"d":0,"h":335008072791,"f":1},"n":"WorkingDirectory","d":623703,"h":326418138199,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":623703,"h":4295590999,"f":1},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":623703,"h":8590558295,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":623703,"h":12885525591,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":623703,"h":17180492887,"f":1}],"h":623703}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 492631;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":427095,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180361815,"f":1},"n":"Item","o":"@$2","d":492631,"h":12885394519,"f":1}],"m":[{"r":262145,"p":[{"n":"module","p":427095}],"n":"Contains","d":492631,"h":21475329111,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":492631,"h":25770296407,"f":1},{"r":655361,"p":[{"n":"module","p":427095}],"n":"IndexOf","d":492631,"h":30065263703,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":492631,"h":4295459927,"f":4},{"p":[{"n":"processModules","p":0}],"n":".ctor","o":"$ctor$3","d":492631,"h":8590427223,"f":1}],"i":[31391745,31653889],"h":492631}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 754775;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":689239,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180623959,"f":1},"n":"Item","o":"@$2","d":754775,"h":12885656663,"f":1}],"m":[{"r":655361,"p":[{"n":"thread","p":689239}],"n":"Add","d":754775,"h":21475591255,"f":1},{"r":262145,"p":[{"n":"thread","p":689239}],"n":"Contains","d":754775,"h":25770558551,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":754775,"h":30065525847,"f":1},{"r":655361,"p":[{"n":"thread","p":689239}],"n":"IndexOf","d":754775,"h":34360493143,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":689239}],"n":"Insert","d":754775,"h":38655460439,"f":1},{"r":65537,"p":[{"n":"thread","p":689239}],"n":"Remove","d":754775,"h":42950427735,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":754775,"h":4295722071,"f":4},{"p":[{"n":"processThreads","p":0}],"n":".ctor","o":"$ctor$3","d":754775,"h":8590689367,"f":1}],"i":[31391745,31653889],"h":754775}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 230487;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":164951}],"n":"Invoke","d":230487,"h":8590165079,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":164951},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":230487,"h":12885132375,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":230487,"h":17180099671,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":230487,"h":4295197783,"f":1}],"i":[57212929,113377281],"h":230487}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$spc.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 558167;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":558167,"n":"Normal","d":558167,"h":4295525463,"f":33},{"t":558167,"n":"Idle","d":558167,"h":8590492759,"f":33},{"t":558167,"n":"High","d":558167,"h":12885460055,"f":33},{"t":558167,"n":"RealTime","d":558167,"h":17180427351,"f":33},{"t":558167,"n":"BelowNormal","d":558167,"h":21475394647,"f":33},{"t":558167,"n":"AboveNormal","d":558167,"h":25770361943,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":558167,"h":30065329239,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":558167}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 820311;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":820311,"n":"Normal","d":820311,"h":4295787607,"f":33},{"t":820311,"n":"Hidden","d":820311,"h":8590754903,"f":33},{"t":820311,"n":"Minimized","d":820311,"h":12885722199,"f":33},{"t":820311,"n":"Maximized","d":820311,"h":17180689495,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":820311,"h":21475656791,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":820311}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$spc.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 885847;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":885847,"n":"Idle","d":885847,"h":4295853143,"f":33},{"t":885847,"n":"Lowest","d":885847,"h":8590820439,"f":33},{"t":885847,"n":"BelowNormal","d":885847,"h":12885787735,"f":33},{"t":885847,"n":"Normal","d":885847,"h":17180755031,"f":33},{"t":885847,"n":"AboveNormal","d":885847,"h":21475722327,"f":33},{"t":885847,"n":"Highest","d":885847,"h":25770689623,"f":33},{"t":885847,"n":"TimeCritical","d":885847,"h":30065656919,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":885847,"h":34360624215,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":885847}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$spc.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 951383;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":951383,"n":"Initialized","d":951383,"h":4295918679,"f":33},{"t":951383,"n":"Ready","d":951383,"h":8590885975,"f":33},{"t":951383,"n":"Running","d":951383,"h":12885853271,"f":33},{"t":951383,"n":"Standby","d":951383,"h":17180820567,"f":33},{"t":951383,"n":"Terminated","d":951383,"h":21475787863,"f":33},{"t":951383,"n":"Wait","d":951383,"h":25770755159,"f":33},{"t":951383,"n":"Transition","d":951383,"h":30065722455,"f":33},{"t":951383,"n":"Unknown","d":951383,"h":34360689751,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":951383,"h":38655657047,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":951383}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$spc.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1016919;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1016919,"n":"Executive","d":1016919,"h":4295984215,"f":33},{"t":1016919,"n":"FreePage","d":1016919,"h":8590951511,"f":33},{"t":1016919,"n":"PageIn","d":1016919,"h":12885918807,"f":33},{"t":1016919,"n":"SystemAllocation","d":1016919,"h":17180886103,"f":33},{"t":1016919,"n":"ExecutionDelay","d":1016919,"h":21475853399,"f":33},{"t":1016919,"n":"Suspended","d":1016919,"h":25770820695,"f":33},{"t":1016919,"n":"UserRequest","d":1016919,"h":30065787991,"f":33},{"t":1016919,"n":"EventPairHigh","d":1016919,"h":34360755287,"f":33},{"t":1016919,"n":"EventPairLow","d":1016919,"h":38655722583,"f":33},{"t":1016919,"n":"LpcReceive","d":1016919,"h":42950689879,"f":33},{"t":1016919,"n":"LpcReply","d":1016919,"h":47245657175,"f":33},{"t":1016919,"n":"VirtualMemory","d":1016919,"h":51540624471,"f":33},{"t":1016919,"n":"PageOut","d":1016919,"h":55835591767,"f":33},{"t":1016919,"n":"Unknown","d":1016919,"h":60130559063,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1016919,"h":64425526359,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1016919}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 99415;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":99415,"h":12885001303,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":99415,"h":4295066711,"f":1},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":99415,"h":8590034007,"f":1}],"i":[57540609],"h":99415}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 164951;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885066839,"f":1},"n":"Data","d":164951,"h":8590099543,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":164951,"h":4295132247,"f":8}],"h":164951}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 296023;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885197911,"f":32769},"n":"Description","d":296023,"h":8590230615,"f":32769}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":296023,"h":4295263319,"f":1}],"h":296023,"a":[{"t":14680065,"c":21489516545,"a":[{"v":32767,"t":14614529}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_ErrorDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_ErrorDataReceived(value)
            {
            }
            /*System.EventHandler*/ add_Exited(value)
            {
            }
            /*System.EventHandler*/ remove_Exited(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_OutputDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_OutputDataReceived(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$1(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$2(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$3(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$5(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 361559;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885263447,"f":1},"n":"BasePriority","d":361559,"h":8590296151,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475198039,"f":1},"s":{"r":0,"d":0,"h":25770165335,"f":1},"n":"EnableRaisingEvents","d":361559,"h":17180230743,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360099927,"f":1},"n":"ExitCode","d":361559,"h":30065132631,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":42950034519,"f":1},"n":"ExitTime","d":361559,"h":38655067223,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":51539969111,"f":1},"n":"Handle","d":361559,"h":47245001815,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":60129903703,"f":1},"n":"HandleCount","d":361559,"h":55834936407,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719838295,"f":1},"n":"HasExited","d":361559,"h":64424870999,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309772887,"f":1},"n":"Id","d":361559,"h":73014805591,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899707479,"f":1},"n":"MachineName","d":361559,"h":81604740183,"f":1},{"p":427095,"g":{"r":0,"d":0,"h":94489642071,"f":1},"n":"MainModule","d":361559,"h":90194674775,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":103079576663,"f":1},"n":"MainWindowHandle","d":361559,"h":98784609367,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669511255,"f":1},"n":"MainWindowTitle","d":361559,"h":107374543959,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":120259445847,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554413143,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":361559,"h":115964478551,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":133144347735,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439315031,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":361559,"h":128849380439,"f":1},{"p":492631,"g":{"r":0,"d":0,"h":146029249623,"f":1},"n":"Modules","d":361559,"h":141734282327,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":154619184215,"f":1},"n":"NonpagedSystemMemorySize","d":361559,"h":150324216919,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209118807,"f":1},"n":"NonpagedSystemMemorySize64","d":361559,"h":158914151511,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799053399,"f":1},"n":"PagedMemorySize","d":361559,"h":167504086103,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180388987991,"f":1},"n":"PagedMemorySize64","d":361559,"h":176094020695,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":188978922583,"f":1},"n":"PagedSystemMemorySize","d":361559,"h":184683955287,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568857175,"f":1},"n":"PagedSystemMemorySize64","d":361559,"h":193273889879,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":206158791767,"f":1},"n":"PeakPagedMemorySize","d":361559,"h":201863824471,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748726359,"f":1},"n":"PeakPagedMemorySize64","d":361559,"h":210453759063,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":223338660951,"f":1},"n":"PeakVirtualMemorySize","d":361559,"h":219043693655,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928595543,"f":1},"n":"PeakVirtualMemorySize64","d":361559,"h":227633628247,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":240518530135,"f":1},"n":"PeakWorkingSet","d":361559,"h":236223562839,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108464727,"f":1},"n":"PeakWorkingSet64","d":361559,"h":244813497431,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":257698399319,"f":1},"s":{"r":0,"d":0,"h":261993366615,"f":1},"n":"PriorityBoostEnabled","d":361559,"h":253403432023,"f":1},{"p":558167,"g":{"r":0,"d":0,"h":270583301207,"f":1},"s":{"r":0,"d":0,"h":274878268503,"f":1},"n":"PriorityClass","d":361559,"h":266288333911,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":283468203095,"f":1},"n":"PrivateMemorySize","d":361559,"h":279173235799,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058137687,"f":1},"n":"PrivateMemorySize64","d":361559,"h":287763170391,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":300648072279,"f":1},"n":"PrivilegedProcessorTime","d":361559,"h":296353104983,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238006871,"f":1},"n":"ProcessName","d":361559,"h":304943039575,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":317827941463,"f":1},"s":{"r":0,"d":0,"h":322122908759,"f":1},"n":"ProcessorAffinity","d":361559,"h":313532974167,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712843351,"f":1},"n":"Responding","d":361559,"h":326417876055,"f":1},{"p":99415,"g":{"r":0,"d":0,"h":339302777943,"f":1},"n":"SafeHandle","d":361559,"h":335007810647,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":347892712535,"f":1},"n":"SessionId","d":361559,"h":343597745239,"f":1},{"p":62521345,"g":{"r":0,"d":0,"h":356482647127,"f":1},"n":"StandardError","d":361559,"h":352187679831,"f":1},{"p":62652417,"g":{"r":0,"d":0,"h":365072581719,"f":1},"n":"StandardInput","d":361559,"h":360777614423,"f":1},{"p":62521345,"g":{"r":0,"d":0,"h":373662516311,"f":1},"n":"StandardOutput","d":361559,"h":369367549015,"f":1},{"p":623703,"g":{"r":0,"d":0,"h":382252450903,"f":1},"s":{"r":0,"d":0,"h":386547418199,"f":1},"n":"StartInfo","d":361559,"h":377957483607,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":395137352791,"f":1},"n":"StartTime","d":361559,"h":390842385495,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727287383,"f":1},"s":{"r":0,"d":0,"h":408022254679,"f":1},"n":"SynchronizingObject","d":361559,"h":399432320087,"f":1},{"p":754775,"g":{"r":0,"d":0,"h":416612189271,"f":1},"n":"Threads","d":361559,"h":412317221975,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":425202123863,"f":1},"n":"TotalProcessorTime","d":361559,"h":420907156567,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":433792058455,"f":1},"n":"UserProcessorTime","d":361559,"h":429497091159,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442381993047,"f":1},"n":"VirtualMemorySize","d":361559,"h":438087025751,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971927639,"f":1},"n":"VirtualMemorySize64","d":361559,"h":446676960343,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":459561862231,"f":1},"n":"WorkingSet","d":361559,"h":455266894935,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151796823,"f":1},"n":"WorkingSet64","d":361559,"h":463856829527,"f":1}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":361559,"h":511101469783,"f":1},{"r":65537,"n":"BeginOutputReadLine","d":361559,"h":515396437079,"f":1},{"r":65537,"n":"CancelErrorRead","d":361559,"h":519691404375,"f":1},{"r":65537,"n":"CancelOutputRead","d":361559,"h":523986371671,"f":1},{"r":65537,"n":"Close","d":361559,"h":528281338967,"f":1},{"r":262145,"n":"CloseMainWindow","d":361559,"h":532576306263,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":361559,"h":536871273559,"f":32772},{"r":65537,"n":"EnterDebugMode","d":361559,"h":541166240855,"f":33},{"r":361559,"n":"GetCurrentProcess","d":361559,"h":545461208151,"f":33},{"r":361559,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","d":361559,"h":549756175447,"f":33},{"r":361559,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","o":"@$1","d":361559,"h":554051142743,"f":33},{"r":0,"n":"GetProcesses","d":361559,"h":558346110039,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":361559,"h":562641077335,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","d":361559,"h":566936044631,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":361559,"h":571231011927,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":361559,"h":575525979223,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":361559,"h":579820946519,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":361559,"h":584115913815,"f":33},{"r":65537,"n":"OnExited","d":361559,"h":588410881111,"f":4},{"r":65537,"n":"Refresh","d":361559,"h":592705848407,"f":1},{"r":262145,"n":"Start","d":361559,"h":597000815703,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":361559,"p":[{"n":"startInfo","p":623703}],"n":"Start","o":"@$1","d":361559,"h":601295782999,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":361559,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$2","d":361559,"h":605590750295,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":361559,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$3","d":361559,"h":609885717591,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":361559,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Start","o":"@$4","d":361559,"h":614180684887,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":361559,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$5","d":361559,"h":618475652183,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":361559,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$6","d":361559,"h":622770619479,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":361559,"h":627065586775,"f":32769},{"r":65537,"n":"WaitForExit","d":361559,"h":631360554071,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":361559,"h":635655521367,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForExit","o":"@$2","d":361559,"h":639950488663,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitForExitAsync","d":361559,"h":644245455959,"f":1},{"r":262145,"n":"WaitForInputIdle","d":361559,"h":648540423255,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":361559,"h":652835390551,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForInputIdle","o":"@$2","d":361559,"h":657130357847,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":361559,"h":4295328855,"f":1}],"e":[{"e":230487,"m":{"r":65537,"p":[{"n":"value","p":230487}],"n":"add_ErrorDataReceived","d":361559,"h":476741731415,"f":1},"r":{"r":65537,"p":[{"n":"value","p":230487}],"n":"remove_ErrorDataReceived","d":361559,"h":481036698711,"f":1},"n":"ErrorDataReceived","d":361559,"h":472446764119,"f":1},{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Exited","d":361559,"h":489626633303,"f":1},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Exited","d":361559,"h":493921600599,"f":1},"n":"Exited","d":361559,"h":485331666007,"f":1},{"e":230487,"m":{"r":65537,"p":[{"n":"value","p":230487}],"n":"add_OutputDataReceived","d":361559,"h":502511535191,"f":1},"r":{"r":65537,"p":[{"n":"value","p":230487}],"n":"remove_OutputDataReceived","d":361559,"h":506806502487,"f":1},"n":"OutputDataReceived","d":361559,"h":498216567895,"f":1}],"i":[1048615,57540609],"h":361559,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 427095;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885328983,"f":1},"n":"BaseAddress","d":427095,"h":8590361687,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":21475263575,"f":1},"n":"EntryPointAddress","d":427095,"h":17180296279,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065198167,"f":1},"n":"FileName","d":427095,"h":25770230871,"f":1},{"p":107790,"g":{"r":0,"d":0,"h":38655132759,"f":1},"n":"FileVersionInfo","d":427095,"h":34360165463,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245067351,"f":1},"n":"ModuleMemorySize","d":427095,"h":42950100055,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835001943,"f":1},"n":"ModuleName","d":427095,"h":51540034647,"f":1}],"m":[{"r":1310721,"n":"ToString","d":427095,"h":60129969239,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":427095,"h":4295394391,"f":8}],"i":[1048615,57540609],"h":427095,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 689239;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885591127,"f":1},"n":"BasePriority","d":689239,"h":8590623831,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":21475525719,"f":1},"n":"CurrentPriority","d":689239,"h":17180558423,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065460311,"f":1},"n":"Id","d":689239,"h":25770493015,"f":1},{"p":655361,"s":{"r":0,"d":0,"h":38655394903,"f":1},"n":"IdealProcessor","d":689239,"h":34360427607,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245329495,"f":1},"s":{"r":0,"d":0,"h":51540296791,"f":1},"n":"PriorityBoostEnabled","d":689239,"h":42950362199,"f":1},{"p":885847,"g":{"r":0,"d":0,"h":60130231383,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425198679,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":689239,"h":55835264087,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015133271,"f":1},"n":"PrivilegedProcessorTime","d":689239,"h":68720165975,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605067863,"f":1},"n":"ProcessorAffinity","d":689239,"h":77310100567,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195002455,"f":1},"n":"StartAddress","d":689239,"h":85900035159,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":98784937047,"f":1},"n":"StartTime","d":689239,"h":94489969751,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":951383,"g":{"r":0,"d":0,"h":107374871639,"f":1},"n":"ThreadState","d":689239,"h":103079904343,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":115964806231,"f":1},"n":"TotalProcessorTime","d":689239,"h":111669838935,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":124554740823,"f":1},"n":"UserProcessorTime","d":689239,"h":120259773527,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1016919,"g":{"r":0,"d":0,"h":133144675415,"f":1},"n":"WaitReason","d":689239,"h":128849708119,"f":1}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":689239,"h":137439642711,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":689239,"h":4295656535,"f":8}],"i":[1048615,57540609],"h":689239,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading.ThreadPool"))