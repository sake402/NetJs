
(function ($global, $, $$, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $scm, $so, $scp, $scs, $sdf, $sifd, $sto, $sip, $stee, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":56922,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 646746;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$h,"g":{"r":0,"d":0,"h":25770450522,"f":50331649},"n":"ArgumentList","d":646746,"h":21475483226,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360385114,"f":50331649},"s":{"r":0,"d":0,"h":38655352410,"f":83886081},"n":"Arguments","d":646746,"h":30065417818,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47245287002,"f":50331649},"s":{"r":0,"d":0,"h":51540254298,"f":83886081},"n":"CreateNewProcessGroup","d":646746,"h":42950319706,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130188890,"f":50331649},"s":{"r":0,"d":0,"h":64425156186,"f":83886081},"n":"CreateNoWindow","d":646746,"h":55835221594,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":73015090778,"f":50331649},"s":{"r":0,"d":0,"h":77310058074,"f":83886081},"n":"Domain","d":646746,"h":68720123482,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,"g":{"r":0,"d":0,"h":85899992666,"f":50331649},"n":"Environment","d":646746,"h":81605025370,"f":2097153},{"p":1310756,"g":{"r":0,"d":0,"h":94489927258,"f":50331649},"n":"EnvironmentVariables","d":646746,"h":90194959962,"f":2097153,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079861850,"f":50331649},"s":{"r":0,"d":0,"h":107374829146,"f":83886081},"n":"ErrorDialog","d":646746,"h":98784894554,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":115964763738,"f":50331649},"s":{"r":0,"d":0,"h":120259731034,"f":83886081},"n":"ErrorDialogParentHandle","d":646746,"h":111669796442,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":128849665626,"f":50331649},"s":{"r":0,"d":0,"h":133144632922,"f":83886081},"n":"FileName","d":646746,"h":124554698330,"f":2097153,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734567514,"f":50331649},"s":{"r":0,"d":0,"h":146029534810,"f":83886081},"n":"LoadUserProfile","d":646746,"h":137439600218,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619469402,"f":50331649},"s":{"r":0,"d":0,"h":158914436698,"f":83886081},"n":"UseCredentialsForNetworkingOnly","d":646746,"h":150324502106,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":117178369,"g":{"r":0,"d":0,"h":167504371290,"f":50331649},"s":{"r":0,"d":0,"h":171799338586,"f":83886081},"n":"Password","d":646746,"h":163209403994,"f":2097153,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389273178,"f":50331649},"s":{"r":0,"d":0,"h":184684240474,"f":83886081},"n":"PasswordInClearText","d":646746,"h":176094305882,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274175066,"f":50331649},"s":{"r":0,"d":0,"h":197569142362,"f":83886081},"n":"RedirectStandardError","d":646746,"h":188979207770,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":206159076954,"f":50331649},"s":{"r":0,"d":0,"h":210454044250,"f":83886081},"n":"RedirectStandardInput","d":646746,"h":201864109658,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":219043978842,"f":50331649},"s":{"r":0,"d":0,"h":223338946138,"f":83886081},"n":"RedirectStandardOutput","d":646746,"h":214749011546,"f":2097153},{"p":121700353,"g":{"r":0,"d":0,"h":231928880730,"f":50331649},"s":{"r":0,"d":0,"h":236223848026,"f":83886081},"n":"StandardErrorEncoding","d":646746,"h":227633913434,"f":2097153},{"p":121700353,"g":{"r":0,"d":0,"h":244813782618,"f":50331649},"s":{"r":0,"d":0,"h":249108749914,"f":83886081},"n":"StandardInputEncoding","d":646746,"h":240518815322,"f":2097153},{"p":121700353,"g":{"r":0,"d":0,"h":257698684506,"f":50331649},"s":{"r":0,"d":0,"h":261993651802,"f":83886081},"n":"StandardOutputEncoding","d":646746,"h":253403717210,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":270583586394,"f":50331649},"s":{"r":0,"d":0,"h":274878553690,"f":83886081},"n":"UserName","d":646746,"h":266288619098,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":283468488282,"f":50331649},"s":{"r":0,"d":0,"h":287763455578,"f":83886081},"n":"UseShellExecute","d":646746,"h":279173520986,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":296353390170,"f":50331649},"s":{"r":0,"d":0,"h":300648357466,"f":83886081},"n":"Verb","d":646746,"h":292058422874,"f":2097153,"a":[{"t":33226753,"c":60162768897,"a":[{"v":"","t":1310721}]}]},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":309238292058,"f":50331649},"n":"Verbs","d":646746,"h":304943324762,"f":2097153},{"p":843354,"g":{"r":0,"d":0,"h":317828226650,"f":50331649},"s":{"r":0,"d":0,"h":322123193946,"f":83886081},"n":"WindowStyle","d":646746,"h":313533259354,"f":2097153,"a":[{"t":33226753,"c":64457736193,"a":[{"v":0,"t":843354}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713128538,"f":50331649},"s":{"r":0,"d":0,"h":335008095834,"f":83886081},"n":"WorkingDirectory","d":646746,"h":326418161242,"f":2097153,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":646746,"h":4295614042,"f":16777217},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$4","d":646746,"h":8590581338,"f":16777217},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":646746,"h":12885548634,"f":16777217},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":".ctor","o":"$ctor$2","d":646746,"h":17180515930,"f":16777217}],"h":646746}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 515674;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":450138,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180384858,"f":50331649},"n":"Item","o":"@$2","d":515674,"h":12885417562,"f":2097153}],"m":[{"r":262145,"p":[{"n":"module","p":450138}],"n":"Contains","d":515674,"h":21475352154,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$sdpc.System.Diagnostics.ProcessModule).$h},{"n":"index","p":655361}],"n":"CopyTo","d":515674,"h":25770319450,"f":16777217},{"r":655361,"p":[{"n":"module","p":450138}],"n":"IndexOf","d":515674,"h":30065286746,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":515674,"h":4295482970,"f":16777220},{"p":[{"n":"processModules","p":$.$typeArray($.$sdpc.System.Diagnostics.ProcessModule).$h}],"n":".ctor","o":"$ctor$3","d":515674,"h":8590450266,"f":16777217}],"i":[31457281,31719425],"h":515674}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 777818;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":712282,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180647002,"f":50331649},"n":"Item","o":"@$2","d":777818,"h":12885679706,"f":2097153}],"m":[{"r":655361,"p":[{"n":"thread","p":712282}],"n":"Add","d":777818,"h":21475614298,"f":16777217},{"r":262145,"p":[{"n":"thread","p":712282}],"n":"Contains","d":777818,"h":25770581594,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$sdpc.System.Diagnostics.ProcessThread).$h},{"n":"index","p":655361}],"n":"CopyTo","d":777818,"h":30065548890,"f":16777217},{"r":655361,"p":[{"n":"thread","p":712282}],"n":"IndexOf","d":777818,"h":34360516186,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":712282}],"n":"Insert","d":777818,"h":38655483482,"f":16777217},{"r":65537,"p":[{"n":"thread","p":712282}],"n":"Remove","d":777818,"h":42950450778,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":777818,"h":4295745114,"f":16777220},{"p":[{"n":"processThreads","p":$.$typeArray($.$sdpc.System.Diagnostics.ProcessThread).$h}],"n":".ctor","o":"$ctor$3","d":777818,"h":8590712410,"f":16777217}],"i":[31457281,31719425],"h":777818}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 253530;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":187994}],"n":"Invoke","d":253530,"h":8590188122,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":187994},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":253530,"h":12885155418,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":253530,"h":17180122714,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":253530,"h":4295220826,"f":16777217}],"i":[57212929,113246209],"h":253530}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$$.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 581210;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":581210,"n":"Normal","d":581210,"h":4295548506,"f":4194337},{"t":581210,"n":"Idle","d":581210,"h":8590515802,"f":4194337},{"t":581210,"n":"High","d":581210,"h":12885483098,"f":4194337},{"t":581210,"n":"RealTime","d":581210,"h":17180450394,"f":4194337},{"t":581210,"n":"BelowNormal","d":581210,"h":21475417690,"f":4194337},{"t":581210,"n":"AboveNormal","d":581210,"h":25770384986,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":581210,"h":30065352282,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":581210}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$$.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 843354;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":843354,"n":"Normal","d":843354,"h":4295810650,"f":4194337},{"t":843354,"n":"Hidden","d":843354,"h":8590777946,"f":4194337},{"t":843354,"n":"Minimized","d":843354,"h":12885745242,"f":4194337},{"t":843354,"n":"Maximized","d":843354,"h":17180712538,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":843354,"h":21475679834,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":843354}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$$.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 908890;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":908890,"n":"Idle","d":908890,"h":4295876186,"f":4194337},{"t":908890,"n":"Lowest","d":908890,"h":8590843482,"f":4194337},{"t":908890,"n":"BelowNormal","d":908890,"h":12885810778,"f":4194337},{"t":908890,"n":"Normal","d":908890,"h":17180778074,"f":4194337},{"t":908890,"n":"AboveNormal","d":908890,"h":21475745370,"f":4194337},{"t":908890,"n":"Highest","d":908890,"h":25770712666,"f":4194337},{"t":908890,"n":"TimeCritical","d":908890,"h":30065679962,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":908890,"h":34360647258,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":908890}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$$.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 974426;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":974426,"n":"Initialized","d":974426,"h":4295941722,"f":4194337},{"t":974426,"n":"Ready","d":974426,"h":8590909018,"f":4194337},{"t":974426,"n":"Running","d":974426,"h":12885876314,"f":4194337},{"t":974426,"n":"Standby","d":974426,"h":17180843610,"f":4194337},{"t":974426,"n":"Terminated","d":974426,"h":21475810906,"f":4194337},{"t":974426,"n":"Wait","d":974426,"h":25770778202,"f":4194337},{"t":974426,"n":"Transition","d":974426,"h":30065745498,"f":4194337},{"t":974426,"n":"Unknown","d":974426,"h":34360712794,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":974426,"h":38655680090,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":974426}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$$.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1039962;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1039962,"n":"Executive","d":1039962,"h":4296007258,"f":4194337},{"t":1039962,"n":"FreePage","d":1039962,"h":8590974554,"f":4194337},{"t":1039962,"n":"PageIn","d":1039962,"h":12885941850,"f":4194337},{"t":1039962,"n":"SystemAllocation","d":1039962,"h":17180909146,"f":4194337},{"t":1039962,"n":"ExecutionDelay","d":1039962,"h":21475876442,"f":4194337},{"t":1039962,"n":"Suspended","d":1039962,"h":25770843738,"f":4194337},{"t":1039962,"n":"UserRequest","d":1039962,"h":30065811034,"f":4194337},{"t":1039962,"n":"EventPairHigh","d":1039962,"h":34360778330,"f":4194337},{"t":1039962,"n":"EventPairLow","d":1039962,"h":38655745626,"f":4194337},{"t":1039962,"n":"LpcReceive","d":1039962,"h":42950712922,"f":4194337},{"t":1039962,"n":"LpcReply","d":1039962,"h":47245680218,"f":4194337},{"t":1039962,"n":"VirtualMemory","d":1039962,"h":51540647514,"f":4194337},{"t":1039962,"n":"PageOut","d":1039962,"h":55835614810,"f":4194337},{"t":1039962,"n":"Unknown","d":1039962,"h":60130582106,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1039962,"h":64425549402,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1039962}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 122458;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":122458,"h":12885024346,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$4","d":122458,"h":4295089754,"f":16777217},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":122458,"h":8590057050,"f":16777217}],"i":[57540609],"h":122458}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 187994;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885089882,"f":50331649},"n":"Data","d":187994,"h":8590122586,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":187994,"h":4295155290,"f":16777224}],"h":187994}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 319066;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885220954,"f":50364417},"n":"Description","d":319066,"h":8590253658,"f":2129921}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":319066,"h":4295286362,"f":16777217}],"h":319066,"a":[{"t":14745601,"c":21489582081,"a":[{"v":32767,"t":14680065}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_ErrorDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_ErrorDataReceived(value)
            {
            }
            /*System.EventHandler*/ add_Exited(value)
            {
            }
            /*System.EventHandler*/ remove_Exited(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_OutputDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_OutputDataReceived(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$5(/*string*/ fileName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$1(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$2(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$3(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 384602;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885286490,"f":50331649},"n":"BasePriority","d":384602,"h":8590319194,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":21475221082,"f":50331649},"s":{"r":0,"d":0,"h":25770188378,"f":83886081},"n":"EnableRaisingEvents","d":384602,"h":17180253786,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":34360122970,"f":50331649},"n":"ExitCode","d":384602,"h":30065155674,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":42950057562,"f":50331649},"n":"ExitTime","d":384602,"h":38655090266,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":51539992154,"f":50331649},"n":"Handle","d":384602,"h":47245024858,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":60129926746,"f":50331649},"n":"HandleCount","d":384602,"h":55834959450,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68719861338,"f":50331649},"n":"HasExited","d":384602,"h":64424894042,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":77309795930,"f":50331649},"n":"Id","d":384602,"h":73014828634,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":85899730522,"f":50331649},"n":"MachineName","d":384602,"h":81604763226,"f":2097153},{"p":450138,"g":{"r":0,"d":0,"h":94489665114,"f":50331649},"n":"MainModule","d":384602,"h":90194697818,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":103079599706,"f":50331649},"n":"MainWindowHandle","d":384602,"h":98784632410,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":111669534298,"f":50331649},"n":"MainWindowTitle","d":384602,"h":107374567002,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":120259468890,"f":50331649,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554436186,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"freebsd","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"macos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":384602,"h":115964501594,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":133144370778,"f":50331649,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439338074,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"freebsd","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"macos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":384602,"h":128849403482,"f":2097153},{"p":515674,"g":{"r":0,"d":0,"h":146029272666,"f":50331649},"n":"Modules","d":384602,"h":141734305370,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":154619207258,"f":50331649},"n":"NonpagedSystemMemorySize","d":384602,"h":150324239962,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209141850,"f":50331649},"n":"NonpagedSystemMemorySize64","d":384602,"h":158914174554,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":171799076442,"f":50331649},"n":"PagedMemorySize","d":384602,"h":167504109146,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180389011034,"f":50331649},"n":"PagedMemorySize64","d":384602,"h":176094043738,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":188978945626,"f":50331649},"n":"PagedSystemMemorySize","d":384602,"h":184683978330,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568880218,"f":50331649},"n":"PagedSystemMemorySize64","d":384602,"h":193273912922,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":206158814810,"f":50331649},"n":"PeakPagedMemorySize","d":384602,"h":201863847514,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748749402,"f":50331649},"n":"PeakPagedMemorySize64","d":384602,"h":210453782106,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":223338683994,"f":50331649},"n":"PeakVirtualMemorySize","d":384602,"h":219043716698,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928618586,"f":50331649},"n":"PeakVirtualMemorySize64","d":384602,"h":227633651290,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":240518553178,"f":50331649},"n":"PeakWorkingSet","d":384602,"h":236223585882,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108487770,"f":50331649},"n":"PeakWorkingSet64","d":384602,"h":244813520474,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":257698422362,"f":50331649},"s":{"r":0,"d":0,"h":261993389658,"f":83886081},"n":"PriorityBoostEnabled","d":384602,"h":253403455066,"f":2097153},{"p":581210,"g":{"r":0,"d":0,"h":270583324250,"f":50331649},"s":{"r":0,"d":0,"h":274878291546,"f":83886081},"n":"PriorityClass","d":384602,"h":266288356954,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":283468226138,"f":50331649},"n":"PrivateMemorySize","d":384602,"h":279173258842,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058160730,"f":50331649},"n":"PrivateMemorySize64","d":384602,"h":287763193434,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":300648095322,"f":50331649},"n":"PrivilegedProcessorTime","d":384602,"h":296353128026,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238029914,"f":50331649},"n":"ProcessName","d":384602,"h":304943062618,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":317827964506,"f":50331649},"s":{"r":0,"d":0,"h":322122931802,"f":83886081},"n":"ProcessorAffinity","d":384602,"h":313532997210,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712866394,"f":50331649},"n":"Responding","d":384602,"h":326417899098,"f":2097153},{"p":122458,"g":{"r":0,"d":0,"h":339302800986,"f":50331649},"n":"SafeHandle","d":384602,"h":335007833690,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":347892735578,"f":50331649},"n":"SessionId","d":384602,"h":343597768282,"f":2097153},{"p":62521345,"g":{"r":0,"d":0,"h":356482670170,"f":50331649},"n":"StandardError","d":384602,"h":352187702874,"f":2097153},{"p":62652417,"g":{"r":0,"d":0,"h":365072604762,"f":50331649},"n":"StandardInput","d":384602,"h":360777637466,"f":2097153},{"p":62521345,"g":{"r":0,"d":0,"h":373662539354,"f":50331649},"n":"StandardOutput","d":384602,"h":369367572058,"f":2097153},{"p":646746,"g":{"r":0,"d":0,"h":382252473946,"f":50331649},"s":{"r":0,"d":0,"h":386547441242,"f":83886081},"n":"StartInfo","d":384602,"h":377957506650,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":395137375834,"f":50331649},"n":"StartTime","d":384602,"h":390842408538,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727310426,"f":50331649},"s":{"r":0,"d":0,"h":408022277722,"f":83886081},"n":"SynchronizingObject","d":384602,"h":399432343130,"f":2097153},{"p":777818,"g":{"r":0,"d":0,"h":416612212314,"f":50331649},"n":"Threads","d":384602,"h":412317245018,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":425202146906,"f":50331649},"n":"TotalProcessorTime","d":384602,"h":420907179610,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140574721,"g":{"r":0,"d":0,"h":433792081498,"f":50331649},"n":"UserProcessorTime","d":384602,"h":429497114202,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442382016090,"f":50331649},"n":"VirtualMemorySize","d":384602,"h":438087048794,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971950682,"f":50331649},"n":"VirtualMemorySize64","d":384602,"h":446676983386,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":459561885274,"f":50331649},"n":"WorkingSet","d":384602,"h":455266917978,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151819866,"f":50331649},"n":"WorkingSet64","d":384602,"h":463856852570,"f":2097153}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":384602,"h":511101492826,"f":16777217},{"r":65537,"n":"BeginOutputReadLine","d":384602,"h":515396460122,"f":16777217},{"r":65537,"n":"CancelErrorRead","d":384602,"h":519691427418,"f":16777217},{"r":65537,"n":"CancelOutputRead","d":384602,"h":523986394714,"f":16777217},{"r":65537,"n":"Close","d":384602,"h":528281362010,"f":16777217},{"r":262145,"n":"CloseMainWindow","d":384602,"h":532576329306,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":384602,"h":536871296602,"f":16809988},{"r":65537,"n":"EnterDebugMode","d":384602,"h":541166263898,"f":16777249},{"r":384602,"n":"GetCurrentProcess","d":384602,"h":545461231194,"f":16777249},{"r":384602,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","o":"@$1","d":384602,"h":549756198490,"f":16777249},{"r":384602,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","d":384602,"h":554051165786,"f":16777249},{"r":$.$typeArray($.$sdpc.System.Diagnostics.Process).$h,"n":"GetProcesses","d":384602,"h":558346133082,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":$.$typeArray($.$sdpc.System.Diagnostics.Process).$h,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":384602,"h":562641100378,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":$.$typeArray($.$sdpc.System.Diagnostics.Process).$h,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":384602,"h":566936067674,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":$.$typeArray($.$sdpc.System.Diagnostics.Process).$h,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","d":384602,"h":571231034970,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":384602,"h":575526002266,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":384602,"h":579820969562,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":384602,"h":584115936858,"f":16777249},{"r":65537,"n":"OnExited","d":384602,"h":588410904154,"f":16777220},{"r":65537,"n":"Refresh","d":384602,"h":592705871450,"f":16777217},{"r":262145,"n":"Start","d":384602,"h":597000838746,"f":16777217,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":384602,"p":[{"n":"startInfo","p":646746}],"n":"Start","o":"@$6","d":384602,"h":601295806042,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":384602,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$5","d":384602,"h":605590773338,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":384602,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$4","d":384602,"h":609885740634,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":384602,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h}],"n":"Start","o":"@$1","d":384602,"h":614180707930,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":384602,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117178369},{"n":"domain","p":1310721}],"n":"Start","o":"@$2","d":384602,"h":618475675226,"f":16777249,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":384602,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117178369},{"n":"domain","p":1310721}],"n":"Start","o":"@$3","d":384602,"h":622770642522,"f":16777249,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":384602,"h":627065609818,"f":16809985},{"r":65537,"n":"WaitForExit","d":384602,"h":631360577114,"f":16777217},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":384602,"h":635655544410,"f":16777217},{"r":262145,"p":[{"n":"timeout","p":140574721}],"n":"WaitForExit","o":"@$2","d":384602,"h":639950511706,"f":16777217},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"WaitForExitAsync","d":384602,"h":644245479002,"f":16777217},{"r":262145,"n":"WaitForInputIdle","d":384602,"h":648540446298,"f":16777217},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":384602,"h":652835413594,"f":16777217},{"r":262145,"p":[{"n":"timeout","p":140574721}],"n":"WaitForInputIdle","o":"@$2","d":384602,"h":657130380890,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$3","d":384602,"h":4295351898,"f":16777217}],"e":[{"e":253530,"m":{"r":65537,"p":[{"n":"value","p":253530}],"n":"add_ErrorDataReceived","d":384602,"h":476741754458,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":253530}],"n":"remove_ErrorDataReceived","d":384602,"h":481036721754,"f":285212673},"n":"ErrorDataReceived","d":384602,"h":472446787162,"f":8388609},{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Exited","d":384602,"h":489626656346,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Exited","d":384602,"h":493921623642,"f":285212673},"n":"Exited","d":384602,"h":485331689050,"f":8388609},{"e":253530,"m":{"r":65537,"p":[{"n":"value","p":253530}],"n":"add_OutputDataReceived","d":384602,"h":502511558234,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":253530}],"n":"remove_OutputDataReceived","d":384602,"h":506806525530,"f":285212673},"n":"OutputDataReceived","d":384602,"h":498216590938,"f":8388609}],"i":[1048615,57540609],"h":384602,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 450138;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885352026,"f":50331649},"n":"BaseAddress","d":450138,"h":8590384730,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":21475286618,"f":50331649},"n":"EntryPointAddress","d":450138,"h":17180319322,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":30065221210,"f":50331649},"n":"FileName","d":450138,"h":25770253914,"f":2097153},{"p":116594,"g":{"r":0,"d":0,"h":38655155802,"f":50331649},"n":"FileVersionInfo","d":450138,"h":34360188506,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":47245090394,"f":50331649},"n":"ModuleMemorySize","d":450138,"h":42950123098,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55835024986,"f":50331649},"n":"ModuleName","d":450138,"h":51540057690,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":450138,"h":60129992282,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$3","d":450138,"h":4295417434,"f":16777224}],"i":[1048615,57540609],"h":450138,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 712282;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885614170,"f":50331649},"n":"BasePriority","d":712282,"h":8590646874,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":21475548762,"f":50331649},"n":"CurrentPriority","d":712282,"h":17180581466,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065483354,"f":50331649},"n":"Id","d":712282,"h":25770516058,"f":2097153},{"p":655361,"s":{"r":0,"d":0,"h":38655417946,"f":83886081},"n":"IdealProcessor","d":712282,"h":34360450650,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47245352538,"f":50331649},"s":{"r":0,"d":0,"h":51540319834,"f":83886081},"n":"PriorityBoostEnabled","d":712282,"h":42950385242,"f":2097153},{"p":908890,"g":{"r":0,"d":0,"h":60130254426,"f":50331649,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425221722,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":712282,"h":55835287130,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":73015156314,"f":50331649},"n":"PrivilegedProcessorTime","d":712282,"h":68720189018,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605090906,"f":83886081},"n":"ProcessorAffinity","d":712282,"h":77310123610,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195025498,"f":50331649},"n":"StartAddress","d":712282,"h":85900058202,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":98784960090,"f":50331649},"n":"StartTime","d":712282,"h":94489992794,"f":2097153,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]}]},{"p":974426,"g":{"r":0,"d":0,"h":107374894682,"f":50331649},"n":"ThreadState","d":712282,"h":103079927386,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":115964829274,"f":50331649},"n":"TotalProcessorTime","d":712282,"h":111669861978,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140574721,"g":{"r":0,"d":0,"h":124554763866,"f":50331649},"n":"UserProcessorTime","d":712282,"h":120259796570,"f":2097153,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1039962,"g":{"r":0,"d":0,"h":133144698458,"f":50331649},"n":"WaitReason","d":712282,"h":128849731162,"f":2097153}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":712282,"h":137439665754,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$3","d":712282,"h":4295679578,"f":16777224}],"i":[1048615,57540609],"h":712282,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading.ThreadPool"))