
//--TRIMMABLE-BOUNDARY-START(76)
(function ($global, $, $$, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $scm, $so, $scp, $scs, $sdf, $sifd, $sto, $sip, $stee, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {
  "h": 76,
  "f": "System.Diagnostics.Process",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.Process",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.Process",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(589900)
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557196)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557196);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557196)
            
            //--TRIMMABLE-BOUNDARY-START(8590524492)
            $ctor$4(/*string*/ fileName)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524492)
            
            //--TRIMMABLE-BOUNDARY-START(12885491788)
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491788);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491788)
            
            //--TRIMMABLE-BOUNDARY-START(17180459084)
            $ctor$2(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459084);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459084)
            
            //--TRIMMABLE-BOUNDARY-START(21475426380)
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475426380)
            
            //--TRIMMABLE-BOUNDARY-START(25770393676)
            /*string */ get Arguments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828169804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770393676)
            
            //--TRIMMABLE-BOUNDARY-START(30065360972)
            /*bool */ get CreateNewProcessGroup()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418104396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065360972)
            
            //--TRIMMABLE-BOUNDARY-START(34360328268)
            /*bool */ get CreateNoWindow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008038988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360328268)
            
            //--TRIMMABLE-BOUNDARY-START(38655295564)
            /*string */ get Domain()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079805004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597973580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655295564)
            
            //--TRIMMABLE-BOUNDARY-START(42950262860)
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950262860)
            
            //--TRIMMABLE-BOUNDARY-START(47245230156)
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245230156)
            
            //--TRIMMABLE-BOUNDARY-START(51540197452)
            /*bool */ get ErrorDialog()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187908172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540197452)
            
            //--TRIMMABLE-BOUNDARY-START(55835164748)
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777842764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835164748)
            
            //--TRIMMABLE-BOUNDARY-START(60130132044)
            /*string */ get FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029477964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367777356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130132044)
            
            //--TRIMMABLE-BOUNDARY-START(287763398732)
            /*bool */ get LoadUserProfile()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957711948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(287763398732)
            
            //--TRIMMABLE-BOUNDARY-START(515396665420)
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928823884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267123276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(515396665420)
            
            //--TRIMMABLE-BOUNDARY-START(292058366028)
            /*System.Security.SecureString? */ get Password()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547646540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(292058366028)
            
            //--TRIMMABLE-BOUNDARY-START(296353333324)
            /*string? */ get PasswordInClearText()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137581132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(296353333324)
            
            //--TRIMMABLE-BOUNDARY-START(300648300620)
            /*bool */ get RedirectStandardError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727515724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(300648300620)
            
            //--TRIMMABLE-BOUNDARY-START(304943267916)
            /*bool */ get RedirectStandardInput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317450316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(304943267916)
            
            //--TRIMMABLE-BOUNDARY-START(309238235212)
            /*bool */ get RedirectStandardOutput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907384908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(309238235212)
            
            //--TRIMMABLE-BOUNDARY-START(502511763532)
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497319500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(502511763532)
            
            //--TRIMMABLE-BOUNDARY-START(506806730828)
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748954700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087254092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(506806730828)
            
            //--TRIMMABLE-BOUNDARY-START(511101698124)
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338889292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677188684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(511101698124)
            
            //--TRIMMABLE-BOUNDARY-START(519691632716)
            /*string */ get UserName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518758476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857057868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(519691632716)
            
            //--TRIMMABLE-BOUNDARY-START(523986600012)
            /*bool */ get UseShellExecute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108693068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446992460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(523986600012)
            
            //--TRIMMABLE-BOUNDARY-START(528281567308)
            /*string */ get Verb()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698627660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036927052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(528281567308)
            
            //--TRIMMABLE-BOUNDARY-START(532576534604)
            /*string[] */ get Verbs()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288562252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(532576534604)
            
            //--TRIMMABLE-BOUNDARY-START(536871501900)
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878496844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626861644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(536871501900)
            
            //--TRIMMABLE-BOUNDARY-START(541166469196)
            /*string */ get WorkingDirectory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468431436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216796236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(541166469196)
            
            static $h = 589900;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475426380),
    {
      "p": $.$$.System.Collections.ObjectModel.Collection$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066636,
        "f": 50331649
      },
      "n": "ArgumentList",
      "d": 589900,
      "h": 21475426380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475426380),
//--TRIMMABLE-BOUNDARY-START(25770393676),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310001228,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828169804,
        "f": 83886081
      },
      "n": "Arguments",
      "d": 589900,
      "h": 25770393676,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770393676),
//--TRIMMABLE-BOUNDARY-START(30065360972),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899935820,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418104396,
        "f": 83886081
      },
      "n": "CreateNewProcessGroup",
      "d": 589900,
      "h": 30065360972,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065360972),
//--TRIMMABLE-BOUNDARY-START(34360328268),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489870412,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008038988,
        "f": 83886081
      },
      "n": "CreateNoWindow",
      "d": 589900,
      "h": 34360328268,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360328268),
//--TRIMMABLE-BOUNDARY-START(38655295564),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079805004,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343597973580,
        "f": 83886081
      },
      "n": "Domain",
      "d": 589900,
      "h": 38655295564,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655295564),
//--TRIMMABLE-BOUNDARY-START(42950262860),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669739596,
        "f": 50331649
      },
      "n": "Environment",
      "d": 589900,
      "h": 42950262860,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950262860),
//--TRIMMABLE-BOUNDARY-START(47245230156),
    {
      "p": 1310737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259674188,
        "f": 50331649
      },
      "n": "EnvironmentVariables",
      "d": 589900,
      "h": 47245230156,
      "f": 2097153,
      "a": [
        {
          "t": 852008,
          "c": 12885753896,
          "a": [
            {
              "v": "System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            },
            {
              "v": "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245230156),
//--TRIMMABLE-BOUNDARY-START(51540197452),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849608780,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352187908172,
        "f": 83886081
      },
      "n": "ErrorDialog",
      "d": 589900,
      "h": 51540197452,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540197452),
//--TRIMMABLE-BOUNDARY-START(55835164748),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439543372,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360777842764,
        "f": 83886081
      },
      "n": "ErrorDialogParentHandle",
      "d": 589900,
      "h": 55835164748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835164748),
//--TRIMMABLE-BOUNDARY-START(60130132044),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029477964,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367777356,
        "f": 83886081
      },
      "n": "FileName",
      "d": 589900,
      "h": 60130132044,
      "f": 2097153,
      "a": [
        {
          "t": 852008,
          "c": 12885753896,
          "a": [
            {
              "v": "System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            },
            {
              "v": "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60130132044),
//--TRIMMABLE-BOUNDARY-START(287763398732),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619412556,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957711948,
        "f": 83886081
      },
      "n": "LoadUserProfile",
      "d": 589900,
      "h": 287763398732,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763398732),
//--TRIMMABLE-BOUNDARY-START(515396665420),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928823884,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 455267123276,
        "f": 83886081
      },
      "n": "UseCredentialsForNetworkingOnly",
      "d": 589900,
      "h": 515396665420,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(515396665420),
//--TRIMMABLE-BOUNDARY-START(292058366028),
    {
      "p": 161284097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209347148,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 386547646540,
        "f": 83886081
      },
      "n": "Password",
      "d": 589900,
      "h": 292058366028,
      "f": 2097153,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(292058366028),
//--TRIMMABLE-BOUNDARY-START(296353333324),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799281740,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 395137581132,
        "f": 83886081
      },
      "n": "PasswordInClearText",
      "d": 589900,
      "h": 296353333324,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(296353333324),
//--TRIMMABLE-BOUNDARY-START(300648300620),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389216332,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 403727515724,
        "f": 83886081
      },
      "n": "RedirectStandardError",
      "d": 589900,
      "h": 300648300620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(300648300620),
//--TRIMMABLE-BOUNDARY-START(304943267916),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979150924,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 412317450316,
        "f": 83886081
      },
      "n": "RedirectStandardInput",
      "d": 589900,
      "h": 304943267916,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304943267916),
//--TRIMMABLE-BOUNDARY-START(309238235212),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569085516,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 420907384908,
        "f": 83886081
      },
      "n": "RedirectStandardOutput",
      "d": 589900,
      "h": 309238235212,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(309238235212),
//--TRIMMABLE-BOUNDARY-START(502511763532),
    {
      "p": 165806081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159020108,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 429497319500,
        "f": 83886081
      },
      "n": "StandardErrorEncoding",
      "d": 589900,
      "h": 502511763532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(502511763532),
//--TRIMMABLE-BOUNDARY-START(506806730828),
    {
      "p": 165806081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748954700,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 438087254092,
        "f": 83886081
      },
      "n": "StandardInputEncoding",
      "d": 589900,
      "h": 506806730828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(506806730828),
//--TRIMMABLE-BOUNDARY-START(511101698124),
    {
      "p": 165806081,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338889292,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 446677188684,
        "f": 83886081
      },
      "n": "StandardOutputEncoding",
      "d": 589900,
      "h": 511101698124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(511101698124),
//--TRIMMABLE-BOUNDARY-START(519691632716),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518758476,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 463857057868,
        "f": 83886081
      },
      "n": "UserName",
      "d": 589900,
      "h": 519691632716,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(519691632716),
//--TRIMMABLE-BOUNDARY-START(523986600012),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108693068,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 472446992460,
        "f": 83886081
      },
      "n": "UseShellExecute",
      "d": 589900,
      "h": 523986600012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(523986600012),
//--TRIMMABLE-BOUNDARY-START(528281567308),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698627660,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 481036927052,
        "f": 83886081
      },
      "n": "Verb",
      "d": 589900,
      "h": 528281567308,
      "f": 2097153,
      "a": [
        {
          "t": 64094209,
          "c": 51603701761,
          "a": [
            {
              "v": "",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(528281567308),
//--TRIMMABLE-BOUNDARY-START(532576534604),
    {
      "p": $.$typeArray($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288562252,
        "f": 50331649
      },
      "n": "Verbs",
      "d": 589900,
      "h": 532576534604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(532576534604),
//--TRIMMABLE-BOUNDARY-START(536871501900),
    {
      "p": 786508,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878496844,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 489626861644,
        "f": 83886081
      },
      "n": "WindowStyle",
      "d": 589900,
      "h": 536871501900,
      "f": 2097153,
      "a": [
        {
          "t": 64094209,
          "c": 55898669057,
          "a": [
            {
              "v": 0,
              "t": 786508
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(536871501900),
//--TRIMMABLE-BOUNDARY-START(541166469196),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468431436,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 498216796236,
        "f": 83886081
      },
      "n": "WorkingDirectory",
      "d": 589900,
      "h": 541166469196,
      "f": 2097153,
      "a": [
        {
          "t": 852008,
          "c": 12885753896,
          "a": [
            {
              "v": "System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            },
            {
              "v": "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(541166469196)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557196),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589900,
      "h": 4295557196,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557196),
//--TRIMMABLE-BOUNDARY-START(8590524492),
    {
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589900,
      "h": 8590524492,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524492),
//--TRIMMABLE-BOUNDARY-START(12885491788),
    {
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589900,
      "h": 12885491788,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491788),
//--TRIMMABLE-BOUNDARY-START(17180459084),
    {
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589900,
      "h": 17180459084,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459084)
  ],
  "h": 589900
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589900)
        
        
        //--TRIMMABLE-BOUNDARY-START(458828)
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295426124)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426124);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426124)
            
            //--TRIMMABLE-BOUNDARY-START(8590393420)
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393420)
            
            //--TRIMMABLE-BOUNDARY-START(34360197196)
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360197196)
            
            //--TRIMMABLE-BOUNDARY-START(12885360716)
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360716)
            
            //--TRIMMABLE-BOUNDARY-START(17180328012)
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180328012)
            
            //--TRIMMABLE-BOUNDARY-START(30065229900)
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065229900)
            
            static $h = 458828;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655376,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360197196),
    {
      "p": 393292,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262604,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 458828,
      "h": 34360197196,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360197196)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360716),
    {
      "r": 262145,
      "p": [
        {
          "n": "module",
          "p": 393292
        }
      ],
      "n": "Contains",
      "d": 458828,
      "h": 12885360716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360716),
//--TRIMMABLE-BOUNDARY-START(17180328012),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$sdpc.System.Diagnostics.ProcessModule).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 458828,
      "h": 17180328012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180328012),
//--TRIMMABLE-BOUNDARY-START(30065229900),
    {
      "r": 655361,
      "p": [
        {
          "n": "module",
          "p": 393292
        }
      ],
      "n": "IndexOf",
      "d": 458828,
      "h": 30065229900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065229900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426124),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458828,
      "h": 4295426124,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295426124),
//--TRIMMABLE-BOUNDARY-START(8590393420),
    {
      "p": [
        {
          "n": "processModules",
          "p": $.$typeArray($.$sdpc.System.Diagnostics.ProcessModule).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458828,
      "h": 8590393420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393420)
  ],
  "i": [62259201,62521345
  ],
  "h": 458828
}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458828)
        
        
        //--TRIMMABLE-BOUNDARY-START(720972)
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4295688268)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688268);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688268)
            
            //--TRIMMABLE-BOUNDARY-START(8590655564)
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590655564);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590655564)
            
            //--TRIMMABLE-BOUNDARY-START(47245361228)
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245361228)
            
            //--TRIMMABLE-BOUNDARY-START(12885622860)
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885622860)
            
            //--TRIMMABLE-BOUNDARY-START(17180590156)
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180590156)
            
            //--TRIMMABLE-BOUNDARY-START(21475557452)
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475557452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475557452)
            
            //--TRIMMABLE-BOUNDARY-START(34360459340)
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360459340)
            
            //--TRIMMABLE-BOUNDARY-START(38655426636)
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655426636)
            
            //--TRIMMABLE-BOUNDARY-START(42950393932)
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950393932)
            
            static $h = 720972;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 655376,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245361228),
    {
      "p": 655436,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492044,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 720972,
      "h": 47245361228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245361228)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885622860),
    {
      "r": 655361,
      "p": [
        {
          "n": "thread",
          "p": 655436
        }
      ],
      "n": "Add",
      "d": 720972,
      "h": 12885622860,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622860),
//--TRIMMABLE-BOUNDARY-START(17180590156),
    {
      "r": 262145,
      "p": [
        {
          "n": "thread",
          "p": 655436
        }
      ],
      "n": "Contains",
      "d": 720972,
      "h": 17180590156,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590156),
//--TRIMMABLE-BOUNDARY-START(21475557452),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$sdpc.System.Diagnostics.ProcessThread).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 720972,
      "h": 21475557452,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557452),
//--TRIMMABLE-BOUNDARY-START(34360459340),
    {
      "r": 655361,
      "p": [
        {
          "n": "thread",
          "p": 655436
        }
      ],
      "n": "IndexOf",
      "d": 720972,
      "h": 34360459340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360459340),
//--TRIMMABLE-BOUNDARY-START(38655426636),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "thread",
          "p": 655436
        }
      ],
      "n": "Insert",
      "d": 720972,
      "h": 38655426636,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426636),
//--TRIMMABLE-BOUNDARY-START(42950393932),
    {
      "r": 65537,
      "p": [
        {
          "n": "thread",
          "p": 655436
        }
      ],
      "n": "Remove",
      "d": 720972,
      "h": 42950393932,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393932)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688268),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720972,
      "h": 4295688268,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295688268),
//--TRIMMABLE-BOUNDARY-START(8590655564),
    {
      "p": [
        {
          "n": "processThreads",
          "p": $.$typeArray($.$sdpc.System.Diagnostics.ProcessThread).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720972,
      "h": 8590655564,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655564)
  ],
  "i": [62259201,62521345
  ],
  "h": 720972
}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720972)
        
        
        //--TRIMMABLE-BOUNDARY-START(196684)
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 196684;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98828289,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065868),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 131148
        }
      ],
      "n": "Invoke",
      "d": 196684,
      "h": 17180065868,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065868),
//--TRIMMABLE-BOUNDARY-START(8590131276),
    {
      "r": 89653249,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 131148
        },
        {
          "n": "callback",
          "p": 45154305
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 196684,
      "h": 8590131276,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131276),
//--TRIMMABLE-BOUNDARY-START(12885098572),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89653249
        }
      ],
      "n": "EndInvoke",
      "d": 196684,
      "h": 12885098572,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098572)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163980),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196684,
      "h": 4295163980,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163980)
  ],
  "i": [89849857,157351937
  ],
  "h": 196684
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196684)
        
        
        //--TRIMMABLE-BOUNDARY-START(524364)
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$$.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 524364;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770328140),
    {
      "t": 524364,
      "n": "Normal",
      "d": 524364,
      "h": 25770328140,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328140),
//--TRIMMABLE-BOUNDARY-START(21475360844),
    {
      "t": 524364,
      "n": "Idle",
      "d": 524364,
      "h": 21475360844,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360844),
//--TRIMMABLE-BOUNDARY-START(17180393548),
    {
      "t": 524364,
      "n": "High",
      "d": 524364,
      "h": 17180393548,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393548),
//--TRIMMABLE-BOUNDARY-START(30065295436),
    {
      "t": 524364,
      "n": "RealTime",
      "d": 524364,
      "h": 30065295436,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295436),
//--TRIMMABLE-BOUNDARY-START(12885426252),
    {
      "t": 524364,
      "n": "BelowNormal",
      "d": 524364,
      "h": 12885426252,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426252),
//--TRIMMABLE-BOUNDARY-START(8590458956),
    {
      "t": 524364,
      "n": "AboveNormal",
      "d": 524364,
      "h": 8590458956,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491660),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524364,
      "h": 4295491660,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491660)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 524364
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524364)
        
        
        //--TRIMMABLE-BOUNDARY-START(786508)
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$$.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 786508;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475622988),
    {
      "t": 786508,
      "n": "Normal",
      "d": 786508,
      "h": 21475622988,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475622988),
//--TRIMMABLE-BOUNDARY-START(8590721100),
    {
      "t": 786508,
      "n": "Hidden",
      "d": 786508,
      "h": 8590721100,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590721100),
//--TRIMMABLE-BOUNDARY-START(17180655692),
    {
      "t": 786508,
      "n": "Minimized",
      "d": 786508,
      "h": 17180655692,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180655692),
//--TRIMMABLE-BOUNDARY-START(12885688396),
    {
      "t": 786508,
      "n": "Maximized",
      "d": 786508,
      "h": 12885688396,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885688396)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753804),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786508,
      "h": 4295753804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753804)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 786508
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786508)
        
        
        //--TRIMMABLE-BOUNDARY-START(852044)
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$$.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 852044;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475688524),
    {
      "t": 852044,
      "n": "Idle",
      "d": 852044,
      "h": 21475688524,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475688524),
//--TRIMMABLE-BOUNDARY-START(25770655820),
    {
      "t": 852044,
      "n": "Lowest",
      "d": 852044,
      "h": 25770655820,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770655820),
//--TRIMMABLE-BOUNDARY-START(12885753932),
    {
      "t": 852044,
      "n": "BelowNormal",
      "d": 852044,
      "h": 12885753932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753932),
//--TRIMMABLE-BOUNDARY-START(30065623116),
    {
      "t": 852044,
      "n": "Normal",
      "d": 852044,
      "h": 30065623116,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065623116),
//--TRIMMABLE-BOUNDARY-START(8590786636),
    {
      "t": 852044,
      "n": "AboveNormal",
      "d": 852044,
      "h": 8590786636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786636),
//--TRIMMABLE-BOUNDARY-START(17180721228),
    {
      "t": 852044,
      "n": "Highest",
      "d": 852044,
      "h": 17180721228,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180721228),
//--TRIMMABLE-BOUNDARY-START(34360590412),
    {
      "t": 852044,
      "n": "TimeCritical",
      "d": 852044,
      "h": 34360590412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360590412)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819340),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852044,
      "h": 4295819340,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819340)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 852044
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852044)
        
        
        //--TRIMMABLE-BOUNDARY-START(917580)
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$$.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(917580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 917580;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852172),
    {
      "t": 917580,
      "n": "Initialized",
      "d": 917580,
      "h": 8590852172,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590852172),
//--TRIMMABLE-BOUNDARY-START(12885819468),
    {
      "t": 917580,
      "n": "Ready",
      "d": 917580,
      "h": 12885819468,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819468),
//--TRIMMABLE-BOUNDARY-START(17180786764),
    {
      "t": 917580,
      "n": "Running",
      "d": 917580,
      "h": 17180786764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786764),
//--TRIMMABLE-BOUNDARY-START(21475754060),
    {
      "t": 917580,
      "n": "Standby",
      "d": 917580,
      "h": 21475754060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754060),
//--TRIMMABLE-BOUNDARY-START(25770721356),
    {
      "t": 917580,
      "n": "Terminated",
      "d": 917580,
      "h": 25770721356,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721356),
//--TRIMMABLE-BOUNDARY-START(38655623244),
    {
      "t": 917580,
      "n": "Wait",
      "d": 917580,
      "h": 38655623244,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655623244),
//--TRIMMABLE-BOUNDARY-START(30065688652),
    {
      "t": 917580,
      "n": "Transition",
      "d": 917580,
      "h": 30065688652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688652),
//--TRIMMABLE-BOUNDARY-START(34360655948),
    {
      "t": 917580,
      "n": "Unknown",
      "d": 917580,
      "h": 34360655948,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655948)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884876),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917580,
      "h": 4295884876,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295884876)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 917580
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917580)
        
        
        //--TRIMMABLE-BOUNDARY-START(983116)
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$$.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(983116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 983116;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21475819596),
    {
      "t": 983116,
      "n": "Executive",
      "d": 983116,
      "h": 21475819596,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475819596),
//--TRIMMABLE-BOUNDARY-START(25770786892),
    {
      "t": 983116,
      "n": "FreePage",
      "d": 983116,
      "h": 25770786892,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770786892),
//--TRIMMABLE-BOUNDARY-START(38655688780),
    {
      "t": 983116,
      "n": "PageIn",
      "d": 983116,
      "h": 38655688780,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655688780),
//--TRIMMABLE-BOUNDARY-START(51540590668),
    {
      "t": 983116,
      "n": "SystemAllocation",
      "d": 983116,
      "h": 51540590668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540590668),
//--TRIMMABLE-BOUNDARY-START(17180852300),
    {
      "t": 983116,
      "n": "ExecutionDelay",
      "d": 983116,
      "h": 17180852300,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180852300),
//--TRIMMABLE-BOUNDARY-START(47245623372),
    {
      "t": 983116,
      "n": "Suspended",
      "d": 983116,
      "h": 47245623372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245623372),
//--TRIMMABLE-BOUNDARY-START(60130525260),
    {
      "t": 983116,
      "n": "UserRequest",
      "d": 983116,
      "h": 60130525260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130525260),
//--TRIMMABLE-BOUNDARY-START(8590917708),
    {
      "t": 983116,
      "n": "EventPairHigh",
      "d": 983116,
      "h": 8590917708,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590917708),
//--TRIMMABLE-BOUNDARY-START(12885885004),
    {
      "t": 983116,
      "n": "EventPairLow",
      "d": 983116,
      "h": 12885885004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885885004),
//--TRIMMABLE-BOUNDARY-START(30065754188),
    {
      "t": 983116,
      "n": "LpcReceive",
      "d": 983116,
      "h": 30065754188,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065754188),
//--TRIMMABLE-BOUNDARY-START(34360721484),
    {
      "t": 983116,
      "n": "LpcReply",
      "d": 983116,
      "h": 34360721484,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360721484),
//--TRIMMABLE-BOUNDARY-START(64425492556),
    {
      "t": 983116,
      "n": "VirtualMemory",
      "d": 983116,
      "h": 64425492556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425492556),
//--TRIMMABLE-BOUNDARY-START(42950656076),
    {
      "t": 983116,
      "n": "PageOut",
      "d": 983116,
      "h": 42950656076,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950656076),
//--TRIMMABLE-BOUNDARY-START(55835557964),
    {
      "t": 983116,
      "n": "Unknown",
      "d": 983116,
      "h": 55835557964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835557964)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950412),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 983116,
      "h": 4295950412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295950412)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 983116
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983116)
        
        
        //--TRIMMABLE-BOUNDARY-START(65612)
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            //--TRIMMABLE-BOUNDARY-START(4295032908)
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032908);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032908)
            
            //--TRIMMABLE-BOUNDARY-START(8590000204)
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000204);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000204)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12884967500, 103226146817)
            /*bool */ ReleaseHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12884967500, 103226146817)
            
            static $h = 65612;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 8060929,
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 12884967500, 103226146817),
    {
      "r": 262145,
      "n": "ReleaseHandle",
      "d": 65612,
      "h": 12884967500,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12884967500, 103226146817)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032908),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65612,
      "h": 4295032908,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032908),
//--TRIMMABLE-BOUNDARY-START(8590000204),
    {
      "p": [
        {
          "n": "existingHandle",
          "p": 786433
        },
        {
          "n": "ownsHandle",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 65612,
      "h": 8590000204,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000204)
  ],
  "i": [90177537
  ],
  "h": 65612
}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65612)
        
        
        //--TRIMMABLE-BOUNDARY-START(131148)
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4295098444)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098444);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098444)
            
            //--TRIMMABLE-BOUNDARY-START(8590065740)
            /*string? */ get Data()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065740)
            
            static $h = 131148;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79626241,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065740),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000332,
        "f": 50331649
      },
      "n": "Data",
      "d": 131148,
      "h": 8590065740,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590065740)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098444),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131148,
      "h": 4295098444,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295098444)
  ],
  "h": 131148
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131148)
        
        
        //--TRIMMABLE-BOUNDARY-START(262220)
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295229516)
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229516);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229516)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 8590196812, 25770131496)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 8590196812, 25770131496)
            
            static $h = 262220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 327720,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 8590196812, 25770131496),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180131404,
        "f": 50364417
      },
      "n": "Description",
      "d": 262220,
      "h": 8590196812,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 8590196812, 25770131496)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229516),
    {
      "p": [
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 262220,
      "h": 4295229516,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229516)
  ],
  "h": 262220,
  "a": [
    {
      "t": 45350913,
      "c": 21520187393,
      "a": [
        {
          "v": 32767,
          "t": 45285377
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262220)
        
        
        //--TRIMMABLE-BOUNDARY-START(327756)
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            //--TRIMMABLE-BOUNDARY-START(4295295052)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295052);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295052)
            
            //--TRIMMABLE-BOUNDARY-START(34360066124)
            /*int */ get BasePriority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360066124)
            
            //--TRIMMABLE-BOUNDARY-START(68719804492)
            /*bool */ get EnableRaisingEvents()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(751619604556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719804492)
            
            //--TRIMMABLE-BOUNDARY-START(81604706380)
            /*int */ get ExitCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604706380)
            
            //--TRIMMABLE-BOUNDARY-START(90194640972)
            /*System.DateTime */ get ExitTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194640972)
            
            //--TRIMMABLE-BOUNDARY-START(554051108940)
            /*System.IntPtr */ get Handle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144313932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(554051108940)
            
            //--TRIMMABLE-BOUNDARY-START(558346076236)
            /*int */ get HandleCount()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734248524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(558346076236)
            
            //--TRIMMABLE-BOUNDARY-START(562641043532)
            /*bool */ get HasExited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(562641043532)
            
            //--TRIMMABLE-BOUNDARY-START(566936010828)
            /*int */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(566936010828)
            
            //--TRIMMABLE-BOUNDARY-START(584115880012)
            /*string */ get MachineName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(584115880012)
            
            //--TRIMMABLE-BOUNDARY-START(588410847308)
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093986892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(588410847308)
            
            //--TRIMMABLE-BOUNDARY-START(592705814604)
            /*System.IntPtr */ get MainWindowHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683921484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(592705814604)
            
            //--TRIMMABLE-BOUNDARY-START(597000781900)
            /*string */ get MainWindowTitle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273856076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(597000781900)
            
            //--TRIMMABLE-BOUNDARY-START(601295749196)
            /*System.IntPtr */ get MaxWorkingSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863790668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(760209539148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(601295749196)
            
            //--TRIMMABLE-BOUNDARY-START(605590716492)
            /*System.IntPtr */ get MinWorkingSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453725260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(768799473740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(605590716492)
            
            //--TRIMMABLE-BOUNDARY-START(609885683788)
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043659852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(609885683788)
            
            //--TRIMMABLE-BOUNDARY-START(614180651084)
            /*int */ get NonpagedSystemMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633594444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(614180651084)
            
            //--TRIMMABLE-BOUNDARY-START(618475618380)
            /*long */ get NonpagedSystemMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223529036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(618475618380)
            
            //--TRIMMABLE-BOUNDARY-START(631360520268)
            /*int */ get PagedMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813463628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(631360520268)
            
            //--TRIMMABLE-BOUNDARY-START(635655487564)
            /*long */ get PagedMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403398220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(635655487564)
            
            //--TRIMMABLE-BOUNDARY-START(639950454860)
            /*int */ get PagedSystemMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993332812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(639950454860)
            
            //--TRIMMABLE-BOUNDARY-START(644245422156)
            /*long */ get PagedSystemMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583267404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(644245422156)
            
            //--TRIMMABLE-BOUNDARY-START(648540389452)
            /*int */ get PeakPagedMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173201996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(648540389452)
            
            //--TRIMMABLE-BOUNDARY-START(652835356748)
            /*long */ get PeakPagedMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763136588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(652835356748)
            
            //--TRIMMABLE-BOUNDARY-START(657130324044)
            /*int */ get PeakVirtualMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353071180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(657130324044)
            
            //--TRIMMABLE-BOUNDARY-START(661425291340)
            /*long */ get PeakVirtualMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943005772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(661425291340)
            
            //--TRIMMABLE-BOUNDARY-START(665720258636)
            /*int */ get PeakWorkingSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313532940364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(665720258636)
            
            //--TRIMMABLE-BOUNDARY-START(670015225932)
            /*long */ get PeakWorkingSet64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322122874956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(670015225932)
            
            //--TRIMMABLE-BOUNDARY-START(674310193228)
            /*bool */ get PriorityBoostEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712809548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(777389408332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(674310193228)
            
            //--TRIMMABLE-BOUNDARY-START(678605160524)
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302744140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(785979342924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(678605160524)
            
            //--TRIMMABLE-BOUNDARY-START(682900127820)
            /*int */ get PrivateMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892678732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(682900127820)
            
            //--TRIMMABLE-BOUNDARY-START(687195095116)
            /*long */ get PrivateMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482613324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(687195095116)
            
            //--TRIMMABLE-BOUNDARY-START(691490062412)
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072547916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(691490062412)
            
            //--TRIMMABLE-BOUNDARY-START(695785029708)
            /*string */ get ProcessName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662482508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(695785029708)
            
            //--TRIMMABLE-BOUNDARY-START(700079997004)
            /*System.IntPtr */ get ProcessorAffinity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252417100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(794569277516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(700079997004)
            
            //--TRIMMABLE-BOUNDARY-START(734439735372)
            /*bool */ get Responding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842351692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(734439735372)
            
            //--TRIMMABLE-BOUNDARY-START(738734702668)
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432286284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(738734702668)
            
            //--TRIMMABLE-BOUNDARY-START(743029669964)
            /*int */ get SessionId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022220876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(743029669964)
            
            //--TRIMMABLE-BOUNDARY-START(816044113996)
            /*System.IO.StreamReader */ get StandardError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612155468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(816044113996)
            
            //--TRIMMABLE-BOUNDARY-START(820339081292)
            /*System.IO.StreamWriter */ get StandardInput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202090060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(820339081292)
            
            //--TRIMMABLE-BOUNDARY-START(824634048588)
            /*System.IO.StreamReader */ get StandardOutput()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792024652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(824634048588)
            
            //--TRIMMABLE-BOUNDARY-START(858993786956)
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442381959244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(803159212108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(858993786956)
            
            //--TRIMMABLE-BOUNDARY-START(863288754252)
            /*System.DateTime */ get StartTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450971893836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(863288754252)
            
            //--TRIMMABLE-BOUNDARY-START(867583721548)
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459561828428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(811749146700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(867583721548)
            
            //--TRIMMABLE-BOUNDARY-START(871878688844)
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468151763020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(871878688844)
            
            //--TRIMMABLE-BOUNDARY-START(880468623436)
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741697612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(880468623436)
            
            //--TRIMMABLE-BOUNDARY-START(884763590732)
            /*System.TimeSpan */ get UserProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331632204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(884763590732)
            
            //--TRIMMABLE-BOUNDARY-START(889058558028)
            /*int */ get VirtualMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921566796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(889058558028)
            
            //--TRIMMABLE-BOUNDARY-START(893353525324)
            /*long */ get VirtualMemorySize64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511501388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(893353525324)
            
            //--TRIMMABLE-BOUNDARY-START(927713263692)
            /*int */ get WorkingSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101435980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(927713263692)
            
            //--TRIMMABLE-BOUNDARY-START(932008230988)
            /*long */ get WorkingSet64()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691370572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(932008230988)
            
            //--TRIMMABLE-BOUNDARY-START(77309739084)
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_ErrorDataReceived(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_ErrorDataReceived(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712964898892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(77309739084)
            
            //--TRIMMABLE-BOUNDARY-START(85899673676)
            /*System.EventHandler*/ add_Exited(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.EventHandler*/ remove_Exited(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721554833484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85899673676)
            
            //--TRIMMABLE-BOUNDARY-START(627065552972)
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_OutputDataReceived(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_OutputDataReceived(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730144768076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(627065552972)
            
            //--TRIMMABLE-BOUNDARY-START(38655033420)
            /*void */ BeginErrorReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655033420)
            
            //--TRIMMABLE-BOUNDARY-START(42950000716)
            /*void */ BeginOutputReadLine()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950000716)
            
            //--TRIMMABLE-BOUNDARY-START(47244968012)
            /*void */ CancelErrorRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244968012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47244968012)
            
            //--TRIMMABLE-BOUNDARY-START(51539935308)
            /*void */ CancelOutputRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51539935308)
            
            //--TRIMMABLE-BOUNDARY-START(55834902604)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55834902604)
            
            //--TRIMMABLE-BOUNDARY-START(60129869900)
            /*bool */ CloseMainWindow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129869900)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 64424837196, 51539804200)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 64424837196, 51539804200)
            
            //--TRIMMABLE-BOUNDARY-START(73014771788)
            static /*void */ EnterDebugMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014771788)
            
            //--TRIMMABLE-BOUNDARY-START(523986337868)
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986337868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(523986337868)
            
            //--TRIMMABLE-BOUNDARY-START(528281305164)
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281305164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(528281305164)
            
            //--TRIMMABLE-BOUNDARY-START(532576272460)
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId, /*string*/ machineName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576272460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(532576272460)
            
            //--TRIMMABLE-BOUNDARY-START(536871239756)
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871239756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(536871239756)
            
            //--TRIMMABLE-BOUNDARY-START(541166207052)
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166207052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(541166207052)
            
            //--TRIMMABLE-BOUNDARY-START(545461174348)
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461174348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(545461174348)
            
            //--TRIMMABLE-BOUNDARY-START(549756141644)
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName, /*string*/ machineName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756141644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(549756141644)
            
            //--TRIMMABLE-BOUNDARY-START(571230978124)
            /*void */ Kill()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571230978124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(571230978124)
            
            //--TRIMMABLE-BOUNDARY-START(575525945420)
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575525945420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(575525945420)
            
            //--TRIMMABLE-BOUNDARY-START(579820912716)
            static /*void */ LeaveDebugMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579820912716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(579820912716)
            
            //--TRIMMABLE-BOUNDARY-START(622770585676)
            /*void */ OnExited()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622770585676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(622770585676)
            
            //--TRIMMABLE-BOUNDARY-START(704374964300)
            /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704374964300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(704374964300)
            
            //--TRIMMABLE-BOUNDARY-START(828929015884)
            /*bool */ Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(828929015884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(828929015884)
            
            //--TRIMMABLE-BOUNDARY-START(833223983180)
            static /*System.Diagnostics.Process? */ Start$6(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833223983180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(833223983180)
            
            //--TRIMMABLE-BOUNDARY-START(837518950476)
            static /*System.Diagnostics.Process */ Start$5(/*string*/ fileName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(837518950476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(837518950476)
            
            //--TRIMMABLE-BOUNDARY-START(841813917772)
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*string*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841813917772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(841813917772)
            
            //--TRIMMABLE-BOUNDARY-START(846108885068)
            static /*System.Diagnostics.Process */ Start$1(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(846108885068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(846108885068)
            
            //--TRIMMABLE-BOUNDARY-START(850403852364)
            static /*System.Diagnostics.Process? */ Start$2(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850403852364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(850403852364)
            
            //--TRIMMABLE-BOUNDARY-START(854698819660)
            static /*System.Diagnostics.Process? */ Start$3(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(854698819660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(854698819660)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 876173656140, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876173656140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 876173656140, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(897648492620)
            /*void */ WaitForExit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(897648492620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(897648492620)
            
            //--TRIMMABLE-BOUNDARY-START(901943459916)
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(901943459916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(901943459916)
            
            //--TRIMMABLE-BOUNDARY-START(906238427212)
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(906238427212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(906238427212)
            
            //--TRIMMABLE-BOUNDARY-START(910533394508)
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(910533394508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(910533394508)
            
            //--TRIMMABLE-BOUNDARY-START(914828361804)
            /*bool */ WaitForInputIdle()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(914828361804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(914828361804)
            
            //--TRIMMABLE-BOUNDARY-START(919123329100)
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(919123329100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(919123329100)
            
            //--TRIMMABLE-BOUNDARY-START(923418296396)
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(923418296396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(923418296396)
            
            static $h = 327756;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196648,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360066124),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784575564,
        "f": 50331649
      },
      "n": "BasePriority",
      "d": 327756,
      "h": 34360066124,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360066124),
//--TRIMMABLE-BOUNDARY-START(68719804492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374510156,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 751619604556,
        "f": 83886081
      },
      "n": "EnableRaisingEvents",
      "d": 327756,
      "h": 68719804492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719804492),
//--TRIMMABLE-BOUNDARY-START(81604706380),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964444748,
        "f": 50331649
      },
      "n": "ExitCode",
      "d": 327756,
      "h": 81604706380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604706380),
//--TRIMMABLE-BOUNDARY-START(90194640972),
    {
      "p": 65142785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554379340,
        "f": 50331649
      },
      "n": "ExitTime",
      "d": 327756,
      "h": 90194640972,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194640972),
//--TRIMMABLE-BOUNDARY-START(554051108940),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144313932,
        "f": 50331649
      },
      "n": "Handle",
      "d": 327756,
      "h": 554051108940,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(554051108940),
//--TRIMMABLE-BOUNDARY-START(558346076236),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734248524,
        "f": 50331649
      },
      "n": "HandleCount",
      "d": 327756,
      "h": 558346076236,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(558346076236),
//--TRIMMABLE-BOUNDARY-START(562641043532),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324183116,
        "f": 50331649
      },
      "n": "HasExited",
      "d": 327756,
      "h": 562641043532,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(562641043532),
//--TRIMMABLE-BOUNDARY-START(566936010828),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914117708,
        "f": 50331649
      },
      "n": "Id",
      "d": 327756,
      "h": 566936010828,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(566936010828),
//--TRIMMABLE-BOUNDARY-START(584115880012),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504052300,
        "f": 50331649
      },
      "n": "MachineName",
      "d": 327756,
      "h": 584115880012,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(584115880012),
//--TRIMMABLE-BOUNDARY-START(588410847308),
    {
      "p": 393292,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093986892,
        "f": 50331649
      },
      "n": "MainModule",
      "d": 327756,
      "h": 588410847308,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(588410847308),
//--TRIMMABLE-BOUNDARY-START(592705814604),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683921484,
        "f": 50331649
      },
      "n": "MainWindowHandle",
      "d": 327756,
      "h": 592705814604,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(592705814604),
//--TRIMMABLE-BOUNDARY-START(597000781900),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273856076,
        "f": 50331649
      },
      "n": "MainWindowTitle",
      "d": 327756,
      "h": 597000781900,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(597000781900),
//--TRIMMABLE-BOUNDARY-START(601295749196),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863790668,
        "f": 50331649,
        "a": [
          {
            "t": 159252481,
            "c": 4454219777,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159252481,
            "c": 4454219777,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "maccatalyst",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 760209539148,
        "f": 83886081,
        "a": [
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "freebsd",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "macos",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "maccatalyst",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "MaxWorkingSet",
      "d": 327756,
      "h": 601295749196,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(601295749196),
//--TRIMMABLE-BOUNDARY-START(605590716492),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453725260,
        "f": 50331649,
        "a": [
          {
            "t": 159252481,
            "c": 4454219777,
            "a": [
              {
                "v": "ios",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159252481,
            "c": 4454219777,
            "a": [
              {
                "v": "tvos",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "maccatalyst",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 768799473740,
        "f": 83886081,
        "a": [
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "freebsd",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "macos",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "maccatalyst",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "MinWorkingSet",
      "d": 327756,
      "h": 605590716492,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(605590716492),
//--TRIMMABLE-BOUNDARY-START(609885683788),
    {
      "p": 458828,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043659852,
        "f": 50331649
      },
      "n": "Modules",
      "d": 327756,
      "h": 609885683788,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(609885683788),
//--TRIMMABLE-BOUNDARY-START(614180651084),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633594444,
        "f": 50331649
      },
      "n": "NonpagedSystemMemorySize",
      "d": 327756,
      "h": 614180651084,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(614180651084),
//--TRIMMABLE-BOUNDARY-START(618475618380),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223529036,
        "f": 50331649
      },
      "n": "NonpagedSystemMemorySize64",
      "d": 327756,
      "h": 618475618380,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(618475618380),
//--TRIMMABLE-BOUNDARY-START(631360520268),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813463628,
        "f": 50331649
      },
      "n": "PagedMemorySize",
      "d": 327756,
      "h": 631360520268,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(631360520268),
//--TRIMMABLE-BOUNDARY-START(635655487564),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403398220,
        "f": 50331649
      },
      "n": "PagedMemorySize64",
      "d": 327756,
      "h": 635655487564,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(635655487564),
//--TRIMMABLE-BOUNDARY-START(639950454860),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993332812,
        "f": 50331649
      },
      "n": "PagedSystemMemorySize",
      "d": 327756,
      "h": 639950454860,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(639950454860),
//--TRIMMABLE-BOUNDARY-START(644245422156),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583267404,
        "f": 50331649
      },
      "n": "PagedSystemMemorySize64",
      "d": 327756,
      "h": 644245422156,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(644245422156),
//--TRIMMABLE-BOUNDARY-START(648540389452),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173201996,
        "f": 50331649
      },
      "n": "PeakPagedMemorySize",
      "d": 327756,
      "h": 648540389452,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(648540389452),
//--TRIMMABLE-BOUNDARY-START(652835356748),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763136588,
        "f": 50331649
      },
      "n": "PeakPagedMemorySize64",
      "d": 327756,
      "h": 652835356748,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(652835356748),
//--TRIMMABLE-BOUNDARY-START(657130324044),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353071180,
        "f": 50331649
      },
      "n": "PeakVirtualMemorySize",
      "d": 327756,
      "h": 657130324044,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(657130324044),
//--TRIMMABLE-BOUNDARY-START(661425291340),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943005772,
        "f": 50331649
      },
      "n": "PeakVirtualMemorySize64",
      "d": 327756,
      "h": 661425291340,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(661425291340),
//--TRIMMABLE-BOUNDARY-START(665720258636),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313532940364,
        "f": 50331649
      },
      "n": "PeakWorkingSet",
      "d": 327756,
      "h": 665720258636,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(665720258636),
//--TRIMMABLE-BOUNDARY-START(670015225932),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322122874956,
        "f": 50331649
      },
      "n": "PeakWorkingSet64",
      "d": 327756,
      "h": 670015225932,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(670015225932),
//--TRIMMABLE-BOUNDARY-START(674310193228),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330712809548,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 777389408332,
        "f": 83886081
      },
      "n": "PriorityBoostEnabled",
      "d": 327756,
      "h": 674310193228,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(674310193228),
//--TRIMMABLE-BOUNDARY-START(678605160524),
    {
      "p": 524364,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339302744140,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 785979342924,
        "f": 83886081
      },
      "n": "PriorityClass",
      "d": 327756,
      "h": 678605160524,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(678605160524),
//--TRIMMABLE-BOUNDARY-START(682900127820),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347892678732,
        "f": 50331649
      },
      "n": "PrivateMemorySize",
      "d": 327756,
      "h": 682900127820,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(682900127820),
//--TRIMMABLE-BOUNDARY-START(687195095116),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356482613324,
        "f": 50331649
      },
      "n": "PrivateMemorySize64",
      "d": 327756,
      "h": 687195095116,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(687195095116),
//--TRIMMABLE-BOUNDARY-START(691490062412),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365072547916,
        "f": 50331649
      },
      "n": "PrivilegedProcessorTime",
      "d": 327756,
      "h": 691490062412,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(691490062412),
//--TRIMMABLE-BOUNDARY-START(695785029708),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373662482508,
        "f": 50331649
      },
      "n": "ProcessName",
      "d": 327756,
      "h": 695785029708,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(695785029708),
//--TRIMMABLE-BOUNDARY-START(700079997004),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382252417100,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 794569277516,
        "f": 83886081
      },
      "n": "ProcessorAffinity",
      "d": 327756,
      "h": 700079997004,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(700079997004),
//--TRIMMABLE-BOUNDARY-START(734439735372),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842351692,
        "f": 50331649
      },
      "n": "Responding",
      "d": 327756,
      "h": 734439735372,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(734439735372),
//--TRIMMABLE-BOUNDARY-START(738734702668),
    {
      "p": 65612,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432286284,
        "f": 50331649
      },
      "n": "SafeHandle",
      "d": 327756,
      "h": 738734702668,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(738734702668),
//--TRIMMABLE-BOUNDARY-START(743029669964),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022220876,
        "f": 50331649
      },
      "n": "SessionId",
      "d": 327756,
      "h": 743029669964,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(743029669964),
//--TRIMMABLE-BOUNDARY-START(816044113996),
    {
      "p": 95158273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612155468,
        "f": 50331649
      },
      "n": "StandardError",
      "d": 327756,
      "h": 816044113996,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(816044113996),
//--TRIMMABLE-BOUNDARY-START(820339081292),
    {
      "p": 95289345,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202090060,
        "f": 50331649
      },
      "n": "StandardInput",
      "d": 327756,
      "h": 820339081292,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(820339081292),
//--TRIMMABLE-BOUNDARY-START(824634048588),
    {
      "p": 95158273,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433792024652,
        "f": 50331649
      },
      "n": "StandardOutput",
      "d": 327756,
      "h": 824634048588,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(824634048588),
//--TRIMMABLE-BOUNDARY-START(858993786956),
    {
      "p": 589900,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442381959244,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 803159212108,
        "f": 83886081
      },
      "n": "StartInfo",
      "d": 327756,
      "h": 858993786956,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(858993786956),
//--TRIMMABLE-BOUNDARY-START(863288754252),
    {
      "p": 65142785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450971893836,
        "f": 50331649
      },
      "n": "StartTime",
      "d": 327756,
      "h": 863288754252,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(863288754252),
//--TRIMMABLE-BOUNDARY-START(867583721548),
    {
      "p": 1572904,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459561828428,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 811749146700,
        "f": 83886081
      },
      "n": "SynchronizingObject",
      "d": 327756,
      "h": 867583721548,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(867583721548),
//--TRIMMABLE-BOUNDARY-START(871878688844),
    {
      "p": 720972,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468151763020,
        "f": 50331649
      },
      "n": "Threads",
      "d": 327756,
      "h": 871878688844,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(871878688844),
//--TRIMMABLE-BOUNDARY-START(880468623436),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476741697612,
        "f": 50331649
      },
      "n": "TotalProcessorTime",
      "d": 327756,
      "h": 880468623436,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(880468623436),
//--TRIMMABLE-BOUNDARY-START(884763590732),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485331632204,
        "f": 50331649
      },
      "n": "UserProcessorTime",
      "d": 327756,
      "h": 884763590732,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(884763590732),
//--TRIMMABLE-BOUNDARY-START(889058558028),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493921566796,
        "f": 50331649
      },
      "n": "VirtualMemorySize",
      "d": 327756,
      "h": 889058558028,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(889058558028),
//--TRIMMABLE-BOUNDARY-START(893353525324),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502511501388,
        "f": 50331649
      },
      "n": "VirtualMemorySize64",
      "d": 327756,
      "h": 893353525324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(893353525324),
//--TRIMMABLE-BOUNDARY-START(927713263692),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511101435980,
        "f": 50331649
      },
      "n": "WorkingSet",
      "d": 327756,
      "h": 927713263692,
      "f": 2097153,
      "a": [
        {
          "t": 103612417,
          "c": 8693547009,
          "a": [
            {
              "v": "Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(927713263692),
//--TRIMMABLE-BOUNDARY-START(932008230988),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519691370572,
        "f": 50331649
      },
      "n": "WorkingSet64",
      "d": 327756,
      "h": 932008230988,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(932008230988)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655033420),
    {
      "r": 65537,
      "n": "BeginErrorReadLine",
      "d": 327756,
      "h": 38655033420,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655033420),
//--TRIMMABLE-BOUNDARY-START(42950000716),
    {
      "r": 65537,
      "n": "BeginOutputReadLine",
      "d": 327756,
      "h": 42950000716,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950000716),
//--TRIMMABLE-BOUNDARY-START(47244968012),
    {
      "r": 65537,
      "n": "CancelErrorRead",
      "d": 327756,
      "h": 47244968012,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244968012),
//--TRIMMABLE-BOUNDARY-START(51539935308),
    {
      "r": 65537,
      "n": "CancelOutputRead",
      "d": 327756,
      "h": 51539935308,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539935308),
//--TRIMMABLE-BOUNDARY-START(55834902604),
    {
      "r": 65537,
      "n": "Close",
      "d": 327756,
      "h": 55834902604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834902604),
//--TRIMMABLE-BOUNDARY-START(60129869900),
    {
      "r": 262145,
      "n": "CloseMainWindow",
      "d": 327756,
      "h": 60129869900,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129869900),
//--TRIMMABLE-BOUNDARY-START(ALL, 64424837196, 51539804200),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 327756,
      "h": 64424837196,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64424837196, 51539804200),
//--TRIMMABLE-BOUNDARY-START(73014771788),
    {
      "r": 65537,
      "n": "EnterDebugMode",
      "d": 327756,
      "h": 73014771788,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014771788),
//--TRIMMABLE-BOUNDARY-START(523986337868),
    {
      "r": 327756,
      "n": "GetCurrentProcess",
      "d": 327756,
      "h": 523986337868,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(523986337868),
//--TRIMMABLE-BOUNDARY-START(528281305164),
    {
      "r": 327756,
      "p": [
        {
          "n": "processId",
          "p": 655361
        }
      ],
      "n": "GetProcessById",
      "o": "@$1",
      "d": 327756,
      "h": 528281305164,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(528281305164),
//--TRIMMABLE-BOUNDARY-START(532576272460),
    {
      "r": 327756,
      "p": [
        {
          "n": "processId",
          "p": 655361
        },
        {
          "n": "machineName",
          "p": 1310721
        }
      ],
      "n": "GetProcessById",
      "d": 327756,
      "h": 532576272460,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(532576272460),
//--TRIMMABLE-BOUNDARY-START(536871239756),
    {
      "r": $.$typeArray($.$sdpc.System.Diagnostics.Process).$h,
      "n": "GetProcesses",
      "d": 327756,
      "h": 536871239756,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(536871239756),
//--TRIMMABLE-BOUNDARY-START(541166207052),
    {
      "r": $.$typeArray($.$sdpc.System.Diagnostics.Process).$h,
      "p": [
        {
          "n": "machineName",
          "p": 1310721
        }
      ],
      "n": "GetProcesses",
      "o": "@$1",
      "d": 327756,
      "h": 541166207052,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(541166207052),
//--TRIMMABLE-BOUNDARY-START(545461174348),
    {
      "r": $.$typeArray($.$sdpc.System.Diagnostics.Process).$h,
      "p": [
        {
          "n": "processName",
          "p": 1310721
        }
      ],
      "n": "GetProcessesByName",
      "o": "@$1",
      "d": 327756,
      "h": 545461174348,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(545461174348),
//--TRIMMABLE-BOUNDARY-START(549756141644),
    {
      "r": $.$typeArray($.$sdpc.System.Diagnostics.Process).$h,
      "p": [
        {
          "n": "processName",
          "p": 1310721
        },
        {
          "n": "machineName",
          "p": 1310721
        }
      ],
      "n": "GetProcessesByName",
      "d": 327756,
      "h": 549756141644,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(549756141644),
//--TRIMMABLE-BOUNDARY-START(571230978124),
    {
      "r": 65537,
      "n": "Kill",
      "d": 327756,
      "h": 571230978124,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(571230978124),
//--TRIMMABLE-BOUNDARY-START(575525945420),
    {
      "r": 65537,
      "p": [
        {
          "n": "entireProcessTree",
          "p": 262145
        }
      ],
      "n": "Kill",
      "o": "@$1",
      "d": 327756,
      "h": 575525945420,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(575525945420),
//--TRIMMABLE-BOUNDARY-START(579820912716),
    {
      "r": 65537,
      "n": "LeaveDebugMode",
      "d": 327756,
      "h": 579820912716,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(579820912716),
//--TRIMMABLE-BOUNDARY-START(622770585676),
    {
      "r": 65537,
      "n": "OnExited",
      "d": 327756,
      "h": 622770585676,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(622770585676),
//--TRIMMABLE-BOUNDARY-START(704374964300),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 327756,
      "h": 704374964300,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(704374964300),
//--TRIMMABLE-BOUNDARY-START(828929015884),
    {
      "r": 262145,
      "n": "Start",
      "d": 327756,
      "h": 828929015884,
      "f": 16777217,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(828929015884),
//--TRIMMABLE-BOUNDARY-START(833223983180),
    {
      "r": 327756,
      "p": [
        {
          "n": "startInfo",
          "p": 589900
        }
      ],
      "n": "Start",
      "o": "@$6",
      "d": 327756,
      "h": 833223983180,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(833223983180),
//--TRIMMABLE-BOUNDARY-START(837518950476),
    {
      "r": 327756,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        }
      ],
      "n": "Start",
      "o": "@$5",
      "d": 327756,
      "h": 837518950476,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(837518950476),
//--TRIMMABLE-BOUNDARY-START(841813917772),
    {
      "r": 327756,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": 1310721
        }
      ],
      "n": "Start",
      "o": "@$4",
      "d": 327756,
      "h": 841813917772,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(841813917772),
//--TRIMMABLE-BOUNDARY-START(846108885068),
    {
      "r": 327756,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        }
      ],
      "n": "Start",
      "o": "@$1",
      "d": 327756,
      "h": 846108885068,
      "f": 16777249,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(846108885068),
//--TRIMMABLE-BOUNDARY-START(850403852364),
    {
      "r": 327756,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 161284097
        },
        {
          "n": "domain",
          "p": 1310721
        }
      ],
      "n": "Start",
      "o": "@$2",
      "d": 327756,
      "h": 850403852364,
      "f": 16777249,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(850403852364),
//--TRIMMABLE-BOUNDARY-START(854698819660),
    {
      "r": 327756,
      "p": [
        {
          "n": "fileName",
          "p": 1310721
        },
        {
          "n": "arguments",
          "p": 1310721
        },
        {
          "n": "userName",
          "p": 1310721
        },
        {
          "n": "password",
          "p": 161284097
        },
        {
          "n": "domain",
          "p": 1310721
        }
      ],
      "n": "Start",
      "o": "@$3",
      "d": 327756,
      "h": 854698819660,
      "f": 16777249,
      "a": [
        {
          "t": 54132737,
          "c": 8644067329,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(854698819660),
//--TRIMMABLE-BOUNDARY-START(ALL, 876173656140, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 327756,
      "h": 876173656140,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 876173656140, 330712612865),
//--TRIMMABLE-BOUNDARY-START(897648492620),
    {
      "r": 65537,
      "n": "WaitForExit",
      "d": 327756,
      "h": 897648492620,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(897648492620),
//--TRIMMABLE-BOUNDARY-START(901943459916),
    {
      "r": 262145,
      "p": [
        {
          "n": "milliseconds",
          "p": 655361
        }
      ],
      "n": "WaitForExit",
      "o": "@$1",
      "d": 327756,
      "h": 901943459916,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(901943459916),
//--TRIMMABLE-BOUNDARY-START(906238427212),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "WaitForExit",
      "o": "@$2",
      "d": 327756,
      "h": 906238427212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(906238427212),
//--TRIMMABLE-BOUNDARY-START(910533394508),
    {
      "r": 177537025,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "WaitForExitAsync",
      "d": 327756,
      "h": 910533394508,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(910533394508),
//--TRIMMABLE-BOUNDARY-START(914828361804),
    {
      "r": 262145,
      "n": "WaitForInputIdle",
      "d": 327756,
      "h": 914828361804,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(914828361804),
//--TRIMMABLE-BOUNDARY-START(919123329100),
    {
      "r": 262145,
      "p": [
        {
          "n": "milliseconds",
          "p": 655361
        }
      ],
      "n": "WaitForInputIdle",
      "o": "@$1",
      "d": 327756,
      "h": 919123329100,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(919123329100),
//--TRIMMABLE-BOUNDARY-START(923418296396),
    {
      "r": 262145,
      "p": [
        {
          "n": "timeout",
          "p": 185729025
        }
      ],
      "n": "WaitForInputIdle",
      "o": "@$2",
      "d": 327756,
      "h": 923418296396,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(923418296396)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295052),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327756,
      "h": 4295295052,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295052)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(77309739084),
    {
      "e": 196684,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196684
          }
        ],
        "n": "add_ErrorDataReceived",
        "d": 327756,
        "h": 12885229644,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196684
          }
        ],
        "n": "remove_ErrorDataReceived",
        "d": 327756,
        "h": 712964898892,
        "f": 285212673
      },
      "n": "ErrorDataReceived",
      "d": 327756,
      "h": 77309739084,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(77309739084),
//--TRIMMABLE-BOUNDARY-START(85899673676),
    {
      "e": 79691777,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79691777
          }
        ],
        "n": "add_Exited",
        "d": 327756,
        "h": 21475164236,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 79691777
          }
        ],
        "n": "remove_Exited",
        "d": 327756,
        "h": 721554833484,
        "f": 285212673
      },
      "n": "Exited",
      "d": 327756,
      "h": 85899673676,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(85899673676),
//--TRIMMABLE-BOUNDARY-START(627065552972),
    {
      "e": 196684,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196684
          }
        ],
        "n": "add_OutputDataReceived",
        "d": 327756,
        "h": 30065098828,
        "f": 150994945
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 196684
          }
        ],
        "n": "remove_OutputDataReceived",
        "d": 327756,
        "h": 730144768076,
        "f": 285212673
      },
      "n": "OutputDataReceived",
      "d": 327756,
      "h": 627065552972,
      "f": 8388609
    },
//--TRIMMABLE-BOUNDARY-END(627065552972)
  ],
  "i": [1048616,90177537
  ],
  "h": 327756,
  "a": [
    {
      "t": 458792,
      "c": 8590393384,
      "a": [
        {
          "v": "System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327756)
        
        
        //--TRIMMABLE-BOUNDARY-START(393292)
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            //--TRIMMABLE-BOUNDARY-START(4295360588)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360588);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360588)
            
            //--TRIMMABLE-BOUNDARY-START(8590327884)
            /*System.IntPtr */ get BaseAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327884)
            
            //--TRIMMABLE-BOUNDARY-START(12885295180)
            /*System.IntPtr */ get EntryPointAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295180)
            
            //--TRIMMABLE-BOUNDARY-START(17180262476)
            /*string */ get FileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180262476)
            
            //--TRIMMABLE-BOUNDARY-START(21475229772)
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475229772)
            
            //--TRIMMABLE-BOUNDARY-START(77309804620)
            /*int */ get ModuleMemorySize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309804620)
            
            //--TRIMMABLE-BOUNDARY-START(81604771916)
            /*string */ get ModuleName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604771916)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 85899739212, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 85899739212, 330712612865)
            
            static $h = 393292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196648,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590327884),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065164364,
        "f": 50331649
      },
      "n": "BaseAddress",
      "d": 393292,
      "h": 8590327884,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590327884),
//--TRIMMABLE-BOUNDARY-START(12885295180),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098956,
        "f": 50331649
      },
      "n": "EntryPointAddress",
      "d": 393292,
      "h": 12885295180,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885295180),
//--TRIMMABLE-BOUNDARY-START(17180262476),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245033548,
        "f": 50331649
      },
      "n": "FileName",
      "d": 393292,
      "h": 17180262476,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180262476),
//--TRIMMABLE-BOUNDARY-START(21475229772),
    {
      "p": 65614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834968140,
        "f": 50331649
      },
      "n": "FileVersionInfo",
      "d": 393292,
      "h": 21475229772,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475229772),
//--TRIMMABLE-BOUNDARY-START(77309804620),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424902732,
        "f": 50331649
      },
      "n": "ModuleMemorySize",
      "d": 393292,
      "h": 77309804620,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309804620),
//--TRIMMABLE-BOUNDARY-START(81604771916),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014837324,
        "f": 50331649
      },
      "n": "ModuleName",
      "d": 393292,
      "h": 81604771916,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771916)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 85899739212, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 393292,
      "h": 85899739212,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 85899739212, 330712612865)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360588),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393292,
      "h": 4295360588,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295360588)
  ],
  "i": [1048616,90177537
  ],
  "h": 393292,
  "a": [
    {
      "t": 458792,
      "c": 8590393384,
      "a": [
        {
          "v": "System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393292)
        
        
        //--TRIMMABLE-BOUNDARY-START(655436)
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            //--TRIMMABLE-BOUNDARY-START(4295622732)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622732)
            
            //--TRIMMABLE-BOUNDARY-START(8590590028)
            /*int */ get BasePriority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590590028)
            
            //--TRIMMABLE-BOUNDARY-START(12885557324)
            /*int */ get CurrentPriority()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885557324)
            
            //--TRIMMABLE-BOUNDARY-START(120259739724)
            /*int */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655361100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259739724)
            
            //--TRIMMABLE-BOUNDARY-START(124554707020)
            /*int */ set IdealProcessor(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619478092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554707020)
            
            //--TRIMMABLE-BOUNDARY-START(128849674316)
            /*bool */ get PriorityBoostEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245295692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209412684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849674316)
            
            //--TRIMMABLE-BOUNDARY-START(133144641612)
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835230284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799347276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144641612)
            
            //--TRIMMABLE-BOUNDARY-START(137439608908)
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425164876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439608908)
            
            //--TRIMMABLE-BOUNDARY-START(141734576204)
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389281868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734576204)
            
            //--TRIMMABLE-BOUNDARY-START(184684249164)
            /*System.IntPtr */ get StartAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015099468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684249164)
            
            //--TRIMMABLE-BOUNDARY-START(188979216460)
            /*System.DateTime */ get StartTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605034060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979216460)
            
            //--TRIMMABLE-BOUNDARY-START(193274183756)
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194968652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274183756)
            
            //--TRIMMABLE-BOUNDARY-START(197569151052)
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784903244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569151052)
            
            //--TRIMMABLE-BOUNDARY-START(201864118348)
            /*System.TimeSpan */ get UserProcessorTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374837836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864118348)
            
            //--TRIMMABLE-BOUNDARY-START(206159085644)
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964772428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159085644)
            
            //--TRIMMABLE-BOUNDARY-START(146029543500)
            /*void */ ResetIdealProcessor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029543500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(146029543500)
            
            static $h = 655436;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196648,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590590028),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475491916,
        "f": 50331649
      },
      "n": "BasePriority",
      "d": 655436,
      "h": 8590590028,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590590028),
//--TRIMMABLE-BOUNDARY-START(12885557324),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065426508,
        "f": 50331649
      },
      "n": "CurrentPriority",
      "d": 655436,
      "h": 12885557324,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885557324),
//--TRIMMABLE-BOUNDARY-START(120259739724),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655361100,
        "f": 50331649
      },
      "n": "Id",
      "d": 655436,
      "h": 120259739724,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259739724),
//--TRIMMABLE-BOUNDARY-START(124554707020),
    {
      "p": 655361,
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619478092,
        "f": 83886081
      },
      "n": "IdealProcessor",
      "d": 655436,
      "h": 124554707020,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554707020),
//--TRIMMABLE-BOUNDARY-START(128849674316),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245295692,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209412684,
        "f": 83886081
      },
      "n": "PriorityBoostEnabled",
      "d": 655436,
      "h": 128849674316,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849674316),
//--TRIMMABLE-BOUNDARY-START(133144641612),
    {
      "p": 852044,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835230284,
        "f": 50331649,
        "a": [
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "linux",
                "t": 1310721
              }
            ]
          },
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "freebsd",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799347276,
        "f": 83886081,
        "a": [
          {
            "t": 158924801,
            "c": 4453892097,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "PriorityLevel",
      "d": 655436,
      "h": 133144641612,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144641612),
//--TRIMMABLE-BOUNDARY-START(137439608908),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425164876,
        "f": 50331649
      },
      "n": "PrivilegedProcessorTime",
      "d": 655436,
      "h": 137439608908,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439608908),
//--TRIMMABLE-BOUNDARY-START(141734576204),
    {
      "p": 786433,
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389281868,
        "f": 83886081
      },
      "n": "ProcessorAffinity",
      "d": 655436,
      "h": 141734576204,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734576204),
//--TRIMMABLE-BOUNDARY-START(184684249164),
    {
      "p": 786433,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015099468,
        "f": 50331649
      },
      "n": "StartAddress",
      "d": 655436,
      "h": 184684249164,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684249164),
//--TRIMMABLE-BOUNDARY-START(188979216460),
    {
      "p": 65142785,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605034060,
        "f": 50331649
      },
      "n": "StartTime",
      "d": 655436,
      "h": 188979216460,
      "f": 2097153,
      "a": [
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979216460),
//--TRIMMABLE-BOUNDARY-START(193274183756),
    {
      "p": 917580,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194968652,
        "f": 50331649
      },
      "n": "ThreadState",
      "d": 655436,
      "h": 193274183756,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274183756),
//--TRIMMABLE-BOUNDARY-START(197569151052),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784903244,
        "f": 50331649
      },
      "n": "TotalProcessorTime",
      "d": 655436,
      "h": 197569151052,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569151052),
//--TRIMMABLE-BOUNDARY-START(201864118348),
    {
      "p": 185729025,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374837836,
        "f": 50331649
      },
      "n": "UserProcessorTime",
      "d": 655436,
      "h": 201864118348,
      "f": 2097153,
      "a": [
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159252481,
          "c": 4454219777,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 158924801,
          "c": 4453892097,
          "a": [
            {
              "v": "maccatalyst",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864118348),
//--TRIMMABLE-BOUNDARY-START(206159085644),
    {
      "p": 983116,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964772428,
        "f": 50331649
      },
      "n": "WaitReason",
      "d": 655436,
      "h": 206159085644,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159085644)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(146029543500),
    {
      "r": 65537,
      "n": "ResetIdealProcessor",
      "d": 655436,
      "h": 146029543500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029543500)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622732),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655436,
      "h": 4295622732,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295622732)
  ],
  "i": [1048616,90177537
  ],
  "h": 655436,
  "a": [
    {
      "t": 458792,
      "c": 8590393384,
      "a": [
        {
          "v": "System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655436)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading.ThreadPool"))
//--TRIMMABLE-BOUNDARY-END(76)
