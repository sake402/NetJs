
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $ssc, $sris, $scp, $sdf, $sifd, $sspw, $scs, $ssa, $mwr, $sip) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":52554,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 642378;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25770446154,"f":1},"n":"ArgumentList","d":642378,"h":21475478858,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360380746,"f":1},"s":{"r":0,"d":0,"h":38655348042,"f":1},"n":"Arguments","d":642378,"h":30065413450,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245282634,"f":1},"s":{"r":0,"d":0,"h":51540249930,"f":1},"n":"CreateNewProcessGroup","d":642378,"h":42950315338,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130184522,"f":1},"s":{"r":0,"d":0,"h":64425151818,"f":1},"n":"CreateNoWindow","d":642378,"h":55835217226,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015086410,"f":1},"s":{"r":0,"d":0,"h":77310053706,"f":1},"n":"Domain","d":642378,"h":68720119114,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":85899988298,"f":1},"n":"Environment","d":642378,"h":81605021002,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94489922890,"f":1},"n":"EnvironmentVariables","d":642378,"h":90194955594,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079857482,"f":1},"s":{"r":0,"d":0,"h":107374824778,"f":1},"n":"ErrorDialog","d":642378,"h":98784890186,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115964759370,"f":1},"s":{"r":0,"d":0,"h":120259726666,"f":1},"n":"ErrorDialogParentHandle","d":642378,"h":111669792074,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849661258,"f":1},"s":{"r":0,"d":0,"h":133144628554,"f":1},"n":"FileName","d":642378,"h":124554693962,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734563146,"f":1},"s":{"r":0,"d":0,"h":146029530442,"f":1},"n":"LoadUserProfile","d":642378,"h":137439595850,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619465034,"f":1},"s":{"r":0,"d":0,"h":158914432330,"f":1},"n":"UseCredentialsForNetworkingOnly","d":642378,"h":150324497738,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":117309441,"g":{"r":0,"d":0,"h":167504366922,"f":1},"s":{"r":0,"d":0,"h":171799334218,"f":1},"n":"Password","d":642378,"h":163209399626,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389268810,"f":1},"s":{"r":0,"d":0,"h":184684236106,"f":1},"n":"PasswordInClearText","d":642378,"h":176094301514,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274170698,"f":1},"s":{"r":0,"d":0,"h":197569137994,"f":1},"n":"RedirectStandardError","d":642378,"h":188979203402,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":206159072586,"f":1},"s":{"r":0,"d":0,"h":210454039882,"f":1},"n":"RedirectStandardInput","d":642378,"h":201864105290,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":219043974474,"f":1},"s":{"r":0,"d":0,"h":223338941770,"f":1},"n":"RedirectStandardOutput","d":642378,"h":214749007178,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":231928876362,"f":1},"s":{"r":0,"d":0,"h":236223843658,"f":1},"n":"StandardErrorEncoding","d":642378,"h":227633909066,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":244813778250,"f":1},"s":{"r":0,"d":0,"h":249108745546,"f":1},"n":"StandardInputEncoding","d":642378,"h":240518810954,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":257698680138,"f":1},"s":{"r":0,"d":0,"h":261993647434,"f":1},"n":"StandardOutputEncoding","d":642378,"h":253403712842,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":270583582026,"f":1},"s":{"r":0,"d":0,"h":274878549322,"f":1},"n":"UserName","d":642378,"h":266288614730,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":283468483914,"f":1},"s":{"r":0,"d":0,"h":287763451210,"f":1},"n":"UseShellExecute","d":642378,"h":279173516618,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":296353385802,"f":1},"s":{"r":0,"d":0,"h":300648353098,"f":1},"n":"Verb","d":642378,"h":292058418506,"f":1,"a":[{"t":33095681,"c":60162637825,"a":[{"v":"","t":1310721}]}]},{"p":0,"g":{"r":0,"d":0,"h":309238287690,"f":1},"n":"Verbs","d":642378,"h":304943320394,"f":1},{"p":838986,"g":{"r":0,"d":0,"h":317828222282,"f":1},"s":{"r":0,"d":0,"h":322123189578,"f":1},"n":"WindowStyle","d":642378,"h":313533254986,"f":1,"a":[{"t":33095681,"c":64457605121,"a":[{"v":0,"t":838986}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713124170,"f":1},"s":{"r":0,"d":0,"h":335008091466,"f":1},"n":"WorkingDirectory","d":642378,"h":326418156874,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":642378,"h":4295609674,"f":1},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":642378,"h":8590576970,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":642378,"h":12885544266,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":642378,"h":17180511562,"f":1}],"h":642378}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 511306;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":445770,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180380490,"f":1},"n":"Item","o":"@$2","d":511306,"h":12885413194,"f":1}],"m":[{"r":262145,"p":[{"n":"module","p":445770}],"n":"Contains","d":511306,"h":21475347786,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":511306,"h":25770315082,"f":1},{"r":655361,"p":[{"n":"module","p":445770}],"n":"IndexOf","d":511306,"h":30065282378,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":511306,"h":4295478602,"f":4},{"p":[{"n":"processModules","p":0}],"n":".ctor","o":"$ctor$3","d":511306,"h":8590445898,"f":1}],"i":[31326209,31588353],"h":511306}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 773450;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":707914,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180642634,"f":1},"n":"Item","o":"@$2","d":773450,"h":12885675338,"f":1}],"m":[{"r":655361,"p":[{"n":"thread","p":707914}],"n":"Add","d":773450,"h":21475609930,"f":1},{"r":262145,"p":[{"n":"thread","p":707914}],"n":"Contains","d":773450,"h":25770577226,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":773450,"h":30065544522,"f":1},{"r":655361,"p":[{"n":"thread","p":707914}],"n":"IndexOf","d":773450,"h":34360511818,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":707914}],"n":"Insert","d":773450,"h":38655479114,"f":1},{"r":65537,"p":[{"n":"thread","p":707914}],"n":"Remove","d":773450,"h":42950446410,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":773450,"h":4295740746,"f":4},{"p":[{"n":"processThreads","p":0}],"n":".ctor","o":"$ctor$3","d":773450,"h":8590708042,"f":1}],"i":[31326209,31588353],"h":773450}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$spc.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 576842;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":576842,"n":"Normal","d":576842,"h":4295544138,"f":33},{"t":576842,"n":"Idle","d":576842,"h":8590511434,"f":33},{"t":576842,"n":"High","d":576842,"h":12885478730,"f":33},{"t":576842,"n":"RealTime","d":576842,"h":17180446026,"f":33},{"t":576842,"n":"BelowNormal","d":576842,"h":21475413322,"f":33},{"t":576842,"n":"AboveNormal","d":576842,"h":25770380618,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":576842,"h":30065347914,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":576842}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 838986;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":838986,"n":"Normal","d":838986,"h":4295806282,"f":33},{"t":838986,"n":"Hidden","d":838986,"h":8590773578,"f":33},{"t":838986,"n":"Minimized","d":838986,"h":12885740874,"f":33},{"t":838986,"n":"Maximized","d":838986,"h":17180708170,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":838986,"h":21475675466,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":838986}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$spc.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 904522;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":904522,"n":"Idle","d":904522,"h":4295871818,"f":33},{"t":904522,"n":"Lowest","d":904522,"h":8590839114,"f":33},{"t":904522,"n":"BelowNormal","d":904522,"h":12885806410,"f":33},{"t":904522,"n":"Normal","d":904522,"h":17180773706,"f":33},{"t":904522,"n":"AboveNormal","d":904522,"h":21475741002,"f":33},{"t":904522,"n":"Highest","d":904522,"h":25770708298,"f":33},{"t":904522,"n":"TimeCritical","d":904522,"h":30065675594,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":904522,"h":34360642890,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":904522}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$spc.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 970058;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":970058,"n":"Initialized","d":970058,"h":4295937354,"f":33},{"t":970058,"n":"Ready","d":970058,"h":8590904650,"f":33},{"t":970058,"n":"Running","d":970058,"h":12885871946,"f":33},{"t":970058,"n":"Standby","d":970058,"h":17180839242,"f":33},{"t":970058,"n":"Terminated","d":970058,"h":21475806538,"f":33},{"t":970058,"n":"Wait","d":970058,"h":25770773834,"f":33},{"t":970058,"n":"Transition","d":970058,"h":30065741130,"f":33},{"t":970058,"n":"Unknown","d":970058,"h":34360708426,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":970058,"h":38655675722,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":970058}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$spc.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1035594;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1035594,"n":"Executive","d":1035594,"h":4296002890,"f":33},{"t":1035594,"n":"FreePage","d":1035594,"h":8590970186,"f":33},{"t":1035594,"n":"PageIn","d":1035594,"h":12885937482,"f":33},{"t":1035594,"n":"SystemAllocation","d":1035594,"h":17180904778,"f":33},{"t":1035594,"n":"ExecutionDelay","d":1035594,"h":21475872074,"f":33},{"t":1035594,"n":"Suspended","d":1035594,"h":25770839370,"f":33},{"t":1035594,"n":"UserRequest","d":1035594,"h":30065806666,"f":33},{"t":1035594,"n":"EventPairHigh","d":1035594,"h":34360773962,"f":33},{"t":1035594,"n":"EventPairLow","d":1035594,"h":38655741258,"f":33},{"t":1035594,"n":"LpcReceive","d":1035594,"h":42950708554,"f":33},{"t":1035594,"n":"LpcReply","d":1035594,"h":47245675850,"f":33},{"t":1035594,"n":"VirtualMemory","d":1035594,"h":51540643146,"f":33},{"t":1035594,"n":"PageOut","d":1035594,"h":55835610442,"f":33},{"t":1035594,"n":"Unknown","d":1035594,"h":60130577738,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1035594,"h":64425545034,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1035594}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118090;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":118090,"h":12885019978,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":118090,"h":4295085386,"f":1},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":118090,"h":8590052682,"f":1}],"i":[57475073],"h":118090}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 183626;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885085514,"f":1},"n":"Data","d":183626,"h":8590118218,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":183626,"h":4295150922,"f":8}],"h":183626}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 314698;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885216586,"f":32769},"n":"Description","d":314698,"h":8590249290,"f":32769}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":314698,"h":4295281994,"f":1}],"h":314698,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 249162;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":183626}],"n":"Invoke","d":249162,"h":8590183754,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":183626},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":249162,"h":12885151050,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":249162,"h":17180118346,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":249162,"h":4295216458,"f":1}],"i":[57147393,113377281],"h":249162}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$remove(value)
            {
            }
            /*System.EventHandler*/ Exited$add(value)
            {
            }
            /*System.EventHandler*/ Exited$remove(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$remove(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$1(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$2(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$3(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$5(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 380234;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885282122,"f":1},"n":"BasePriority","d":380234,"h":8590314826,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475216714,"f":1},"s":{"r":0,"d":0,"h":25770184010,"f":1},"n":"EnableRaisingEvents","d":380234,"h":17180249418,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360118602,"f":1},"n":"ExitCode","d":380234,"h":30065151306,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":42950053194,"f":1},"n":"ExitTime","d":380234,"h":38655085898,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":51539987786,"f":1},"n":"Handle","d":380234,"h":47245020490,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":60129922378,"f":1},"n":"HandleCount","d":380234,"h":55834955082,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719856970,"f":1},"n":"HasExited","d":380234,"h":64424889674,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309791562,"f":1},"n":"Id","d":380234,"h":73014824266,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899726154,"f":1},"n":"MachineName","d":380234,"h":81604758858,"f":1},{"p":445770,"g":{"r":0,"d":0,"h":94489660746,"f":1},"n":"MainModule","d":380234,"h":90194693450,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":103079595338,"f":1},"n":"MainWindowHandle","d":380234,"h":98784628042,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669529930,"f":1},"n":"MainWindowTitle","d":380234,"h":107374562634,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":120259464522,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554431818,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":380234,"h":115964497226,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":133144366410,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439333706,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":380234,"h":128849399114,"f":1},{"p":511306,"g":{"r":0,"d":0,"h":146029268298,"f":1},"n":"Modules","d":380234,"h":141734301002,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":154619202890,"f":1},"n":"NonpagedSystemMemorySize","d":380234,"h":150324235594,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209137482,"f":1},"n":"NonpagedSystemMemorySize64","d":380234,"h":158914170186,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799072074,"f":1},"n":"PagedMemorySize","d":380234,"h":167504104778,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180389006666,"f":1},"n":"PagedMemorySize64","d":380234,"h":176094039370,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":188978941258,"f":1},"n":"PagedSystemMemorySize","d":380234,"h":184683973962,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568875850,"f":1},"n":"PagedSystemMemorySize64","d":380234,"h":193273908554,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":206158810442,"f":1},"n":"PeakPagedMemorySize","d":380234,"h":201863843146,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748745034,"f":1},"n":"PeakPagedMemorySize64","d":380234,"h":210453777738,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":223338679626,"f":1},"n":"PeakVirtualMemorySize","d":380234,"h":219043712330,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928614218,"f":1},"n":"PeakVirtualMemorySize64","d":380234,"h":227633646922,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":240518548810,"f":1},"n":"PeakWorkingSet","d":380234,"h":236223581514,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108483402,"f":1},"n":"PeakWorkingSet64","d":380234,"h":244813516106,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":257698417994,"f":1},"s":{"r":0,"d":0,"h":261993385290,"f":1},"n":"PriorityBoostEnabled","d":380234,"h":253403450698,"f":1},{"p":576842,"g":{"r":0,"d":0,"h":270583319882,"f":1},"s":{"r":0,"d":0,"h":274878287178,"f":1},"n":"PriorityClass","d":380234,"h":266288352586,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":283468221770,"f":1},"n":"PrivateMemorySize","d":380234,"h":279173254474,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058156362,"f":1},"n":"PrivateMemorySize64","d":380234,"h":287763189066,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":300648090954,"f":1},"n":"PrivilegedProcessorTime","d":380234,"h":296353123658,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238025546,"f":1},"n":"ProcessName","d":380234,"h":304943058250,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":317827960138,"f":1},"s":{"r":0,"d":0,"h":322122927434,"f":1},"n":"ProcessorAffinity","d":380234,"h":313532992842,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712862026,"f":1},"n":"Responding","d":380234,"h":326417894730,"f":1},{"p":118090,"g":{"r":0,"d":0,"h":339302796618,"f":1},"n":"SafeHandle","d":380234,"h":335007829322,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":347892731210,"f":1},"n":"SessionId","d":380234,"h":343597763914,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":356482665802,"f":1},"n":"StandardError","d":380234,"h":352187698506,"f":1},{"p":62586881,"g":{"r":0,"d":0,"h":365072600394,"f":1},"n":"StandardInput","d":380234,"h":360777633098,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":373662534986,"f":1},"n":"StandardOutput","d":380234,"h":369367567690,"f":1},{"p":642378,"g":{"r":0,"d":0,"h":382252469578,"f":1},"s":{"r":0,"d":0,"h":386547436874,"f":1},"n":"StartInfo","d":380234,"h":377957502282,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":395137371466,"f":1},"n":"StartTime","d":380234,"h":390842404170,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727306058,"f":1},"s":{"r":0,"d":0,"h":408022273354,"f":1},"n":"SynchronizingObject","d":380234,"h":399432338762,"f":1},{"p":773450,"g":{"r":0,"d":0,"h":416612207946,"f":1},"n":"Threads","d":380234,"h":412317240650,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":425202142538,"f":1},"n":"TotalProcessorTime","d":380234,"h":420907175242,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":433792077130,"f":1},"n":"UserProcessorTime","d":380234,"h":429497109834,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442382011722,"f":1},"n":"VirtualMemorySize","d":380234,"h":438087044426,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971946314,"f":1},"n":"VirtualMemorySize64","d":380234,"h":446676979018,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":459561880906,"f":1},"n":"WorkingSet","d":380234,"h":455266913610,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151815498,"f":1},"n":"WorkingSet64","d":380234,"h":463856848202,"f":1}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":380234,"h":511101488458,"f":1},{"r":65537,"n":"BeginOutputReadLine","d":380234,"h":515396455754,"f":1},{"r":65537,"n":"CancelErrorRead","d":380234,"h":519691423050,"f":1},{"r":65537,"n":"CancelOutputRead","d":380234,"h":523986390346,"f":1},{"r":65537,"n":"Close","d":380234,"h":528281357642,"f":1},{"r":262145,"n":"CloseMainWindow","d":380234,"h":532576324938,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":380234,"h":536871292234,"f":32772},{"r":65537,"n":"EnterDebugMode","d":380234,"h":541166259530,"f":33},{"r":380234,"n":"GetCurrentProcess","d":380234,"h":545461226826,"f":33},{"r":380234,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","d":380234,"h":549756194122,"f":33},{"r":380234,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","o":"@$1","d":380234,"h":554051161418,"f":33},{"r":0,"n":"GetProcesses","d":380234,"h":558346128714,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":380234,"h":562641096010,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","d":380234,"h":566936063306,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":380234,"h":571231030602,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":380234,"h":575525997898,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":380234,"h":579820965194,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":380234,"h":584115932490,"f":33},{"r":65537,"n":"OnExited","d":380234,"h":588410899786,"f":4},{"r":65537,"n":"Refresh","d":380234,"h":592705867082,"f":1},{"r":262145,"n":"Start","d":380234,"h":597000834378,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380234,"p":[{"n":"startInfo","p":642378}],"n":"Start","o":"@$1","d":380234,"h":601295801674,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380234,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$2","d":380234,"h":605590768970,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380234,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$3","d":380234,"h":609885736266,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380234,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Start","o":"@$4","d":380234,"h":614180703562,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380234,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$5","d":380234,"h":618475670858,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":380234,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$6","d":380234,"h":622770638154,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":380234,"h":627065605450,"f":32769},{"r":65537,"n":"WaitForExit","d":380234,"h":631360572746,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":380234,"h":635655540042,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForExit","o":"@$2","d":380234,"h":639950507338,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitForExitAsync","d":380234,"h":644245474634,"f":1},{"r":262145,"n":"WaitForInputIdle","d":380234,"h":648540441930,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":380234,"h":652835409226,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForInputIdle","o":"@$2","d":380234,"h":657130376522,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":380234,"h":4295347530,"f":1}],"e":[{"e":249162,"m":{"r":65537,"p":[{"n":"value","p":249162}],"n":"add_ErrorDataReceived","d":380234,"h":476741750090,"f":1},"r":{"r":65537,"p":[{"n":"value","p":249162}],"n":"remove_ErrorDataReceived","d":380234,"h":481036717386,"f":1},"n":"ErrorDataReceived","d":380234,"h":472446782794,"f":1},{"e":46989313,"m":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"add_Exited","d":380234,"h":489626651978,"f":1},"r":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"remove_Exited","d":380234,"h":493921619274,"f":1},"n":"Exited","d":380234,"h":485331684682,"f":1},{"e":249162,"m":{"r":65537,"p":[{"n":"value","p":249162}],"n":"add_OutputDataReceived","d":380234,"h":502511553866,"f":1},"r":{"r":65537,"p":[{"n":"value","p":249162}],"n":"remove_OutputDataReceived","d":380234,"h":506806521162,"f":1},"n":"OutputDataReceived","d":380234,"h":498216586570,"f":1}],"i":[1048615,57475073],"h":380234,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 445770;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885347658,"f":1},"n":"BaseAddress","d":445770,"h":8590380362,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":21475282250,"f":1},"n":"EntryPointAddress","d":445770,"h":17180314954,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065216842,"f":1},"n":"FileName","d":445770,"h":25770249546,"f":1},{"p":104536,"g":{"r":0,"d":0,"h":38655151434,"f":1},"n":"FileVersionInfo","d":445770,"h":34360184138,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245086026,"f":1},"n":"ModuleMemorySize","d":445770,"h":42950118730,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835020618,"f":1},"n":"ModuleName","d":445770,"h":51540053322,"f":1}],"m":[{"r":1310721,"n":"ToString","d":445770,"h":60129987914,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":445770,"h":4295413066,"f":8}],"i":[1048615,57475073],"h":445770,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 707914;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885609802,"f":1},"n":"BasePriority","d":707914,"h":8590642506,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":21475544394,"f":1},"n":"CurrentPriority","d":707914,"h":17180577098,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065478986,"f":1},"n":"Id","d":707914,"h":25770511690,"f":1},{"p":655361,"s":{"r":0,"d":0,"h":38655413578,"f":1},"n":"IdealProcessor","d":707914,"h":34360446282,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245348170,"f":1},"s":{"r":0,"d":0,"h":51540315466,"f":1},"n":"PriorityBoostEnabled","d":707914,"h":42950380874,"f":1},{"p":904522,"g":{"r":0,"d":0,"h":60130250058,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425217354,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":707914,"h":55835282762,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015151946,"f":1},"n":"PrivilegedProcessorTime","d":707914,"h":68720184650,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605086538,"f":1},"n":"ProcessorAffinity","d":707914,"h":77310119242,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195021130,"f":1},"n":"StartAddress","d":707914,"h":85900053834,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":98784955722,"f":1},"n":"StartTime","d":707914,"h":94489988426,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":970058,"g":{"r":0,"d":0,"h":107374890314,"f":1},"n":"ThreadState","d":707914,"h":103079923018,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":115964824906,"f":1},"n":"TotalProcessorTime","d":707914,"h":111669857610,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":124554759498,"f":1},"n":"UserProcessorTime","d":707914,"h":120259792202,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1035594,"g":{"r":0,"d":0,"h":133144694090,"f":1},"n":"WaitReason","d":707914,"h":128849726794,"f":1}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":707914,"h":137439661386,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":707914,"h":4295675210,"f":8}],"i":[1048615,57475073],"h":707914,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Specialized", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.IO.Pipes"))