
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $ssc, $sris, $scp, $sdf, $sifd, $sspw, $scs, $ssa, $mwr, $sip) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":64963,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 654787;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25770458563,"f":1},"n":"ArgumentList","d":654787,"h":21475491267,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360393155,"f":1},"s":{"r":0,"d":0,"h":38655360451,"f":1},"n":"Arguments","d":654787,"h":30065425859,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245295043,"f":1},"s":{"r":0,"d":0,"h":51540262339,"f":1},"n":"CreateNewProcessGroup","d":654787,"h":42950327747,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130196931,"f":1},"s":{"r":0,"d":0,"h":64425164227,"f":1},"n":"CreateNoWindow","d":654787,"h":55835229635,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015098819,"f":1},"s":{"r":0,"d":0,"h":77310066115,"f":1},"n":"Domain","d":654787,"h":68720131523,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":85900000707,"f":1},"n":"Environment","d":654787,"h":81605033411,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94489935299,"f":1},"n":"EnvironmentVariables","d":654787,"h":90194968003,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079869891,"f":1},"s":{"r":0,"d":0,"h":107374837187,"f":1},"n":"ErrorDialog","d":654787,"h":98784902595,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115964771779,"f":1},"s":{"r":0,"d":0,"h":120259739075,"f":1},"n":"ErrorDialogParentHandle","d":654787,"h":111669804483,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849673667,"f":1},"s":{"r":0,"d":0,"h":133144640963,"f":1},"n":"FileName","d":654787,"h":124554706371,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734575555,"f":1},"s":{"r":0,"d":0,"h":146029542851,"f":1},"n":"LoadUserProfile","d":654787,"h":137439608259,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619477443,"f":1},"s":{"r":0,"d":0,"h":158914444739,"f":1},"n":"UseCredentialsForNetworkingOnly","d":654787,"h":150324510147,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":117309441,"g":{"r":0,"d":0,"h":167504379331,"f":1},"s":{"r":0,"d":0,"h":171799346627,"f":1},"n":"Password","d":654787,"h":163209412035,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389281219,"f":1},"s":{"r":0,"d":0,"h":184684248515,"f":1},"n":"PasswordInClearText","d":654787,"h":176094313923,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274183107,"f":1},"s":{"r":0,"d":0,"h":197569150403,"f":1},"n":"RedirectStandardError","d":654787,"h":188979215811,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":206159084995,"f":1},"s":{"r":0,"d":0,"h":210454052291,"f":1},"n":"RedirectStandardInput","d":654787,"h":201864117699,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":219043986883,"f":1},"s":{"r":0,"d":0,"h":223338954179,"f":1},"n":"RedirectStandardOutput","d":654787,"h":214749019587,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":231928888771,"f":1},"s":{"r":0,"d":0,"h":236223856067,"f":1},"n":"StandardErrorEncoding","d":654787,"h":227633921475,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":244813790659,"f":1},"s":{"r":0,"d":0,"h":249108757955,"f":1},"n":"StandardInputEncoding","d":654787,"h":240518823363,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":257698692547,"f":1},"s":{"r":0,"d":0,"h":261993659843,"f":1},"n":"StandardOutputEncoding","d":654787,"h":253403725251,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":270583594435,"f":1},"s":{"r":0,"d":0,"h":274878561731,"f":1},"n":"UserName","d":654787,"h":266288627139,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":283468496323,"f":1},"s":{"r":0,"d":0,"h":287763463619,"f":1},"n":"UseShellExecute","d":654787,"h":279173529027,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":296353398211,"f":1},"s":{"r":0,"d":0,"h":300648365507,"f":1},"n":"Verb","d":654787,"h":292058430915,"f":1,"a":[{"t":33095681,"c":60162637825,"a":[{"v":"","t":1310721}]}]},{"p":0,"g":{"r":0,"d":0,"h":309238300099,"f":1},"n":"Verbs","d":654787,"h":304943332803,"f":1},{"p":851395,"g":{"r":0,"d":0,"h":317828234691,"f":1},"s":{"r":0,"d":0,"h":322123201987,"f":1},"n":"WindowStyle","d":654787,"h":313533267395,"f":1,"a":[{"t":33095681,"c":64457605121,"a":[{"v":0,"t":851395}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713136579,"f":1},"s":{"r":0,"d":0,"h":335008103875,"f":1},"n":"WorkingDirectory","d":654787,"h":326418169283,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":654787,"h":4295622083,"f":1},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":654787,"h":8590589379,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":654787,"h":12885556675,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":654787,"h":17180523971,"f":1}],"h":654787}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 523715;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":458179,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180392899,"f":1},"n":"Item","o":"@$2","d":523715,"h":12885425603,"f":1}],"m":[{"r":262145,"p":[{"n":"module","p":458179}],"n":"Contains","d":523715,"h":21475360195,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":523715,"h":25770327491,"f":1},{"r":655361,"p":[{"n":"module","p":458179}],"n":"IndexOf","d":523715,"h":30065294787,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":523715,"h":4295491011,"f":4},{"p":[{"n":"processModules","p":0}],"n":".ctor","o":"$ctor$3","d":523715,"h":8590458307,"f":1}],"i":[31326209,31588353],"h":523715}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 785859;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":720323,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180655043,"f":1},"n":"Item","o":"@$2","d":785859,"h":12885687747,"f":1}],"m":[{"r":655361,"p":[{"n":"thread","p":720323}],"n":"Add","d":785859,"h":21475622339,"f":1},{"r":262145,"p":[{"n":"thread","p":720323}],"n":"Contains","d":785859,"h":25770589635,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":785859,"h":30065556931,"f":1},{"r":655361,"p":[{"n":"thread","p":720323}],"n":"IndexOf","d":785859,"h":34360524227,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":720323}],"n":"Insert","d":785859,"h":38655491523,"f":1},{"r":65537,"p":[{"n":"thread","p":720323}],"n":"Remove","d":785859,"h":42950458819,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":785859,"h":4295753155,"f":4},{"p":[{"n":"processThreads","p":0}],"n":".ctor","o":"$ctor$3","d":785859,"h":8590720451,"f":1}],"i":[31326209,31588353],"h":785859}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$spc.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 589251;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":589251,"n":"Normal","d":589251,"h":4295556547,"f":33},{"t":589251,"n":"Idle","d":589251,"h":8590523843,"f":33},{"t":589251,"n":"High","d":589251,"h":12885491139,"f":33},{"t":589251,"n":"RealTime","d":589251,"h":17180458435,"f":33},{"t":589251,"n":"BelowNormal","d":589251,"h":21475425731,"f":33},{"t":589251,"n":"AboveNormal","d":589251,"h":25770393027,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":589251,"h":30065360323,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":589251}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 851395;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":851395,"n":"Normal","d":851395,"h":4295818691,"f":33},{"t":851395,"n":"Hidden","d":851395,"h":8590785987,"f":33},{"t":851395,"n":"Minimized","d":851395,"h":12885753283,"f":33},{"t":851395,"n":"Maximized","d":851395,"h":17180720579,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":851395,"h":21475687875,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":851395}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$spc.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 916931;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":916931,"n":"Idle","d":916931,"h":4295884227,"f":33},{"t":916931,"n":"Lowest","d":916931,"h":8590851523,"f":33},{"t":916931,"n":"BelowNormal","d":916931,"h":12885818819,"f":33},{"t":916931,"n":"Normal","d":916931,"h":17180786115,"f":33},{"t":916931,"n":"AboveNormal","d":916931,"h":21475753411,"f":33},{"t":916931,"n":"Highest","d":916931,"h":25770720707,"f":33},{"t":916931,"n":"TimeCritical","d":916931,"h":30065688003,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":916931,"h":34360655299,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":916931}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$spc.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 982467;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":982467,"n":"Initialized","d":982467,"h":4295949763,"f":33},{"t":982467,"n":"Ready","d":982467,"h":8590917059,"f":33},{"t":982467,"n":"Running","d":982467,"h":12885884355,"f":33},{"t":982467,"n":"Standby","d":982467,"h":17180851651,"f":33},{"t":982467,"n":"Terminated","d":982467,"h":21475818947,"f":33},{"t":982467,"n":"Wait","d":982467,"h":25770786243,"f":33},{"t":982467,"n":"Transition","d":982467,"h":30065753539,"f":33},{"t":982467,"n":"Unknown","d":982467,"h":34360720835,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":982467,"h":38655688131,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":982467}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$spc.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1048003;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1048003,"n":"Executive","d":1048003,"h":4296015299,"f":33},{"t":1048003,"n":"FreePage","d":1048003,"h":8590982595,"f":33},{"t":1048003,"n":"PageIn","d":1048003,"h":12885949891,"f":33},{"t":1048003,"n":"SystemAllocation","d":1048003,"h":17180917187,"f":33},{"t":1048003,"n":"ExecutionDelay","d":1048003,"h":21475884483,"f":33},{"t":1048003,"n":"Suspended","d":1048003,"h":25770851779,"f":33},{"t":1048003,"n":"UserRequest","d":1048003,"h":30065819075,"f":33},{"t":1048003,"n":"EventPairHigh","d":1048003,"h":34360786371,"f":33},{"t":1048003,"n":"EventPairLow","d":1048003,"h":38655753667,"f":33},{"t":1048003,"n":"LpcReceive","d":1048003,"h":42950720963,"f":33},{"t":1048003,"n":"LpcReply","d":1048003,"h":47245688259,"f":33},{"t":1048003,"n":"VirtualMemory","d":1048003,"h":51540655555,"f":33},{"t":1048003,"n":"PageOut","d":1048003,"h":55835622851,"f":33},{"t":1048003,"n":"Unknown","d":1048003,"h":60130590147,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1048003,"h":64425557443,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1048003}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 130499;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":130499,"h":12885032387,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":130499,"h":4295097795,"f":1},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":130499,"h":8590065091,"f":1}],"i":[57475073],"h":130499}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 196035;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885097923,"f":1},"n":"Data","d":196035,"h":8590130627,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":196035,"h":4295163331,"f":8}],"h":196035}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 327107;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885228995,"f":32769},"n":"Description","d":327107,"h":8590261699,"f":32769}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":327107,"h":4295294403,"f":1}],"h":327107,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 261571;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":196035}],"n":"Invoke","d":261571,"h":8590196163,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":196035},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":261571,"h":12885163459,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":261571,"h":17180130755,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":261571,"h":4295228867,"f":1}],"i":[57147393,113377281],"h":261571}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$remove(value)
            {
            }
            /*System.EventHandler*/ Exited$add(value)
            {
            }
            /*System.EventHandler*/ Exited$remove(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$remove(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$1(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$2(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$3(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$5(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 392643;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885294531,"f":1},"n":"BasePriority","d":392643,"h":8590327235,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475229123,"f":1},"s":{"r":0,"d":0,"h":25770196419,"f":1},"n":"EnableRaisingEvents","d":392643,"h":17180261827,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360131011,"f":1},"n":"ExitCode","d":392643,"h":30065163715,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":42950065603,"f":1},"n":"ExitTime","d":392643,"h":38655098307,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":51540000195,"f":1},"n":"Handle","d":392643,"h":47245032899,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":60129934787,"f":1},"n":"HandleCount","d":392643,"h":55834967491,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719869379,"f":1},"n":"HasExited","d":392643,"h":64424902083,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309803971,"f":1},"n":"Id","d":392643,"h":73014836675,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899738563,"f":1},"n":"MachineName","d":392643,"h":81604771267,"f":1},{"p":458179,"g":{"r":0,"d":0,"h":94489673155,"f":1},"n":"MainModule","d":392643,"h":90194705859,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":103079607747,"f":1},"n":"MainWindowHandle","d":392643,"h":98784640451,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669542339,"f":1},"n":"MainWindowTitle","d":392643,"h":107374575043,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":120259476931,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554444227,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":392643,"h":115964509635,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":133144378819,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439346115,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":392643,"h":128849411523,"f":1},{"p":523715,"g":{"r":0,"d":0,"h":146029280707,"f":1},"n":"Modules","d":392643,"h":141734313411,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":154619215299,"f":1},"n":"NonpagedSystemMemorySize","d":392643,"h":150324248003,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209149891,"f":1},"n":"NonpagedSystemMemorySize64","d":392643,"h":158914182595,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799084483,"f":1},"n":"PagedMemorySize","d":392643,"h":167504117187,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180389019075,"f":1},"n":"PagedMemorySize64","d":392643,"h":176094051779,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":188978953667,"f":1},"n":"PagedSystemMemorySize","d":392643,"h":184683986371,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568888259,"f":1},"n":"PagedSystemMemorySize64","d":392643,"h":193273920963,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":206158822851,"f":1},"n":"PeakPagedMemorySize","d":392643,"h":201863855555,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748757443,"f":1},"n":"PeakPagedMemorySize64","d":392643,"h":210453790147,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":223338692035,"f":1},"n":"PeakVirtualMemorySize","d":392643,"h":219043724739,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928626627,"f":1},"n":"PeakVirtualMemorySize64","d":392643,"h":227633659331,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":240518561219,"f":1},"n":"PeakWorkingSet","d":392643,"h":236223593923,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108495811,"f":1},"n":"PeakWorkingSet64","d":392643,"h":244813528515,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":257698430403,"f":1},"s":{"r":0,"d":0,"h":261993397699,"f":1},"n":"PriorityBoostEnabled","d":392643,"h":253403463107,"f":1},{"p":589251,"g":{"r":0,"d":0,"h":270583332291,"f":1},"s":{"r":0,"d":0,"h":274878299587,"f":1},"n":"PriorityClass","d":392643,"h":266288364995,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":283468234179,"f":1},"n":"PrivateMemorySize","d":392643,"h":279173266883,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058168771,"f":1},"n":"PrivateMemorySize64","d":392643,"h":287763201475,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":300648103363,"f":1},"n":"PrivilegedProcessorTime","d":392643,"h":296353136067,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238037955,"f":1},"n":"ProcessName","d":392643,"h":304943070659,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":317827972547,"f":1},"s":{"r":0,"d":0,"h":322122939843,"f":1},"n":"ProcessorAffinity","d":392643,"h":313533005251,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712874435,"f":1},"n":"Responding","d":392643,"h":326417907139,"f":1},{"p":130499,"g":{"r":0,"d":0,"h":339302809027,"f":1},"n":"SafeHandle","d":392643,"h":335007841731,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":347892743619,"f":1},"n":"SessionId","d":392643,"h":343597776323,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":356482678211,"f":1},"n":"StandardError","d":392643,"h":352187710915,"f":1},{"p":62586881,"g":{"r":0,"d":0,"h":365072612803,"f":1},"n":"StandardInput","d":392643,"h":360777645507,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":373662547395,"f":1},"n":"StandardOutput","d":392643,"h":369367580099,"f":1},{"p":654787,"g":{"r":0,"d":0,"h":382252481987,"f":1},"s":{"r":0,"d":0,"h":386547449283,"f":1},"n":"StartInfo","d":392643,"h":377957514691,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":395137383875,"f":1},"n":"StartTime","d":392643,"h":390842416579,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727318467,"f":1},"s":{"r":0,"d":0,"h":408022285763,"f":1},"n":"SynchronizingObject","d":392643,"h":399432351171,"f":1},{"p":785859,"g":{"r":0,"d":0,"h":416612220355,"f":1},"n":"Threads","d":392643,"h":412317253059,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":425202154947,"f":1},"n":"TotalProcessorTime","d":392643,"h":420907187651,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":433792089539,"f":1},"n":"UserProcessorTime","d":392643,"h":429497122243,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442382024131,"f":1},"n":"VirtualMemorySize","d":392643,"h":438087056835,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971958723,"f":1},"n":"VirtualMemorySize64","d":392643,"h":446676991427,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":459561893315,"f":1},"n":"WorkingSet","d":392643,"h":455266926019,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151827907,"f":1},"n":"WorkingSet64","d":392643,"h":463856860611,"f":1}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":392643,"h":511101500867,"f":1},{"r":65537,"n":"BeginOutputReadLine","d":392643,"h":515396468163,"f":1},{"r":65537,"n":"CancelErrorRead","d":392643,"h":519691435459,"f":1},{"r":65537,"n":"CancelOutputRead","d":392643,"h":523986402755,"f":1},{"r":65537,"n":"Close","d":392643,"h":528281370051,"f":1},{"r":262145,"n":"CloseMainWindow","d":392643,"h":532576337347,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":392643,"h":536871304643,"f":32772},{"r":65537,"n":"EnterDebugMode","d":392643,"h":541166271939,"f":33},{"r":392643,"n":"GetCurrentProcess","d":392643,"h":545461239235,"f":33},{"r":392643,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","d":392643,"h":549756206531,"f":33},{"r":392643,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","o":"@$1","d":392643,"h":554051173827,"f":33},{"r":0,"n":"GetProcesses","d":392643,"h":558346141123,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":392643,"h":562641108419,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","d":392643,"h":566936075715,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":392643,"h":571231043011,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":392643,"h":575526010307,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":392643,"h":579820977603,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":392643,"h":584115944899,"f":33},{"r":65537,"n":"OnExited","d":392643,"h":588410912195,"f":4},{"r":65537,"n":"Refresh","d":392643,"h":592705879491,"f":1},{"r":262145,"n":"Start","d":392643,"h":597000846787,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":392643,"p":[{"n":"startInfo","p":654787}],"n":"Start","o":"@$1","d":392643,"h":601295814083,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":392643,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$2","d":392643,"h":605590781379,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":392643,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$3","d":392643,"h":609885748675,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":392643,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Start","o":"@$4","d":392643,"h":614180715971,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":392643,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$5","d":392643,"h":618475683267,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":392643,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$6","d":392643,"h":622770650563,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":392643,"h":627065617859,"f":32769},{"r":65537,"n":"WaitForExit","d":392643,"h":631360585155,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":392643,"h":635655552451,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForExit","o":"@$2","d":392643,"h":639950519747,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitForExitAsync","d":392643,"h":644245487043,"f":1},{"r":262145,"n":"WaitForInputIdle","d":392643,"h":648540454339,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":392643,"h":652835421635,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForInputIdle","o":"@$2","d":392643,"h":657130388931,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":392643,"h":4295359939,"f":1}],"e":[{"e":261571,"m":{"r":65537,"p":[{"n":"value","p":261571}],"n":"add_ErrorDataReceived","d":392643,"h":476741762499,"f":1},"r":{"r":65537,"p":[{"n":"value","p":261571}],"n":"remove_ErrorDataReceived","d":392643,"h":481036729795,"f":1},"n":"ErrorDataReceived","d":392643,"h":472446795203,"f":1},{"e":46989313,"m":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"add_Exited","d":392643,"h":489626664387,"f":1},"r":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"remove_Exited","d":392643,"h":493921631683,"f":1},"n":"Exited","d":392643,"h":485331697091,"f":1},{"e":261571,"m":{"r":65537,"p":[{"n":"value","p":261571}],"n":"add_OutputDataReceived","d":392643,"h":502511566275,"f":1},"r":{"r":65537,"p":[{"n":"value","p":261571}],"n":"remove_OutputDataReceived","d":392643,"h":506806533571,"f":1},"n":"OutputDataReceived","d":392643,"h":498216598979,"f":1}],"i":[1048615,57475073],"h":392643,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 458179;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885360067,"f":1},"n":"BaseAddress","d":458179,"h":8590392771,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":21475294659,"f":1},"n":"EntryPointAddress","d":458179,"h":17180327363,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065229251,"f":1},"n":"FileName","d":458179,"h":25770261955,"f":1},{"p":123944,"g":{"r":0,"d":0,"h":38655163843,"f":1},"n":"FileVersionInfo","d":458179,"h":34360196547,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245098435,"f":1},"n":"ModuleMemorySize","d":458179,"h":42950131139,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835033027,"f":1},"n":"ModuleName","d":458179,"h":51540065731,"f":1}],"m":[{"r":1310721,"n":"ToString","d":458179,"h":60130000323,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":458179,"h":4295425475,"f":8}],"i":[1048615,57475073],"h":458179,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 720323;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885622211,"f":1},"n":"BasePriority","d":720323,"h":8590654915,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":21475556803,"f":1},"n":"CurrentPriority","d":720323,"h":17180589507,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065491395,"f":1},"n":"Id","d":720323,"h":25770524099,"f":1},{"p":655361,"s":{"r":0,"d":0,"h":38655425987,"f":1},"n":"IdealProcessor","d":720323,"h":34360458691,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245360579,"f":1},"s":{"r":0,"d":0,"h":51540327875,"f":1},"n":"PriorityBoostEnabled","d":720323,"h":42950393283,"f":1},{"p":916931,"g":{"r":0,"d":0,"h":60130262467,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425229763,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":720323,"h":55835295171,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015164355,"f":1},"n":"PrivilegedProcessorTime","d":720323,"h":68720197059,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605098947,"f":1},"n":"ProcessorAffinity","d":720323,"h":77310131651,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195033539,"f":1},"n":"StartAddress","d":720323,"h":85900066243,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":98784968131,"f":1},"n":"StartTime","d":720323,"h":94490000835,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":982467,"g":{"r":0,"d":0,"h":107374902723,"f":1},"n":"ThreadState","d":720323,"h":103079935427,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":115964837315,"f":1},"n":"TotalProcessorTime","d":720323,"h":111669870019,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":124554771907,"f":1},"n":"UserProcessorTime","d":720323,"h":120259804611,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1048003,"g":{"r":0,"d":0,"h":133144706499,"f":1},"n":"WaitReason","d":720323,"h":128849739203,"f":1}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":720323,"h":137439673795,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":720323,"h":4295687619,"f":8}],"i":[1048615,57475073],"h":720323,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Specialized", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.IO.Pipes"))