
(function ($global, $, $spc, $mwp, $sc, $sm, $spu, $sr, $sdt, $st, $scc, $sris, $scn, $stt, $ssc, $sspw, $ssa, $mwr, $scm, $so, $scp, $scs, $sdf, $sifd, $sto, $sip, $stee, $sttp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":53290,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 643114;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25770446890,"f":1},"n":"ArgumentList","d":643114,"h":21475479594,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360381482,"f":1},"s":{"r":0,"d":0,"h":38655348778,"f":1},"n":"Arguments","d":643114,"h":30065414186,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245283370,"f":1},"s":{"r":0,"d":0,"h":51540250666,"f":1},"n":"CreateNewProcessGroup","d":643114,"h":42950316074,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130185258,"f":1},"s":{"r":0,"d":0,"h":64425152554,"f":1},"n":"CreateNoWindow","d":643114,"h":55835217962,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015087146,"f":1},"s":{"r":0,"d":0,"h":77310054442,"f":1},"n":"Domain","d":643114,"h":68720119850,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":85899989034,"f":1},"n":"Environment","d":643114,"h":81605021738,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94489923626,"f":1},"n":"EnvironmentVariables","d":643114,"h":90194956330,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079858218,"f":1},"s":{"r":0,"d":0,"h":107374825514,"f":1},"n":"ErrorDialog","d":643114,"h":98784890922,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115964760106,"f":1},"s":{"r":0,"d":0,"h":120259727402,"f":1},"n":"ErrorDialogParentHandle","d":643114,"h":111669792810,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849661994,"f":1},"s":{"r":0,"d":0,"h":133144629290,"f":1},"n":"FileName","d":643114,"h":124554694698,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734563882,"f":1},"s":{"r":0,"d":0,"h":146029531178,"f":1},"n":"LoadUserProfile","d":643114,"h":137439596586,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619465770,"f":1},"s":{"r":0,"d":0,"h":158914433066,"f":1},"n":"UseCredentialsForNetworkingOnly","d":643114,"h":150324498474,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":117309441,"g":{"r":0,"d":0,"h":167504367658,"f":1},"s":{"r":0,"d":0,"h":171799334954,"f":1},"n":"Password","d":643114,"h":163209400362,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389269546,"f":1},"s":{"r":0,"d":0,"h":184684236842,"f":1},"n":"PasswordInClearText","d":643114,"h":176094302250,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274171434,"f":1},"s":{"r":0,"d":0,"h":197569138730,"f":1},"n":"RedirectStandardError","d":643114,"h":188979204138,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":206159073322,"f":1},"s":{"r":0,"d":0,"h":210454040618,"f":1},"n":"RedirectStandardInput","d":643114,"h":201864106026,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":219043975210,"f":1},"s":{"r":0,"d":0,"h":223338942506,"f":1},"n":"RedirectStandardOutput","d":643114,"h":214749007914,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":231928877098,"f":1},"s":{"r":0,"d":0,"h":236223844394,"f":1},"n":"StandardErrorEncoding","d":643114,"h":227633909802,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":244813778986,"f":1},"s":{"r":0,"d":0,"h":249108746282,"f":1},"n":"StandardInputEncoding","d":643114,"h":240518811690,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":257698680874,"f":1},"s":{"r":0,"d":0,"h":261993648170,"f":1},"n":"StandardOutputEncoding","d":643114,"h":253403713578,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":270583582762,"f":1},"s":{"r":0,"d":0,"h":274878550058,"f":1},"n":"UserName","d":643114,"h":266288615466,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":283468484650,"f":1},"s":{"r":0,"d":0,"h":287763451946,"f":1},"n":"UseShellExecute","d":643114,"h":279173517354,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":296353386538,"f":1},"s":{"r":0,"d":0,"h":300648353834,"f":1},"n":"Verb","d":643114,"h":292058419242,"f":1,"a":[{"t":33161217,"c":60162703361,"a":[{"v":"","t":1310721}]}]},{"p":0,"g":{"r":0,"d":0,"h":309238288426,"f":1},"n":"Verbs","d":643114,"h":304943321130,"f":1},{"p":839722,"g":{"r":0,"d":0,"h":317828223018,"f":1},"s":{"r":0,"d":0,"h":322123190314,"f":1},"n":"WindowStyle","d":643114,"h":313533255722,"f":1,"a":[{"t":33161217,"c":64457670657,"a":[{"v":0,"t":839722}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713124906,"f":1},"s":{"r":0,"d":0,"h":335008092202,"f":1},"n":"WorkingDirectory","d":643114,"h":326418157610,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":643114,"h":4295610410,"f":1},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":643114,"h":8590577706,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":643114,"h":12885545002,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":643114,"h":17180512298,"f":1}],"h":643114}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 512042;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":446506,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180381226,"f":1},"n":"Item","o":"@$2","d":512042,"h":12885413930,"f":1}],"m":[{"r":262145,"p":[{"n":"module","p":446506}],"n":"Contains","d":512042,"h":21475348522,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":512042,"h":25770315818,"f":1},{"r":655361,"p":[{"n":"module","p":446506}],"n":"IndexOf","d":512042,"h":30065283114,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":512042,"h":4295479338,"f":4},{"p":[{"n":"processModules","p":0}],"n":".ctor","o":"$ctor$3","d":512042,"h":8590446634,"f":1}],"i":[31391745,31653889],"h":512042}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 774186;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":708650,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180643370,"f":1},"n":"Item","o":"@$2","d":774186,"h":12885676074,"f":1}],"m":[{"r":655361,"p":[{"n":"thread","p":708650}],"n":"Add","d":774186,"h":21475610666,"f":1},{"r":262145,"p":[{"n":"thread","p":708650}],"n":"Contains","d":774186,"h":25770577962,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":774186,"h":30065545258,"f":1},{"r":655361,"p":[{"n":"thread","p":708650}],"n":"IndexOf","d":774186,"h":34360512554,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":708650}],"n":"Insert","d":774186,"h":38655479850,"f":1},{"r":65537,"p":[{"n":"thread","p":708650}],"n":"Remove","d":774186,"h":42950447146,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":774186,"h":4295741482,"f":4},{"p":[{"n":"processThreads","p":0}],"n":".ctor","o":"$ctor$3","d":774186,"h":8590708778,"f":1}],"i":[31391745,31653889],"h":774186}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 249898;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":184362}],"n":"Invoke","d":249898,"h":8590184490,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":184362},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":249898,"h":12885151786,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":249898,"h":17180119082,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":249898,"h":4295217194,"f":1}],"i":[57212929,113377281],"h":249898}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$spc.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 577578;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":577578,"n":"Normal","d":577578,"h":4295544874,"f":33},{"t":577578,"n":"Idle","d":577578,"h":8590512170,"f":33},{"t":577578,"n":"High","d":577578,"h":12885479466,"f":33},{"t":577578,"n":"RealTime","d":577578,"h":17180446762,"f":33},{"t":577578,"n":"BelowNormal","d":577578,"h":21475414058,"f":33},{"t":577578,"n":"AboveNormal","d":577578,"h":25770381354,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":577578,"h":30065348650,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":577578}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 839722;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":839722,"n":"Normal","d":839722,"h":4295807018,"f":33},{"t":839722,"n":"Hidden","d":839722,"h":8590774314,"f":33},{"t":839722,"n":"Minimized","d":839722,"h":12885741610,"f":33},{"t":839722,"n":"Maximized","d":839722,"h":17180708906,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":839722,"h":21475676202,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":839722}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$spc.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 905258;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":905258,"n":"Idle","d":905258,"h":4295872554,"f":33},{"t":905258,"n":"Lowest","d":905258,"h":8590839850,"f":33},{"t":905258,"n":"BelowNormal","d":905258,"h":12885807146,"f":33},{"t":905258,"n":"Normal","d":905258,"h":17180774442,"f":33},{"t":905258,"n":"AboveNormal","d":905258,"h":21475741738,"f":33},{"t":905258,"n":"Highest","d":905258,"h":25770709034,"f":33},{"t":905258,"n":"TimeCritical","d":905258,"h":30065676330,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":905258,"h":34360643626,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":905258}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$spc.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 970794;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":970794,"n":"Initialized","d":970794,"h":4295938090,"f":33},{"t":970794,"n":"Ready","d":970794,"h":8590905386,"f":33},{"t":970794,"n":"Running","d":970794,"h":12885872682,"f":33},{"t":970794,"n":"Standby","d":970794,"h":17180839978,"f":33},{"t":970794,"n":"Terminated","d":970794,"h":21475807274,"f":33},{"t":970794,"n":"Wait","d":970794,"h":25770774570,"f":33},{"t":970794,"n":"Transition","d":970794,"h":30065741866,"f":33},{"t":970794,"n":"Unknown","d":970794,"h":34360709162,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":970794,"h":38655676458,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":970794}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$spc.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1036330;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1036330,"n":"Executive","d":1036330,"h":4296003626,"f":33},{"t":1036330,"n":"FreePage","d":1036330,"h":8590970922,"f":33},{"t":1036330,"n":"PageIn","d":1036330,"h":12885938218,"f":33},{"t":1036330,"n":"SystemAllocation","d":1036330,"h":17180905514,"f":33},{"t":1036330,"n":"ExecutionDelay","d":1036330,"h":21475872810,"f":33},{"t":1036330,"n":"Suspended","d":1036330,"h":25770840106,"f":33},{"t":1036330,"n":"UserRequest","d":1036330,"h":30065807402,"f":33},{"t":1036330,"n":"EventPairHigh","d":1036330,"h":34360774698,"f":33},{"t":1036330,"n":"EventPairLow","d":1036330,"h":38655741994,"f":33},{"t":1036330,"n":"LpcReceive","d":1036330,"h":42950709290,"f":33},{"t":1036330,"n":"LpcReply","d":1036330,"h":47245676586,"f":33},{"t":1036330,"n":"VirtualMemory","d":1036330,"h":51540643882,"f":33},{"t":1036330,"n":"PageOut","d":1036330,"h":55835611178,"f":33},{"t":1036330,"n":"Unknown","d":1036330,"h":60130578474,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1036330,"h":64425545770,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1036330}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118826;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":118826,"h":12885020714,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":118826,"h":4295086122,"f":1},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":118826,"h":8590053418,"f":1}],"i":[57540609],"h":118826}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 184362;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885086250,"f":1},"n":"Data","d":184362,"h":8590118954,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":184362,"h":4295151658,"f":8}],"h":184362}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 315434;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885217322,"f":32769},"n":"Description","d":315434,"h":8590250026,"f":32769}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":315434,"h":4295282730,"f":1}],"h":315434,"a":[{"t":14680065,"c":21489516545,"a":[{"v":32767,"t":14614529}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_ErrorDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_ErrorDataReceived(value)
            {
            }
            /*System.EventHandler*/ add_Exited(value)
            {
            }
            /*System.EventHandler*/ remove_Exited(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ add_OutputDataReceived(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ remove_OutputDataReceived(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$1(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$2(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$3(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$5(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 380970;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885282858,"f":1},"n":"BasePriority","d":380970,"h":8590315562,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475217450,"f":1},"s":{"r":0,"d":0,"h":25770184746,"f":1},"n":"EnableRaisingEvents","d":380970,"h":17180250154,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360119338,"f":1},"n":"ExitCode","d":380970,"h":30065152042,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":42950053930,"f":1},"n":"ExitTime","d":380970,"h":38655086634,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":51539988522,"f":1},"n":"Handle","d":380970,"h":47245021226,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":60129923114,"f":1},"n":"HandleCount","d":380970,"h":55834955818,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719857706,"f":1},"n":"HasExited","d":380970,"h":64424890410,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309792298,"f":1},"n":"Id","d":380970,"h":73014825002,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899726890,"f":1},"n":"MachineName","d":380970,"h":81604759594,"f":1},{"p":446506,"g":{"r":0,"d":0,"h":94489661482,"f":1},"n":"MainModule","d":380970,"h":90194694186,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":103079596074,"f":1},"n":"MainWindowHandle","d":380970,"h":98784628778,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669530666,"f":1},"n":"MainWindowTitle","d":380970,"h":107374563370,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":120259465258,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554432554,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":380970,"h":115964497962,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":133144367146,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439334442,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":380970,"h":128849399850,"f":1},{"p":512042,"g":{"r":0,"d":0,"h":146029269034,"f":1},"n":"Modules","d":380970,"h":141734301738,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":154619203626,"f":1},"n":"NonpagedSystemMemorySize","d":380970,"h":150324236330,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209138218,"f":1},"n":"NonpagedSystemMemorySize64","d":380970,"h":158914170922,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799072810,"f":1},"n":"PagedMemorySize","d":380970,"h":167504105514,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180389007402,"f":1},"n":"PagedMemorySize64","d":380970,"h":176094040106,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":188978941994,"f":1},"n":"PagedSystemMemorySize","d":380970,"h":184683974698,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568876586,"f":1},"n":"PagedSystemMemorySize64","d":380970,"h":193273909290,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":206158811178,"f":1},"n":"PeakPagedMemorySize","d":380970,"h":201863843882,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748745770,"f":1},"n":"PeakPagedMemorySize64","d":380970,"h":210453778474,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":223338680362,"f":1},"n":"PeakVirtualMemorySize","d":380970,"h":219043713066,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928614954,"f":1},"n":"PeakVirtualMemorySize64","d":380970,"h":227633647658,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":240518549546,"f":1},"n":"PeakWorkingSet","d":380970,"h":236223582250,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108484138,"f":1},"n":"PeakWorkingSet64","d":380970,"h":244813516842,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":257698418730,"f":1},"s":{"r":0,"d":0,"h":261993386026,"f":1},"n":"PriorityBoostEnabled","d":380970,"h":253403451434,"f":1},{"p":577578,"g":{"r":0,"d":0,"h":270583320618,"f":1},"s":{"r":0,"d":0,"h":274878287914,"f":1},"n":"PriorityClass","d":380970,"h":266288353322,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":283468222506,"f":1},"n":"PrivateMemorySize","d":380970,"h":279173255210,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058157098,"f":1},"n":"PrivateMemorySize64","d":380970,"h":287763189802,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":300648091690,"f":1},"n":"PrivilegedProcessorTime","d":380970,"h":296353124394,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238026282,"f":1},"n":"ProcessName","d":380970,"h":304943058986,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":317827960874,"f":1},"s":{"r":0,"d":0,"h":322122928170,"f":1},"n":"ProcessorAffinity","d":380970,"h":313532993578,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712862762,"f":1},"n":"Responding","d":380970,"h":326417895466,"f":1},{"p":118826,"g":{"r":0,"d":0,"h":339302797354,"f":1},"n":"SafeHandle","d":380970,"h":335007830058,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":347892731946,"f":1},"n":"SessionId","d":380970,"h":343597764650,"f":1},{"p":62521345,"g":{"r":0,"d":0,"h":356482666538,"f":1},"n":"StandardError","d":380970,"h":352187699242,"f":1},{"p":62652417,"g":{"r":0,"d":0,"h":365072601130,"f":1},"n":"StandardInput","d":380970,"h":360777633834,"f":1},{"p":62521345,"g":{"r":0,"d":0,"h":373662535722,"f":1},"n":"StandardOutput","d":380970,"h":369367568426,"f":1},{"p":643114,"g":{"r":0,"d":0,"h":382252470314,"f":1},"s":{"r":0,"d":0,"h":386547437610,"f":1},"n":"StartInfo","d":380970,"h":377957503018,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":395137372202,"f":1},"n":"StartTime","d":380970,"h":390842404906,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727306794,"f":1},"s":{"r":0,"d":0,"h":408022274090,"f":1},"n":"SynchronizingObject","d":380970,"h":399432339498,"f":1},{"p":774186,"g":{"r":0,"d":0,"h":416612208682,"f":1},"n":"Threads","d":380970,"h":412317241386,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":425202143274,"f":1},"n":"TotalProcessorTime","d":380970,"h":420907175978,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":433792077866,"f":1},"n":"UserProcessorTime","d":380970,"h":429497110570,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442382012458,"f":1},"n":"VirtualMemorySize","d":380970,"h":438087045162,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971947050,"f":1},"n":"VirtualMemorySize64","d":380970,"h":446676979754,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":459561881642,"f":1},"n":"WorkingSet","d":380970,"h":455266914346,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151816234,"f":1},"n":"WorkingSet64","d":380970,"h":463856848938,"f":1}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":380970,"h":511101489194,"f":1},{"r":65537,"n":"BeginOutputReadLine","d":380970,"h":515396456490,"f":1},{"r":65537,"n":"CancelErrorRead","d":380970,"h":519691423786,"f":1},{"r":65537,"n":"CancelOutputRead","d":380970,"h":523986391082,"f":1},{"r":65537,"n":"Close","d":380970,"h":528281358378,"f":1},{"r":262145,"n":"CloseMainWindow","d":380970,"h":532576325674,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":380970,"h":536871292970,"f":32772},{"r":65537,"n":"EnterDebugMode","d":380970,"h":541166260266,"f":33},{"r":380970,"n":"GetCurrentProcess","d":380970,"h":545461227562,"f":33},{"r":380970,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","d":380970,"h":549756194858,"f":33},{"r":380970,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","o":"@$1","d":380970,"h":554051162154,"f":33},{"r":0,"n":"GetProcesses","d":380970,"h":558346129450,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":380970,"h":562641096746,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","d":380970,"h":566936064042,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":380970,"h":571231031338,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":380970,"h":575525998634,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":380970,"h":579820965930,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":380970,"h":584115933226,"f":33},{"r":65537,"n":"OnExited","d":380970,"h":588410900522,"f":4},{"r":65537,"n":"Refresh","d":380970,"h":592705867818,"f":1},{"r":262145,"n":"Start","d":380970,"h":597000835114,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380970,"p":[{"n":"startInfo","p":643114}],"n":"Start","o":"@$1","d":380970,"h":601295802410,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380970,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$2","d":380970,"h":605590769706,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380970,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$3","d":380970,"h":609885737002,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380970,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Start","o":"@$4","d":380970,"h":614180704298,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":380970,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$5","d":380970,"h":618475671594,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":380970,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$6","d":380970,"h":622770638890,"f":33,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":380970,"h":627065606186,"f":32769},{"r":65537,"n":"WaitForExit","d":380970,"h":631360573482,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":380970,"h":635655540778,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForExit","o":"@$2","d":380970,"h":639950508074,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitForExitAsync","d":380970,"h":644245475370,"f":1},{"r":262145,"n":"WaitForInputIdle","d":380970,"h":648540442666,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":380970,"h":652835409962,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForInputIdle","o":"@$2","d":380970,"h":657130377258,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":380970,"h":4295348266,"f":1}],"e":[{"e":249898,"m":{"r":65537,"p":[{"n":"value","p":249898}],"n":"add_ErrorDataReceived","d":380970,"h":476741750826,"f":1},"r":{"r":65537,"p":[{"n":"value","p":249898}],"n":"remove_ErrorDataReceived","d":380970,"h":481036718122,"f":1},"n":"ErrorDataReceived","d":380970,"h":472446783530,"f":1},{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Exited","d":380970,"h":489626652714,"f":1},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Exited","d":380970,"h":493921620010,"f":1},"n":"Exited","d":380970,"h":485331685418,"f":1},{"e":249898,"m":{"r":65537,"p":[{"n":"value","p":249898}],"n":"add_OutputDataReceived","d":380970,"h":502511554602,"f":1},"r":{"r":65537,"p":[{"n":"value","p":249898}],"n":"remove_OutputDataReceived","d":380970,"h":506806521898,"f":1},"n":"OutputDataReceived","d":380970,"h":498216587306,"f":1}],"i":[1048615,57540609],"h":380970,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 446506;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885348394,"f":1},"n":"BaseAddress","d":446506,"h":8590381098,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":21475282986,"f":1},"n":"EntryPointAddress","d":446506,"h":17180315690,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065217578,"f":1},"n":"FileName","d":446506,"h":25770250282,"f":1},{"p":116668,"g":{"r":0,"d":0,"h":38655152170,"f":1},"n":"FileVersionInfo","d":446506,"h":34360184874,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245086762,"f":1},"n":"ModuleMemorySize","d":446506,"h":42950119466,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835021354,"f":1},"n":"ModuleName","d":446506,"h":51540054058,"f":1}],"m":[{"r":1310721,"n":"ToString","d":446506,"h":60129988650,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":446506,"h":4295413802,"f":8}],"i":[1048615,57540609],"h":446506,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 708650;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885610538,"f":1},"n":"BasePriority","d":708650,"h":8590643242,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":21475545130,"f":1},"n":"CurrentPriority","d":708650,"h":17180577834,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065479722,"f":1},"n":"Id","d":708650,"h":25770512426,"f":1},{"p":655361,"s":{"r":0,"d":0,"h":38655414314,"f":1},"n":"IdealProcessor","d":708650,"h":34360447018,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245348906,"f":1},"s":{"r":0,"d":0,"h":51540316202,"f":1},"n":"PriorityBoostEnabled","d":708650,"h":42950381610,"f":1},{"p":905258,"g":{"r":0,"d":0,"h":60130250794,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425218090,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":708650,"h":55835283498,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015152682,"f":1},"n":"PrivilegedProcessorTime","d":708650,"h":68720185386,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605087274,"f":1},"n":"ProcessorAffinity","d":708650,"h":77310119978,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195021866,"f":1},"n":"StartAddress","d":708650,"h":85900054570,"f":1},{"p":34209793,"g":{"r":0,"d":0,"h":98784956458,"f":1},"n":"StartTime","d":708650,"h":94489989162,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":970794,"g":{"r":0,"d":0,"h":107374891050,"f":1},"n":"ThreadState","d":708650,"h":103079923754,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":115964825642,"f":1},"n":"TotalProcessorTime","d":708650,"h":111669858346,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":124554760234,"f":1},"n":"UserProcessorTime","d":708650,"h":120259792938,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1036330,"g":{"r":0,"d":0,"h":133144694826,"f":1},"n":"WaitReason","d":708650,"h":128849727530,"f":1}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":708650,"h":137439662122,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":708650,"h":4295675946,"f":8}],"i":[1048615,57540609],"h":708650,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Collections.NonGeneric", "NetJs.System.Threading.Thread", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Threading.Overlapped", "NetJs.System.IO.Pipes", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading.ThreadPool"))