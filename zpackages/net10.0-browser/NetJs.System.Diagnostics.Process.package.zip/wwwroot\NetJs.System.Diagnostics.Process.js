
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $scm, $so, $ssc, $sris, $scp, $sdf, $sifd, $sspw, $scs, $ssa, $mwr, $sip) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Process", 
    {"h":33141,"f":"System.Diagnostics.Process","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Process","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessStartInfo", ($self) => class ProcessStartInfo extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ fileName)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*string*/ fileName, /*string*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.Collection<string> */ get ArgumentList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Arguments()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Arguments(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNewProcessGroup()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNewProcessGroup(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CreateNoWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set CreateNoWindow(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Domain()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Domain(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IDictionary<string, string?> */ get Environment()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Specialized.StringDictionary */ get EnvironmentVariables()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ErrorDialog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ErrorDialog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ErrorDialogParentHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ErrorDialogParentHandle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set FileName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LoadUserProfile()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set LoadUserProfile(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseCredentialsForNetworkingOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseCredentialsForNetworkingOnly(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ get Password()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.SecureString? */ set Password(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get PasswordInClearText()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set PasswordInClearText(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardError(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardInput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RedirectStandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RedirectStandardOutput(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardErrorEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardErrorEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardInputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardInputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ get StandardOutputEncoding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Text.Encoding? */ set StandardOutputEncoding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get UserName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set UserName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseShellExecute()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseShellExecute(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Verb()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Verb(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Verbs()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ get WindowStyle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessWindowStyle */ set WindowStyle(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get WorkingDirectory()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set WorkingDirectory(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 622965;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.Collection$$($.$spc.System.String).$h,"g":{"r":0,"d":0,"h":25770426741,"f":1},"n":"ArgumentList","d":622965,"h":21475459445,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360361333,"f":1},"s":{"r":0,"d":0,"h":38655328629,"f":1},"n":"Arguments","d":622965,"h":30065394037,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245263221,"f":1},"s":{"r":0,"d":0,"h":51540230517,"f":1},"n":"CreateNewProcessGroup","d":622965,"h":42950295925,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":60130165109,"f":1},"s":{"r":0,"d":0,"h":64425132405,"f":1},"n":"CreateNoWindow","d":622965,"h":55835197813,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73015066997,"f":1},"s":{"r":0,"d":0,"h":77310034293,"f":1},"n":"Domain","d":622965,"h":68720099701,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":$.$spc.System.Collections.Generic.IDictionary$$$($.$spc.System.String, $.$spc.System.String).$h,"g":{"r":0,"d":0,"h":85899968885,"f":1},"n":"Environment","d":622965,"h":81605001589,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94489903477,"f":1},"n":"EnvironmentVariables","d":622965,"h":90194936181,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StringDictionaryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":103079838069,"f":1},"s":{"r":0,"d":0,"h":107374805365,"f":1},"n":"ErrorDialog","d":622965,"h":98784870773,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":115964739957,"f":1},"s":{"r":0,"d":0,"h":120259707253,"f":1},"n":"ErrorDialogParentHandle","d":622965,"h":111669772661,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":128849641845,"f":1},"s":{"r":0,"d":0,"h":133144609141,"f":1},"n":"FileName","d":622965,"h":124554674549,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.StartFileNameEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":141734543733,"f":1},"s":{"r":0,"d":0,"h":146029511029,"f":1},"n":"LoadUserProfile","d":622965,"h":137439576437,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619445621,"f":1},"s":{"r":0,"d":0,"h":158914412917,"f":1},"n":"UseCredentialsForNetworkingOnly","d":622965,"h":150324478325,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":117309441,"g":{"r":0,"d":0,"h":167504347509,"f":1},"s":{"r":0,"d":0,"h":171799314805,"f":1},"n":"Password","d":622965,"h":163209380213,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":180389249397,"f":1},"s":{"r":0,"d":0,"h":184684216693,"f":1},"n":"PasswordInClearText","d":622965,"h":176094282101,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":193274151285,"f":1},"s":{"r":0,"d":0,"h":197569118581,"f":1},"n":"RedirectStandardError","d":622965,"h":188979183989,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":206159053173,"f":1},"s":{"r":0,"d":0,"h":210454020469,"f":1},"n":"RedirectStandardInput","d":622965,"h":201864085877,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":219043955061,"f":1},"s":{"r":0,"d":0,"h":223338922357,"f":1},"n":"RedirectStandardOutput","d":622965,"h":214748987765,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":231928856949,"f":1},"s":{"r":0,"d":0,"h":236223824245,"f":1},"n":"StandardErrorEncoding","d":622965,"h":227633889653,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":244813758837,"f":1},"s":{"r":0,"d":0,"h":249108726133,"f":1},"n":"StandardInputEncoding","d":622965,"h":240518791541,"f":1},{"p":121831425,"g":{"r":0,"d":0,"h":257698660725,"f":1},"s":{"r":0,"d":0,"h":261993628021,"f":1},"n":"StandardOutputEncoding","d":622965,"h":253403693429,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":270583562613,"f":1},"s":{"r":0,"d":0,"h":274878529909,"f":1},"n":"UserName","d":622965,"h":266288595317,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":283468464501,"f":1},"s":{"r":0,"d":0,"h":287763431797,"f":1},"n":"UseShellExecute","d":622965,"h":279173497205,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":296353366389,"f":1},"s":{"r":0,"d":0,"h":300648333685,"f":1},"n":"Verb","d":622965,"h":292058399093,"f":1,"a":[{"t":33095681,"c":60162637825,"a":[{"v":"","t":1310721}]}]},{"p":0,"g":{"r":0,"d":0,"h":309238268277,"f":1},"n":"Verbs","d":622965,"h":304943300981,"f":1},{"p":819573,"g":{"r":0,"d":0,"h":317828202869,"f":1},"s":{"r":0,"d":0,"h":322123170165,"f":1},"n":"WindowStyle","d":622965,"h":313533235573,"f":1,"a":[{"t":33095681,"c":64457605121,"a":[{"v":0,"t":819573}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":330713104757,"f":1},"s":{"r":0,"d":0,"h":335008072053,"f":1},"n":"WorkingDirectory","d":622965,"h":326418137461,"f":1,"a":[{"t":852007,"c":12885753895,"a":[{"v":"System.Diagnostics.Design.WorkingDirectoryEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":622965,"h":4295590261,"f":1},{"p":[{"n":"fileName","p":1310721}],"n":".ctor","o":"$ctor$2","d":622965,"h":8590557557,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":".ctor","o":"$ctor$3","d":622965,"h":12885524853,"f":1},{"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":".ctor","o":"$ctor$4","d":622965,"h":17180492149,"f":1}],"h":622965}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.ProcessStartInfo`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModuleCollection", ($self) => class ProcessModuleCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessModule[]*/ processModules)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessModule*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessModule[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessModule*/ module)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 491893;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":426357,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180361077,"f":1},"n":"Item","o":"@$2","d":491893,"h":12885393781,"f":1}],"m":[{"r":262145,"p":[{"n":"module","p":426357}],"n":"Contains","d":491893,"h":21475328373,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":491893,"h":25770295669,"f":1},{"r":655361,"p":[{"n":"module","p":426357}],"n":"IndexOf","d":491893,"h":30065262965,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":491893,"h":4295459189,"f":4},{"p":[{"n":"processModules","p":0}],"n":".ctor","o":"$ctor$3","d":491893,"h":8590426485,"f":1}],"i":[31326209,31588353],"h":491893}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModuleCollection`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThreadCollection", ($self) => class ProcessThreadCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*System.Diagnostics.ProcessThread[]*/ processThreads)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Diagnostics.ProcessThread*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Add(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Contains(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Diagnostics.ProcessThread[]*/ array, /*int*/ index)
            {
            }
            /*int */ IndexOf(/*System.Diagnostics.ProcessThread*/ thread)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Insert(/*int*/ index, /*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            /*void */ Remove(/*System.Diagnostics.ProcessThread*/ thread)
            {
            }
            static $h = 754037;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"p":[{"p":688501,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":17180623221,"f":1},"n":"Item","o":"@$2","d":754037,"h":12885655925,"f":1}],"m":[{"r":655361,"p":[{"n":"thread","p":688501}],"n":"Add","d":754037,"h":21475590517,"f":1},{"r":262145,"p":[{"n":"thread","p":688501}],"n":"Contains","d":754037,"h":25770557813,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":754037,"h":30065525109,"f":1},{"r":655361,"p":[{"n":"thread","p":688501}],"n":"IndexOf","d":754037,"h":34360492405,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"thread","p":688501}],"n":"Insert","d":754037,"h":38655459701,"f":1},{"r":65537,"p":[{"n":"thread","p":688501}],"n":"Remove","d":754037,"h":42950426997,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":754037,"h":4295721333,"f":4},{"p":[{"n":"processThreads","p":0}],"n":".ctor","o":"$ctor$3","d":754037,"h":8590688629,"f":1}],"i":[31326209,31588353],"h":754037}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThreadCollection`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessPriorityClass", ($self) => class ProcessPriorityClass extends $.$spc.System.Enum
        {
            static Normal = 32;
            static Idle = 64;
            static High = 128;
            static RealTime = 256;
            static BelowNormal = 16384;
            static AboveNormal = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 32n,
                    "Idle": 64n,
                    "High": 128n,
                    "RealTime": 256n,
                    "BelowNormal": 16384n,
                    "AboveNormal": 32768n
                };
            }
            static $h = 557429;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":557429,"n":"Normal","d":557429,"h":4295524725,"f":33},{"t":557429,"n":"Idle","d":557429,"h":8590492021,"f":33},{"t":557429,"n":"High","d":557429,"h":12885459317,"f":33},{"t":557429,"n":"RealTime","d":557429,"h":17180426613,"f":33},{"t":557429,"n":"BelowNormal","d":557429,"h":21475393909,"f":33},{"t":557429,"n":"AboveNormal","d":557429,"h":25770361205,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":557429,"h":30065328501,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":557429}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessPriorityClass`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ProcessWindowStyle", ($self) => class ProcessWindowStyle extends $.$spc.System.Enum
        {
            static Normal = 0;
            static Hidden = 1;
            static Minimized = 2;
            static Maximized = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Normal": 0n,
                    "Hidden": 1n,
                    "Minimized": 2n,
                    "Maximized": 3n
                };
            }
            static $h = 819573;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":819573,"n":"Normal","d":819573,"h":4295786869,"f":33},{"t":819573,"n":"Hidden","d":819573,"h":8590754165,"f":33},{"t":819573,"n":"Minimized","d":819573,"h":12885721461,"f":33},{"t":819573,"n":"Maximized","d":819573,"h":17180688757,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":819573,"h":21475656053,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":819573}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ProcessWindowStyle`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadPriorityLevel", ($self) => class ThreadPriorityLevel extends $.$spc.System.Enum
        {
            static Idle = -15;
            static Lowest = -2;
            static BelowNormal = -1;
            static Normal = 0;
            static AboveNormal = 1;
            static Highest = 2;
            static TimeCritical = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Idle": -15n,
                    "Lowest": -2n,
                    "BelowNormal": -1n,
                    "Normal": 0n,
                    "AboveNormal": 1n,
                    "Highest": 2n,
                    "TimeCritical": 15n
                };
            }
            static $h = 885109;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":885109,"n":"Idle","d":885109,"h":4295852405,"f":33},{"t":885109,"n":"Lowest","d":885109,"h":8590819701,"f":33},{"t":885109,"n":"BelowNormal","d":885109,"h":12885786997,"f":33},{"t":885109,"n":"Normal","d":885109,"h":17180754293,"f":33},{"t":885109,"n":"AboveNormal","d":885109,"h":21475721589,"f":33},{"t":885109,"n":"Highest","d":885109,"h":25770688885,"f":33},{"t":885109,"n":"TimeCritical","d":885109,"h":30065656181,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":885109,"h":34360623477,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":885109}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadPriorityLevel`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadState", ($self) => class ThreadState extends $.$spc.System.Enum
        {
            static Initialized = 0;
            static Ready = 1;
            static Running = 2;
            static Standby = 3;
            static Terminated = 4;
            static Wait = 5;
            static Transition = 6;
            static Unknown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Initialized": 0n,
                    "Ready": 1n,
                    "Running": 2n,
                    "Standby": 3n,
                    "Terminated": 4n,
                    "Wait": 5n,
                    "Transition": 6n,
                    "Unknown": 7n
                };
            }
            static $h = 950645;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":950645,"n":"Initialized","d":950645,"h":4295917941,"f":33},{"t":950645,"n":"Ready","d":950645,"h":8590885237,"f":33},{"t":950645,"n":"Running","d":950645,"h":12885852533,"f":33},{"t":950645,"n":"Standby","d":950645,"h":17180819829,"f":33},{"t":950645,"n":"Terminated","d":950645,"h":21475787125,"f":33},{"t":950645,"n":"Wait","d":950645,"h":25770754421,"f":33},{"t":950645,"n":"Transition","d":950645,"h":30065721717,"f":33},{"t":950645,"n":"Unknown","d":950645,"h":34360689013,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":950645,"h":38655656309,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":950645}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadState`; }
        });
        
        $asm.$str("$sdpc.System.Diagnostics.ThreadWaitReason", ($self) => class ThreadWaitReason extends $.$spc.System.Enum
        {
            static Executive = 0;
            static FreePage = 1;
            static PageIn = 2;
            static SystemAllocation = 3;
            static ExecutionDelay = 4;
            static Suspended = 5;
            static UserRequest = 6;
            static EventPairHigh = 7;
            static EventPairLow = 8;
            static LpcReceive = 9;
            static LpcReply = 10;
            static VirtualMemory = 11;
            static PageOut = 12;
            static Unknown = 13;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Executive": 0n,
                    "FreePage": 1n,
                    "PageIn": 2n,
                    "SystemAllocation": 3n,
                    "ExecutionDelay": 4n,
                    "Suspended": 5n,
                    "UserRequest": 6n,
                    "EventPairHigh": 7n,
                    "EventPairLow": 8n,
                    "LpcReceive": 9n,
                    "LpcReply": 10n,
                    "VirtualMemory": 11n,
                    "PageOut": 12n,
                    "Unknown": 13n
                };
            }
            static $h = 1016181;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1016181,"n":"Executive","d":1016181,"h":4295983477,"f":33},{"t":1016181,"n":"FreePage","d":1016181,"h":8590950773,"f":33},{"t":1016181,"n":"PageIn","d":1016181,"h":12885918069,"f":33},{"t":1016181,"n":"SystemAllocation","d":1016181,"h":17180885365,"f":33},{"t":1016181,"n":"ExecutionDelay","d":1016181,"h":21475852661,"f":33},{"t":1016181,"n":"Suspended","d":1016181,"h":25770819957,"f":33},{"t":1016181,"n":"UserRequest","d":1016181,"h":30065787253,"f":33},{"t":1016181,"n":"EventPairHigh","d":1016181,"h":34360754549,"f":33},{"t":1016181,"n":"EventPairLow","d":1016181,"h":38655721845,"f":33},{"t":1016181,"n":"LpcReceive","d":1016181,"h":42950689141,"f":33},{"t":1016181,"n":"LpcReply","d":1016181,"h":47245656437,"f":33},{"t":1016181,"n":"VirtualMemory","d":1016181,"h":51540623733,"f":33},{"t":1016181,"n":"PageOut","d":1016181,"h":55835591029,"f":33},{"t":1016181,"n":"Unknown","d":1016181,"h":60130558325,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1016181,"h":64425525621,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1016181}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.ThreadWaitReason`; }
        });
        
        $asm.$cls("$sdpc.Microsoft.Win32.SafeHandles.SafeProcessHandle", ($self) => class SafeProcessHandle extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IntPtr*/ existingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 98677;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"m":[{"r":262145,"n":"ReleaseHandle","d":98677,"h":12885000565,"f":32772}],"c":[{"n":".ctor","o":"$ctor$4","d":98677,"h":4295065973,"f":1},{"p":[{"n":"existingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":98677,"h":8590033269,"f":1}],"i":[57475073],"h":98677}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `Microsoft.Win32.SafeHandles.SafeProcessHandle`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventArgs", ($self) => class DataReceivedEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*string? */ get Data()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 164213;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885066101,"f":1},"n":"Data","d":164213,"h":8590098805,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":164213,"h":4295131509,"f":8}],"h":164213}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventArgs`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.MonitoringDescriptionAttribute", ($self) => class MonitoringDescriptionAttribute extends $.$scp.System.ComponentModel.DescriptionAttribute
        {
            $ctor$4(/*string*/ description)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 295285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":327719,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885197173,"f":32769},"n":"Description","d":295285,"h":8590229877,"f":32769}],"c":[{"p":[{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":295285,"h":4295262581,"f":1}],"h":295285,"a":[{"t":14614529,"c":21489451009,"a":[{"v":32767,"t":14548993}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.DescriptionAttribute; }
            static get $fullName() { return `System.Diagnostics.MonitoringDescriptionAttribute`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.DataReceivedEventHandler", ($self) => class DataReceivedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$sdpc.System.Diagnostics.DataReceivedEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 229749;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":164213}],"n":"Invoke","d":229749,"h":8590164341,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":164213},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":229749,"h":12885131637,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":229749,"h":17180098933,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":229749,"h":4295197045,"f":1}],"i":[57147393,113377281],"h":229749}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Diagnostics.DataReceivedEventHandler`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.Process", ($self) => class Process extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableRaisingEvents()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableRaisingEvents(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ExitCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get ExitTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get Handle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HandleCount()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get HasExited()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MachineName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModule? */ get MainModule()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MainWindowHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get MainWindowTitle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MaxWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MaxWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get MinWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set MinWorkingSet(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessModuleCollection */ get Modules()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get NonpagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get NonpagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PagedSystemMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PagedSystemMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakPagedMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakPagedMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakVirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakVirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PeakWorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PeakWorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ get PriorityClass()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessPriorityClass */ set PriorityClass(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get PrivateMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get PrivateMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ProcessName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get ProcessorAffinity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Responding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*Microsoft.Win32.SafeHandles.SafeProcessHandle */ get SafeHandle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SessionId()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamWriter */ get StandardInput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.StreamReader */ get StandardOutput()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ get StartInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessStartInfo */ set StartInfo(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ get SynchronizingObject()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ComponentModel.ISynchronizeInvoke? */ set SynchronizingObject(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ProcessThreadCollection */ get Threads()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get VirtualMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get VirtualMemorySize64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WorkingSet()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get WorkingSet64()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ ErrorDataReceived$remove(value)
            {
            }
            /*System.EventHandler*/ Exited$add(value)
            {
            }
            /*System.EventHandler*/ Exited$remove(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$add(value)
            {
            }
            /*System.Diagnostics.DataReceivedEventHandler?*/ OutputDataReceived$remove(value)
            {
            }
            /*void */ BeginErrorReadLine()
            {
            }
            /*void */ BeginOutputReadLine()
            {
            }
            /*void */ CancelErrorRead()
            {
            }
            /*void */ CancelOutputRead()
            {
            }
            /*void */ Close()
            {
            }
            /*bool */ CloseMainWindow()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            static /*void */ EnterDebugMode()
            {
            }
            static /*System.Diagnostics.Process */ GetCurrentProcess()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById(/*int*/ processId)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ GetProcessById$1(/*int*/ processId, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcesses$1(/*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName(/*string?*/ processName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process[] */ GetProcessesByName$1(/*string?*/ processName, /*string*/ machineName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Kill()
            {
            }
            /*void */ Kill$1(/*bool*/ entireProcessTree)
            {
            }
            static /*void */ LeaveDebugMode()
            {
            }
            /*void */ OnExited()
            {
            }
            /*void */ Refresh()
            {
            }
            /*bool */ Start()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$1(/*System.Diagnostics.ProcessStartInfo*/ startInfo)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$2(/*string*/ fileName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$3(/*string*/ fileName, /*string*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process */ Start$4(/*string*/ fileName, /*System.Collections.Generic.IEnumerable<string>*/ $arguments)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$5(/*string*/ fileName, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Diagnostics.Process? */ Start$6(/*string*/ fileName, /*string*/ $arguments, /*string*/ userName, /*System.Security.SecureString*/ password, /*string*/ domain)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.Process.ToString.apply(this, arguments); }
            /*void */ WaitForExit()
            {
            }
            /*bool */ WaitForExit$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForExit$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ WaitForExitAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$1(/*int*/ milliseconds)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ WaitForInputIdle$2(/*System.TimeSpan*/ timeout)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 360821;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885262709,"f":1},"n":"BasePriority","d":360821,"h":8590295413,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":21475197301,"f":1},"s":{"r":0,"d":0,"h":25770164597,"f":1},"n":"EnableRaisingEvents","d":360821,"h":17180230005,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":34360099189,"f":1},"n":"ExitCode","d":360821,"h":30065131893,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":42950033781,"f":1},"n":"ExitTime","d":360821,"h":38655066485,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":51539968373,"f":1},"n":"Handle","d":360821,"h":47245001077,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":60129902965,"f":1},"n":"HandleCount","d":360821,"h":55834935669,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":68719837557,"f":1},"n":"HasExited","d":360821,"h":64424870261,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77309772149,"f":1},"n":"Id","d":360821,"h":73014804853,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85899706741,"f":1},"n":"MachineName","d":360821,"h":81604739445,"f":1},{"p":426357,"g":{"r":0,"d":0,"h":94489641333,"f":1},"n":"MainModule","d":360821,"h":90194674037,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":103079575925,"f":1},"n":"MainWindowHandle","d":360821,"h":98784608629,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":111669510517,"f":1},"n":"MainWindowTitle","d":360821,"h":107374543221,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":120259445109,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":124554412405,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MaxWorkingSet","d":360821,"h":115964477813,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":133144346997,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},"s":{"r":0,"d":0,"h":137439314293,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"macos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"MinWorkingSet","d":360821,"h":128849379701,"f":1},{"p":491893,"g":{"r":0,"d":0,"h":146029248885,"f":1},"n":"Modules","d":360821,"h":141734281589,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":154619183477,"f":1},"n":"NonpagedSystemMemorySize","d":360821,"h":150324216181,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.NonpagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.NonpagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":163209118069,"f":1},"n":"NonpagedSystemMemorySize64","d":360821,"h":158914150773,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":171799052661,"f":1},"n":"PagedMemorySize","d":360821,"h":167504085365,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":180388987253,"f":1},"n":"PagedMemorySize64","d":360821,"h":176094019957,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":188978921845,"f":1},"n":"PagedSystemMemorySize","d":360821,"h":184683954549,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PagedSystemMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PagedSystemMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":197568856437,"f":1},"n":"PagedSystemMemorySize64","d":360821,"h":193273889141,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":206158791029,"f":1},"n":"PeakPagedMemorySize","d":360821,"h":201863823733,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakPagedMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakPagedMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":214748725621,"f":1},"n":"PeakPagedMemorySize64","d":360821,"h":210453758325,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":223338660213,"f":1},"n":"PeakVirtualMemorySize","d":360821,"h":219043692917,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakVirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakVirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":231928594805,"f":1},"n":"PeakVirtualMemorySize64","d":360821,"h":227633627509,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":240518529397,"f":1},"n":"PeakWorkingSet","d":360821,"h":236223562101,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PeakWorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PeakWorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":249108463989,"f":1},"n":"PeakWorkingSet64","d":360821,"h":244813496693,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":257698398581,"f":1},"s":{"r":0,"d":0,"h":261993365877,"f":1},"n":"PriorityBoostEnabled","d":360821,"h":253403431285,"f":1},{"p":557429,"g":{"r":0,"d":0,"h":270583300469,"f":1},"s":{"r":0,"d":0,"h":274878267765,"f":1},"n":"PriorityClass","d":360821,"h":266288333173,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":283468202357,"f":1},"n":"PrivateMemorySize","d":360821,"h":279173235061,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.PrivateMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.PrivateMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":292058136949,"f":1},"n":"PrivateMemorySize64","d":360821,"h":287763169653,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":300648071541,"f":1},"n":"PrivilegedProcessorTime","d":360821,"h":296353104245,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":309238006133,"f":1},"n":"ProcessName","d":360821,"h":304943038837,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":317827940725,"f":1},"s":{"r":0,"d":0,"h":322122908021,"f":1},"n":"ProcessorAffinity","d":360821,"h":313532973429,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":330712842613,"f":1},"n":"Responding","d":360821,"h":326417875317,"f":1},{"p":98677,"g":{"r":0,"d":0,"h":339302777205,"f":1},"n":"SafeHandle","d":360821,"h":335007809909,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":347892711797,"f":1},"n":"SessionId","d":360821,"h":343597744501,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":356482646389,"f":1},"n":"StandardError","d":360821,"h":352187679093,"f":1},{"p":62586881,"g":{"r":0,"d":0,"h":365072580981,"f":1},"n":"StandardInput","d":360821,"h":360777613685,"f":1},{"p":62455809,"g":{"r":0,"d":0,"h":373662515573,"f":1},"n":"StandardOutput","d":360821,"h":369367548277,"f":1},{"p":622965,"g":{"r":0,"d":0,"h":382252450165,"f":1},"s":{"r":0,"d":0,"h":386547417461,"f":1},"n":"StartInfo","d":360821,"h":377957482869,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":395137352053,"f":1},"n":"StartTime","d":360821,"h":390842384757,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1572903,"g":{"r":0,"d":0,"h":403727286645,"f":1},"s":{"r":0,"d":0,"h":408022253941,"f":1},"n":"SynchronizingObject","d":360821,"h":399432319349,"f":1},{"p":754037,"g":{"r":0,"d":0,"h":416612188533,"f":1},"n":"Threads","d":360821,"h":412317221237,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":425202123125,"f":1},"n":"TotalProcessorTime","d":360821,"h":420907155829,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":433792057717,"f":1},"n":"UserProcessorTime","d":360821,"h":429497090421,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":442381992309,"f":1},"n":"VirtualMemorySize","d":360821,"h":438087025013,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.VirtualMemorySize has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.VirtualMemorySize64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":450971926901,"f":1},"n":"VirtualMemorySize64","d":360821,"h":446676959605,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":459561861493,"f":1},"n":"WorkingSet","d":360821,"h":455266894197,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Process.WorkingSet has been deprecated because the type of the property can\u0027t represent all valid results. Use System.Diagnostics.Process.WorkingSet64 instead.","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":468151796085,"f":1},"n":"WorkingSet64","d":360821,"h":463856828789,"f":1}],"m":[{"r":65537,"n":"BeginErrorReadLine","d":360821,"h":511101469045,"f":1},{"r":65537,"n":"BeginOutputReadLine","d":360821,"h":515396436341,"f":1},{"r":65537,"n":"CancelErrorRead","d":360821,"h":519691403637,"f":1},{"r":65537,"n":"CancelOutputRead","d":360821,"h":523986370933,"f":1},{"r":65537,"n":"Close","d":360821,"h":528281338229,"f":1},{"r":262145,"n":"CloseMainWindow","d":360821,"h":532576305525,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":360821,"h":536871272821,"f":32772},{"r":65537,"n":"EnterDebugMode","d":360821,"h":541166240117,"f":33},{"r":360821,"n":"GetCurrentProcess","d":360821,"h":545461207413,"f":33},{"r":360821,"p":[{"n":"processId","p":655361}],"n":"GetProcessById","d":360821,"h":549756174709,"f":33},{"r":360821,"p":[{"n":"processId","p":655361},{"n":"machineName","p":1310721}],"n":"GetProcessById","o":"@$1","d":360821,"h":554051142005,"f":33},{"r":0,"n":"GetProcesses","d":360821,"h":558346109301,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"machineName","p":1310721}],"n":"GetProcesses","o":"@$1","d":360821,"h":562641076597,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721}],"n":"GetProcessesByName","d":360821,"h":566936043893,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":0,"p":[{"n":"processName","p":1310721},{"n":"machineName","p":1310721}],"n":"GetProcessesByName","o":"@$1","d":360821,"h":571231011189,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"Kill","d":360821,"h":575525978485,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"p":[{"n":"entireProcessTree","p":262145}],"n":"Kill","o":"@$1","d":360821,"h":579820945781,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":65537,"n":"LeaveDebugMode","d":360821,"h":584115913077,"f":33},{"r":65537,"n":"OnExited","d":360821,"h":588410880373,"f":4},{"r":65537,"n":"Refresh","d":360821,"h":592705847669,"f":1},{"r":262145,"n":"Start","d":360821,"h":597000814965,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":360821,"p":[{"n":"startInfo","p":622965}],"n":"Start","o":"@$1","d":360821,"h":601295782261,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":360821,"p":[{"n":"fileName","p":1310721}],"n":"Start","o":"@$2","d":360821,"h":605590749557,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":360821,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721}],"n":"Start","o":"@$3","d":360821,"h":609885716853,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":360821,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.String).$h}],"n":"Start","o":"@$4","d":360821,"h":614180684149,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"r":360821,"p":[{"n":"fileName","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$5","d":360821,"h":618475651445,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":360821,"p":[{"n":"fileName","p":1310721},{"n":"arguments","p":1310721},{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":"Start","o":"@$6","d":360821,"h":622770618741,"f":33,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":1310721,"n":"ToString","d":360821,"h":627065586037,"f":32769},{"r":65537,"n":"WaitForExit","d":360821,"h":631360553333,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForExit","o":"@$1","d":360821,"h":635655520629,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForExit","o":"@$2","d":360821,"h":639950487925,"f":1},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"WaitForExitAsync","d":360821,"h":644245455221,"f":1},{"r":262145,"n":"WaitForInputIdle","d":360821,"h":648540422517,"f":1},{"r":262145,"p":[{"n":"milliseconds","p":655361}],"n":"WaitForInputIdle","o":"@$1","d":360821,"h":652835389813,"f":1},{"r":262145,"p":[{"n":"timeout","p":140705793}],"n":"WaitForInputIdle","o":"@$2","d":360821,"h":657130357109,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":360821,"h":4295328117,"f":1}],"e":[{"e":229749,"m":{"r":65537,"p":[{"n":"value","p":229749}],"n":"add_ErrorDataReceived","d":360821,"h":476741730677,"f":1},"r":{"r":65537,"p":[{"n":"value","p":229749}],"n":"remove_ErrorDataReceived","d":360821,"h":481036697973,"f":1},"n":"ErrorDataReceived","d":360821,"h":472446763381,"f":1},{"e":46989313,"m":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"add_Exited","d":360821,"h":489626632565,"f":1},"r":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"remove_Exited","d":360821,"h":493921599861,"f":1},"n":"Exited","d":360821,"h":485331665269,"f":1},{"e":229749,"m":{"r":65537,"p":[{"n":"value","p":229749}],"n":"add_OutputDataReceived","d":360821,"h":502511534453,"f":1},"r":{"r":65537,"p":[{"n":"value","p":229749}],"n":"remove_OutputDataReceived","d":360821,"h":506806501749,"f":1},"n":"OutputDataReceived","d":360821,"h":498216567157,"f":1}],"i":[1048615,57475073],"h":360821,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.Process`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessModule", ($self) => class ProcessModule extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IntPtr */ get BaseAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get EntryPointAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get FileName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.FileVersionInfo */ get FileVersionInfo()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ModuleMemorySize()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get ModuleName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdpc.System.Diagnostics.ProcessModule.ToString.apply(this, arguments); }
            static $h = 426357;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":786433,"g":{"r":0,"d":0,"h":12885328245,"f":1},"n":"BaseAddress","d":426357,"h":8590360949,"f":1},{"p":786433,"g":{"r":0,"d":0,"h":21475262837,"f":1},"n":"EntryPointAddress","d":426357,"h":17180295541,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":30065197429,"f":1},"n":"FileName","d":426357,"h":25770230133,"f":1},{"p":102922,"g":{"r":0,"d":0,"h":38655132021,"f":1},"n":"FileVersionInfo","d":426357,"h":34360164725,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":47245066613,"f":1},"n":"ModuleMemorySize","d":426357,"h":42950099317,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835001205,"f":1},"n":"ModuleName","d":426357,"h":51540033909,"f":1}],"m":[{"r":1310721,"n":"ToString","d":426357,"h":60129968501,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":426357,"h":4295393653,"f":8}],"i":[1048615,57475073],"h":426357,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessModuleDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessModule`; }
        });
        
        $asm.$cls("$sdpc.System.Diagnostics.ProcessThread", ($self) => class ProcessThread extends $.$scp.System.ComponentModel.Component
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*int */ get BasePriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CurrentPriority()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set IdealProcessor(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get PriorityBoostEnabled()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PriorityBoostEnabled(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ get PriorityLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadPriorityLevel */ set PriorityLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get PrivilegedProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ set ProcessorAffinity(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IntPtr */ get StartAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ get StartTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadState */ get ThreadState()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get TotalProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get UserProcessorTime()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Diagnostics.ThreadWaitReason */ get WaitReason()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ResetIdealProcessor()
            {
            }
            static $h = 688501;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196647,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885590389,"f":1},"n":"BasePriority","d":688501,"h":8590623093,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":21475524981,"f":1},"n":"CurrentPriority","d":688501,"h":17180557685,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065459573,"f":1},"n":"Id","d":688501,"h":25770492277,"f":1},{"p":655361,"s":{"r":0,"d":0,"h":38655394165,"f":1},"n":"IdealProcessor","d":688501,"h":34360426869,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47245328757,"f":1},"s":{"r":0,"d":0,"h":51540296053,"f":1},"n":"PriorityBoostEnabled","d":688501,"h":42950361461,"f":1},{"p":885109,"g":{"r":0,"d":0,"h":60130230645,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]}]},"s":{"r":0,"d":0,"h":64425197941,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"PriorityLevel","d":688501,"h":55835263349,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":73015132533,"f":1},"n":"PrivilegedProcessorTime","d":688501,"h":68720165237,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":786433,"s":{"r":0,"d":0,"h":81605067125,"f":1},"n":"ProcessorAffinity","d":688501,"h":77310099829,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":786433,"g":{"r":0,"d":0,"h":90195001717,"f":1},"n":"StartAddress","d":688501,"h":85900034421,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":98784936309,"f":1},"n":"StartTime","d":688501,"h":94489969013,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":950645,"g":{"r":0,"d":0,"h":107374870901,"f":1},"n":"ThreadState","d":688501,"h":103079903605,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":115964805493,"f":1},"n":"TotalProcessorTime","d":688501,"h":111669838197,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":140705793,"g":{"r":0,"d":0,"h":124554740085,"f":1},"n":"UserProcessorTime","d":688501,"h":120259772789,"f":1,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"maccatalyst","t":1310721}]}]},{"p":1016181,"g":{"r":0,"d":0,"h":133144674677,"f":1},"n":"WaitReason","d":688501,"h":128849707381,"f":1}],"m":[{"r":65537,"n":"ResetIdealProcessor","d":688501,"h":137439641973,"f":1}],"c":[{"n":".ctor","o":"$ctor$3","d":688501,"h":4295655797,"f":8}],"i":[1048615,57475073],"h":688501,"a":[{"t":458791,"c":8590393383,"a":[{"v":"System.Diagnostics.Design.ProcessThreadDesigner, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$scp.System.ComponentModel.Component; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$scp.System.ComponentModel.IComponent, $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.ProcessThread`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Diagnostics.FileVersionInfo", "NetJs.System.IO.FileSystem.DriveInfo", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Specialized", "NetJs.System.Security.AccessControl", "NetJs.Microsoft.Win32.Registry", "NetJs.System.IO.Pipes"))