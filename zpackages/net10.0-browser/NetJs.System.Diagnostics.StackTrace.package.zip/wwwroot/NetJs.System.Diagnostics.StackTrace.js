
//--TRIMMABLE-BOUNDARY-START(43)
(async function () {
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {
  "h": 43,
  "f": "System.Diagnostics.StackTrace",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.StackTrace",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.StackTrace",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131115)
        $asm.$cls(`$sds.SDS.ISymbolBinder`, ($self) => class ISymbolBinder
        {
            static $h = 131115;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098411),
    {
      "r": 458795,
      "p": [
        {
          "n": "importer",
          "p": 655361
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "searchPath",
          "p": 1310721
        }
      ],
      "n": "GetReader",
      "o": "SDS$ISymbolBinder$GetReader",
      "d": 131115,
      "h": 4295098411,
      "f": 16777473,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295098411)
  ],
  "h": 131115
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolBinder`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131115)
        
        

        //--TRIMMABLE-BOUNDARY-START(524331)
        $asm.$cls(`$sds.SDS.ISymbolScope`, ($self) => class ISymbolScope
        {
            static $h = 524331;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835099179),
    {
      "p": 327723,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360811,
        "f": 50331905
      },
      "n": "Method",
      "o": "SDS$ISymbolScope$Method",
      "d": 524331,
      "h": 55835099179,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55835099179),
//--TRIMMABLE-BOUNDARY-START(60130066475),
    {
      "p": 524331,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295403,
        "f": 50331905
      },
      "n": "Parent",
      "o": "SDS$ISymbolScope$Parent",
      "d": 524331,
      "h": 60130066475,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60130066475),
//--TRIMMABLE-BOUNDARY-START(64425033771),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655229995,
        "f": 50331905
      },
      "n": "StartOffset",
      "o": "SDS$ISymbolScope$StartOffset",
      "d": 524331,
      "h": 64425033771,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64425033771),
//--TRIMMABLE-BOUNDARY-START(4295491627),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885426219,
        "f": 50331905
      },
      "n": "EndOffset",
      "o": "SDS$ISymbolScope$EndOffset",
      "d": 524331,
      "h": 4295491627,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295491627)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950197291),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolScope).$h,
      "n": "GetChildren",
      "o": "SDS$ISymbolScope$GetChildren",
      "d": 524331,
      "h": 42950197291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950197291),
//--TRIMMABLE-BOUNDARY-START(47245164587),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolVariable).$h,
      "n": "GetLocals",
      "o": "SDS$ISymbolScope$GetLocals",
      "d": 524331,
      "h": 47245164587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245164587),
//--TRIMMABLE-BOUNDARY-START(51540131883),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "SDS$ISymbolScope$GetNamespaces",
      "d": 524331,
      "h": 51540131883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540131883)
  ],
  "h": 524331
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolScope`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524331)
        
        

        //--TRIMMABLE-BOUNDARY-START(458795)
        $asm.$cls(`$sds.SDS.ISymbolReader`, ($self) => class ISymbolReader
        {
            static $h = 458795;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540066347),
    {
      "p": 786475,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590393387,
        "f": 50331905
      },
      "n": "UserEntryPoint",
      "o": "SDS$ISymbolReader$UserEntryPoint",
      "d": 458795,
      "h": 51540066347,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540066347)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360683),
    {
      "r": 262187,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "language",
          "p": 89784321
        },
        {
          "n": "languageVendor",
          "p": 89784321
        },
        {
          "n": "documentType",
          "p": 89784321
        }
      ],
      "n": "GetDocument",
      "o": "SDS$ISymbolReader$GetDocument",
      "d": 458795,
      "h": 12885360683,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885360683),
//--TRIMMABLE-BOUNDARY-START(17180327979),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolDocument).$h,
      "n": "GetDocuments",
      "o": "SDS$ISymbolReader$GetDocuments",
      "d": 458795,
      "h": 17180327979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180327979),
//--TRIMMABLE-BOUNDARY-START(30065229867),
    {
      "r": 327723,
      "p": [
        {
          "n": "method",
          "p": 786475
        }
      ],
      "n": "GetMethod",
      "o": "SDS$ISymbolReader$GetMethod$1",
      "d": 458795,
      "h": 30065229867,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065229867),
//--TRIMMABLE-BOUNDARY-START(25770262571),
    {
      "r": 327723,
      "p": [
        {
          "n": "method",
          "p": 786475
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetMethod",
      "o": "SDS$ISymbolReader$GetMethod",
      "d": 458795,
      "h": 25770262571,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770262571),
//--TRIMMABLE-BOUNDARY-START(47245099051),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolVariable).$h,
      "p": [
        {
          "n": "parent",
          "p": 786475
        }
      ],
      "n": "GetVariables",
      "o": "SDS$ISymbolReader$GetVariables",
      "d": 458795,
      "h": 47245099051,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245099051),
//--TRIMMABLE-BOUNDARY-START(21475295275),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolVariable).$h,
      "n": "GetGlobalVariables",
      "o": "SDS$ISymbolReader$GetGlobalVariables",
      "d": 458795,
      "h": 21475295275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475295275),
//--TRIMMABLE-BOUNDARY-START(34360197163),
    {
      "r": 327723,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetMethodFromDocumentPosition",
      "o": "SDS$ISymbolReader$GetMethodFromDocumentPosition",
      "d": 458795,
      "h": 34360197163,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360197163),
//--TRIMMABLE-BOUNDARY-START(42950131755),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetSymAttribute",
      "o": "SDS$ISymbolReader$GetSymAttribute",
      "d": 458795,
      "h": 42950131755,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950131755),
//--TRIMMABLE-BOUNDARY-START(38655164459),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "SDS$ISymbolReader$GetNamespaces",
      "d": 458795,
      "h": 38655164459,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655164459)
  ],
  "h": 458795
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolReader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458795)
        
        

        //--TRIMMABLE-BOUNDARY-START(655403)
        $asm.$cls(`$sds.SDS.ISymbolWriter`, ($self) => class ISymbolWriter
        {
            static $h = 655403;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245295659),
    {
      "r": 65537,
      "p": [
        {
          "n": "emitter",
          "p": 786433
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "fFullBuild",
          "p": 262145
        }
      ],
      "n": "Initialize",
      "o": "SDS$ISymbolWriter$Initialize",
      "d": 655403,
      "h": 47245295659,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245295659),
//--TRIMMABLE-BOUNDARY-START(21475491883),
    {
      "r": 72220673,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "language",
          "p": 89784321
        },
        {
          "n": "languageVendor",
          "p": 89784321
        },
        {
          "n": "documentType",
          "p": 89784321
        }
      ],
      "n": "DefineDocument",
      "o": "SDS$ISymbolWriter$DefineDocument",
      "d": 655403,
      "h": 21475491883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475491883),
//--TRIMMABLE-BOUNDARY-START(81605034027),
    {
      "r": 65537,
      "p": [
        {
          "n": "entryMethod",
          "p": 786475
        }
      ],
      "n": "SetUserEntryPoint",
      "o": "SDS$ISymbolWriter$SetUserEntryPoint",
      "d": 655403,
      "h": 81605034027,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81605034027),
//--TRIMMABLE-BOUNDARY-START(51540262955),
    {
      "r": 65537,
      "p": [
        {
          "n": "method",
          "p": 786475
        }
      ],
      "n": "OpenMethod",
      "o": "SDS$ISymbolWriter$OpenMethod",
      "d": 655403,
      "h": 51540262955,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540262955),
//--TRIMMABLE-BOUNDARY-START(8590589995),
    {
      "r": 65537,
      "n": "CloseMethod",
      "o": "SDS$ISymbolWriter$CloseMethod",
      "d": 655403,
      "h": 8590589995,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590589995),
//--TRIMMABLE-BOUNDARY-START(42950328363),
    {
      "r": 65537,
      "p": [
        {
          "n": "document",
          "p": 72220673
        },
        {
          "n": "offsets",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "endLines",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "endColumns",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "DefineSequencePoints",
      "o": "SDS$ISymbolWriter$DefineSequencePoints",
      "d": 655403,
      "h": 42950328363,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950328363),
//--TRIMMABLE-BOUNDARY-START(60130197547),
    {
      "r": 655361,
      "p": [
        {
          "n": "startOffset",
          "p": 655361
        }
      ],
      "n": "OpenScope",
      "o": "SDS$ISymbolWriter$OpenScope",
      "d": 655403,
      "h": 60130197547,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60130197547),
//--TRIMMABLE-BOUNDARY-START(17180524587),
    {
      "r": 65537,
      "p": [
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "CloseScope",
      "o": "SDS$ISymbolWriter$CloseScope",
      "d": 655403,
      "h": 17180524587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180524587),
//--TRIMMABLE-BOUNDARY-START(68720132139),
    {
      "r": 65537,
      "p": [
        {
          "n": "scopeID",
          "p": 655361
        },
        {
          "n": "startOffset",
          "p": 655361
        },
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "SetScopeRange",
      "o": "SDS$ISymbolWriter$SetScopeRange",
      "d": 655403,
      "h": 68720132139,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(68720132139),
//--TRIMMABLE-BOUNDARY-START(34360393771),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 114556929
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        },
        {
          "n": "startOffset",
          "p": 655361
        },
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "DefineLocalVariable",
      "o": "SDS$ISymbolWriter$DefineLocalVariable",
      "d": 655403,
      "h": 34360393771,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360393771),
//--TRIMMABLE-BOUNDARY-START(38655361067),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 119013377
        },
        {
          "n": "sequence",
          "p": 655361
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineParameter",
      "o": "SDS$ISymbolWriter$DefineParameter",
      "d": 655403,
      "h": 38655361067,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655361067),
//--TRIMMABLE-BOUNDARY-START(25770459179),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 114556929
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineField",
      "o": "SDS$ISymbolWriter$DefineField",
      "d": 655403,
      "h": 25770459179,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770459179),
//--TRIMMABLE-BOUNDARY-START(30065426475),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 114556929
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineGlobalVariable",
      "o": "SDS$ISymbolWriter$DefineGlobalVariable",
      "d": 655403,
      "h": 30065426475,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065426475),
//--TRIMMABLE-BOUNDARY-START(4295622699),
    {
      "r": 65537,
      "n": "Close",
      "o": "SDS$ISymbolWriter$Close",
      "d": 655403,
      "h": 4295622699,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622699),
//--TRIMMABLE-BOUNDARY-START(73015099435),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "SetSymAttribute",
      "o": "SDS$ISymbolWriter$SetSymAttribute",
      "d": 655403,
      "h": 73015099435,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73015099435),
//--TRIMMABLE-BOUNDARY-START(55835230251),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "OpenNamespace",
      "o": "SDS$ISymbolWriter$OpenNamespace",
      "d": 655403,
      "h": 55835230251,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55835230251),
//--TRIMMABLE-BOUNDARY-START(12885557291),
    {
      "r": 65537,
      "n": "CloseNamespace",
      "o": "SDS$ISymbolWriter$CloseNamespace",
      "d": 655403,
      "h": 12885557291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885557291),
//--TRIMMABLE-BOUNDARY-START(85900001323),
    {
      "r": 65537,
      "p": [
        {
          "n": "fullName",
          "p": 1310721
        }
      ],
      "n": "UsingNamespace",
      "o": "SDS$ISymbolWriter$UsingNamespace",
      "d": 655403,
      "h": 85900001323,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(85900001323),
//--TRIMMABLE-BOUNDARY-START(64425164843),
    {
      "r": 65537,
      "p": [
        {
          "n": "startDoc",
          "p": 72220673
        },
        {
          "n": "startLine",
          "p": 655361
        },
        {
          "n": "startColumn",
          "p": 655361
        },
        {
          "n": "endDoc",
          "p": 72220673
        },
        {
          "n": "endLine",
          "p": 655361
        },
        {
          "n": "endColumn",
          "p": 655361
        }
      ],
      "n": "SetMethodSourceRange",
      "o": "SDS$ISymbolWriter$SetMethodSourceRange",
      "d": 655403,
      "h": 64425164843,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64425164843),
//--TRIMMABLE-BOUNDARY-START(77310066731),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingWriter",
          "p": 786433
        }
      ],
      "n": "SetUnderlyingWriter",
      "o": "SDS$ISymbolWriter$SetUnderlyingWriter",
      "d": 655403,
      "h": 77310066731,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77310066731)
  ],
  "h": 655403
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolWriter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655403)
        
        

        //--TRIMMABLE-BOUNDARY-START(327723)
        $asm.$cls(`$sds.SDS.ISymbolMethod`, ($self) => class ISymbolMethod
        {
            static $h = 327723;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719804459),
    {
      "p": 786475,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131499,
        "f": 50331905
      },
      "n": "Token",
      "o": "SDS$ISymbolMethod$Token",
      "d": 327723,
      "h": 68719804459,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68719804459),
//--TRIMMABLE-BOUNDARY-START(64424837163),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196907,
        "f": 50331905
      },
      "n": "SequencePointCount",
      "o": "SDS$ISymbolMethod$SequencePointCount",
      "d": 327723,
      "h": 64424837163,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64424837163),
//--TRIMMABLE-BOUNDARY-START(60129869867),
    {
      "p": 524331,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590262315,
        "f": 50331905
      },
      "n": "RootScope",
      "o": "SDS$ISymbolMethod$RootScope",
      "d": 327723,
      "h": 60129869867,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60129869867)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539935275),
    {
      "r": 65537,
      "p": [
        {
          "n": "offsets",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "documents",
          "p": $.$typeArray($.$sds.SDS.ISymbolDocument).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "endLines",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "endColumns",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "GetSequencePoints",
      "o": "SDS$ISymbolMethod$GetSequencePoints",
      "d": 327723,
      "h": 51539935275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51539935275),
//--TRIMMABLE-BOUNDARY-START(47244967979),
    {
      "r": 524331,
      "p": [
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetScope",
      "o": "SDS$ISymbolMethod$GetScope",
      "d": 327723,
      "h": 47244967979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47244967979),
//--TRIMMABLE-BOUNDARY-START(34360066091),
    {
      "r": 655361,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetOffset",
      "o": "SDS$ISymbolMethod$GetOffset",
      "d": 327723,
      "h": 34360066091,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360066091),
//--TRIMMABLE-BOUNDARY-START(42950000683),
    {
      "r": $.$typeArray($.$$.S.Int32).$h,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetRanges",
      "o": "SDS$ISymbolMethod$GetRanges",
      "d": 327723,
      "h": 42950000683,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950000683),
//--TRIMMABLE-BOUNDARY-START(38655033387),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolVariable).$h,
      "n": "GetParameters",
      "o": "SDS$ISymbolMethod$GetParameters",
      "d": 327723,
      "h": 38655033387,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655033387),
//--TRIMMABLE-BOUNDARY-START(30065098795),
    {
      "r": 393259,
      "n": "GetNamespace",
      "o": "SDS$ISymbolMethod$GetNamespace",
      "d": 327723,
      "h": 30065098795,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065098795),
//--TRIMMABLE-BOUNDARY-START(55834902571),
    {
      "r": 262145,
      "p": [
        {
          "n": "docs",
          "p": $.$typeArray($.$sds.SDS.ISymbolDocument).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.S.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.S.Int32).$h
        }
      ],
      "n": "GetSourceStartEnd",
      "o": "SDS$ISymbolMethod$GetSourceStartEnd",
      "d": 327723,
      "h": 55834902571,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55834902571)
  ],
  "h": 327723
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolMethod`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolMethod`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327723)
        
        

        //--TRIMMABLE-BOUNDARY-START(589867)
        $asm.$cls(`$sds.SDS.ISymbolVariable`, ($self) => class ISymbolVariable
        {
            static $h = 589867;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079804971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899935787,
        "f": 50331905
      },
      "n": "Name",
      "o": "SDS$ISymbolVariable$Name",
      "d": 589867,
      "h": 103079804971,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103079804971),
//--TRIMMABLE-BOUNDARY-START(21475426347),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066603,
        "f": 50331905
      },
      "n": "Attributes",
      "o": "SDS$ISymbolVariable$Attributes",
      "d": 589867,
      "h": 21475426347,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475426347),
//--TRIMMABLE-BOUNDARY-START(17180459051),
    {
      "p": 720939,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132011,
        "f": 50331905
      },
      "n": "AddressKind",
      "o": "SDS$ISymbolVariable$AddressKind",
      "d": 589867,
      "h": 17180459051,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180459051),
//--TRIMMABLE-BOUNDARY-START(4295557163),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328235,
        "f": 50331905
      },
      "n": "AddressField1",
      "o": "SDS$ISymbolVariable$AddressField1",
      "d": 589867,
      "h": 4295557163,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295557163),
//--TRIMMABLE-BOUNDARY-START(8590524459),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262827,
        "f": 50331905
      },
      "n": "AddressField2",
      "o": "SDS$ISymbolVariable$AddressField2",
      "d": 589867,
      "h": 8590524459,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590524459),
//--TRIMMABLE-BOUNDARY-START(12885491755),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197419,
        "f": 50331905
      },
      "n": "AddressField3",
      "o": "SDS$ISymbolVariable$AddressField3",
      "d": 589867,
      "h": 12885491755,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885491755),
//--TRIMMABLE-BOUNDARY-START(107374772267),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489870379,
        "f": 50331905
      },
      "n": "StartOffset",
      "o": "SDS$ISymbolVariable$StartOffset",
      "d": 589867,
      "h": 107374772267,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107374772267),
//--TRIMMABLE-BOUNDARY-START(25770393643),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310001195,
        "f": 50331905
      },
      "n": "EndOffset",
      "o": "SDS$ISymbolVariable$EndOffset",
      "d": 589867,
      "h": 25770393643,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770393643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784837675),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetSignature",
      "o": "SDS$ISymbolVariable$GetSignature",
      "d": 589867,
      "h": 98784837675,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(98784837675)
  ],
  "h": 589867
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolVariable`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolVariable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589867)
        
        

        //--TRIMMABLE-BOUNDARY-START(262187)
        $asm.$cls(`$sds.SDS.ISymbolDocument`, ($self) => class ISymbolDocument
        {
            static $h = 262187;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079477291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706219,
        "f": 50331905
      },
      "n": "URL",
      "o": "SDS$ISymbolDocument$URL",
      "d": 262187,
      "h": 103079477291,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103079477291),
//--TRIMMABLE-BOUNDARY-START(8590196779),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033259,
        "f": 50331905
      },
      "n": "DocumentType",
      "o": "SDS$ISymbolDocument$DocumentType",
      "d": 262187,
      "h": 8590196779,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590196779),
//--TRIMMABLE-BOUNDARY-START(90194575403),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902443,
        "f": 50331905
      },
      "n": "Language",
      "o": "SDS$ISymbolDocument$Language",
      "d": 262187,
      "h": 90194575403,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90194575403),
//--TRIMMABLE-BOUNDARY-START(94489542699),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837035,
        "f": 50331905
      },
      "n": "LanguageVendor",
      "o": "SDS$ISymbolDocument$LanguageVendor",
      "d": 262187,
      "h": 94489542699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94489542699),
//--TRIMMABLE-BOUNDARY-START(4295229483),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098667,
        "f": 50331905
      },
      "n": "CheckSumAlgorithmId",
      "o": "SDS$ISymbolDocument$CheckSumAlgorithmId",
      "d": 262187,
      "h": 4295229483,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295229483),
//--TRIMMABLE-BOUNDARY-START(85899608107),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967851,
        "f": 50331905
      },
      "n": "HasEmbeddedSource",
      "o": "SDS$ISymbolDocument$HasEmbeddedSource",
      "d": 262187,
      "h": 85899608107,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85899608107),
//--TRIMMABLE-BOUNDARY-START(98784509995),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771627,
        "f": 50331905
      },
      "n": "SourceLength",
      "o": "SDS$ISymbolDocument$SourceLength",
      "d": 262187,
      "h": 98784509995,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98784509995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77309673515),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "n": "GetCheckSum",
      "o": "SDS$ISymbolDocument$GetCheckSum",
      "d": 262187,
      "h": 77309673515,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77309673515),
//--TRIMMABLE-BOUNDARY-START(12885164075),
    {
      "r": 655361,
      "p": [
        {
          "n": "line",
          "p": 655361
        }
      ],
      "n": "FindClosestLine",
      "o": "SDS$ISymbolDocument$FindClosestLine",
      "d": 262187,
      "h": 12885164075,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885164075),
//--TRIMMABLE-BOUNDARY-START(81604640811),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "startLine",
          "p": 655361
        },
        {
          "n": "startColumn",
          "p": 655361
        },
        {
          "n": "endLine",
          "p": 655361
        },
        {
          "n": "endColumn",
          "p": 655361
        }
      ],
      "n": "GetSourceRange",
      "o": "SDS$ISymbolDocument$GetSourceRange",
      "d": 262187,
      "h": 81604640811,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81604640811)
  ],
  "h": 262187
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolDocument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolDocument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262187)
        
        

        //--TRIMMABLE-BOUNDARY-START(393259)
        $asm.$cls(`$sds.SDS.ISymbolNamespace`, ($self) => class ISymbolNamespace
        {
            static $h = 393259;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590327851,
        "f": 50331905
      },
      "n": "Name",
      "o": "SDS$ISymbolNamespace$Name",
      "d": 393259,
      "h": 21475229739,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475229739)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295147),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "SDS$ISymbolNamespace$GetNamespaces",
      "d": 393259,
      "h": 12885295147,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885295147),
//--TRIMMABLE-BOUNDARY-START(17180262443),
    {
      "r": $.$typeArray($.$sds.SDS.ISymbolVariable).$h,
      "n": "GetVariables",
      "o": "SDS$ISymbolNamespace$GetVariables",
      "d": 393259,
      "h": 17180262443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180262443)
  ],
  "h": 393259
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolNamespace`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393259)
        
        

        //--TRIMMABLE-BOUNDARY-START(196651)
        $asm.$cls(`$sds.SDS.ISymbolBinder1`, ($self) => class ISymbolBinder1
        {
            static $h = 196651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163947),
    {
      "r": 458795,
      "p": [
        {
          "n": "importer",
          "p": 786433
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "searchPath",
          "p": 1310721
        }
      ],
      "n": "GetReader",
      "o": "SDS$ISymbolBinder1$GetReader",
      "d": 196651,
      "h": 4295163947,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295163947)
  ],
  "h": 196651
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}ISymbolBinder1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196651)
        
        

        //--TRIMMABLE-BOUNDARY-START(917547)
        $asm.$cls(`$sds.SDS.SymLanguageType`, ($self) => class SymLanguageType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180786731)
            /*Guid*/ static C;
            //--TRIMMABLE-BOUNDARY-END(17180786731)
            
            //--TRIMMABLE-BOUNDARY-START(25770721323)
            /*Guid*/ static CPlusPlus;
            //--TRIMMABLE-BOUNDARY-END(25770721323)
            
            //--TRIMMABLE-BOUNDARY-START(30065688619)
            /*Guid*/ static CSharp;
            //--TRIMMABLE-BOUNDARY-END(30065688619)
            
            //--TRIMMABLE-BOUNDARY-START(12885819435)
            /*Guid*/ static Basic;
            //--TRIMMABLE-BOUNDARY-END(12885819435)
            
            //--TRIMMABLE-BOUNDARY-START(38655623211)
            /*Guid*/ static Java;
            //--TRIMMABLE-BOUNDARY-END(38655623211)
            
            //--TRIMMABLE-BOUNDARY-START(21475754027)
            /*Guid*/ static Cobol;
            //--TRIMMABLE-BOUNDARY-END(21475754027)
            
            //--TRIMMABLE-BOUNDARY-START(51540525099)
            /*Guid*/ static Pascal;
            //--TRIMMABLE-BOUNDARY-END(51540525099)
            
            //--TRIMMABLE-BOUNDARY-START(34360655915)
            /*Guid*/ static ILAssembly;
            //--TRIMMABLE-BOUNDARY-END(34360655915)
            
            //--TRIMMABLE-BOUNDARY-START(42950590507)
            /*Guid*/ static JScript;
            //--TRIMMABLE-BOUNDARY-END(42950590507)
            
            //--TRIMMABLE-BOUNDARY-START(55835492395)
            /*Guid*/ static SMC;
            //--TRIMMABLE-BOUNDARY-END(55835492395)
            
            //--TRIMMABLE-BOUNDARY-START(47245557803)
            /*Guid*/ static MCPlusPlus;
            //--TRIMMABLE-BOUNDARY-END(47245557803)
            
            //--TRIMMABLE-BOUNDARY-START(8590852139)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852139)
            
            //--TRIMMABLE-BOUNDARY-START(8590852139)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590852139)
            
            //--TRIMMABLE-BOUNDARY-START(4295884843)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295884843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786731)
                    this.C = new $.$$.S.Guid().$ctor$4(1671464724, ((64567 & 0xFFFF) | 0), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(17180786731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721323)
                    this.CPlusPlus = new $.$$.S.Guid().$ctor$4(974311607, ((49772 & 0xFFFF) | 0), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(25770721323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065688619)
                    this.CSharp = new $.$$.S.Guid().$ctor$4(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(30065688619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885819435)
                    this.Basic = new $.$$.S.Guid().$ctor$4(974311608, ((49772 & 0xFFFF) | 0), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(12885819435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655623211)
                    this.Java = new $.$$.S.Guid().$ctor$4(974311604, ((49772 & 0xFFFF) | 0), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(38655623211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754027)
                    this.Cobol = new $.$$.S.Guid().$ctor$4((2936302801 | 0), ((53473 & 0xFFFF) | 0), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(21475754027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540525099)
                    this.Pascal = new $.$$.S.Guid().$ctor$4((2936302802 | 0), ((53473 & 0xFFFF) | 0), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(51540525099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655915)
                    this.ILAssembly = new $.$$.S.Guid().$ctor$4((2936302803 | 0), ((53473 & 0xFFFF) | 0), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(34360655915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950590507)
                    this.JScript = new $.$$.S.Guid().$ctor$4(974311606, ((49772 & 0xFFFF) | 0), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(42950590507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492395)
                    this.SMC = new $.$$.S.Guid().$ctor$4(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                    //--TRIMMABLE-BOUNDARY-END(55835492395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557803)
                    this.MCPlusPlus = new $.$$.S.Guid().$ctor$4(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(47245557803)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295884843)
            
            static $h = 917547;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786731),
    {
      "t": 89784321,
      "n": "C",
      "d": 917547,
      "h": 17180786731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786731),
//--TRIMMABLE-BOUNDARY-START(25770721323),
    {
      "t": 89784321,
      "n": "CPlusPlus",
      "d": 917547,
      "h": 25770721323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721323),
//--TRIMMABLE-BOUNDARY-START(30065688619),
    {
      "t": 89784321,
      "n": "CSharp",
      "d": 917547,
      "h": 30065688619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688619),
//--TRIMMABLE-BOUNDARY-START(12885819435),
    {
      "t": 89784321,
      "n": "Basic",
      "d": 917547,
      "h": 12885819435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819435),
//--TRIMMABLE-BOUNDARY-START(38655623211),
    {
      "t": 89784321,
      "n": "Java",
      "d": 917547,
      "h": 38655623211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655623211),
//--TRIMMABLE-BOUNDARY-START(21475754027),
    {
      "t": 89784321,
      "n": "Cobol",
      "d": 917547,
      "h": 21475754027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754027),
//--TRIMMABLE-BOUNDARY-START(51540525099),
    {
      "t": 89784321,
      "n": "Pascal",
      "d": 917547,
      "h": 51540525099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540525099),
//--TRIMMABLE-BOUNDARY-START(34360655915),
    {
      "t": 89784321,
      "n": "ILAssembly",
      "d": 917547,
      "h": 34360655915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655915),
//--TRIMMABLE-BOUNDARY-START(42950590507),
    {
      "t": 89784321,
      "n": "JScript",
      "d": 917547,
      "h": 42950590507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950590507),
//--TRIMMABLE-BOUNDARY-START(55835492395),
    {
      "t": 89784321,
      "n": "SMC",
      "d": 917547,
      "h": 55835492395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835492395),
//--TRIMMABLE-BOUNDARY-START(47245557803),
    {
      "t": 89784321,
      "n": "MCPlusPlus",
      "d": 917547,
      "h": 47245557803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245557803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852139),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917547,
      "h": 8590852139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852139)
  ],
  "h": 917547
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.SymLanguageType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}SymLanguageType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917547)
        
        

        //--TRIMMABLE-BOUNDARY-START(852011)
        $asm.$cls(`$sds.SDS.SymDocumentType`, ($self) => class SymDocumentType extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885753899)
            /*Guid*/ static Text;
            //--TRIMMABLE-BOUNDARY-END(12885753899)
            
            //--TRIMMABLE-BOUNDARY-START(8590786603)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590786603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786603)
            
            //--TRIMMABLE-BOUNDARY-START(8590786603)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590786603)
            
            //--TRIMMABLE-BOUNDARY-START(4295819307)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753899)
                    this.Text = new $.$$.S.Guid().$ctor$4(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                    //--TRIMMABLE-BOUNDARY-END(12885753899)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819307)
            
            static $h = 852011;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753899),
    {
      "t": 89784321,
      "n": "Text",
      "d": 852011,
      "h": 12885753899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786603),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852011,
      "h": 8590786603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786603)
  ],
  "h": 852011
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.SymDocumentType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}SymDocumentType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852011)
        
        

        //--TRIMMABLE-BOUNDARY-START(983083)
        $asm.$cls(`$sds.SDS.SymLanguageVendor`, ($self) => class SymLanguageVendor extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885884971)
            /*Guid*/ static Microsoft;
            //--TRIMMABLE-BOUNDARY-END(12885884971)
            
            //--TRIMMABLE-BOUNDARY-START(8590917675)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917675)
            
            //--TRIMMABLE-BOUNDARY-START(8590917675)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917675)
            
            //--TRIMMABLE-BOUNDARY-START(4295950379)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(12885884971)
                    this.Microsoft = new $.$$.S.Guid().$ctor$4((2571847108 | 0), ((59113 & 0xFFFF) | 0), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(12885884971)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950379)
            
            static $h = 983083;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884971),
    {
      "t": 89784321,
      "n": "Microsoft",
      "d": 983083,
      "h": 12885884971,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885884971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917675),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983083,
      "h": 8590917675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917675)
  ],
  "h": 983083
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}SymLanguageVendor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983083)
        
        

        //--TRIMMABLE-BOUNDARY-START(65579)
        $asm.$cls(`$sds.SD.StackTraceSymbols`, ($self) => class StackTraceSymbols extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032875)
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295032875)
            
            //--TRIMMABLE-BOUNDARY-START(8590000171)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._metadataCache = new ($.$$.SRC.ConditionalWeakTable$$$($.$$.SR.Assembly, $.$srm.SRM.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000171)
            
            //--TRIMMABLE-BOUNDARY-START(17179934763)
            /*void */ S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en1 = this._metadataCache.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let $t2 = $en1.SCG$IEnumerator$$$Current;
                    /*MetadataReaderProvider?*/ let provider = $t2.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934763)
            
            //--TRIMMABLE-BOUNDARY-START(12884967467)
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.SRME.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.SRM.MethodDefinitionHandle.op_Explicit$1(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            let $en3 = sequencePoints.GetEnumerator();
                            while ($en3.MoveNext())
                            {
                                let point = $en3.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$$.S.Nullable$$($.$srm.SRM.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$$.S.Nullable$$($.$srm.SRM.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$$.S.Nullable$$($.$srm.SRM.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString(reader.GetDocument($.$$.S.Nullable$$($.$srm.SRM.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967467)
            
            //--TRIMMABLE-BOUNDARY-START(25769869355)
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (loadedPeAddress === $.$$.S.IntPtr.Zero && assemblyPath === null && inMemoryPdbAddress === $.$$.S.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.SRM.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$$.S.IntPtr.Zero ? $.$sds.SD.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.SD.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869355)
            
            //--TRIMMABLE-BOUNDARY-START(34359803947)
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(inMemoryPdbAddress !== $.$$.S.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < 4 || $.$$.$interop.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.SRM.MetadataReaderProvider.FromMetadataImage($.$$.$interop.$addr2Ptr(inMemoryPdbAddress, null), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803947)
            
            //--TRIMMABLE-BOUNDARY-START(21474902059)
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (loadedPeAddress !== $.$$.S.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.SRP.PEReader().$ctor$1($.$$.$interop.$addr2Ptr(loadedPeAddress, null), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.SD.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.SRP.PEReader().$ctor$6(peStream);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902059)
            
            //--TRIMMABLE-BOUNDARY-START(38654771243)
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let peReader = null;
                try
                {
                    peReader = $.$sds.SD.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$$.S.Func$$$($.$$.S.String, $.$$.SI.Stream))().$ctor($.$sds.SD.StackTraceSymbols, $.$sds.SD.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.SRM.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$$.S.String)))
                        {
                            return provider;
                        }
                    }
                    let $en7 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en7.MoveNext())
                    {
                        let entry = $en7.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.S$IDisposable$Dispose();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771243)
            
            //--TRIMMABLE-BOUNDARY-START(30064836651)
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.SI.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$$.SI.FileStream().$ctor$14(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836651)
            
            //--TRIMMABLE-BOUNDARY-START(8590000171)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000171)
            
            static $h = 65579;
            static $f = 0b10010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967467),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        },
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        },
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        },
        {
          "n": "methodToken",
          "p": 655361
        },
        {
          "n": "ilOffset",
          "p": 655361
        },
        {
          "n": "sourceFile",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "sourceLine",
          "p": 655361,
          "f": 2
        },
        {
          "n": "sourceColumn",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetSourceLineInfo",
      "d": 65579,
      "h": 12884967467,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12884967467),
//--TRIMMABLE-BOUNDARY-START(25769869355),
    {
      "r": 24576067,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        },
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        },
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        }
      ],
      "n": "TryGetReader",
      "d": 65579,
      "h": 25769869355,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25769869355),
//--TRIMMABLE-BOUNDARY-START(34359803947),
    {
      "r": 24772675,
      "p": [
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        }
      ],
      "n": "TryOpenReaderForInMemoryPdb",
      "d": 65579,
      "h": 34359803947,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359803947),
//--TRIMMABLE-BOUNDARY-START(21474902059),
    {
      "r": 31588419,
      "p": [
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        }
      ],
      "n": "TryGetPEReader",
      "d": 65579,
      "h": 21474902059,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474902059),
//--TRIMMABLE-BOUNDARY-START(38654771243),
    {
      "r": 24772675,
      "p": [
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        }
      ],
      "n": "TryOpenReaderFromAssemblyFile",
      "d": 65579,
      "h": 38654771243,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654771243),
//--TRIMMABLE-BOUNDARY-START(30064836651),
    {
      "r": 95748097,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "TryOpenFile",
      "d": 65579,
      "h": 30064836651,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064836651)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032875),
    {
      "t": $.$$.SRC.ConditionalWeakTable$$$($.$$.SR.Assembly, $.$srm.SRM.MetadataReaderProvider).$h,
      "n": "_metadataCache",
      "d": 65579,
      "h": 4295032875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000171),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65579,
      "h": 8590000171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000171)
  ],
  "h": 65579
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.StackTraceSymbols`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}StackTraceSymbols`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65579)
        
        

        //--TRIMMABLE-BOUNDARY-START(786475)
        $asm.$str(`$sds.SDS.SymbolToken`, ($self) => class SymbolToken extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295753771)
            /*int*/ _token = 0;
            //--TRIMMABLE-BOUNDARY-END(4295753771)
            
            //--TRIMMABLE-BOUNDARY-START(12885688363)
            $ctor$3(/*int*/ val)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._token = val;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688363)
            
            //--TRIMMABLE-BOUNDARY-START(30065557547)
            /*int */ GetToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._token;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557547)
            
            //--TRIMMABLE-BOUNDARY-START(25770590251)
            /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590251);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._token;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590251)
            
            //--TRIMMABLE-BOUNDARY-START(17180655659)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(obj, $.$sds.SDS.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.SDS.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180655659)
            
            //--TRIMMABLE-BOUNDARY-START(21475622955)
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475622955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return obj._token === this._token;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475622955)
            
            //--TRIMMABLE-BOUNDARY-START(34360524843)
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360524843);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return a.Equals$2(b);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524843)
            
            //--TRIMMABLE-BOUNDARY-START(38655492139)
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492139);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return !($.$sds.SDS.SymbolToken.op_Equality(a, b));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655492139)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            S$IEquatable$System$Diagnostics$SymbolStore$SymbolToken$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(8590721067)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590721067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721067)
            
            //--TRIMMABLE-BOUNDARY-START(8590721067)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(8590721067)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            static $h = 786475;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065557547),
    {
      "r": 655361,
      "n": "GetToken",
      "d": 786475,
      "h": 30065557547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557547),
//--TRIMMABLE-BOUNDARY-START(25770590251),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 786475,
      "h": 25770590251,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770590251),
//--TRIMMABLE-BOUNDARY-START(17180655659),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 786475,
      "h": 17180655659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180655659),
//--TRIMMABLE-BOUNDARY-START(21475622955),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 786475
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 786475,
      "h": 21475622955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622955)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753771),
    {
      "t": 655361,
      "n": "_token",
      "d": 786475,
      "h": 4295753771,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688363),
    {
      "p": [
        {
          "n": "val",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786475,
      "h": 12885688363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688363),
//--TRIMMABLE-BOUNDARY-START(8590721067),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786475,
      "h": 8590721067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721067)
  ],
  "h": 786475
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$sds.SDS.SymbolToken) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.SymbolToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}SymbolToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786475)
        
        

        //--TRIMMABLE-BOUNDARY-START(720939)
        $asm.$str(`$sds.SDS.SymAddressKind`, ($self) => class SymAddressKind extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688235)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688235)
            
            //--TRIMMABLE-BOUNDARY-START(4295688235)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688235)
            
            static $h = 720939;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622827),
    {
      "t": 720939,
      "n": "ILOffset",
      "d": 720939,
      "h": 12885622827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622827),
//--TRIMMABLE-BOUNDARY-START(38655426603),
    {
      "t": 720939,
      "n": "NativeRVA",
      "d": 720939,
      "h": 38655426603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426603),
//--TRIMMABLE-BOUNDARY-START(21475557419),
    {
      "t": 720939,
      "n": "NativeRegister",
      "d": 720939,
      "h": 21475557419,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557419),
//--TRIMMABLE-BOUNDARY-START(30065492011),
    {
      "t": 720939,
      "n": "NativeRegisterRelative",
      "d": 720939,
      "h": 30065492011,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492011),
//--TRIMMABLE-BOUNDARY-START(17180590123),
    {
      "t": 720939,
      "n": "NativeOffset",
      "d": 720939,
      "h": 17180590123,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590123),
//--TRIMMABLE-BOUNDARY-START(25770524715),
    {
      "t": 720939,
      "n": "NativeRegisterRegister",
      "d": 720939,
      "h": 25770524715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524715),
//--TRIMMABLE-BOUNDARY-START(34360459307),
    {
      "t": 720939,
      "n": "NativeRegisterStack",
      "d": 720939,
      "h": 34360459307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459307),
//--TRIMMABLE-BOUNDARY-START(47245361195),
    {
      "t": 720939,
      "n": "NativeStackRegister",
      "d": 720939,
      "h": 47245361195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361195),
//--TRIMMABLE-BOUNDARY-START(8590655531),
    {
      "t": 720939,
      "n": "BitField",
      "d": 720939,
      "h": 8590655531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655531),
//--TRIMMABLE-BOUNDARY-START(42950393899),
    {
      "t": 720939,
      "n": "NativeSectionOffset",
      "d": 720939,
      "h": 42950393899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950393899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688235),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720939,
      "h": 4295688235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688235)
  ],
  "h": 720939
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SymbolStore.SymAddressKind`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SymbolStore${separator}SymAddressKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720939)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"));
})();
//--TRIMMABLE-BOUNDARY-END(43)
