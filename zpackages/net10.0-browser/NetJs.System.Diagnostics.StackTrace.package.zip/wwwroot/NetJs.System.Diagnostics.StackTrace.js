
//--TRIMMABLE-BOUNDARY-START(43)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {
  "h": 43,
  "f": "System.Diagnostics.StackTrace",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.StackTrace",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.StackTrace",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131115)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 131115;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098411),
    {
      "r": 458795,
      "p": [
        {
          "n": "importer",
          "p": 655361
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "searchPath",
          "p": 1310721
        }
      ],
      "n": "GetReader",
      "o": "System$Diagnostics$SymbolStore$ISymbolBinder$GetReader",
      "d": 131115,
      "h": 4295098411,
      "f": 16777473,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295098411)
  ],
  "h": 131115
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131115)
        
        
        //--TRIMMABLE-BOUNDARY-START(458795)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 458795;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540066347),
    {
      "p": 786475,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590393387,
        "f": 50331905
      },
      "n": "UserEntryPoint",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint",
      "d": 458795,
      "h": 51540066347,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(51540066347)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885360683),
    {
      "r": 262187,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "language",
          "p": 88997889
        },
        {
          "n": "languageVendor",
          "p": 88997889
        },
        {
          "n": "documentType",
          "p": 88997889
        }
      ],
      "n": "GetDocument",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetDocument",
      "d": 458795,
      "h": 12885360683,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885360683),
//--TRIMMABLE-BOUNDARY-START(17180327979),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h,
      "n": "GetDocuments",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments",
      "d": 458795,
      "h": 17180327979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180327979),
//--TRIMMABLE-BOUNDARY-START(30065229867),
    {
      "r": 327723,
      "p": [
        {
          "n": "method",
          "p": 786475
        }
      ],
      "n": "GetMethod",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1",
      "d": 458795,
      "h": 30065229867,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065229867),
//--TRIMMABLE-BOUNDARY-START(25770262571),
    {
      "r": 327723,
      "p": [
        {
          "n": "method",
          "p": 786475
        },
        {
          "n": "version",
          "p": 655361
        }
      ],
      "n": "GetMethod",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetMethod",
      "d": 458795,
      "h": 25770262571,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770262571),
//--TRIMMABLE-BOUNDARY-START(47245099051),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,
      "p": [
        {
          "n": "parent",
          "p": 786475
        }
      ],
      "n": "GetVariables",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetVariables",
      "d": 458795,
      "h": 47245099051,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245099051),
//--TRIMMABLE-BOUNDARY-START(21475295275),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,
      "n": "GetGlobalVariables",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables",
      "d": 458795,
      "h": 21475295275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475295275),
//--TRIMMABLE-BOUNDARY-START(34360197163),
    {
      "r": 327723,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetMethodFromDocumentPosition",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition",
      "d": 458795,
      "h": 34360197163,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360197163),
//--TRIMMABLE-BOUNDARY-START(42950131755),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "GetSymAttribute",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute",
      "d": 458795,
      "h": 42950131755,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950131755),
//--TRIMMABLE-BOUNDARY-START(38655164459),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces",
      "d": 458795,
      "h": 38655164459,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655164459)
  ],
  "h": 458795
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458795)
        
        
        //--TRIMMABLE-BOUNDARY-START(262187)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 262187;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079477291),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706219,
        "f": 50331905
      },
      "n": "URL",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$URL",
      "d": 262187,
      "h": 103079477291,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103079477291),
//--TRIMMABLE-BOUNDARY-START(8590196779),
    {
      "p": 88997889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033259,
        "f": 50331905
      },
      "n": "DocumentType",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType",
      "d": 262187,
      "h": 8590196779,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590196779),
//--TRIMMABLE-BOUNDARY-START(90194575403),
    {
      "p": 88997889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902443,
        "f": 50331905
      },
      "n": "Language",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$Language",
      "d": 262187,
      "h": 90194575403,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90194575403),
//--TRIMMABLE-BOUNDARY-START(94489542699),
    {
      "p": 88997889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837035,
        "f": 50331905
      },
      "n": "LanguageVendor",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor",
      "d": 262187,
      "h": 94489542699,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94489542699),
//--TRIMMABLE-BOUNDARY-START(4295229483),
    {
      "p": 88997889,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098667,
        "f": 50331905
      },
      "n": "CheckSumAlgorithmId",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId",
      "d": 262187,
      "h": 4295229483,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295229483),
//--TRIMMABLE-BOUNDARY-START(85899608107),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967851,
        "f": 50331905
      },
      "n": "HasEmbeddedSource",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource",
      "d": 262187,
      "h": 85899608107,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85899608107),
//--TRIMMABLE-BOUNDARY-START(98784509995),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771627,
        "f": 50331905
      },
      "n": "SourceLength",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength",
      "d": 262187,
      "h": 98784509995,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98784509995)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77309673515),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "n": "GetCheckSum",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum",
      "d": 262187,
      "h": 77309673515,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77309673515),
//--TRIMMABLE-BOUNDARY-START(12885164075),
    {
      "r": 655361,
      "p": [
        {
          "n": "line",
          "p": 655361
        }
      ],
      "n": "FindClosestLine",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine",
      "d": 262187,
      "h": 12885164075,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885164075),
//--TRIMMABLE-BOUNDARY-START(81604640811),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "startLine",
          "p": 655361
        },
        {
          "n": "startColumn",
          "p": 655361
        },
        {
          "n": "endLine",
          "p": 655361
        },
        {
          "n": "endColumn",
          "p": 655361
        }
      ],
      "n": "GetSourceRange",
      "o": "System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange",
      "d": 262187,
      "h": 81604640811,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81604640811)
  ],
  "h": 262187
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262187)
        
        
        //--TRIMMABLE-BOUNDARY-START(655403)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 655403;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245295659),
    {
      "r": 65537,
      "p": [
        {
          "n": "emitter",
          "p": 786433
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "fFullBuild",
          "p": 262145
        }
      ],
      "n": "Initialize",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$Initialize",
      "d": 655403,
      "h": 47245295659,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245295659),
//--TRIMMABLE-BOUNDARY-START(21475491883),
    {
      "r": 71499777,
      "p": [
        {
          "n": "url",
          "p": 1310721
        },
        {
          "n": "language",
          "p": 88997889
        },
        {
          "n": "languageVendor",
          "p": 88997889
        },
        {
          "n": "documentType",
          "p": 88997889
        }
      ],
      "n": "DefineDocument",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument",
      "d": 655403,
      "h": 21475491883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(21475491883),
//--TRIMMABLE-BOUNDARY-START(81605034027),
    {
      "r": 65537,
      "p": [
        {
          "n": "entryMethod",
          "p": 786475
        }
      ],
      "n": "SetUserEntryPoint",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint",
      "d": 655403,
      "h": 81605034027,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(81605034027),
//--TRIMMABLE-BOUNDARY-START(51540262955),
    {
      "r": 65537,
      "p": [
        {
          "n": "method",
          "p": 786475
        }
      ],
      "n": "OpenMethod",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod",
      "d": 655403,
      "h": 51540262955,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540262955),
//--TRIMMABLE-BOUNDARY-START(8590589995),
    {
      "r": 65537,
      "n": "CloseMethod",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod",
      "d": 655403,
      "h": 8590589995,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590589995),
//--TRIMMABLE-BOUNDARY-START(42950328363),
    {
      "r": 65537,
      "p": [
        {
          "n": "document",
          "p": 71499777
        },
        {
          "n": "offsets",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "endLines",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "endColumns",
          "p": $.$typeArray($.$$.System.Int32).$h
        }
      ],
      "n": "DefineSequencePoints",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints",
      "d": 655403,
      "h": 42950328363,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950328363),
//--TRIMMABLE-BOUNDARY-START(60130197547),
    {
      "r": 655361,
      "p": [
        {
          "n": "startOffset",
          "p": 655361
        }
      ],
      "n": "OpenScope",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope",
      "d": 655403,
      "h": 60130197547,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(60130197547),
//--TRIMMABLE-BOUNDARY-START(17180524587),
    {
      "r": 65537,
      "p": [
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "CloseScope",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope",
      "d": 655403,
      "h": 17180524587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180524587),
//--TRIMMABLE-BOUNDARY-START(68720132139),
    {
      "r": 65537,
      "p": [
        {
          "n": "scopeID",
          "p": 655361
        },
        {
          "n": "startOffset",
          "p": 655361
        },
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "SetScopeRange",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange",
      "d": 655403,
      "h": 68720132139,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(68720132139),
//--TRIMMABLE-BOUNDARY-START(34360393771),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 113836033
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        },
        {
          "n": "startOffset",
          "p": 655361
        },
        {
          "n": "endOffset",
          "p": 655361
        }
      ],
      "n": "DefineLocalVariable",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable",
      "d": 655403,
      "h": 34360393771,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360393771),
//--TRIMMABLE-BOUNDARY-START(38655361067),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 118292481
        },
        {
          "n": "sequence",
          "p": 655361
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineParameter",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter",
      "d": 655403,
      "h": 38655361067,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655361067),
//--TRIMMABLE-BOUNDARY-START(25770459179),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 113836033
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineField",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineField",
      "d": 655403,
      "h": 25770459179,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(25770459179),
//--TRIMMABLE-BOUNDARY-START(30065426475),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "attributes",
          "p": 113836033
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "addrKind",
          "p": 720939
        },
        {
          "n": "addr1",
          "p": 655361
        },
        {
          "n": "addr2",
          "p": 655361
        },
        {
          "n": "addr3",
          "p": 655361
        }
      ],
      "n": "DefineGlobalVariable",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable",
      "d": 655403,
      "h": 30065426475,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065426475),
//--TRIMMABLE-BOUNDARY-START(4295622699),
    {
      "r": 65537,
      "n": "Close",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$Close",
      "d": 655403,
      "h": 4295622699,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295622699),
//--TRIMMABLE-BOUNDARY-START(73015099435),
    {
      "r": 65537,
      "p": [
        {
          "n": "parent",
          "p": 786475
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": "SetSymAttribute",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute",
      "d": 655403,
      "h": 73015099435,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(73015099435),
//--TRIMMABLE-BOUNDARY-START(55835230251),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "OpenNamespace",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace",
      "d": 655403,
      "h": 55835230251,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55835230251),
//--TRIMMABLE-BOUNDARY-START(12885557291),
    {
      "r": 65537,
      "n": "CloseNamespace",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace",
      "d": 655403,
      "h": 12885557291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885557291),
//--TRIMMABLE-BOUNDARY-START(85900001323),
    {
      "r": 65537,
      "p": [
        {
          "n": "fullName",
          "p": 1310721
        }
      ],
      "n": "UsingNamespace",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace",
      "d": 655403,
      "h": 85900001323,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(85900001323),
//--TRIMMABLE-BOUNDARY-START(64425164843),
    {
      "r": 65537,
      "p": [
        {
          "n": "startDoc",
          "p": 71499777
        },
        {
          "n": "startLine",
          "p": 655361
        },
        {
          "n": "startColumn",
          "p": 655361
        },
        {
          "n": "endDoc",
          "p": 71499777
        },
        {
          "n": "endLine",
          "p": 655361
        },
        {
          "n": "endColumn",
          "p": 655361
        }
      ],
      "n": "SetMethodSourceRange",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange",
      "d": 655403,
      "h": 64425164843,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(64425164843),
//--TRIMMABLE-BOUNDARY-START(77310066731),
    {
      "r": 65537,
      "p": [
        {
          "n": "underlyingWriter",
          "p": 786433
        }
      ],
      "n": "SetUnderlyingWriter",
      "o": "System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter",
      "d": 655403,
      "h": 77310066731,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(77310066731)
  ],
  "h": 655403
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655403)
        
        
        //--TRIMMABLE-BOUNDARY-START(524331)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 524331;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55835099179),
    {
      "p": 327723,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360811,
        "f": 50331905
      },
      "n": "Method",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$Method",
      "d": 524331,
      "h": 55835099179,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(55835099179),
//--TRIMMABLE-BOUNDARY-START(60130066475),
    {
      "p": 524331,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295403,
        "f": 50331905
      },
      "n": "Parent",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$Parent",
      "d": 524331,
      "h": 60130066475,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60130066475),
//--TRIMMABLE-BOUNDARY-START(64425033771),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655229995,
        "f": 50331905
      },
      "n": "StartOffset",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$StartOffset",
      "d": 524331,
      "h": 64425033771,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64425033771),
//--TRIMMABLE-BOUNDARY-START(4295491627),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885426219,
        "f": 50331905
      },
      "n": "EndOffset",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$EndOffset",
      "d": 524331,
      "h": 4295491627,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295491627)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950197291),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolScope).$h,
      "n": "GetChildren",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$GetChildren",
      "d": 524331,
      "h": 42950197291,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950197291),
//--TRIMMABLE-BOUNDARY-START(47245164587),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,
      "n": "GetLocals",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$GetLocals",
      "d": 524331,
      "h": 47245164587,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47245164587),
//--TRIMMABLE-BOUNDARY-START(51540131883),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces",
      "d": 524331,
      "h": 51540131883,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51540131883)
  ],
  "h": 524331
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524331)
        
        
        //--TRIMMABLE-BOUNDARY-START(327723)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 327723;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68719804459),
    {
      "p": 786475,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131499,
        "f": 50331905
      },
      "n": "Token",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$Token",
      "d": 327723,
      "h": 68719804459,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68719804459),
//--TRIMMABLE-BOUNDARY-START(64424837163),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180196907,
        "f": 50331905
      },
      "n": "SequencePointCount",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount",
      "d": 327723,
      "h": 64424837163,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64424837163),
//--TRIMMABLE-BOUNDARY-START(60129869867),
    {
      "p": 524331,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590262315,
        "f": 50331905
      },
      "n": "RootScope",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$RootScope",
      "d": 327723,
      "h": 60129869867,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60129869867)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51539935275),
    {
      "r": 65537,
      "p": [
        {
          "n": "offsets",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "documents",
          "p": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "endLines",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "endColumns",
          "p": $.$typeArray($.$$.System.Int32).$h
        }
      ],
      "n": "GetSequencePoints",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints",
      "d": 327723,
      "h": 51539935275,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(51539935275),
//--TRIMMABLE-BOUNDARY-START(47244967979),
    {
      "r": 524331,
      "p": [
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "GetScope",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetScope",
      "d": 327723,
      "h": 47244967979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(47244967979),
//--TRIMMABLE-BOUNDARY-START(34360066091),
    {
      "r": 655361,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetOffset",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset",
      "d": 327723,
      "h": 34360066091,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360066091),
//--TRIMMABLE-BOUNDARY-START(42950000683),
    {
      "r": $.$typeArray($.$$.System.Int32).$h,
      "p": [
        {
          "n": "document",
          "p": 262187
        },
        {
          "n": "line",
          "p": 655361
        },
        {
          "n": "column",
          "p": 655361
        }
      ],
      "n": "GetRanges",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges",
      "d": 327723,
      "h": 42950000683,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950000683),
//--TRIMMABLE-BOUNDARY-START(38655033387),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,
      "n": "GetParameters",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters",
      "d": 327723,
      "h": 38655033387,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(38655033387),
//--TRIMMABLE-BOUNDARY-START(30065098795),
    {
      "r": 393259,
      "n": "GetNamespace",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace",
      "d": 327723,
      "h": 30065098795,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(30065098795),
//--TRIMMABLE-BOUNDARY-START(55834902571),
    {
      "r": 262145,
      "p": [
        {
          "n": "docs",
          "p": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h
        },
        {
          "n": "lines",
          "p": $.$typeArray($.$$.System.Int32).$h
        },
        {
          "n": "columns",
          "p": $.$typeArray($.$$.System.Int32).$h
        }
      ],
      "n": "GetSourceStartEnd",
      "o": "System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd",
      "d": 327723,
      "h": 55834902571,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(55834902571)
  ],
  "h": 327723
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327723)
        
        
        //--TRIMMABLE-BOUNDARY-START(393259)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 393259;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475229739),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 8590327851,
        "f": 50331905
      },
      "n": "Name",
      "o": "System$Diagnostics$SymbolStore$ISymbolNamespace$Name",
      "d": 393259,
      "h": 21475229739,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475229739)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885295147),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,
      "n": "GetNamespaces",
      "o": "System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces",
      "d": 393259,
      "h": 12885295147,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885295147),
//--TRIMMABLE-BOUNDARY-START(17180262443),
    {
      "r": $.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,
      "n": "GetVariables",
      "o": "System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables",
      "d": 393259,
      "h": 17180262443,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(17180262443)
  ],
  "h": 393259
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393259)
        
        
        //--TRIMMABLE-BOUNDARY-START(589867)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 589867;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103079804971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899935787,
        "f": 50331905
      },
      "n": "Name",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$Name",
      "d": 589867,
      "h": 103079804971,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(103079804971),
//--TRIMMABLE-BOUNDARY-START(21475426347),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066603,
        "f": 50331905
      },
      "n": "Attributes",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$Attributes",
      "d": 589867,
      "h": 21475426347,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475426347),
//--TRIMMABLE-BOUNDARY-START(17180459051),
    {
      "p": 720939,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130132011,
        "f": 50331905
      },
      "n": "AddressKind",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind",
      "d": 589867,
      "h": 17180459051,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180459051),
//--TRIMMABLE-BOUNDARY-START(4295557163),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328235,
        "f": 50331905
      },
      "n": "AddressField1",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1",
      "d": 589867,
      "h": 4295557163,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(4295557163),
//--TRIMMABLE-BOUNDARY-START(8590524459),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262827,
        "f": 50331905
      },
      "n": "AddressField2",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2",
      "d": 589867,
      "h": 8590524459,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590524459),
//--TRIMMABLE-BOUNDARY-START(12885491755),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197419,
        "f": 50331905
      },
      "n": "AddressField3",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3",
      "d": 589867,
      "h": 12885491755,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885491755),
//--TRIMMABLE-BOUNDARY-START(107374772267),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489870379,
        "f": 50331905
      },
      "n": "StartOffset",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset",
      "d": 589867,
      "h": 107374772267,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(107374772267),
//--TRIMMABLE-BOUNDARY-START(25770393643),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310001195,
        "f": 50331905
      },
      "n": "EndOffset",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset",
      "d": 589867,
      "h": 25770393643,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770393643)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98784837675),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "n": "GetSignature",
      "o": "System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature",
      "d": 589867,
      "h": 98784837675,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(98784837675)
  ],
  "h": 589867
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589867)
        
        
        //--TRIMMABLE-BOUNDARY-START(196651)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 196651;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295163947),
    {
      "r": 458795,
      "p": [
        {
          "n": "importer",
          "p": 786433
        },
        {
          "n": "filename",
          "p": 1310721
        },
        {
          "n": "searchPath",
          "p": 1310721
        }
      ],
      "n": "GetReader",
      "o": "System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader",
      "d": 196651,
      "h": 4295163947,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295163947)
  ],
  "h": 196651
}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196651)
        
        
        //--TRIMMABLE-BOUNDARY-START(917547)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(17180786731)
            /*Guid*/ static C;
            //--TRIMMABLE-BOUNDARY-END(17180786731)
            
            //--TRIMMABLE-BOUNDARY-START(25770721323)
            /*Guid*/ static CPlusPlus;
            //--TRIMMABLE-BOUNDARY-END(25770721323)
            
            //--TRIMMABLE-BOUNDARY-START(30065688619)
            /*Guid*/ static CSharp;
            //--TRIMMABLE-BOUNDARY-END(30065688619)
            
            //--TRIMMABLE-BOUNDARY-START(12885819435)
            /*Guid*/ static Basic;
            //--TRIMMABLE-BOUNDARY-END(12885819435)
            
            //--TRIMMABLE-BOUNDARY-START(38655623211)
            /*Guid*/ static Java;
            //--TRIMMABLE-BOUNDARY-END(38655623211)
            
            //--TRIMMABLE-BOUNDARY-START(21475754027)
            /*Guid*/ static Cobol;
            //--TRIMMABLE-BOUNDARY-END(21475754027)
            
            //--TRIMMABLE-BOUNDARY-START(51540525099)
            /*Guid*/ static Pascal;
            //--TRIMMABLE-BOUNDARY-END(51540525099)
            
            //--TRIMMABLE-BOUNDARY-START(34360655915)
            /*Guid*/ static ILAssembly;
            //--TRIMMABLE-BOUNDARY-END(34360655915)
            
            //--TRIMMABLE-BOUNDARY-START(42950590507)
            /*Guid*/ static JScript;
            //--TRIMMABLE-BOUNDARY-END(42950590507)
            
            //--TRIMMABLE-BOUNDARY-START(55835492395)
            /*Guid*/ static SMC;
            //--TRIMMABLE-BOUNDARY-END(55835492395)
            
            //--TRIMMABLE-BOUNDARY-START(47245557803)
            /*Guid*/ static MCPlusPlus;
            //--TRIMMABLE-BOUNDARY-END(47245557803)
            
            //--TRIMMABLE-BOUNDARY-START(8590852139)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590852139)
            
            //--TRIMMABLE-BOUNDARY-START(4295884843)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180786731)
                    this.C = new $.$$.System.Guid().$ctor$4(1671464724, $.$cast(64567, $.$$.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(17180786731)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770721323)
                    this.CPlusPlus = new $.$$.System.Guid().$ctor$4(974311607, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(25770721323)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065688619)
                    this.CSharp = new $.$$.System.Guid().$ctor$4(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(30065688619)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885819435)
                    this.Basic = new $.$$.System.Guid().$ctor$4(974311608, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(12885819435)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655623211)
                    this.Java = new $.$$.System.Guid().$ctor$4(974311604, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(38655623211)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475754027)
                    this.Cobol = new $.$$.System.Guid().$ctor$4((2936302801 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(21475754027)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540525099)
                    this.Pascal = new $.$$.System.Guid().$ctor$4((2936302802 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(51540525099)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360655915)
                    this.ILAssembly = new $.$$.System.Guid().$ctor$4((2936302803 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                    //--TRIMMABLE-BOUNDARY-END(34360655915)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950590507)
                    this.JScript = new $.$$.System.Guid().$ctor$4(974311606, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                    //--TRIMMABLE-BOUNDARY-END(42950590507)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492395)
                    this.SMC = new $.$$.System.Guid().$ctor$4(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                    //--TRIMMABLE-BOUNDARY-END(55835492395)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557803)
                    this.MCPlusPlus = new $.$$.System.Guid().$ctor$4(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(47245557803)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295884843)
            
            static $h = 917547;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180786731),
    {
      "t": 88997889,
      "n": "C",
      "d": 917547,
      "h": 17180786731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180786731),
//--TRIMMABLE-BOUNDARY-START(25770721323),
    {
      "t": 88997889,
      "n": "CPlusPlus",
      "d": 917547,
      "h": 25770721323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770721323),
//--TRIMMABLE-BOUNDARY-START(30065688619),
    {
      "t": 88997889,
      "n": "CSharp",
      "d": 917547,
      "h": 30065688619,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065688619),
//--TRIMMABLE-BOUNDARY-START(12885819435),
    {
      "t": 88997889,
      "n": "Basic",
      "d": 917547,
      "h": 12885819435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885819435),
//--TRIMMABLE-BOUNDARY-START(38655623211),
    {
      "t": 88997889,
      "n": "Java",
      "d": 917547,
      "h": 38655623211,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655623211),
//--TRIMMABLE-BOUNDARY-START(21475754027),
    {
      "t": 88997889,
      "n": "Cobol",
      "d": 917547,
      "h": 21475754027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475754027),
//--TRIMMABLE-BOUNDARY-START(51540525099),
    {
      "t": 88997889,
      "n": "Pascal",
      "d": 917547,
      "h": 51540525099,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540525099),
//--TRIMMABLE-BOUNDARY-START(34360655915),
    {
      "t": 88997889,
      "n": "ILAssembly",
      "d": 917547,
      "h": 34360655915,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360655915),
//--TRIMMABLE-BOUNDARY-START(42950590507),
    {
      "t": 88997889,
      "n": "JScript",
      "d": 917547,
      "h": 42950590507,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950590507),
//--TRIMMABLE-BOUNDARY-START(55835492395),
    {
      "t": 88997889,
      "n": "SMC",
      "d": 917547,
      "h": 55835492395,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835492395),
//--TRIMMABLE-BOUNDARY-START(47245557803),
    {
      "t": 88997889,
      "n": "MCPlusPlus",
      "d": 917547,
      "h": 47245557803,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245557803)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590852139),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917547,
      "h": 8590852139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590852139)
  ],
  "h": 917547
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917547)
        
        
        //--TRIMMABLE-BOUNDARY-START(852011)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885753899)
            /*Guid*/ static Text;
            //--TRIMMABLE-BOUNDARY-END(12885753899)
            
            //--TRIMMABLE-BOUNDARY-START(8590786603)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590786603)
            
            //--TRIMMABLE-BOUNDARY-START(4295819307)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885753899)
                    this.Text = new $.$$.System.Guid().$ctor$4(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                    //--TRIMMABLE-BOUNDARY-END(12885753899)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819307)
            
            static $h = 852011;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753899),
    {
      "t": 88997889,
      "n": "Text",
      "d": 852011,
      "h": 12885753899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590786603),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852011,
      "h": 8590786603,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590786603)
  ],
  "h": 852011
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852011)
        
        
        //--TRIMMABLE-BOUNDARY-START(983083)
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885884971)
            /*Guid*/ static Microsoft;
            //--TRIMMABLE-BOUNDARY-END(12885884971)
            
            //--TRIMMABLE-BOUNDARY-START(8590917675)
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917675)
            
            //--TRIMMABLE-BOUNDARY-START(4295950379)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885884971)
                    this.Microsoft = new $.$$.System.Guid().$ctor$4((2571847108 | 0), $.$cast(59113, $.$$.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                    //--TRIMMABLE-BOUNDARY-END(12885884971)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295950379)
            
            static $h = 983083;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884971),
    {
      "t": 88997889,
      "n": "Microsoft",
      "d": 983083,
      "h": 12885884971,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885884971)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917675),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983083,
      "h": 8590917675,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917675)
  ],
  "h": 983083
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983083)
        
        
        //--TRIMMABLE-BOUNDARY-START(65579)
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032875)
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295032875)
            
            //--TRIMMABLE-BOUNDARY-START(8590000171)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000171);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._metadataCache = new ($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000171)
            
            //--TRIMMABLE-BOUNDARY-START(17179934763)
            /*void */ System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934763)
            
            //--TRIMMABLE-BOUNDARY-START(12884967467)
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit$1(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString(reader.GetDocument($.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967467)
            
            //--TRIMMABLE-BOUNDARY-START(25769869355)
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (loadedPeAddress === $.$$.System.IntPtr.Zero && $.$$.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$$.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$$.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null) ?? null;
            }
            //--TRIMMABLE-BOUNDARY-END(25769869355)
            
            //--TRIMMABLE-BOUNDARY-START(34359803947)
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(inMemoryPdbAddress !== $.$$.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$$.System.UInt32.$z || $.$$.$interop.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$$.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803947)
            
            //--TRIMMABLE-BOUNDARY-START(21474902059)
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (loadedPeAddress !== $.$$.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$1($.$cast(loadedPeAddress, $.$typePointer($.$$.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$5(peStream);
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902059)
            
            //--TRIMMABLE-BOUNDARY-START(38654771243)
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.IO.Stream))().$ctor($.$sds.System.Diagnostics.StackTraceSymbols, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$$.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771243)
            
            //--TRIMMABLE-BOUNDARY-START(30064836651)
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$$.System.IO.FileStream().$ctor$14(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836651)
            
            static $h = 65579;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967467),
    {
      "r": 65537,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        },
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        },
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        },
        {
          "n": "methodToken",
          "p": 655361
        },
        {
          "n": "ilOffset",
          "p": 655361
        },
        {
          "n": "sourceFile",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "sourceLine",
          "p": 655361,
          "f": 2
        },
        {
          "n": "sourceColumn",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetSourceLineInfo",
      "d": 65579,
      "h": 12884967467,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12884967467),
//--TRIMMABLE-BOUNDARY-START(25769869355),
    {
      "r": 24576067,
      "p": [
        {
          "n": "assembly",
          "p": 106299393
        },
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        },
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        }
      ],
      "n": "TryGetReader",
      "d": 65579,
      "h": 25769869355,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25769869355),
//--TRIMMABLE-BOUNDARY-START(34359803947),
    {
      "r": 24772675,
      "p": [
        {
          "n": "inMemoryPdbAddress",
          "p": 786433
        },
        {
          "n": "inMemoryPdbSize",
          "p": 655361
        }
      ],
      "n": "TryOpenReaderForInMemoryPdb",
      "d": 65579,
      "h": 34359803947,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359803947),
//--TRIMMABLE-BOUNDARY-START(21474902059),
    {
      "r": 31588419,
      "p": [
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        }
      ],
      "n": "TryGetPEReader",
      "d": 65579,
      "h": 21474902059,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21474902059),
//--TRIMMABLE-BOUNDARY-START(38654771243),
    {
      "r": 24772675,
      "p": [
        {
          "n": "assemblyPath",
          "p": 1310721
        },
        {
          "n": "loadedPeAddress",
          "p": 786433
        },
        {
          "n": "loadedPeSize",
          "p": 655361
        },
        {
          "n": "isFileLayout",
          "p": 262145
        }
      ],
      "n": "TryOpenReaderFromAssemblyFile",
      "d": 65579,
      "h": 38654771243,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38654771243),
//--TRIMMABLE-BOUNDARY-START(30064836651),
    {
      "r": 94961665,
      "p": [
        {
          "n": "path",
          "p": 1310721
        }
      ],
      "n": "TryOpenFile",
      "d": 65579,
      "h": 30064836651,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30064836651)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032875),
    {
      "t": $.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,
      "n": "_metadataCache",
      "d": 65579,
      "h": 4295032875,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032875)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000171),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65579,
      "h": 8590000171,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000171)
  ],
  "i": [90308609
  ],
  "h": 65579
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65579)
        
        
        //--TRIMMABLE-BOUNDARY-START(786475)
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295753771)
            /*int*/  get _token() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(4295753771)
            
            //--TRIMMABLE-BOUNDARY-START(12885688363)
            $ctor$3(/*int*/ val)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885688363);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._token = val;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688363)
            
            //--TRIMMABLE-BOUNDARY-START(30065557547)
            /*int */ GetToken()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557547);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._token;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557547)
            
            //--TRIMMABLE-BOUNDARY-START(25770590251)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590251);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._token;
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(25770590251)
            
            //--TRIMMABLE-BOUNDARY-START(17180655659)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(17180655659)
            
            //--TRIMMABLE-BOUNDARY-START(21475622955)
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475622955);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return obj._token === this._token;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475622955)
            
            //--TRIMMABLE-BOUNDARY-START(34360524843)
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                {
                    return a.Equals$2(b);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360524843)
            
            //--TRIMMABLE-BOUNDARY-START(38655492139)
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                {
                    return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655492139)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(8590721067)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721067)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295753771)
                this._token = 0;
                //--TRIMMABLE-BOUNDARY-END(4295753771)
                
            }
            static $h = 786475;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065557547),
    {
      "r": 655361,
      "n": "GetToken",
      "d": 786475,
      "h": 30065557547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065557547),
//--TRIMMABLE-BOUNDARY-START(25770590251),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 786475,
      "h": 25770590251,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770590251),
//--TRIMMABLE-BOUNDARY-START(17180655659),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 786475,
      "h": 17180655659,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180655659),
//--TRIMMABLE-BOUNDARY-START(21475622955),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 786475
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 786475,
      "h": 21475622955,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622955)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753771),
    {
      "t": 655361,
      "n": "_token",
      "d": 786475,
      "h": 4295753771,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753771)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688363),
    {
      "p": [
        {
          "n": "val",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786475,
      "h": 12885688363,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688363),
//--TRIMMABLE-BOUNDARY-START(8590721067),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786475,
      "h": 8590721067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721067)
  ],
  "i": [$.$$.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h
  ],
  "h": 786475
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786475)
        
        
        //--TRIMMABLE-BOUNDARY-START(720939)
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$$.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 720939;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885622827),
    {
      "t": 720939,
      "n": "ILOffset",
      "d": 720939,
      "h": 12885622827,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622827),
//--TRIMMABLE-BOUNDARY-START(38655426603),
    {
      "t": 720939,
      "n": "NativeRVA",
      "d": 720939,
      "h": 38655426603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426603),
//--TRIMMABLE-BOUNDARY-START(21475557419),
    {
      "t": 720939,
      "n": "NativeRegister",
      "d": 720939,
      "h": 21475557419,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557419),
//--TRIMMABLE-BOUNDARY-START(30065492011),
    {
      "t": 720939,
      "n": "NativeRegisterRelative",
      "d": 720939,
      "h": 30065492011,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492011),
//--TRIMMABLE-BOUNDARY-START(17180590123),
    {
      "t": 720939,
      "n": "NativeOffset",
      "d": 720939,
      "h": 17180590123,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590123),
//--TRIMMABLE-BOUNDARY-START(25770524715),
    {
      "t": 720939,
      "n": "NativeRegisterRegister",
      "d": 720939,
      "h": 25770524715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524715),
//--TRIMMABLE-BOUNDARY-START(34360459307),
    {
      "t": 720939,
      "n": "NativeRegisterStack",
      "d": 720939,
      "h": 34360459307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459307),
//--TRIMMABLE-BOUNDARY-START(47245361195),
    {
      "t": 720939,
      "n": "NativeStackRegister",
      "d": 720939,
      "h": 47245361195,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245361195),
//--TRIMMABLE-BOUNDARY-START(8590655531),
    {
      "t": 720939,
      "n": "BitField",
      "d": 720939,
      "h": 8590655531,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590655531),
//--TRIMMABLE-BOUNDARY-START(42950393899),
    {
      "t": 720939,
      "n": "NativeSectionOffset",
      "d": 720939,
      "h": 42950393899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950393899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688235),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720939,
      "h": 4295688235,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688235)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 720939
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720939)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"))
//--TRIMMABLE-BOUNDARY-END(43)
