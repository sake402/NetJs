
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {"h":64090,"f":"System.Diagnostics.StackTrace","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 391770;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":850522,"g":{"r":0,"d":0,"h":8590326362,"f":257},"n":"Token","o":"System$Diagnostics$SymbolStore$ISymbolMethod$Token","d":391770,"h":4295359066,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":17180260954,"f":257},"n":"SequencePointCount","o":"System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount","d":391770,"h":12885293658,"f":257},{"p":588378,"g":{"r":0,"d":0,"h":30065162842,"f":257},"n":"RootScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$RootScope","d":391770,"h":25770195546,"f":257}],"m":[{"r":65537,"p":[{"n":"offsets","p":0},{"n":"documents","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"GetSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints","d":391770,"h":21475228250,"f":257},{"r":588378,"p":[{"n":"offset","p":655361}],"n":"GetScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetScope","d":391770,"h":34360130138,"f":257},{"r":655361,"p":[{"n":"document","p":326234},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetOffset","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset","d":391770,"h":38655097434,"f":257},{"r":0,"p":[{"n":"document","p":326234},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetRanges","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges","d":391770,"h":42950064730,"f":257},{"r":0,"n":"GetParameters","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters","d":391770,"h":47245032026,"f":257},{"r":457306,"n":"GetNamespace","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace","d":391770,"h":51539999322,"f":257},{"r":262145,"p":[{"n":"docs","p":0},{"n":"lines","p":0},{"n":"columns","p":0}],"n":"GetSourceStartEnd","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd","d":391770,"h":55834966618,"f":257}],"h":391770}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 588378;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":391770,"g":{"r":0,"d":0,"h":8590522970,"f":257},"n":"Method","o":"System$Diagnostics$SymbolStore$ISymbolScope$Method","d":588378,"h":4295555674,"f":257},{"p":588378,"g":{"r":0,"d":0,"h":17180457562,"f":257},"n":"Parent","o":"System$Diagnostics$SymbolStore$ISymbolScope$Parent","d":588378,"h":12885490266,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":30065359450,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$StartOffset","d":588378,"h":25770392154,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655294042,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$EndOffset","d":588378,"h":34360326746,"f":257}],"m":[{"r":0,"n":"GetChildren","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetChildren","d":588378,"h":21475424858,"f":257},{"r":0,"n":"GetLocals","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetLocals","d":588378,"h":42950261338,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces","d":588378,"h":47245228634,"f":257}],"h":588378}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 457306;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590391898,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$Name","d":457306,"h":4295424602,"f":257}],"m":[{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces","d":457306,"h":12885359194,"f":257},{"r":0,"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables","d":457306,"h":17180326490,"f":257}],"h":457306}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 719450;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"emitter","p":786433},{"n":"filename","p":1310721},{"n":"fFullBuild","p":262145}],"n":"Initialize","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Initialize","d":719450,"h":4295686746,"f":257},{"r":38731777,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"DefineDocument","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument","d":719450,"h":8590654042,"f":257},{"r":65537,"p":[{"n":"entryMethod","p":850522}],"n":"SetUserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint","d":719450,"h":12885621338,"f":257},{"r":65537,"p":[{"n":"method","p":850522}],"n":"OpenMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod","d":719450,"h":17180588634,"f":257},{"r":65537,"n":"CloseMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod","d":719450,"h":21475555930,"f":257},{"r":65537,"p":[{"n":"document","p":38731777},{"n":"offsets","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"DefineSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints","d":719450,"h":25770523226,"f":257},{"r":655361,"p":[{"n":"startOffset","p":655361}],"n":"OpenScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope","d":719450,"h":30065490522,"f":257},{"r":65537,"p":[{"n":"endOffset","p":655361}],"n":"CloseScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope","d":719450,"h":34360457818,"f":257},{"r":65537,"p":[{"n":"scopeID","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"SetScopeRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange","d":719450,"h":38655425114,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":784986},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"DefineLocalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable","d":719450,"h":42950392410,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":81068033},{"n":"sequence","p":655361},{"n":"addrKind","p":784986},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineParameter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter","d":719450,"h":47245359706,"f":257},{"r":65537,"p":[{"n":"parent","p":850522},{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":784986},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineField","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineField","d":719450,"h":51540327002,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":784986},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineGlobalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable","d":719450,"h":55835294298,"f":257},{"r":65537,"n":"Close","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Close","d":719450,"h":60130261594,"f":257},{"r":65537,"p":[{"n":"parent","p":850522},{"n":"name","p":1310721},{"n":"data","p":0}],"n":"SetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute","d":719450,"h":64425228890,"f":257},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"OpenNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace","d":719450,"h":68720196186,"f":257},{"r":65537,"n":"CloseNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace","d":719450,"h":73015163482,"f":257},{"r":65537,"p":[{"n":"fullName","p":1310721}],"n":"UsingNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace","d":719450,"h":77310130778,"f":257},{"r":65537,"p":[{"n":"startDoc","p":38731777},{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endDoc","p":38731777},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"SetMethodSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange","d":719450,"h":81605098074,"f":257},{"r":65537,"p":[{"n":"underlyingWriter","p":786433}],"n":"SetUnderlyingWriter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter","d":719450,"h":85900065370,"f":257}],"h":719450}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 653914;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590588506,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Name","d":653914,"h":4295621210,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":17180523098,"f":257},"n":"Attributes","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Attributes","d":653914,"h":12885555802,"f":257},{"p":784986,"g":{"r":0,"d":0,"h":30065424986,"f":257},"n":"AddressKind","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind","d":653914,"h":25770457690,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655359578,"f":257},"n":"AddressField1","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1","d":653914,"h":34360392282,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245294170,"f":257},"n":"AddressField2","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2","d":653914,"h":42950326874,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55835228762,"f":257},"n":"AddressField3","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3","d":653914,"h":51540261466,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":64425163354,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset","d":653914,"h":60130196058,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":73015097946,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset","d":653914,"h":68720130650,"f":257}],"m":[{"r":0,"n":"GetSignature","o":"System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature","d":653914,"h":21475490394,"f":257}],"h":653914}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 195162;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":522842,"p":[{"n":"importer","p":655361},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder$GetReader","d":195162,"h":4295162458,"f":257,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.","t":1310721}]}]}],"h":195162}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 522842;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":850522,"g":{"r":0,"d":0,"h":17180392026,"f":257},"n":"UserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint","d":522842,"h":12885424730,"f":257}],"m":[{"r":326234,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"GetDocument","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocument","d":522842,"h":4295490138,"f":257},{"r":0,"n":"GetDocuments","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments","d":522842,"h":8590457434,"f":257},{"r":391770,"p":[{"n":"method","p":850522}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod","d":522842,"h":21475359322,"f":257},{"r":391770,"p":[{"n":"method","p":850522},{"n":"version","p":655361}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1","d":522842,"h":25770326618,"f":257},{"r":0,"p":[{"n":"parent","p":850522}],"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetVariables","d":522842,"h":30065293914,"f":257},{"r":0,"n":"GetGlobalVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables","d":522842,"h":34360261210,"f":257},{"r":391770,"p":[{"n":"document","p":326234},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetMethodFromDocumentPosition","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition","d":522842,"h":38655228506,"f":257},{"r":0,"p":[{"n":"parent","p":850522},{"n":"name","p":1310721}],"n":"GetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute","d":522842,"h":42950195802,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces","d":522842,"h":47245163098,"f":257}],"h":522842}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 260698;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":522842,"p":[{"n":"importer","p":786433},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader","d":260698,"h":4295227994,"f":257}],"h":260698}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 326234;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590260826,"f":257},"n":"URL","o":"System$Diagnostics$SymbolStore$ISymbolDocument$URL","d":326234,"h":4295293530,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":17180195418,"f":257},"n":"DocumentType","o":"System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType","d":326234,"h":12885228122,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":25770130010,"f":257},"n":"Language","o":"System$Diagnostics$SymbolStore$ISymbolDocument$Language","d":326234,"h":21475162714,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":34360064602,"f":257},"n":"LanguageVendor","o":"System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor","d":326234,"h":30065097306,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":42949999194,"f":257},"n":"CheckSumAlgorithmId","o":"System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId","d":326234,"h":38655031898,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":60129868378,"f":257},"n":"HasEmbeddedSource","o":"System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource","d":326234,"h":55834901082,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":68719802970,"f":257},"n":"SourceLength","o":"System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength","d":326234,"h":64424835674,"f":257}],"m":[{"r":0,"n":"GetCheckSum","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum","d":326234,"h":47244966490,"f":257},{"r":655361,"p":[{"n":"line","p":655361}],"n":"FindClosestLine","o":"System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine","d":326234,"h":51539933786,"f":257},{"r":0,"p":[{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"GetSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange","d":326234,"h":73014770266,"f":257}],"h":326234}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$spc.System.Object
        {
            /*Guid*/ static Text;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Text = new $.$spc.System.Guid().$ctor$7(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
            }
            static $h = 916058;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Text","d":916058,"h":4295883354,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":916058,"h":8590850650,"f":1}],"h":916058}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$spc.System.Object
        {
            /*Guid*/ static Microsoft;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Microsoft = new $.$spc.System.Guid().$ctor$7((2571847108 | 0), $.$cast(59113, $.$spc.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 1047130;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Microsoft","d":1047130,"h":4296014426,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1047130,"h":8590981722,"f":1}],"h":1047130}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$spc.System.Object
        {
            /*Guid*/ static C;
            /*Guid*/ static CPlusPlus;
            /*Guid*/ static CSharp;
            /*Guid*/ static Basic;
            /*Guid*/ static Java;
            /*Guid*/ static Cobol;
            /*Guid*/ static Pascal;
            /*Guid*/ static ILAssembly;
            /*Guid*/ static JScript;
            /*Guid*/ static SMC;
            /*Guid*/ static MCPlusPlus;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.C = new $.$spc.System.Guid().$ctor$7(1671464724, $.$cast(64567, $.$spc.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.CPlusPlus = new $.$spc.System.Guid().$ctor$7(974311607, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.CSharp = new $.$spc.System.Guid().$ctor$7(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.Basic = new $.$spc.System.Guid().$ctor$7(974311608, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Java = new $.$spc.System.Guid().$ctor$7(974311604, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Cobol = new $.$spc.System.Guid().$ctor$7((2936302801 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.Pascal = new $.$spc.System.Guid().$ctor$7((2936302802 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.ILAssembly = new $.$spc.System.Guid().$ctor$7((2936302803 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.JScript = new $.$spc.System.Guid().$ctor$7(974311606, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.SMC = new $.$spc.System.Guid().$ctor$7(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
                {
                    this.MCPlusPlus = new $.$spc.System.Guid().$ctor$7(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 981594;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"C","d":981594,"h":4295948890,"f":33},{"t":56229889,"n":"CPlusPlus","d":981594,"h":8590916186,"f":33},{"t":56229889,"n":"CSharp","d":981594,"h":12885883482,"f":33},{"t":56229889,"n":"Basic","d":981594,"h":17180850778,"f":33},{"t":56229889,"n":"Java","d":981594,"h":21475818074,"f":33},{"t":56229889,"n":"Cobol","d":981594,"h":25770785370,"f":33},{"t":56229889,"n":"Pascal","d":981594,"h":30065752666,"f":33},{"t":56229889,"n":"ILAssembly","d":981594,"h":34360719962,"f":33},{"t":56229889,"n":"JScript","d":981594,"h":38655687258,"f":33},{"t":56229889,"n":"SMC","d":981594,"h":42950654554,"f":33},{"t":56229889,"n":"MCPlusPlus","d":981594,"h":47245621850,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":981594,"h":51540589146,"f":1}],"h":981594}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$spc.System.Object
        {
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._metadataCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            /*void */ System$IDisposable$Dispose()
            {
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString$2(reader.GetDocument($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                if (loadedPeAddress === $.$spc.System.IntPtr.Zero && $.$spc.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$spc.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null);
            }
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$spc.System.UInt32.$z || $.$spc.InteropUtility.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$spc.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                if (loadedPeAddress !== $.$spc.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$2($.$cast(loadedPeAddress, $.$typePointer($.$spc.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$3(peStream);
                }
                return null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.IO.Stream))().$ctor($.$sds.System.Diagnostics.StackTraceSymbols, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$spc.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                if (!$.$spc.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$spc.System.IO.FileStream().$ctor$12(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            static $h = 129626;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361},{"n":"methodToken","p":655361},{"n":"ilOffset","p":655361},{"n":"sourceFile","p":1310721,"f":2},{"n":"sourceLine","p":655361,"f":2},{"n":"sourceColumn","p":655361,"f":2}],"n":"GetSourceLineInfo","d":129626,"h":17179998810,"f":8},{"r":24626392,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryGetReader","d":129626,"h":21474966106,"f":2},{"r":24823000,"p":[{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryOpenReaderForInMemoryPdb","d":129626,"h":25769933402,"f":34},{"r":31638744,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryGetPEReader","d":129626,"h":30064900698,"f":34},{"r":24823000,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryOpenReaderFromAssemblyFile","d":129626,"h":34359867994,"f":34},{"r":62193665,"p":[{"n":"path","p":1310721}],"n":"TryOpenFile","d":129626,"h":38654835290,"f":34}],"l":[{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,"n":"_metadataCache","d":129626,"h":4295096922,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":129626,"h":8590064218,"f":1}],"i":[57540609],"h":129626}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$spc.System.ValueType
        {
            /*int*/  get _token() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ val)
            {
                super.$ctor$1();
                {
                    this._token = val;
                }
                return this;
            }
            /*int */ GetToken()
            {
                return this._token;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._token;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                return obj._token === this._token;
            }
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._token = 0;
            }
            static $h = 850522;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetToken","d":850522,"h":12885752410,"f":1},{"r":655361,"n":"GetHashCode","d":850522,"h":17180719706,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":850522,"h":21475687002,"f":32769},{"r":262145,"p":[{"n":"obj","p":850522}],"n":"Equals","o":"@$2","d":850522,"h":25770654298,"f":1}],"l":[{"t":655361,"n":"_token","d":850522,"h":4295817818,"f":2}],"c":[{"p":[{"n":"val","p":655361}],"n":".ctor","o":"$ctor$2","d":850522,"h":8590785114,"f":1},{"n":".ctor","o":"$ctor$3","d":850522,"h":38655556186,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h],"h":850522}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$spc.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 784986;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":784986,"n":"ILOffset","d":784986,"h":4295752282,"f":33},{"t":784986,"n":"NativeRVA","d":784986,"h":8590719578,"f":33},{"t":784986,"n":"NativeRegister","d":784986,"h":12885686874,"f":33},{"t":784986,"n":"NativeRegisterRelative","d":784986,"h":17180654170,"f":33},{"t":784986,"n":"NativeOffset","d":784986,"h":21475621466,"f":33},{"t":784986,"n":"NativeRegisterRegister","d":784986,"h":25770588762,"f":33},{"t":784986,"n":"NativeRegisterStack","d":784986,"h":30065556058,"f":33},{"t":784986,"n":"NativeStackRegister","d":784986,"h":34360523354,"f":33},{"t":784986,"n":"BitField","d":784986,"h":38655490650,"f":33},{"t":784986,"n":"NativeSectionOffset","d":784986,"h":42950457946,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":784986,"h":47245425242,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":784986}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"))