
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {"h":47616,"f":"System.Diagnostics.StackTrace","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 178688;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":506368,"p":[{"n":"importer","p":655361},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder$GetReader","d":178688,"h":4295145984,"f":16777473,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.","t":1310721}]}]}],"h":178688}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 702976;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"emitter","p":786433},{"n":"filename","p":1310721},{"n":"fFullBuild","p":262145}],"n":"Initialize","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Initialize","d":702976,"h":4295670272,"f":16777473},{"r":38731777,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"DefineDocument","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument","d":702976,"h":8590637568,"f":16777473},{"r":65537,"p":[{"n":"entryMethod","p":834048}],"n":"SetUserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint","d":702976,"h":12885604864,"f":16777473},{"r":65537,"p":[{"n":"method","p":834048}],"n":"OpenMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod","d":702976,"h":17180572160,"f":16777473},{"r":65537,"n":"CloseMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod","d":702976,"h":21475539456,"f":16777473},{"r":65537,"p":[{"n":"document","p":38731777},{"n":"offsets","p":$.$typeArray($.$$.System.Int32).$h},{"n":"lines","p":$.$typeArray($.$$.System.Int32).$h},{"n":"columns","p":$.$typeArray($.$$.System.Int32).$h},{"n":"endLines","p":$.$typeArray($.$$.System.Int32).$h},{"n":"endColumns","p":$.$typeArray($.$$.System.Int32).$h}],"n":"DefineSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints","d":702976,"h":25770506752,"f":16777473},{"r":655361,"p":[{"n":"startOffset","p":655361}],"n":"OpenScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope","d":702976,"h":30065474048,"f":16777473},{"r":65537,"p":[{"n":"endOffset","p":655361}],"n":"CloseScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope","d":702976,"h":34360441344,"f":16777473},{"r":65537,"p":[{"n":"scopeID","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"SetScopeRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange","d":702976,"h":38655408640,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":$.$typeArray($.$$.System.Byte).$h},{"n":"addrKind","p":768512},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"DefineLocalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable","d":702976,"h":42950375936,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":81068033},{"n":"sequence","p":655361},{"n":"addrKind","p":768512},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineParameter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter","d":702976,"h":47245343232,"f":16777473},{"r":65537,"p":[{"n":"parent","p":834048},{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":$.$typeArray($.$$.System.Byte).$h},{"n":"addrKind","p":768512},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineField","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineField","d":702976,"h":51540310528,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":$.$typeArray($.$$.System.Byte).$h},{"n":"addrKind","p":768512},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineGlobalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable","d":702976,"h":55835277824,"f":16777473},{"r":65537,"n":"Close","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Close","d":702976,"h":60130245120,"f":16777473},{"r":65537,"p":[{"n":"parent","p":834048},{"n":"name","p":1310721},{"n":"data","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute","d":702976,"h":64425212416,"f":16777473},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"OpenNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace","d":702976,"h":68720179712,"f":16777473},{"r":65537,"n":"CloseNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace","d":702976,"h":73015147008,"f":16777473},{"r":65537,"p":[{"n":"fullName","p":1310721}],"n":"UsingNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace","d":702976,"h":77310114304,"f":16777473},{"r":65537,"p":[{"n":"startDoc","p":38731777},{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endDoc","p":38731777},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"SetMethodSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange","d":702976,"h":81605081600,"f":16777473},{"r":65537,"p":[{"n":"underlyingWriter","p":786433}],"n":"SetUnderlyingWriter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter","d":702976,"h":85900048896,"f":16777473}],"h":702976}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 309760;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590244352,"f":50331905},"n":"URL","o":"System$Diagnostics$SymbolStore$ISymbolDocument$URL","d":309760,"h":4295277056,"f":2097409},{"p":56229889,"g":{"r":0,"d":0,"h":17180178944,"f":50331905},"n":"DocumentType","o":"System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType","d":309760,"h":12885211648,"f":2097409},{"p":56229889,"g":{"r":0,"d":0,"h":25770113536,"f":50331905},"n":"Language","o":"System$Diagnostics$SymbolStore$ISymbolDocument$Language","d":309760,"h":21475146240,"f":2097409},{"p":56229889,"g":{"r":0,"d":0,"h":34360048128,"f":50331905},"n":"LanguageVendor","o":"System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor","d":309760,"h":30065080832,"f":2097409},{"p":56229889,"g":{"r":0,"d":0,"h":42949982720,"f":50331905},"n":"CheckSumAlgorithmId","o":"System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId","d":309760,"h":38655015424,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":60129851904,"f":50331905},"n":"HasEmbeddedSource","o":"System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource","d":309760,"h":55834884608,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":68719786496,"f":50331905},"n":"SourceLength","o":"System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength","d":309760,"h":64424819200,"f":2097409}],"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetCheckSum","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum","d":309760,"h":47244950016,"f":16777473},{"r":655361,"p":[{"n":"line","p":655361}],"n":"FindClosestLine","o":"System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine","d":309760,"h":51539917312,"f":16777473},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"GetSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange","d":309760,"h":73014753792,"f":16777473}],"h":309760}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 571904;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":375296,"g":{"r":0,"d":0,"h":8590506496,"f":50331905},"n":"Method","o":"System$Diagnostics$SymbolStore$ISymbolScope$Method","d":571904,"h":4295539200,"f":2097409},{"p":571904,"g":{"r":0,"d":0,"h":17180441088,"f":50331905},"n":"Parent","o":"System$Diagnostics$SymbolStore$ISymbolScope$Parent","d":571904,"h":12885473792,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":30065342976,"f":50331905},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$StartOffset","d":571904,"h":25770375680,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":38655277568,"f":50331905},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$EndOffset","d":571904,"h":34360310272,"f":2097409}],"m":[{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolScope).$h,"n":"GetChildren","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetChildren","d":571904,"h":21475408384,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,"n":"GetLocals","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetLocals","d":571904,"h":42950244864,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces","d":571904,"h":47245212160,"f":16777473}],"h":571904}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 637440;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590572032,"f":50331905},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Name","d":637440,"h":4295604736,"f":2097409},{"p":131073,"g":{"r":0,"d":0,"h":17180506624,"f":50331905},"n":"Attributes","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Attributes","d":637440,"h":12885539328,"f":2097409},{"p":768512,"g":{"r":0,"d":0,"h":30065408512,"f":50331905},"n":"AddressKind","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind","d":637440,"h":25770441216,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":38655343104,"f":50331905},"n":"AddressField1","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1","d":637440,"h":34360375808,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":47245277696,"f":50331905},"n":"AddressField2","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2","d":637440,"h":42950310400,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":55835212288,"f":50331905},"n":"AddressField3","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3","d":637440,"h":51540244992,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":64425146880,"f":50331905},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset","d":637440,"h":60130179584,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":73015081472,"f":50331905},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset","d":637440,"h":68720114176,"f":2097409}],"m":[{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetSignature","o":"System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature","d":637440,"h":21475473920,"f":16777473}],"h":637440}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 440832;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590375424,"f":50331905},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$Name","d":440832,"h":4295408128,"f":2097409}],"m":[{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces","d":440832,"h":12885342720,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables","d":440832,"h":17180310016,"f":16777473}],"h":440832}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 375296;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":834048,"g":{"r":0,"d":0,"h":8590309888,"f":50331905},"n":"Token","o":"System$Diagnostics$SymbolStore$ISymbolMethod$Token","d":375296,"h":4295342592,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":17180244480,"f":50331905},"n":"SequencePointCount","o":"System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount","d":375296,"h":12885277184,"f":2097409},{"p":571904,"g":{"r":0,"d":0,"h":30065146368,"f":50331905},"n":"RootScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$RootScope","d":375296,"h":25770179072,"f":2097409}],"m":[{"r":65537,"p":[{"n":"offsets","p":$.$typeArray($.$$.System.Int32).$h},{"n":"documents","p":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h},{"n":"lines","p":$.$typeArray($.$$.System.Int32).$h},{"n":"columns","p":$.$typeArray($.$$.System.Int32).$h},{"n":"endLines","p":$.$typeArray($.$$.System.Int32).$h},{"n":"endColumns","p":$.$typeArray($.$$.System.Int32).$h}],"n":"GetSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints","d":375296,"h":21475211776,"f":16777473},{"r":571904,"p":[{"n":"offset","p":655361}],"n":"GetScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetScope","d":375296,"h":34360113664,"f":16777473},{"r":655361,"p":[{"n":"document","p":309760},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetOffset","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset","d":375296,"h":38655080960,"f":16777473},{"r":$.$typeArray($.$$.System.Int32).$h,"p":[{"n":"document","p":309760},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetRanges","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges","d":375296,"h":42950048256,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,"n":"GetParameters","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters","d":375296,"h":47245015552,"f":16777473},{"r":440832,"n":"GetNamespace","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace","d":375296,"h":51539982848,"f":16777473},{"r":262145,"p":[{"n":"docs","p":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h},{"n":"lines","p":$.$typeArray($.$$.System.Int32).$h},{"n":"columns","p":$.$typeArray($.$$.System.Int32).$h}],"n":"GetSourceStartEnd","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd","d":375296,"h":55834950144,"f":16777473}],"h":375296}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 244224;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":506368,"p":[{"n":"importer","p":786433},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader","d":244224,"h":4295211520,"f":16777473}],"h":244224}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 506368;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":834048,"g":{"r":0,"d":0,"h":17180375552,"f":50331905},"n":"UserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint","d":506368,"h":12885408256,"f":2097409}],"m":[{"r":309760,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"GetDocument","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocument","d":506368,"h":4295473664,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolDocument).$h,"n":"GetDocuments","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments","d":506368,"h":8590440960,"f":16777473},{"r":375296,"p":[{"n":"method","p":834048}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1","d":506368,"h":21475342848,"f":16777473},{"r":375296,"p":[{"n":"method","p":834048},{"n":"version","p":655361}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod","d":506368,"h":25770310144,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,"p":[{"n":"parent","p":834048}],"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetVariables","d":506368,"h":30065277440,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolVariable).$h,"n":"GetGlobalVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables","d":506368,"h":34360244736,"f":16777473},{"r":375296,"p":[{"n":"document","p":309760},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetMethodFromDocumentPosition","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition","d":506368,"h":38655212032,"f":16777473},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"parent","p":834048},{"n":"name","p":1310721}],"n":"GetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute","d":506368,"h":42950179328,"f":16777473},{"r":$.$typeArray($.$sds.System.Diagnostics.SymbolStore.ISymbolNamespace).$h,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces","d":506368,"h":47245146624,"f":16777473}],"h":506368}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$$.System.Object
        {
            /*Guid*/ static C;
            /*Guid*/ static CPlusPlus;
            /*Guid*/ static CSharp;
            /*Guid*/ static Basic;
            /*Guid*/ static Java;
            /*Guid*/ static Cobol;
            /*Guid*/ static Pascal;
            /*Guid*/ static ILAssembly;
            /*Guid*/ static JScript;
            /*Guid*/ static SMC;
            /*Guid*/ static MCPlusPlus;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.C = new $.$$.System.Guid().$ctor$4(1671464724, $.$cast(64567, $.$$.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.CPlusPlus = new $.$$.System.Guid().$ctor$4(974311607, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.CSharp = new $.$$.System.Guid().$ctor$4(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.Basic = new $.$$.System.Guid().$ctor$4(974311608, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Java = new $.$$.System.Guid().$ctor$4(974311604, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Cobol = new $.$$.System.Guid().$ctor$4((2936302801 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.Pascal = new $.$$.System.Guid().$ctor$4((2936302802 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.ILAssembly = new $.$$.System.Guid().$ctor$4((2936302803 | 0), $.$cast(53473, $.$$.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.JScript = new $.$$.System.Guid().$ctor$4(974311606, $.$cast(49772, $.$$.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.SMC = new $.$$.System.Guid().$ctor$4(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
                {
                    this.MCPlusPlus = new $.$$.System.Guid().$ctor$4(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 965120;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"C","d":965120,"h":4295932416,"f":4194337},{"t":56229889,"n":"CPlusPlus","d":965120,"h":8590899712,"f":4194337},{"t":56229889,"n":"CSharp","d":965120,"h":12885867008,"f":4194337},{"t":56229889,"n":"Basic","d":965120,"h":17180834304,"f":4194337},{"t":56229889,"n":"Java","d":965120,"h":21475801600,"f":4194337},{"t":56229889,"n":"Cobol","d":965120,"h":25770768896,"f":4194337},{"t":56229889,"n":"Pascal","d":965120,"h":30065736192,"f":4194337},{"t":56229889,"n":"ILAssembly","d":965120,"h":34360703488,"f":4194337},{"t":56229889,"n":"JScript","d":965120,"h":38655670784,"f":4194337},{"t":56229889,"n":"SMC","d":965120,"h":42950638080,"f":4194337},{"t":56229889,"n":"MCPlusPlus","d":965120,"h":47245605376,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":965120,"h":51540572672,"f":16777217}],"h":965120}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$$.System.Object
        {
            /*Guid*/ static Text;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Text = new $.$$.System.Guid().$ctor$4(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
            }
            static $h = 899584;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Text","d":899584,"h":4295866880,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":899584,"h":8590834176,"f":16777217}],"h":899584}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$$.System.Object
        {
            /*Guid*/ static Microsoft;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Microsoft = new $.$$.System.Guid().$ctor$4((2571847108 | 0), $.$cast(59113, $.$$.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 1030656;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Microsoft","d":1030656,"h":4295997952,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$1","d":1030656,"h":8590965248,"f":16777217}],"h":1030656}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$$.System.Object
        {
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._metadataCache = new ($.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            /*void */ System$IDisposable$Dispose()
            {
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit$1(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString(reader.GetDocument($.$$.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                if (loadedPeAddress === $.$$.System.IntPtr.Zero && $.$$.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$$.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$$.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null) ?? null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(inMemoryPdbAddress !== $.$$.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$$.System.UInt32.$z || $.$$.$interop.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$$.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                if (loadedPeAddress !== $.$$.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$1($.$cast(loadedPeAddress, $.$typePointer($.$$.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$5(peStream);
                }
                return null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$$.System.Func$$$($.$$.System.String, $.$$.System.IO.Stream))().$ctor($.$sds.System.Diagnostics.StackTraceSymbols, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$$.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                if (!$.$$.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$$.System.IO.FileStream().$ctor$14(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            static $h = 113152;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361},{"n":"methodToken","p":655361},{"n":"ilOffset","p":655361},{"n":"sourceFile","p":1310721,"f":2},{"n":"sourceLine","p":655361,"f":2},{"n":"sourceColumn","p":655361,"f":2}],"n":"GetSourceLineInfo","d":113152,"h":17179982336,"f":16777224},{"r":24616972,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryGetReader","d":113152,"h":21474949632,"f":16777218},{"r":24813580,"p":[{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryOpenReaderForInMemoryPdb","d":113152,"h":25769916928,"f":16777250},{"r":31629324,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryGetPEReader","d":113152,"h":30064884224,"f":16777250},{"r":24813580,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryOpenReaderFromAssemblyFile","d":113152,"h":34359851520,"f":16777250},{"r":62193665,"p":[{"n":"path","p":1310721}],"n":"TryOpenFile","d":113152,"h":38654818816,"f":16777250}],"l":[{"t":$.$$.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$$.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,"n":"_metadataCache","d":113152,"h":4295080448,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":113152,"h":8590047744,"f":16777217}],"i":[57540609],"h":113152}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$$.System.ValueType
        {
            /*int*/  get _token() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$$.System.Int32, value); }
            $ctor$3(/*int*/ val)
            {
                super.$ctor$1();
                {
                    this._token = val;
                }
                return this;
            }
            /*int */ GetToken()
            {
                return this._token;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._token;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                return obj._token === this._token;
            }
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._token = 0;
            }
            static $h = 834048;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetToken","d":834048,"h":12885735936,"f":16777217},{"r":655361,"n":"GetHashCode","d":834048,"h":17180703232,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":834048,"h":21475670528,"f":16809985},{"r":262145,"p":[{"n":"obj","p":834048}],"n":"Equals","o":"@$2","d":834048,"h":25770637824,"f":16777217}],"l":[{"t":655361,"n":"_token","d":834048,"h":4295801344,"f":4194306}],"c":[{"p":[{"n":"val","p":655361}],"n":".ctor","o":"$ctor$3","d":834048,"h":8590768640,"f":16777217},{"n":".ctor","o":"$ctor$2","d":834048,"h":38655539712,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h],"h":834048}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$$.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 768512;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":768512,"n":"ILOffset","d":768512,"h":4295735808,"f":4194337},{"t":768512,"n":"NativeRVA","d":768512,"h":8590703104,"f":4194337},{"t":768512,"n":"NativeRegister","d":768512,"h":12885670400,"f":4194337},{"t":768512,"n":"NativeRegisterRelative","d":768512,"h":17180637696,"f":4194337},{"t":768512,"n":"NativeOffset","d":768512,"h":21475604992,"f":4194337},{"t":768512,"n":"NativeRegisterRegister","d":768512,"h":25770572288,"f":4194337},{"t":768512,"n":"NativeRegisterStack","d":768512,"h":30065539584,"f":4194337},{"t":768512,"n":"NativeStackRegister","d":768512,"h":34360506880,"f":4194337},{"t":768512,"n":"BitField","d":768512,"h":38655474176,"f":4194337},{"t":768512,"n":"NativeSectionOffset","d":768512,"h":42950441472,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":768512,"h":47245408768,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":768512}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"))