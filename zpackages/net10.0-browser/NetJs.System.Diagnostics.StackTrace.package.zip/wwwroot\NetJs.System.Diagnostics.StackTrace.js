
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $stt, $sr, $scc, $sris, $sic, $sim, $sl, $sci, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {"h":50109,"f":"System.Diagnostics.StackTrace","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 181181;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":508861,"p":[{"n":"importer","p":655361},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder$GetReader","d":181181,"h":4295148477,"f":257,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.","t":1310721}]}]}],"h":181181}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 705469;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"emitter","p":786433},{"n":"filename","p":1310721},{"n":"fFullBuild","p":262145}],"n":"Initialize","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Initialize","d":705469,"h":4295672765,"f":257},{"r":38666241,"p":[{"n":"url","p":1310721},{"n":"language","p":56164353},{"n":"languageVendor","p":56164353},{"n":"documentType","p":56164353}],"n":"DefineDocument","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument","d":705469,"h":8590640061,"f":257},{"r":65537,"p":[{"n":"entryMethod","p":836541}],"n":"SetUserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint","d":705469,"h":12885607357,"f":257},{"r":65537,"p":[{"n":"method","p":836541}],"n":"OpenMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod","d":705469,"h":17180574653,"f":257},{"r":65537,"n":"CloseMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod","d":705469,"h":21475541949,"f":257},{"r":65537,"p":[{"n":"document","p":38666241},{"n":"offsets","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"DefineSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints","d":705469,"h":25770509245,"f":257},{"r":655361,"p":[{"n":"startOffset","p":655361}],"n":"OpenScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope","d":705469,"h":30065476541,"f":257},{"r":65537,"p":[{"n":"endOffset","p":655361}],"n":"CloseScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope","d":705469,"h":34360443837,"f":257},{"r":65537,"p":[{"n":"scopeID","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"SetScopeRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange","d":705469,"h":38655411133,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":771005},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"DefineLocalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable","d":705469,"h":42950378429,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":81068033},{"n":"sequence","p":655361},{"n":"addrKind","p":771005},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineParameter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter","d":705469,"h":47245345725,"f":257},{"r":65537,"p":[{"n":"parent","p":836541},{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":771005},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineField","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineField","d":705469,"h":51540313021,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":771005},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineGlobalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable","d":705469,"h":55835280317,"f":257},{"r":65537,"n":"Close","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Close","d":705469,"h":60130247613,"f":257},{"r":65537,"p":[{"n":"parent","p":836541},{"n":"name","p":1310721},{"n":"data","p":0}],"n":"SetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute","d":705469,"h":64425214909,"f":257},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"OpenNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace","d":705469,"h":68720182205,"f":257},{"r":65537,"n":"CloseNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace","d":705469,"h":73015149501,"f":257},{"r":65537,"p":[{"n":"fullName","p":1310721}],"n":"UsingNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace","d":705469,"h":77310116797,"f":257},{"r":65537,"p":[{"n":"startDoc","p":38666241},{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endDoc","p":38666241},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"SetMethodSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange","d":705469,"h":81605084093,"f":257},{"r":65537,"p":[{"n":"underlyingWriter","p":786433}],"n":"SetUnderlyingWriter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter","d":705469,"h":85900051389,"f":257}],"h":705469}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 574397;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":377789,"g":{"r":0,"d":0,"h":8590508989,"f":257},"n":"Method","o":"System$Diagnostics$SymbolStore$ISymbolScope$Method","d":574397,"h":4295541693,"f":257},{"p":574397,"g":{"r":0,"d":0,"h":17180443581,"f":257},"n":"Parent","o":"System$Diagnostics$SymbolStore$ISymbolScope$Parent","d":574397,"h":12885476285,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":30065345469,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$StartOffset","d":574397,"h":25770378173,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655280061,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$EndOffset","d":574397,"h":34360312765,"f":257}],"m":[{"r":0,"n":"GetChildren","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetChildren","d":574397,"h":21475410877,"f":257},{"r":0,"n":"GetLocals","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetLocals","d":574397,"h":42950247357,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces","d":574397,"h":47245214653,"f":257}],"h":574397}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 508861;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":836541,"g":{"r":0,"d":0,"h":17180378045,"f":257},"n":"UserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint","d":508861,"h":12885410749,"f":257}],"m":[{"r":312253,"p":[{"n":"url","p":1310721},{"n":"language","p":56164353},{"n":"languageVendor","p":56164353},{"n":"documentType","p":56164353}],"n":"GetDocument","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocument","d":508861,"h":4295476157,"f":257},{"r":0,"n":"GetDocuments","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments","d":508861,"h":8590443453,"f":257},{"r":377789,"p":[{"n":"method","p":836541}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod","d":508861,"h":21475345341,"f":257},{"r":377789,"p":[{"n":"method","p":836541},{"n":"version","p":655361}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1","d":508861,"h":25770312637,"f":257},{"r":0,"p":[{"n":"parent","p":836541}],"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetVariables","d":508861,"h":30065279933,"f":257},{"r":0,"n":"GetGlobalVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables","d":508861,"h":34360247229,"f":257},{"r":377789,"p":[{"n":"document","p":312253},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetMethodFromDocumentPosition","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition","d":508861,"h":38655214525,"f":257},{"r":0,"p":[{"n":"parent","p":836541},{"n":"name","p":1310721}],"n":"GetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute","d":508861,"h":42950181821,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces","d":508861,"h":47245149117,"f":257}],"h":508861}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 312253;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590246845,"f":257},"n":"URL","o":"System$Diagnostics$SymbolStore$ISymbolDocument$URL","d":312253,"h":4295279549,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":17180181437,"f":257},"n":"DocumentType","o":"System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType","d":312253,"h":12885214141,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":25770116029,"f":257},"n":"Language","o":"System$Diagnostics$SymbolStore$ISymbolDocument$Language","d":312253,"h":21475148733,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":34360050621,"f":257},"n":"LanguageVendor","o":"System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor","d":312253,"h":30065083325,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":42949985213,"f":257},"n":"CheckSumAlgorithmId","o":"System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId","d":312253,"h":38655017917,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":60129854397,"f":257},"n":"HasEmbeddedSource","o":"System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource","d":312253,"h":55834887101,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":68719788989,"f":257},"n":"SourceLength","o":"System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength","d":312253,"h":64424821693,"f":257}],"m":[{"r":0,"n":"GetCheckSum","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum","d":312253,"h":47244952509,"f":257},{"r":655361,"p":[{"n":"line","p":655361}],"n":"FindClosestLine","o":"System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine","d":312253,"h":51539919805,"f":257},{"r":0,"p":[{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"GetSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange","d":312253,"h":73014756285,"f":257}],"h":312253}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 639933;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590574525,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Name","d":639933,"h":4295607229,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":17180509117,"f":257},"n":"Attributes","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Attributes","d":639933,"h":12885541821,"f":257},{"p":771005,"g":{"r":0,"d":0,"h":30065411005,"f":257},"n":"AddressKind","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind","d":639933,"h":25770443709,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655345597,"f":257},"n":"AddressField1","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1","d":639933,"h":34360378301,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245280189,"f":257},"n":"AddressField2","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2","d":639933,"h":42950312893,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55835214781,"f":257},"n":"AddressField3","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3","d":639933,"h":51540247485,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":64425149373,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset","d":639933,"h":60130182077,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":73015083965,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset","d":639933,"h":68720116669,"f":257}],"m":[{"r":0,"n":"GetSignature","o":"System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature","d":639933,"h":21475476413,"f":257}],"h":639933}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 377789;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":836541,"g":{"r":0,"d":0,"h":8590312381,"f":257},"n":"Token","o":"System$Diagnostics$SymbolStore$ISymbolMethod$Token","d":377789,"h":4295345085,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":17180246973,"f":257},"n":"SequencePointCount","o":"System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount","d":377789,"h":12885279677,"f":257},{"p":574397,"g":{"r":0,"d":0,"h":30065148861,"f":257},"n":"RootScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$RootScope","d":377789,"h":25770181565,"f":257}],"m":[{"r":65537,"p":[{"n":"offsets","p":0},{"n":"documents","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"GetSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints","d":377789,"h":21475214269,"f":257},{"r":574397,"p":[{"n":"offset","p":655361}],"n":"GetScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetScope","d":377789,"h":34360116157,"f":257},{"r":655361,"p":[{"n":"document","p":312253},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetOffset","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset","d":377789,"h":38655083453,"f":257},{"r":0,"p":[{"n":"document","p":312253},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetRanges","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges","d":377789,"h":42950050749,"f":257},{"r":0,"n":"GetParameters","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters","d":377789,"h":47245018045,"f":257},{"r":443325,"n":"GetNamespace","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace","d":377789,"h":51539985341,"f":257},{"r":262145,"p":[{"n":"docs","p":0},{"n":"lines","p":0},{"n":"columns","p":0}],"n":"GetSourceStartEnd","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd","d":377789,"h":55834952637,"f":257}],"h":377789}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 443325;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590377917,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$Name","d":443325,"h":4295410621,"f":257}],"m":[{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces","d":443325,"h":12885345213,"f":257},{"r":0,"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables","d":443325,"h":17180312509,"f":257}],"h":443325}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 246717;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":508861,"p":[{"n":"importer","p":786433},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader","d":246717,"h":4295214013,"f":257}],"h":246717}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$spc.System.Object
        {
            /*Guid*/ static Text;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Text = new $.$spc.System.Guid().$ctor$7(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
            }
            static $h = 902077;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"Text","d":902077,"h":4295869373,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":902077,"h":8590836669,"f":1}],"h":902077}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$spc.System.Object
        {
            /*Guid*/ static Microsoft;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Microsoft = new $.$spc.System.Guid().$ctor$7((2571847108 | 0), $.$cast(59113, $.$spc.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 1033149;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"Microsoft","d":1033149,"h":4296000445,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1033149,"h":8590967741,"f":1}],"h":1033149}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$spc.System.Object
        {
            /*Guid*/ static C;
            /*Guid*/ static CPlusPlus;
            /*Guid*/ static CSharp;
            /*Guid*/ static Basic;
            /*Guid*/ static Java;
            /*Guid*/ static Cobol;
            /*Guid*/ static Pascal;
            /*Guid*/ static ILAssembly;
            /*Guid*/ static JScript;
            /*Guid*/ static SMC;
            /*Guid*/ static MCPlusPlus;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.C = new $.$spc.System.Guid().$ctor$7(1671464724, $.$cast(64567, $.$spc.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.CPlusPlus = new $.$spc.System.Guid().$ctor$7(974311607, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.CSharp = new $.$spc.System.Guid().$ctor$7(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.Basic = new $.$spc.System.Guid().$ctor$7(974311608, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Java = new $.$spc.System.Guid().$ctor$7(974311604, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Cobol = new $.$spc.System.Guid().$ctor$7((2936302801 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.Pascal = new $.$spc.System.Guid().$ctor$7((2936302802 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.ILAssembly = new $.$spc.System.Guid().$ctor$7((2936302803 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.JScript = new $.$spc.System.Guid().$ctor$7(974311606, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.SMC = new $.$spc.System.Guid().$ctor$7(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
                {
                    this.MCPlusPlus = new $.$spc.System.Guid().$ctor$7(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 967613;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"C","d":967613,"h":4295934909,"f":33},{"t":56164353,"n":"CPlusPlus","d":967613,"h":8590902205,"f":33},{"t":56164353,"n":"CSharp","d":967613,"h":12885869501,"f":33},{"t":56164353,"n":"Basic","d":967613,"h":17180836797,"f":33},{"t":56164353,"n":"Java","d":967613,"h":21475804093,"f":33},{"t":56164353,"n":"Cobol","d":967613,"h":25770771389,"f":33},{"t":56164353,"n":"Pascal","d":967613,"h":30065738685,"f":33},{"t":56164353,"n":"ILAssembly","d":967613,"h":34360705981,"f":33},{"t":56164353,"n":"JScript","d":967613,"h":38655673277,"f":33},{"t":56164353,"n":"SMC","d":967613,"h":42950640573,"f":33},{"t":56164353,"n":"MCPlusPlus","d":967613,"h":47245607869,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":967613,"h":51540575165,"f":1}],"h":967613}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$spc.System.Object
        {
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._metadataCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            /*void */ System$IDisposable$Dispose()
            {
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString$2(reader.GetDocument($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                if (loadedPeAddress === $.$spc.System.IntPtr.Zero && $.$spc.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$spc.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null);
            }
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$spc.System.UInt32.$z || $.$spc.InteropUtility.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$spc.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                if (loadedPeAddress !== $.$spc.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$2($.$cast(loadedPeAddress, $.$typePointer($.$spc.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$3(peStream);
                }
                return null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.IO.Stream))().$ctor(null, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$spc.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                if (!$.$spc.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$spc.System.IO.FileStream().$ctor$12(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            static $h = 115645;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361},{"n":"methodToken","p":655361},{"n":"ilOffset","p":655361},{"n":"sourceFile","p":1310721,"f":2},{"n":"sourceLine","p":655361,"f":2},{"n":"sourceColumn","p":655361,"f":2}],"n":"GetSourceLineInfo","d":115645,"h":17179984829,"f":8},{"r":24628074,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryGetReader","d":115645,"h":21474952125,"f":2},{"r":24824682,"p":[{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryOpenReaderForInMemoryPdb","d":115645,"h":25769919421,"f":34},{"r":31640426,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryGetPEReader","d":115645,"h":30064886717,"f":34},{"r":24824682,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryOpenReaderFromAssemblyFile","d":115645,"h":34359854013,"f":34},{"r":62128129,"p":[{"n":"path","p":1310721}],"n":"TryOpenFile","d":115645,"h":38654821309,"f":34}],"l":[{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,"n":"_metadataCache","d":115645,"h":4295082941,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":115645,"h":8590050237,"f":1}],"i":[57475073],"h":115645}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$spc.System.ValueType
        {
            /*int*/  get _token() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ val)
            {
                super.$ctor$1();
                {
                    this._token = val;
                }
                return this;
            }
            /*int */ GetToken()
            {
                return this._token;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._token;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                return obj._token === this._token;
            }
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._token = 0;
            }
            static $h = 836541;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetToken","d":836541,"h":12885738429,"f":1},{"r":655361,"n":"GetHashCode","d":836541,"h":17180705725,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":836541,"h":21475673021,"f":32769},{"r":262145,"p":[{"n":"obj","p":836541}],"n":"Equals","o":"@$2","d":836541,"h":25770640317,"f":1}],"l":[{"t":655361,"n":"_token","d":836541,"h":4295803837,"f":2}],"c":[{"p":[{"n":"val","p":655361}],"n":".ctor","o":"$ctor$2","d":836541,"h":8590771133,"f":1},{"n":".ctor","o":"$ctor$3","d":836541,"h":38655542205,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h],"h":836541}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$spc.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 771005;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":771005,"n":"ILOffset","d":771005,"h":4295738301,"f":33},{"t":771005,"n":"NativeRVA","d":771005,"h":8590705597,"f":33},{"t":771005,"n":"NativeRegister","d":771005,"h":12885672893,"f":33},{"t":771005,"n":"NativeRegisterRelative","d":771005,"h":17180640189,"f":33},{"t":771005,"n":"NativeOffset","d":771005,"h":21475607485,"f":33},{"t":771005,"n":"NativeRegisterRegister","d":771005,"h":25770574781,"f":33},{"t":771005,"n":"NativeRegisterStack","d":771005,"h":30065542077,"f":33},{"t":771005,"n":"NativeStackRegister","d":771005,"h":34360509373,"f":33},{"t":771005,"n":"BitField","d":771005,"h":38655476669,"f":33},{"t":771005,"n":"NativeSectionOffset","d":771005,"h":42950443965,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":771005,"h":47245411261,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":771005}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata"))