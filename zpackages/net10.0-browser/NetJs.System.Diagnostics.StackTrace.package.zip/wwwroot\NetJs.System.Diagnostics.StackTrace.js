
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $stee, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {"h":40520,"f":"System.Diagnostics.StackTrace","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 368200;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":826952,"g":{"r":0,"d":0,"h":8590302792,"f":257},"n":"Token","o":"System$Diagnostics$SymbolStore$ISymbolMethod$Token","d":368200,"h":4295335496,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":17180237384,"f":257},"n":"SequencePointCount","o":"System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount","d":368200,"h":12885270088,"f":257},{"p":564808,"g":{"r":0,"d":0,"h":30065139272,"f":257},"n":"RootScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$RootScope","d":368200,"h":25770171976,"f":257}],"m":[{"r":65537,"p":[{"n":"offsets","p":0},{"n":"documents","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"GetSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints","d":368200,"h":21475204680,"f":257},{"r":564808,"p":[{"n":"offset","p":655361}],"n":"GetScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetScope","d":368200,"h":34360106568,"f":257},{"r":655361,"p":[{"n":"document","p":302664},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetOffset","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset","d":368200,"h":38655073864,"f":257},{"r":0,"p":[{"n":"document","p":302664},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetRanges","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges","d":368200,"h":42950041160,"f":257},{"r":0,"n":"GetParameters","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters","d":368200,"h":47245008456,"f":257},{"r":433736,"n":"GetNamespace","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace","d":368200,"h":51539975752,"f":257},{"r":262145,"p":[{"n":"docs","p":0},{"n":"lines","p":0},{"n":"columns","p":0}],"n":"GetSourceStartEnd","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd","d":368200,"h":55834943048,"f":257}],"h":368200}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 695880;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"emitter","p":786433},{"n":"filename","p":1310721},{"n":"fFullBuild","p":262145}],"n":"Initialize","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Initialize","d":695880,"h":4295663176,"f":257},{"r":38731777,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"DefineDocument","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument","d":695880,"h":8590630472,"f":257},{"r":65537,"p":[{"n":"entryMethod","p":826952}],"n":"SetUserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint","d":695880,"h":12885597768,"f":257},{"r":65537,"p":[{"n":"method","p":826952}],"n":"OpenMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod","d":695880,"h":17180565064,"f":257},{"r":65537,"n":"CloseMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod","d":695880,"h":21475532360,"f":257},{"r":65537,"p":[{"n":"document","p":38731777},{"n":"offsets","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"DefineSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints","d":695880,"h":25770499656,"f":257},{"r":655361,"p":[{"n":"startOffset","p":655361}],"n":"OpenScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope","d":695880,"h":30065466952,"f":257},{"r":65537,"p":[{"n":"endOffset","p":655361}],"n":"CloseScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope","d":695880,"h":34360434248,"f":257},{"r":65537,"p":[{"n":"scopeID","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"SetScopeRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange","d":695880,"h":38655401544,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":761416},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"DefineLocalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable","d":695880,"h":42950368840,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":81068033},{"n":"sequence","p":655361},{"n":"addrKind","p":761416},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineParameter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter","d":695880,"h":47245336136,"f":257},{"r":65537,"p":[{"n":"parent","p":826952},{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":761416},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineField","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineField","d":695880,"h":51540303432,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":761416},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineGlobalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable","d":695880,"h":55835270728,"f":257},{"r":65537,"n":"Close","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Close","d":695880,"h":60130238024,"f":257},{"r":65537,"p":[{"n":"parent","p":826952},{"n":"name","p":1310721},{"n":"data","p":0}],"n":"SetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute","d":695880,"h":64425205320,"f":257},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"OpenNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace","d":695880,"h":68720172616,"f":257},{"r":65537,"n":"CloseNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace","d":695880,"h":73015139912,"f":257},{"r":65537,"p":[{"n":"fullName","p":1310721}],"n":"UsingNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace","d":695880,"h":77310107208,"f":257},{"r":65537,"p":[{"n":"startDoc","p":38731777},{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endDoc","p":38731777},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"SetMethodSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange","d":695880,"h":81605074504,"f":257},{"r":65537,"p":[{"n":"underlyingWriter","p":786433}],"n":"SetUnderlyingWriter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter","d":695880,"h":85900041800,"f":257}],"h":695880}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 302664;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590237256,"f":257},"n":"URL","o":"System$Diagnostics$SymbolStore$ISymbolDocument$URL","d":302664,"h":4295269960,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":17180171848,"f":257},"n":"DocumentType","o":"System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType","d":302664,"h":12885204552,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":25770106440,"f":257},"n":"Language","o":"System$Diagnostics$SymbolStore$ISymbolDocument$Language","d":302664,"h":21475139144,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":34360041032,"f":257},"n":"LanguageVendor","o":"System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor","d":302664,"h":30065073736,"f":257},{"p":56229889,"g":{"r":0,"d":0,"h":42949975624,"f":257},"n":"CheckSumAlgorithmId","o":"System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId","d":302664,"h":38655008328,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":60129844808,"f":257},"n":"HasEmbeddedSource","o":"System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource","d":302664,"h":55834877512,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":68719779400,"f":257},"n":"SourceLength","o":"System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength","d":302664,"h":64424812104,"f":257}],"m":[{"r":0,"n":"GetCheckSum","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum","d":302664,"h":47244942920,"f":257},{"r":655361,"p":[{"n":"line","p":655361}],"n":"FindClosestLine","o":"System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine","d":302664,"h":51539910216,"f":257},{"r":0,"p":[{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"GetSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange","d":302664,"h":73014746696,"f":257}],"h":302664}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 499272;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":826952,"g":{"r":0,"d":0,"h":17180368456,"f":257},"n":"UserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint","d":499272,"h":12885401160,"f":257}],"m":[{"r":302664,"p":[{"n":"url","p":1310721},{"n":"language","p":56229889},{"n":"languageVendor","p":56229889},{"n":"documentType","p":56229889}],"n":"GetDocument","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocument","d":499272,"h":4295466568,"f":257},{"r":0,"n":"GetDocuments","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments","d":499272,"h":8590433864,"f":257},{"r":368200,"p":[{"n":"method","p":826952}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod","d":499272,"h":21475335752,"f":257},{"r":368200,"p":[{"n":"method","p":826952},{"n":"version","p":655361}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1","d":499272,"h":25770303048,"f":257},{"r":0,"p":[{"n":"parent","p":826952}],"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetVariables","d":499272,"h":30065270344,"f":257},{"r":0,"n":"GetGlobalVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables","d":499272,"h":34360237640,"f":257},{"r":368200,"p":[{"n":"document","p":302664},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetMethodFromDocumentPosition","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition","d":499272,"h":38655204936,"f":257},{"r":0,"p":[{"n":"parent","p":826952},{"n":"name","p":1310721}],"n":"GetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute","d":499272,"h":42950172232,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces","d":499272,"h":47245139528,"f":257}],"h":499272}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 433736;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590368328,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$Name","d":433736,"h":4295401032,"f":257}],"m":[{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces","d":433736,"h":12885335624,"f":257},{"r":0,"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables","d":433736,"h":17180302920,"f":257}],"h":433736}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 564808;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":368200,"g":{"r":0,"d":0,"h":8590499400,"f":257},"n":"Method","o":"System$Diagnostics$SymbolStore$ISymbolScope$Method","d":564808,"h":4295532104,"f":257},{"p":564808,"g":{"r":0,"d":0,"h":17180433992,"f":257},"n":"Parent","o":"System$Diagnostics$SymbolStore$ISymbolScope$Parent","d":564808,"h":12885466696,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":30065335880,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$StartOffset","d":564808,"h":25770368584,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655270472,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$EndOffset","d":564808,"h":34360303176,"f":257}],"m":[{"r":0,"n":"GetChildren","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetChildren","d":564808,"h":21475401288,"f":257},{"r":0,"n":"GetLocals","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetLocals","d":564808,"h":42950237768,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces","d":564808,"h":47245205064,"f":257}],"h":564808}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 171592;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":499272,"p":[{"n":"importer","p":655361},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder$GetReader","d":171592,"h":4295138888,"f":257,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.","t":1310721}]}]}],"h":171592}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 630344;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590564936,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Name","d":630344,"h":4295597640,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":17180499528,"f":257},"n":"Attributes","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Attributes","d":630344,"h":12885532232,"f":257},{"p":761416,"g":{"r":0,"d":0,"h":30065401416,"f":257},"n":"AddressKind","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind","d":630344,"h":25770434120,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655336008,"f":257},"n":"AddressField1","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1","d":630344,"h":34360368712,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245270600,"f":257},"n":"AddressField2","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2","d":630344,"h":42950303304,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55835205192,"f":257},"n":"AddressField3","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3","d":630344,"h":51540237896,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":64425139784,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset","d":630344,"h":60130172488,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":73015074376,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset","d":630344,"h":68720107080,"f":257}],"m":[{"r":0,"n":"GetSignature","o":"System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature","d":630344,"h":21475466824,"f":257}],"h":630344}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 237128;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":499272,"p":[{"n":"importer","p":786433},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader","d":237128,"h":4295204424,"f":257}],"h":237128}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$spc.System.Object
        {
            /*Guid*/ static C;
            /*Guid*/ static CPlusPlus;
            /*Guid*/ static CSharp;
            /*Guid*/ static Basic;
            /*Guid*/ static Java;
            /*Guid*/ static Cobol;
            /*Guid*/ static Pascal;
            /*Guid*/ static ILAssembly;
            /*Guid*/ static JScript;
            /*Guid*/ static SMC;
            /*Guid*/ static MCPlusPlus;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.C = new $.$spc.System.Guid().$ctor$7(1671464724, $.$cast(64567, $.$spc.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.CPlusPlus = new $.$spc.System.Guid().$ctor$7(974311607, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.CSharp = new $.$spc.System.Guid().$ctor$7(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.Basic = new $.$spc.System.Guid().$ctor$7(974311608, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Java = new $.$spc.System.Guid().$ctor$7(974311604, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Cobol = new $.$spc.System.Guid().$ctor$7((2936302801 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.Pascal = new $.$spc.System.Guid().$ctor$7((2936302802 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.ILAssembly = new $.$spc.System.Guid().$ctor$7((2936302803 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.JScript = new $.$spc.System.Guid().$ctor$7(974311606, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.SMC = new $.$spc.System.Guid().$ctor$7(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
                {
                    this.MCPlusPlus = new $.$spc.System.Guid().$ctor$7(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 958024;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"C","d":958024,"h":4295925320,"f":33},{"t":56229889,"n":"CPlusPlus","d":958024,"h":8590892616,"f":33},{"t":56229889,"n":"CSharp","d":958024,"h":12885859912,"f":33},{"t":56229889,"n":"Basic","d":958024,"h":17180827208,"f":33},{"t":56229889,"n":"Java","d":958024,"h":21475794504,"f":33},{"t":56229889,"n":"Cobol","d":958024,"h":25770761800,"f":33},{"t":56229889,"n":"Pascal","d":958024,"h":30065729096,"f":33},{"t":56229889,"n":"ILAssembly","d":958024,"h":34360696392,"f":33},{"t":56229889,"n":"JScript","d":958024,"h":38655663688,"f":33},{"t":56229889,"n":"SMC","d":958024,"h":42950630984,"f":33},{"t":56229889,"n":"MCPlusPlus","d":958024,"h":47245598280,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":958024,"h":51540565576,"f":1}],"h":958024}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$spc.System.Object
        {
            /*Guid*/ static Microsoft;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Microsoft = new $.$spc.System.Guid().$ctor$7((2571847108 | 0), $.$cast(59113, $.$spc.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 1023560;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Microsoft","d":1023560,"h":4295990856,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1023560,"h":8590958152,"f":1}],"h":1023560}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$spc.System.Object
        {
            /*Guid*/ static Text;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Text = new $.$spc.System.Guid().$ctor$7(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
            }
            static $h = 892488;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56229889,"n":"Text","d":892488,"h":4295859784,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":892488,"h":8590827080,"f":1}],"h":892488}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$spc.System.Object
        {
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._metadataCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            /*void */ System$IDisposable$Dispose()
            {
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString$2(reader.GetDocument($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                if (loadedPeAddress === $.$spc.System.IntPtr.Zero && $.$spc.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$spc.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null);
            }
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$spc.System.UInt32.$z || $.$spc.InteropUtility.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$spc.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                if (loadedPeAddress !== $.$spc.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$2($.$cast(loadedPeAddress, $.$typePointer($.$spc.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$3(peStream);
                }
                return null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.IO.Stream))().$ctor($.$sds.System.Diagnostics.StackTraceSymbols, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$spc.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                if (!$.$spc.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$spc.System.IO.FileStream().$ctor$12(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            static $h = 106056;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361},{"n":"methodToken","p":655361},{"n":"ilOffset","p":655361},{"n":"sourceFile","p":1310721,"f":2},{"n":"sourceLine","p":655361,"f":2},{"n":"sourceColumn","p":655361,"f":2}],"n":"GetSourceLineInfo","d":106056,"h":17179975240,"f":8},{"r":24639673,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryGetReader","d":106056,"h":21474942536,"f":2},{"r":24836281,"p":[{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryOpenReaderForInMemoryPdb","d":106056,"h":25769909832,"f":34},{"r":31652025,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryGetPEReader","d":106056,"h":30064877128,"f":34},{"r":24836281,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryOpenReaderFromAssemblyFile","d":106056,"h":34359844424,"f":34},{"r":62193665,"p":[{"n":"path","p":1310721}],"n":"TryOpenFile","d":106056,"h":38654811720,"f":34}],"l":[{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,"n":"_metadataCache","d":106056,"h":4295073352,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":106056,"h":8590040648,"f":1}],"i":[57540609],"h":106056}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$spc.System.ValueType
        {
            /*int*/  get _token() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ val)
            {
                super.$ctor$1();
                {
                    this._token = val;
                }
                return this;
            }
            /*int */ GetToken()
            {
                return this._token;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._token;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                return obj._token === this._token;
            }
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._token = 0;
            }
            static $h = 826952;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetToken","d":826952,"h":12885728840,"f":1},{"r":655361,"n":"GetHashCode","d":826952,"h":17180696136,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":826952,"h":21475663432,"f":32769},{"r":262145,"p":[{"n":"obj","p":826952}],"n":"Equals","o":"@$2","d":826952,"h":25770630728,"f":1}],"l":[{"t":655361,"n":"_token","d":826952,"h":4295794248,"f":2}],"c":[{"p":[{"n":"val","p":655361}],"n":".ctor","o":"$ctor$2","d":826952,"h":8590761544,"f":1},{"n":".ctor","o":"$ctor$3","d":826952,"h":38655532616,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h],"h":826952}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$spc.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 761416;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":761416,"n":"ILOffset","d":761416,"h":4295728712,"f":33},{"t":761416,"n":"NativeRVA","d":761416,"h":8590696008,"f":33},{"t":761416,"n":"NativeRegister","d":761416,"h":12885663304,"f":33},{"t":761416,"n":"NativeRegisterRelative","d":761416,"h":17180630600,"f":33},{"t":761416,"n":"NativeOffset","d":761416,"h":21475597896,"f":33},{"t":761416,"n":"NativeRegisterRegister","d":761416,"h":25770565192,"f":33},{"t":761416,"n":"NativeRegisterStack","d":761416,"h":30065532488,"f":33},{"t":761416,"n":"NativeStackRegister","d":761416,"h":34360499784,"f":33},{"t":761416,"n":"BitField","d":761416,"h":38655467080,"f":33},{"t":761416,"n":"NativeSectionOffset","d":761416,"h":42950434376,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":761416,"h":47245401672,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":761416}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata"))