
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $stt, $sr, $scc, $sris, $sic, $sim, $sl, $sci, $srm) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.StackTrace", 
    {"h":35900,"f":"System.Diagnostics.StackTrace","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.StackTrace","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolMethod", ($self) => class ISymbolMethod
        {
            static $h = 363580;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":822332,"g":{"r":0,"d":0,"h":8590298172,"f":257},"n":"Token","o":"System$Diagnostics$SymbolStore$ISymbolMethod$Token","d":363580,"h":4295330876,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":17180232764,"f":257},"n":"SequencePointCount","o":"System$Diagnostics$SymbolStore$ISymbolMethod$SequencePointCount","d":363580,"h":12885265468,"f":257},{"p":560188,"g":{"r":0,"d":0,"h":30065134652,"f":257},"n":"RootScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$RootScope","d":363580,"h":25770167356,"f":257}],"m":[{"r":65537,"p":[{"n":"offsets","p":0},{"n":"documents","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"GetSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSequencePoints","d":363580,"h":21475200060,"f":257},{"r":560188,"p":[{"n":"offset","p":655361}],"n":"GetScope","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetScope","d":363580,"h":34360101948,"f":257},{"r":655361,"p":[{"n":"document","p":298044},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetOffset","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetOffset","d":363580,"h":38655069244,"f":257},{"r":0,"p":[{"n":"document","p":298044},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetRanges","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetRanges","d":363580,"h":42950036540,"f":257},{"r":0,"n":"GetParameters","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetParameters","d":363580,"h":47245003836,"f":257},{"r":429116,"n":"GetNamespace","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetNamespace","d":363580,"h":51539971132,"f":257},{"r":262145,"p":[{"n":"docs","p":0},{"n":"lines","p":0},{"n":"columns","p":0}],"n":"GetSourceStartEnd","o":"System$Diagnostics$SymbolStore$ISymbolMethod$GetSourceStartEnd","d":363580,"h":55834938428,"f":257}],"h":363580}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolMethod`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder", ($self) => class ISymbolBinder
        {
            static $h = 166972;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":494652,"p":[{"n":"importer","p":655361},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder$GetReader","d":166972,"h":4295134268,"f":257,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"ISymbolBinder.GetReader has been deprecated because it is not 64-bit compatible. Use ISymbolBinder1.GetReader instead. ISymbolBinder1.GetReader accepts the importer interface pointer as an IntPtr instead of an Int32, and thus works on both 32-bit and 64-bit architectures.","t":1310721}]}]}],"h":166972}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolDocument", ($self) => class ISymbolDocument
        {
            static $h = 298044;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590232636,"f":257},"n":"URL","o":"System$Diagnostics$SymbolStore$ISymbolDocument$URL","d":298044,"h":4295265340,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":17180167228,"f":257},"n":"DocumentType","o":"System$Diagnostics$SymbolStore$ISymbolDocument$DocumentType","d":298044,"h":12885199932,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":25770101820,"f":257},"n":"Language","o":"System$Diagnostics$SymbolStore$ISymbolDocument$Language","d":298044,"h":21475134524,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":34360036412,"f":257},"n":"LanguageVendor","o":"System$Diagnostics$SymbolStore$ISymbolDocument$LanguageVendor","d":298044,"h":30065069116,"f":257},{"p":56164353,"g":{"r":0,"d":0,"h":42949971004,"f":257},"n":"CheckSumAlgorithmId","o":"System$Diagnostics$SymbolStore$ISymbolDocument$CheckSumAlgorithmId","d":298044,"h":38655003708,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":60129840188,"f":257},"n":"HasEmbeddedSource","o":"System$Diagnostics$SymbolStore$ISymbolDocument$HasEmbeddedSource","d":298044,"h":55834872892,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":68719774780,"f":257},"n":"SourceLength","o":"System$Diagnostics$SymbolStore$ISymbolDocument$SourceLength","d":298044,"h":64424807484,"f":257}],"m":[{"r":0,"n":"GetCheckSum","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetCheckSum","d":298044,"h":47244938300,"f":257},{"r":655361,"p":[{"n":"line","p":655361}],"n":"FindClosestLine","o":"System$Diagnostics$SymbolStore$ISymbolDocument$FindClosestLine","d":298044,"h":51539905596,"f":257},{"r":0,"p":[{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"GetSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolDocument$GetSourceRange","d":298044,"h":73014742076,"f":257}],"h":298044}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolDocument`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolReader", ($self) => class ISymbolReader
        {
            static $h = 494652;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":822332,"g":{"r":0,"d":0,"h":17180363836,"f":257},"n":"UserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolReader$UserEntryPoint","d":494652,"h":12885396540,"f":257}],"m":[{"r":298044,"p":[{"n":"url","p":1310721},{"n":"language","p":56164353},{"n":"languageVendor","p":56164353},{"n":"documentType","p":56164353}],"n":"GetDocument","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocument","d":494652,"h":4295461948,"f":257},{"r":0,"n":"GetDocuments","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetDocuments","d":494652,"h":8590429244,"f":257},{"r":363580,"p":[{"n":"method","p":822332}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod","d":494652,"h":21475331132,"f":257},{"r":363580,"p":[{"n":"method","p":822332},{"n":"version","p":655361}],"n":"GetMethod","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethod$1","d":494652,"h":25770298428,"f":257},{"r":0,"p":[{"n":"parent","p":822332}],"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetVariables","d":494652,"h":30065265724,"f":257},{"r":0,"n":"GetGlobalVariables","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetGlobalVariables","d":494652,"h":34360233020,"f":257},{"r":363580,"p":[{"n":"document","p":298044},{"n":"line","p":655361},{"n":"column","p":655361}],"n":"GetMethodFromDocumentPosition","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetMethodFromDocumentPosition","d":494652,"h":38655200316,"f":257},{"r":0,"p":[{"n":"parent","p":822332},{"n":"name","p":1310721}],"n":"GetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetSymAttribute","d":494652,"h":42950167612,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolReader$GetNamespaces","d":494652,"h":47245134908,"f":257}],"h":494652}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolReader`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolNamespace", ($self) => class ISymbolNamespace
        {
            static $h = 429116;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590363708,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$Name","d":429116,"h":4295396412,"f":257}],"m":[{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetNamespaces","d":429116,"h":12885331004,"f":257},{"r":0,"n":"GetVariables","o":"System$Diagnostics$SymbolStore$ISymbolNamespace$GetVariables","d":429116,"h":17180298300,"f":257}],"h":429116}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolNamespace`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolWriter", ($self) => class ISymbolWriter
        {
            static $h = 691260;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"emitter","p":786433},{"n":"filename","p":1310721},{"n":"fFullBuild","p":262145}],"n":"Initialize","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Initialize","d":691260,"h":4295658556,"f":257},{"r":38666241,"p":[{"n":"url","p":1310721},{"n":"language","p":56164353},{"n":"languageVendor","p":56164353},{"n":"documentType","p":56164353}],"n":"DefineDocument","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineDocument","d":691260,"h":8590625852,"f":257},{"r":65537,"p":[{"n":"entryMethod","p":822332}],"n":"SetUserEntryPoint","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUserEntryPoint","d":691260,"h":12885593148,"f":257},{"r":65537,"p":[{"n":"method","p":822332}],"n":"OpenMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenMethod","d":691260,"h":17180560444,"f":257},{"r":65537,"n":"CloseMethod","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseMethod","d":691260,"h":21475527740,"f":257},{"r":65537,"p":[{"n":"document","p":38666241},{"n":"offsets","p":0},{"n":"lines","p":0},{"n":"columns","p":0},{"n":"endLines","p":0},{"n":"endColumns","p":0}],"n":"DefineSequencePoints","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineSequencePoints","d":691260,"h":25770495036,"f":257},{"r":655361,"p":[{"n":"startOffset","p":655361}],"n":"OpenScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenScope","d":691260,"h":30065462332,"f":257},{"r":65537,"p":[{"n":"endOffset","p":655361}],"n":"CloseScope","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseScope","d":691260,"h":34360429628,"f":257},{"r":65537,"p":[{"n":"scopeID","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"SetScopeRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetScopeRange","d":691260,"h":38655396924,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":756796},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361},{"n":"startOffset","p":655361},{"n":"endOffset","p":655361}],"n":"DefineLocalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineLocalVariable","d":691260,"h":42950364220,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":81068033},{"n":"sequence","p":655361},{"n":"addrKind","p":756796},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineParameter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineParameter","d":691260,"h":47245331516,"f":257},{"r":65537,"p":[{"n":"parent","p":822332},{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":756796},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineField","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineField","d":691260,"h":51540298812,"f":257},{"r":65537,"p":[{"n":"name","p":1310721},{"n":"attributes","p":76611585},{"n":"signature","p":0},{"n":"addrKind","p":756796},{"n":"addr1","p":655361},{"n":"addr2","p":655361},{"n":"addr3","p":655361}],"n":"DefineGlobalVariable","o":"System$Diagnostics$SymbolStore$ISymbolWriter$DefineGlobalVariable","d":691260,"h":55835266108,"f":257},{"r":65537,"n":"Close","o":"System$Diagnostics$SymbolStore$ISymbolWriter$Close","d":691260,"h":60130233404,"f":257},{"r":65537,"p":[{"n":"parent","p":822332},{"n":"name","p":1310721},{"n":"data","p":0}],"n":"SetSymAttribute","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetSymAttribute","d":691260,"h":64425200700,"f":257},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"OpenNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$OpenNamespace","d":691260,"h":68720167996,"f":257},{"r":65537,"n":"CloseNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$CloseNamespace","d":691260,"h":73015135292,"f":257},{"r":65537,"p":[{"n":"fullName","p":1310721}],"n":"UsingNamespace","o":"System$Diagnostics$SymbolStore$ISymbolWriter$UsingNamespace","d":691260,"h":77310102588,"f":257},{"r":65537,"p":[{"n":"startDoc","p":38666241},{"n":"startLine","p":655361},{"n":"startColumn","p":655361},{"n":"endDoc","p":38666241},{"n":"endLine","p":655361},{"n":"endColumn","p":655361}],"n":"SetMethodSourceRange","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetMethodSourceRange","d":691260,"h":81605069884,"f":257},{"r":65537,"p":[{"n":"underlyingWriter","p":786433}],"n":"SetUnderlyingWriter","o":"System$Diagnostics$SymbolStore$ISymbolWriter$SetUnderlyingWriter","d":691260,"h":85900037180,"f":257}],"h":691260}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolWriter`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolVariable", ($self) => class ISymbolVariable
        {
            static $h = 625724;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":1310721,"g":{"r":0,"d":0,"h":8590560316,"f":257},"n":"Name","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Name","d":625724,"h":4295593020,"f":257},{"p":131073,"g":{"r":0,"d":0,"h":17180494908,"f":257},"n":"Attributes","o":"System$Diagnostics$SymbolStore$ISymbolVariable$Attributes","d":625724,"h":12885527612,"f":257},{"p":756796,"g":{"r":0,"d":0,"h":30065396796,"f":257},"n":"AddressKind","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressKind","d":625724,"h":25770429500,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655331388,"f":257},"n":"AddressField1","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField1","d":625724,"h":34360364092,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245265980,"f":257},"n":"AddressField2","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField2","d":625724,"h":42950298684,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55835200572,"f":257},"n":"AddressField3","o":"System$Diagnostics$SymbolStore$ISymbolVariable$AddressField3","d":625724,"h":51540233276,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":64425135164,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$StartOffset","d":625724,"h":60130167868,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":73015069756,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolVariable$EndOffset","d":625724,"h":68720102460,"f":257}],"m":[{"r":0,"n":"GetSignature","o":"System$Diagnostics$SymbolStore$ISymbolVariable$GetSignature","d":625724,"h":21475462204,"f":257}],"h":625724}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolVariable`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolScope", ($self) => class ISymbolScope
        {
            static $h = 560188;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":363580,"g":{"r":0,"d":0,"h":8590494780,"f":257},"n":"Method","o":"System$Diagnostics$SymbolStore$ISymbolScope$Method","d":560188,"h":4295527484,"f":257},{"p":560188,"g":{"r":0,"d":0,"h":17180429372,"f":257},"n":"Parent","o":"System$Diagnostics$SymbolStore$ISymbolScope$Parent","d":560188,"h":12885462076,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":30065331260,"f":257},"n":"StartOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$StartOffset","d":560188,"h":25770363964,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655265852,"f":257},"n":"EndOffset","o":"System$Diagnostics$SymbolStore$ISymbolScope$EndOffset","d":560188,"h":34360298556,"f":257}],"m":[{"r":0,"n":"GetChildren","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetChildren","d":560188,"h":21475396668,"f":257},{"r":0,"n":"GetLocals","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetLocals","d":560188,"h":42950233148,"f":257},{"r":0,"n":"GetNamespaces","o":"System$Diagnostics$SymbolStore$ISymbolScope$GetNamespaces","d":560188,"h":47245200444,"f":257}],"h":560188}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolScope`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.ISymbolBinder1", ($self) => class ISymbolBinder1
        {
            static $h = 232508;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":494652,"p":[{"n":"importer","p":786433},{"n":"filename","p":1310721},{"n":"searchPath","p":1310721}],"n":"GetReader","o":"System$Diagnostics$SymbolStore$ISymbolBinder1$GetReader","d":232508,"h":4295199804,"f":257}],"h":232508}; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.ISymbolBinder1`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymDocumentType", ($self) => class SymDocumentType extends $.$spc.System.Object
        {
            /*Guid*/ static Text;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Text = new $.$spc.System.Guid().$ctor$7(1518771467, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
            }
            static $h = 887868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"Text","d":887868,"h":4295855164,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":887868,"h":8590822460,"f":1}],"h":887868}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymDocumentType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageVendor", ($self) => class SymLanguageVendor extends $.$spc.System.Object
        {
            /*Guid*/ static Microsoft;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Microsoft = new $.$spc.System.Guid().$ctor$7((2571847108 | 0), $.$cast(59113, $.$spc.System.Int16), 4562, 144, 63, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 1018940;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"Microsoft","d":1018940,"h":4295986236,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1018940,"h":8590953532,"f":1}],"h":1018940}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageVendor`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.SymbolStore.SymLanguageType", ($self) => class SymLanguageType extends $.$spc.System.Object
        {
            /*Guid*/ static C;
            /*Guid*/ static CPlusPlus;
            /*Guid*/ static CSharp;
            /*Guid*/ static Basic;
            /*Guid*/ static Java;
            /*Guid*/ static Cobol;
            /*Guid*/ static Pascal;
            /*Guid*/ static ILAssembly;
            /*Guid*/ static JScript;
            /*Guid*/ static SMC;
            /*Guid*/ static MCPlusPlus;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.C = new $.$spc.System.Guid().$ctor$7(1671464724, $.$cast(64567, $.$spc.System.Int16), 4562, 144, 76, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.CPlusPlus = new $.$spc.System.Guid().$ctor$7(974311607, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.CSharp = new $.$spc.System.Guid().$ctor$7(1062298360, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
                {
                    this.Basic = new $.$spc.System.Guid().$ctor$7(974311608, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Java = new $.$spc.System.Guid().$ctor$7(974311604, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.Cobol = new $.$spc.System.Guid().$ctor$7((2936302801 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.Pascal = new $.$spc.System.Guid().$ctor$7((2936302802 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.ILAssembly = new $.$spc.System.Guid().$ctor$7((2936302803 | 0), $.$cast(53473, $.$spc.System.Int16), 4562, 151, 124, 0, 160, 201, 180, 213, 12);
                }
                {
                    this.JScript = new $.$spc.System.Guid().$ctor$7(974311606, $.$cast(49772, $.$spc.System.Int16), 4560, 180, 66, 0, 160, 36, 74, 29, 210);
                }
                {
                    this.SMC = new $.$spc.System.Guid().$ctor$7(228302715, 26129, 4563, 189, 42, 0, 0, 248, 8, 73, 189);
                }
                {
                    this.MCPlusPlus = new $.$spc.System.Guid().$ctor$7(1261829608, 1990, 4563, 144, 83, 0, 192, 79, 163, 2, 161);
                }
            }
            static $h = 953404;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":56164353,"n":"C","d":953404,"h":4295920700,"f":33},{"t":56164353,"n":"CPlusPlus","d":953404,"h":8590887996,"f":33},{"t":56164353,"n":"CSharp","d":953404,"h":12885855292,"f":33},{"t":56164353,"n":"Basic","d":953404,"h":17180822588,"f":33},{"t":56164353,"n":"Java","d":953404,"h":21475789884,"f":33},{"t":56164353,"n":"Cobol","d":953404,"h":25770757180,"f":33},{"t":56164353,"n":"Pascal","d":953404,"h":30065724476,"f":33},{"t":56164353,"n":"ILAssembly","d":953404,"h":34360691772,"f":33},{"t":56164353,"n":"JScript","d":953404,"h":38655659068,"f":33},{"t":56164353,"n":"SMC","d":953404,"h":42950626364,"f":33},{"t":56164353,"n":"MCPlusPlus","d":953404,"h":47245593660,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":953404,"h":51540560956,"f":1}],"h":953404}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymLanguageType`; }
        });
        
        $asm.$cls("$sds.System.Diagnostics.StackTraceSymbols", ($self) => class StackTraceSymbols extends $.$spc.System.Object
        {
            /*ConditionalWeakTable<Assembly, MetadataReaderProvider?>*/ _metadataCache = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._metadataCache = new ($.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider))().$ctor$1();
                }
                return this;
            }
            /*void */ System$IDisposable$Dispose()
            {
                var $en2 = this._metadataCache.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var $t1 = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    $.$discardRef() = $t1.Item1;
                    /*MetadataReaderProvider?*/ let provider = $t1.Item2;
                    {
                        provider?.Dispose();
                    }
                }
                this._metadataCache.Clear();
            }
            /*void */ GetSourceLineInfo(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize, /*int*/ methodToken, /*int*/ ilOffset, /*out string?*/ sourceFile, /*out int*/ sourceLine, /*out int*/ sourceColumn)
            {
                sourceFile.$v = null;
                sourceLine.$v = 0;
                sourceColumn.$v = 0;
                /*Handle*/ let handle = $.$srm.System.Reflection.Metadata.Ecma335.MetadataTokens.Handle(methodToken);
                if (!handle.IsNil && handle.Kind === 6/*HandleKind.MethodDefinition*/)
                {
                    /*MetadataReader?*/ let reader = this.TryGetReader(assembly, assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout, inMemoryPdbAddress, inMemoryPdbSize);
                    if (reader !== null)
                    {
                        /*MethodDebugInformationHandle*/ let methodDebugHandle = ($.$srm.System.Reflection.Metadata.MethodDefinitionHandle.op_Explicit(handle)).ToDebugInformationHandle();
                        /*MethodDebugInformation*/ let methodInfo = reader.GetMethodDebugInformation(methodDebugHandle);
                        if (!methodInfo.SequencePointsBlob.IsNil)
                        {
                            /*SequencePointCollection*/ let sequencePoints = methodInfo.GetSequencePoints();
                            /*SequencePoint?*/ let bestPointSoFar = null;
                            var $en5 = sequencePoints.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var point = $en5.Current;
                                {
                                    if (point.Offset > ilOffset)
                                    {
                                        break;
                                    }
                                    if (point.StartLine !== 16707566/*SequencePoint.HiddenLine*/)
                                    {
                                        bestPointSoFar = point;
                                    }
                                }
                            }
                            if ($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).HasValue$get.call(bestPointSoFar))
                            {
                                sourceLine.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartLine;
                                sourceColumn.$v = $.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).StartColumn;
                                sourceFile.$v = reader.GetString$2(reader.GetDocument($.$spc.System.Nullable$$($.$srm.System.Reflection.Metadata.SequencePoint).Value$get.call(bestPointSoFar).Document).Name);
                            }
                        }
                    }
                }
            }
            /*MetadataReader? */ TryGetReader(/*Assembly*/ assembly, /*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout, /*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                if (loadedPeAddress === $.$spc.System.IntPtr.Zero && $.$spc.System.String.op_Equality(assemblyPath, null) && inMemoryPdbAddress === $.$spc.System.IntPtr.Zero)
                {
                    return null;
                }
                /*MetadataReaderProvider?*/ let provider;
                while(!this._metadataCache.TryGetValue(assembly, $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider)))
                {
                    provider = inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero ? $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderForInMemoryPdb(inMemoryPdbAddress, inMemoryPdbSize) : $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenReaderFromAssemblyFile(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (this._metadataCache.TryAdd(assembly, provider))
                    {
                        break;
                    }
                    provider?.Dispose();
                }
                return provider?.GetMetadataReader(1, null);
            }
            static /*MetadataReaderProvider? */ TryOpenReaderForInMemoryPdb(/*IntPtr*/ inMemoryPdbAddress, /*int*/ inMemoryPdbSize)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(inMemoryPdbAddress !== $.$spc.System.IntPtr.Zero, "inMemoryPdbAddress != IntPtr.Zero");
                /*uint*/ let ManagedMetadataSignature = 1112167234;
                if (inMemoryPdbSize < $.$spc.System.UInt32.$z || $.$spc.InteropUtility.castAddress2Object(inMemoryPdbAddress) !== ManagedMetadataSignature)
                {
                    return null;
                }
                /*var*/ let provider = $.$srm.System.Reflection.Metadata.MetadataReaderProvider.FromMetadataImage($.$cast(inMemoryPdbAddress, $.$typePointer($.$spc.System.Byte)), inMemoryPdbSize);
                try
                {
                    provider.GetMetadataReader(1, null);
                    return provider;
                }
                catch($e)
                {
                    provider.Dispose();
                    return null;
                }
            }
            static /*PEReader? */ TryGetPEReader(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                if (loadedPeAddress !== $.$spc.System.IntPtr.Zero && loadedPeSize > 0)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$2($.$cast(loadedPeAddress, $.$typePointer($.$spc.System.Byte)), loadedPeSize, !isFileLayout);
                }
                /*Stream?*/ let peStream = $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile(assemblyPath);
                if (peStream !== null)
                {
                    return new $.$srm.System.Reflection.PortableExecutable.PEReader().$ctor$3(peStream);
                }
                return null;
            }
            static /*MetadataReaderProvider? */ TryOpenReaderFromAssemblyFile(/*string*/ assemblyPath, /*IntPtr*/ loadedPeAddress, /*int*/ loadedPeSize, /*bool*/ isFileLayout)
            {
                let peReader = null;
                try
                {
                    peReader = $.$sds.System.Diagnostics.StackTraceSymbols.TryGetPEReader(assemblyPath, loadedPeAddress, loadedPeSize, isFileLayout);
                    if (peReader === null)
                    {
                        return null;
                    }
                    if (!(assemblyPath === null))
                    {
                        /*string?*/ let pdbPath;
                        /*MetadataReaderProvider?*/ let provider;
                        if (peReader.TryOpenAssociatedPortablePdb(assemblyPath, new ($.$spc.System.Func$$$($.$spc.System.String, $.$spc.System.IO.Stream))().$ctor(null, $.$sds.System.Diagnostics.StackTraceSymbols.TryOpenFile), $.$ref(() => provider, ($v) => provider = $v, $.$srm.System.Reflection.Metadata.MetadataReaderProvider), $.$ref(() => pdbPath, ($v) => pdbPath = $v, $.$spc.System.String)))
                        {
                            return provider;
                        }
                    }
                    var $en3 = peReader.ReadDebugDirectory().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var entry = $en3.Current;
                        {
                            if (entry.Type === 17/*DebugDirectoryEntryType.EmbeddedPortablePdb*/)
                            {
                                try
                                {
                                    return peReader.ReadEmbeddedPortablePdbDebugDirectoryData(entry);
                                }
                                catch(e)
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                finally
                {
                    peReader?.System$IDisposable$Dispose();
                }
                return null;
            }
            static /*Stream? */ TryOpenFile(/*string*/ path)
            {
                if (!$.$spc.System.IO.File.Exists(path))
                {
                    return null;
                }
                try
                {
                    return new $.$spc.System.IO.FileStream().$ctor$12(path, 3/*FileMode.Open*/, 1/*FileAccess.Read*/, 1/*FileShare.Read*/ | 4/*FileShare.Delete*/);
                }
                catch($e)
                {
                    return null;
                }
            }
            static $h = 101436;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361},{"n":"methodToken","p":655361},{"n":"ilOffset","p":655361},{"n":"sourceFile","p":1310721,"f":2},{"n":"sourceLine","p":655361,"f":2},{"n":"sourceColumn","p":655361,"f":2}],"n":"GetSourceLineInfo","d":101436,"h":17179970620,"f":8},{"r":24616909,"p":[{"n":"assembly","p":73465857},{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145},{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryGetReader","d":101436,"h":21474937916,"f":2},{"r":24813517,"p":[{"n":"inMemoryPdbAddress","p":786433},{"n":"inMemoryPdbSize","p":655361}],"n":"TryOpenReaderForInMemoryPdb","d":101436,"h":25769905212,"f":34},{"r":31629261,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryGetPEReader","d":101436,"h":30064872508,"f":34},{"r":24813517,"p":[{"n":"assemblyPath","p":1310721},{"n":"loadedPeAddress","p":786433},{"n":"loadedPeSize","p":655361},{"n":"isFileLayout","p":262145}],"n":"TryOpenReaderFromAssemblyFile","d":101436,"h":34359839804,"f":34},{"r":62128129,"p":[{"n":"path","p":1310721}],"n":"TryOpenFile","d":101436,"h":38654807100,"f":34}],"l":[{"t":$.$spc.System.Runtime.CompilerServices.ConditionalWeakTable$$$($.$spc.System.Reflection.Assembly, $.$srm.System.Reflection.Metadata.MetadataReaderProvider).$h,"n":"_metadataCache","d":101436,"h":4295068732,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":101436,"h":8590036028,"f":1}],"i":[57475073],"h":101436}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.StackTraceSymbols`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymbolToken", ($self) => class SymbolToken extends $.$spc.System.ValueType
        {
            /*int*/  get _token() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set _token(value) { this.$setField(0, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ val)
            {
                super.$ctor$1();
                {
                    this._token = val;
                }
                return this;
            }
            /*int */ GetToken()
            {
                return this._token;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return this._token;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                if ($.$is(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken))
                {
                    return this.Equals$2($.$cast(obj, $.$sds.System.Diagnostics.SymbolStore.SymbolToken));
                }
                else 
                {
                    return false;
                }
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sds.System.Diagnostics.SymbolStore.SymbolToken.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SymbolToken*/ obj)
            {
                return obj._token === this._token;
            }
            static /*bool */ op_Equality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return a.Equals$2(b);
            }
            static /*bool */ op_Inequality(/*SymbolToken*/ a, /*SymbolToken*/ b)
            {
                return !($.$sds.System.Diagnostics.SymbolStore.SymbolToken.op_Equality(a, b));
            }
            //Generated interface implemetation for System.IEquatable<System.Diagnostics.SymbolStore.SymbolToken>.Equals(System.Diagnostics.SymbolStore.SymbolToken)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._token = this._token;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._token = 0;
            }
            static $h = 822332;
            static $z = 4;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetToken","d":822332,"h":12885724220,"f":1},{"r":655361,"n":"GetHashCode","d":822332,"h":17180691516,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":822332,"h":21475658812,"f":32769},{"r":262145,"p":[{"n":"obj","p":822332}],"n":"Equals","o":"@$2","d":822332,"h":25770626108,"f":1}],"l":[{"t":655361,"n":"_token","d":822332,"h":4295789628,"f":2}],"c":[{"p":[{"n":"val","p":655361}],"n":".ctor","o":"$ctor$2","d":822332,"h":8590756924,"f":1},{"n":".ctor","o":"$ctor$3","d":822332,"h":38655527996,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken).$h],"h":822332}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sds.System.Diagnostics.SymbolStore.SymbolToken) ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymbolToken`; }
        });
        
        $asm.$str("$sds.System.Diagnostics.SymbolStore.SymAddressKind", ($self) => class SymAddressKind extends $.$spc.System.Enum
        {
            static ILOffset = 1;
            static NativeRVA = 2;
            static NativeRegister = 3;
            static NativeRegisterRelative = 4;
            static NativeOffset = 5;
            static NativeRegisterRegister = 6;
            static NativeRegisterStack = 7;
            static NativeStackRegister = 8;
            static BitField = 9;
            static NativeSectionOffset = 10;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ILOffset": 1n,
                    "NativeRVA": 2n,
                    "NativeRegister": 3n,
                    "NativeRegisterRelative": 4n,
                    "NativeOffset": 5n,
                    "NativeRegisterRegister": 6n,
                    "NativeRegisterStack": 7n,
                    "NativeStackRegister": 8n,
                    "BitField": 9n,
                    "NativeSectionOffset": 10n
                };
            }
            static $h = 756796;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":756796,"n":"ILOffset","d":756796,"h":4295724092,"f":33},{"t":756796,"n":"NativeRVA","d":756796,"h":8590691388,"f":33},{"t":756796,"n":"NativeRegister","d":756796,"h":12885658684,"f":33},{"t":756796,"n":"NativeRegisterRelative","d":756796,"h":17180625980,"f":33},{"t":756796,"n":"NativeOffset","d":756796,"h":21475593276,"f":33},{"t":756796,"n":"NativeRegisterRegister","d":756796,"h":25770560572,"f":33},{"t":756796,"n":"NativeRegisterStack","d":756796,"h":30065527868,"f":33},{"t":756796,"n":"NativeStackRegister","d":756796,"h":34360495164,"f":33},{"t":756796,"n":"BitField","d":756796,"h":38655462460,"f":33},{"t":756796,"n":"NativeSectionOffset","d":756796,"h":42950429756,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":756796,"h":47245397052,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":756796}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SymbolStore.SymAddressKind`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Thread", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Reflection.Metadata"))