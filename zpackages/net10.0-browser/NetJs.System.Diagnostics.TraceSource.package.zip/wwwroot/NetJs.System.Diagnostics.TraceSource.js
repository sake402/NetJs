
//--TRIMMABLE-BOUNDARY-START(45)
(async function () {
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.TraceSource", 
    {
  "h": 45,
  "f": "System.Diagnostics.TraceSource",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.TraceSource",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Diagnostics.TraceSource",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1245229)
        $asm.$cls(`$sdts.SD.TraceFilter`, ($self) => class TraceFilter extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476081709)
            /*bool */ ShouldTrace$3(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, null, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(21476081709)
            
            //--TRIMMABLE-BOUNDARY-START(17181114413)
            /*bool */ ShouldTrace$2(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, null, null);
            }
            //--TRIMMABLE-BOUNDARY-END(17181114413)
            
            //--TRIMMABLE-BOUNDARY-START(12886147117)
            /*bool */ ShouldTrace$1(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886147117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, data1, null);
            }
            //--TRIMMABLE-BOUNDARY-END(12886147117)
            
            //--TRIMMABLE-BOUNDARY-START(4296212525)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212525)
            
            //--TRIMMABLE-BOUNDARY-START(4296212525)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296212525)
            
            static $h = 1245229;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591179821),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "data1",
          "p": 131073
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ShouldTrace",
      "d": 1245229,
      "h": 8591179821,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8591179821),
//--TRIMMABLE-BOUNDARY-START(21476081709),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        }
      ],
      "n": "ShouldTrace",
      "o": "@$3",
      "d": 1245229,
      "h": 21476081709,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21476081709),
//--TRIMMABLE-BOUNDARY-START(17181114413),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ShouldTrace",
      "o": "@$2",
      "d": 1245229,
      "h": 17181114413,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17181114413),
//--TRIMMABLE-BOUNDARY-START(12886147117),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "data1",
          "p": 131073
        }
      ],
      "n": "ShouldTrace",
      "o": "@$1",
      "d": 1245229,
      "h": 12886147117,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12886147117)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212525),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1245229,
      "h": 4296212525,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296212525)
  ],
  "h": 1245229
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245229)
        
        

        //--TRIMMABLE-BOUNDARY-START(852013)
        $asm.$cls(`$sdts.SD.Switch`, ($self) => class Switch extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885753901)
            /*string?*/ _description = null;
            //--TRIMMABLE-BOUNDARY-END(12885753901)
            
            //--TRIMMABLE-BOUNDARY-START(17180721197)
            /*string*/ _displayName = null;
            //--TRIMMABLE-BOUNDARY-END(17180721197)
            
            //--TRIMMABLE-BOUNDARY-START(34360590381)
            /*int*/ _switchSetting = 0;
            //--TRIMMABLE-BOUNDARY-END(34360590381)
            
            //--TRIMMABLE-BOUNDARY-START(21475688493)
            /*bool*/ _initialized = false;
            //--TRIMMABLE-BOUNDARY-END(21475688493)
            
            //--TRIMMABLE-BOUNDARY-START(25770655789)
            /*bool*/ _initializing = false;
            //--TRIMMABLE-BOUNDARY-END(25770655789)
            
            //--TRIMMABLE-BOUNDARY-START(38655557677)
            /*string?*/ _switchValueString = null;
            //--TRIMMABLE-BOUNDARY-END(38655557677)
            
            //--TRIMMABLE-BOUNDARY-START(8590786605)
            /*string*/ _defaultValue = null;
            //--TRIMMABLE-BOUNDARY-END(8590786605)
            
            //--TRIMMABLE-BOUNDARY-START(201864314925)
            /*List<WeakReference<Switch>>*/ static s_switches = null;
            //--TRIMMABLE-BOUNDARY-END(201864314925)
            
            //--TRIMMABLE-BOUNDARY-START(197569347629)
            /*int*/ static s_LastCollectionCount = 0;
            //--TRIMMABLE-BOUNDARY-END(197569347629)
            
            //--TRIMMABLE-BOUNDARY-START(4295819309)
            /*StringDictionary?*/ _attributes = null;
            //--TRIMMABLE-BOUNDARY-END(4295819309)
            
            //--TRIMMABLE-BOUNDARY-START(154619674669)
            /*object*/ $InitializedLock = null;
            /*object */ get InitializedLock()
            {
                return this.InitializedLock$ ?? $.$$.ST$1.Interlocked.CompareExchange$7($.$ref(() => this.InitializedLock$, ($v) => this.InitializedLock$ = $v, $.$$.S.Object), new $.$$.S.Object().$ctor(), null) ?? this.InitializedLock$;
            }
            //--TRIMMABLE-BOUNDARY-END(154619674669)
            
            //--TRIMMABLE-BOUNDARY-START(55835426861)
            $ctor$2(/*string*/ displayName, /*string?*/ description)
            {
                this.$ctor$1(displayName, description, "0");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835426861);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835426861)
            
            //--TRIMMABLE-BOUNDARY-START(51540459565)
            $ctor$1(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540459565);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._displayName = displayName ?? $.$$.S.String.Empty;
                    this._description = description;
                    //lock(s_switches)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.Switch.s_switches)
                        {
                            $.$sdts.SD.Switch._pruneCachedSwitches();
                            $.$sdts.SD.Switch.s_switches.Add(new ($.$$.S.WeakReference$$($.$sdts.SD.Switch))().$ctor$3(this));
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.Switch.s_switches)
                    }
                    this._defaultValue = defaultSwitchValue;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540459565)
            
            //--TRIMMABLE-BOUNDARY-START(30065623085)
            static /*void */ _pruneCachedSwitches()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065623085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(s_switches)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.Switch.s_switches)
                    {
                        if ($.$sdts.SD.Switch.s_LastCollectionCount !== $.$$.S.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<Switch>>*/ let buffer = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.Switch)))().$ctor$3($.$sdts.SD.Switch.s_switches.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.SD.Switch.s_switches.Count; i++)
                            {
                                if ($.$sdts.SD.Switch.s_switches.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.SD.Switch.s_switches.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.SD.Switch.s_switches.Count)
                            {
                                $.$sdts.SD.Switch.s_switches.Clear();
                                $.$sdts.SD.Switch.s_switches.AddRange(buffer);
                                $.$sdts.SD.Switch.s_switches.TrimExcess();
                            }
                            $.$sdts.SD.Switch.s_LastCollectionCount = $.$$.S.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.Switch.s_switches)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065623085)
            
            //--TRIMMABLE-BOUNDARY-START(81605230637)
            /*string */ get DisplayName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964969005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._displayName;
            }
            //--TRIMMABLE-BOUNDARY-END(81605230637)
            
            //--TRIMMABLE-BOUNDARY-START(77310263341)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375034413);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._description ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(77310263341)
            
            //--TRIMMABLE-BOUNDARY-START(68720328749)
            /*StringDictionary */ get Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195165229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                return this._attributes ??= new $.$scs.SCS.StringDictionary().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(68720328749)
            
            //--TRIMMABLE-BOUNDARY-START(227634118701)
            /*int */ get SwitchSetting()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144838189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._initialized)
                {
                    if (this.InitializeWithStatus())
                    {
                        this.OnSwitchSettingChanged();
                    }
                }
                return this._switchSetting;
            }
            /*int */ set SwitchSetting(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454249517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let didUpdate = false;
                //lock(InitializedLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._initialized = true;
                        if (this._switchSetting !== value)
                        {
                            this._switchSetting = value;
                            didUpdate = true;
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.InitializedLock)
                }
                if (didUpdate)
                {
                    this.OnSwitchSettingChanged();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634118701)
            
            //--TRIMMABLE-BOUNDARY-START(146029740077)
            /*string[]? */ GetSupportedAttributes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029740077);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029740077)
            
            //--TRIMMABLE-BOUNDARY-START(223339151405)
            /*void */ SetSwitchValues(/*int*/ switchSetting, /*string*/ switchValueString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339151405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                $.$$.SD.Debug.Assert$4(!(switchValueString === null), "Unexpected 'switchValueString' null value");
                //lock(InitializedLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._switchSetting = switchSetting;
                        this._switchValueString = switchValueString;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.InitializedLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339151405)
            
            //--TRIMMABLE-BOUNDARY-START(73015296045)
            /*string */ get DefaultValue()
            {
                return this._defaultValue;
            }
            //--TRIMMABLE-BOUNDARY-END(73015296045)
            
            //--TRIMMABLE-BOUNDARY-START(231929085997)
            /*string */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734772781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                return this._switchValueString;
            }
            /*string */ set Value(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044184109);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                this._switchValueString = value;
                this.OnValueChanged();
            }
            //--TRIMMABLE-BOUNDARY-END(231929085997)
            
            //--TRIMMABLE-BOUNDARY-START(163209609261)
            /*EventHandler<InitializingSwitchEventArgs>?*/ static Initializing = null;
            //--TRIMMABLE-BOUNDARY-END(163209609261)
            
            //--TRIMMABLE-BOUNDARY-START(163209609261)
            //--TRIMMABLE-BOUNDARY-START(64425361453)
            static add_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425361453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Switch.Initializing = $.$$.S.Delegate.Combine$2($.$sdts.SD.Switch.Initializing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(64425361453)
            
            //--TRIMMABLE-BOUNDARY-START(193274380333)
            static remove_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274380333);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Switch.Initializing = $.$$.S.Delegate.Remove($.$sdts.SD.Switch.Initializing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(193274380333)
            
            //--TRIMMABLE-BOUNDARY-END(163209609261)
            
            //--TRIMMABLE-BOUNDARY-START(167504576557)
            /*void */ OnInitializing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504576557);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Switch.Initializing?.Invoke(null, new $.$sdts.SD.InitializingSwitchEventArgs().$ctor$2(this));
                $.$sdts.SD.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
            }
            //--TRIMMABLE-BOUNDARY-END(167504576557)
            
            //--TRIMMABLE-BOUNDARY-START(150324707373)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324707373);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.InitializeWithStatus();
            }
            //--TRIMMABLE-BOUNDARY-END(150324707373)
            
            //--TRIMMABLE-BOUNDARY-START(158914641965)
            /*bool */ InitializeWithStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914641965);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._initialized)
                {
                    //lock(InitializedLock)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this.InitializedLock)
                        {
                            if (this._initialized || this._initializing)
                            {
                                return false;
                            }
                            this._initializing = true;
                            this._switchValueString = null;
                            try
                            {
                                this.OnInitializing();
                            }
                            catch($e)
                            {
                                this._initialized = false;
                                this._initializing = false;
                                throw $e;
                            }
                            if (this._switchValueString === null)
                            {
                                this._switchValueString = this._defaultValue;
                                this.OnValueChanged();
                            }
                            this._initialized = true;
                            this._initializing = false;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this.InitializedLock)
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(158914641965)
            
            //--TRIMMABLE-BOUNDARY-START(171799543853)
            /*void */ OnSwitchSettingChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799543853);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(171799543853)
            
            //--TRIMMABLE-BOUNDARY-START(176094511149)
            /*void */ OnValueChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094511149);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SwitchSetting = $.$$.S.Int32.Parse$6(this.Value, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(176094511149)
            
            //--TRIMMABLE-BOUNDARY-START(184684445741)
            static /*void */ RefreshAll()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684445741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(s_switches)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.Switch.s_switches)
                    {
                        $.$sdts.SD.Switch._pruneCachedSwitches();
                        for(/*int*/ let i = 0; i < $.$sdts.SD.Switch.s_switches.Count; i++)
                        {
                            /*Switch?*/ let swtch;
                            if ($.$sdts.SD.Switch.s_switches.get_Item(i).TryGetTarget($.$ref(() => swtch, ($v) => swtch = $v, $.$sdts.SD.Switch)))
                            {
                                swtch.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.Switch.s_switches)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684445741)
            
            //--TRIMMABLE-BOUNDARY-START(180389478445)
            /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389478445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(InitializedLock)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._initialized = false;
                        this.Initialize();
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit(this.InitializedLock)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389478445)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(38655557677)
                this._switchValueString = $.$$.S.String.Empty;
                //--TRIMMABLE-BOUNDARY-END(38655557677)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47245492269)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245492269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(201864314925)
                    this.s_switches = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.Switch)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(201864314925)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245492269)
            
            static $h = 852013;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(154619674669),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554903597,
        "f": 50331650
      },
      "n": "InitializedLock",
      "d": 852013,
      "h": 154619674669,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(154619674669),
//--TRIMMABLE-BOUNDARY-START(81605230637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964969005,
        "f": 50331649
      },
      "n": "DisplayName",
      "d": 852013,
      "h": 81605230637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605230637),
//--TRIMMABLE-BOUNDARY-START(77310263341),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375034413,
        "f": 50331649
      },
      "n": "Description",
      "d": 852013,
      "h": 77310263341,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77310263341),
//--TRIMMABLE-BOUNDARY-START(68720328749),
    {
      "p": 1310737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195165229,
        "f": 50331649
      },
      "n": "Attributes",
      "d": 852013,
      "h": 68720328749,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720328749),
//--TRIMMABLE-BOUNDARY-START(227634118701),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144838189,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454249517,
        "f": 83886084
      },
      "n": "SwitchSetting",
      "d": 852013,
      "h": 227634118701,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(227634118701),
//--TRIMMABLE-BOUNDARY-START(73015296045),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785099821,
        "f": 50331649
      },
      "n": "DefaultValue",
      "d": 852013,
      "h": 73015296045,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73015296045),
//--TRIMMABLE-BOUNDARY-START(231929085997),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734772781,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044184109,
        "f": 83886081
      },
      "n": "Value",
      "d": 852013,
      "h": 231929085997,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(231929085997)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065623085),
    {
      "r": 65537,
      "n": "_pruneCachedSwitches",
      "d": 852013,
      "h": 30065623085,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065623085),
//--TRIMMABLE-BOUNDARY-START(146029740077),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetSupportedAttributes",
      "d": 852013,
      "h": 146029740077,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(146029740077),
//--TRIMMABLE-BOUNDARY-START(223339151405),
    {
      "r": 65537,
      "p": [
        {
          "n": "switchSetting",
          "p": 655361
        },
        {
          "n": "switchValueString",
          "p": 1310721
        }
      ],
      "n": "SetSwitchValues",
      "d": 852013,
      "h": 223339151405,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(223339151405),
//--TRIMMABLE-BOUNDARY-START(167504576557),
    {
      "r": 65537,
      "n": "OnInitializing",
      "d": 852013,
      "h": 167504576557,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(167504576557),
//--TRIMMABLE-BOUNDARY-START(150324707373),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 852013,
      "h": 150324707373,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324707373),
//--TRIMMABLE-BOUNDARY-START(158914641965),
    {
      "r": 262145,
      "n": "InitializeWithStatus",
      "d": 852013,
      "h": 158914641965,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914641965),
//--TRIMMABLE-BOUNDARY-START(171799543853),
    {
      "r": 65537,
      "n": "OnSwitchSettingChanged",
      "d": 852013,
      "h": 171799543853,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(171799543853),
//--TRIMMABLE-BOUNDARY-START(176094511149),
    {
      "r": 65537,
      "n": "OnValueChanged",
      "d": 852013,
      "h": 176094511149,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(176094511149),
//--TRIMMABLE-BOUNDARY-START(184684445741),
    {
      "r": 65537,
      "n": "RefreshAll",
      "d": 852013,
      "h": 184684445741,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(184684445741),
//--TRIMMABLE-BOUNDARY-START(180389478445),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 852013,
      "h": 180389478445,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389478445)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753901),
    {
      "t": 1310721,
      "n": "_description",
      "d": 852013,
      "h": 12885753901,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885753901),
//--TRIMMABLE-BOUNDARY-START(17180721197),
    {
      "t": 1310721,
      "n": "_displayName",
      "d": 852013,
      "h": 17180721197,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180721197),
//--TRIMMABLE-BOUNDARY-START(34360590381),
    {
      "t": 655361,
      "n": "_switchSetting",
      "d": 852013,
      "h": 34360590381,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360590381),
//--TRIMMABLE-BOUNDARY-START(21475688493),
    {
      "t": 262145,
      "n": "_initialized",
      "d": 852013,
      "h": 21475688493,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475688493),
//--TRIMMABLE-BOUNDARY-START(25770655789),
    {
      "t": 262145,
      "n": "_initializing",
      "d": 852013,
      "h": 25770655789,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25770655789),
//--TRIMMABLE-BOUNDARY-START(38655557677),
    {
      "t": 1310721,
      "n": "_switchValueString",
      "d": 852013,
      "h": 38655557677,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(38655557677),
//--TRIMMABLE-BOUNDARY-START(8590786605),
    {
      "t": 1310721,
      "n": "_defaultValue",
      "d": 852013,
      "h": 8590786605,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590786605),
//--TRIMMABLE-BOUNDARY-START(201864314925),
    {
      "t": $.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.Switch)).$h,
      "n": "s_switches",
      "d": 852013,
      "h": 201864314925,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(201864314925),
//--TRIMMABLE-BOUNDARY-START(197569347629),
    {
      "t": 655361,
      "n": "s_LastCollectionCount",
      "d": 852013,
      "h": 197569347629,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(197569347629),
//--TRIMMABLE-BOUNDARY-START(4295819309),
    {
      "t": 1310737,
      "n": "_attributes",
      "d": 852013,
      "h": 4295819309,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295819309)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(55835426861),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 852013,
      "h": 55835426861,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(55835426861),
//--TRIMMABLE-BOUNDARY-START(51540459565),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "defaultSwitchValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852013,
      "h": 51540459565,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(51540459565)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(163209609261),
    {
      "e": $.$$.S.EventHandler$$($.$sdts.SD.InitializingSwitchEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$sdts.SD.InitializingSwitchEventArgs).$h
          }
        ],
        "n": "add_Initializing",
        "d": 852013,
        "h": 64425361453,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$sdts.SD.InitializingSwitchEventArgs).$h
          }
        ],
        "n": "remove_Initializing",
        "d": 852013,
        "h": 193274380333,
        "f": 285212705
      },
      "n": "Initializing",
      "d": 852013,
      "h": 163209609261,
      "f": 8388641
    },
//--TRIMMABLE-BOUNDARY-END(163209609261)
  ],
  "h": 852013
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.Switch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}Switch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852013)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507373)
        $asm.$cls(`$sdts.SD.TraceListener`, ($self) => class TraceListener extends $.$$.S.MarshalByRefObject
        {
            //--TRIMMABLE-BOUNDARY-START(8591441965)
            /*int*/ _indentLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(8591441965)
            
            //--TRIMMABLE-BOUNDARY-START(12886409261)
            /*int*/ _indentSize = 4;
            //--TRIMMABLE-BOUNDARY-END(12886409261)
            
            //--TRIMMABLE-BOUNDARY-START(25771311149)
            /*TraceOptions*/ _traceOptions = 0;
            //--TRIMMABLE-BOUNDARY-END(25771311149)
            
            //--TRIMMABLE-BOUNDARY-START(21476343853)
            /*bool*/ _needIndent = true;
            //--TRIMMABLE-BOUNDARY-END(21476343853)
            
            //--TRIMMABLE-BOUNDARY-START(17181376557)
            /*string?*/ _listenerName = null;
            //--TRIMMABLE-BOUNDARY-END(17181376557)
            
            //--TRIMMABLE-BOUNDARY-START(4296474669)
            /*TraceFilter?*/ _filter = null;
            //--TRIMMABLE-BOUNDARY-END(4296474669)
            
            //--TRIMMABLE-BOUNDARY-START(34361245741)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34361245741);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34361245741)
            
            //--TRIMMABLE-BOUNDARY-START(38656213037)
            $ctor$3(/*string?*/ name)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38656213037);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._listenerName = name;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38656213037)
            
            //--TRIMMABLE-BOUNDARY-START(42951180333)
            /*StringDictionary*/ $Attributes = null;
            /*StringDictionary */ get Attributes()
            {
                return this.Attributes$ ??= new $.$scs.SCS.StringDictionary().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(42951180333)
            
            //--TRIMMABLE-BOUNDARY-START(167505231917)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555558957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._listenerName ?? "";
            }
            /*string */ set Name(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159937581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._listenerName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(167505231917)
            
            //--TRIMMABLE-BOUNDARY-START(163210264621)
            /*bool */ get IsThreadSafe()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624365);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(163210264621)
            
            //--TRIMMABLE-BOUNDARY-START(51541114925)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114925);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(51541114925)
            
            //--TRIMMABLE-BOUNDARY-START(55836082221)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082221);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return;
            }
            //--TRIMMABLE-BOUNDARY-END(55836082221)
            
            //--TRIMMABLE-BOUNDARY-START(73015951405)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951405);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return;
            }
            //--TRIMMABLE-BOUNDARY-END(73015951405)
            
            //--TRIMMABLE-BOUNDARY-START(150325362733)
            /*int */ get IndentLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._indentLevel;
            }
            /*int */ set IndentLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980068397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._indentLevel = (value < 0) ? 0 : value;
            }
            //--TRIMMABLE-BOUNDARY-END(150325362733)
            
            //--TRIMMABLE-BOUNDARY-START(154620330029)
            /*int */ get IndentSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689773);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._indentSize;
            }
            /*int */ set IndentSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570002989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$18("IndentSize", $.$box(value, $.$$.S.Int32), $.$sdts.S.SR.TraceListenerIndentSize);
                }
                this._indentSize = value;
            }
            //--TRIMMABLE-BOUNDARY-END(154620330029)
            
            //--TRIMMABLE-BOUNDARY-START(68720984109)
            /*TraceFilter? */ get Filter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._filter;
            }
            /*TraceFilter? */ set Filter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390133805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._filter = value;
            }
            //--TRIMMABLE-BOUNDARY-END(68720984109)
            
            //--TRIMMABLE-BOUNDARY-START(171800199213)
            /*bool */ get NeedIndent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145493549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._needIndent;
            }
            /*bool */ set NeedIndent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749872173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._needIndent = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171800199213)
            
            //--TRIMMABLE-BOUNDARY-START(249109610541)
            /*TraceOptions */ get TraceOutputOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735428141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._traceOptions;
            }
            /*TraceOptions */ set TraceOutputOptions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339806765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((value >> 6) !== 0)
                {
                    throw new $.$$.S.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._traceOptions = value;
            }
            //--TRIMMABLE-BOUNDARY-END(249109610541)
            
            //--TRIMMABLE-BOUNDARY-START(47246147629)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147629);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return;
            }
            //--TRIMMABLE-BOUNDARY-END(47246147629)
            
            //--TRIMMABLE-BOUNDARY-START(146030395437)
            /*string[]? */ GetSupportedAttributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030395437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(146030395437)
            
            //--TRIMMABLE-BOUNDARY-START(253404577837)
            /*void */ TraceTransfer(/*TraceEventCache?*/ eventCache, /*string*/ source, /*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404577837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.TraceEvent$1(eventCache, source, 4096/*TraceEventType.Transfer*/, id, $.$$.S.String.Create$6(null, $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 256, null), `${$.$strNN(message)}, relatedActivityId=${$.$strNN(relatedActivityId.ToString())}`));
            }
            //--TRIMMABLE-BOUNDARY-END(253404577837)
            
            //--TRIMMABLE-BOUNDARY-START(64426016813)
            /*void */ Fail$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016813);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Fail(message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(64426016813)
            
            //--TRIMMABLE-BOUNDARY-START(60131049517)
            /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049517);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteLine$3(detailMessage === null ? `${$.$strNN($.$sdts.S.SR.TraceListenerFail)} ${$.$strNN(message)}` : `${$.$strNN($.$sdts.S.SR.TraceListenerFail)} ${$.$strNN(message)} ${$.$strNN(detailMessage)}`);
            }
            //--TRIMMABLE-BOUNDARY-END(60131049517)
            
            //--TRIMMABLE-BOUNDARY-START(261994512429)
            /*void */ Write$1(/*object?*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994512429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                if (o === null)
                {
                    return;
                }
                this.Write$3($.$dspc(o, $.$$.S.Object, ($t) => $t.ToString));
            }
            //--TRIMMABLE-BOUNDARY-END(261994512429)
            
            //--TRIMMABLE-BOUNDARY-START(266289479725)
            /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289479725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if (category === null)
                {
                    this.Write$3(message);
                }
                else 
                {
                    this.Write$3($.$strNN(category) + ": " + $.$strNN((message ?? $.$$.S.String.Empty)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289479725)
            
            //--TRIMMABLE-BOUNDARY-START(257699545133)
            /*void */ Write(/*object?*/ o, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699545133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                if (category === null)
                {
                    this.Write$1(o);
                }
                else 
                {
                    this.Write$2(o === null ? "" : $.$dspc(o, $.$$.S.Object, ($t) => $t.ToString), category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699545133)
            
            //--TRIMMABLE-BOUNDARY-START(283469348909)
            /*void */ WriteIndent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469348909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.NeedIndent = false;
                for(/*int*/ let i = 0; i < this._indentLevel; i++)
                {
                    if (this._indentSize === 4)
                    {
                        this.Write$3("    ");
                    }
                    else 
                    {
                        for(/*int*/ let j = 0; j < this._indentSize; j++)
                        {
                            this.Write$3(" ");
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283469348909)
            
            //--TRIMMABLE-BOUNDARY-START(292059283501)
            /*void */ WriteLine$1(/*object?*/ o)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059283501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                this.WriteLine$3(o === null ? "" : $.$dspc(o, $.$$.S.Object, ($t) => $t.ToString));
            }
            //--TRIMMABLE-BOUNDARY-END(292059283501)
            
            //--TRIMMABLE-BOUNDARY-START(296354250797)
            /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354250797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if (category === null)
                {
                    this.WriteLine$3(message);
                }
                else 
                {
                    this.WriteLine$3($.$strNN(category) + ": " + $.$strNN((message ?? $.$$.S.String.Empty)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(296354250797)
            
            //--TRIMMABLE-BOUNDARY-START(287764316205)
            /*void */ WriteLine(/*object?*/ o, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764316205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                this.WriteLine$2(o === null ? "" : $.$dspc(o, $.$$.S.Object, ($t) => $t.ToString), category);
            }
            //--TRIMMABLE-BOUNDARY-END(287764316205)
            
            //--TRIMMABLE-BOUNDARY-START(227634774061)
            /*void */ TraceData(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634774061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(eventCache, source, eventType, id, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                /*string?*/ let datastring = $.$$.S.String.Empty;
                if (data !== null)
                {
                    datastring = $.$dspc(data, $.$$.S.Object, ($t) => $t.ToString);
                }
                this.WriteLine$3(datastring);
                this.WriteFooter(eventCache);
            }
            //--TRIMMABLE-BOUNDARY-END(227634774061)
            
            //--TRIMMABLE-BOUNDARY-START(231929741357)
            /*void */ TraceData$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929741357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace(eventCache, source, eventType, id, null, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine$3(data !== null ? $.$$.S.String.Join$6(", ", data) : $.$$.S.String.Empty);
                this.WriteFooter(eventCache);
            }
            //--TRIMMABLE-BOUNDARY-END(231929741357)
            
            //--TRIMMABLE-BOUNDARY-START(244814643245)
            /*void */ TraceEvent$2(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814643245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.TraceEvent$1(eventCache, source, eventType, id, $.$$.S.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(244814643245)
            
            //--TRIMMABLE-BOUNDARY-START(240519675949)
            /*void */ TraceEvent$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519675949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(eventCache, source, eventType, id, message))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine$3(message);
                this.WriteFooter(eventCache);
            }
            //--TRIMMABLE-BOUNDARY-END(240519675949)
            
            //--TRIMMABLE-BOUNDARY-START(236224708653)
            /*void */ TraceEvent(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224708653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Filter !== null && !this.Filter.ShouldTrace$2(eventCache, source, eventType, id, format, args))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                if (args !== null)
                {
                    this.WriteLine$3($.$$.S.String.Format$5($.$$.SG.CultureInfo.InvariantCulture, format, args));
                }
                else 
                {
                    this.WriteLine$3(format);
                }
                this.WriteFooter(eventCache);
            }
            //--TRIMMABLE-BOUNDARY-END(236224708653)
            
            //--TRIMMABLE-BOUNDARY-START(279174381613)
            /*void */ WriteHeader(/*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279174381613);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Write$3($.$$.S.String.Create$6($.$$.SG.CultureInfo.InvariantCulture, $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 256, null), `${$.$strNN(source)} ${$.$strNN($.$$.S.Enum.ToStringT($.$sdts.SD.TraceEventType, $.$$.S.UInt32, eventType))}: ${$.$strNN(id)} : `));
            }
            //--TRIMMABLE-BOUNDARY-END(279174381613)
            
            //--TRIMMABLE-BOUNDARY-START(274879414317)
            /*void */ WriteFooter(/*TraceEventCache?*/ eventCache)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879414317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (eventCache === null)
                {
                    return;
                }
                this._indentLevel++;
                if (this.IsEnabled(8/*TraceOptions.ProcessId*/))
                {
                    this.WriteLine$3("ProcessId=" + eventCache.ProcessId);
                }
                if (this.IsEnabled(1/*TraceOptions.LogicalOperationStack*/))
                {
                    this.Write$3("LogicalOperationStack=");
                    /*Stack*/ let operationStack = eventCache.LogicalOperationStack;
                    /*bool*/ let first = true;
                    let $en1 = operationStack.GetEnumerator();
                    while ($en1.SC$1$IEnumerator$MoveNext())
                    {
                        let obj = $en1.SC$1$IEnumerator$Current;
                        {
                            if (!first)
                            {
                                this.Write$3(", ");
                            }
                            else 
                            {
                                first = false;
                            }
                            this.Write$3($.$dsp(obj, $.$$.S.Object, ($t) => $t.ToString));
                        }
                    }
                    this.WriteLine$3($.$$.S.String.Empty);
                }
                /*Span<char>*/ let stackBuffer = $.$$.SRC.RuntimeHelpers.StackAllocSpan($.$$.S.Char, 128, null);
                if (this.IsEnabled(16/*TraceOptions.ThreadId*/))
                {
                    this.WriteLine$3("ThreadId=" + $.$strNN(eventCache.ThreadId));
                }
                if (this.IsEnabled(2/*TraceOptions.DateTime*/))
                {
                    this.WriteLine$3($.$$.S.String.Create$6(null, stackBuffer, (() =>
                    {
                        var $handler = new $.$$.SRC.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("DateTime=");
                        $handler.AppendFormatted($.$box(eventCache.DateTime, $.$$.S.DateTime), null, "o");
                        return $handler.ToStringAndClear                ();
                    })()));
                }
                if (this.IsEnabled(4/*TraceOptions.Timestamp*/))
                {
                    this.WriteLine$3($.$$.S.String.Create$6(null, stackBuffer, `Timestamp=${$.$strNN(eventCache.Timestamp)}`));
                }
                if (this.IsEnabled(32/*TraceOptions.Callstack*/))
                {
                    this.WriteLine$3("Callstack=" + $.$strNN(eventCache.Callstack));
                }
                this._indentLevel--;
            }
            //--TRIMMABLE-BOUNDARY-END(274879414317)
            
            //--TRIMMABLE-BOUNDARY-START(158915297325)
            /*bool */ IsEnabled(/*TraceOptions*/ opts)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915297325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (opts & this.TraceOutputOptions) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(158915297325)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(34361245741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(34361245741)
            
            static $h = 1507373;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MarshalByRefObject; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42951180333),
    {
      "p": 1310737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605885997,
        "f": 50331649
      },
      "n": "Attributes",
      "d": 1507373,
      "h": 42951180333,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951180333),
//--TRIMMABLE-BOUNDARY-START(167505231917),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555558957,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159937581,
        "f": 83886209
      },
      "n": "Name",
      "d": 1507373,
      "h": 167505231917,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(167505231917),
//--TRIMMABLE-BOUNDARY-START(163210264621),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965624365,
        "f": 50331777
      },
      "n": "IsThreadSafe",
      "d": 1507373,
      "h": 163210264621,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(163210264621),
//--TRIMMABLE-BOUNDARY-START(150325362733),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785755181,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188980068397,
        "f": 83886081
      },
      "n": "IndentLevel",
      "d": 1507373,
      "h": 150325362733,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150325362733),
//--TRIMMABLE-BOUNDARY-START(154620330029),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375689773,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570002989,
        "f": 83886081
      },
      "n": "IndentSize",
      "d": 1507373,
      "h": 154620330029,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154620330029),
//--TRIMMABLE-BOUNDARY-START(68720984109),
    {
      "p": 1245229,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195820589,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180390133805,
        "f": 83886081
      },
      "n": "Filter",
      "d": 1507373,
      "h": 68720984109,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720984109),
//--TRIMMABLE-BOUNDARY-START(171800199213),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145493549,
        "f": 50331652
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749872173,
        "f": 83886084
      },
      "n": "NeedIndent",
      "d": 1507373,
      "h": 171800199213,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(171800199213),
//--TRIMMABLE-BOUNDARY-START(249109610541),
    {
      "p": 1638445,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735428141,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339806765,
        "f": 83886081
      },
      "n": "TraceOutputOptions",
      "d": 1507373,
      "h": 249109610541,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(249109610541)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51541114925),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1507373,
      "h": 51541114925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51541114925),
//--TRIMMABLE-BOUNDARY-START(55836082221),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1507373,
      "h": 55836082221,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(55836082221),
//--TRIMMABLE-BOUNDARY-START(73015951405),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1507373,
      "h": 73015951405,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73015951405),
//--TRIMMABLE-BOUNDARY-START(47246147629),
    {
      "r": 65537,
      "n": "Close",
      "d": 1507373,
      "h": 47246147629,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47246147629),
//--TRIMMABLE-BOUNDARY-START(146030395437),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetSupportedAttributes",
      "d": 1507373,
      "h": 146030395437,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(146030395437),
//--TRIMMABLE-BOUNDARY-START(253404577837),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "relatedActivityId",
          "p": 89784321
        }
      ],
      "n": "TraceTransfer",
      "d": 1507373,
      "h": 253404577837,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(253404577837),
//--TRIMMABLE-BOUNDARY-START(64426016813),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 1507373,
      "h": 64426016813,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64426016813),
//--TRIMMABLE-BOUNDARY-START(60131049517),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "d": 1507373,
      "h": 60131049517,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60131049517),
//--TRIMMABLE-BOUNDARY-START(270584447021),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$3",
      "d": 1507373,
      "h": 270584447021,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(270584447021),
//--TRIMMABLE-BOUNDARY-START(261994512429),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1507373,
      "h": 261994512429,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(261994512429),
//--TRIMMABLE-BOUNDARY-START(266289479725),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 1507373,
      "h": 266289479725,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(266289479725),
//--TRIMMABLE-BOUNDARY-START(257699545133),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "d": 1507373,
      "h": 257699545133,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(257699545133),
//--TRIMMABLE-BOUNDARY-START(283469348909),
    {
      "r": 65537,
      "n": "WriteIndent",
      "d": 1507373,
      "h": 283469348909,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(283469348909),
//--TRIMMABLE-BOUNDARY-START(300649218093),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$3",
      "d": 1507373,
      "h": 300649218093,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(300649218093),
//--TRIMMABLE-BOUNDARY-START(292059283501),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$1",
      "d": 1507373,
      "h": 292059283501,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(292059283501),
//--TRIMMABLE-BOUNDARY-START(296354250797),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$2",
      "d": 1507373,
      "h": 296354250797,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(296354250797),
//--TRIMMABLE-BOUNDARY-START(287764316205),
    {
      "r": 65537,
      "p": [
        {
          "n": "o",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "d": 1507373,
      "h": 287764316205,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(287764316205),
//--TRIMMABLE-BOUNDARY-START(227634774061),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": "TraceData",
      "d": 1507373,
      "h": 227634774061,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(227634774061),
//--TRIMMABLE-BOUNDARY-START(231929741357),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceData",
      "o": "@$1",
      "d": 1507373,
      "h": 231929741357,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(231929741357),
//--TRIMMABLE-BOUNDARY-START(244814643245),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "TraceEvent",
      "o": "@$2",
      "d": 1507373,
      "h": 244814643245,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(244814643245),
//--TRIMMABLE-BOUNDARY-START(240519675949),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceEvent",
      "o": "@$1",
      "d": 1507373,
      "h": 240519675949,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(240519675949),
//--TRIMMABLE-BOUNDARY-START(236224708653),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceEvent",
      "d": 1507373,
      "h": 236224708653,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(236224708653),
//--TRIMMABLE-BOUNDARY-START(279174381613),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "WriteHeader",
      "d": 1507373,
      "h": 279174381613,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279174381613),
//--TRIMMABLE-BOUNDARY-START(274879414317),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventCache",
          "p": 1114157
        }
      ],
      "n": "WriteFooter",
      "d": 1507373,
      "h": 274879414317,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274879414317),
//--TRIMMABLE-BOUNDARY-START(158915297325),
    {
      "r": 262145,
      "p": [
        {
          "n": "opts",
          "p": 1638445
        }
      ],
      "n": "IsEnabled",
      "d": 1507373,
      "h": 158915297325,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158915297325)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591441965),
    {
      "t": 655361,
      "n": "_indentLevel",
      "d": 1507373,
      "h": 8591441965,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591441965),
//--TRIMMABLE-BOUNDARY-START(12886409261),
    {
      "t": 655361,
      "n": "_indentSize",
      "d": 1507373,
      "h": 12886409261,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12886409261),
//--TRIMMABLE-BOUNDARY-START(25771311149),
    {
      "t": 1638445,
      "n": "_traceOptions",
      "d": 1507373,
      "h": 25771311149,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(25771311149),
//--TRIMMABLE-BOUNDARY-START(21476343853),
    {
      "t": 262145,
      "n": "_needIndent",
      "d": 1507373,
      "h": 21476343853,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476343853),
//--TRIMMABLE-BOUNDARY-START(17181376557),
    {
      "t": 1310721,
      "n": "_listenerName",
      "d": 1507373,
      "h": 17181376557,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181376557),
//--TRIMMABLE-BOUNDARY-START(4296474669),
    {
      "t": 1245229,
      "n": "_filter",
      "d": 1507373,
      "h": 4296474669,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296474669)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34361245741),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507373,
      "h": 34361245741,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(34361245741),
//--TRIMMABLE-BOUNDARY-START(38656213037),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507373,
      "h": 38656213037,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(38656213037)
  ],
  "h": 1507373
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceListener`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507373)
        
        

        //--TRIMMABLE-BOUNDARY-START(393261)
        $asm.$cls(`$sdts.SD.DiagnosticsConfiguration`, ($self) => class DiagnosticsConfiguration
        {
            //--TRIMMABLE-BOUNDARY-START(8590327853)
            static /*bool */ get AutoFlush()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327853)
            
            //--TRIMMABLE-BOUNDARY-START(64424902701)
            static /*bool */ get UseGlobalLock()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(64424902701)
            
            //--TRIMMABLE-BOUNDARY-START(55834968109)
            static /*int */ get IndentSize()
            {
                return 4;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968109)
            
            //--TRIMMABLE-BOUNDARY-START(4295360557)
            static /*bool */ get AssertUIEnabled()
            {
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360557)
            
            //--TRIMMABLE-BOUNDARY-START(60129935405)
            static /*string */ get LogFileName()
            {
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(60129935405)
            
            static $h = 393261;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590327853),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197037,
        "f": 50331688
      },
      "n": "AutoFlush",
      "d": 393261,
      "h": 8590327853,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8590327853),
//--TRIMMABLE-BOUNDARY-START(64424902701),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000813,
        "f": 50331688
      },
      "n": "UseGlobalLock",
      "d": 393261,
      "h": 64424902701,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(64424902701),
//--TRIMMABLE-BOUNDARY-START(55834968109),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131629,
        "f": 50331688
      },
      "n": "IndentSize",
      "d": 393261,
      "h": 55834968109,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(55834968109),
//--TRIMMABLE-BOUNDARY-START(4295360557),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180262445,
        "f": 50331688
      },
      "n": "AssertUIEnabled",
      "d": 393261,
      "h": 4295360557,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(4295360557),
//--TRIMMABLE-BOUNDARY-START(60129935405),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066221,
        "f": 50331688
      },
      "n": "LogFileName",
      "d": 393261,
      "h": 60129935405,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(60129935405)
  ],
  "h": 393261
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.DiagnosticsConfiguration`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}DiagnosticsConfiguration`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393261)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114157)
        $asm.$cls(`$sdts.SD.TraceEventCache`, ($self) => class TraceEventCache extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8591048749)
            /*long*/ _timeStamp = -1n;
            //--TRIMMABLE-BOUNDARY-END(8591048749)
            
            //--TRIMMABLE-BOUNDARY-START(4296081453)
            /*DateTime*/ _dateTime;
            //--TRIMMABLE-BOUNDARY-END(4296081453)
            
            //--TRIMMABLE-BOUNDARY-START(25770917933)
            /*DateTime */ get DateTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950787117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.DateTime.op_Equality(this._dateTime, $.$$.S.DateTime.MinValue))
                {
                    this._dateTime = $.$$.S.DateTime.UtcNow;
                }
                return this._dateTime;
            }
            //--TRIMMABLE-BOUNDARY-END(25770917933)
            
            //--TRIMMABLE-BOUNDARY-START(85900460077)
            /*int */ get ProcessId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130656301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Environment.ProcessId;
            }
            //--TRIMMABLE-BOUNDARY-END(85900460077)
            
            //--TRIMMABLE-BOUNDARY-START(90195427373)
            /*string */ get ThreadId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720590893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.Int32.ToString$1.call($.$$.S.Environment.CurrentManagedThreadId, $.$$.SG.CultureInfo.InvariantCulture);
            }
            //--TRIMMABLE-BOUNDARY-END(90195427373)
            
            //--TRIMMABLE-BOUNDARY-START(94490394669)
            /*long */ get Timestamp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310525485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._timeStamp === BigInt(-1))
                {
                    this._timeStamp = $.$$.SD.Stopwatch.GetTimestamp();
                }
                return this._timeStamp;
            }
            //--TRIMMABLE-BOUNDARY-END(94490394669)
            
            //--TRIMMABLE-BOUNDARY-START(21475950637)
            /*string*/ $Callstack = null;
            /*string */ get Callstack()
            {
                return this.Callstack$ ??= $.$$.S.Environment.StackTrace;
            }
            //--TRIMMABLE-BOUNDARY-END(21475950637)
            
            //--TRIMMABLE-BOUNDARY-START(81605492781)
            /*Stack */ get LogicalOperationStack()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540721709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.Trace.CorrelationManager.LogicalOperationStack;
            }
            //--TRIMMABLE-BOUNDARY-END(81605492781)
            
            //--TRIMMABLE-BOUNDARY-START(17180983341)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983341)
            
            //--TRIMMABLE-BOUNDARY-START(17180983341)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180983341)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4296081453)
                this._dateTime = $.$$.S.DateTime.MinValue;
                //--TRIMMABLE-BOUNDARY-END(4296081453)
                
            }
            static $h = 1114157;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770917933),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950787117,
        "f": 50331649
      },
      "n": "DateTime",
      "d": 1114157,
      "h": 25770917933,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770917933),
//--TRIMMABLE-BOUNDARY-START(85900460077),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130656301,
        "f": 50331649
      },
      "n": "ProcessId",
      "d": 1114157,
      "h": 85900460077,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900460077),
//--TRIMMABLE-BOUNDARY-START(90195427373),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720590893,
        "f": 50331649
      },
      "n": "ThreadId",
      "d": 1114157,
      "h": 90195427373,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195427373),
//--TRIMMABLE-BOUNDARY-START(94490394669),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310525485,
        "f": 50331649
      },
      "n": "Timestamp",
      "d": 1114157,
      "h": 94490394669,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490394669),
//--TRIMMABLE-BOUNDARY-START(21475950637),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360852525,
        "f": 50331649
      },
      "n": "Callstack",
      "d": 1114157,
      "h": 21475950637,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475950637),
//--TRIMMABLE-BOUNDARY-START(81605492781),
    {
      "p": 1179664,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540721709,
        "f": 50331649
      },
      "n": "LogicalOperationStack",
      "d": 1114157,
      "h": 81605492781,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605492781)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591048749),
    {
      "t": 917505,
      "n": "_timeStamp",
      "d": 1114157,
      "h": 8591048749,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048749),
//--TRIMMABLE-BOUNDARY-START(4296081453),
    {
      "t": 65994753,
      "n": "_dateTime",
      "d": 1114157,
      "h": 4296081453,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081453)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983341),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1114157,
      "h": 17180983341,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983341)
  ],
  "h": 1114157
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceEventCache`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceEventCache`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114157)
        
        

        //--TRIMMABLE-BOUNDARY-START(1835053)
        $asm.$cls(`$sdts.SD.TraceUtils`, ($self) => class TraceUtils
        {
            //--TRIMMABLE-BOUNDARY-START(4296802349)
            static /*void */ VerifyAttributes(/*StringDictionary?*/ attributes, /*string[]?*/ supportedAttributes, /*object*/ parent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296802349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(attributes, "attributes");
                let $en1 = attributes.Keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en1.SCG$IEnumerator$$$Current;
                    {
                        if (supportedAttributes === null || !$.$$.S.MemoryExtensions.Contains$2($.$$.S.String, $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1(supportedAttributes), key))
                        {
                            throw new $.$$.S.ArgumentException().$ctor$14($.$sdts.S.SR.Format$5($.$sdts.S.SR.AttributeNotSupported, key, $.$$.S.Object.GetType.call(parent).FullName));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296802349)
            
            static $h = 1835053;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296802349),
    {
      "r": 65537,
      "p": [
        {
          "n": "attributes",
          "p": 1310737
        },
        {
          "n": "supportedAttributes",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "parent",
          "p": 131073
        }
      ],
      "n": "VerifyAttributes",
      "d": 1835053,
      "h": 4296802349,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4296802349)
  ],
  "h": 1835053
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceUtils`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceUtils`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835053)
        
        

        //--TRIMMABLE-BOUNDARY-START(131117)
        $asm.$cls(`$sdts.SD.CorrelationManager`, ($self) => class CorrelationManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098413)
            /*AsyncLocal<Guid>*/ _activityId = null;
            //--TRIMMABLE-BOUNDARY-END(4295098413)
            
            //--TRIMMABLE-BOUNDARY-START(8590065709)
            /*AsyncLocal<StackNode?>*/ _stack = null;
            //--TRIMMABLE-BOUNDARY-END(8590065709)
            
            //--TRIMMABLE-BOUNDARY-START(12885033005)
            /*AsyncLocalStackWrapper*/ _stackWrapper = null;
            //--TRIMMABLE-BOUNDARY-END(12885033005)
            
            //--TRIMMABLE-BOUNDARY-START(17180000301)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000301);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._stackWrapper = new $.$sdts.SD.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180000301)
            
            //--TRIMMABLE-BOUNDARY-START(42949804077)
            /*Stack */ get LogicalOperationStack()
            {
                return this._stackWrapper;
            }
            //--TRIMMABLE-BOUNDARY-END(42949804077)
            
            //--TRIMMABLE-BOUNDARY-START(55834705965)
            /*void */ StartLogicalOperation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834705965);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.StartLogicalOperation$1($.$$.S.Guid.NewGuid());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834705965)
            
            //--TRIMMABLE-BOUNDARY-START(64424640557)
            /*void */ StopLogicalOperation()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640557);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._stackWrapper.Pop();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424640557)
            
            //--TRIMMABLE-BOUNDARY-START(21474967597)
            /*Guid */ get ActivityId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._activityId.Value;
            }
            /*Guid */ set ActivityId(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738669);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._activityId.Value = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967597)
            
            //--TRIMMABLE-BOUNDARY-START(60129673261)
            /*void */ StartLogicalOperation$1(/*object*/ operationId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673261);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(operationId, "operationId");
                this._stackWrapper.Push(operationId);
            }
            //--TRIMMABLE-BOUNDARY-END(60129673261)
            
            //--TRIMMABLE-BOUNDARY-START(262189)
            static $_StackNode;
            static get StackNode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sdts.SD.CorrelationManager;
                return $cls.$_StackNode ??= $asm.$ncls(`$sdts.SD.CorrelationManager.StackNode`, ($self) => class StackNode extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(17180131373)
                    $ctor$1(/*object?*/ value, /*StackNode?*/ prev)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180131373);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this.Value = value;
                            this.Prev = prev;
                            this.Count = prev !== null ? ((prev.Count + 1) | 0) : 1;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180131373)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475098669)
                    /*int*/ Count = 0;
                    //--TRIMMABLE-BOUNDARY-END(21475098669)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834837037)
                    /*object?*/ Value = null;
                    //--TRIMMABLE-BOUNDARY-END(55834837037)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539869741)
                    /*StackNode?*/ Prev = null;
                    //--TRIMMABLE-BOUNDARY-END(51539869741)
                    
                    static $h = 262189;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475098669),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033261,
        "f": 50331656
      },
      "n": "Count",
      "d": 262189,
      "h": 21475098669,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(21475098669),
//--TRIMMABLE-BOUNDARY-START(55834837037),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902445,
        "f": 50331656
      },
      "n": "Value",
      "d": 262189,
      "h": 55834837037,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(55834837037),
//--TRIMMABLE-BOUNDARY-START(51539869741),
    {
      "p": 262189,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967853,
        "f": 50331656
      },
      "n": "Prev",
      "d": 262189,
      "h": 51539869741,
      "f": 2097160
    },
//--TRIMMABLE-BOUNDARY-END(51539869741)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180131373),
    {
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "prev",
          "p": 262189,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262189,
      "h": 17180131373,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180131373)
  ],
  "d": 131117,
  "h": 262189
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Diagnostics.CorrelationManager+StackNode`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}CorrelationManager${separator}StackNode`; }
                }, $cls, ($v) => $cls.$_StackNode = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(262189)
            
            //--TRIMMABLE-BOUNDARY-START(196653)
            static $_AsyncLocalStackWrapper;
            static get AsyncLocalStackWrapper()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196653);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sdts.SD.CorrelationManager;
                return $cls.$_AsyncLocalStackWrapper ??= $asm.$ncls(`$sdts.SD.CorrelationManager.AsyncLocalStackWrapper`, ($self) => class AsyncLocalStackWrapper extends $.$scn.SC.Stack
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163949)
                    /*AsyncLocal<StackNode?>*/ _stack = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163949)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131245)
                    $ctor$4(/*AsyncLocal<StackNode?>*/ stack)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590131245);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            $.$$.SD.Debug.Assert$4(stack !== null, "stack != null");
                            this._stack = stack;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131245)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098541)
                    /*void */ Clear()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(12885098541);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return this._stack.Value = null;
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098541)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180065837)
                    /*object */ Clone()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180065837);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return new $.$sdts.SD.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180065837)
                    
                    //--TRIMMABLE-BOUNDARY-START(30064967725)
                    /*int */ get Count()
                    {
                        return (this._stack.Value?.Count ?? null) ?? 0;
                    }
                    //--TRIMMABLE-BOUNDARY-END(30064967725)
                    
                    //--TRIMMABLE-BOUNDARY-START(42949869613)
                    /*IEnumerator */ GetEnumerator()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(42949869613);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return $.$sdts.SD.CorrelationManager.AsyncLocalStackWrapper.GetEnumerator$1(this._stack.Value);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(42949869613)
                    
                    //--TRIMMABLE-BOUNDARY-START(51539804205)
                    /*object? */ Peek()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(51539804205);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            return (this._stack.Value?.Value ?? null);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(51539804205)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475033133)
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033133);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            if (obj === null)
                            {
                                if (n.Value === null)
                                {
                                    return true;
                                }
                            }
                            else if ($.$dspc(obj, $.$$.S.Object, ($t) => $t.Equals$1, n.Value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475033133)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000429)
                    /*void */ CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25770000429);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            array.SetValue$2(n.Value, index++);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000429)
                    
                    //--TRIMMABLE-BOUNDARY-START(47244836909)
                    static /*IEnumerator */ GetEnumerator$1(/*StackNode?*/ n)
                    {
                        return new ($.$$.N.YieldToIterator$$($.$$.S.Object))().$ctor$1(function*()
                        {
                            while(n !== null)
                            {
                                yield n.Value;
                                n = n.Prev;
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    //--TRIMMABLE-BOUNDARY-END(47244836909)
                    
                    //--TRIMMABLE-BOUNDARY-START(55834771501)
                    /*object? */ Pop()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(55834771501);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            super.Pop();
                        }
                        this._stack.Value = n.Prev;
                        return n.Value;
                    }
                    //--TRIMMABLE-BOUNDARY-END(55834771501)
                    
                    //--TRIMMABLE-BOUNDARY-START(60129738797)
                    /*void */ Push(/*object?*/ obj)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(60129738797);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        this._stack.Value = new $.$sdts.SD.CorrelationManager.StackNode().$ctor$1(obj, this._stack.Value);
                    }
                    //--TRIMMABLE-BOUNDARY-END(60129738797)
                    
                    //--TRIMMABLE-BOUNDARY-START(64424706093)
                    /*object?[] */ ToArray()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(64424706093);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            return $.$$.S.Array.Empty($.$$.S.Object);
                        }
                        /*var*/ let results = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                        do
                        {
                            results.Add(n.Value);
                            n = n.Prev;
                        }
                        while(n !== null);
                        return results.ToArray();
                    }
                    //--TRIMMABLE-BOUNDARY-END(64424706093)
                    
                    static $h = 196653;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$scn.SC.Stack; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30064967725),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902317,
        "f": 50364417
      },
      "n": "Count",
      "d": 196653,
      "h": 30064967725,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30064967725)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098541),
    {
      "r": 65537,
      "n": "Clear",
      "d": 196653,
      "h": 12885098541,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885098541),
//--TRIMMABLE-BOUNDARY-START(17180065837),
    {
      "r": 131073,
      "n": "Clone",
      "d": 196653,
      "h": 17180065837,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180065837),
//--TRIMMABLE-BOUNDARY-START(42949869613),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 196653,
      "h": 42949869613,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42949869613),
//--TRIMMABLE-BOUNDARY-START(51539804205),
    {
      "r": 131073,
      "n": "Peek",
      "d": 196653,
      "h": 51539804205,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51539804205),
//--TRIMMABLE-BOUNDARY-START(21475033133),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Contains",
      "d": 196653,
      "h": 21475033133,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21475033133),
//--TRIMMABLE-BOUNDARY-START(25770000429),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 196653,
      "h": 25770000429,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770000429),
//--TRIMMABLE-BOUNDARY-START(47244836909),
    {
      "r": 63504385,
      "p": [
        {
          "n": "n",
          "p": 262189
        }
      ],
      "n": "GetEnumerator",
      "o": "@$1",
      "d": 196653,
      "h": 47244836909,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47244836909),
//--TRIMMABLE-BOUNDARY-START(55834771501),
    {
      "r": 131073,
      "n": "Pop",
      "d": 196653,
      "h": 55834771501,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55834771501),
//--TRIMMABLE-BOUNDARY-START(60129738797),
    {
      "r": 65537,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Push",
      "d": 196653,
      "h": 60129738797,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60129738797),
//--TRIMMABLE-BOUNDARY-START(64424706093),
    {
      "r": $.$typeArray($.$$.S.Object).$h,
      "n": "ToArray",
      "d": 196653,
      "h": 64424706093,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64424706093)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163949),
    {
      "t": $.$$.ST$1.AsyncLocal$$($.$sdts.SD.CorrelationManager.StackNode).$h,
      "n": "_stack",
      "d": 196653,
      "h": 4295163949,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163949)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131245),
    {
      "p": [
        {
          "n": "stack",
          "p": $.$$.ST$1.AsyncLocal$$($.$sdts.SD.CorrelationManager.StackNode).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 196653,
      "h": 8590131245,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8590131245)
  ],
  "d": 131117,
  "h": 196653
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable, $.$$.S.ICloneable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Diagnostics.CorrelationManager+AsyncLocalStackWrapper`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}CorrelationManager${separator}AsyncLocalStackWrapper`; }
                }, $cls, ($v) => $cls.$_AsyncLocalStackWrapper = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196653)
            
            //--TRIMMABLE-BOUNDARY-START(17180000301)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000301)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295098413)
                this._activityId = new ($.$$.ST$1.AsyncLocal$$($.$$.S.Guid))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(4295098413)
                
                //--TRIMMABLE-BOUNDARY-START(8590065709)
                this._stack = new ($.$$.ST$1.AsyncLocal$$($.$sdts.SD.CorrelationManager.StackNode))().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(8590065709)
                
            }
            static $h = 131117;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42949804077),
    {
      "p": 1179664,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836781,
        "f": 50331649
      },
      "n": "LogicalOperationStack",
      "d": 131117,
      "h": 42949804077,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949804077),
//--TRIMMABLE-BOUNDARY-START(21474967597),
    {
      "p": 89784321,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902189,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539738669,
        "f": 83886081
      },
      "n": "ActivityId",
      "d": 131117,
      "h": 21474967597,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967597)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55834705965),
    {
      "r": 65537,
      "n": "StartLogicalOperation",
      "d": 131117,
      "h": 55834705965,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834705965),
//--TRIMMABLE-BOUNDARY-START(64424640557),
    {
      "r": 65537,
      "n": "StopLogicalOperation",
      "d": 131117,
      "h": 64424640557,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424640557),
//--TRIMMABLE-BOUNDARY-START(60129673261),
    {
      "r": 65537,
      "p": [
        {
          "n": "operationId",
          "p": 131073
        }
      ],
      "n": "StartLogicalOperation",
      "o": "@$1",
      "d": 131117,
      "h": 60129673261,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129673261)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098413),
    {
      "t": $.$$.ST$1.AsyncLocal$$($.$$.S.Guid).$h,
      "n": "_activityId",
      "d": 131117,
      "h": 4295098413,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098413),
//--TRIMMABLE-BOUNDARY-START(8590065709),
    {
      "t": $.$$.ST$1.AsyncLocal$$($.$sdts.SD.CorrelationManager.StackNode).$h,
      "n": "_stack",
      "d": 131117,
      "h": 8590065709,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590065709),
//--TRIMMABLE-BOUNDARY-START(12885033005),
    {
      "t": 196653,
      "n": "_stackWrapper",
      "d": 131117,
      "h": 12885033005,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885033005)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180000301),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131117,
      "h": 17180000301,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(17180000301)
  ],
  "h": 131117
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sdts.SD.CorrelationManager.StackNode, $.$sdts.SD.CorrelationManager.AsyncLocalStackWrapper ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.CorrelationManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}CorrelationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131117)
        
        

        //--TRIMMABLE-BOUNDARY-START(1900589)
        $asm.$cls(`$sdts.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(227635167277)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(227635167277)
            
            //--TRIMMABLE-BOUNDARY-START(206160330797)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206160330797);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206160330797)
            
            //--TRIMMABLE-BOUNDARY-START(261994905645)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261994905645);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdts.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994905645)
            
            //--TRIMMABLE-BOUNDARY-START(201865363501)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865363501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdts.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(201865363501)
            
            //--TRIMMABLE-BOUNDARY-START(197570396205)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570396205);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sdts.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(197570396205)
            
            //--TRIMMABLE-BOUNDARY-START(60131442733)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131442733);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60131442733)
            
            //--TRIMMABLE-BOUNDARY-START(55836475437)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836475437);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(55836475437)
            
            //--TRIMMABLE-BOUNDARY-START(51541508141)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541508141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51541508141)
            
            //--TRIMMABLE-BOUNDARY-START(64426410029)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426410029);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sdts.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(64426410029)
            
            //--TRIMMABLE-BOUNDARY-START(42951573549)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951573549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42951573549)
            
            //--TRIMMABLE-BOUNDARY-START(38656606253)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656606253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38656606253)
            
            //--TRIMMABLE-BOUNDARY-START(34361638957)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361638957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34361638957)
            
            //--TRIMMABLE-BOUNDARY-START(47246540845)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246540845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sdts.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47246540845)
            
            //--TRIMMABLE-BOUNDARY-START(223340199981)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(223340199981)
            
            //--TRIMMABLE-BOUNDARY-START(214750265389)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(214750265389)
            
            //--TRIMMABLE-BOUNDARY-START(219045232685)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325755949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sdts.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Diagnostics.TraceSource", $.$sdts.S.SR.$type.Assembly);
                    $.$sdts.S.SR.s_resourceManager = temp;
                }
                return $.$sdts.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(219045232685)
            
            //--TRIMMABLE-BOUNDARY-START(12886802477)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786148397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236225101869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12886802477)
            
            //--TRIMMABLE-BOUNDARY-START(8591835181)
            static /*string */ get AttributeNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196213805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "'{0}' is not a valid attribute for type '{1}'.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591835181)
            
            //--TRIMMABLE-BOUNDARY-START(68721377325)
            static /*string */ FormatAttributeNotSupported(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721377325);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("'{0}' is not a valid attribute for type '{1}'.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68721377325)
            
            //--TRIMMABLE-BOUNDARY-START(30066671661)
            static /*string */ get ExceptionOccurred()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145886765);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "An exception occurred while writing to the log file {0}: {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066671661)
            
            //--TRIMMABLE-BOUNDARY-START(73016344621)
            static /*string */ FormatExceptionOccurred(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016344621);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$8("An exception occurred while writing to the log file {0}: {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(73016344621)
            
            //--TRIMMABLE-BOUNDARY-START(210455298093)
            static /*string */ get MustAddListener()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735821357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Only TraceListeners can be added to a TraceListenerCollection.";
            }
            //--TRIMMABLE-BOUNDARY-END(210455298093)
            
            //--TRIMMABLE-BOUNDARY-START(240520069165)
            static /*string */ get TraceListenerFail()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915690541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Fail:";
            }
            //--TRIMMABLE-BOUNDARY-END(240520069165)
            
            //--TRIMMABLE-BOUNDARY-START(244815036461)
            static /*string */ get TraceListenerIndentSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505625133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The IndentSize property must be non-negative.";
            }
            //--TRIMMABLE-BOUNDARY-END(244815036461)
            
            //--TRIMMABLE-BOUNDARY-START(17181769773)
            static /*string */ get DebugAssertBanner()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107376082989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "---- DEBUG ASSERTION FAILED ----";
            }
            //--TRIMMABLE-BOUNDARY-END(17181769773)
            
            //--TRIMMABLE-BOUNDARY-START(25771704365)
            static /*string */ get DebugAssertShortMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555952173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "---- Assert Short Message ----";
            }
            //--TRIMMABLE-BOUNDARY-END(25771704365)
            
            //--TRIMMABLE-BOUNDARY-START(21476737069)
            static /*string */ get DebugAssertLongMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115966017581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "---- Assert Long Message ----";
            }
            //--TRIMMABLE-BOUNDARY-END(21476737069)
            
            //--TRIMMABLE-BOUNDARY-START(257699938349)
            static /*string */ get TraceSwitchLevelTooLow()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275428909);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off";
            }
            //--TRIMMABLE-BOUNDARY-END(257699938349)
            
            //--TRIMMABLE-BOUNDARY-START(81606279213)
            static /*string */ FormatTraceSwitchLevelTooLow(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606279213);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81606279213)
            
            //--TRIMMABLE-BOUNDARY-START(249110003757)
            static /*string */ get TraceSwitchInvalidLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095559725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The Level must be set to a value in the enumeration TraceLevel.";
            }
            //--TRIMMABLE-BOUNDARY-END(249110003757)
            
            //--TRIMMABLE-BOUNDARY-START(253404971053)
            static /*string */ get TraceSwitchLevelTooHigh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685494317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose";
            }
            //--TRIMMABLE-BOUNDARY-END(253404971053)
            
            //--TRIMMABLE-BOUNDARY-START(77311311917)
            static /*string */ FormatTraceSwitchLevelTooHigh(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77311311917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77311311917)
            
            //--TRIMMABLE-BOUNDARY-START(4296867885)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296867885);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(227635167277)
                    this.s_usingResourceKeys = $.$sdts.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(227635167277)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296867885)
            
            static $h = 1900589;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1900589
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900589)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048621)
        $asm.$cls(`$sdts.SD.Trace`, ($self) => class Trace extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(8590983213)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590983213);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590983213)
            
            //--TRIMMABLE-BOUNDARY-START(42950721581)
            /*CorrelationManager*/ static $CorrelationManager = null;
            static /*CorrelationManager */ get CorrelationManager()
            {
                return $.$sdts.SD.Trace.CorrelationManager$ ?? $.$$.ST$1.Interlocked.CompareExchange$14($.$sdts.SD.CorrelationManager, $.$ref(() => $.$sdts.SD.Trace.CorrelationManager$, ($v) => $.$sdts.SD.Trace.CorrelationManager$ = $v, $.$sdts.SD.CorrelationManager), new $.$sdts.SD.CorrelationManager().$ctor$1(), null) ?? $.$sdts.SD.Trace.CorrelationManager$;
            }
            //--TRIMMABLE-BOUNDARY-END(42950721581)
            
            //--TRIMMABLE-BOUNDARY-START(124555100205)
            static /*TraceListenerCollection */ get Listeners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296429);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.TraceInternal.Listeners;
            }
            //--TRIMMABLE-BOUNDARY-END(124555100205)
            
            //--TRIMMABLE-BOUNDARY-START(34360786989)
            static /*bool */ get AutoFlush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.TraceInternal.AutoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619871277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.AutoFlush = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360786989)
            
            //--TRIMMABLE-BOUNDARY-START(214749413421)
            static /*bool */ get UseGlobalLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375231021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.TraceInternal.UseGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389675053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.UseGlobalLock = value;
            }
            //--TRIMMABLE-BOUNDARY-END(214749413421)
            
            //--TRIMMABLE-BOUNDARY-START(115965165613)
            static /*int */ get IndentLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605427245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.TraceInternal.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209805869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.IndentLevel = value;
            }
            //--TRIMMABLE-BOUNDARY-END(115965165613)
            
            //--TRIMMABLE-BOUNDARY-START(120260132909)
            static /*int */ get IndentSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195361837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdts.SD.TraceInternal.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799740461);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.IndentSize = value;
            }
            //--TRIMMABLE-BOUNDARY-END(120260132909)
            
            //--TRIMMABLE-BOUNDARY-START(55835623469)
            static /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623469);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Flush();
            }
            //--TRIMMABLE-BOUNDARY-END(55835623469)
            
            //--TRIMMABLE-BOUNDARY-START(38655754285)
            static /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655754285);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Close();
            }
            //--TRIMMABLE-BOUNDARY-END(38655754285)
            
            //--TRIMMABLE-BOUNDARY-START(30065819693)
            static /*void */ Assert$2(/*bool*/ condition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Assert$2(condition);
            }
            //--TRIMMABLE-BOUNDARY-END(30065819693)
            
            //--TRIMMABLE-BOUNDARY-START(25770852397)
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Assert$1(condition, message);
            }
            //--TRIMMABLE-BOUNDARY-END(25770852397)
            
            //--TRIMMABLE-BOUNDARY-START(21475885101)
            static /*void */ Assert(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Assert(condition, message, detailMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(21475885101)
            
            //--TRIMMABLE-BOUNDARY-START(51540656173)
            static /*void */ Fail$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Fail$1(message);
            }
            //--TRIMMABLE-BOUNDARY-END(51540656173)
            
            //--TRIMMABLE-BOUNDARY-START(47245688877)
            static /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688877);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Fail(message, detailMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(47245688877)
            
            //--TRIMMABLE-BOUNDARY-START(137440002093)
            /*EventHandler?*/ static Refreshing = null;
            //--TRIMMABLE-BOUNDARY-END(137440002093)
            
            //--TRIMMABLE-BOUNDARY-START(137440002093)
            //--TRIMMABLE-BOUNDARY-START(17180917805)
            static add_Refreshing(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Trace.Refreshing = $.$$.S.Delegate.Combine$2($.$sdts.SD.Trace.Refreshing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180917805)
            
            //--TRIMMABLE-BOUNDARY-START(146029936685)
            static remove_Refreshing(/*EventHandler?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029936685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Trace.Refreshing = $.$$.S.Delegate.Remove($.$sdts.SD.Trace.Refreshing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(146029936685)
            
            //--TRIMMABLE-BOUNDARY-END(137440002093)
            
            //--TRIMMABLE-BOUNDARY-START(128850067501)
            static /*void */ OnRefreshing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850067501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Trace.Refreshing?.Invoke(null, $.$$.S.EventArgs.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(128850067501)
            
            //--TRIMMABLE-BOUNDARY-START(133145034797)
            static /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145034797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.Trace.OnRefreshing();
                $.$sdts.SD.Switch.RefreshAll();
                $.$sdts.SD.TraceSource.RefreshAll();
                $.$sdts.SD.TraceInternal.Refresh();
            }
            //--TRIMMABLE-BOUNDARY-END(133145034797)
            
            //--TRIMMABLE-BOUNDARY-START(197569544237)
            static /*void */ TraceInformation$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569544237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(197569544237)
            
            //--TRIMMABLE-BOUNDARY-START(193274576941)
            static /*void */ TraceInformation(/*string*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274576941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(193274576941)
            
            //--TRIMMABLE-BOUNDARY-START(206159478829)
            static /*void */ TraceWarning$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159478829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(206159478829)
            
            //--TRIMMABLE-BOUNDARY-START(201864511533)
            static /*void */ TraceWarning(/*string*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864511533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(201864511533)
            
            //--TRIMMABLE-BOUNDARY-START(188979609645)
            static /*void */ TraceError$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979609645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(188979609645)
            
            //--TRIMMABLE-BOUNDARY-START(184684642349)
            static /*void */ TraceError(/*string*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684642349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, format, args);
            }
            //--TRIMMABLE-BOUNDARY-END(184684642349)
            
            //--TRIMMABLE-BOUNDARY-START(231929282605)
            static /*void */ Write$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929282605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Write$3(message);
            }
            //--TRIMMABLE-BOUNDARY-END(231929282605)
            
            //--TRIMMABLE-BOUNDARY-START(223339348013)
            static /*void */ Write$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339348013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Write$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(223339348013)
            
            //--TRIMMABLE-BOUNDARY-START(227634315309)
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634315309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Write$2(message, category);
            }
            //--TRIMMABLE-BOUNDARY-END(227634315309)
            
            //--TRIMMABLE-BOUNDARY-START(219044380717)
            static /*void */ Write(/*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044380717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Write(value, category);
            }
            //--TRIMMABLE-BOUNDARY-END(219044380717)
            
            //--TRIMMABLE-BOUNDARY-START(266289020973)
            static /*void */ WriteLine$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289020973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLine$3(message);
            }
            //--TRIMMABLE-BOUNDARY-END(266289020973)
            
            //--TRIMMABLE-BOUNDARY-START(257699086381)
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699086381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLine$1(value);
            }
            //--TRIMMABLE-BOUNDARY-END(257699086381)
            
            //--TRIMMABLE-BOUNDARY-START(261994053677)
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994053677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLine$2(message, category);
            }
            //--TRIMMABLE-BOUNDARY-END(261994053677)
            
            //--TRIMMABLE-BOUNDARY-START(253404119085)
            static /*void */ WriteLine(/*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404119085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLine(value, category);
            }
            //--TRIMMABLE-BOUNDARY-END(253404119085)
            
            //--TRIMMABLE-BOUNDARY-START(249109151789)
            static /*void */ WriteIf$3(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109151789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteIf$3(condition, message);
            }
            //--TRIMMABLE-BOUNDARY-END(249109151789)
            
            //--TRIMMABLE-BOUNDARY-START(240519217197)
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519217197);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteIf$1(condition, value);
            }
            //--TRIMMABLE-BOUNDARY-END(240519217197)
            
            //--TRIMMABLE-BOUNDARY-START(244814184493)
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814184493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteIf$2(condition, message, category);
            }
            //--TRIMMABLE-BOUNDARY-END(244814184493)
            
            //--TRIMMABLE-BOUNDARY-START(236224249901)
            static /*void */ WriteIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224249901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteIf(condition, value, category);
            }
            //--TRIMMABLE-BOUNDARY-END(236224249901)
            
            //--TRIMMABLE-BOUNDARY-START(283468890157)
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468890157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLineIf$3(condition, message);
            }
            //--TRIMMABLE-BOUNDARY-END(283468890157)
            
            //--TRIMMABLE-BOUNDARY-START(274878955565)
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878955565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLineIf$1(condition, value);
            }
            //--TRIMMABLE-BOUNDARY-END(274878955565)
            
            //--TRIMMABLE-BOUNDARY-START(279173922861)
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173922861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLineIf$2(condition, message, category);
            }
            //--TRIMMABLE-BOUNDARY-END(279173922861)
            
            //--TRIMMABLE-BOUNDARY-START(270583988269)
            static /*void */ WriteLineIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583988269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.WriteLineIf(condition, value, category);
            }
            //--TRIMMABLE-BOUNDARY-END(270583988269)
            
            //--TRIMMABLE-BOUNDARY-START(111670198317)
            static /*void */ Indent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670198317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Indent();
            }
            //--TRIMMABLE-BOUNDARY-END(111670198317)
            
            //--TRIMMABLE-BOUNDARY-START(210454446125)
            static /*void */ Unindent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454446125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.Unindent();
            }
            //--TRIMMABLE-BOUNDARY-END(210454446125)
            
            //--TRIMMABLE-BOUNDARY-START(8590983213)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590983213)
            
            static $h = 1048621;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950721581),
    {
      "p": 131117,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015492653,
        "f": 50331681
      },
      "n": "CorrelationManager",
      "d": 1048621,
      "h": 42950721581,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950721581),
//--TRIMMABLE-BOUNDARY-START(124555100205),
    {
      "p": 1572909,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785296429,
        "f": 50331681
      },
      "n": "Listeners",
      "d": 1048621,
      "h": 124555100205,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(124555100205),
//--TRIMMABLE-BOUNDARY-START(34360786989),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425558061,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 154619871277,
        "f": 83886113
      },
      "n": "AutoFlush",
      "d": 1048621,
      "h": 34360786989,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360786989),
//--TRIMMABLE-BOUNDARY-START(214749413421),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375231021,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 180389675053,
        "f": 83886113
      },
      "n": "UseGlobalLock",
      "d": 1048621,
      "h": 214749413421,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(214749413421),
//--TRIMMABLE-BOUNDARY-START(115965165613),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605427245,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 163209805869,
        "f": 83886113
      },
      "n": "IndentLevel",
      "d": 1048621,
      "h": 115965165613,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(115965165613),
//--TRIMMABLE-BOUNDARY-START(120260132909),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195361837,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 171799740461,
        "f": 83886113
      },
      "n": "IndentSize",
      "d": 1048621,
      "h": 120260132909,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120260132909)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835623469),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1048621,
      "h": 55835623469,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55835623469),
//--TRIMMABLE-BOUNDARY-START(38655754285),
    {
      "r": 65537,
      "n": "Close",
      "d": 1048621,
      "h": 38655754285,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655754285),
//--TRIMMABLE-BOUNDARY-START(30065819693),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        }
      ],
      "n": "Assert",
      "o": "@$2",
      "d": 1048621,
      "h": 30065819693,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        },
        {
          "t": 132186113,
          "c": 8722120705,
          "a": [
            {
              "v": -1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065819693),
//--TRIMMABLE-BOUNDARY-START(25770852397),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721,
          "f": 65,
          "a": [
            {
              "t": 125960193,
              "c": 8715894785,
              "a": [
                {
                  "v": "condition",
                  "t": 1310721
                }
              ]
            }
          ]
        }
      ],
      "n": "Assert",
      "o": "@$1",
      "d": 1048621,
      "h": 25770852397,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770852397),
//--TRIMMABLE-BOUNDARY-START(21475885101),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Assert",
      "d": 1048621,
      "h": 21475885101,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475885101),
//--TRIMMABLE-BOUNDARY-START(51540656173),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 1048621,
      "h": 51540656173,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51540656173),
//--TRIMMABLE-BOUNDARY-START(47245688877),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "d": 1048621,
      "h": 47245688877,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47245688877),
//--TRIMMABLE-BOUNDARY-START(128850067501),
    {
      "r": 65537,
      "n": "OnRefreshing",
      "d": 1048621,
      "h": 128850067501,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128850067501),
//--TRIMMABLE-BOUNDARY-START(133145034797),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 1048621,
      "h": 133145034797,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(133145034797),
//--TRIMMABLE-BOUNDARY-START(197569544237),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceInformation",
      "o": "@$1",
      "d": 1048621,
      "h": 197569544237,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569544237),
//--TRIMMABLE-BOUNDARY-START(193274576941),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceInformation",
      "d": 1048621,
      "h": 193274576941,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274576941),
//--TRIMMABLE-BOUNDARY-START(206159478829),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceWarning",
      "o": "@$1",
      "d": 1048621,
      "h": 206159478829,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159478829),
//--TRIMMABLE-BOUNDARY-START(201864511533),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceWarning",
      "d": 1048621,
      "h": 201864511533,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864511533),
//--TRIMMABLE-BOUNDARY-START(188979609645),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceError",
      "o": "@$1",
      "d": 1048621,
      "h": 188979609645,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979609645),
//--TRIMMABLE-BOUNDARY-START(184684642349),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceError",
      "d": 1048621,
      "h": 184684642349,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184684642349),
//--TRIMMABLE-BOUNDARY-START(231929282605),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$3",
      "d": 1048621,
      "h": 231929282605,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231929282605),
//--TRIMMABLE-BOUNDARY-START(223339348013),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1048621,
      "h": 223339348013,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223339348013),
//--TRIMMABLE-BOUNDARY-START(227634315309),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 1048621,
      "h": 227634315309,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634315309),
//--TRIMMABLE-BOUNDARY-START(219044380717),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "d": 1048621,
      "h": 219044380717,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219044380717),
//--TRIMMABLE-BOUNDARY-START(266289020973),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$3",
      "d": 1048621,
      "h": 266289020973,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266289020973),
//--TRIMMABLE-BOUNDARY-START(257699086381),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$1",
      "d": 1048621,
      "h": 257699086381,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257699086381),
//--TRIMMABLE-BOUNDARY-START(261994053677),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$2",
      "d": 1048621,
      "h": 261994053677,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261994053677),
//--TRIMMABLE-BOUNDARY-START(253404119085),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "d": 1048621,
      "h": 253404119085,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253404119085),
//--TRIMMABLE-BOUNDARY-START(249109151789),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "o": "@$3",
      "d": 1048621,
      "h": 249109151789,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249109151789),
//--TRIMMABLE-BOUNDARY-START(240519217197),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteIf",
      "o": "@$1",
      "d": 1048621,
      "h": 240519217197,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240519217197),
//--TRIMMABLE-BOUNDARY-START(244814184493),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "o": "@$2",
      "d": 1048621,
      "h": 244814184493,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244814184493),
//--TRIMMABLE-BOUNDARY-START(236224249901),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "d": 1048621,
      "h": 236224249901,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236224249901),
//--TRIMMABLE-BOUNDARY-START(283468890157),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "o": "@$3",
      "d": 1048621,
      "h": 283468890157,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468890157),
//--TRIMMABLE-BOUNDARY-START(274878955565),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLineIf",
      "o": "@$1",
      "d": 1048621,
      "h": 274878955565,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274878955565),
//--TRIMMABLE-BOUNDARY-START(279173922861),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "o": "@$2",
      "d": 1048621,
      "h": 279173922861,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173922861),
//--TRIMMABLE-BOUNDARY-START(270583988269),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "d": 1048621,
      "h": 270583988269,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270583988269),
//--TRIMMABLE-BOUNDARY-START(111670198317),
    {
      "r": 65537,
      "n": "Indent",
      "d": 1048621,
      "h": 111670198317,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670198317),
//--TRIMMABLE-BOUNDARY-START(210454446125),
    {
      "r": 65537,
      "n": "Unindent",
      "d": 1048621,
      "h": 210454446125,
      "f": 16777249,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210454446125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590983213),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048621,
      "h": 8590983213,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590983213)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(137440002093),
    {
      "e": 80609281,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "add_Refreshing",
        "d": 1048621,
        "h": 17180917805,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 80609281
          }
        ],
        "n": "remove_Refreshing",
        "d": 1048621,
        "h": 146029936685,
        "f": 285212705
      },
      "n": "Refreshing",
      "d": 1048621,
      "h": 137440002093,
      "f": 8388641
    },
//--TRIMMABLE-BOUNDARY-END(137440002093)
  ],
  "h": 1048621
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.Trace`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}Trace`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048621)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703981)
        $asm.$cls(`$sdts.SD.TraceSource`, ($self) => class TraceSource extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(167505428525)
            /*List<WeakReference<TraceSource>>*/ static s_tracesources = null;
            //--TRIMMABLE-BOUNDARY-END(167505428525)
            
            //--TRIMMABLE-BOUNDARY-START(163210461229)
            /*int*/ static s_LastCollectionCount = 0;
            //--TRIMMABLE-BOUNDARY-END(163210461229)
            
            //--TRIMMABLE-BOUNDARY-START(17181573165)
            /*SourceSwitch?*/ _internalSwitch = null;
            //--TRIMMABLE-BOUNDARY-END(17181573165)
            
            //--TRIMMABLE-BOUNDARY-START(21476540461)
            /*TraceListenerCollection?*/ _listeners = null;
            //--TRIMMABLE-BOUNDARY-END(21476540461)
            
            //--TRIMMABLE-BOUNDARY-START(34361442349)
            /*SourceLevels*/ _switchLevel = 0;
            //--TRIMMABLE-BOUNDARY-END(34361442349)
            
            //--TRIMMABLE-BOUNDARY-START(30066475053)
            /*string*/ _sourceName = null;
            //--TRIMMABLE-BOUNDARY-END(30066475053)
            
            //--TRIMMABLE-BOUNDARY-START(12886605869)
            /*bool*/ _initCalled = false;
            //--TRIMMABLE-BOUNDARY-END(12886605869)
            
            //--TRIMMABLE-BOUNDARY-START(8591638573)
            /*bool*/ _configInitializing = false;
            //--TRIMMABLE-BOUNDARY-END(8591638573)
            
            //--TRIMMABLE-BOUNDARY-START(4296671277)
            /*StringDictionary?*/ _attributes = null;
            //--TRIMMABLE-BOUNDARY-END(4296671277)
            
            //--TRIMMABLE-BOUNDARY-START(47246344237)
            $ctor$2(/*string*/ name)
            {
                this.$ctor$1(name, 0/*SourceLevels.Off*/);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47246344237);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47246344237)
            
            //--TRIMMABLE-BOUNDARY-START(42951376941)
            $ctor$1(/*string*/ name, /*SourceLevels*/ defaultLevel)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42951376941);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.S.ArgumentException.ThrowIfNullOrEmpty(name, "name");
                    this._sourceName = name;
                    this._switchLevel = defaultLevel;
                    //lock(s_tracesources)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceSource.s_tracesources)
                        {
                            $.$sdts.SD.TraceSource._pruneCachedTraceSources();
                            $.$sdts.SD.TraceSource.s_tracesources.Add(new ($.$$.S.WeakReference$$($.$sdts.SD.TraceSource))().$ctor$3(this));
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceSource.s_tracesources)
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42951376941)
            
            //--TRIMMABLE-BOUNDARY-START(25771507757)
            static /*void */ _pruneCachedTraceSources()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771507757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(s_tracesources)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceSource.s_tracesources)
                    {
                        if ($.$sdts.SD.TraceSource.s_LastCollectionCount !== $.$$.S.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<TraceSource>>*/ let buffer = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.TraceSource)))().$ctor$3($.$sdts.SD.TraceSource.s_tracesources.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.SD.TraceSource.s_tracesources.Count; i++)
                            {
                                if ($.$sdts.SD.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.SD.TraceSource.s_tracesources.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.SD.TraceSource.s_tracesources.Count)
                            {
                                $.$sdts.SD.TraceSource.s_tracesources.Clear();
                                $.$sdts.SD.TraceSource.s_tracesources.AddRange(buffer);
                                $.$sdts.SD.TraceSource.s_tracesources.TrimExcess();
                            }
                            $.$sdts.SD.TraceSource.s_LastCollectionCount = $.$$.S.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceSource.s_tracesources)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771507757)
            
            //--TRIMMABLE-BOUNDARY-START(124555755565)
            /*void */ Initialize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555755565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._initCalled)
                {
                    //lock(this)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1(this)
                        {
                            if (this._initCalled)
                            {
                                return;
                            }
                            if (this._configInitializing)
                            {
                                return;
                            }
                            this._configInitializing = true;
                            NoConfigInit_BeforeEvent.call(this);
                            /*InitializingTraceSourceEventArgs*/ let e = new $.$sdts.SD.InitializingTraceSourceEventArgs().$ctor$2(this);
                            this.OnInitializing(e);
                            if (!e.WasInitialized)
                            {
                                NoConfigInit_AfterEvent.call(this);
                            }
                            this._configInitializing = false;
                            this._initCalled = true;
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit(this)
                    }
                }
                /*void*/  function NoConfigInit_BeforeEvent()
                {
                    this._listeners = new $.$sdts.SD.TraceListenerCollection().$ctor$1();
                    this._internalSwitch = new $.$sdts.SD.SourceSwitch().$ctor$3(this._sourceName, $.$$.S.Enum.ToStringT($.$sdts.SD.SourceLevels, $.$$.S.UInt32, this._switchLevel));
                }
                /*void*/  function NoConfigInit_AfterEvent()
                {
                    $.$$.SD.Debug.Assert$4(this._listeners !== null, "_listeners != null");
                    this._listeners.Add(new $.$sdts.SD.DefaultTraceListener().$ctor$4());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124555755565)
            
            //--TRIMMABLE-BOUNDARY-START(64426213421)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426213421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._listeners !== null)
                {
                    //lock(TraceInternal.critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en1 = this._listeners.GetEnumerator();
                            while ($en1.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en1.SC$1$IEnumerator$Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64426213421)
            
            //--TRIMMABLE-BOUNDARY-START(73016148013)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016148013);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._listeners !== null)
                {
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                let $en2 = this._listeners.GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en2.SC$1$IEnumerator$Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        let $en3 = this._listeners.GetEnumerator();
                        while ($en3.SC$1$IEnumerator$MoveNext())
                        {
                            let listener = $en3.SC$1$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock(listener)
                                    try
                                    {
                                        $.$$.ST$1.Monitor.Enter$1(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.ST$1.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73016148013)
            
            //--TRIMMABLE-BOUNDARY-START(120260788269)
            /*string[]? */ GetSupportedAttributes()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120260788269);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260788269)
            
            //--TRIMMABLE-BOUNDARY-START(150325559341)
            static /*void */ RefreshAll()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325559341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(s_tracesources)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceSource.s_tracesources)
                    {
                        $.$sdts.SD.TraceSource._pruneCachedTraceSources();
                        for(/*int*/ let i = 0; i < $.$sdts.SD.TraceSource.s_tracesources.Count; i++)
                        {
                            /*TraceSource?*/ let tracesource;
                            if ($.$sdts.SD.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$ref(() => tracesource, ($v) => tracesource = $v, $.$sdts.SD.TraceSource)))
                            {
                                tracesource.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceSource.s_tracesources)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150325559341)
            
            //--TRIMMABLE-BOUNDARY-START(146030592045)
            /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030592045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._initCalled)
                {
                    this.Initialize();
                    return;
                }
                this.OnInitializing(new $.$sdts.SD.InitializingTraceSourceEventArgs().$ctor$2(this));
            }
            //--TRIMMABLE-BOUNDARY-END(146030592045)
            
            //--TRIMMABLE-BOUNDARY-START(201865166893)
            /*void */ TraceEvent$2(/*TraceEventType*/ eventType, /*int*/ id)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201865166893);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceEvent$2(manager, this.Name, eventType, id);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent$2(manager, this.Name, eventType, id);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$2(manager, this.Name, eventType, id);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201865166893)
            
            //--TRIMMABLE-BOUNDARY-START(197570199597)
            /*void */ TraceEvent$1(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570199597);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197570199597)
            
            //--TRIMMABLE-BOUNDARY-START(193275232301)
            /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193275232301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193275232301)
            
            //--TRIMMABLE-BOUNDARY-START(184685297709)
            /*void */ TraceData(/*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685297709);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceData(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceData(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData(manager, this.Name, eventType, id, data);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184685297709)
            
            //--TRIMMABLE-BOUNDARY-START(188980265005)
            /*void */ TraceData$1(/*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980265005);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceData$1(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceData$1(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData$1(manager, this.Name, eventType, id, data);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188980265005)
            
            //--TRIMMABLE-BOUNDARY-START(210455101485)
            /*void */ TraceInformation$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210455101485);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
            }
            //--TRIMMABLE-BOUNDARY-END(210455101485)
            
            //--TRIMMABLE-BOUNDARY-START(206160134189)
            /*void */ TraceInformation(/*string?*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160134189);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                ;
            }
            //--TRIMMABLE-BOUNDARY-END(206160134189)
            
            //--TRIMMABLE-BOUNDARY-START(214750068781)
            /*void */ TraceTransfer(/*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750068781);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                /*TraceEventCache*/ let manager = new $.$sdts.SD.TraceEventCache().$ctor$1();
                if (this._internalSwitch.ShouldTrace(4096/*TraceEventType.Transfer*/) && this._listeners !== null)
                {
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                                    listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                    if ($.$sdts.SD.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item$1(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                        if ($.$sdts.SD.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                if ($.$sdts.SD.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214750068781)
            
            //--TRIMMABLE-BOUNDARY-START(60131246125)
            /*StringDictionary */ get Attributes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606082605);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                return this._attributes ??= new $.$scs.SCS.StringDictionary().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(60131246125)
            
            //--TRIMMABLE-BOUNDARY-START(68721180717)
            /*SourceLevels */ get DefaultLevel()
            {
                return this._switchLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(68721180717)
            
            //--TRIMMABLE-BOUNDARY-START(128850722861)
            /*EventHandler<InitializingTraceSourceEventArgs>?*/ static Initializing = null;
            //--TRIMMABLE-BOUNDARY-END(128850722861)
            
            //--TRIMMABLE-BOUNDARY-START(128850722861)
            //--TRIMMABLE-BOUNDARY-START(55836278829)
            static add_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836278829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceSource.Initializing = $.$$.S.Delegate.Combine$2($.$sdts.SD.TraceSource.Initializing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(55836278829)
            
            //--TRIMMABLE-BOUNDARY-START(158915493933)
            static remove_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915493933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceSource.Initializing = $.$$.S.Delegate.Remove($.$sdts.SD.TraceSource.Initializing, value);
            }
            //--TRIMMABLE-BOUNDARY-END(158915493933)
            
            //--TRIMMABLE-BOUNDARY-END(128850722861)
            
            //--TRIMMABLE-BOUNDARY-START(141735624749)
            /*void */ OnInitializing(/*InitializingTraceSourceEventArgs*/ e)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735624749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceSource.Initializing?.Invoke(this, e);
                $.$sdts.SD.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(TraceInternal.critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en5 = this.Listeners.GetEnumerator();
                            while ($en5.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en5.SC$1$IEnumerator$Current;
                                {
                                    $.$sdts.SD.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en6 = this.Listeners.GetEnumerator();
                    while ($en6.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en6.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        $.$sdts.SD.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                $.$sdts.SD.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141735624749)
            
            //--TRIMMABLE-BOUNDARY-START(137440657453)
            /*string */ get Name()
            {
                return this._sourceName;
            }
            //--TRIMMABLE-BOUNDARY-END(137440657453)
            
            //--TRIMMABLE-BOUNDARY-START(133145690157)
            /*TraceListenerCollection */ get Listeners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785951789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                return this._listeners;
            }
            //--TRIMMABLE-BOUNDARY-END(133145690157)
            
            //--TRIMMABLE-BOUNDARY-START(180390330413)
            /*SourceSwitch */ get Switch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965820973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Initialize();
                return this._internalSwitch;
            }
            /*SourceSwitch */ set Switch(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095363117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "Switch");
                this.Initialize();
                this._internalSwitch = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180390330413)
            
            //--TRIMMABLE-BOUNDARY-START(38656409645)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656409645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(167505428525)
                    this.s_tracesources = new ($.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.TraceSource)))().$ctor$1();
                    //--TRIMMABLE-BOUNDARY-END(167505428525)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656409645)
            
            static $h = 1703981;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(60131246125),
    {
      "p": 1310737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606082605,
        "f": 50331649
      },
      "n": "Attributes",
      "d": 1703981,
      "h": 60131246125,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(60131246125),
//--TRIMMABLE-BOUNDARY-START(68721180717),
    {
      "p": 720941,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196017197,
        "f": 50331649
      },
      "n": "DefaultLevel",
      "d": 1703981,
      "h": 68721180717,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68721180717),
//--TRIMMABLE-BOUNDARY-START(137440657453),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375886381,
        "f": 50331649
      },
      "n": "Name",
      "d": 1703981,
      "h": 137440657453,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137440657453),
//--TRIMMABLE-BOUNDARY-START(133145690157),
    {
      "p": 1572909,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785951789,
        "f": 50331649
      },
      "n": "Listeners",
      "d": 1703981,
      "h": 133145690157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133145690157),
//--TRIMMABLE-BOUNDARY-START(180390330413),
    {
      "p": 786477,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965820973,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176095363117,
        "f": 83886081
      },
      "n": "Switch",
      "d": 1703981,
      "h": 180390330413,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390330413)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771507757),
    {
      "r": 65537,
      "n": "_pruneCachedTraceSources",
      "d": 1703981,
      "h": 25771507757,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771507757),
//--TRIMMABLE-BOUNDARY-START(124555755565),
    {
      "r": 65537,
      "n": "Initialize",
      "d": 1703981,
      "h": 124555755565,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124555755565),
//--TRIMMABLE-BOUNDARY-START(64426213421),
    {
      "r": 65537,
      "n": "Close",
      "d": 1703981,
      "h": 64426213421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64426213421),
//--TRIMMABLE-BOUNDARY-START(73016148013),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1703981,
      "h": 73016148013,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016148013),
//--TRIMMABLE-BOUNDARY-START(120260788269),
    {
      "r": $.$typeArray($.$$.S.String).$h,
      "n": "GetSupportedAttributes",
      "d": 1703981,
      "h": 120260788269,
      "f": 16777360
    },
//--TRIMMABLE-BOUNDARY-END(120260788269),
//--TRIMMABLE-BOUNDARY-START(150325559341),
    {
      "r": 65537,
      "n": "RefreshAll",
      "d": 1703981,
      "h": 150325559341,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(150325559341),
//--TRIMMABLE-BOUNDARY-START(146030592045),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 1703981,
      "h": 146030592045,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(146030592045),
//--TRIMMABLE-BOUNDARY-START(201865166893),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        }
      ],
      "n": "TraceEvent",
      "o": "@$2",
      "d": 1703981,
      "h": 201865166893,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201865166893),
//--TRIMMABLE-BOUNDARY-START(197570199597),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceEvent",
      "o": "@$1",
      "d": 1703981,
      "h": 197570199597,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197570199597),
//--TRIMMABLE-BOUNDARY-START(193275232301),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceEvent",
      "d": 1703981,
      "h": 193275232301,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193275232301),
//--TRIMMABLE-BOUNDARY-START(184685297709),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": 131073
        }
      ],
      "n": "TraceData",
      "d": 1703981,
      "h": 184685297709,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(184685297709),
//--TRIMMABLE-BOUNDARY-START(188980265005),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceData",
      "o": "@$1",
      "d": 1703981,
      "h": 188980265005,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188980265005),
//--TRIMMABLE-BOUNDARY-START(210455101485),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "TraceInformation",
      "o": "@$1",
      "d": 1703981,
      "h": 210455101485,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210455101485),
//--TRIMMABLE-BOUNDARY-START(206160134189),
    {
      "r": 65537,
      "p": [
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceInformation",
      "d": 1703981,
      "h": 206160134189,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206160134189),
//--TRIMMABLE-BOUNDARY-START(214750068781),
    {
      "r": 65537,
      "p": [
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "relatedActivityId",
          "p": 89784321
        }
      ],
      "n": "TraceTransfer",
      "d": 1703981,
      "h": 214750068781,
      "f": 16777217,
      "a": [
        {
          "t": 69468161,
          "c": 8659402753,
          "a": [
            {
              "v": "TRACE",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214750068781),
//--TRIMMABLE-BOUNDARY-START(141735624749),
    {
      "r": 65537,
      "p": [
        {
          "n": "e",
          "p": 589869
        }
      ],
      "n": "OnInitializing",
      "d": 1703981,
      "h": 141735624749,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(141735624749)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(167505428525),
    {
      "t": $.$$.SCG.List$$($.$$.S.WeakReference$$($.$sdts.SD.TraceSource)).$h,
      "n": "s_tracesources",
      "d": 1703981,
      "h": 167505428525,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(167505428525),
//--TRIMMABLE-BOUNDARY-START(163210461229),
    {
      "t": 655361,
      "n": "s_LastCollectionCount",
      "d": 1703981,
      "h": 163210461229,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(163210461229),
//--TRIMMABLE-BOUNDARY-START(17181573165),
    {
      "t": 786477,
      "n": "_internalSwitch",
      "d": 1703981,
      "h": 17181573165,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17181573165),
//--TRIMMABLE-BOUNDARY-START(21476540461),
    {
      "t": 1572909,
      "n": "_listeners",
      "d": 1703981,
      "h": 21476540461,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21476540461),
//--TRIMMABLE-BOUNDARY-START(34361442349),
    {
      "t": 720941,
      "n": "_switchLevel",
      "d": 1703981,
      "h": 34361442349,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34361442349),
//--TRIMMABLE-BOUNDARY-START(30066475053),
    {
      "t": 1310721,
      "n": "_sourceName",
      "d": 1703981,
      "h": 30066475053,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30066475053),
//--TRIMMABLE-BOUNDARY-START(12886605869),
    {
      "t": 262145,
      "n": "_initCalled",
      "d": 1703981,
      "h": 12886605869,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12886605869),
//--TRIMMABLE-BOUNDARY-START(8591638573),
    {
      "t": 262145,
      "n": "_configInitializing",
      "d": 1703981,
      "h": 8591638573,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8591638573),
//--TRIMMABLE-BOUNDARY-START(4296671277),
    {
      "t": 1310737,
      "n": "_attributes",
      "d": 1703981,
      "h": 4296671277,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296671277)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47246344237),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703981,
      "h": 47246344237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47246344237),
//--TRIMMABLE-BOUNDARY-START(42951376941),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "defaultLevel",
          "p": 720941
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1703981,
      "h": 42951376941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42951376941)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(128850722861),
    {
      "e": $.$$.S.EventHandler$$($.$sdts.SD.InitializingTraceSourceEventArgs).$h,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$sdts.SD.InitializingTraceSourceEventArgs).$h
          }
        ],
        "n": "add_Initializing",
        "d": 1703981,
        "h": 55836278829,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": $.$$.S.EventHandler$$($.$sdts.SD.InitializingTraceSourceEventArgs).$h
          }
        ],
        "n": "remove_Initializing",
        "d": 1703981,
        "h": 158915493933,
        "f": 285212705
      },
      "n": "Initializing",
      "d": 1703981,
      "h": 128850722861,
      "f": 8388641
    },
//--TRIMMABLE-BOUNDARY-END(128850722861)
  ],
  "h": 1703981
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceSource`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceSource`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703981)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310765)
        $asm.$cls(`$sdts.SD.TraceInternal`, ($self) => class TraceInternal
        {
            //--TRIMMABLE-BOUNDARY-START(1376301)
            static $_TraceProvider;
            static get TraceProvider()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376301);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sdts.SD.TraceInternal;
                return $cls.$_TraceProvider ??= $asm.$ncls(`$sdts.SD.TraceInternal.TraceProvider`, ($self) => class TraceProvider extends $.$$.SD.DebugProvider
                {
                    //--TRIMMABLE-BOUNDARY-START(8591310893)
                    /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8591310893);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$sdts.SD.TraceInternal.Fail(message, detailMessage);
                    }
                    //--TRIMMABLE-BOUNDARY-END(8591310893)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886278189)
                    /*void */ OnIndentLevelChanged(/*int*/ indentLevel)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12886278189);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                let $en1 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                                while ($en1.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en1.SC$1$IEnumerator$Current;
                                    {
                                        listener.IndentLevel = indentLevel;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12886278189)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181245485)
                    /*void */ OnIndentSizeChanged(/*int*/ indentSize)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17181245485);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        //lock(TraceInternal.critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                let $en2 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                                while ($en2.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en2.SC$1$IEnumerator$Current;
                                    {
                                        listener.IndentSize = indentSize;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(17181245485)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476212781)
                    /*void */ Write(/*string?*/ message)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21476212781);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$sdts.SD.TraceInternal.Write$3(message);
                    }
                    //--TRIMMABLE-BOUNDARY-END(21476212781)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771180077)
                    /*void */ WriteLine(/*string?*/ message)
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(25771180077);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        $.$sdts.SD.TraceInternal.WriteLine$3(message);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25771180077)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343597)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4296343597);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343597)
                    
                    //--TRIMMABLE-BOUNDARY-START(4296343597)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4296343597)
                    
                    static $h = 1376301;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.SD.DebugProvider; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591310893),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "d": 1376301,
      "h": 8591310893,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591310893),
//--TRIMMABLE-BOUNDARY-START(12886278189),
    {
      "r": 65537,
      "p": [
        {
          "n": "indentLevel",
          "p": 655361
        }
      ],
      "n": "OnIndentLevelChanged",
      "d": 1376301,
      "h": 12886278189,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12886278189),
//--TRIMMABLE-BOUNDARY-START(17181245485),
    {
      "r": 65537,
      "p": [
        {
          "n": "indentSize",
          "p": 655361
        }
      ],
      "n": "OnIndentSizeChanged",
      "d": 1376301,
      "h": 17181245485,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181245485),
//--TRIMMABLE-BOUNDARY-START(21476212781),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "d": 1376301,
      "h": 21476212781,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(21476212781),
//--TRIMMABLE-BOUNDARY-START(25771180077),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "d": 1376301,
      "h": 25771180077,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25771180077)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343597),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1376301,
      "h": 4296343597,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343597)
  ],
  "d": 1310765,
  "h": 1376301
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceInternal+TraceProvider`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceInternal${separator}TraceProvider`; }
                }, $cls, ($v) => $cls.$_TraceProvider = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1376301)
            
            //--TRIMMABLE-BOUNDARY-START(137440264237)
            /*TraceListenerCollection?*/ static s_listeners = null;
            //--TRIMMABLE-BOUNDARY-END(137440264237)
            
            //--TRIMMABLE-BOUNDARY-START(133145296941)
            /*bool*/ static s_autoFlush = false;
            //--TRIMMABLE-BOUNDARY-END(133145296941)
            
            //--TRIMMABLE-BOUNDARY-START(150325166125)
            /*bool*/ static s_useGlobalLock = false;
            //--TRIMMABLE-BOUNDARY-END(150325166125)
            
            //--TRIMMABLE-BOUNDARY-START(141735231533)
            /*bool*/ static s_settingsInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(141735231533)
            
            //--TRIMMABLE-BOUNDARY-START(146030198829)
            /*bool*/ static s_settingsInitializing = false;
            //--TRIMMABLE-BOUNDARY-END(146030198829)
            
            //--TRIMMABLE-BOUNDARY-START(38656016429)
            /*object*/ static critSec = null;
            //--TRIMMABLE-BOUNDARY-END(38656016429)
            
            //--TRIMMABLE-BOUNDARY-START(124555362349)
            static /*TraceListenerCollection */ get Listeners()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490591277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.InitializeSettings();
                if ($.$sdts.SD.TraceInternal.s_listeners === null)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            if ($.$sdts.SD.TraceInternal.s_listeners === null)
                            {
                                $.$$.SD.Debug.SetProvider(new $.$sdts.SD.TraceInternal.TraceProvider().$ctor$2());
                                $.$sdts.SD.TraceInternal.s_listeners = new $.$sdts.SD.TraceListenerCollection().$ctor$1();
                                /*TraceListener*/ let defaultListener = new $.$sdts.SD.DefaultTraceListener().$ctor$4();
                                defaultListener.IndentLevel = $.$$.SD.Debug.IndentLevel;
                                defaultListener.IndentSize = $.$$.SD.Debug.IndentSize;
                                $.$sdts.SD.TraceInternal.s_listeners.Add(defaultListener);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                return $.$sdts.SD.TraceInternal.s_listeners;
            }
            //--TRIMMABLE-BOUNDARY-END(124555362349)
            
            //--TRIMMABLE-BOUNDARY-START(12886212653)
            /*string*/ static $AppName = null;
            static /*string */ get AppName()
            {
                return $.$sdts.SD.TraceInternal.AppName$ ??= ($.$$.SR.Assembly.GetEntryAssembly()?.GetName().Name ?? null) ?? $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212653)
            
            //--TRIMMABLE-BOUNDARY-START(30066081837)
            static /*bool */ get AutoFlush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720787501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.InitializeSettings();
                return $.$sdts.SD.TraceInternal.s_autoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915100717);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.InitializeSettings();
                $.$sdts.SD.TraceInternal.s_autoFlush = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30066081837)
            
            //--TRIMMABLE-BOUNDARY-START(197569806381)
            static /*bool */ get UseGlobalLock()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080525869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.InitializeSettings();
                return $.$sdts.SD.TraceInternal.s_useGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684904493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceInternal.InitializeSettings();
                $.$sdts.SD.TraceInternal.s_useGlobalLock = value;
            }
            //--TRIMMABLE-BOUNDARY-END(197569806381)
            
            //--TRIMMABLE-BOUNDARY-START(111670460461)
            static /*int */ get IndentLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310722093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SD.Debug.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505035309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.IndentLevel = value;
            }
            //--TRIMMABLE-BOUNDARY-END(111670460461)
            
            //--TRIMMABLE-BOUNDARY-START(115965427757)
            static /*int */ get IndentSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900656685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.SD.Debug.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094969901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.IndentSize = value;
            }
            //--TRIMMABLE-BOUNDARY-END(115965427757)
            
            //--TRIMMABLE-BOUNDARY-START(107375493165)
            static /*void */ Indent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375493165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.IndentLevel++;
            }
            //--TRIMMABLE-BOUNDARY-END(107375493165)
            
            //--TRIMMABLE-BOUNDARY-START(193274839085)
            static /*void */ Unindent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274839085);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.IndentLevel--;
            }
            //--TRIMMABLE-BOUNDARY-END(193274839085)
            
            //--TRIMMABLE-BOUNDARY-START(51540918317)
            static /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918317);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.s_listeners !== null)
                {
                    if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                    {
                        //lock(critSec)
                        try
                        {
                            $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                            {
                                let $en3 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                                while ($en3.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en3.SC$1$IEnumerator$Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        let $en4 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.SC$1$IEnumerator$MoveNext())
                        {
                            let listener = $en4.SC$1$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock(listener)
                                    try
                                    {
                                        $.$$.ST$1.Monitor.Enter$1(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.ST$1.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540918317)
            
            //--TRIMMABLE-BOUNDARY-START(34361049133)
            static /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.s_listeners !== null)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en5 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en5.SC$1$IEnumerator$Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361049133)
            
            //--TRIMMABLE-BOUNDARY-START(25771114541)
            static /*void */ Assert$2(/*bool*/ condition)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114541);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    return;
                }
                $.$sdts.SD.TraceInternal.Fail$1($.$$.S.String.Empty);
            }
            //--TRIMMABLE-BOUNDARY-END(25771114541)
            
            //--TRIMMABLE-BOUNDARY-START(21476147245)
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147245);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    return;
                }
                $.$sdts.SD.TraceInternal.Fail$1(message);
            }
            //--TRIMMABLE-BOUNDARY-END(21476147245)
            
            //--TRIMMABLE-BOUNDARY-START(17181179949)
            static /*void */ Assert(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    return;
                }
                $.$sdts.SD.TraceInternal.Fail(message, detailMessage);
            }
            //--TRIMMABLE-BOUNDARY-END(17181179949)
            
            //--TRIMMABLE-BOUNDARY-START(47245951021)
            static /*void */ Fail$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245951021);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en6 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en6.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en6.SC$1$IEnumerator$Current;
                                {
                                    listener.Fail$1(message);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en7 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en7.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en7.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Fail$1(message);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail$1(message);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245951021)
            
            //--TRIMMABLE-BOUNDARY-START(42950983725)
            static /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983725);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en8 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en8.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en8.SC$1$IEnumerator$Current;
                                {
                                    listener.Fail(message, detailMessage);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en9 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en9.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en9.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Fail(message, detailMessage);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail(message, detailMessage);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950983725)
            
            //--TRIMMABLE-BOUNDARY-START(120260395053)
            static /*void */ InitializeSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260395053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$sdts.SD.TraceInternal.s_settingsInitialized)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            if ($.$sdts.SD.TraceInternal.s_settingsInitializing)
                            {
                                return;
                            }
                            $.$sdts.SD.TraceInternal.s_settingsInitializing = true;
                            if (!$.$sdts.SD.TraceInternal.s_settingsInitialized)
                            {
                                $.$sdts.SD.TraceInternal.s_autoFlush = $.$sdts.SD.DiagnosticsConfiguration.AutoFlush;
                                $.$sdts.SD.TraceInternal.s_useGlobalLock = $.$sdts.SD.DiagnosticsConfiguration.UseGlobalLock;
                                $.$sdts.SD.TraceInternal.s_settingsInitialized = true;
                                $.$sdts.SD.TraceInternal.s_settingsInitializing = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120260395053)
            
            //--TRIMMABLE-BOUNDARY-START(128850329645)
            static /*void */ Refresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850329645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        $.$sdts.SD.TraceInternal.s_settingsInitialized = false;
                        $.$sdts.SD.TraceInternal.s_listeners = null;
                        $.$$.SD.Debug.IndentSize = $.$sdts.SD.DiagnosticsConfiguration.IndentSize;
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
                $.$sdts.SD.TraceInternal.InitializeSettings();
            }
            //--TRIMMABLE-BOUNDARY-END(128850329645)
            
            //--TRIMMABLE-BOUNDARY-START(188979871789)
            static /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979871789);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TraceEventCache*/ let EventCache = new $.$sdts.SD.TraceEventCache().$ctor$1();
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            if (args === null)
                            {
                                let $en10 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                                while ($en10.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en10.SC$1$IEnumerator$Current;
                                    {
                                        listener.TraceEvent$1(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                            else 
                            {
                                let $en11 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                                while ($en11.SC$1$IEnumerator$MoveNext())
                                {
                                    let listener = $en11.SC$1$IEnumerator$Current;
                                    {
                                        listener.TraceEvent(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format, args);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    if (args === null)
                    {
                        let $en12 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                        while ($en12.SC$1$IEnumerator$MoveNext())
                        {
                            let listener = $en12.SC$1$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock(listener)
                                    try
                                    {
                                        $.$$.ST$1.Monitor.Enter$1(listener)
                                        {
                                            listener.TraceEvent$1(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format);
                                            if ($.$sdts.SD.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.ST$1.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent$1(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    else 
                    {
                        let $en13 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                        while ($en13.SC$1$IEnumerator$MoveNext())
                        {
                            let listener = $en13.SC$1$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock(listener)
                                    try
                                    {
                                        $.$$.ST$1.Monitor.Enter$1(listener)
                                        {
                                            listener.TraceEvent(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format, args);
                                            if ($.$sdts.SD.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.ST$1.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent(EventCache, $.$sdts.SD.TraceInternal.AppName, eventType, id, format, args);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188979871789)
            
            //--TRIMMABLE-BOUNDARY-START(214749675565)
            static /*void */ Write$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749675565);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en14 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en14.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en14.SC$1$IEnumerator$Current;
                                {
                                    listener.Write$3(message);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en15 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en15.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en15.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$3(message);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$3(message);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749675565)
            
            //--TRIMMABLE-BOUNDARY-START(206159740973)
            static /*void */ Write$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159740973);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en16 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en16.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en16.SC$1$IEnumerator$Current;
                                {
                                    listener.Write$1(value);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en17 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en17.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en17.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$1(value);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$1(value);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159740973)
            
            //--TRIMMABLE-BOUNDARY-START(210454708269)
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454708269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en18 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en18.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en18.SC$1$IEnumerator$Current;
                                {
                                    listener.Write$2(message, category);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en19 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en19.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en19.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$2(message, category);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$2(message, category);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454708269)
            
            //--TRIMMABLE-BOUNDARY-START(201864773677)
            static /*void */ Write(/*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864773677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en20 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en20.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en20.SC$1$IEnumerator$Current;
                                {
                                    listener.Write(value, category);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en21 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en21.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en21.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.Write(value, category);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write(value, category);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864773677)
            
            //--TRIMMABLE-BOUNDARY-START(249109413933)
            static /*void */ WriteLine$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109413933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en22 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en22.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en22.SC$1$IEnumerator$Current;
                                {
                                    listener.WriteLine$3(message);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en23 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en23.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en23.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$3(message);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$3(message);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249109413933)
            
            //--TRIMMABLE-BOUNDARY-START(240519479341)
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519479341);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en24 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en24.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en24.SC$1$IEnumerator$Current;
                                {
                                    listener.WriteLine$1(value);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en25 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en25.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en25.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$1(value);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$1(value);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240519479341)
            
            //--TRIMMABLE-BOUNDARY-START(244814446637)
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814446637);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en26 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en26.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en26.SC$1$IEnumerator$Current;
                                {
                                    listener.WriteLine$2(message, category);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en27 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en27.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en27.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$2(message, category);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$2(message, category);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814446637)
            
            //--TRIMMABLE-BOUNDARY-START(236224512045)
            static /*void */ WriteLine(/*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224512045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdts.SD.TraceInternal.UseGlobalLock)
                {
                    //lock(critSec)
                    try
                    {
                        $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                        {
                            let $en28 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                            while ($en28.SC$1$IEnumerator$MoveNext())
                            {
                                let listener = $en28.SC$1$IEnumerator$Current;
                                {
                                    listener.WriteLine(value, category);
                                    if ($.$sdts.SD.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                    }
                }
                else 
                {
                    let $en29 = $.$sdts.SD.TraceInternal.Listeners.GetEnumerator();
                    while ($en29.SC$1$IEnumerator$MoveNext())
                    {
                        let listener = $en29.SC$1$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock(listener)
                                try
                                {
                                    $.$$.ST$1.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine(value, category);
                                        if ($.$sdts.SD.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.ST$1.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine(value, category);
                                if ($.$sdts.SD.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236224512045)
            
            //--TRIMMABLE-BOUNDARY-START(231929544749)
            static /*void */ WriteIf$3(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929544749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.Write$3(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929544749)
            
            //--TRIMMABLE-BOUNDARY-START(223339610157)
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339610157);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.Write$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339610157)
            
            //--TRIMMABLE-BOUNDARY-START(227634577453)
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634577453);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.Write$2(message, category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227634577453)
            
            //--TRIMMABLE-BOUNDARY-START(219044642861)
            static /*void */ WriteIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044642861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.Write(value, category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044642861)
            
            //--TRIMMABLE-BOUNDARY-START(266289283117)
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289283117);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.WriteLine$3(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(266289283117)
            
            //--TRIMMABLE-BOUNDARY-START(257699348525)
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699348525);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.WriteLine$1(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257699348525)
            
            //--TRIMMABLE-BOUNDARY-START(261994315821)
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994315821);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.WriteLine$2(message, category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261994315821)
            
            //--TRIMMABLE-BOUNDARY-START(253404381229)
            static /*void */ WriteLineIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404381229);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (condition)
                {
                    $.$sdts.SD.TraceInternal.WriteLine(value, category);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253404381229)
            
            //--TRIMMABLE-BOUNDARY-START(8591245357)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(38656016429)
                    this.critSec = new $.$$.S.Object().$ctor();
                    //--TRIMMABLE-BOUNDARY-END(38656016429)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591245357)
            
            static $h = 1310765;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(124555362349),
    {
      "p": 1572909,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490591277,
        "f": 50331681
      },
      "n": "Listeners",
      "d": 1310765,
      "h": 124555362349,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(124555362349),
//--TRIMMABLE-BOUNDARY-START(12886212653),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130852909,
        "f": 50331688
      },
      "n": "AppName",
      "d": 1310765,
      "h": 12886212653,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(12886212653),
//--TRIMMABLE-BOUNDARY-START(30066081837),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720787501,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158915100717,
        "f": 83886113
      },
      "n": "AutoFlush",
      "d": 1310765,
      "h": 30066081837,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066081837),
//--TRIMMABLE-BOUNDARY-START(197569806381),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080525869,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184684904493,
        "f": 83886113
      },
      "n": "UseGlobalLock",
      "d": 1310765,
      "h": 197569806381,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197569806381),
//--TRIMMABLE-BOUNDARY-START(111670460461),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310722093,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167505035309,
        "f": 83886113
      },
      "n": "IndentLevel",
      "d": 1310765,
      "h": 111670460461,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111670460461),
//--TRIMMABLE-BOUNDARY-START(115965427757),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900656685,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176094969901,
        "f": 83886113
      },
      "n": "IndentSize",
      "d": 1310765,
      "h": 115965427757,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(115965427757)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(107375493165),
    {
      "r": 65537,
      "n": "Indent",
      "d": 1310765,
      "h": 107375493165,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107375493165),
//--TRIMMABLE-BOUNDARY-START(193274839085),
    {
      "r": 65537,
      "n": "Unindent",
      "d": 1310765,
      "h": 193274839085,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(193274839085),
//--TRIMMABLE-BOUNDARY-START(51540918317),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1310765,
      "h": 51540918317,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540918317),
//--TRIMMABLE-BOUNDARY-START(34361049133),
    {
      "r": 65537,
      "n": "Close",
      "d": 1310765,
      "h": 34361049133,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361049133),
//--TRIMMABLE-BOUNDARY-START(25771114541),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        }
      ],
      "n": "Assert",
      "o": "@$2",
      "d": 1310765,
      "h": 25771114541,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771114541),
//--TRIMMABLE-BOUNDARY-START(21476147245),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Assert",
      "o": "@$1",
      "d": 1310765,
      "h": 21476147245,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476147245),
//--TRIMMABLE-BOUNDARY-START(17181179949),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Assert",
      "d": 1310765,
      "h": 17181179949,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181179949),
//--TRIMMABLE-BOUNDARY-START(47245951021),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 1310765,
      "h": 47245951021,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245951021),
//--TRIMMABLE-BOUNDARY-START(42950983725),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "d": 1310765,
      "h": 42950983725,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950983725),
//--TRIMMABLE-BOUNDARY-START(120260395053),
    {
      "r": 65537,
      "n": "InitializeSettings",
      "d": 1310765,
      "h": 120260395053,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(120260395053),
//--TRIMMABLE-BOUNDARY-START(128850329645),
    {
      "r": 65537,
      "n": "Refresh",
      "d": 1310765,
      "h": 128850329645,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128850329645),
//--TRIMMABLE-BOUNDARY-START(188979871789),
    {
      "r": 65537,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "format",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h,
          "f": 16
        }
      ],
      "n": "TraceEvent",
      "d": 1310765,
      "h": 188979871789,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188979871789),
//--TRIMMABLE-BOUNDARY-START(214749675565),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$3",
      "d": 1310765,
      "h": 214749675565,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(214749675565),
//--TRIMMABLE-BOUNDARY-START(206159740973),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1310765,
      "h": 206159740973,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(206159740973),
//--TRIMMABLE-BOUNDARY-START(210454708269),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 1310765,
      "h": 210454708269,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(210454708269),
//--TRIMMABLE-BOUNDARY-START(201864773677),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "Write",
      "d": 1310765,
      "h": 201864773677,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(201864773677),
//--TRIMMABLE-BOUNDARY-START(249109413933),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$3",
      "d": 1310765,
      "h": 249109413933,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249109413933),
//--TRIMMABLE-BOUNDARY-START(240519479341),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLine",
      "o": "@$1",
      "d": 1310765,
      "h": 240519479341,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(240519479341),
//--TRIMMABLE-BOUNDARY-START(244814446637),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$2",
      "d": 1310765,
      "h": 244814446637,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(244814446637),
//--TRIMMABLE-BOUNDARY-START(236224512045),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "d": 1310765,
      "h": 236224512045,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(236224512045),
//--TRIMMABLE-BOUNDARY-START(231929544749),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "o": "@$3",
      "d": 1310765,
      "h": 231929544749,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(231929544749),
//--TRIMMABLE-BOUNDARY-START(223339610157),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteIf",
      "o": "@$1",
      "d": 1310765,
      "h": 223339610157,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(223339610157),
//--TRIMMABLE-BOUNDARY-START(227634577453),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "o": "@$2",
      "d": 1310765,
      "h": 227634577453,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(227634577453),
//--TRIMMABLE-BOUNDARY-START(219044642861),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteIf",
      "d": 1310765,
      "h": 219044642861,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(219044642861),
//--TRIMMABLE-BOUNDARY-START(266289283117),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "o": "@$3",
      "d": 1310765,
      "h": 266289283117,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(266289283117),
//--TRIMMABLE-BOUNDARY-START(257699348525),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "WriteLineIf",
      "o": "@$1",
      "d": 1310765,
      "h": 257699348525,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(257699348525),
//--TRIMMABLE-BOUNDARY-START(261994315821),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "o": "@$2",
      "d": 1310765,
      "h": 261994315821,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(261994315821),
//--TRIMMABLE-BOUNDARY-START(253404381229),
    {
      "r": 65537,
      "p": [
        {
          "n": "condition",
          "p": 262145
        },
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "category",
          "p": 1310721
        }
      ],
      "n": "WriteLineIf",
      "d": 1310765,
      "h": 253404381229,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(253404381229)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(137440264237),
    {
      "t": 1572909,
      "n": "s_listeners",
      "d": 1310765,
      "h": 137440264237,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(137440264237),
//--TRIMMABLE-BOUNDARY-START(133145296941),
    {
      "t": 262145,
      "n": "s_autoFlush",
      "d": 1310765,
      "h": 133145296941,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(133145296941),
//--TRIMMABLE-BOUNDARY-START(150325166125),
    {
      "t": 262145,
      "n": "s_useGlobalLock",
      "d": 1310765,
      "h": 150325166125,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(150325166125),
//--TRIMMABLE-BOUNDARY-START(141735231533),
    {
      "t": 262145,
      "n": "s_settingsInitialized",
      "d": 1310765,
      "h": 141735231533,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(141735231533),
//--TRIMMABLE-BOUNDARY-START(146030198829),
    {
      "t": 262145,
      "n": "s_settingsInitializing",
      "d": 1310765,
      "h": 146030198829,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(146030198829),
//--TRIMMABLE-BOUNDARY-START(38656016429),
    {
      "t": 131073,
      "n": "critSec",
      "d": 1310765,
      "h": 38656016429,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38656016429)
  ],
  "h": 1310765
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sdts.SD.TraceInternal.TraceProvider ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceInternal`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceInternal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310765)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572909)
        $asm.$cls(`$sdts.SD.TraceListenerCollection`, ($self) => class TraceListenerCollection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296540205)
            /*List<TraceListener?>*/ _list = null;
            //--TRIMMABLE-BOUNDARY-END(4296540205)
            
            //--TRIMMABLE-BOUNDARY-START(8591507501)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591507501);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._list = new ($.$$.SCG.List$$($.$sdts.SD.TraceListener))().$ctor$3(1);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591507501)
            
            //--TRIMMABLE-BOUNDARY-START(206160003117)
            /*TraceListener*/ get_Item$1(/*int*/ i)
            {
                return this._list.get_Item(i);
            }
            /*void*/ set_Item$1(/*int*/ i, /*TraceListener*/ value)
            {
                $.$sdts.SD.TraceListenerCollection.InitializeListener(value);
                this._list.set_Item(i, value);
            }
            //--TRIMMABLE-BOUNDARY-END(206160003117)
            
            //--TRIMMABLE-BOUNDARY-START(210454970413)
            /*TraceListener?*/ get_Item$2(/*string*/ name)
            {
                let $en1 = this.GetEnumerator();
                while ($en1.SC$1$IEnumerator$MoveNext())
                {
                    let listener = $en1.SC$1$IEnumerator$Current;
                    {
                        if (listener.Name === name)
                        {
                            return listener;
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(210454970413)
            
            //--TRIMMABLE-BOUNDARY-START(38656278573)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246213165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(38656278573)
            
            //--TRIMMABLE-BOUNDARY-START(12886474797)
            /*int */ Add(/*TraceListener*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886474797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceListenerCollection.InitializeListener(listener);
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        return (this._list).SC$1$IList$Add(listener);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886474797)
            
            //--TRIMMABLE-BOUNDARY-START(17181442093)
            /*void */ AddRange(/*TraceListener[]*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181442093);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                for(/*int*/ let i = 0; (i) < (value.length); i = ((((i) + (1)) | 0)))
                {
                    this.Add($.$$.System.Array.$ReadT1.call(value, i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181442093)
            
            //--TRIMMABLE-BOUNDARY-START(21476409389)
            /*void */ AddRange$1(/*TraceListenerCollection*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476409389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*int*/ let currentCount = value.Count;
                for(/*int*/ let i = 0; i < currentCount; i = ((((i) + (1)) | 0)))
                {
                    this.Add(value.get_Item$1(i));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476409389)
            
            //--TRIMMABLE-BOUNDARY-START(25771376685)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771376685);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._list.Clear();
            }
            //--TRIMMABLE-BOUNDARY-END(25771376685)
            
            //--TRIMMABLE-BOUNDARY-START(30066343981)
            /*bool */ Contains(/*TraceListener?*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066343981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).SC$1$IList$Contains(listener);
            }
            //--TRIMMABLE-BOUNDARY-END(30066343981)
            
            //--TRIMMABLE-BOUNDARY-START(34361311277)
            /*void */ CopyTo(/*TraceListener[]*/ listeners, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361311277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this).SC$1$ICollection$CopyTo(listeners, index);
            }
            //--TRIMMABLE-BOUNDARY-END(34361311277)
            
            //--TRIMMABLE-BOUNDARY-START(68721049645)
            /*IEnumerator */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721049645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list.GetEnumerator();
            }
            //--TRIMMABLE-BOUNDARY-END(68721049645)
            
            //--TRIMMABLE-BOUNDARY-START(77310984237)
            static /*void */ InitializeListener(/*TraceListener*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310984237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(listener, "listener");
                listener.IndentSize = $.$sdts.SD.TraceInternal.IndentSize;
                listener.IndentLevel = $.$sdts.SD.TraceInternal.IndentLevel;
            }
            //--TRIMMABLE-BOUNDARY-END(77310984237)
            
            //--TRIMMABLE-BOUNDARY-START(73016016941)
            /*int */ IndexOf(/*TraceListener?*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016016941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this).SC$1$IList$IndexOf(listener);
            }
            //--TRIMMABLE-BOUNDARY-END(73016016941)
            
            //--TRIMMABLE-BOUNDARY-START(81605951533)
            /*void */ Insert(/*int*/ index, /*TraceListener*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605951533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.TraceListenerCollection.InitializeListener(listener);
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        this._list.Insert(index, listener);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605951533)
            
            //--TRIMMABLE-BOUNDARY-START(85900918829)
            /*void */ Remove(/*TraceListener?*/ listener)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900918829);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this).SC$1$IList$Remove(listener);
            }
            //--TRIMMABLE-BOUNDARY-END(85900918829)
            
            //--TRIMMABLE-BOUNDARY-START(90195886125)
            /*void */ Remove$1(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195886125);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TraceListener?*/ let listener = this.get_Item$2(name);
                if (listener !== null)
                {
                    (this).SC$1$IList$Remove(listener);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195886125)
            
            //--TRIMMABLE-BOUNDARY-START(94490853421)
            /*void */ RemoveAt(/*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490853421);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        this._list.RemoveAt(index);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490853421)
            
            //--TRIMMABLE-BOUNDARY-START(201865035821)
            //--TRIMMABLE-BOUNDARY-START(77373112321)
            /*object?*/ SC$1$IList$get_Item(/*int*/ index)
            {
                return this._list.get_Item(index);
            }
            /*void*/ SC$1$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.SD.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sdts.S.SR.MustAddListener, "value");
                }
                $.$sdts.SD.TraceListenerCollection.InitializeListener(listener);
                this._list.set_Item(index, listener);
            }
            //--TRIMMABLE-BOUNDARY-END(77373112321)
            
            //--TRIMMABLE-BOUNDARY-END(201865035821)
            
            //--TRIMMABLE-BOUNDARY-START(184685166637)
            /*bool */ get SC$1$IList$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915362861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(184685166637)
            
            //--TRIMMABLE-BOUNDARY-START(180390199341)
            /*bool */ get SC$1$IList$IsFixedSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325428269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(180390199341)
            
            //--TRIMMABLE-BOUNDARY-START(137440526381)
            /*int */ SC$1$IList$Add(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440526381);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.SD.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sdts.S.SR.MustAddListener, "value");
                }
                $.$sdts.SD.TraceListenerCollection.InitializeListener(listener);
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        return (this._list).SC$1$IList$Add(value);
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137440526381)
            
            //--TRIMMABLE-BOUNDARY-START(141735493677)
            /*bool */ SC$1$IList$Contains(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735493677);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list.Contains($.$cast(value, $.$sdts.SD.TraceListener));
            }
            //--TRIMMABLE-BOUNDARY-END(141735493677)
            
            //--TRIMMABLE-BOUNDARY-START(171800264749)
            /*int */ SC$1$IList$IndexOf(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800264749);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._list.IndexOf$2($.$cast(value, $.$sdts.SD.TraceListener));
            }
            //--TRIMMABLE-BOUNDARY-END(171800264749)
            
            //--TRIMMABLE-BOUNDARY-START(176095232045)
            /*void */ SC$1$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095232045);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.SD.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13($.$sdts.S.SR.MustAddListener, "value");
                }
                $.$sdts.SD.TraceListenerCollection.InitializeListener(listener);
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        this._list.Insert(index, $.$cast(value, $.$sdts.SD.TraceListener));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176095232045)
            
            //--TRIMMABLE-BOUNDARY-START(188980133933)
            /*void */ SC$1$IList$Remove(/*object?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980133933);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //lock(TraceInternal.critSec)
                try
                {
                    $.$$.ST$1.Monitor.Enter$1($.$sdts.SD.TraceInternal.critSec)
                    {
                        this._list.Remove($.$cast(value, $.$sdts.SD.TraceListener));
                    }
                }
                finally
                {
                    $.$$.ST$1.Monitor.Exit($.$sdts.SD.TraceInternal.critSec)
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188980133933)
            
            //--TRIMMABLE-BOUNDARY-START(133145559085)
            /*object */ get SC$1$ICollection$SyncRoot()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555624493);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(133145559085)
            
            //--TRIMMABLE-BOUNDARY-START(128850591789)
            /*bool */ get SC$1$ICollection$IsSynchronized()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965689901);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(128850591789)
            
            //--TRIMMABLE-BOUNDARY-START(107375755309)
            /*void */ SC$1$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375755309);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                (this._list).SC$1$ICollection$CopyTo(array, index);
            }
            //--TRIMMABLE-BOUNDARY-END(107375755309)
            
            //--TRIMMABLE-BOUNDARY-START(8653635585)
            //Generated interface implemetation for System.Collections.IList.Clear()
            SC$1$IList$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653635585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8653635585)
            
            //--TRIMMABLE-BOUNDARY-START(64488210433)
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            SC$1$IList$RemoveAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64488210433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.RemoveAt(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(64488210433)
            
            //--TRIMMABLE-BOUNDARY-START(17242980353)
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get SC$1$ICollection$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8653045761);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(17242980353)
            
            //--TRIMMABLE-BOUNDARY-START(4358340609)
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            SC$1$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4358340609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4358340609)
            
            //--TRIMMABLE-BOUNDARY-START(8591507501)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8591507501)
            
            static $h = 1572909;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(206160003117),
    {
      "p": 1507373,
      "i": [
        {
          "n": "i",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836147757,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 103080788013,
        "f": 83886081
      },
      "n": "Item",
      "o": "@$1",
      "d": 1572909,
      "h": 206160003117,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(206160003117),
//--TRIMMABLE-BOUNDARY-START(210454970413),
    {
      "p": 1507373,
      "i": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426082349,
        "f": 50331649
      },
      "n": "Item",
      "o": "@$2",
      "d": 1572909,
      "h": 210454970413,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(210454970413),
//--TRIMMABLE-BOUNDARY-START(38656278573),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246213165,
        "f": 50331649
      },
      "n": "Count",
      "d": 1572909,
      "h": 38656278573,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656278573),
//--TRIMMABLE-BOUNDARY-START(201865035821),
    {
      "p": 131073,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505297453,
        "f": 50331650
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197570068525,
        "f": 83886082
      },
      "n": "{63700993}.this[]",
      "o": "SC$1$IList$Item",
      "d": 1572909,
      "h": 201865035821,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(201865035821),
//--TRIMMABLE-BOUNDARY-START(184685166637),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915362861,
        "f": 50331650
      },
      "n": "{63700993}.IsReadOnly",
      "o": "SC$1$IList$IsReadOnly",
      "d": 1572909,
      "h": 184685166637,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(184685166637),
//--TRIMMABLE-BOUNDARY-START(180390199341),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325428269,
        "f": 50331650
      },
      "n": "{63700993}.IsFixedSize",
      "o": "SC$1$IList$IsFixedSize",
      "d": 1572909,
      "h": 180390199341,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(180390199341),
//--TRIMMABLE-BOUNDARY-START(133145559085),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555624493,
        "f": 50331650
      },
      "n": "{63111169}.SyncRoot",
      "o": "SC$1$ICollection$SyncRoot",
      "d": 1572909,
      "h": 133145559085,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(133145559085),
//--TRIMMABLE-BOUNDARY-START(128850591789),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965689901,
        "f": 50331650
      },
      "n": "{63111169}.IsSynchronized",
      "o": "SC$1$ICollection$IsSynchronized",
      "d": 1572909,
      "h": 128850591789,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(128850591789)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886474797),
    {
      "r": 655361,
      "p": [
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "Add",
      "d": 1572909,
      "h": 12886474797,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886474797),
//--TRIMMABLE-BOUNDARY-START(17181442093),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": $.$typeArray($.$sdts.SD.TraceListener).$h
        }
      ],
      "n": "AddRange",
      "d": 1572909,
      "h": 17181442093,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181442093),
//--TRIMMABLE-BOUNDARY-START(21476409389),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 1572909
        }
      ],
      "n": "AddRange",
      "o": "@$1",
      "d": 1572909,
      "h": 21476409389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476409389),
//--TRIMMABLE-BOUNDARY-START(25771376685),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1572909,
      "h": 25771376685,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771376685),
//--TRIMMABLE-BOUNDARY-START(30066343981),
    {
      "r": 262145,
      "p": [
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "Contains",
      "d": 1572909,
      "h": 30066343981,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30066343981),
//--TRIMMABLE-BOUNDARY-START(34361311277),
    {
      "r": 65537,
      "p": [
        {
          "n": "listeners",
          "p": $.$typeArray($.$sdts.SD.TraceListener).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1572909,
      "h": 34361311277,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34361311277),
//--TRIMMABLE-BOUNDARY-START(68721049645),
    {
      "r": 63504385,
      "n": "GetEnumerator",
      "d": 1572909,
      "h": 68721049645,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68721049645),
//--TRIMMABLE-BOUNDARY-START(77310984237),
    {
      "r": 65537,
      "p": [
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "InitializeListener",
      "d": 1572909,
      "h": 77310984237,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(77310984237),
//--TRIMMABLE-BOUNDARY-START(73016016941),
    {
      "r": 655361,
      "p": [
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "IndexOf",
      "d": 1572909,
      "h": 73016016941,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73016016941),
//--TRIMMABLE-BOUNDARY-START(81605951533),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "Insert",
      "d": 1572909,
      "h": 81605951533,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605951533),
//--TRIMMABLE-BOUNDARY-START(85900918829),
    {
      "r": 65537,
      "p": [
        {
          "n": "listener",
          "p": 1507373
        }
      ],
      "n": "Remove",
      "d": 1572909,
      "h": 85900918829,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85900918829),
//--TRIMMABLE-BOUNDARY-START(90195886125),
    {
      "r": 65537,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "Remove",
      "o": "@$1",
      "d": 1572909,
      "h": 90195886125,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(90195886125),
//--TRIMMABLE-BOUNDARY-START(94490853421),
    {
      "r": 65537,
      "p": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "n": "RemoveAt",
      "d": 1572909,
      "h": 94490853421,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94490853421)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296540205),
    {
      "t": $.$$.SCG.List$$($.$sdts.SD.TraceListener).$h,
      "n": "_list",
      "d": 1572909,
      "h": 4296540205,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296540205)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591507501),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1572909,
      "h": 8591507501,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(8591507501)
  ],
  "h": 1572909
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.IList, $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceListenerCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceListenerCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572909)
        
        

        //--TRIMMABLE-BOUNDARY-START(786477)
        $asm.$cls(`$sdts.SD.SourceSwitch`, ($self) => class SourceSwitch extends $.$sdts.SD.Switch
        {
            //--TRIMMABLE-BOUNDARY-START(8590721069)
            $ctor$4(/*string*/ name)
            {
                super.$ctor$2(name, $.$$.S.String.Empty);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590721069);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590721069)
            
            //--TRIMMABLE-BOUNDARY-START(4295753773)
            $ctor$3(/*string*/ displayName, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, $.$$.S.String.Empty, defaultSwitchValue);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753773);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753773)
            
            //--TRIMMABLE-BOUNDARY-START(21475622957)
            /*SourceLevels */ get Level()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.SwitchSetting, $.$sdts.SD.SourceLevels);
            }
            /*SourceLevels */ set Level(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524845);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SwitchSetting = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622957)
            
            //--TRIMMABLE-BOUNDARY-START(38655492141)
            /*bool */ ShouldTrace(/*TraceEventType*/ eventType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655492141);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.SwitchSetting & eventType) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(38655492141)
            
            //--TRIMMABLE-BOUNDARY-START(25770590253)
            /*void */ OnValueChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590253);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SwitchSetting = $.$$.S.Enum.Parse$6($.$sdts.SD.SourceLevels, this.Value, true);
            }
            //--TRIMMABLE-BOUNDARY-END(25770590253)
            
            static $h = 786477;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.Switch; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475622957),
    {
      "p": 720941,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180655661,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34360524845,
        "f": 83886081
      },
      "n": "Level",
      "d": 786477,
      "h": 21475622957,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475622957)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655492141),
    {
      "r": 262145,
      "p": [
        {
          "n": "eventType",
          "p": 1179693
        }
      ],
      "n": "ShouldTrace",
      "d": 786477,
      "h": 38655492141,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655492141),
//--TRIMMABLE-BOUNDARY-START(25770590253),
    {
      "r": 65537,
      "n": "OnValueChanged",
      "d": 786477,
      "h": 25770590253,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25770590253)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721069),
    {
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786477,
      "h": 8590721069,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721069),
//--TRIMMABLE-BOUNDARY-START(4295753773),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "defaultSwitchValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786477,
      "h": 4295753773,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753773)
  ],
  "h": 786477
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SourceSwitch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SourceSwitch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786477)
        
        

        //--TRIMMABLE-BOUNDARY-START(458797)
        $asm.$cls(`$sdts.SD.EventTypeFilter`, ($self) => class EventTypeFilter extends $.$sdts.SD.TraceFilter
        {
            //--TRIMMABLE-BOUNDARY-START(4295426093)
            /*SourceLevels*/ _level = 0;
            //--TRIMMABLE-BOUNDARY-END(4295426093)
            
            //--TRIMMABLE-BOUNDARY-START(8590393389)
            $ctor$2(/*SourceLevels*/ level)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393389);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._level = level;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590393389)
            
            //--TRIMMABLE-BOUNDARY-START(34360197165)
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (eventType & this._level) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(34360197165)
            
            //--TRIMMABLE-BOUNDARY-START(12885360685)
            /*SourceLevels */ get EventType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._level;
            }
            /*SourceLevels */ set EventType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229869);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._level = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885360685)
            
            static $h = 458797;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.TraceFilter; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885360685),
    {
      "p": 720941,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475295277,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065229869,
        "f": 83886081
      },
      "n": "EventType",
      "d": 458797,
      "h": 12885360685,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885360685)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360197165),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "data1",
          "p": 131073
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ShouldTrace",
      "d": 458797,
      "h": 34360197165,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34360197165)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426093),
    {
      "t": 720941,
      "n": "_level",
      "d": 458797,
      "h": 4295426093,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426093)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590393389),
    {
      "p": [
        {
          "n": "level",
          "p": 720941
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458797,
      "h": 8590393389,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393389)
  ],
  "h": 458797
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.EventTypeFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}EventTypeFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458797)
        
        

        //--TRIMMABLE-BOUNDARY-START(983085)
        $asm.$cls(`$sdts.SD.SwitchLevelAttribute`, ($self) => class SwitchLevelAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(4295950381)
            /*Type*/ _type = null;
            //--TRIMMABLE-BOUNDARY-END(4295950381)
            
            //--TRIMMABLE-BOUNDARY-START(8590917677)
            $ctor$2(/*Type*/ switchLevelType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917677);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SwitchLevelType = switchLevelType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917677)
            
            //--TRIMMABLE-BOUNDARY-START(30065754157)
            /*Type */ get SwitchLevelType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852269);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type;
            }
            /*Type */ set SwitchLevelType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786861);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                this._type = value;
            }
            //--TRIMMABLE-BOUNDARY-END(30065754157)
            
            static $h = 983085;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065754157),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180852269,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770786861,
        "f": 83886081
      },
      "n": "SwitchLevelType",
      "d": 983085,
      "h": 30065754157,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065754157)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295950381),
    {
      "t": 188547073,
      "n": "_type",
      "d": 983085,
      "h": 4295950381,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295950381)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590917677),
    {
      "p": [
        {
          "n": "switchLevelType",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983085,
      "h": 8590917677,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590917677)
  ],
  "h": 983085,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 4,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SwitchLevelAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SwitchLevelAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983085)
        
        

        //--TRIMMABLE-BOUNDARY-START(655405)
        $asm.$cls(`$sdts.SD.SourceFilter`, ($self) => class SourceFilter extends $.$sdts.SD.TraceFilter
        {
            //--TRIMMABLE-BOUNDARY-START(4295622701)
            /*string*/ _src = null;
            //--TRIMMABLE-BOUNDARY-END(4295622701)
            
            //--TRIMMABLE-BOUNDARY-START(8590589997)
            $ctor$2(/*string*/ source)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590589997);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Source = source;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590589997)
            
            //--TRIMMABLE-BOUNDARY-START(30065426477)
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065426477);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$$.S.String.Equals$4(this._src, source);
            }
            //--TRIMMABLE-BOUNDARY-END(30065426477)
            
            //--TRIMMABLE-BOUNDARY-START(34360393773)
            /*string */ get Source()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524589);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._src;
            }
            /*string */ set Source(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459181);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "Source");
                this._src = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360393773)
            
            static $h = 655405;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.TraceFilter; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360393773),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180524589,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770459181,
        "f": 83886081
      },
      "n": "Source",
      "d": 655405,
      "h": 34360393773,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360393773)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065426477),
    {
      "r": 262145,
      "p": [
        {
          "n": "cache",
          "p": 1114157
        },
        {
          "n": "source",
          "p": 1310721
        },
        {
          "n": "eventType",
          "p": 1179693
        },
        {
          "n": "id",
          "p": 655361
        },
        {
          "n": "formatOrMessage",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$typeArray($.$$.S.Object).$h
        },
        {
          "n": "data1",
          "p": 131073
        },
        {
          "n": "data",
          "p": $.$typeArray($.$$.S.Object).$h
        }
      ],
      "n": "ShouldTrace",
      "d": 655405,
      "h": 30065426477,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065426477)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295622701),
    {
      "t": 1310721,
      "n": "_src",
      "d": 655405,
      "h": 4295622701,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295622701)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590589997),
    {
      "p": [
        {
          "n": "source",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655405,
      "h": 8590589997,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590589997)
  ],
  "h": 655405
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SourceFilter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SourceFilter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655405)
        
        

        //--TRIMMABLE-BOUNDARY-START(65581)
        $asm.$cls(`$sdts.SD.BooleanSwitch`, ($self) => class BooleanSwitch extends $.$sdts.SD.Switch
        {
            //--TRIMMABLE-BOUNDARY-START(8590000173)
            $ctor$4(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$2(displayName, description);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000173);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000173)
            
            //--TRIMMABLE-BOUNDARY-START(4295032877)
            $ctor$3(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, description, defaultSwitchValue);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032877);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032877)
            
            //--TRIMMABLE-BOUNDARY-START(12884967469)
            /*bool */ get Enabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902061);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (this.SwitchSetting === 0) ? false : true;
            }
            /*bool */ set Enabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803949);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.SwitchSetting = value ? 1 : 0;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967469)
            
            //--TRIMMABLE-BOUNDARY-START(25769869357)
            /*void */ OnValueChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869357);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let b;
                if ($.$$.S.Boolean.TryParse$1(this.Value, $.$ref(() => b, ($v) => b = $v, $.$$.S.Boolean)))
                {
                    this.SwitchSetting = (b ? 1 : 0);
                }
                else 
                {
                    super.OnValueChanged();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869357)
            
            static $h = 65581;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.Switch; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12884967469),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902061,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 34359803949,
        "f": 83886081
      },
      "n": "Enabled",
      "d": 65581,
      "h": 12884967469,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12884967469)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769869357),
    {
      "r": 65537,
      "n": "OnValueChanged",
      "d": 65581,
      "h": 25769869357,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(25769869357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590000173),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65581,
      "h": 8590000173,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590000173),
//--TRIMMABLE-BOUNDARY-START(4295032877),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "defaultSwitchValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65581,
      "h": 4295032877,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032877)
  ],
  "h": 65581,
  "a": [
    {
      "t": 983085,
      "c": 8590917677,
      "a": [
        {
          "v": 262145,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.BooleanSwitch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}BooleanSwitch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65581)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769517)
        $asm.$cls(`$sdts.SD.TraceSwitch`, ($self) => class TraceSwitch extends $.$sdts.SD.Switch
        {
            //--TRIMMABLE-BOUNDARY-START(8591704109)
            $ctor$4(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$2(displayName, description);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704109);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591704109)
            
            //--TRIMMABLE-BOUNDARY-START(4296736813)
            $ctor$3(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, description, defaultSwitchValue);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736813);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736813)
            
            //--TRIMMABLE-BOUNDARY-START(55836344365)
            /*TraceLevel */ get Level()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181638701);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast(this.SwitchSetting, $.$sdts.SD.TraceLevel);
            }
            /*TraceLevel */ set Level(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016213549);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value < 0/*TraceLevel.Off*/ || value > 4/*TraceLevel.Verbose*/)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14($.$sdts.S.SR.TraceSwitchInvalidLevel);
                }
                this.SetSwitchValues(value, $.$$.S.Enum.ToStringT($.$sdts.SD.TraceLevel, $.$$.S.UInt32, value));
            }
            //--TRIMMABLE-BOUNDARY-END(55836344365)
            
            //--TRIMMABLE-BOUNDARY-START(77311180845)
            /*bool */ get TraceError()
            {
                return this.Level >= 1/*TraceLevel.Error*/;
            }
            //--TRIMMABLE-BOUNDARY-END(77311180845)
            
            //--TRIMMABLE-BOUNDARY-START(90196082733)
            /*bool */ get TraceWarning()
            {
                return this.Level >= 2/*TraceLevel.Warning*/;
            }
            //--TRIMMABLE-BOUNDARY-END(90196082733)
            
            //--TRIMMABLE-BOUNDARY-START(81606148141)
            /*bool */ get TraceInfo()
            {
                return this.Level >= 3/*TraceLevel.Info*/;
            }
            //--TRIMMABLE-BOUNDARY-END(81606148141)
            
            //--TRIMMABLE-BOUNDARY-START(85901115437)
            /*bool */ get TraceVerbose()
            {
                return this.Level === 4/*TraceLevel.Verbose*/;
            }
            //--TRIMMABLE-BOUNDARY-END(85901115437)
            
            //--TRIMMABLE-BOUNDARY-START(60131311661)
            /*void */ OnSwitchSettingChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131311661);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let level = this.SwitchSetting;
                if (level < 0/*TraceLevel.Off*/)
                {
                    ;
                    this.SwitchSetting = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    ;
                    this.SwitchSetting = 4/*TraceLevel.Verbose*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60131311661)
            
            //--TRIMMABLE-BOUNDARY-START(64426278957)
            /*void */ OnValueChanged()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426278957);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*TraceLevel*/ let level = $.$$.S.Enum.Parse$6($.$sdts.SD.TraceLevel, this.Value, true);
                if (level < 0/*TraceLevel.Off*/)
                {
                    level = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    level = 4/*TraceLevel.Verbose*/;
                }
                this.SetSwitchValues(level, $.$$.S.Enum.ToStringT($.$sdts.SD.TraceLevel, $.$$.S.UInt32, level));
            }
            //--TRIMMABLE-BOUNDARY-END(64426278957)
            
            static $h = 1769517;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.Switch; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(55836344365),
    {
      "p": 1441837,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181638701,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73016213549,
        "f": 83886081
      },
      "n": "Level",
      "d": 1769517,
      "h": 55836344365,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55836344365),
//--TRIMMABLE-BOUNDARY-START(77311180845),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771573293,
        "f": 50331649
      },
      "n": "TraceError",
      "d": 1769517,
      "h": 77311180845,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77311180845),
//--TRIMMABLE-BOUNDARY-START(90196082733),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541377069,
        "f": 50331649
      },
      "n": "TraceWarning",
      "d": 1769517,
      "h": 90196082733,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90196082733),
//--TRIMMABLE-BOUNDARY-START(81606148141),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361507885,
        "f": 50331649
      },
      "n": "TraceInfo",
      "d": 1769517,
      "h": 81606148141,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81606148141),
//--TRIMMABLE-BOUNDARY-START(85901115437),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951442477,
        "f": 50331649
      },
      "n": "TraceVerbose",
      "d": 1769517,
      "h": 85901115437,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85901115437)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(60131311661),
    {
      "r": 65537,
      "n": "OnSwitchSettingChanged",
      "d": 1769517,
      "h": 60131311661,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60131311661),
//--TRIMMABLE-BOUNDARY-START(64426278957),
    {
      "r": 65537,
      "n": "OnValueChanged",
      "d": 1769517,
      "h": 64426278957,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64426278957)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8591704109),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1769517,
      "h": 8591704109,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591704109),
//--TRIMMABLE-BOUNDARY-START(4296736813),
    {
      "p": [
        {
          "n": "displayName",
          "p": 1310721
        },
        {
          "n": "description",
          "p": 1310721
        },
        {
          "n": "defaultSwitchValue",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1769517,
      "h": 4296736813,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736813)
  ],
  "h": 1769517,
  "a": [
    {
      "t": 983085,
      "c": 8590917677,
      "a": [
        {
          "v": 1441837,
          "t": 188547073
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceSwitch`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceSwitch`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769517)
        
        

        //--TRIMMABLE-BOUNDARY-START(917549)
        $asm.$cls(`$sdts.SD.SwitchAttribute`, ($self) => class SwitchAttribute extends $.$$.S.Attribute
        {
            //--TRIMMABLE-BOUNDARY-START(8590852141)
            /*Type*/ _type = null;
            //--TRIMMABLE-BOUNDARY-END(8590852141)
            
            //--TRIMMABLE-BOUNDARY-START(4295884845)
            /*string*/ _name = null;
            //--TRIMMABLE-BOUNDARY-END(4295884845)
            
            //--TRIMMABLE-BOUNDARY-START(17180786733)
            $ctor$2(/*string*/ switchName, /*Type*/ switchType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786733);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.SwitchName = switchName;
                    this.SwitchType = switchType;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786733)
            
            //--TRIMMABLE-BOUNDARY-START(90195230765)
            /*string */ get SwitchName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655917);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._name;
            }
            /*string */ set SwitchName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361581);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentException.ThrowIfNullOrEmpty(value, "value");
                this._name = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90195230765)
            
            //--TRIMMABLE-BOUNDARY-START(94490198061)
            /*Type */ get SwitchType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590509);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._type;
            }
            /*Type */ set SwitchType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296173);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(value, "value");
                this._type = value;
            }
            //--TRIMMABLE-BOUNDARY-END(94490198061)
            
            //--TRIMMABLE-BOUNDARY-START(85900263469)
            /*string?*/ SwitchDescription = null;
            //--TRIMMABLE-BOUNDARY-END(85900263469)
            
            //--TRIMMABLE-BOUNDARY-START(47245557805)
            static /*SwitchAttribute[] */ GetAll(/*Assembly*/ assembly)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557805);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(assembly, "assembly");
                /*List<object>*/ let switchAttribs = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                /*object[]*/ let attribs = assembly.GetCustomAttributes$1($.$sdts.SD.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
                let $i1 = 0;
                let $arr1 = assembly.GetTypes();
                while ($i1 < $arr1.length)
                {
                    let type = $arr1[$i1++];
                    $.$sdts.SD.SwitchAttribute.GetAllRecursive$1(type, switchAttribs);
                }
                /*SwitchAttribute[]*/ let ret = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$sdts.SD.SwitchAttribute), null, [switchAttribs.Count], null);
                switchAttribs.CopyTo$1(ret, 0);
                return ret;
            }
            //--TRIMMABLE-BOUNDARY-END(47245557805)
            
            //--TRIMMABLE-BOUNDARY-START(55835492397)
            static /*void */ GetAllRecursive$1(/*Type*/ type, /*List<object>*/ switchAttribs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492397);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdts.SD.SwitchAttribute.GetAllRecursive(type, switchAttribs);
                /*MemberInfo[]*/ let members = type.GetMembers$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/);
                let $i2 = 0;
                let $arr2 = members;
                while ($i2 < $arr2.length)
                {
                    let member = $arr2[$i2++];
                    if (!($.$is(member, $.$$.S.Type)))
                    {
                        $.$sdts.SD.SwitchAttribute.GetAllRecursive(member, switchAttribs);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835492397)
            
            //--TRIMMABLE-BOUNDARY-START(51540525101)
            static /*void */ GetAllRecursive(/*MemberInfo*/ member, /*List<object>*/ switchAttribs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525101);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object[]*/ let attribs = member.GetCustomAttributes$1($.$sdts.SD.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525101)
            
            static $h = 917549;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Attribute; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(90195230765),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360655917,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73015361581,
        "f": 83886081
      },
      "n": "SwitchName",
      "d": 917549,
      "h": 90195230765,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195230765),
//--TRIMMABLE-BOUNDARY-START(94490198061),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950590509,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81605296173,
        "f": 83886081
      },
      "n": "SwitchType",
      "d": 917549,
      "h": 94490198061,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490198061),
//--TRIMMABLE-BOUNDARY-START(85900263469),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770721325,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425426989,
        "f": 83886081
      },
      "n": "SwitchDescription",
      "d": 917549,
      "h": 85900263469,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900263469)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245557805),
    {
      "r": $.$typeArray($.$sdts.SD.SwitchAttribute).$h,
      "p": [
        {
          "n": "assembly",
          "p": 107020289
        }
      ],
      "n": "GetAll",
      "d": 917549,
      "h": 47245557805,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245557805),
//--TRIMMABLE-BOUNDARY-START(55835492397),
    {
      "r": 65537,
      "p": [
        {
          "n": "type",
          "p": 188547073
        },
        {
          "n": "switchAttribs",
          "p": $.$$.SCG.List$$($.$$.S.Object).$h
        }
      ],
      "n": "GetAllRecursive",
      "o": "@$1",
      "d": 917549,
      "h": 55835492397,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(55835492397),
//--TRIMMABLE-BOUNDARY-START(51540525101),
    {
      "r": 65537,
      "p": [
        {
          "n": "member",
          "p": 116195329
        },
        {
          "n": "switchAttribs",
          "p": $.$$.SCG.List$$($.$$.S.Object).$h
        }
      ],
      "n": "GetAllRecursive",
      "d": 917549,
      "h": 51540525101,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51540525101)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590852141),
    {
      "t": 188547073,
      "n": "_type",
      "d": 917549,
      "h": 8590852141,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852141),
//--TRIMMABLE-BOUNDARY-START(4295884845),
    {
      "t": 1310721,
      "n": "_name",
      "d": 917549,
      "h": 4295884845,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884845)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786733),
    {
      "p": [
        {
          "n": "switchName",
          "p": 1310721
        },
        {
          "n": "switchType",
          "p": 188547073
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917549,
      "h": 17180786733,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786733)
  ],
  "h": 917549,
  "a": [
    {
      "t": 46202881,
      "c": 25816006657,
      "a": [
        {
          "v": 741,
          "t": 46137345
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SwitchAttribute`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SwitchAttribute`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917549)
        
        

        //--TRIMMABLE-BOUNDARY-START(327725)
        $asm.$cls(`$sdts.SD.DefaultTraceListener`, ($self) => class DefaultTraceListener extends $.$sdts.SD.TraceListener
        {
            //--TRIMMABLE-BOUNDARY-START(4295295021)
            /*bool*/ _assertUIEnabled = false;
            //--TRIMMABLE-BOUNDARY-END(4295295021)
            
            //--TRIMMABLE-BOUNDARY-START(12885229613)
            /*bool*/ _settingsInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(12885229613)
            
            //--TRIMMABLE-BOUNDARY-START(8590262317)
            /*string?*/ _logFileName = null;
            //--TRIMMABLE-BOUNDARY-END(8590262317)
            
            //--TRIMMABLE-BOUNDARY-START(17180196909)
            $ctor$4()
            {
                super.$ctor$3("Default");
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196909);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196909)
            
            //--TRIMMABLE-BOUNDARY-START(21475164205)
            /*bool */ get AssertUiEnabled()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033389);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._assertUIEnabled;
            }
            /*bool */ set AssertUiEnabled(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837165);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._assertUIEnabled = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21475164205)
            
            //--TRIMMABLE-BOUNDARY-START(55834902573)
            /*string? */ get LogFileName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244967981);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._logFileName;
            }
            /*string? */ set LogFileName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771757);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._logFileName = value;
            }
            //--TRIMMABLE-BOUNDARY-END(55834902573)
            
            //--TRIMMABLE-BOUNDARY-START(30065098797)
            /*void */ Fail$1(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098797);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Fail(message, null);
            }
            //--TRIMMABLE-BOUNDARY-END(30065098797)
            
            //--TRIMMABLE-BOUNDARY-START(25770131501)
            /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131501);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let stackTrace;
                try
                {
                    stackTrace = new $.$$.SD.StackTrace().$ctor$2(true).ToString();
                }
                catch($e)
                {
                    stackTrace = "";
                }
                this.WriteAssert(stackTrace, message, detailMessage);
                if (this.AssertUiEnabled)
                {
                    $.$$.SD.DebugProvider.FailCore(stackTrace, message, detailMessage, "Assertion Failed");
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770131501)
            
            //--TRIMMABLE-BOUNDARY-START(51539935277)
            /*void */ InitializeSettings()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935277);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._assertUIEnabled = $.$sdts.SD.DiagnosticsConfiguration.AssertUIEnabled;
                this._logFileName = $.$sdts.SD.DiagnosticsConfiguration.LogFileName;
                this._settingsInitialized = true;
            }
            //--TRIMMABLE-BOUNDARY-END(51539935277)
            
            //--TRIMMABLE-BOUNDARY-START(85899673645)
            /*void */ WriteAssert(/*string*/ stackTrace, /*string?*/ message, /*string?*/ detailMessage)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673645);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteLine$3($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$strNN($.$sdts.S.SR.DebugAssertBanner) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN($.$sdts.S.SR.DebugAssertShortMessage)) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN(message)) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN($.$sdts.S.SR.DebugAssertLongMessage)) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN(detailMessage)) + $.$strNN($.$$.S.Environment.NewLine)) + $.$strNN(stackTrace));
            }
            //--TRIMMABLE-BOUNDARY-END(85899673645)
            
            //--TRIMMABLE-BOUNDARY-START(81604706349)
            /*void */ Write$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706349);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Write$4(message, true);
            }
            //--TRIMMABLE-BOUNDARY-END(81604706349)
            
            //--TRIMMABLE-BOUNDARY-START(94489608237)
            /*void */ WriteLine$3(/*string?*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.WriteLine$4(message, true);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608237)
            
            //--TRIMMABLE-BOUNDARY-START(90194640941)
            /*void */ WriteLine$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194640941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.NeedIndent)
                {
                    this.WriteIndent();
                }
                this.Write$4($.$strNN(message) + $.$strNN($.$$.S.Environment.NewLine), useLogFile);
                this.NeedIndent = true;
            }
            //--TRIMMABLE-BOUNDARY-END(90194640941)
            
            //--TRIMMABLE-BOUNDARY-START(77309739053)
            /*void */ Write$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739053);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                message ??= $.$$.S.String.Empty;
                if (this.NeedIndent && message.length !== 0)
                {
                    this.WriteIndent();
                }
                $.$$.SD.DebugProvider.WriteCore(message);
                if (useLogFile && !$.$$.S.String.IsNullOrEmpty(this.LogFileName))
                {
                    this.WriteToLogFile(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309739053)
            
            //--TRIMMABLE-BOUNDARY-START(98784575533)
            /*void */ WriteToLogFile(/*string*/ message)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575533);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    $.$$.SI.File.AppendAllText$3(this.LogFileName, message);
                }
                catch(e)
                {
                    this.WriteLine$4($.$sdts.S.SR.Format$5($.$sdts.S.SR.ExceptionOccurred, this.LogFileName, e), false);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784575533)
            
            //--TRIMMABLE-BOUNDARY-START(17180196909)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(17180196909)
            
            static $h = 327725;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sdts.SD.TraceListener; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475164205),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655033389,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424837165,
        "f": 83886081
      },
      "n": "AssertUiEnabled",
      "d": 327725,
      "h": 21475164205,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475164205),
//--TRIMMABLE-BOUNDARY-START(55834902573),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244967981,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014771757,
        "f": 83886081
      },
      "n": "LogFileName",
      "d": 327725,
      "h": 55834902573,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834902573)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065098797),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "o": "@$1",
      "d": 327725,
      "h": 30065098797,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(30065098797),
//--TRIMMABLE-BOUNDARY-START(25770131501),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "Fail",
      "d": 327725,
      "h": 25770131501,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770131501),
//--TRIMMABLE-BOUNDARY-START(51539935277),
    {
      "r": 65537,
      "n": "InitializeSettings",
      "d": 327725,
      "h": 51539935277,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51539935277),
//--TRIMMABLE-BOUNDARY-START(85899673645),
    {
      "r": 65537,
      "p": [
        {
          "n": "stackTrace",
          "p": 1310721
        },
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "detailMessage",
          "p": 1310721
        }
      ],
      "n": "WriteAssert",
      "d": 327725,
      "h": 85899673645,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899673645),
//--TRIMMABLE-BOUNDARY-START(81604706349),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "Write",
      "o": "@$3",
      "d": 327725,
      "h": 81604706349,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81604706349),
//--TRIMMABLE-BOUNDARY-START(94489608237),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteLine",
      "o": "@$3",
      "d": 327725,
      "h": 94489608237,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489608237),
//--TRIMMABLE-BOUNDARY-START(90194640941),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "useLogFile",
          "p": 262145
        }
      ],
      "n": "WriteLine",
      "o": "@$4",
      "d": 327725,
      "h": 90194640941,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(90194640941),
//--TRIMMABLE-BOUNDARY-START(77309739053),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        },
        {
          "n": "useLogFile",
          "p": 262145
        }
      ],
      "n": "Write",
      "o": "@$4",
      "d": 327725,
      "h": 77309739053,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77309739053),
//--TRIMMABLE-BOUNDARY-START(98784575533),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "WriteToLogFile",
      "d": 327725,
      "h": 98784575533,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784575533)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295021),
    {
      "t": 262145,
      "n": "_assertUIEnabled",
      "d": 327725,
      "h": 4295295021,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295021),
//--TRIMMABLE-BOUNDARY-START(12885229613),
    {
      "t": 262145,
      "n": "_settingsInitialized",
      "d": 327725,
      "h": 12885229613,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885229613),
//--TRIMMABLE-BOUNDARY-START(8590262317),
    {
      "t": 1310721,
      "n": "_logFileName",
      "d": 327725,
      "h": 8590262317,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262317)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180196909),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 327725,
      "h": 17180196909,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196909)
  ],
  "h": 327725
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.DefaultTraceListener`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}DefaultTraceListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327725)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441837)
        $asm.$str(`$sdts.SD.TraceLevel`, ($self) => class TraceLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Off = 0;
            static Error = 1;
            static Warning = 2;
            static Info = 3;
            static Verbose = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1441837);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Error": 1n,
                    "Warning": 2n,
                    "Info": 3n,
                    "Verbose": 4n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296409133)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296409133);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409133)
            
            //--TRIMMABLE-BOUNDARY-START(4296409133)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409133)
            
            static $h = 1441837;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181311021),
    {
      "t": 1441837,
      "n": "Off",
      "d": 1441837,
      "h": 17181311021,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181311021),
//--TRIMMABLE-BOUNDARY-START(8591376429),
    {
      "t": 1441837,
      "n": "Error",
      "d": 1441837,
      "h": 8591376429,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591376429),
//--TRIMMABLE-BOUNDARY-START(25771245613),
    {
      "t": 1441837,
      "n": "Warning",
      "d": 1441837,
      "h": 25771245613,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771245613),
//--TRIMMABLE-BOUNDARY-START(12886343725),
    {
      "t": 1441837,
      "n": "Info",
      "d": 1441837,
      "h": 12886343725,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886343725),
//--TRIMMABLE-BOUNDARY-START(21476278317),
    {
      "t": 1441837,
      "n": "Verbose",
      "d": 1441837,
      "h": 21476278317,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476278317)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409133),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1441837,
      "h": 4296409133,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296409133)
  ],
  "h": 1441837
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceLevel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441837)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179693)
        $asm.$str(`$sdts.SD.TraceEventType`, ($self) => class TraceEventType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Critical = 1;
            static Error = 2;
            static Warning = 4;
            static Information = 8;
            static Verbose = 16;
            static Start = 256;
            static Stop = 512;
            static Suspend = 1024;
            static Resume = 2048;
            static Transfer = 4096;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1179693);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 4n,
                    "Information": 8n,
                    "Verbose": 16n,
                    "Start": 256n,
                    "Stop": 512n,
                    "Suspend": 1024n,
                    "Resume": 2048n,
                    "Transfer": 4096n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296146989)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296146989);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146989)
            
            //--TRIMMABLE-BOUNDARY-START(4296146989)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296146989)
            
            static $h = 1179693;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591114285),
    {
      "t": 1179693,
      "n": "Critical",
      "d": 1179693,
      "h": 8591114285,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591114285),
//--TRIMMABLE-BOUNDARY-START(12886081581),
    {
      "t": 1179693,
      "n": "Error",
      "d": 1179693,
      "h": 12886081581,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886081581),
//--TRIMMABLE-BOUNDARY-START(47245819949),
    {
      "t": 1179693,
      "n": "Warning",
      "d": 1179693,
      "h": 47245819949,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245819949),
//--TRIMMABLE-BOUNDARY-START(17181048877),
    {
      "t": 1179693,
      "n": "Information",
      "d": 1179693,
      "h": 17181048877,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181048877),
//--TRIMMABLE-BOUNDARY-START(42950852653),
    {
      "t": 1179693,
      "n": "Verbose",
      "d": 1179693,
      "h": 42950852653,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950852653),
//--TRIMMABLE-BOUNDARY-START(25770983469),
    {
      "t": 1179693,
      "n": "Start",
      "d": 1179693,
      "h": 25770983469,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770983469),
//--TRIMMABLE-BOUNDARY-START(30065950765),
    {
      "t": 1179693,
      "n": "Stop",
      "d": 1179693,
      "h": 30065950765,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065950765),
//--TRIMMABLE-BOUNDARY-START(34360918061),
    {
      "t": 1179693,
      "n": "Suspend",
      "d": 1179693,
      "h": 34360918061,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360918061),
//--TRIMMABLE-BOUNDARY-START(21476016173),
    {
      "t": 1179693,
      "n": "Resume",
      "d": 1179693,
      "h": 21476016173,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476016173),
//--TRIMMABLE-BOUNDARY-START(38655885357),
    {
      "t": 1179693,
      "n": "Transfer",
      "d": 1179693,
      "h": 38655885357,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655885357)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146989),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179693,
      "h": 4296146989,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146989)
  ],
  "h": 1179693
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceEventType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceEventType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179693)
        
        

        //--TRIMMABLE-BOUNDARY-START(720941)
        $asm.$str(`$sdts.SD.SourceLevels`, ($self) => class SourceLevels extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Off = 0;
            static Critical = 1;
            static Error = 3;
            static Warning = 7;
            static Information = 15;
            static Verbose = 31;
            static ActivityTracing = 65280;
            static All = -1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(720941);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Critical": 1n,
                    "Error": 3n,
                    "Warning": 7n,
                    "Information": 15n,
                    "Verbose": 31n,
                    "ActivityTracing": 65280n,
                    "All": 4294967295n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295688237)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295688237);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688237)
            
            //--TRIMMABLE-BOUNDARY-START(4295688237)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688237)
            
            static $h = 720941;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065492013),
    {
      "t": 720941,
      "n": "Off",
      "d": 720941,
      "h": 30065492013,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065492013),
//--TRIMMABLE-BOUNDARY-START(17180590125),
    {
      "t": 720941,
      "n": "Critical",
      "d": 720941,
      "h": 17180590125,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180590125),
//--TRIMMABLE-BOUNDARY-START(21475557421),
    {
      "t": 720941,
      "n": "Error",
      "d": 720941,
      "h": 21475557421,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475557421),
//--TRIMMABLE-BOUNDARY-START(38655426605),
    {
      "t": 720941,
      "n": "Warning",
      "d": 720941,
      "h": 38655426605,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655426605),
//--TRIMMABLE-BOUNDARY-START(25770524717),
    {
      "t": 720941,
      "n": "Information",
      "d": 720941,
      "h": 25770524717,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770524717),
//--TRIMMABLE-BOUNDARY-START(34360459309),
    {
      "t": 720941,
      "n": "Verbose",
      "d": 720941,
      "h": 34360459309,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360459309),
//--TRIMMABLE-BOUNDARY-START(8590655533),
    {
      "t": 720941,
      "n": "ActivityTracing",
      "d": 720941,
      "h": 8590655533,
      "f": 4194337,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 2,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590655533),
//--TRIMMABLE-BOUNDARY-START(12885622829),
    {
      "t": 720941,
      "n": "All",
      "d": 720941,
      "h": 12885622829,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885622829)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688237),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720941,
      "h": 4295688237,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688237)
  ],
  "h": 720941,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.SourceLevels`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}SourceLevels`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720941)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638445)
        $asm.$str(`$sdts.SD.TraceOptions`, ($self) => class TraceOptions extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static LogicalOperationStack = 1;
            static DateTime = 2;
            static Timestamp = 4;
            static ProcessId = 8;
            static ThreadId = 16;
            static Callstack = 32;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638445);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "LogicalOperationStack": 1n,
                    "DateTime": 2n,
                    "Timestamp": 4n,
                    "ProcessId": 8n,
                    "ThreadId": 16n,
                    "Callstack": 32n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296605741)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605741);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605741)
            
            //--TRIMMABLE-BOUNDARY-START(4296605741)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605741)
            
            static $h = 1638445;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476474925),
    {
      "t": 1638445,
      "n": "None",
      "d": 1638445,
      "h": 21476474925,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474925),
//--TRIMMABLE-BOUNDARY-START(17181507629),
    {
      "t": 1638445,
      "n": "LogicalOperationStack",
      "d": 1638445,
      "h": 17181507629,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507629),
//--TRIMMABLE-BOUNDARY-START(12886540333),
    {
      "t": 1638445,
      "n": "DateTime",
      "d": 1638445,
      "h": 12886540333,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540333),
//--TRIMMABLE-BOUNDARY-START(34361376813),
    {
      "t": 1638445,
      "n": "Timestamp",
      "d": 1638445,
      "h": 34361376813,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361376813),
//--TRIMMABLE-BOUNDARY-START(25771442221),
    {
      "t": 1638445,
      "n": "ProcessId",
      "d": 1638445,
      "h": 25771442221,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771442221),
//--TRIMMABLE-BOUNDARY-START(30066409517),
    {
      "t": 1638445,
      "n": "ThreadId",
      "d": 1638445,
      "h": 30066409517,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066409517),
//--TRIMMABLE-BOUNDARY-START(8591573037),
    {
      "t": 1638445,
      "n": "Callstack",
      "d": 1638445,
      "h": 8591573037,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573037)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605741),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638445,
      "h": 4296605741,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605741)
  ],
  "h": 1638445,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.TraceOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}TraceOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638445)
        
        

        //--TRIMMABLE-BOUNDARY-START(524333)
        $asm.$cls(`$sdts.SD.InitializingSwitchEventArgs`, ($self) => class InitializingSwitchEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(8590458925)
            $ctor$2(/*Switch*/ $switch)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458925);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.Switch = $switch;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590458925)
            
            //--TRIMMABLE-BOUNDARY-START(21475360813)
            /*Switch*/ Switch = null;
            //--TRIMMABLE-BOUNDARY-END(21475360813)
            
            static $h = 524333;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475360813),
    {
      "p": 852013,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180393517,
        "f": 50331649
      },
      "n": "Switch",
      "d": 524333,
      "h": 21475360813,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475360813)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590458925),
    {
      "p": [
        {
          "n": "switch",
          "p": 852013
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524333,
      "h": 8590458925,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590458925)
  ],
  "h": 524333
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.InitializingSwitchEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}InitializingSwitchEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524333)
        
        

        //--TRIMMABLE-BOUNDARY-START(589869)
        $asm.$cls(`$sdts.SD.InitializingTraceSourceEventArgs`, ($self) => class InitializingTraceSourceEventArgs extends $.$$.S.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(12885491757)
            $ctor$2(/*TraceSource*/ traceSource)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885491757);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.TraceSource = traceSource;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491757)
            
            //--TRIMMABLE-BOUNDARY-START(42950262829)
            /*TraceSource*/ TraceSource = null;
            //--TRIMMABLE-BOUNDARY-END(42950262829)
            
            //--TRIMMABLE-BOUNDARY-START(47245230125)
            /*bool*/ WasInitialized = false;
            //--TRIMMABLE-BOUNDARY-END(47245230125)
            
            static $h = 589869;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.EventArgs; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(42950262829),
    {
      "p": 1703981,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426349,
        "f": 50331649
      },
      "n": "TraceSource",
      "d": 589869,
      "h": 42950262829,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950262829),
//--TRIMMABLE-BOUNDARY-START(47245230125),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065360941,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 38655295533,
        "f": 83886081
      },
      "n": "WasInitialized",
      "d": 589869,
      "h": 47245230125,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230125)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885491757),
    {
      "p": [
        {
          "n": "traceSource",
          "p": 1703981
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589869,
      "h": 12885491757,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491757)
  ],
  "h": 589869
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Diagnostics.InitializingTraceSourceEventArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Diagnostics${separator}InitializingTraceSourceEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589869)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"));
})();
//--TRIMMABLE-BOUNDARY-END(45)
