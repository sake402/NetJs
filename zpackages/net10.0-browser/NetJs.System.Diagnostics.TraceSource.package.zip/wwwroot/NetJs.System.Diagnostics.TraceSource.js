
(function ($global, $, $$, $sc, $sm, $spu, $sr, $st, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.TraceSource", 
    {"h":49667,"f":"System.Diagnostics.TraceSource","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.TraceSource","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.TraceSource","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdts.System.Diagnostics.TraceFilter", ($self) => class TraceFilter extends $.$$.System.Object
        {
            /*bool */ ShouldTrace$3(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, null, null, null);
            }
            /*bool */ ShouldTrace$2(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, null, null);
            }
            /*bool */ ShouldTrace$1(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, data1, null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1294851;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h},{"n":"data1","p":131073},{"n":"data","p":$.$typeArray($.$$.System.Object).$h}],"n":"ShouldTrace","d":1294851,"h":4296262147,"f":16777473},{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721}],"n":"ShouldTrace","o":"@$3","d":1294851,"h":8591229443,"f":16777224},{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h}],"n":"ShouldTrace","o":"@$2","d":1294851,"h":12886196739,"f":16777224},{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h},{"n":"data1","p":131073}],"n":"ShouldTrace","o":"@$1","d":1294851,"h":17181164035,"f":16777224}],"c":[{"n":".ctor","o":"$ctor$1","d":1294851,"h":21476131331,"f":16777220}],"h":1294851}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.Switch", ($self) => class Switch extends $.$$.System.Object
        {
            /*string?*/ _description = null;
            /*string*/ _displayName = null;
            /*int*/ _switchSetting = 0;
            /*bool*/ _initialized = false;
            /*bool*/ _initializing = false;
            /*string?*/ _switchValueString = null;
            /*string*/ _defaultValue = null;
            /*List<WeakReference<Switch>>*/ static s_switches = null;
            /*int*/ static s_LastCollectionCount = 0;
            /*StringDictionary?*/ _attributes = null;
            /*object*/ InitializedLock$ = null;
            /*object */ get InitializedLock()
            {
                return this.InitializedLock$ ?? $.$$.System.Threading.Interlocked.CompareExchange$6($.$ref(() => this.InitializedLock$, ($v) => this.InitializedLock$ = $v, $.$$.System.Object), new $.$$.System.Object().$ctor(), null) ?? this.InitializedLock$;
            }
            $ctor$2(/*string*/ displayName, /*string?*/ description)
            {
                this.$ctor$1(displayName, description, "0");
                {
                }
                return this;
            }
            $ctor$1(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor();
                {
                    this._displayName = displayName ?? $.$$.System.String.Empty;
                    this._description = description;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.Switch.s_switches)
                        {
                            $.$sdts.System.Diagnostics.Switch._pruneCachedSwitches();
                            $.$sdts.System.Diagnostics.Switch.s_switches.Add(new ($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.Switch))().$ctor$3(this));
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                    }
                    this._defaultValue = defaultSwitchValue;
                }
                return this;
            }
            static /*void */ _pruneCachedSwitches()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.Switch.s_switches)
                    {
                        if ($.$sdts.System.Diagnostics.Switch.s_LastCollectionCount !== $.$$.System.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<Switch>>*/ let buffer = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)))().$ctor$3($.$sdts.System.Diagnostics.Switch.s_switches.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.Switch.s_switches.Count; i++)
                            {
                                if ($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.System.Diagnostics.Switch.s_switches.Count)
                            {
                                $.$sdts.System.Diagnostics.Switch.s_switches.Clear();
                                $.$sdts.System.Diagnostics.Switch.s_switches.AddRange(buffer);
                                $.$sdts.System.Diagnostics.Switch.s_switches.TrimExcess();
                            }
                            $.$sdts.System.Diagnostics.Switch.s_LastCollectionCount = $.$$.System.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                }
            }
            /*string */ get DisplayName()
            {
                return this._displayName;
            }
            /*string */ get Description()
            {
                return this._description ?? $.$$.System.String.Empty;
            }
            /*StringDictionary */ get Attributes()
            {
                this.Initialize();
                return this._attributes ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*int */ get SwitchSetting()
            {
                if (!this._initialized)
                {
                    if (this.InitializeWithStatus())
                    {
                        this.OnSwitchSettingChanged();
                    }
                }
                return this._switchSetting;
            }
            /*int */ set SwitchSetting(value)
            {
                /*bool*/ let didUpdate = false;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._initialized = true;
                        if (this._switchSetting !== value)
                        {
                            this._switchSetting = value;
                            didUpdate = true;
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.InitializedLock)
                }
                if (didUpdate)
                {
                    this.OnSwitchSettingChanged();
                }
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            /*void */ SetSwitchValues(/*int*/ switchSetting, /*string*/ switchValueString)
            {
                this.Initialize();
                $.$$.System.Diagnostics.Debug.Assert$2(!(switchValueString === null), "Unexpected 'switchValueString' null value");
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._switchSetting = switchSetting;
                        this._switchValueString = switchValueString;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.InitializedLock)
                }
            }
            /*string */ get DefaultValue()
            {
                return this._defaultValue;
            }
            /*string */ get Value()
            {
                this.Initialize();
                return this._switchValueString;
            }
            /*string */ set Value(value)
            {
                this.Initialize();
                this._switchValueString = value;
                this.OnValueChanged();
            }
            /*EventHandler<InitializingSwitchEventArgs>?*/ static Initializing = null;
            static add_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.Switch.Initializing = $.$$.System.Delegate.Combine($.$sdts.System.Diagnostics.Switch.Initializing, value);
            }
            static remove_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.Switch.Initializing = $.$$.System.Delegate.Remove($.$sdts.System.Diagnostics.Switch.Initializing, value);
            }
            /*void */ OnInitializing()
            {
                $.$sdts.System.Diagnostics.Switch.Initializing?.Invoke(null, new $.$sdts.System.Diagnostics.InitializingSwitchEventArgs().$ctor$2(this));
                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
            }
            /*void */ Initialize()
            {
                this.InitializeWithStatus();
            }
            /*bool */ InitializeWithStatus()
            {
                if (!this._initialized)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.InitializedLock)
                        {
                            if (this._initialized || this._initializing)
                            {
                                return false;
                            }
                            this._initializing = true;
                            this._switchValueString = null;
                            try
                            {
                                this.OnInitializing();
                            }
                            catch($e)
                            {
                                this._initialized = false;
                                this._initializing = false;
                                throw $e;
                            }
                            if ($.$$.System.String.op_Equality(this._switchValueString, null))
                            {
                                this._switchValueString = this._defaultValue;
                                this.OnValueChanged();
                            }
                            this._initialized = true;
                            this._initializing = false;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.InitializedLock)
                    }
                }
                return true;
            }
            /*void */ OnSwitchSettingChanged()
            {
            }
            /*void */ OnValueChanged()
            {
                this.SwitchSetting = $.$$.System.Int32.Parse$6(this.Value, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            static /*void */ RefreshAll()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.Switch.s_switches)
                    {
                        $.$sdts.System.Diagnostics.Switch._pruneCachedSwitches();
                        for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.Switch.s_switches.Count; i++)
                        {
                            /*Switch?*/ let swtch;
                            if ($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i).TryGetTarget($.$ref(() => swtch, ($v) => swtch = $v, $.$sdts.System.Diagnostics.Switch)))
                            {
                                swtch.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                }
            }
            /*void */ Refresh()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.InitializedLock)
                    {
                        this._initialized = false;
                        this.Initialize();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.InitializedLock)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._switchValueString = $.$$.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_switches = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)))().$ctor$1();
                }
            }
            static $h = 901635;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":55835476483,"f":50331650},"n":"InitializedLock","d":901635,"h":51540509187,"f":2097154},{"p":1310721,"g":{"r":0,"d":0,"h":77310312963,"f":50331649},"n":"DisplayName","d":901635,"h":73015345667,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":85900247555,"f":50331649},"n":"Description","d":901635,"h":81605280259,"f":2097153},{"p":1310756,"g":{"r":0,"d":0,"h":94490182147,"f":50331649},"n":"Attributes","d":901635,"h":90195214851,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103080116739,"f":50331652},"s":{"r":0,"d":0,"h":107375084035,"f":83886084},"n":"SwitchSetting","d":901635,"h":98785149443,"f":2097156},{"p":1310721,"g":{"r":0,"d":0,"h":124554953219,"f":50331649},"n":"DefaultValue","d":901635,"h":120259985923,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":133144887811,"f":50331649},"s":{"r":0,"d":0,"h":137439855107,"f":83886081},"n":"Value","d":901635,"h":128849920515,"f":2097153}],"m":[{"r":65537,"n":"_pruneCachedSwitches","d":901635,"h":68720378371,"f":16777250},{"r":$.$typeArray($.$$.System.String).$h,"n":"GetSupportedAttributes","d":901635,"h":111670051331,"f":16777360},{"r":65537,"p":[{"n":"switchSetting","p":655361},{"n":"switchValueString","p":1310721}],"n":"SetSwitchValues","d":901635,"h":115965018627,"f":16777224},{"r":65537,"n":"OnInitializing","d":901635,"h":154619724291,"f":16777224},{"r":65537,"n":"Initialize","d":901635,"h":158914691587,"f":16777218},{"r":262145,"n":"InitializeWithStatus","d":901635,"h":163209658883,"f":16777218},{"r":65537,"n":"OnSwitchSettingChanged","d":901635,"h":167504626179,"f":16777348},{"r":65537,"n":"OnValueChanged","d":901635,"h":171799593475,"f":16777348},{"r":65537,"n":"RefreshAll","d":901635,"h":176094560771,"f":16777256},{"r":65537,"n":"Refresh","d":901635,"h":180389528067,"f":16777217}],"l":[{"t":1310721,"n":"_description","d":901635,"h":4295868931,"f":4194306},{"t":1310721,"n":"_displayName","d":901635,"h":8590836227,"f":4194306},{"t":655361,"n":"_switchSetting","d":901635,"h":12885803523,"f":4194306},{"t":262145,"n":"_initialized","d":901635,"h":17180770819,"f":4194306},{"t":262145,"n":"_initializing","d":901635,"h":21475738115,"f":4194306},{"t":1310721,"n":"_switchValueString","d":901635,"h":25770705411,"f":4194306},{"t":1310721,"n":"_defaultValue","d":901635,"h":30065672707,"f":4194306},{"t":$.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)).$h,"n":"s_switches","d":901635,"h":34360640003,"f":4194338},{"t":655361,"n":"s_LastCollectionCount","d":901635,"h":38655607299,"f":4194338},{"t":1310756,"n":"_attributes","d":901635,"h":42950574595,"f":4194306}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$2","d":901635,"h":60130443779,"f":16777220},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$1","d":901635,"h":64425411075,"f":16777220}],"e":[{"e":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h}],"n":"add_Initializing","d":901635,"h":141734822403,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h}],"n":"remove_Initializing","d":901635,"h":146029789699,"f":285212705},"n":"Initializing","d":901635,"h":150324756995,"f":8388641}],"h":901635}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.Switch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceListener", ($self) => class TraceListener extends $.$$.System.MarshalByRefObject
        {
            /*int*/ _indentLevel = 0;
            /*int*/ _indentSize = 4;
            /*TraceOptions*/ _traceOptions = 0;
            /*bool*/ _needIndent = true;
            /*string?*/ _listenerName = null;
            /*TraceFilter?*/ _filter = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string?*/ name)
            {
                super.$ctor$1();
                {
                    this._listenerName = name;
                }
                return this;
            }
            /*StringDictionary*/ Attributes$ = null;
            /*StringDictionary */ get Attributes()
            {
                return this.Attributes$ ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*string */ get Name()
            {
                return this._listenerName ?? "";
            }
            /*string */ set Name(value)
            {
                this._listenerName = value;
            }
            /*bool */ get IsThreadSafe()
            {
                return false;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                return;
            }
            /*void */ Flush()
            {
                return;
            }
            /*int */ get IndentLevel()
            {
                return this._indentLevel;
            }
            /*int */ set IndentLevel(value)
            {
                this._indentLevel = (value < 0) ? 0 : value;
            }
            /*int */ get IndentSize()
            {
                return this._indentSize;
            }
            /*int */ set IndentSize(value)
            {
                if (value < 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$18("IndentSize", $.$box(value, $.$$.System.Int32), $.$sdts.System.SR.TraceListenerIndentSize);
                }
                this._indentSize = value;
            }
            /*TraceFilter? */ get Filter()
            {
                return this._filter;
            }
            /*TraceFilter? */ set Filter(value)
            {
                this._filter = value;
            }
            /*bool */ get NeedIndent()
            {
                return this._needIndent;
            }
            /*bool */ set NeedIndent(value)
            {
                this._needIndent = value;
            }
            /*TraceOptions */ get TraceOutputOptions()
            {
                return this._traceOptions;
            }
            /*TraceOptions */ set TraceOutputOptions(value)
            {
                if ((value >> 6) !== 0)
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._traceOptions = value;
            }
            /*void */ Close()
            {
                return;
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            /*void */ TraceTransfer(/*TraceEventCache?*/ eventCache, /*string*/ source, /*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                this.TraceEvent$1(eventCache, source, 4096/*TraceEventType.Transfer*/, id, $.$$.System.String.Create$5(null, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256, null), `${message}, relatedActivityId=${$.$$.System.Guid.ToString.call(relatedActivityId)}`));
            }
            /*void */ Fail$1(/*string?*/ message)
            {
                this.Fail(message, null);
            }
            /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                this.WriteLine$3(detailMessage === null ? `${$.$sdts.System.SR.TraceListenerFail} ${message}` : `${$.$sdts.System.SR.TraceListenerFail} ${message} ${detailMessage}`);
            }
            /*void */ Write$1(/*object?*/ o)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                if (o === null)
                {
                    return;
                }
                this.Write$3($.$$.System.Object.ToString.call(o));
            }
            /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if ($.$$.System.String.op_Equality(category, null))
                {
                    this.Write$3(message);
                }
                else 
                {
                    this.Write$3(category + ": " + (message ?? $.$$.System.String.Empty));
                }
            }
            /*void */ Write(/*object?*/ o, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                if ($.$$.System.String.op_Equality(category, null))
                {
                    this.Write$1(o);
                }
                else 
                {
                    this.Write$2(o === null ? "" : $.$$.System.Object.ToString.call(o), category);
                }
            }
            /*void */ WriteIndent()
            {
                this.NeedIndent = false;
                for(/*int*/ let i = 0; i < this._indentLevel; i++)
                {
                    if (this._indentSize === 4)
                    {
                        this.Write$3("    ");
                    }
                    else 
                    {
                        for(/*int*/ let j = 0; j < this._indentSize; j++)
                        {
                            this.Write$3(" ");
                        }
                    }
                }
            }
            /*void */ WriteLine$1(/*object?*/ o)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                this.WriteLine$3(o === null ? "" : $.$$.System.Object.ToString.call(o));
            }
            /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if ($.$$.System.String.op_Equality(category, null))
                {
                    this.WriteLine$3(message);
                }
                else 
                {
                    this.WriteLine$3(category + ": " + (message ?? $.$$.System.String.Empty));
                }
            }
            /*void */ WriteLine(/*object?*/ o, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                this.WriteLine$2(o === null ? "" : $.$$.System.Object.ToString.call(o), category);
            }
            /*void */ TraceData(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(eventCache, source, eventType, id, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                /*string?*/ let datastring = $.$$.System.String.Empty;
                if (data !== null)
                {
                    datastring = $.$$.System.Object.ToString.call(data);
                }
                this.WriteLine$3(datastring);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceData$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace(eventCache, source, eventType, id, null, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine$3(data !== null ? $.$$.System.String.Join$6(", ", data) : $.$$.System.String.Empty);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceEvent$2(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                this.TraceEvent$1(eventCache, source, eventType, id, $.$$.System.String.Empty);
            }
            /*void */ TraceEvent$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(eventCache, source, eventType, id, message))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine$3(message);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceEvent(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$2(eventCache, source, eventType, id, format, args))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                if (args !== null)
                {
                    this.WriteLine$3($.$$.System.String.Format$3($.$$.System.Globalization.CultureInfo.InvariantCulture, format, args));
                }
                else 
                {
                    this.WriteLine$3(format);
                }
                this.WriteFooter(eventCache);
            }
            /*void */ WriteHeader(/*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                this.Write$3($.$$.System.String.Create$5($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256, null), `${source} ${eventType}: ${id} : `));
            }
            /*void */ WriteFooter(/*TraceEventCache?*/ eventCache)
            {
                if (eventCache === null)
                {
                    return;
                }
                this._indentLevel++;
                if (this.IsEnabled(8/*TraceOptions.ProcessId*/))
                {
                    this.WriteLine$3("ProcessId=" + eventCache.ProcessId);
                }
                if (this.IsEnabled(1/*TraceOptions.LogicalOperationStack*/))
                {
                    this.Write$3("LogicalOperationStack=");
                    /*Stack*/ let operationStack = eventCache.LogicalOperationStack;
                    /*bool*/ let first = true;
                    var $en3 = operationStack.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!first)
                            {
                                this.Write$3(", ");
                            }
                            else 
                            {
                                first = false;
                            }
                            this.Write$3($.$$.System.Object.ToString.call(obj));
                        }
                    }
                    this.WriteLine$3($.$$.System.String.Empty);
                }
                /*Span<char>*/ let stackBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128, null);
                if (this.IsEnabled(16/*TraceOptions.ThreadId*/))
                {
                    this.WriteLine$3("ThreadId=" + eventCache.ThreadId);
                }
                if (this.IsEnabled(2/*TraceOptions.DateTime*/))
                {
                    this.WriteLine$3($.$$.System.String.Create$5(null, stackBuffer, (() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("DateTime=");
                        $handler.AppendFormatted($.$box(eventCache.DateTime, $.$$.System.DateTime), null, "o");
                        return $handler.ToStringAndClear                ();
                    })()));
                }
                if (this.IsEnabled(4/*TraceOptions.Timestamp*/))
                {
                    this.WriteLine$3($.$$.System.String.Create$5(null, stackBuffer, `Timestamp=${eventCache.Timestamp}`));
                }
                if (this.IsEnabled(32/*TraceOptions.Callstack*/))
                {
                    this.WriteLine$3("Callstack=" + eventCache.Callstack);
                }
                this._indentLevel--;
            }
            /*bool */ IsEnabled(/*TraceOptions*/ opts)
            {
                return (opts & this.TraceOutputOptions) !== 0;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1556995;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65011713,"p":[{"p":1310756,"g":{"r":0,"d":0,"h":47246197251,"f":50331649},"n":"Attributes","d":1556995,"h":42951229955,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55836131843,"f":50331777},"s":{"r":0,"d":0,"h":60131099139,"f":83886209},"n":"Name","d":1556995,"h":51541164547,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":68721033731,"f":50331777},"n":"IsThreadSafe","d":1556995,"h":64426066435,"f":2097281},{"p":655361,"g":{"r":0,"d":0,"h":90195870211,"f":50331649},"s":{"r":0,"d":0,"h":94490837507,"f":83886081},"n":"IndentLevel","d":1556995,"h":85900902915,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103080772099,"f":50331649},"s":{"r":0,"d":0,"h":107375739395,"f":83886081},"n":"IndentSize","d":1556995,"h":98785804803,"f":2097153},{"p":1294851,"g":{"r":0,"d":0,"h":115965673987,"f":50331649},"s":{"r":0,"d":0,"h":120260641283,"f":83886081},"n":"Filter","d":1556995,"h":111670706691,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":128850575875,"f":50331652},"s":{"r":0,"d":0,"h":133145543171,"f":83886084},"n":"NeedIndent","d":1556995,"h":124555608579,"f":2097156},{"p":1688067,"g":{"r":0,"d":0,"h":141735477763,"f":50331649},"s":{"r":0,"d":0,"h":146030445059,"f":83886081},"n":"TraceOutputOptions","d":1556995,"h":137440510467,"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":1556995,"h":73016001027,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1556995,"h":77310968323,"f":16777348},{"r":65537,"n":"Flush","d":1556995,"h":81605935619,"f":16777345},{"r":65537,"n":"Close","d":1556995,"h":150325412355,"f":16777345},{"r":$.$typeArray($.$$.System.String).$h,"n":"GetSupportedAttributes","d":1556995,"h":154620379651,"f":16777360},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"id","p":655361},{"n":"message","p":1310721},{"n":"relatedActivityId","p":56229889}],"n":"TraceTransfer","d":1556995,"h":158915346947,"f":16777345},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","o":"@$1","d":1556995,"h":163210314243,"f":16777345},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":1556995,"h":167505281539,"f":16777345},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","o":"@$3","d":1556995,"h":171800248835,"f":16777473},{"r":65537,"p":[{"n":"o","p":131073}],"n":"Write","o":"@$1","d":1556995,"h":176095216131,"f":16777345},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1556995,"h":180390183427,"f":16777345},{"r":65537,"p":[{"n":"o","p":131073},{"n":"category","p":1310721}],"n":"Write","d":1556995,"h":184685150723,"f":16777345},{"r":65537,"n":"WriteIndent","d":1556995,"h":188980118019,"f":16777348},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","o":"@$3","d":1556995,"h":193275085315,"f":16777473},{"r":65537,"p":[{"n":"o","p":131073}],"n":"WriteLine","o":"@$1","d":1556995,"h":197570052611,"f":16777345},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1556995,"h":201865019907,"f":16777345},{"r":65537,"p":[{"n":"o","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","d":1556995,"h":206159987203,"f":16777345},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"data","p":131073}],"n":"TraceData","d":1556995,"h":210454954499,"f":16777345},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"data","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceData","o":"@$1","d":1556995,"h":214749921795,"f":16777345},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361}],"n":"TraceEvent","o":"@$2","d":1556995,"h":219044889091,"f":16777345},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"message","p":1310721}],"n":"TraceEvent","o":"@$1","d":1556995,"h":223339856387,"f":16777345},{"r":65537,"p":[{"n":"eventCache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceEvent","d":1556995,"h":227634823683,"f":16777345},{"r":65537,"p":[{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361}],"n":"WriteHeader","d":1556995,"h":231929790979,"f":16777218},{"r":65537,"p":[{"n":"eventCache","p":1163779}],"n":"WriteFooter","d":1556995,"h":236224758275,"f":16777218},{"r":262145,"p":[{"n":"opts","p":1688067}],"n":"IsEnabled","d":1556995,"h":240519725571,"f":16777224}],"l":[{"t":655361,"n":"_indentLevel","d":1556995,"h":4296524291,"f":4194306},{"t":655361,"n":"_indentSize","d":1556995,"h":8591491587,"f":4194306},{"t":1688067,"n":"_traceOptions","d":1556995,"h":12886458883,"f":4194306},{"t":262145,"n":"_needIndent","d":1556995,"h":17181426179,"f":4194306},{"t":1310721,"n":"_listenerName","d":1556995,"h":21476393475,"f":4194306},{"t":1294851,"n":"_filter","d":1556995,"h":25771360771,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1556995,"h":30066328067,"f":16777220},{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$3","d":1556995,"h":34361295363,"f":16777220}],"i":[57540609],"h":1556995}; }
            static get $b() { return $.$$.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.TraceListener`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceEventCache", ($self) => class TraceEventCache extends $.$$.System.Object
        {
            /*long*/ _timeStamp = -1n;
            /*DateTime*/ _dateTime;
            /*DateTime */ get DateTime()
            {
                if ($.$$.System.DateTime.op_Equality(this._dateTime, $.$$.System.DateTime.MinValue))
                {
                    this._dateTime = $.$$.System.DateTime.UtcNow;
                }
                return this._dateTime;
            }
            /*int */ get ProcessId()
            {
                return $.$$.System.Environment.ProcessId;
            }
            /*string */ get ThreadId()
            {
                return $.$$.System.Int32.ToString$1.call($.$$.System.Environment.CurrentManagedThreadId, $.$$.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*long */ get Timestamp()
            {
                if (this._timeStamp === BigInt(-1))
                {
                    this._timeStamp = $.$$.System.Diagnostics.Stopwatch.GetTimestamp();
                }
                return this._timeStamp;
            }
            /*string*/ Callstack$ = null;
            /*string */ get Callstack()
            {
                return this.Callstack$ ??= $.$$.System.Environment.StackTrace;
            }
            /*Stack */ get LogicalOperationStack()
            {
                return $.$sdts.System.Diagnostics.Trace.CorrelationManager.LogicalOperationStack;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dateTime = $.$$.System.DateTime.MinValue;
            }
            static $h = 1163779;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34275329,"g":{"r":0,"d":0,"h":17181032963,"f":50331649},"n":"DateTime","d":1163779,"h":12886065667,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25770967555,"f":50331649},"n":"ProcessId","d":1163779,"h":21476000259,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":34360902147,"f":50331649},"n":"ThreadId","d":1163779,"h":30065934851,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":42950836739,"f":50331649},"n":"Timestamp","d":1163779,"h":38655869443,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55835738627,"f":50331649},"n":"Callstack","d":1163779,"h":51540771331,"f":2097153},{"p":1048611,"g":{"r":0,"d":0,"h":64425673219,"f":50331649},"n":"LogicalOperationStack","d":1163779,"h":60130705923,"f":2097153}],"l":[{"t":917505,"n":"_timeStamp","d":1163779,"h":4296131075,"f":4194306},{"t":34275329,"n":"_dateTime","d":1163779,"h":8591098371,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1163779,"h":68720640515,"f":16777217}],"h":1163779}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceEventCache`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.DiagnosticsConfiguration", ($self) => class DiagnosticsConfiguration
        {
            static /*bool */ get AutoFlush()
            {
                return false;
            }
            static /*bool */ get UseGlobalLock()
            {
                return true;
            }
            static /*int */ get IndentSize()
            {
                return 4;
            }
            static /*bool */ get AssertUIEnabled()
            {
                return true;
            }
            static /*string */ get LogFileName()
            {
                return $.$$.System.String.Empty;
            }
            static $h = 442883;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590377475,"f":50331688},"n":"AutoFlush","d":442883,"h":4295410179,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":17180312067,"f":50331688},"n":"UseGlobalLock","d":442883,"h":12885344771,"f":2097192},{"p":655361,"g":{"r":0,"d":0,"h":25770246659,"f":50331688},"n":"IndentSize","d":442883,"h":21475279363,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":34360181251,"f":50331688},"n":"AssertUIEnabled","d":442883,"h":30065213955,"f":2097192},{"p":1310721,"g":{"r":0,"d":0,"h":42950115843,"f":50331688},"n":"LogFileName","d":442883,"h":38655148547,"f":2097192}],"h":442883}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticsConfiguration`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceUtils", ($self) => class TraceUtils
        {
            static /*void */ VerifyAttributes(/*StringDictionary?*/ attributes, /*string[]?*/ supportedAttributes, /*object*/ parent)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(attributes, "attributes");
                var $en2 = attributes.Keys$1.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (supportedAttributes === null || !$.$$.System.MemoryExtensions.Contains$2($.$$.System.String, $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1(supportedAttributes), key))
                        {
                            throw new $.$$.System.ArgumentException().$ctor$14($.$sdts.System.SR.Format$5($.$sdts.System.SR.AttributeNotSupported, key, $.$$.System.Object.GetType.call(parent).FullName));
                        }
                    }
                }
            }
            static $h = 1884675;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"attributes","p":1310756},{"n":"supportedAttributes","p":$.$typeArray($.$$.System.String).$h},{"n":"parent","p":131073}],"n":"VerifyAttributes","d":1884675,"h":4296851971,"f":16777256}],"h":1884675}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceUtils`; }
        });
        
        $asm.$cls("$sdts.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sdts.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Diagnostics.TraceSource", $.$sdts.System.SR.$type.Assembly);
                    $.$sdts.System.SR.s_resourceManager = temp;
                }
                return $.$sdts.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdts.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdts.System.SR.resourceCulture = value;
            }
            static /*string */ get AttributeNotSupported()
            {
                return "'{0}' is not a valid attribute for type '{1}'.";
            }
            static /*string */ FormatAttributeNotSupported(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("'{0}' is not a valid attribute for type '{1}'.", arg1, arg2);
            }
            static /*string */ get ExceptionOccurred()
            {
                return "An exception occurred while writing to the log file {0}: {1}.";
            }
            static /*string */ FormatExceptionOccurred(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("An exception occurred while writing to the log file {0}: {1}.", arg1, arg2);
            }
            static /*string */ get MustAddListener()
            {
                return "Only TraceListeners can be added to a TraceListenerCollection.";
            }
            static /*string */ get TraceListenerFail()
            {
                return "Fail:";
            }
            static /*string */ get TraceListenerIndentSize()
            {
                return "The IndentSize property must be non-negative.";
            }
            static /*string */ get DebugAssertBanner()
            {
                return "---- DEBUG ASSERTION FAILED ----";
            }
            static /*string */ get DebugAssertShortMessage()
            {
                return "---- Assert Short Message ----";
            }
            static /*string */ get DebugAssertLongMessage()
            {
                return "---- Assert Long Message ----";
            }
            static /*string */ get TraceSwitchLevelTooLow()
            {
                return "Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off";
            }
            static /*string */ FormatTraceSwitchLevelTooLow(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off", arg1);
            }
            static /*string */ get TraceSwitchInvalidLevel()
            {
                return "The Level must be set to a value in the enumeration TraceLevel.";
            }
            static /*string */ get TraceSwitchLevelTooHigh()
            {
                return "Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose";
            }
            static /*string */ FormatTraceSwitchLevelTooHigh(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdts.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdts.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdts.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdts.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdts.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdts.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1950211;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1950211}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.CorrelationManager", ($self) => class CorrelationManager extends $.$$.System.Object
        {
            /*AsyncLocal<Guid>*/ _activityId = null;
            /*AsyncLocal<StackNode?>*/ _stack = null;
            /*AsyncLocalStackWrapper*/ _stackWrapper = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._stackWrapper = new $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                }
                return this;
            }
            /*Stack */ get LogicalOperationStack()
            {
                return this._stackWrapper;
            }
            /*void */ StartLogicalOperation()
            {
                return this.StartLogicalOperation$1($.$$.System.Guid.NewGuid());
            }
            /*void */ StopLogicalOperation()
            {
                return this._stackWrapper.Pop();
            }
            /*Guid */ get ActivityId()
            {
                return this._activityId.Value;
            }
            /*Guid */ set ActivityId(value)
            {
                this._activityId.Value = value;
            }
            /*void */ StartLogicalOperation$1(/*object*/ operationId)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(operationId, "operationId");
                this._stackWrapper.Push(operationId);
            }
            static $_StackNode;
            static get StackNode()
            {
                let $cls = $.$sdts.System.Diagnostics.CorrelationManager;
                return $cls.$_StackNode ??= $asm.$ncls("$sdts.System.Diagnostics.CorrelationManager.StackNode", ($self) => class StackNode extends $.$$.System.Object
                {
                    $ctor$1(/*object?*/ value, /*StackNode?*/ prev)
                    {
                        super.$ctor();
                        {
                            this.Value = value;
                            this.Prev = prev;
                            this.Count = prev !== null ? ((prev.Count + 1) | 0) : 1;
                        }
                        return this;
                    }
                    /*int*/ Count = 0;
                    /*object?*/ Value = null;
                    /*StackNode?*/ Prev = null;
                    static $h = 311811;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180180995,"f":50331656},"n":"Count","d":311811,"h":12885213699,"f":2097160},{"p":131073,"g":{"r":0,"d":0,"h":30065082883,"f":50331656},"n":"Value","d":311811,"h":25770115587,"f":2097160},{"p":311811,"g":{"r":0,"d":0,"h":42949984771,"f":50331656},"n":"Prev","d":311811,"h":38655017475,"f":2097160}],"c":[{"p":[{"n":"value","p":131073},{"n":"prev","p":311811,"f":65}],"n":".ctor","o":"$ctor$1","d":311811,"h":4295279107,"f":16777224}],"d":180739,"h":311811}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Diagnostics.CorrelationManager.StackNode`; }
                }, $cls, ($v) => $cls.$_StackNode = $v);
            }
            static $_AsyncLocalStackWrapper;
            static get AsyncLocalStackWrapper()
            {
                let $cls = $.$sdts.System.Diagnostics.CorrelationManager;
                return $cls.$_AsyncLocalStackWrapper ??= $asm.$ncls("$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper", ($self) => class AsyncLocalStackWrapper extends $.$scn.System.Collections.Stack
                {
                    /*AsyncLocal<StackNode?>*/ _stack = null;
                    $ctor$4(/*AsyncLocal<StackNode?>*/ stack)
                    {
                        super.$ctor$1();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(stack !== null, "stack != null");
                            this._stack = stack;
                        }
                        return this;
                    }
                    /*void */ Clear()
                    {
                        return this._stack.Value = null;
                    }
                    /*object */ Clone()
                    {
                        return new $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                    }
                    /*int */ get Count()
                    {
                        return (this._stack.Value?.Count ?? null) ?? 0;
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        return $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper.GetEnumerator$1(this._stack.Value);
                    }
                    /*object? */ Peek()
                    {
                        return (this._stack.Value?.Value ?? null);
                    }
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            if (obj === null)
                            {
                                if (n.Value === null)
                                {
                                    return true;
                                }
                            }
                            else if ($.$$.System.Object.Equals$1.call(obj, n.Value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            array.SetValue$2(n.Value, index++);
                        }
                    }
                    static /*IEnumerator */ GetEnumerator$1(/*StackNode?*/ n)
                    {
                        return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                        {
                            while(n !== null)
                            {
                                yield n.Value;
                                n = n.Prev;
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*object? */ Pop()
                    {
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            super.Pop();
                        }
                        this._stack.Value = n.Prev;
                        return n.Value;
                    }
                    /*void */ Push(/*object?*/ obj)
                    {
                        this._stack.Value = new $.$sdts.System.Diagnostics.CorrelationManager.StackNode().$ctor$1(obj, this._stack.Value);
                    }
                    /*object?[] */ ToArray()
                    {
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            return $.$$.System.Array.Empty($.$$.System.Object);
                        }
                        /*var*/ let results = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                        do
                        {
                            results.Add(n.Value);
                            n = n.Prev;
                        }
                        while(n !== null);
                        return results.ToArray();
                    }
                    static $h = 246275;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048611,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25770050051,"f":50364417},"n":"Count","d":246275,"h":21475082755,"f":2129921}],"m":[{"r":65537,"n":"Clear","d":246275,"h":12885148163,"f":16809985},{"r":131073,"n":"Clone","d":246275,"h":17180115459,"f":16809985},{"r":31850497,"n":"GetEnumerator","d":246275,"h":30065017347,"f":16809985},{"r":131073,"n":"Peek","d":246275,"h":34359984643,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":246275,"h":38654951939,"f":16809985},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":246275,"h":42949919235,"f":16809985},{"r":31850497,"p":[{"n":"n","p":311811}],"n":"GetEnumerator","o":"@$1","d":246275,"h":47244886531,"f":16777250},{"r":131073,"n":"Pop","d":246275,"h":51539853827,"f":16809985},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"Push","d":246275,"h":55834821123,"f":16809985},{"r":$.$typeArray($.$$.System.Object).$h,"n":"ToArray","d":246275,"h":60129788419,"f":16809985}],"l":[{"t":$.$$.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h,"n":"_stack","d":246275,"h":4295213571,"f":4194306}],"c":[{"p":[{"n":"stack","p":$.$$.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h}],"n":".ctor","o":"$ctor$4","d":246275,"h":8590180867,"f":16777224}],"i":[31457281,31719425,57212929],"d":180739,"h":246275}; }
                    static get $b() { return $.$scn.System.Collections.Stack; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable, $.$$.System.ICloneable ]; }
                    static get $fullName() { return `System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper`; }
                }, $cls, ($v) => $cls.$_AsyncLocalStackWrapper = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._activityId = new ($.$$.System.Threading.AsyncLocal$$($.$$.System.Guid))().$ctor$1();
                this._stack = new ($.$$.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode))().$ctor$1();
            }
            static $h = 180739;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1048611,"g":{"r":0,"d":0,"h":25769984515,"f":50331649},"n":"LogicalOperationStack","d":180739,"h":21475017219,"f":2097153},{"p":56229889,"g":{"r":0,"d":0,"h":42949853699,"f":50331649},"s":{"r":0,"d":0,"h":47244820995,"f":83886081},"n":"ActivityId","d":180739,"h":38654886403,"f":2097153}],"m":[{"r":65537,"n":"StartLogicalOperation","d":180739,"h":30064951811,"f":16777217},{"r":65537,"n":"StopLogicalOperation","d":180739,"h":34359919107,"f":16777217},{"r":65537,"p":[{"n":"operationId","p":131073}],"n":"StartLogicalOperation","o":"@$1","d":180739,"h":51539788291,"f":16777217}],"l":[{"t":$.$$.System.Threading.AsyncLocal$$($.$$.System.Guid).$h,"n":"_activityId","d":180739,"h":4295148035,"f":4194306},{"t":$.$$.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h,"n":"_stack","d":180739,"h":8590115331,"f":4194306},{"t":246275,"n":"_stackWrapper","d":180739,"h":12885082627,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":180739,"h":17180049923,"f":16777224}],"j":[311811,246275],"h":180739}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.CorrelationManager`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceInternal", ($self) => class TraceInternal
        {
            static $_TraceProvider;
            static get TraceProvider()
            {
                let $cls = $.$sdts.System.Diagnostics.TraceInternal;
                return $cls.$_TraceProvider ??= $asm.$ncls("$sdts.System.Diagnostics.TraceInternal.TraceProvider", ($self) => class TraceProvider extends $.$$.System.Diagnostics.DebugProvider
                {
                    /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.Fail(message, detailMessage);
                    }
                    /*void */ OnIndentLevelChanged(/*int*/ indentLevel)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.IndentLevel = indentLevel;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    /*void */ OnIndentSizeChanged(/*int*/ indentSize)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.IndentSize = indentSize;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    /*void */ Write(/*string?*/ message)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.Write$3(message);
                    }
                    /*void */ WriteLine(/*string?*/ message)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.WriteLine$3(message);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 1425923;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":38076417,"m":[{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":1425923,"h":4296393219,"f":16809985},{"r":65537,"p":[{"n":"indentLevel","p":655361}],"n":"OnIndentLevelChanged","d":1425923,"h":8591360515,"f":16809985},{"r":65537,"p":[{"n":"indentSize","p":655361}],"n":"OnIndentSizeChanged","d":1425923,"h":12886327811,"f":16809985},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":1425923,"h":17181295107,"f":16809985},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":1425923,"h":21476262403,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$2","d":1425923,"h":25771229699,"f":16777217}],"d":1360387,"h":1425923}; }
                    static get $b() { return $.$$.System.Diagnostics.DebugProvider; }
                    static get $fullName() { return `System.Diagnostics.TraceInternal.TraceProvider`; }
                }, $cls, ($v) => $cls.$_TraceProvider = $v);
            }
            /*TraceListenerCollection?*/ static s_listeners = null;
            /*bool*/ static s_autoFlush = false;
            /*bool*/ static s_useGlobalLock = false;
            /*bool*/ static s_settingsInitialized = false;
            /*bool*/ static s_settingsInitializing = false;
            /*object*/ static critSec = null;
            static /*TraceListenerCollection */ get Listeners()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners === null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners === null)
                            {
                                $.$$.System.Diagnostics.Debug.SetProvider(new $.$sdts.System.Diagnostics.TraceInternal.TraceProvider().$ctor$2());
                                $.$sdts.System.Diagnostics.TraceInternal.s_listeners = new $.$sdts.System.Diagnostics.TraceListenerCollection().$ctor$1();
                                /*TraceListener*/ let defaultListener = new $.$sdts.System.Diagnostics.DefaultTraceListener().$ctor$4();
                                defaultListener.IndentLevel = $.$$.System.Diagnostics.Debug.IndentLevel;
                                defaultListener.IndentSize = $.$$.System.Diagnostics.Debug.IndentSize;
                                $.$sdts.System.Diagnostics.TraceInternal.s_listeners.Add(defaultListener);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                return $.$sdts.System.Diagnostics.TraceInternal.s_listeners;
            }
            /*string*/ static AppName$ = null;
            static /*string */ get AppName()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.AppName$ ??= ($.$$.System.Reflection.Assembly.GetEntryAssembly()?.GetName().Name ?? null) ?? $.$$.System.String.Empty;
            }
            static /*bool */ get AutoFlush()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                return $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush = value;
            }
            static /*bool */ get UseGlobalLock()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                return $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock = value;
            }
            static /*int */ get IndentLevel()
            {
                return $.$$.System.Diagnostics.Debug.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                $.$$.System.Diagnostics.Debug.IndentLevel = value;
            }
            static /*int */ get IndentSize()
            {
                return $.$$.System.Diagnostics.Debug.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                $.$$.System.Diagnostics.Debug.IndentSize = value;
            }
            static /*void */ Indent()
            {
                $.$$.System.Diagnostics.Debug.IndentLevel++;
            }
            static /*void */ Unindent()
            {
                $.$$.System.Diagnostics.Debug.IndentLevel--;
            }
            static /*void */ Flush()
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var listener = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$$.System.Threading.Monitor.Enter$1(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Close()
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            static /*void */ Assert$2(/*bool*/ condition)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail$1($.$$.System.String.Empty);
            }
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail$1(message);
            }
            static /*void */ Assert(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail(message, detailMessage);
            }
            static /*void */ Fail$1(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Fail$1(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Fail$1(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail$1(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Fail(message, detailMessage);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Fail(message, detailMessage);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail(message, detailMessage);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ InitializeSettings()
            {
                if (!$.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if ($.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing)
                            {
                                return;
                            }
                            $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing = true;
                            if (!$.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized)
                            {
                                $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.AutoFlush;
                                $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.UseGlobalLock;
                                $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized = true;
                                $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            static /*void */ Refresh()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized = false;
                        $.$sdts.System.Diagnostics.TraceInternal.s_listeners = null;
                        $.$$.System.Diagnostics.Debug.IndentSize = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.IndentSize;
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
            }
            static /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                /*TraceEventCache*/ let EventCache = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if (args === null)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                            else 
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.TraceEvent(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    if (args === null)
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var listener = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$$.System.Threading.Monitor.Enter$1(listener)
                                        {
                                            listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                            if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    else 
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var listener = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$$.System.Threading.Monitor.Enter$1(listener)
                                        {
                                            listener.TraceEvent(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                            if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$3(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Write$3(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$3(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$3(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$1(/*object?*/ value)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Write$1(value);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$1(value);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$1(value);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Write$2(message, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Write$2(message, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$2(message, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write(/*object?*/ value, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Write(value, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.Write(value, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write(value, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$3(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.WriteLine$3(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$3(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$3(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.WriteLine$1(value);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$1(value);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$1(value);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.WriteLine$2(message, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine$2(message, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$2(message, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine(/*object?*/ value, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.WriteLine(value, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.WriteLine(value, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine(value, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteIf$3(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$3(message);
                }
            }
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$1(value);
                }
            }
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$2(message, category);
                }
            }
            static /*void */ WriteIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write(value, category);
                }
            }
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$3(message);
                }
            }
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$1(value);
                }
            }
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$2(message, category);
                }
            }
            static /*void */ WriteLineIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine(value, category);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.critSec = new $.$$.System.Object().$ctor();
                }
            }
            static $h = 1360387;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1622531,"g":{"r":0,"d":0,"h":38656066051,"f":50331681},"n":"Listeners","d":1360387,"h":34361098755,"f":2097185},{"p":1310721,"g":{"r":0,"d":0,"h":51540967939,"f":50331688},"n":"AppName","d":1360387,"h":47246000643,"f":2097192},{"p":262145,"g":{"r":0,"d":0,"h":60130902531,"f":50331681},"s":{"r":0,"d":0,"h":64425869827,"f":83886113},"n":"AutoFlush","d":1360387,"h":55835935235,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":73015804419,"f":50331681},"s":{"r":0,"d":0,"h":77310771715,"f":83886113},"n":"UseGlobalLock","d":1360387,"h":68720837123,"f":2097185},{"p":655361,"g":{"r":0,"d":0,"h":85900706307,"f":50331681},"s":{"r":0,"d":0,"h":90195673603,"f":83886113},"n":"IndentLevel","d":1360387,"h":81605739011,"f":2097185},{"p":655361,"g":{"r":0,"d":0,"h":98785608195,"f":50331681},"s":{"r":0,"d":0,"h":103080575491,"f":83886113},"n":"IndentSize","d":1360387,"h":94490640899,"f":2097185}],"m":[{"r":65537,"n":"Indent","d":1360387,"h":107375542787,"f":16777249},{"r":65537,"n":"Unindent","d":1360387,"h":111670510083,"f":16777249},{"r":65537,"n":"Flush","d":1360387,"h":115965477379,"f":16777249},{"r":65537,"n":"Close","d":1360387,"h":120260444675,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145}],"n":"Assert","o":"@$2","d":1360387,"h":124555411971,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"Assert","o":"@$1","d":1360387,"h":128850379267,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Assert","d":1360387,"h":133145346563,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","o":"@$1","d":1360387,"h":137440313859,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":1360387,"h":141735281155,"f":16777249},{"r":65537,"n":"InitializeSettings","d":1360387,"h":146030248451,"f":16777250},{"r":65537,"n":"Refresh","d":1360387,"h":150325215747,"f":16777256},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceEvent","d":1360387,"h":154620183043,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","o":"@$3","d":1360387,"h":158915150339,"f":16777249},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Write","o":"@$1","d":1360387,"h":163210117635,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1360387,"h":167505084931,"f":16777249},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"Write","d":1360387,"h":171800052227,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","o":"@$3","d":1360387,"h":176095019523,"f":16777249},{"r":65537,"p":[{"n":"value","p":131073}],"n":"WriteLine","o":"@$1","d":1360387,"h":180389986819,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1360387,"h":184684954115,"f":16777249},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","d":1360387,"h":188979921411,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteIf","o":"@$3","d":1360387,"h":193274888707,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteIf","o":"@$1","d":1360387,"h":197569856003,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$2","d":1360387,"h":201864823299,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteIf","d":1360387,"h":206159790595,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteLineIf","o":"@$3","d":1360387,"h":210454757891,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteLineIf","o":"@$1","d":1360387,"h":214749725187,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$2","d":1360387,"h":219044692483,"f":16777249},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLineIf","d":1360387,"h":223339659779,"f":16777249}],"l":[{"t":1622531,"n":"s_listeners","d":1360387,"h":8591294979,"f":4194338},{"t":262145,"n":"s_autoFlush","d":1360387,"h":12886262275,"f":4194338},{"t":262145,"n":"s_useGlobalLock","d":1360387,"h":17181229571,"f":4194338},{"t":262145,"n":"s_settingsInitialized","d":1360387,"h":21476196867,"f":4194338},{"t":262145,"n":"s_settingsInitializing","d":1360387,"h":25771164163,"f":4194338},{"t":131073,"n":"critSec","d":1360387,"h":30066131459,"f":4194344}],"j":[1425923],"h":1360387}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceInternal`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceSource", ($self) => class TraceSource extends $.$$.System.Object
        {
            /*List<WeakReference<TraceSource>>*/ static s_tracesources = null;
            /*int*/ static s_LastCollectionCount = 0;
            /*SourceSwitch?*/ _internalSwitch = null;
            /*TraceListenerCollection?*/ _listeners = null;
            /*SourceLevels*/ _switchLevel = 0;
            /*string*/ _sourceName = null;
            /*bool*/ _initCalled = false;
            /*bool*/ _configInitializing = false;
            /*StringDictionary?*/ _attributes = null;
            $ctor$2(/*string*/ name)
            {
                this.$ctor$1(name, 0/*SourceLevels.Off*/);
                {
                }
                return this;
            }
            $ctor$1(/*string*/ name, /*SourceLevels*/ defaultLevel)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentException.ThrowIfNullOrEmpty(name, "name");
                    this._sourceName = name;
                    this._switchLevel = defaultLevel;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                        {
                            $.$sdts.System.Diagnostics.TraceSource._pruneCachedTraceSources();
                            $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Add(new ($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource))().$ctor$3(this));
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    }
                }
                return this;
            }
            static /*void */ _pruneCachedTraceSources()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    {
                        if ($.$sdts.System.Diagnostics.TraceSource.s_LastCollectionCount !== $.$$.System.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<TraceSource>>*/ let buffer = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)))().$ctor$3($.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count; i++)
                            {
                                if ($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count)
                            {
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Clear();
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.AddRange(buffer);
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.TrimExcess();
                            }
                            $.$sdts.System.Diagnostics.TraceSource.s_LastCollectionCount = $.$$.System.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                }
            }
            /*void */ Initialize()
            {
                if (!this._initCalled)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this)
                        {
                            if (this._initCalled)
                            {
                                return;
                            }
                            if (this._configInitializing)
                            {
                                return;
                            }
                            this._configInitializing = true;
                            NoConfigInit_BeforeEvent.call(this);
                            /*InitializingTraceSourceEventArgs*/ let e = new $.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs().$ctor$2(this);
                            this.OnInitializing(e);
                            if (!e.WasInitialized)
                            {
                                NoConfigInit_AfterEvent.call(this);
                            }
                            this._configInitializing = false;
                            this._initCalled = true;
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this)
                    }
                }
                /*void*/  function NoConfigInit_BeforeEvent()
                {
                    this._listeners = new $.$sdts.System.Diagnostics.TraceListenerCollection().$ctor$1();
                    this._internalSwitch = new $.$sdts.System.Diagnostics.SourceSwitch().$ctor$3(this._sourceName, $.$$.System.Enum.ToStringT($.$sdts.System.Diagnostics.SourceLevels, $.$$.System.UInt32, this._switchLevel));
                }
                /*void*/  function NoConfigInit_AfterEvent()
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._listeners !== null, "_listeners != null");
                    this._listeners.Add(new $.$sdts.System.Diagnostics.DefaultTraceListener().$ctor$4());
                }
            }
            /*void */ Close()
            {
                if (this._listeners !== null)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = this._listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            /*void */ Flush()
            {
                if (this._listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = this._listeners.GetEnumerator();
                                while ($en6.System$Collections$IEnumerator$MoveNext())
                                {
                                    var listener = $en6.System$Collections$IEnumerator$Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        var $en4 = this._listeners.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var listener = $en4.System$Collections$IEnumerator$Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$$.System.Threading.Monitor.Enter$1(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            static /*void */ RefreshAll()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    {
                        $.$sdts.System.Diagnostics.TraceSource._pruneCachedTraceSources();
                        for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count; i++)
                        {
                            /*TraceSource?*/ let tracesource;
                            if ($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$ref(() => tracesource, ($v) => tracesource = $v, $.$sdts.System.Diagnostics.TraceSource)))
                            {
                                tracesource.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                }
            }
            /*void */ Refresh()
            {
                if (!this._initCalled)
                {
                    this.Initialize();
                    return;
                }
                this.OnInitializing(new $.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs().$ctor$2(this));
            }
            /*void */ TraceEvent$2(/*TraceEventType*/ eventType, /*int*/ id)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent$2(manager, this.Name, eventType, id);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent$2(manager, this.Name, eventType, id);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$2(manager, this.Name, eventType, id);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceEvent$1(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent(manager, this.Name, eventType, id, format, args);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceData(/*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceData(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceData(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData(manager, this.Name, eventType, id, data);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceData$1(/*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceData$1(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceData$1(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData$1(manager, this.Name, eventType, id, data);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceInformation$1(/*string?*/ message)
            {
                ;
            }
            /*void */ TraceInformation(/*string?*/ format, /*params object?[]?*/ args)
            {
                ;
            }
            /*void */ TraceTransfer(/*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                this.Initialize();
                /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                if (this._internalSwitch.ShouldTrace(4096/*TraceEventType.Transfer*/) && this._listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*StringDictionary */ get Attributes()
            {
                this.Initialize();
                return this._attributes ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*SourceLevels */ get DefaultLevel()
            {
                return this._switchLevel;
            }
            /*EventHandler<InitializingTraceSourceEventArgs>?*/ static Initializing = null;
            static add_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing = $.$$.System.Delegate.Combine($.$sdts.System.Diagnostics.TraceSource.Initializing, value);
            }
            static remove_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing = $.$$.System.Delegate.Remove($.$sdts.System.Diagnostics.TraceSource.Initializing, value);
            }
            /*void */ OnInitializing(/*InitializingTraceSourceEventArgs*/ e)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing?.Invoke(this, e);
                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = this.Listeners.GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var listener = $en5.System$Collections$IEnumerator$Current;
                                {
                                    $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = this.Listeners.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var listener = $en3.System$Collections$IEnumerator$Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(listener)
                                    {
                                        $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                            }
                        }
                    }
                }
            }
            /*string */ get Name()
            {
                return this._sourceName;
            }
            /*TraceListenerCollection */ get Listeners()
            {
                this.Initialize();
                return this._listeners;
            }
            /*SourceSwitch */ get Switch()
            {
                this.Initialize();
                return this._internalSwitch;
            }
            /*SourceSwitch */ set Switch(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "Switch");
                this.Initialize();
                this._internalSwitch = value;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_tracesources = new ($.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)))().$ctor$1();
                }
            }
            static $h = 1753603;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310756,"g":{"r":0,"d":0,"h":120260837891,"f":50331649},"n":"Attributes","d":1753603,"h":115965870595,"f":2097153},{"p":770563,"g":{"r":0,"d":0,"h":128850772483,"f":50331649},"n":"DefaultLevel","d":1753603,"h":124555805187,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":154620576259,"f":50331649},"n":"Name","d":1753603,"h":150325608963,"f":2097153},{"p":1622531,"g":{"r":0,"d":0,"h":163210510851,"f":50331649},"n":"Listeners","d":1753603,"h":158915543555,"f":2097153},{"p":836099,"g":{"r":0,"d":0,"h":171800445443,"f":50331649},"s":{"r":0,"d":0,"h":176095412739,"f":83886081},"n":"Switch","d":1753603,"h":167505478147,"f":2097153}],"m":[{"r":65537,"n":"_pruneCachedTraceSources","d":1753603,"h":51541361155,"f":16777250},{"r":65537,"n":"Initialize","d":1753603,"h":55836328451,"f":16777218},{"r":65537,"n":"Close","d":1753603,"h":60131295747,"f":16777217},{"r":65537,"n":"Flush","d":1753603,"h":64426263043,"f":16777217},{"r":$.$typeArray($.$$.System.String).$h,"n":"GetSupportedAttributes","d":1753603,"h":68721230339,"f":16777360},{"r":65537,"n":"RefreshAll","d":1753603,"h":73016197635,"f":16777256},{"r":65537,"n":"Refresh","d":1753603,"h":77311164931,"f":16777224},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361}],"n":"TraceEvent","o":"@$2","d":1753603,"h":81606132227,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"message","p":1310721}],"n":"TraceEvent","o":"@$1","d":1753603,"h":85901099523,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceEvent","d":1753603,"h":90196066819,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"data","p":131073}],"n":"TraceData","d":1753603,"h":94491034115,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"data","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceData","o":"@$1","d":1753603,"h":98786001411,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceInformation","o":"@$1","d":1753603,"h":103080968707,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceInformation","d":1753603,"h":107375936003,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"id","p":655361},{"n":"message","p":1310721},{"n":"relatedActivityId","p":56229889}],"n":"TraceTransfer","d":1753603,"h":111670903299,"f":16777217,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"e","p":639491}],"n":"OnInitializing","d":1753603,"h":146030641667,"f":16777224}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$$.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)).$h,"n":"s_tracesources","d":1753603,"h":4296720899,"f":4194338},{"t":655361,"n":"s_LastCollectionCount","d":1753603,"h":8591688195,"f":4194338},{"t":836099,"n":"_internalSwitch","d":1753603,"h":12886655491,"f":4194306},{"t":1622531,"n":"_listeners","d":1753603,"h":17181622787,"f":4194306},{"t":770563,"n":"_switchLevel","d":1753603,"h":21476590083,"f":4194306},{"t":1310721,"n":"_sourceName","d":1753603,"h":25771557379,"f":4194306},{"t":262145,"n":"_initCalled","d":1753603,"h":30066524675,"f":4194312},{"t":262145,"n":"_configInitializing","d":1753603,"h":34361491971,"f":4194312},{"t":1310756,"n":"_attributes","d":1753603,"h":38656459267,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$2","d":1753603,"h":42951426563,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"defaultLevel","p":770563}],"n":".ctor","o":"$ctor$1","d":1753603,"h":47246393859,"f":16777217}],"e":[{"e":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h}],"n":"add_Initializing","d":1753603,"h":133145739779,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h}],"n":"remove_Initializing","d":1753603,"h":137440707075,"f":285212705},"n":"Initializing","d":1753603,"h":141735674371,"f":8388641}],"h":1753603}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceSource`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.Trace", ($self) => class Trace extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*CorrelationManager*/ static CorrelationManager$ = null;
            static /*CorrelationManager */ get CorrelationManager()
            {
                return $.$sdts.System.Diagnostics.Trace.CorrelationManager$ ?? $.$$.System.Threading.Interlocked.CompareExchange$14($.$sdts.System.Diagnostics.CorrelationManager, $.$ref(() => $.$sdts.System.Diagnostics.Trace.CorrelationManager$, ($v) => $.$sdts.System.Diagnostics.Trace.CorrelationManager$ = $v, $.$sdts.System.Diagnostics.CorrelationManager), new $.$sdts.System.Diagnostics.CorrelationManager().$ctor$1(), null) ?? $.$sdts.System.Diagnostics.Trace.CorrelationManager$;
            }
            static /*TraceListenerCollection */ get Listeners()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.Listeners;
            }
            static /*bool */ get AutoFlush()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.AutoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.AutoFlush = value;
            }
            static /*bool */ get UseGlobalLock()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock = value;
            }
            static /*int */ get IndentLevel()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.IndentLevel = value;
            }
            static /*int */ get IndentSize()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.IndentSize = value;
            }
            static /*void */ Flush()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Flush();
            }
            static /*void */ Close()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Close();
            }
            static /*void */ Assert$2(/*bool*/ condition)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert$2(condition);
            }
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert$1(condition, message);
            }
            static /*void */ Assert(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert(condition, message, detailMessage);
            }
            static /*void */ Fail$1(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Fail$1(message);
            }
            static /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Fail(message, detailMessage);
            }
            /*EventHandler?*/ static Refreshing = null;
            static add_Refreshing(/*EventHandler?*/ value)
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing = $.$$.System.Delegate.Combine($.$sdts.System.Diagnostics.Trace.Refreshing, value);
            }
            static remove_Refreshing(/*EventHandler?*/ value)
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing = $.$$.System.Delegate.Remove($.$sdts.System.Diagnostics.Trace.Refreshing, value);
            }
            static /*void */ OnRefreshing()
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing?.Invoke(null, $.$$.System.EventArgs.Empty);
            }
            static /*void */ Refresh()
            {
                $.$sdts.System.Diagnostics.Trace.OnRefreshing();
                $.$sdts.System.Diagnostics.Switch.RefreshAll();
                $.$sdts.System.Diagnostics.TraceSource.RefreshAll();
                $.$sdts.System.Diagnostics.TraceInternal.Refresh();
            }
            static /*void */ TraceInformation$1(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, message, null);
            }
            static /*void */ TraceInformation(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, format, args);
            }
            static /*void */ TraceWarning$1(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, message, null);
            }
            static /*void */ TraceWarning(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, format, args);
            }
            static /*void */ TraceError$1(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, message, null);
            }
            static /*void */ TraceError(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, format, args);
            }
            static /*void */ Write$3(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$3(message);
            }
            static /*void */ Write$1(/*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$1(value);
            }
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$2(message, category);
            }
            static /*void */ Write(/*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write(value, category);
            }
            static /*void */ WriteLine$3(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$3(message);
            }
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$1(value);
            }
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$2(message, category);
            }
            static /*void */ WriteLine(/*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine(value, category);
            }
            static /*void */ WriteIf$3(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$3(condition, message);
            }
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$1(condition, value);
            }
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$2(condition, message, category);
            }
            static /*void */ WriteIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf(condition, value, category);
            }
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$3(condition, message);
            }
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$1(condition, value);
            }
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$2(condition, message, category);
            }
            static /*void */ WriteLineIf(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf(condition, value, category);
            }
            static /*void */ Indent()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Indent();
            }
            static /*void */ Unindent()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Unindent();
            }
            static $h = 1098243;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":180739,"g":{"r":0,"d":0,"h":17180967427,"f":50331681},"n":"CorrelationManager","d":1098243,"h":12886000131,"f":2097185},{"p":1622531,"g":{"r":0,"d":0,"h":25770902019,"f":50331681},"n":"Listeners","d":1098243,"h":21475934723,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":34360836611,"f":50331681},"s":{"r":0,"d":0,"h":38655803907,"f":83886113},"n":"AutoFlush","d":1098243,"h":30065869315,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":47245738499,"f":50331681},"s":{"r":0,"d":0,"h":51540705795,"f":83886113},"n":"UseGlobalLock","d":1098243,"h":42950771203,"f":2097185},{"p":655361,"g":{"r":0,"d":0,"h":60130640387,"f":50331681},"s":{"r":0,"d":0,"h":64425607683,"f":83886113},"n":"IndentLevel","d":1098243,"h":55835673091,"f":2097185},{"p":655361,"g":{"r":0,"d":0,"h":73015542275,"f":50331681},"s":{"r":0,"d":0,"h":77310509571,"f":83886113},"n":"IndentSize","d":1098243,"h":68720574979,"f":2097185}],"m":[{"r":65537,"n":"Flush","d":1098243,"h":81605476867,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Close","d":1098243,"h":85900444163,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145}],"n":"Assert","o":"@$2","d":1098243,"h":90195411459,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]},{"t":93847553,"c":4388814849,"a":[{"v":-1,"t":655361}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721,"f":65,"a":[{"t":87818241,"c":4382785537,"a":[{"v":"condition","t":1310721}]}]}],"n":"Assert","o":"@$1","d":1098243,"h":94490378755,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Assert","d":1098243,"h":98785346051,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","o":"@$1","d":1098243,"h":103080313347,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":1098243,"h":107375280643,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"OnRefreshing","d":1098243,"h":124555149827,"f":16777256},{"r":65537,"n":"Refresh","d":1098243,"h":128850117123,"f":16777249},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceInformation","o":"@$1","d":1098243,"h":133145084419,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceInformation","d":1098243,"h":137440051715,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceWarning","o":"@$1","d":1098243,"h":141735019011,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceWarning","d":1098243,"h":146029986307,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceError","o":"@$1","d":1098243,"h":150324953603,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h,"f":16}],"n":"TraceError","d":1098243,"h":154619920899,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","o":"@$3","d":1098243,"h":158914888195,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Write","o":"@$1","d":1098243,"h":163209855491,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1098243,"h":167504822787,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"Write","d":1098243,"h":171799790083,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","o":"@$3","d":1098243,"h":176094757379,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"WriteLine","o":"@$1","d":1098243,"h":180389724675,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1098243,"h":184684691971,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","d":1098243,"h":188979659267,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteIf","o":"@$3","d":1098243,"h":193274626563,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteIf","o":"@$1","d":1098243,"h":197569593859,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$2","d":1098243,"h":201864561155,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteIf","d":1098243,"h":206159528451,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteLineIf","o":"@$3","d":1098243,"h":210454495747,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteLineIf","o":"@$1","d":1098243,"h":214749463043,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$2","d":1098243,"h":219044430339,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLineIf","d":1098243,"h":223339397635,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Indent","d":1098243,"h":227634364931,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Unindent","d":1098243,"h":231929332227,"f":16777249,"a":[{"t":35979265,"c":4330946561,"a":[{"v":"TRACE","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1098243,"h":4296065539,"f":16777218}],"e":[{"e":47054849,"m":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"add_Refreshing","d":1098243,"h":111670247939,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":47054849}],"n":"remove_Refreshing","d":1098243,"h":115965215235,"f":285212705},"n":"Refreshing","d":1098243,"h":120260182531,"f":8388641}],"h":1098243}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Diagnostics.Trace`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceListenerCollection", ($self) => class TraceListenerCollection extends $.$$.System.Object
        {
            /*List<TraceListener?>*/ _list = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._list = new ($.$$.System.Collections.Generic.List$$($.$sdts.System.Diagnostics.TraceListener))().$ctor$3(1);
                }
                return this;
            }
            /*TraceListener*/ get_Item(/*int*/ i)
            {
                return this._list.get_Item(i);
            }
            /*void*/ set_Item(/*int*/ i, /*TraceListener*/ value)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(value);
                this._list.set_Item(i, value);
            }
            /*TraceListener?*/ get_Item$1(/*string*/ name)
            {
                var $en2 = this.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var listener = $en2.System$Collections$IEnumerator$Current;
                    {
                        if ($.$$.System.String.op_Equality(listener.Name, name))
                        {
                            return listener;
                        }
                    }
                }
                return null;
            }
            /*int */ get Count()
            {
                return this._list.Count;
            }
            /*int */ Add(/*TraceListener*/ listener)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        return (this._list).System$Collections$IList$Add(listener);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ AddRange(/*TraceListener[]*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                for(/*int*/ let i = 0; (i) < (value.length); i = ((((i) + (1)) | 0)))
                {
                    this.Add($.$$.System.Array.$ReadT1.call(value, i));
                }
            }
            /*void */ AddRange$1(/*TraceListenerCollection*/ value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                /*int*/ let currentCount = value.Count;
                for(/*int*/ let i = 0; i < currentCount; i = ((((i) + (1)) | 0)))
                {
                    this.Add(value.get_Item(i));
                }
            }
            /*void */ Clear()
            {
                this._list.Clear();
            }
            /*bool */ Contains(/*TraceListener?*/ listener)
            {
                return (this).System$Collections$IList$Contains(listener);
            }
            /*void */ CopyTo(/*TraceListener[]*/ listeners, /*int*/ index)
            {
                (this).System$Collections$ICollection$CopyTo(listeners, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this._list.GetEnumerator();
            }
            static /*void */ InitializeListener(/*TraceListener*/ listener)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(listener, "listener");
                listener.IndentSize = $.$sdts.System.Diagnostics.TraceInternal.IndentSize;
                listener.IndentLevel = $.$sdts.System.Diagnostics.TraceInternal.IndentLevel;
            }
            /*int */ IndexOf(/*TraceListener?*/ listener)
            {
                return (this).System$Collections$IList$IndexOf(listener);
            }
            /*void */ Insert(/*int*/ index, /*TraceListener*/ listener)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Insert(index, listener);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ Remove$1(/*TraceListener?*/ listener)
            {
                (this).System$Collections$IList$Remove(listener);
            }
            /*void */ Remove(/*string*/ name)
            {
                /*TraceListener?*/ let listener = this.get_Item$1(name);
                if (listener !== null)
                {
                    (this).System$Collections$IList$Remove(listener);
                }
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.RemoveAt(index);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this._list.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                this._list.set_Item(index, listener);
            }
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return false;
            }
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        return (this._list).System$Collections$IList$Add(value);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                return this._list.Contains($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
            }
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                return this._list.IndexOf$2($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
            }
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Insert(index, $.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Remove($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return true;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                (this._list).System$Collections$ICollection$CopyTo(array, index);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1622531;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1556995,"i":[{"n":"i","p":655361}],"g":{"r":0,"d":0,"h":17181491715,"f":50331649},"s":{"r":0,"d":0,"h":21476459011,"f":83886081},"n":"Item","o":"@$2","d":1622531,"h":12886524419,"f":2097153},{"p":1556995,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":30066393603,"f":50331649},"n":"Item","o":"@$3","d":1622531,"h":25771426307,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38656328195,"f":50331649},"n":"Count","d":1622531,"h":34361360899,"f":2097153},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":103080837635,"f":50331650},"s":{"r":0,"d":0,"h":107375804931,"f":83886082},"n":"{32047105}.this[]","o":"System$Collections$IList$Item","d":1622531,"h":98785870339,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":115965739523,"f":50331650},"n":"{32047105}.IsReadOnly","o":"System$Collections$IList$IsReadOnly","d":1622531,"h":111670772227,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":124555674115,"f":50331650},"n":"{32047105}.IsFixedSize","o":"System$Collections$IList$IsFixedSize","d":1622531,"h":120260706819,"f":2097154},{"p":131073,"g":{"r":0,"d":0,"h":154620445187,"f":50331650},"n":"{31457281}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":1622531,"h":150325477891,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":163210379779,"f":50331650},"n":"{31457281}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":1622531,"h":158915412483,"f":2097154}],"m":[{"r":655361,"p":[{"n":"listener","p":1556995}],"n":"Add","d":1622531,"h":42951295491,"f":16777217},{"r":65537,"p":[{"n":"value","p":$.$typeArray($.$sdts.System.Diagnostics.TraceListener).$h}],"n":"AddRange","d":1622531,"h":47246262787,"f":16777217},{"r":65537,"p":[{"n":"value","p":1622531}],"n":"AddRange","o":"@$1","d":1622531,"h":51541230083,"f":16777217},{"r":65537,"n":"Clear","d":1622531,"h":55836197379,"f":16777217},{"r":262145,"p":[{"n":"listener","p":1556995}],"n":"Contains","d":1622531,"h":60131164675,"f":16777217},{"r":65537,"p":[{"n":"listeners","p":$.$typeArray($.$sdts.System.Diagnostics.TraceListener).$h},{"n":"index","p":655361}],"n":"CopyTo","d":1622531,"h":64426131971,"f":16777217},{"r":31850497,"n":"GetEnumerator","d":1622531,"h":68721099267,"f":16777217},{"r":65537,"p":[{"n":"listener","p":1556995}],"n":"InitializeListener","d":1622531,"h":73016066563,"f":16777256},{"r":655361,"p":[{"n":"listener","p":1556995}],"n":"IndexOf","d":1622531,"h":77311033859,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361},{"n":"listener","p":1556995}],"n":"Insert","d":1622531,"h":81606001155,"f":16777217},{"r":65537,"p":[{"n":"listener","p":1556995}],"n":"Remove","o":"@$1","d":1622531,"h":85900968451,"f":16777217},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Remove","d":1622531,"h":90195935747,"f":16777217},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":1622531,"h":94490903043,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.List$$($.$sdts.System.Diagnostics.TraceListener).$h,"n":"_list","d":1622531,"h":4296589827,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1622531,"h":8591557123,"f":16777224}],"i":[32047105,31457281,31719425],"h":1622531}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IList, $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.TraceListenerCollection`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.EventTypeFilter", ($self) => class EventTypeFilter extends $.$sdts.System.Diagnostics.TraceFilter
        {
            /*SourceLevels*/ _level = 0;
            $ctor$2(/*SourceLevels*/ level)
            {
                super.$ctor$1();
                {
                    this._level = level;
                }
                return this;
            }
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                return (eventType & this._level) !== 0;
            }
            /*SourceLevels */ get EventType()
            {
                return this._level;
            }
            /*SourceLevels */ set EventType(value)
            {
                this._level = value;
            }
            static $h = 508419;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1294851,"p":[{"p":770563,"g":{"r":0,"d":0,"h":21475344899,"f":50331649},"s":{"r":0,"d":0,"h":25770312195,"f":83886081},"n":"EventType","d":508419,"h":17180377603,"f":2097153}],"m":[{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h},{"n":"data1","p":131073},{"n":"data","p":$.$typeArray($.$$.System.Object).$h}],"n":"ShouldTrace","d":508419,"h":12885410307,"f":16809985}],"l":[{"t":770563,"n":"_level","d":508419,"h":4295475715,"f":4194306}],"c":[{"p":[{"n":"level","p":770563}],"n":".ctor","o":"$ctor$2","d":508419,"h":8590443011,"f":16777217}],"h":508419}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceFilter; }
            static get $fullName() { return `System.Diagnostics.EventTypeFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SwitchLevelAttribute", ($self) => class SwitchLevelAttribute extends $.$$.System.Attribute
        {
            /*Type*/ _type = null;
            $ctor$2(/*Type*/ switchLevelType)
            {
                super.$ctor$1();
                {
                    this.SwitchLevelType = switchLevelType;
                }
                return this;
            }
            /*Type */ get SwitchLevelType()
            {
                return this._type;
            }
            /*Type */ set SwitchLevelType(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this._type = value;
            }
            static $h = 1032707;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":17180901891,"f":50331649},"s":{"r":0,"d":0,"h":21475869187,"f":83886081},"n":"SwitchLevelType","d":1032707,"h":12885934595,"f":2097153}],"l":[{"t":142475265,"n":"_type","d":1032707,"h":4296000003,"f":4194306}],"c":[{"p":[{"n":"switchLevelType","p":142475265}],"n":".ctor","o":"$ctor$2","d":1032707,"h":8590967299,"f":16777217}],"h":1032707,"a":[{"t":14745601,"c":21489582081,"a":[{"v":4,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Diagnostics.SwitchLevelAttribute`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SourceSwitch", ($self) => class SourceSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$4(/*string*/ name)
            {
                super.$ctor$2(name, $.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ displayName, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, $.$$.System.String.Empty, defaultSwitchValue);
                {
                }
                return this;
            }
            /*SourceLevels */ get Level()
            {
                return $.$cast(this.SwitchSetting, $.$sdts.System.Diagnostics.SourceLevels);
            }
            /*SourceLevels */ set Level(value)
            {
                this.SwitchSetting = value;
            }
            /*bool */ ShouldTrace(/*TraceEventType*/ eventType)
            {
                return (this.SwitchSetting & eventType) !== 0;
            }
            /*void */ OnValueChanged()
            {
                this.SwitchSetting = $.$$.System.Enum.Parse$6($.$sdts.System.Diagnostics.SourceLevels, this.Value, true);
            }
            static $h = 836099;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":901635,"p":[{"p":770563,"g":{"r":0,"d":0,"h":17180705283,"f":50331649},"s":{"r":0,"d":0,"h":21475672579,"f":83886081},"n":"Level","d":836099,"h":12885737987,"f":2097153}],"m":[{"r":262145,"p":[{"n":"eventType","p":1229315}],"n":"ShouldTrace","d":836099,"h":25770639875,"f":16777217},{"r":65537,"n":"OnValueChanged","d":836099,"h":30065607171,"f":16809988}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$4","d":836099,"h":4295803395,"f":16777217},{"p":[{"n":"displayName","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$3","d":836099,"h":8590770691,"f":16777217}],"h":836099}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.SourceSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SwitchAttribute", ($self) => class SwitchAttribute extends $.$$.System.Attribute
        {
            /*Type*/ _type = null;
            /*string*/ _name = null;
            $ctor$2(/*string*/ switchName, /*Type*/ switchType)
            {
                super.$ctor$1();
                {
                    this.SwitchName = switchName;
                    this.SwitchType = switchType;
                }
                return this;
            }
            /*string */ get SwitchName()
            {
                return this._name;
            }
            /*string */ set SwitchName(value)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(value, "value");
                this._name = value;
            }
            /*Type */ get SwitchType()
            {
                return this._type;
            }
            /*Type */ set SwitchType(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this._type = value;
            }
            /*string?*/ SwitchDescription = null;
            static /*SwitchAttribute[] */ GetAll(/*Assembly*/ assembly)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(assembly, "assembly");
                /*List<object>*/ let switchAttribs = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                /*object[]*/ let attribs = assembly.GetCustomAttributes$1($.$sdts.System.Diagnostics.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
                let $i1 = 0;
                let $arr1 = assembly.GetTypes();
                while ($i1 < $arr1.length)
                {
                    let type = $arr1[$i1++];
                    $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive$1(type, switchAttribs);
                }
                /*SwitchAttribute[]*/ let ret = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdts.System.Diagnostics.SwitchAttribute), null, [switchAttribs.Count], null);
                switchAttribs.CopyTo(ret, 0);
                return ret;
            }
            static /*void */ GetAllRecursive$1(/*Type*/ type, /*List<object>*/ switchAttribs)
            {
                $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive(type, switchAttribs);
                /*MemberInfo[]*/ let members = type.GetMembers$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/);
                let $i1 = 0;
                let $arr1 = members;
                while ($i1 < $arr1.length)
                {
                    let member = $arr1[$i1++];
                    if (!($.$is(member, $.$$.System.Type)))
                    {
                        $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive(member, switchAttribs);
                    }
                }
            }
            static /*void */ GetAllRecursive(/*MemberInfo*/ member, /*List<object>*/ switchAttribs)
            {
                /*object[]*/ let attribs = member.GetCustomAttributes$1($.$sdts.System.Diagnostics.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
            }
            static $h = 967171;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14614529,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475803651,"f":50331649},"s":{"r":0,"d":0,"h":25770770947,"f":83886081},"n":"SwitchName","d":967171,"h":17180836355,"f":2097153},{"p":142475265,"g":{"r":0,"d":0,"h":34360705539,"f":50331649},"s":{"r":0,"d":0,"h":38655672835,"f":83886081},"n":"SwitchType","d":967171,"h":30065738243,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540574723,"f":50331649},"s":{"r":0,"d":0,"h":55835542019,"f":83886081},"n":"SwitchDescription","d":967171,"h":47245607427,"f":2097153}],"m":[{"r":$.$typeArray($.$sdts.System.Diagnostics.SwitchAttribute).$h,"p":[{"n":"assembly","p":73465857}],"n":"GetAll","d":967171,"h":60130509315,"f":16777249},{"r":65537,"p":[{"n":"type","p":142475265},{"n":"switchAttribs","p":$.$$.System.Collections.Generic.List$$($.$$.System.Object).$h}],"n":"GetAllRecursive","o":"@$1","d":967171,"h":64425476611,"f":16777250},{"r":65537,"p":[{"n":"member","p":78249985},{"n":"switchAttribs","p":$.$$.System.Collections.Generic.List$$($.$$.System.Object).$h}],"n":"GetAllRecursive","d":967171,"h":68720443907,"f":16777250}],"l":[{"t":142475265,"n":"_type","d":967171,"h":4295934467,"f":4194306},{"t":1310721,"n":"_name","d":967171,"h":8590901763,"f":4194306}],"c":[{"p":[{"n":"switchName","p":1310721},{"n":"switchType","p":142475265}],"n":".ctor","o":"$ctor$2","d":967171,"h":12885869059,"f":16777217}],"h":967171,"a":[{"t":14745601,"c":21489582081,"a":[{"v":741,"t":14680065}]}]}; }
            static get $b() { return $.$$.System.Attribute; }
            static get $fullName() { return `System.Diagnostics.SwitchAttribute`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SourceFilter", ($self) => class SourceFilter extends $.$sdts.System.Diagnostics.TraceFilter
        {
            /*string*/ _src = null;
            $ctor$2(/*string*/ source)
            {
                super.$ctor$1();
                {
                    this.Source = source;
                }
                return this;
            }
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$$.System.String.Equals$3(this._src, source);
            }
            /*string */ get Source()
            {
                return this._src;
            }
            /*string */ set Source(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "Source");
                this._src = value;
            }
            static $h = 705027;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1294851,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475541507,"f":50331649},"s":{"r":0,"d":0,"h":25770508803,"f":83886081},"n":"Source","d":705027,"h":17180574211,"f":2097153}],"m":[{"r":262145,"p":[{"n":"cache","p":1163779},{"n":"source","p":1310721},{"n":"eventType","p":1229315},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":$.$typeArray($.$$.System.Object).$h},{"n":"data1","p":131073},{"n":"data","p":$.$typeArray($.$$.System.Object).$h}],"n":"ShouldTrace","d":705027,"h":12885606915,"f":16809985}],"l":[{"t":1310721,"n":"_src","d":705027,"h":4295672323,"f":4194306}],"c":[{"p":[{"n":"source","p":1310721}],"n":".ctor","o":"$ctor$2","d":705027,"h":8590639619,"f":16777217}],"h":705027}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceFilter; }
            static get $fullName() { return `System.Diagnostics.SourceFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.BooleanSwitch", ($self) => class BooleanSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$4(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$2(displayName, description);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, description, defaultSwitchValue);
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                return (this.SwitchSetting === 0) ? false : true;
            }
            /*bool */ set Enabled(value)
            {
                this.SwitchSetting = value ? 1 : 0;
            }
            /*void */ OnValueChanged()
            {
                /*bool*/ let b;
                if ($.$$.System.Boolean.TryParse$1(this.Value, $.$ref(() => b, ($v) => b = $v, $.$$.System.Boolean)))
                {
                    this.SwitchSetting = (b ? 1 : 0);
                }
                else 
                {
                    super.OnValueChanged();
                }
            }
            static $h = 115203;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":901635,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179984387,"f":50331649},"s":{"r":0,"d":0,"h":21474951683,"f":83886081},"n":"Enabled","d":115203,"h":12885017091,"f":2097153}],"m":[{"r":65537,"n":"OnValueChanged","d":115203,"h":25769918979,"f":16809988}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":115203,"h":4295082499,"f":16777217},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$3","d":115203,"h":8590049795,"f":16777217}],"h":115203,"a":[{"t":1032707,"c":8590967299,"a":[{"v":262145,"t":142475265}]}]}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.BooleanSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceSwitch", ($self) => class TraceSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$4(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$2(displayName, description);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$1(displayName, description, defaultSwitchValue);
                {
                }
                return this;
            }
            /*TraceLevel */ get Level()
            {
                return $.$cast(this.SwitchSetting, $.$sdts.System.Diagnostics.TraceLevel);
            }
            /*TraceLevel */ set Level(value)
            {
                if (value < 0/*TraceLevel.Off*/ || value > 4/*TraceLevel.Verbose*/)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sdts.System.SR.TraceSwitchInvalidLevel);
                }
                this.SetSwitchValues(value, $.$$.System.Enum.ToStringT($.$sdts.System.Diagnostics.TraceLevel, $.$$.System.UInt32, value));
            }
            /*bool */ get TraceError()
            {
                return this.Level >= 1/*TraceLevel.Error*/;
            }
            /*bool */ get TraceWarning()
            {
                return this.Level >= 2/*TraceLevel.Warning*/;
            }
            /*bool */ get TraceInfo()
            {
                return this.Level >= 3/*TraceLevel.Info*/;
            }
            /*bool */ get TraceVerbose()
            {
                return this.Level === 4/*TraceLevel.Verbose*/;
            }
            /*void */ OnSwitchSettingChanged()
            {
                /*int*/ let level = this.SwitchSetting;
                if (level < 0/*TraceLevel.Off*/)
                {
                    ;
                    this.SwitchSetting = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    ;
                    this.SwitchSetting = 4/*TraceLevel.Verbose*/;
                }
            }
            /*void */ OnValueChanged()
            {
                /*TraceLevel*/ let level = $.$$.System.Enum.Parse$6($.$sdts.System.Diagnostics.TraceLevel, this.Value, true);
                if (level < 0/*TraceLevel.Off*/)
                {
                    level = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    level = 4/*TraceLevel.Verbose*/;
                }
                this.SetSwitchValues(level, $.$$.System.Enum.ToStringT($.$sdts.System.Diagnostics.TraceLevel, $.$$.System.UInt32, level));
            }
            static $h = 1819139;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":901635,"p":[{"p":1491459,"g":{"r":0,"d":0,"h":17181688323,"f":50331649},"s":{"r":0,"d":0,"h":21476655619,"f":83886081},"n":"Level","d":1819139,"h":12886721027,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30066590211,"f":50331649},"n":"TraceError","d":1819139,"h":25771622915,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38656524803,"f":50331649},"n":"TraceWarning","d":1819139,"h":34361557507,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47246459395,"f":50331649},"n":"TraceInfo","d":1819139,"h":42951492099,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55836393987,"f":50331649},"n":"TraceVerbose","d":1819139,"h":51541426691,"f":2097153}],"m":[{"r":65537,"n":"OnSwitchSettingChanged","d":1819139,"h":60131361283,"f":16809988},{"r":65537,"n":"OnValueChanged","d":1819139,"h":64426328579,"f":16809988}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$4","d":1819139,"h":4296786435,"f":16777217},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$3","d":1819139,"h":8591753731,"f":16777217}],"h":1819139,"a":[{"t":1032707,"c":8590967299,"a":[{"v":1491459,"t":142475265}]}]}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.TraceSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.DefaultTraceListener", ($self) => class DefaultTraceListener extends $.$sdts.System.Diagnostics.TraceListener
        {
            /*bool*/ _assertUIEnabled = false;
            /*bool*/ _settingsInitialized = false;
            /*string?*/ _logFileName = null;
            $ctor$4()
            {
                super.$ctor$3("Default");
                {
                }
                return this;
            }
            /*bool */ get AssertUiEnabled()
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._assertUIEnabled;
            }
            /*bool */ set AssertUiEnabled(value)
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._assertUIEnabled = value;
            }
            /*string? */ get LogFileName()
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._logFileName;
            }
            /*string? */ set LogFileName(value)
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._logFileName = value;
            }
            /*void */ Fail$1(/*string?*/ message)
            {
                this.Fail(message, null);
            }
            /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
            {
                /*string*/ let stackTrace;
                try
                {
                    stackTrace = $.$$.System.Diagnostics.StackTrace.ToString.call(new $.$$.System.Diagnostics.StackTrace().$ctor$2(true));
                }
                catch($e)
                {
                    stackTrace = "";
                }
                this.WriteAssert(stackTrace, message, detailMessage);
                if (this.AssertUiEnabled)
                {
                    $.$$.System.Diagnostics.DebugProvider.FailCore(stackTrace, message, detailMessage, "Assertion Failed");
                }
            }
            /*void */ InitializeSettings()
            {
                this._assertUIEnabled = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.AssertUIEnabled;
                this._logFileName = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.LogFileName;
                this._settingsInitialized = true;
            }
            /*void */ WriteAssert(/*string*/ stackTrace, /*string?*/ message, /*string?*/ detailMessage)
            {
                this.WriteLine$3($.$sdts.System.SR.DebugAssertBanner + $.$$.System.Environment.NewLine + $.$sdts.System.SR.DebugAssertShortMessage + $.$$.System.Environment.NewLine + message + $.$$.System.Environment.NewLine + $.$sdts.System.SR.DebugAssertLongMessage + $.$$.System.Environment.NewLine + detailMessage + $.$$.System.Environment.NewLine + stackTrace);
            }
            /*void */ Write$3(/*string?*/ message)
            {
                this.Write$4(message, true);
            }
            /*void */ WriteLine$3(/*string?*/ message)
            {
                this.WriteLine$4(message, true);
            }
            /*void */ WriteLine$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                if (this.NeedIndent)
                {
                    this.WriteIndent();
                }
                this.Write$4(message + $.$$.System.Environment.NewLine, useLogFile);
                this.NeedIndent = true;
            }
            /*void */ Write$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                message ??= $.$$.System.String.Empty;
                if (this.NeedIndent && message.length !== 0)
                {
                    this.WriteIndent();
                }
                $.$$.System.Diagnostics.DebugProvider.WriteCore(message);
                if (useLogFile && !$.$$.System.String.IsNullOrEmpty(this.LogFileName))
                {
                    this.WriteToLogFile(message);
                }
            }
            /*void */ WriteToLogFile(/*string*/ message)
            {
                try
                {
                    $.$$.System.IO.File.AppendAllText$3(this.LogFileName, message);
                }
                catch(e)
                {
                    this.WriteLine$4($.$sdts.System.SR.Format$5($.$sdts.System.SR.ExceptionOccurred, this.LogFileName, e), false);
                }
            }
            static $h = 377347;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1556995,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770181123,"f":50331649},"s":{"r":0,"d":0,"h":30065148419,"f":83886081},"n":"AssertUiEnabled","d":377347,"h":21475213827,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38655083011,"f":50331649},"s":{"r":0,"d":0,"h":42950050307,"f":83886081},"n":"LogFileName","d":377347,"h":34360115715,"f":2097153}],"m":[{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","o":"@$1","d":377347,"h":47245017603,"f":16809985},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":377347,"h":51539984899,"f":16809985},{"r":65537,"n":"InitializeSettings","d":377347,"h":55834952195,"f":16777218},{"r":65537,"p":[{"n":"stackTrace","p":1310721},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"WriteAssert","d":377347,"h":60129919491,"f":16777218},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","o":"@$3","d":377347,"h":64424886787,"f":16809985},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","o":"@$3","d":377347,"h":68719854083,"f":16809985},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"useLogFile","p":262145}],"n":"WriteLine","o":"@$4","d":377347,"h":73014821379,"f":16777218},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"useLogFile","p":262145}],"n":"Write","o":"@$4","d":377347,"h":77309788675,"f":16777218},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteToLogFile","d":377347,"h":81604755971,"f":16777218}],"l":[{"t":262145,"n":"_assertUIEnabled","d":377347,"h":4295344643,"f":4194306},{"t":262145,"n":"_settingsInitialized","d":377347,"h":8590311939,"f":4194306},{"t":1310721,"n":"_logFileName","d":377347,"h":12885279235,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$4","d":377347,"h":17180246531,"f":16777217}],"i":[57540609],"h":377347}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceListener; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.DefaultTraceListener`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceEventType", ($self) => class TraceEventType extends $.$$.System.Enum
        {
            static Critical = 1;
            static Error = 2;
            static Warning = 4;
            static Information = 8;
            static Verbose = 16;
            static Start = 256;
            static Stop = 512;
            static Suspend = 1024;
            static Resume = 2048;
            static Transfer = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 4n,
                    "Information": 8n,
                    "Verbose": 16n,
                    "Start": 256n,
                    "Stop": 512n,
                    "Suspend": 1024n,
                    "Resume": 2048n,
                    "Transfer": 4096n
                };
            }
            static $h = 1229315;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1229315,"n":"Critical","d":1229315,"h":4296196611,"f":4194337},{"t":1229315,"n":"Error","d":1229315,"h":8591163907,"f":4194337},{"t":1229315,"n":"Warning","d":1229315,"h":12886131203,"f":4194337},{"t":1229315,"n":"Information","d":1229315,"h":17181098499,"f":4194337},{"t":1229315,"n":"Verbose","d":1229315,"h":21476065795,"f":4194337},{"t":1229315,"n":"Start","d":1229315,"h":25771033091,"f":4194337},{"t":1229315,"n":"Stop","d":1229315,"h":30066000387,"f":4194337},{"t":1229315,"n":"Suspend","d":1229315,"h":34360967683,"f":4194337},{"t":1229315,"n":"Resume","d":1229315,"h":38655934979,"f":4194337},{"t":1229315,"n":"Transfer","d":1229315,"h":42950902275,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1229315,"h":47245869571,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1229315}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceEventType`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceLevel", ($self) => class TraceLevel extends $.$$.System.Enum
        {
            static Off = 0;
            static Error = 1;
            static Warning = 2;
            static Info = 3;
            static Verbose = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Error": 1n,
                    "Warning": 2n,
                    "Info": 3n,
                    "Verbose": 4n
                };
            }
            static $h = 1491459;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1491459,"n":"Off","d":1491459,"h":4296458755,"f":4194337},{"t":1491459,"n":"Error","d":1491459,"h":8591426051,"f":4194337},{"t":1491459,"n":"Warning","d":1491459,"h":12886393347,"f":4194337},{"t":1491459,"n":"Info","d":1491459,"h":17181360643,"f":4194337},{"t":1491459,"n":"Verbose","d":1491459,"h":21476327939,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1491459,"h":25771295235,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1491459}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceLevel`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.SourceLevels", ($self) => class SourceLevels extends $.$$.System.Enum
        {
            static Off = 0;
            static Critical = 1;
            static Error = 3;
            static Warning = 7;
            static Information = 15;
            static Verbose = 31;
            static ActivityTracing = 65280;
            static All = -1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Critical": 1n,
                    "Error": 3n,
                    "Warning": 7n,
                    "Information": 15n,
                    "Verbose": 31n,
                    "ActivityTracing": 65280n,
                    "All": -1n
                };
            }
            static $h = 770563;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":770563,"n":"Off","d":770563,"h":4295737859,"f":4194337},{"t":770563,"n":"Critical","d":770563,"h":8590705155,"f":4194337},{"t":770563,"n":"Error","d":770563,"h":12885672451,"f":4194337},{"t":770563,"n":"Warning","d":770563,"h":17180639747,"f":4194337},{"t":770563,"n":"Information","d":770563,"h":21475607043,"f":4194337},{"t":770563,"n":"Verbose","d":770563,"h":25770574339,"f":4194337},{"t":770563,"n":"ActivityTracing","d":770563,"h":30065541635,"f":4194337,"a":[{"t":33292289,"c":4328259585,"a":[{"v":2,"t":33357825}]}]},{"t":770563,"n":"All","d":770563,"h":34360508931,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":770563,"h":38655476227,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":770563,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SourceLevels`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceOptions", ($self) => class TraceOptions extends $.$$.System.Enum
        {
            static None = 0;
            static LogicalOperationStack = 1;
            static DateTime = 2;
            static Timestamp = 4;
            static ProcessId = 8;
            static ThreadId = 16;
            static Callstack = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "LogicalOperationStack": 1n,
                    "DateTime": 2n,
                    "Timestamp": 4n,
                    "ProcessId": 8n,
                    "ThreadId": 16n,
                    "Callstack": 32n
                };
            }
            static $h = 1688067;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1688067,"n":"None","d":1688067,"h":4296655363,"f":4194337},{"t":1688067,"n":"LogicalOperationStack","d":1688067,"h":8591622659,"f":4194337},{"t":1688067,"n":"DateTime","d":1688067,"h":12886589955,"f":4194337},{"t":1688067,"n":"Timestamp","d":1688067,"h":17181557251,"f":4194337},{"t":1688067,"n":"ProcessId","d":1688067,"h":21476524547,"f":4194337},{"t":1688067,"n":"ThreadId","d":1688067,"h":25771491843,"f":4194337},{"t":1688067,"n":"Callstack","d":1688067,"h":30066459139,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1688067,"h":34361426435,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1688067,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceOptions`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.InitializingSwitchEventArgs", ($self) => class InitializingSwitchEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*Switch*/ $switch)
            {
                super.$ctor$1();
                {
                    this.Switch = $switch;
                }
                return this;
            }
            /*Switch*/ Switch = null;
            static $h = 573955;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":901635,"g":{"r":0,"d":0,"h":17180443139,"f":50331649},"n":"Switch","d":573955,"h":12885475843,"f":2097153}],"c":[{"p":[{"n":"switch","p":901635}],"n":".ctor","o":"$ctor$2","d":573955,"h":4295541251,"f":16777217}],"h":573955}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.InitializingSwitchEventArgs`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.InitializingTraceSourceEventArgs", ($self) => class InitializingTraceSourceEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2(/*TraceSource*/ traceSource)
            {
                super.$ctor$1();
                {
                    this.TraceSource = traceSource;
                }
                return this;
            }
            /*TraceSource*/ TraceSource = null;
            /*bool*/ WasInitialized = false;
            //default member initializer
            constructor()
            {
                super();
                this.WasInitialized = false;
            }
            static $h = 639491;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":1753603,"g":{"r":0,"d":0,"h":17180508675,"f":50331649},"n":"TraceSource","d":639491,"h":12885541379,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":30065410563,"f":50331649},"s":{"r":0,"d":0,"h":34360377859,"f":83886081},"n":"WasInitialized","d":639491,"h":25770443267,"f":2097153}],"c":[{"p":[{"n":"traceSource","p":1753603}],"n":".ctor","o":"$ctor$2","d":639491,"h":4295606787,"f":16777217}],"h":639491}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.InitializingTraceSourceEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Threading", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"))