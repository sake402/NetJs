
(function ($global, $, $spc, $sc, $sm, $spu, $st, $sr, $scn, $scm, $so, $scp, $scs) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.TraceSource", 
    {"h":44101,"f":"System.Diagnostics.TraceSource","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.TraceSource","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.TraceSource","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdts.System.Diagnostics.Switch", ($self) => class Switch extends $.$spc.System.Object
        {
            /*string?*/ _description = null;
            /*string*/ _displayName = null;
            /*int*/ _switchSetting = 0;
            /*bool*/ _initialized = false;
            /*bool*/ _initializing = false;
            /*string?*/ _switchValueString = null;
            /*string*/ _defaultValue = null;
            /*List<WeakReference<Switch>>*/ static s_switches = null;
            /*int*/ static s_LastCollectionCount = 0;
            /*StringDictionary?*/ _attributes = null;
            /*object*/ InitializedLock$ = null;
            /*object */ get InitializedLock()
            {
                return this.InitializedLock$ ?? $.$spc.System.Threading.Interlocked.CompareExchange$2($.$ref(() => this.InitializedLock$, ($v) => this.InitializedLock$ = $v, $.$spc.System.Object), new $.$spc.System.Object().$ctor(), null) ?? this.InitializedLock$;
            }
            $ctor$1(/*string*/ displayName, /*string?*/ description)
            {
                this.$ctor$2(displayName, description, "0");
                {
                }
                return this;
            }
            $ctor$2(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor();
                {
                    this._displayName = displayName ?? $.$spc.System.String.Empty;
                    this._description = description;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.Switch.s_switches)
                        {
                            $.$sdts.System.Diagnostics.Switch._pruneCachedSwitches();
                            $.$sdts.System.Diagnostics.Switch.s_switches.Add(new ($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.Switch))().$ctor$1(this));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                    }
                    this._defaultValue = defaultSwitchValue;
                }
                return this;
            }
            static /*void */ _pruneCachedSwitches()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.Switch.s_switches)
                    {
                        if ($.$sdts.System.Diagnostics.Switch.s_LastCollectionCount !== $.$spc.System.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<Switch>>*/ let buffer = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)))().$ctor$2($.$sdts.System.Diagnostics.Switch.s_switches.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.Switch.s_switches.Count; i++)
                            {
                                if ($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.System.Diagnostics.Switch.s_switches.Count)
                            {
                                $.$sdts.System.Diagnostics.Switch.s_switches.Clear();
                                $.$sdts.System.Diagnostics.Switch.s_switches.AddRange(buffer);
                                $.$sdts.System.Diagnostics.Switch.s_switches.TrimExcess();
                            }
                            $.$sdts.System.Diagnostics.Switch.s_LastCollectionCount = $.$spc.System.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                }
            }
            /*string */ get DisplayName()
            {
                return this._displayName;
            }
            /*string */ get Description()
            {
                return this._description ?? $.$spc.System.String.Empty;
            }
            /*StringDictionary */ get Attributes()
            {
                this.Initialize();
                return this._attributes ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*int */ get SwitchSetting()
            {
                if (!this._initialized)
                {
                    if (this.InitializeWithStatus())
                    {
                        this.OnSwitchSettingChanged();
                    }
                }
                return this._switchSetting;
            }
            /*int */ set SwitchSetting(value)
            {
                /*bool*/ let didUpdate = false;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.InitializedLock)
                    {
                        this._initialized = true;
                        if (this._switchSetting !== value)
                        {
                            this._switchSetting = value;
                            didUpdate = true;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.InitializedLock)
                }
                if (didUpdate)
                {
                    this.OnSwitchSettingChanged();
                }
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            /*void */ SetSwitchValues(/*int*/ switchSetting, /*string*/ switchValueString)
            {
                this.Initialize();
                $.$spc.System.Diagnostics.Debug.Assert$1(!(switchValueString === null), "Unexpected 'switchValueString' null value");
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.InitializedLock)
                    {
                        this._switchSetting = switchSetting;
                        this._switchValueString = switchValueString;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.InitializedLock)
                }
            }
            /*string */ get DefaultValue()
            {
                return this._defaultValue;
            }
            /*string */ get Value()
            {
                this.Initialize();
                return this._switchValueString;
            }
            /*string */ set Value(value)
            {
                this.Initialize();
                this._switchValueString = value;
                this.OnValueChanged();
            }
            /*EventHandler<InitializingSwitchEventArgs>?*/ static Initializing = null;
            static add_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.Switch.Initializing = $.$spc.System.Delegate.Combine($.$sdts.System.Diagnostics.Switch.Initializing, value);
            }
            static remove_Initializing(/*EventHandler<InitializingSwitchEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.Switch.Initializing = $.$spc.System.Delegate.Remove($.$sdts.System.Diagnostics.Switch.Initializing, value);
            }
            /*void */ OnInitializing()
            {
                $.$sdts.System.Diagnostics.Switch.Initializing?.Invoke(null, new $.$sdts.System.Diagnostics.InitializingSwitchEventArgs().$ctor$2(this));
                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
            }
            /*void */ Initialize()
            {
                this.InitializeWithStatus();
            }
            /*bool */ InitializeWithStatus()
            {
                if (!this._initialized)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.InitializedLock)
                        {
                            if (this._initialized || this._initializing)
                            {
                                return false;
                            }
                            this._initializing = true;
                            this._switchValueString = null;
                            try
                            {
                                this.OnInitializing();
                            }
                            catch($e)
                            {
                                this._initialized = false;
                                this._initializing = false;
                                throw $e;
                            }
                            if ($.$spc.System.String.op_Equality(this._switchValueString, null))
                            {
                                this._switchValueString = this._defaultValue;
                                this.OnValueChanged();
                            }
                            this._initialized = true;
                            this._initializing = false;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.InitializedLock)
                    }
                }
                return true;
            }
            /*void */ OnSwitchSettingChanged()
            {
            }
            /*void */ OnValueChanged()
            {
                this.SwitchSetting = $.$spc.System.Int32.Parse$2(this.Value, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            static /*void */ RefreshAll()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.Switch.s_switches)
                    {
                        $.$sdts.System.Diagnostics.Switch._pruneCachedSwitches();
                        for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.Switch.s_switches.Count; i++)
                        {
                            /*Switch?*/ let swtch;
                            if ($.$sdts.System.Diagnostics.Switch.s_switches.get_Item(i).TryGetTarget($.$ref(() => swtch, ($v) => swtch = $v, $.$sdts.System.Diagnostics.Switch)))
                            {
                                swtch.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.Switch.s_switches)
                }
            }
            /*void */ Refresh()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.InitializedLock)
                    {
                        this._initialized = false;
                        this.Initialize();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.InitializedLock)
                }
            }
            //default member initializer
            constructor()
            {
                super();
                this._switchValueString = $.$spc.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_switches = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)))().$ctor$1();
                }
            }
            static $h = 896069;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":55835470917,"f":2},"n":"InitializedLock","d":896069,"h":51540503621,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":77310307397,"f":1},"n":"DisplayName","d":896069,"h":73015340101,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":85900241989,"f":1},"n":"Description","d":896069,"h":81605274693,"f":1},{"p":1310756,"g":{"r":0,"d":0,"h":94490176581,"f":1},"n":"Attributes","d":896069,"h":90195209285,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080111173,"f":4},"s":{"r":0,"d":0,"h":107375078469,"f":4},"n":"SwitchSetting","d":896069,"h":98785143877,"f":4},{"p":1310721,"g":{"r":0,"d":0,"h":124554947653,"f":1},"n":"DefaultValue","d":896069,"h":120259980357,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":133144882245,"f":1},"s":{"r":0,"d":0,"h":137439849541,"f":1},"n":"Value","d":896069,"h":128849914949,"f":1}],"m":[{"r":65537,"n":"_pruneCachedSwitches","d":896069,"h":68720372805,"f":34},{"r":0,"n":"GetSupportedAttributes","d":896069,"h":111670045765,"f":144},{"r":65537,"p":[{"n":"switchSetting","p":655361},{"n":"switchValueString","p":1310721}],"n":"SetSwitchValues","d":896069,"h":115965013061,"f":8},{"r":65537,"n":"OnInitializing","d":896069,"h":154619718725,"f":8},{"r":65537,"n":"Initialize","d":896069,"h":158914686021,"f":2},{"r":262145,"n":"InitializeWithStatus","d":896069,"h":163209653317,"f":2},{"r":65537,"n":"OnSwitchSettingChanged","d":896069,"h":167504620613,"f":132},{"r":65537,"n":"OnValueChanged","d":896069,"h":171799587909,"f":132},{"r":65537,"n":"RefreshAll","d":896069,"h":176094555205,"f":40},{"r":65537,"n":"Refresh","d":896069,"h":180389522501,"f":1}],"l":[{"t":1310721,"n":"_description","d":896069,"h":4295863365,"f":2},{"t":1310721,"n":"_displayName","d":896069,"h":8590830661,"f":2},{"t":655361,"n":"_switchSetting","d":896069,"h":12885797957,"f":2},{"t":262145,"n":"_initialized","d":896069,"h":17180765253,"f":2},{"t":262145,"n":"_initializing","d":896069,"h":21475732549,"f":2},{"t":1310721,"n":"_switchValueString","d":896069,"h":25770699845,"f":2},{"t":1310721,"n":"_defaultValue","d":896069,"h":30065667141,"f":2},{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.Switch)).$h,"n":"s_switches","d":896069,"h":34360634437,"f":34},{"t":655361,"n":"s_LastCollectionCount","d":896069,"h":38655601733,"f":34},{"t":1310756,"n":"_attributes","d":896069,"h":42950569029,"f":2}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$1","d":896069,"h":60130438213,"f":4},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$2","d":896069,"h":64425405509,"f":4}],"e":[{"e":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h}],"n":"add_Initializing","d":896069,"h":141734816837,"f":33},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingSwitchEventArgs).$h}],"n":"remove_Initializing","d":896069,"h":146029784133,"f":33},"n":"Initializing","d":896069,"h":150324751429,"f":33}],"h":896069}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Switch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceFilter", ($self) => class TraceFilter extends $.$spc.System.Object
        {
            /*bool */ ShouldTrace$1(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, null, null, null);
            }
            /*bool */ ShouldTrace$2(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, null, null);
            }
            /*bool */ ShouldTrace$3(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1)
            {
                return this.ShouldTrace(cache, source, eventType, id, formatOrMessage, args, data1, null);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 1289285;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":0},{"n":"data1","p":131073},{"n":"data","p":0}],"n":"ShouldTrace","d":1289285,"h":4296256581,"f":257},{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721}],"n":"ShouldTrace","o":"@$1","d":1289285,"h":8591223877,"f":8},{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":0}],"n":"ShouldTrace","o":"@$2","d":1289285,"h":12886191173,"f":8},{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":0},{"n":"data1","p":131073}],"n":"ShouldTrace","o":"@$3","d":1289285,"h":17181158469,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":1289285,"h":21476125765,"f":4}],"h":1289285}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceListener", ($self) => class TraceListener extends $.$spc.System.MarshalByRefObject
        {
            /*int*/ _indentLevel = 0;
            /*int*/ _indentSize = 4;
            /*TraceOptions*/ _traceOptions = 0;
            /*bool*/ _needIndent = true;
            /*string?*/ _listenerName = null;
            /*TraceFilter?*/ _filter = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*string?*/ name)
            {
                super.$ctor$1();
                {
                    this._listenerName = name;
                }
                return this;
            }
            /*StringDictionary*/ Attributes$ = null;
            /*StringDictionary */ get Attributes()
            {
                return this.Attributes$ ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*string */ get Name()
            {
                return this._listenerName ?? "";
            }
            /*string */ set Name(value)
            {
                this._listenerName = value;
            }
            /*bool */ get IsThreadSafe()
            {
                return false;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$spc.System.GC.SuppressFinalize(this);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                return;
            }
            /*void */ Flush()
            {
                return;
            }
            /*int */ get IndentLevel()
            {
                return this._indentLevel;
            }
            /*int */ set IndentLevel(value)
            {
                this._indentLevel = (value < 0) ? 0 : value;
            }
            /*int */ get IndentSize()
            {
                return this._indentSize;
            }
            /*int */ set IndentSize(value)
            {
                if (value < 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$19("IndentSize", $.$box(value, $.$spc.System.Int32), $.$sdts.System.SR.TraceListenerIndentSize);
                }
                this._indentSize = value;
            }
            /*TraceFilter? */ get Filter()
            {
                return this._filter;
            }
            /*TraceFilter? */ set Filter(value)
            {
                this._filter = value;
            }
            /*bool */ get NeedIndent()
            {
                return this._needIndent;
            }
            /*bool */ set NeedIndent(value)
            {
                this._needIndent = value;
            }
            /*TraceOptions */ get TraceOutputOptions()
            {
                return this._traceOptions;
            }
            /*TraceOptions */ set TraceOutputOptions(value)
            {
                if ((value >> 6) !== 0)
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
                this._traceOptions = value;
            }
            /*void */ Close()
            {
                return;
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            /*void */ TraceTransfer(/*TraceEventCache?*/ eventCache, /*string*/ source, /*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                this.TraceEvent$1(eventCache, source, 4096/*TraceEventType.Transfer*/, id, $.$spc.System.String.Create$10(null, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null), `${message}, relatedActivityId=${$.$spc.System.Guid.ToString.call(relatedActivityId)}`));
            }
            /*void */ Fail(/*string?*/ message)
            {
                this.Fail$1(message, null);
            }
            /*void */ Fail$1(/*string?*/ message, /*string?*/ detailMessage)
            {
                this.WriteLine(detailMessage === null ? `${$.$sdts.System.SR.TraceListenerFail} ${message}` : `${$.$sdts.System.SR.TraceListenerFail} ${message} ${detailMessage}`);
            }
            /*void */ Write$1(/*object?*/ o)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                if (o === null)
                {
                    return;
                }
                this.Write($.$spc.System.Object.ToString.call(o));
            }
            /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if ($.$spc.System.String.op_Equality(category, null))
                {
                    this.Write(message);
                }
                else 
                {
                    this.Write(category + ": " + (message ?? $.$spc.System.String.Empty));
                }
            }
            /*void */ Write$3(/*object?*/ o, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                if ($.$spc.System.String.op_Equality(category, null))
                {
                    this.Write$1(o);
                }
                else 
                {
                    this.Write$2(o === null ? "" : $.$spc.System.Object.ToString.call(o), category);
                }
            }
            /*void */ WriteIndent()
            {
                this.NeedIndent = false;
                for(/*int*/ let i = 0; i < this._indentLevel; i++)
                {
                    if (this._indentSize === 4)
                    {
                        this.Write("    ");
                    }
                    else 
                    {
                        for(/*int*/ let j = 0; j < this._indentSize; j++)
                        {
                            this.Write(" ");
                        }
                    }
                }
            }
            /*void */ WriteLine$1(/*object?*/ o)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, null, null, o))
                {
                    return;
                }
                this.WriteLine(o === null ? "" : $.$spc.System.Object.ToString.call(o));
            }
            /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(null, "", 16/*TraceEventType.Verbose*/, 0, message))
                {
                    return;
                }
                if ($.$spc.System.String.op_Equality(category, null))
                {
                    this.WriteLine(message);
                }
                else 
                {
                    this.WriteLine(category + ": " + (message ?? $.$spc.System.String.Empty));
                }
            }
            /*void */ WriteLine$3(/*object?*/ o, /*string?*/ category)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(null, "", 16/*TraceEventType.Verbose*/, 0, category, null, o))
                {
                    return;
                }
                this.WriteLine$2(o === null ? "" : $.$spc.System.Object.ToString.call(o), category);
            }
            /*void */ TraceData(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$3(eventCache, source, eventType, id, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                /*string?*/ let datastring = $.$spc.System.String.Empty;
                if (data !== null)
                {
                    datastring = $.$spc.System.Object.ToString.call(data);
                }
                this.WriteLine(datastring);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceData$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace(eventCache, source, eventType, id, null, null, null, data))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine(data !== null ? $.$spc.System.String.Join$9(", ", data) : $.$spc.System.String.Empty);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceEvent(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                this.TraceEvent$1(eventCache, source, eventType, id, $.$spc.System.String.Empty);
            }
            /*void */ TraceEvent$1(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$1(eventCache, source, eventType, id, message))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                this.WriteLine(message);
                this.WriteFooter(eventCache);
            }
            /*void */ TraceEvent$2(/*TraceEventCache?*/ eventCache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                if (this.Filter !== null && !this.Filter.ShouldTrace$2(eventCache, source, eventType, id, format, args))
                {
                    return;
                }
                this.WriteHeader(source, eventType, id);
                if (args !== null)
                {
                    this.WriteLine($.$spc.System.String.Format$8($.$spc.System.Globalization.CultureInfo.InvariantCulture, format, args));
                }
                else 
                {
                    this.WriteLine(format);
                }
                this.WriteFooter(eventCache);
            }
            /*void */ WriteHeader(/*string*/ source, /*TraceEventType*/ eventType, /*int*/ id)
            {
                this.Write($.$spc.System.String.Create$10($.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null), `${source} ${eventType}: ${id} : `));
            }
            /*void */ WriteFooter(/*TraceEventCache?*/ eventCache)
            {
                if (eventCache === null)
                {
                    return;
                }
                this._indentLevel++;
                if (this.IsEnabled(8/*TraceOptions.ProcessId*/))
                {
                    this.WriteLine("ProcessId=" + eventCache.ProcessId);
                }
                if (this.IsEnabled(1/*TraceOptions.LogicalOperationStack*/))
                {
                    this.Write("LogicalOperationStack=");
                    /*Stack*/ let operationStack = eventCache.LogicalOperationStack;
                    /*bool*/ let first = true;
                    var $en3 = operationStack.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var obj = $en3.Current;
                        {
                            if (!first)
                            {
                                this.Write(", ");
                            }
                            else 
                            {
                                first = false;
                            }
                            this.Write($.$spc.System.Object.ToString.call(obj));
                        }
                    }
                    this.WriteLine($.$spc.System.String.Empty);
                }
                /*Span<char>*/ let stackBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null);
                if (this.IsEnabled(16/*TraceOptions.ThreadId*/))
                {
                    this.WriteLine("ThreadId=" + eventCache.ThreadId);
                }
                if (this.IsEnabled(2/*TraceOptions.DateTime*/))
                {
                    this.WriteLine($.$spc.System.String.Create$10(null, stackBuffer, (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 1);
                        $handler.AppendLiteral("DateTime=");
                        $handler.AppendFormatted$8($.$box(eventCache.DateTime, $.$spc.System.DateTime), null, "o");
                        return $handler.ToStringAndClear();
                    })()));
                }
                if (this.IsEnabled(4/*TraceOptions.Timestamp*/))
                {
                    this.WriteLine($.$spc.System.String.Create$10(null, stackBuffer, `Timestamp=${eventCache.Timestamp}`));
                }
                if (this.IsEnabled(32/*TraceOptions.Callstack*/))
                {
                    this.WriteLine("Callstack=" + eventCache.Callstack);
                }
                this._indentLevel--;
            }
            /*bool */ IsEnabled(/*TraceOptions*/ opts)
            {
                return (opts & this.TraceOutputOptions) !== 0;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1551429;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":65011713,"p":[{"p":1310756,"g":{"r":0,"d":0,"h":47246191685,"f":1},"n":"Attributes","d":1551429,"h":42951224389,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55836126277,"f":129},"s":{"r":0,"d":0,"h":60131093573,"f":129},"n":"Name","d":1551429,"h":51541158981,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":68721028165,"f":129},"n":"IsThreadSafe","d":1551429,"h":64426060869,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":90195864645,"f":1},"s":{"r":0,"d":0,"h":94490831941,"f":1},"n":"IndentLevel","d":1551429,"h":85900897349,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080766533,"f":1},"s":{"r":0,"d":0,"h":107375733829,"f":1},"n":"IndentSize","d":1551429,"h":98785799237,"f":1},{"p":1289285,"g":{"r":0,"d":0,"h":115965668421,"f":1},"s":{"r":0,"d":0,"h":120260635717,"f":1},"n":"Filter","d":1551429,"h":111670701125,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":128850570309,"f":4},"s":{"r":0,"d":0,"h":133145537605,"f":4},"n":"NeedIndent","d":1551429,"h":124555603013,"f":4},{"p":1682501,"g":{"r":0,"d":0,"h":141735472197,"f":1},"s":{"r":0,"d":0,"h":146030439493,"f":1},"n":"TraceOutputOptions","d":1551429,"h":137440504901,"f":1}],"m":[{"r":65537,"n":"Dispose","d":1551429,"h":73015995461,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1551429,"h":77310962757,"f":132},{"r":65537,"n":"Flush","d":1551429,"h":81605930053,"f":129},{"r":65537,"n":"Close","d":1551429,"h":150325406789,"f":129},{"r":0,"n":"GetSupportedAttributes","d":1551429,"h":154620374085,"f":144},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"id","p":655361},{"n":"message","p":1310721},{"n":"relatedActivityId","p":56164353}],"n":"TraceTransfer","d":1551429,"h":158915341381,"f":129},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","d":1551429,"h":163210308677,"f":129},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","o":"@$1","d":1551429,"h":167505275973,"f":129},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":1551429,"h":171800243269,"f":257},{"r":65537,"p":[{"n":"o","p":131073}],"n":"Write","o":"@$1","d":1551429,"h":176095210565,"f":129},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1551429,"h":180390177861,"f":129},{"r":65537,"p":[{"n":"o","p":131073},{"n":"category","p":1310721}],"n":"Write","o":"@$3","d":1551429,"h":184685145157,"f":129},{"r":65537,"n":"WriteIndent","d":1551429,"h":188980112453,"f":132},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":1551429,"h":193275079749,"f":257},{"r":65537,"p":[{"n":"o","p":131073}],"n":"WriteLine","o":"@$1","d":1551429,"h":197570047045,"f":129},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1551429,"h":201865014341,"f":129},{"r":65537,"p":[{"n":"o","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$3","d":1551429,"h":206159981637,"f":129},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"data","p":131073}],"n":"TraceData","d":1551429,"h":210454948933,"f":129},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"data","p":0,"f":16}],"n":"TraceData","o":"@$1","d":1551429,"h":214749916229,"f":129},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361}],"n":"TraceEvent","d":1551429,"h":219044883525,"f":129},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"message","p":1310721}],"n":"TraceEvent","o":"@$1","d":1551429,"h":223339850821,"f":129},{"r":65537,"p":[{"n":"eventCache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceEvent","o":"@$2","d":1551429,"h":227634818117,"f":129},{"r":65537,"p":[{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361}],"n":"WriteHeader","d":1551429,"h":231929785413,"f":2},{"r":65537,"p":[{"n":"eventCache","p":1158213}],"n":"WriteFooter","d":1551429,"h":236224752709,"f":2},{"r":262145,"p":[{"n":"opts","p":1682501}],"n":"IsEnabled","d":1551429,"h":240519720005,"f":8}],"l":[{"t":655361,"n":"_indentLevel","d":1551429,"h":4296518725,"f":2},{"t":655361,"n":"_indentSize","d":1551429,"h":8591486021,"f":2},{"t":1682501,"n":"_traceOptions","d":1551429,"h":12886453317,"f":2},{"t":262145,"n":"_needIndent","d":1551429,"h":17181420613,"f":2},{"t":1310721,"n":"_listenerName","d":1551429,"h":21476387909,"f":2},{"t":1289285,"n":"_filter","d":1551429,"h":25771355205,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":1551429,"h":30066322501,"f":4},{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$3","d":1551429,"h":34361289797,"f":4}],"i":[57475073],"h":1551429}; }
            static get $b() { return $.$spc.System.MarshalByRefObject; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.TraceListener`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.CorrelationManager", ($self) => class CorrelationManager extends $.$spc.System.Object
        {
            /*AsyncLocal<Guid>*/ _activityId = null;
            /*AsyncLocal<StackNode?>*/ _stack = null;
            /*AsyncLocalStackWrapper*/ _stackWrapper = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._stackWrapper = new $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                }
                return this;
            }
            /*Stack */ get LogicalOperationStack()
            {
                return this._stackWrapper;
            }
            /*void */ StartLogicalOperation()
            {
                return this.StartLogicalOperation$1($.$spc.System.Guid.NewGuid());
            }
            /*void */ StopLogicalOperation()
            {
                return this._stackWrapper.Pop();
            }
            /*Guid */ get ActivityId()
            {
                return this._activityId.Value;
            }
            /*Guid */ set ActivityId(value)
            {
                this._activityId.Value = value;
            }
            /*void */ StartLogicalOperation$1(/*object*/ operationId)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(operationId, "operationId");
                this._stackWrapper.Push(operationId);
            }
            static $_StackNode;
            static get StackNode()
            {
                let $cls = $.$sdts.System.Diagnostics.CorrelationManager;
                return $cls.$_StackNode ??= $asm.$ncls("$sdts.System.Diagnostics.CorrelationManager.StackNode", ($self) => class StackNode extends $.$spc.System.Object
                {
                    $ctor$1(/*object?*/ value, /*StackNode?*/ prev)
                    {
                        super.$ctor();
                        {
                            this.Value = value;
                            this.Prev = prev;
                            this.Count = prev !== null ? ((prev.Count + 1) | 0) : 1;
                        }
                        return this;
                    }
                    /*int*/ Count = 0;
                    /*object?*/ Value = null;
                    /*StackNode?*/ Prev = null;
                    static $h = 306245;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180175429,"f":8},"n":"Count","d":306245,"h":12885208133,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":30065077317,"f":8},"n":"Value","d":306245,"h":25770110021,"f":8},{"p":306245,"g":{"r":0,"d":0,"h":42949979205,"f":8},"n":"Prev","d":306245,"h":38655011909,"f":8}],"c":[{"p":[{"n":"value","p":131073},{"n":"prev","p":306245,"f":65}],"n":".ctor","o":"$ctor$1","d":306245,"h":4295273541,"f":8}],"d":175173,"h":306245}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Diagnostics.CorrelationManager.StackNode`; }
                }, $cls, ($v) => $cls.$_StackNode = $v);
            }
            static $_AsyncLocalStackWrapper;
            static get AsyncLocalStackWrapper()
            {
                let $cls = $.$sdts.System.Diagnostics.CorrelationManager;
                return $cls.$_AsyncLocalStackWrapper ??= $asm.$ncls("$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper", ($self) => class AsyncLocalStackWrapper extends $.$scn.System.Collections.Stack
                {
                    /*AsyncLocal<StackNode?>*/ _stack = null;
                    $ctor$4(/*AsyncLocal<StackNode?>*/ stack)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(stack !== null, "stack != null");
                            this._stack = stack;
                        }
                        return this;
                    }
                    /*void */ Clear()
                    {
                        return this._stack.Value = null;
                    }
                    /*object */ Clone()
                    {
                        return new $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper().$ctor$4(this._stack);
                    }
                    /*int */ get Count()
                    {
                        return (this._stack.Value?.Count ?? null) ?? 0;
                    }
                    /*IEnumerator */ GetEnumerator()
                    {
                        return $.$sdts.System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper.GetEnumerator$1(this._stack.Value);
                    }
                    /*object? */ Peek()
                    {
                        return (this._stack.Value?.Value ?? null);
                    }
                    /*bool */ Contains(/*object?*/ obj)
                    {
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            if (obj === null)
                            {
                                if (n.Value === null)
                                {
                                    return true;
                                }
                            }
                            else if ($.$spc.System.Object.Equals.call(obj, n.Value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    /*void */ CopyTo(/*Array*/ array, /*int*/ index)
                    {
                        for(/*StackNode?*/ let n = this._stack.Value; n !== null; n = n.Prev)
                        {
                            array.SetValue(n.Value, index++);
                        }
                    }
                    static /*IEnumerator */ GetEnumerator$1(/*StackNode?*/ n)
                    {
                        return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                        {
                            while(n !== null)
                            {
                                yield n.Value;
                                n = n.Prev;
                            }
                        }.bind(this)).GetEnumerator();
                    }
                    /*object? */ Pop()
                    {
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            super.Pop();
                        }
                        this._stack.Value = n.Prev;
                        return n.Value;
                    }
                    /*void */ Push(/*object?*/ obj)
                    {
                        this._stack.Value = new $.$sdts.System.Diagnostics.CorrelationManager.StackNode().$ctor$1(obj, this._stack.Value);
                    }
                    /*object?[] */ ToArray()
                    {
                        /*StackNode?*/ let n = this._stack.Value;
                        if (n === null)
                        {
                            return $.$spc.System.Array.Empty($.$spc.System.Object);
                        }
                        /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                        do
                        {
                            results.Add(n.Value);
                            n = n.Prev;
                        }
                        while(n !== null);
                        return results.ToArray();
                    }
                    static $h = 240709;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048611,"p":[{"p":655361,"g":{"r":0,"d":0,"h":25770044485,"f":32769},"n":"Count","d":240709,"h":21475077189,"f":32769}],"m":[{"r":65537,"n":"Clear","d":240709,"h":12885142597,"f":32769},{"r":131073,"n":"Clone","d":240709,"h":17180109893,"f":32769},{"r":31719425,"n":"GetEnumerator","d":240709,"h":30065011781,"f":32769},{"r":131073,"n":"Peek","d":240709,"h":34359979077,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Contains","d":240709,"h":38654946373,"f":32769},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":240709,"h":42949913669,"f":32769},{"r":31719425,"p":[{"n":"n","p":306245}],"n":"GetEnumerator","o":"@$1","d":240709,"h":47244880965,"f":34},{"r":131073,"n":"Pop","d":240709,"h":51539848261,"f":32769},{"r":65537,"p":[{"n":"obj","p":131073}],"n":"Push","d":240709,"h":55834815557,"f":32769},{"r":0,"n":"ToArray","d":240709,"h":60129782853,"f":32769}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h,"n":"_stack","d":240709,"h":4295208005,"f":2}],"c":[{"p":[{"n":"stack","p":$.$spc.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h}],"n":".ctor","o":"$ctor$4","d":240709,"h":8590175301,"f":8}],"i":[31326209,31588353,57147393],"d":175173,"h":240709}; }
                    static get $b() { return $.$scn.System.Collections.Stack; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable, $.$spc.System.ICloneable ]; }
                    static get $fullName() { return `System.Diagnostics.CorrelationManager.AsyncLocalStackWrapper`; }
                }, $cls, ($v) => $cls.$_AsyncLocalStackWrapper = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._activityId = new ($.$spc.System.Threading.AsyncLocal$$($.$spc.System.Guid))().$ctor$1();
                this._stack = new ($.$spc.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode))().$ctor$1();
            }
            static $h = 175173;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1048611,"g":{"r":0,"d":0,"h":25769978949,"f":1},"n":"LogicalOperationStack","d":175173,"h":21475011653,"f":1},{"p":56164353,"g":{"r":0,"d":0,"h":42949848133,"f":1},"s":{"r":0,"d":0,"h":47244815429,"f":1},"n":"ActivityId","d":175173,"h":38654880837,"f":1}],"m":[{"r":65537,"n":"StartLogicalOperation","d":175173,"h":30064946245,"f":1},{"r":65537,"n":"StopLogicalOperation","d":175173,"h":34359913541,"f":1},{"r":65537,"p":[{"n":"operationId","p":131073}],"n":"StartLogicalOperation","o":"@$1","d":175173,"h":51539782725,"f":1}],"l":[{"t":$.$spc.System.Threading.AsyncLocal$$($.$spc.System.Guid).$h,"n":"_activityId","d":175173,"h":4295142469,"f":2},{"t":$.$spc.System.Threading.AsyncLocal$$($.$sdts.System.Diagnostics.CorrelationManager.StackNode).$h,"n":"_stack","d":175173,"h":8590109765,"f":2},{"t":240709,"n":"_stackWrapper","d":175173,"h":12885077061,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":175173,"h":17180044357,"f":8}],"j":[306245,240709],"h":175173}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.CorrelationManager`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.DiagnosticsConfiguration", ($self) => class DiagnosticsConfiguration
        {
            static /*bool */ get AutoFlush()
            {
                return false;
            }
            static /*bool */ get UseGlobalLock()
            {
                return true;
            }
            static /*int */ get IndentSize()
            {
                return 4;
            }
            static /*bool */ get AssertUIEnabled()
            {
                return true;
            }
            static /*string */ get LogFileName()
            {
                return $.$spc.System.String.Empty;
            }
            static $h = 437317;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590371909,"f":40},"n":"AutoFlush","d":437317,"h":4295404613,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":17180306501,"f":40},"n":"UseGlobalLock","d":437317,"h":12885339205,"f":40},{"p":655361,"g":{"r":0,"d":0,"h":25770241093,"f":40},"n":"IndentSize","d":437317,"h":21475273797,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":34360175685,"f":40},"n":"AssertUIEnabled","d":437317,"h":30065208389,"f":40},{"p":1310721,"g":{"r":0,"d":0,"h":42950110277,"f":40},"n":"LogFileName","d":437317,"h":38655142981,"f":40}],"h":437317}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.DiagnosticsConfiguration`; }
        });
        
        $asm.$cls("$sdts.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdts.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Diagnostics.TraceSource", $.$sdts.System.SR.$type.Assembly);
                    $.$sdts.System.SR.s_resourceManager = temp;
                }
                return $.$sdts.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdts.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdts.System.SR.resourceCulture = value;
            }
            static /*string */ get AttributeNotSupported()
            {
                return "'{0}' is not a valid attribute for type '{1}'.";
            }
            static /*string */ FormatAttributeNotSupported(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("'{0}' is not a valid attribute for type '{1}'.", arg1, arg2);
            }
            static /*string */ get ExceptionOccurred()
            {
                return "An exception occurred while writing to the log file {0}: {1}.";
            }
            static /*string */ FormatExceptionOccurred(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("An exception occurred while writing to the log file {0}: {1}.", arg1, arg2);
            }
            static /*string */ get MustAddListener()
            {
                return "Only TraceListeners can be added to a TraceListenerCollection.";
            }
            static /*string */ get TraceListenerFail()
            {
                return "Fail:";
            }
            static /*string */ get TraceListenerIndentSize()
            {
                return "The IndentSize property must be non-negative.";
            }
            static /*string */ get DebugAssertBanner()
            {
                return "---- DEBUG ASSERTION FAILED ----";
            }
            static /*string */ get DebugAssertShortMessage()
            {
                return "---- Assert Short Message ----";
            }
            static /*string */ get DebugAssertLongMessage()
            {
                return "---- Assert Long Message ----";
            }
            static /*string */ get TraceSwitchLevelTooLow()
            {
                return "Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off";
            }
            static /*string */ FormatTraceSwitchLevelTooLow(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Attempted to set {0} to a value that is too low.  Setting level to TraceLevel.Off", arg1);
            }
            static /*string */ get TraceSwitchInvalidLevel()
            {
                return "The Level must be set to a value in the enumeration TraceLevel.";
            }
            static /*string */ get TraceSwitchLevelTooHigh()
            {
                return "Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose";
            }
            static /*string */ FormatTraceSwitchLevelTooHigh(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Attempted to set {0} to a value that is too high.  Setting level to TraceLevel.Verbose", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdts.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdts.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdts.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdts.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdts.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdts.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdts.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1944645;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1944645}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceEventCache", ($self) => class TraceEventCache extends $.$spc.System.Object
        {
            /*long*/ _timeStamp = -1n;
            /*DateTime*/ _dateTime;
            /*DateTime */ get DateTime()
            {
                if ($.$spc.System.DateTime.op_Equality(this._dateTime, $.$spc.System.DateTime.MinValue))
                {
                    this._dateTime = $.$spc.System.DateTime.UtcNow;
                }
                return this._dateTime;
            }
            /*int */ get ProcessId()
            {
                return $.$spc.System.Environment.ProcessId;
            }
            /*string */ get ThreadId()
            {
                return $.$spc.System.Int32.ToString$2.call($.$spc.System.Environment.CurrentManagedThreadId, $.$spc.System.Globalization.CultureInfo.InvariantCulture);
            }
            /*long */ get Timestamp()
            {
                if (this._timeStamp === BigInt(-1))
                {
                    this._timeStamp = $.$spc.System.Diagnostics.Stopwatch.GetTimestamp();
                }
                return this._timeStamp;
            }
            /*string*/ Callstack$ = null;
            /*string */ get Callstack()
            {
                return this.Callstack$ ??= $.$spc.System.Environment.StackTrace;
            }
            /*Stack */ get LogicalOperationStack()
            {
                return $.$sdts.System.Diagnostics.Trace.CorrelationManager.LogicalOperationStack;
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dateTime = $.$spc.System.DateTime.MinValue;
            }
            static $h = 1158213;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":34144257,"g":{"r":0,"d":0,"h":17181027397,"f":1},"n":"DateTime","d":1158213,"h":12886060101,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770961989,"f":1},"n":"ProcessId","d":1158213,"h":21475994693,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":34360896581,"f":1},"n":"ThreadId","d":1158213,"h":30065929285,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":42950831173,"f":1},"n":"Timestamp","d":1158213,"h":38655863877,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55835733061,"f":1},"n":"Callstack","d":1158213,"h":51540765765,"f":1},{"p":1048611,"g":{"r":0,"d":0,"h":64425667653,"f":1},"n":"LogicalOperationStack","d":1158213,"h":60130700357,"f":1}],"l":[{"t":917505,"n":"_timeStamp","d":1158213,"h":4296125509,"f":2},{"t":34144257,"n":"_dateTime","d":1158213,"h":8591092805,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1158213,"h":68720634949,"f":1}],"h":1158213}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceEventCache`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.Trace", ($self) => class Trace extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*CorrelationManager*/ static CorrelationManager$ = null;
            static /*CorrelationManager */ get CorrelationManager()
            {
                return $.$sdts.System.Diagnostics.Trace.CorrelationManager$ ?? $.$spc.System.Threading.Interlocked.CompareExchange$14($.$sdts.System.Diagnostics.CorrelationManager, $.$ref(() => $.$sdts.System.Diagnostics.Trace.CorrelationManager$, ($v) => $.$sdts.System.Diagnostics.Trace.CorrelationManager$ = $v, $.$sdts.System.Diagnostics.CorrelationManager), new $.$sdts.System.Diagnostics.CorrelationManager().$ctor$1(), null) ?? $.$sdts.System.Diagnostics.Trace.CorrelationManager$;
            }
            static /*TraceListenerCollection */ get Listeners()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.Listeners;
            }
            static /*bool */ get AutoFlush()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.AutoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.AutoFlush = value;
            }
            static /*bool */ get UseGlobalLock()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock = value;
            }
            static /*int */ get IndentLevel()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.IndentLevel = value;
            }
            static /*int */ get IndentSize()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.IndentSize = value;
            }
            static /*void */ Flush()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Flush();
            }
            static /*void */ Close()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Close();
            }
            static /*void */ Assert(/*bool*/ condition)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert(condition);
            }
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert$1(condition, message);
            }
            static /*void */ Assert$2(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Assert$2(condition, message, detailMessage);
            }
            static /*void */ Fail(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Fail(message);
            }
            static /*void */ Fail$1(/*string?*/ message, /*string?*/ detailMessage)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Fail$1(message, detailMessage);
            }
            /*EventHandler?*/ static Refreshing = null;
            static add_Refreshing(/*EventHandler?*/ value)
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing = $.$spc.System.Delegate.Combine($.$sdts.System.Diagnostics.Trace.Refreshing, value);
            }
            static remove_Refreshing(/*EventHandler?*/ value)
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing = $.$spc.System.Delegate.Remove($.$sdts.System.Diagnostics.Trace.Refreshing, value);
            }
            static /*void */ OnRefreshing()
            {
                $.$sdts.System.Diagnostics.Trace.Refreshing?.Invoke(null, $.$spc.System.EventArgs.Empty);
            }
            static /*void */ Refresh()
            {
                $.$sdts.System.Diagnostics.Trace.OnRefreshing();
                $.$sdts.System.Diagnostics.Switch.RefreshAll();
                $.$sdts.System.Diagnostics.TraceSource.RefreshAll();
                $.$sdts.System.Diagnostics.TraceInternal.Refresh();
            }
            static /*void */ TraceInformation(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, message, null);
            }
            static /*void */ TraceInformation$1(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(8/*TraceEventType.Information*/, 0, format, args);
            }
            static /*void */ TraceWarning(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, message, null);
            }
            static /*void */ TraceWarning$1(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(4/*TraceEventType.Warning*/, 0, format, args);
            }
            static /*void */ TraceError(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, message, null);
            }
            static /*void */ TraceError$1(/*string*/ format, /*params object?[]?*/ args)
            {
                $.$sdts.System.Diagnostics.TraceInternal.TraceEvent(2/*TraceEventType.Error*/, 0, format, args);
            }
            static /*void */ Write(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write(message);
            }
            static /*void */ Write$1(/*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$1(value);
            }
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$2(message, category);
            }
            static /*void */ Write$3(/*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.Write$3(value, category);
            }
            static /*void */ WriteLine(/*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine(message);
            }
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$1(value);
            }
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$2(message, category);
            }
            static /*void */ WriteLine$3(/*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLine$3(value, category);
            }
            static /*void */ WriteIf(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf(condition, message);
            }
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$1(condition, value);
            }
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$2(condition, message, category);
            }
            static /*void */ WriteIf$3(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteIf$3(condition, value, category);
            }
            static /*void */ WriteLineIf(/*bool*/ condition, /*string?*/ message)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf(condition, message);
            }
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$1(condition, value);
            }
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$2(condition, message, category);
            }
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                $.$sdts.System.Diagnostics.TraceInternal.WriteLineIf$3(condition, value, category);
            }
            static /*void */ Indent()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Indent();
            }
            static /*void */ Unindent()
            {
                $.$sdts.System.Diagnostics.TraceInternal.Unindent();
            }
            static $h = 1092677;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":175173,"g":{"r":0,"d":0,"h":17180961861,"f":33},"n":"CorrelationManager","d":1092677,"h":12885994565,"f":33},{"p":1616965,"g":{"r":0,"d":0,"h":25770896453,"f":33},"n":"Listeners","d":1092677,"h":21475929157,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":34360831045,"f":33},"s":{"r":0,"d":0,"h":38655798341,"f":33},"n":"AutoFlush","d":1092677,"h":30065863749,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":47245732933,"f":33},"s":{"r":0,"d":0,"h":51540700229,"f":33},"n":"UseGlobalLock","d":1092677,"h":42950765637,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":60130634821,"f":33},"s":{"r":0,"d":0,"h":64425602117,"f":33},"n":"IndentLevel","d":1092677,"h":55835667525,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":73015536709,"f":33},"s":{"r":0,"d":0,"h":77310504005,"f":33},"n":"IndentSize","d":1092677,"h":68720569413,"f":33}],"m":[{"r":65537,"n":"Flush","d":1092677,"h":81605471301,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Close","d":1092677,"h":85900438597,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145}],"n":"Assert","d":1092677,"h":90195405893,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]},{"t":93978625,"c":4388945921,"a":[{"v":-1,"t":655361}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721,"f":65,"a":[{"t":87949313,"c":4382916609,"a":[{"v":"condition","t":1310721}]}]}],"n":"Assert","o":"@$1","d":1092677,"h":94490373189,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Assert","o":"@$2","d":1092677,"h":98785340485,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","d":1092677,"h":103080307781,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","o":"@$1","d":1092677,"h":107375275077,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"OnRefreshing","d":1092677,"h":124555144261,"f":40},{"r":65537,"n":"Refresh","d":1092677,"h":128850111557,"f":33},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceInformation","d":1092677,"h":133145078853,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceInformation","o":"@$1","d":1092677,"h":137440046149,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceWarning","d":1092677,"h":141735013445,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceWarning","o":"@$1","d":1092677,"h":146029980741,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceError","d":1092677,"h":150324948037,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceError","o":"@$1","d":1092677,"h":154619915333,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":1092677,"h":158914882629,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Write","o":"@$1","d":1092677,"h":163209849925,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1092677,"h":167504817221,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"Write","o":"@$3","d":1092677,"h":171799784517,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":1092677,"h":176094751813,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073}],"n":"WriteLine","o":"@$1","d":1092677,"h":180389719109,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1092677,"h":184684686405,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$3","d":1092677,"h":188979653701,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteIf","d":1092677,"h":193274620997,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteIf","o":"@$1","d":1092677,"h":197569588293,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$2","d":1092677,"h":201864555589,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$3","d":1092677,"h":206159522885,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteLineIf","d":1092677,"h":210454490181,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteLineIf","o":"@$1","d":1092677,"h":214749457477,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$2","d":1092677,"h":219044424773,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$3","d":1092677,"h":223339392069,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Indent","d":1092677,"h":227634359365,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"n":"Unindent","d":1092677,"h":231929326661,"f":33,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1092677,"h":4296059973,"f":2}],"e":[{"e":46989313,"m":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"add_Refreshing","d":1092677,"h":111670242373,"f":33},"r":{"r":65537,"p":[{"n":"value","p":46989313}],"n":"remove_Refreshing","d":1092677,"h":115965209669,"f":33},"n":"Refreshing","d":1092677,"h":120260176965,"f":33}],"h":1092677}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.Trace`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceInternal", ($self) => class TraceInternal
        {
            static $_TraceProvider;
            static get TraceProvider()
            {
                let $cls = $.$sdts.System.Diagnostics.TraceInternal;
                return $cls.$_TraceProvider ??= $asm.$ncls("$sdts.System.Diagnostics.TraceInternal.TraceProvider", ($self) => class TraceProvider extends $.$spc.System.Diagnostics.DebugProvider
                {
                    /*void */ Fail(/*string?*/ message, /*string?*/ detailMessage)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.Fail$1(message, detailMessage);
                    }
                    /*void */ OnIndentLevelChanged(/*int*/ indentLevel)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.IndentLevel = indentLevel;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    /*void */ OnIndentSizeChanged(/*int*/ indentSize)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.IndentSize = indentSize;
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    /*void */ Write(/*string?*/ message)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.Write(message);
                    }
                    /*void */ WriteLine(/*string?*/ message)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.WriteLine(message);
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 1420357;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":38010881,"m":[{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","d":1420357,"h":4296387653,"f":32769},{"r":65537,"p":[{"n":"indentLevel","p":655361}],"n":"OnIndentLevelChanged","d":1420357,"h":8591354949,"f":32769},{"r":65537,"p":[{"n":"indentSize","p":655361}],"n":"OnIndentSizeChanged","d":1420357,"h":12886322245,"f":32769},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":1420357,"h":17181289541,"f":32769},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":1420357,"h":21476256837,"f":32769}],"c":[{"n":".ctor","o":"$ctor$2","d":1420357,"h":25771224133,"f":1}],"d":1354821,"h":1420357}; }
                    static get $b() { return $.$spc.System.Diagnostics.DebugProvider; }
                    static get $fullName() { return `System.Diagnostics.TraceInternal.TraceProvider`; }
                }, $cls, ($v) => $cls.$_TraceProvider = $v);
            }
            /*TraceListenerCollection?*/ static s_listeners = null;
            /*bool*/ static s_autoFlush = false;
            /*bool*/ static s_useGlobalLock = false;
            /*bool*/ static s_settingsInitialized = false;
            /*bool*/ static s_settingsInitializing = false;
            /*object*/ static critSec = null;
            static /*TraceListenerCollection */ get Listeners()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners === null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners === null)
                            {
                                $.$spc.System.Diagnostics.Debug.SetProvider(new $.$sdts.System.Diagnostics.TraceInternal.TraceProvider().$ctor$2());
                                $.$sdts.System.Diagnostics.TraceInternal.s_listeners = new $.$sdts.System.Diagnostics.TraceListenerCollection().$ctor$1();
                                /*TraceListener*/ let defaultListener = new $.$sdts.System.Diagnostics.DefaultTraceListener().$ctor$4();
                                defaultListener.IndentLevel = $.$spc.System.Diagnostics.Debug.IndentLevel;
                                defaultListener.IndentSize = $.$spc.System.Diagnostics.Debug.IndentSize;
                                $.$sdts.System.Diagnostics.TraceInternal.s_listeners.Add(defaultListener);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                return $.$sdts.System.Diagnostics.TraceInternal.s_listeners;
            }
            /*string*/ static AppName$ = null;
            static /*string */ get AppName()
            {
                return $.$sdts.System.Diagnostics.TraceInternal.AppName$ ??= ($.$spc.System.Reflection.Assembly.GetEntryAssembly()?.GetName().Name ?? null) ?? $.$spc.System.String.Empty;
            }
            static /*bool */ get AutoFlush()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                return $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush;
            }
            static /*bool */ set AutoFlush(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush = value;
            }
            static /*bool */ get UseGlobalLock()
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                return $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock;
            }
            static /*bool */ set UseGlobalLock(value)
            {
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
                $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock = value;
            }
            static /*int */ get IndentLevel()
            {
                return $.$spc.System.Diagnostics.Debug.IndentLevel;
            }
            static /*int */ set IndentLevel(value)
            {
                $.$spc.System.Diagnostics.Debug.IndentLevel = value;
            }
            static /*int */ get IndentSize()
            {
                return $.$spc.System.Diagnostics.Debug.IndentSize;
            }
            static /*int */ set IndentSize(value)
            {
                $.$spc.System.Diagnostics.Debug.IndentSize = value;
            }
            static /*void */ Indent()
            {
                $.$spc.System.Diagnostics.Debug.IndentLevel++;
            }
            static /*void */ Unindent()
            {
                $.$spc.System.Diagnostics.Debug.IndentLevel--;
            }
            static /*void */ Flush()
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var listener = $en4.Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Close()
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.s_listeners !== null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            static /*void */ Assert(/*bool*/ condition)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail($.$spc.System.String.Empty);
            }
            static /*void */ Assert$1(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail(message);
            }
            static /*void */ Assert$2(/*bool*/ condition, /*string?*/ message, /*string?*/ detailMessage)
            {
                if (condition)
                {
                    return;
                }
                $.$sdts.System.Diagnostics.TraceInternal.Fail$1(message, detailMessage);
            }
            static /*void */ Fail(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Fail(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Fail(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Fail$1(/*string?*/ message, /*string?*/ detailMessage)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Fail$1(message, detailMessage);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Fail$1(message, detailMessage);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Fail$1(message, detailMessage);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ InitializeSettings()
            {
                if (!$.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if ($.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing)
                            {
                                return;
                            }
                            $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing = true;
                            if (!$.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized)
                            {
                                $.$sdts.System.Diagnostics.TraceInternal.s_autoFlush = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.AutoFlush;
                                $.$sdts.System.Diagnostics.TraceInternal.s_useGlobalLock = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.UseGlobalLock;
                                $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized = true;
                                $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitializing = false;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            static /*void */ Refresh()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        $.$sdts.System.Diagnostics.TraceInternal.s_settingsInitialized = false;
                        $.$sdts.System.Diagnostics.TraceInternal.s_listeners = null;
                        $.$spc.System.Diagnostics.Debug.IndentSize = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.IndentSize;
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
                $.$sdts.System.Diagnostics.TraceInternal.InitializeSettings();
            }
            static /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                /*TraceEventCache*/ let EventCache = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            if (args === null)
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                            else 
                            {
                                var $en6 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.TraceEvent$2(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    if (args === null)
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var listener = $en4.Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(listener)
                                        {
                                            listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                            if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent$1(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    else 
                    {
                        var $en4 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var listener = $en4.Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(listener)
                                        {
                                            listener.TraceEvent$2(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                            if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                            {
                                                listener.Flush();
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.TraceEvent$2(EventCache, $.$sdts.System.Diagnostics.TraceInternal.AppName, eventType, id, format, args);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Write(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Write(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$1(/*object?*/ value)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Write$1(value);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Write$1(value);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$1(value);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$2(/*string?*/ message, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Write$2(message, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Write$2(message, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$2(message, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ Write$3(/*object?*/ value, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Write$3(value, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.Write$3(value, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.Write$3(value, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine(/*string?*/ message)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.WriteLine(message);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.WriteLine(message);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine(message);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$1(/*object?*/ value)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.WriteLine$1(value);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.WriteLine$1(value);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$1(value);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$2(/*string?*/ message, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.WriteLine$2(message, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.WriteLine$2(message, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$2(message, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteLine$3(/*object?*/ value, /*string?*/ category)
            {
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.WriteLine$3(value, category);
                                    if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = $.$sdts.System.Diagnostics.TraceInternal.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.WriteLine$3(value, category);
                                        if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.WriteLine$3(value, category);
                                if ($.$sdts.System.Diagnostics.TraceInternal.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            static /*void */ WriteIf(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write(message);
                }
            }
            static /*void */ WriteIf$1(/*bool*/ condition, /*object?*/ value)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$1(value);
                }
            }
            static /*void */ WriteIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$2(message, category);
                }
            }
            static /*void */ WriteIf$3(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.Write$3(value, category);
                }
            }
            static /*void */ WriteLineIf(/*bool*/ condition, /*string?*/ message)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine(message);
                }
            }
            static /*void */ WriteLineIf$1(/*bool*/ condition, /*object?*/ value)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$1(value);
                }
            }
            static /*void */ WriteLineIf$2(/*bool*/ condition, /*string?*/ message, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$2(message, category);
                }
            }
            static /*void */ WriteLineIf$3(/*bool*/ condition, /*object?*/ value, /*string?*/ category)
            {
                if (condition)
                {
                    $.$sdts.System.Diagnostics.TraceInternal.WriteLine$3(value, category);
                }
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.critSec = new $.$spc.System.Object().$ctor();
                }
            }
            static $h = 1354821;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1616965,"g":{"r":0,"d":0,"h":38656060485,"f":33},"n":"Listeners","d":1354821,"h":34361093189,"f":33},{"p":1310721,"g":{"r":0,"d":0,"h":51540962373,"f":40},"n":"AppName","d":1354821,"h":47245995077,"f":40},{"p":262145,"g":{"r":0,"d":0,"h":60130896965,"f":33},"s":{"r":0,"d":0,"h":64425864261,"f":33},"n":"AutoFlush","d":1354821,"h":55835929669,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":73015798853,"f":33},"s":{"r":0,"d":0,"h":77310766149,"f":33},"n":"UseGlobalLock","d":1354821,"h":68720831557,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":85900700741,"f":33},"s":{"r":0,"d":0,"h":90195668037,"f":33},"n":"IndentLevel","d":1354821,"h":81605733445,"f":33},{"p":655361,"g":{"r":0,"d":0,"h":98785602629,"f":33},"s":{"r":0,"d":0,"h":103080569925,"f":33},"n":"IndentSize","d":1354821,"h":94490635333,"f":33}],"m":[{"r":65537,"n":"Indent","d":1354821,"h":107375537221,"f":33},{"r":65537,"n":"Unindent","d":1354821,"h":111670504517,"f":33},{"r":65537,"n":"Flush","d":1354821,"h":115965471813,"f":33},{"r":65537,"n":"Close","d":1354821,"h":120260439109,"f":33},{"r":65537,"p":[{"n":"condition","p":262145}],"n":"Assert","d":1354821,"h":124555406405,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"Assert","o":"@$1","d":1354821,"h":128850373701,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Assert","o":"@$2","d":1354821,"h":133145340997,"f":33},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","d":1354821,"h":137440308293,"f":33},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","o":"@$1","d":1354821,"h":141735275589,"f":33},{"r":65537,"n":"InitializeSettings","d":1354821,"h":146030242885,"f":34},{"r":65537,"n":"Refresh","d":1354821,"h":150325210181,"f":40},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceEvent","d":1354821,"h":154620177477,"f":33},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":1354821,"h":158915144773,"f":33},{"r":65537,"p":[{"n":"value","p":131073}],"n":"Write","o":"@$1","d":1354821,"h":163210112069,"f":33},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"Write","o":"@$2","d":1354821,"h":167505079365,"f":33},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"Write","o":"@$3","d":1354821,"h":171800046661,"f":33},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":1354821,"h":176095013957,"f":33},{"r":65537,"p":[{"n":"value","p":131073}],"n":"WriteLine","o":"@$1","d":1354821,"h":180389981253,"f":33},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$2","d":1354821,"h":184684948549,"f":33},{"r":65537,"p":[{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLine","o":"@$3","d":1354821,"h":188979915845,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteIf","d":1354821,"h":193274883141,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteIf","o":"@$1","d":1354821,"h":197569850437,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$2","d":1354821,"h":201864817733,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteIf","o":"@$3","d":1354821,"h":206159785029,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721}],"n":"WriteLineIf","d":1354821,"h":210454752325,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073}],"n":"WriteLineIf","o":"@$1","d":1354821,"h":214749719621,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"message","p":1310721},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$2","d":1354821,"h":219044686917,"f":33},{"r":65537,"p":[{"n":"condition","p":262145},{"n":"value","p":131073},{"n":"category","p":1310721}],"n":"WriteLineIf","o":"@$3","d":1354821,"h":223339654213,"f":33}],"l":[{"t":1616965,"n":"s_listeners","d":1354821,"h":8591289413,"f":34},{"t":262145,"n":"s_autoFlush","d":1354821,"h":12886256709,"f":34},{"t":262145,"n":"s_useGlobalLock","d":1354821,"h":17181224005,"f":34},{"t":262145,"n":"s_settingsInitialized","d":1354821,"h":21476191301,"f":34},{"t":262145,"n":"s_settingsInitializing","d":1354821,"h":25771158597,"f":34},{"t":131073,"n":"critSec","d":1354821,"h":30066125893,"f":40}],"j":[1420357],"h":1354821}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceInternal`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceSource", ($self) => class TraceSource extends $.$spc.System.Object
        {
            /*List<WeakReference<TraceSource>>*/ static s_tracesources = null;
            /*int*/ static s_LastCollectionCount = 0;
            /*SourceSwitch?*/ _internalSwitch = null;
            /*TraceListenerCollection?*/ _listeners = null;
            /*SourceLevels*/ _switchLevel = 0;
            /*string*/ _sourceName = null;
            /*bool*/ _initCalled = false;
            /*bool*/ _configInitializing = false;
            /*StringDictionary?*/ _attributes = null;
            $ctor$1(/*string*/ name)
            {
                this.$ctor$2(name, 0/*SourceLevels.Off*/);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*SourceLevels*/ defaultLevel)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(name, "name");
                    this._sourceName = name;
                    this._switchLevel = defaultLevel;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                        {
                            $.$sdts.System.Diagnostics.TraceSource._pruneCachedTraceSources();
                            $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Add(new ($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource))().$ctor$1(this));
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    }
                }
                return this;
            }
            static /*void */ _pruneCachedTraceSources()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    {
                        if ($.$sdts.System.Diagnostics.TraceSource.s_LastCollectionCount !== $.$spc.System.GC.CollectionCount(2))
                        {
                            /*List<WeakReference<TraceSource>>*/ let buffer = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)))().$ctor$2($.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count);
                            for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count; i++)
                            {
                                if ($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$discardRef()))
                                {
                                    buffer.Add($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i));
                                }
                            }
                            if (buffer.Count < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count)
                            {
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Clear();
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.AddRange(buffer);
                                $.$sdts.System.Diagnostics.TraceSource.s_tracesources.TrimExcess();
                            }
                            $.$sdts.System.Diagnostics.TraceSource.s_LastCollectionCount = $.$spc.System.GC.CollectionCount(2);
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                }
            }
            /*void */ Initialize()
            {
                if (!this._initCalled)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this)
                        {
                            if (this._initCalled)
                            {
                                return;
                            }
                            if (this._configInitializing)
                            {
                                return;
                            }
                            this._configInitializing = true;
                            NoConfigInit_BeforeEvent.call(this);
                            /*InitializingTraceSourceEventArgs*/ let e = new $.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs().$ctor$2(this);
                            this.OnInitializing(e);
                            if (!e.WasInitialized)
                            {
                                NoConfigInit_AfterEvent.call(this);
                            }
                            this._configInitializing = false;
                            this._initCalled = true;
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this)
                    }
                }
                /*void*/  function NoConfigInit_BeforeEvent()
                {
                    this._listeners = new $.$sdts.System.Diagnostics.TraceListenerCollection().$ctor$1();
                    this._internalSwitch = new $.$sdts.System.Diagnostics.SourceSwitch().$ctor$4(this._sourceName, $.$spc.System.Enum.ToStringT($.$sdts.System.Diagnostics.SourceLevels, $.$spc.System.UInt32, this._switchLevel));
                }
                /*void*/  function NoConfigInit_AfterEvent()
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._listeners !== null, "_listeners != null");
                    this._listeners.Add(new $.$sdts.System.Diagnostics.DefaultTraceListener().$ctor$4());
                }
            }
            /*void */ Close()
            {
                if (this._listeners !== null)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = this._listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    listener.Close();
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
            }
            /*void */ Flush()
            {
                if (this._listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                var $en6 = this._listeners.GetEnumerator();
                                while ($en6.MoveNext())
                                {
                                    var listener = $en6.Current;
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        var $en4 = this._listeners.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var listener = $en4.Current;
                            {
                                if (!listener.IsThreadSafe)
                                {
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(listener)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(listener)
                                    }
                                }
                                else 
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*string[]? */ GetSupportedAttributes()
            {
                return null;
            }
            static /*void */ RefreshAll()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                    {
                        $.$sdts.System.Diagnostics.TraceSource._pruneCachedTraceSources();
                        for(/*int*/ let i = 0; i < $.$sdts.System.Diagnostics.TraceSource.s_tracesources.Count; i++)
                        {
                            /*TraceSource?*/ let tracesource;
                            if ($.$sdts.System.Diagnostics.TraceSource.s_tracesources.get_Item(i).TryGetTarget($.$ref(() => tracesource, ($v) => tracesource = $v, $.$sdts.System.Diagnostics.TraceSource)))
                            {
                                tracesource.Refresh();
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceSource.s_tracesources)
                }
            }
            /*void */ Refresh()
            {
                if (!this._initCalled)
                {
                    this.Initialize();
                    return;
                }
                this.OnInitializing(new $.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs().$ctor$2(this));
            }
            /*void */ TraceEvent(/*TraceEventType*/ eventType, /*int*/ id)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent(manager, this.Name, eventType, id);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceEvent(manager, this.Name, eventType, id);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent(manager, this.Name, eventType, id);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceEvent$1(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ message)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$1(manager, this.Name, eventType, id, message);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceEvent$2(/*TraceEventType*/ eventType, /*int*/ id, /*string?*/ format, /*params object?[]?*/ args)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceEvent$2(manager, this.Name, eventType, id, format, args);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceEvent$2(manager, this.Name, eventType, id, format, args);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceEvent$2(manager, this.Name, eventType, id, format, args);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceData(/*TraceEventType*/ eventType, /*int*/ id, /*object?*/ data)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceData(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceData(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData(manager, this.Name, eventType, id, data);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceData$1(/*TraceEventType*/ eventType, /*int*/ id, /*params object?[]?*/ data)
            {
                this.Initialize();
                if (this._internalSwitch.ShouldTrace(eventType) && this._listeners !== null)
                {
                    /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceData$1(manager, this.Name, eventType, id, data);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceData$1(manager, this.Name, eventType, id, data);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceData$1(manager, this.Name, eventType, id, data);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*void */ TraceInformation(/*string?*/ message)
            {
                ;
            }
            /*void */ TraceInformation$1(/*string?*/ format, /*params object?[]?*/ args)
            {
                ;
            }
            /*void */ TraceTransfer(/*int*/ id, /*string?*/ message, /*Guid*/ relatedActivityId)
            {
                this.Initialize();
                /*TraceEventCache*/ let manager = new $.$sdts.System.Diagnostics.TraceEventCache().$ctor$1();
                if (this._internalSwitch.ShouldTrace(4096/*TraceEventType.Transfer*/) && this._listeners !== null)
                {
                    if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                            {
                                for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                                {
                                    /*TraceListener*/ let listener = this._listeners.get_Item(i);
                                    listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                    if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                    {
                                        listener.Flush();
                                    }
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        }
                    }
                    else 
                    {
                        for(/*int*/ let i = 0; i < this._listeners.Count; i++)
                        {
                            /*TraceListener*/ let listener = this._listeners.get_Item(i);
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                        if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                        {
                                            listener.Flush();
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                listener.TraceTransfer(manager, this.Name, id, message, relatedActivityId);
                                if ($.$sdts.System.Diagnostics.Trace.AutoFlush)
                                {
                                    listener.Flush();
                                }
                            }
                        }
                    }
                }
            }
            /*StringDictionary */ get Attributes()
            {
                this.Initialize();
                return this._attributes ??= new $.$scs.System.Collections.Specialized.StringDictionary().$ctor$1();
            }
            /*SourceLevels */ get DefaultLevel()
            {
                return this._switchLevel;
            }
            /*EventHandler<InitializingTraceSourceEventArgs>?*/ static Initializing = null;
            static add_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing = $.$spc.System.Delegate.Combine($.$sdts.System.Diagnostics.TraceSource.Initializing, value);
            }
            static remove_Initializing(/*EventHandler<InitializingTraceSourceEventArgs>?*/ value)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing = $.$spc.System.Delegate.Remove($.$sdts.System.Diagnostics.TraceSource.Initializing, value);
            }
            /*void */ OnInitializing(/*InitializingTraceSourceEventArgs*/ e)
            {
                $.$sdts.System.Diagnostics.TraceSource.Initializing?.Invoke(this, e);
                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(this.Attributes, this.GetSupportedAttributes(), this);
                if ($.$sdts.System.Diagnostics.TraceInternal.UseGlobalLock)
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                        {
                            var $en5 = this.Listeners.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var listener = $en5.Current;
                                {
                                    $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    }
                }
                else 
                {
                    var $en3 = this.Listeners.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var listener = $en3.Current;
                        {
                            if (!listener.IsThreadSafe)
                            {
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(listener)
                                    {
                                        $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(listener)
                                }
                            }
                            else 
                            {
                                $.$sdts.System.Diagnostics.TraceUtils.VerifyAttributes(listener.Attributes, listener.GetSupportedAttributes(), this);
                            }
                        }
                    }
                }
            }
            /*string */ get Name()
            {
                return this._sourceName;
            }
            /*TraceListenerCollection */ get Listeners()
            {
                this.Initialize();
                return this._listeners;
            }
            /*SourceSwitch */ get Switch()
            {
                this.Initialize();
                return this._internalSwitch;
            }
            /*SourceSwitch */ set Switch(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "Switch");
                this.Initialize();
                this._internalSwitch = value;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_tracesources = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)))().$ctor$1();
                }
            }
            static $h = 1748037;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310756,"g":{"r":0,"d":0,"h":120260832325,"f":1},"n":"Attributes","d":1748037,"h":115965865029,"f":1},{"p":764997,"g":{"r":0,"d":0,"h":128850766917,"f":1},"n":"DefaultLevel","d":1748037,"h":124555799621,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":154620570693,"f":1},"n":"Name","d":1748037,"h":150325603397,"f":1},{"p":1616965,"g":{"r":0,"d":0,"h":163210505285,"f":1},"n":"Listeners","d":1748037,"h":158915537989,"f":1},{"p":830533,"g":{"r":0,"d":0,"h":171800439877,"f":1},"s":{"r":0,"d":0,"h":176095407173,"f":1},"n":"Switch","d":1748037,"h":167505472581,"f":1}],"m":[{"r":65537,"n":"_pruneCachedTraceSources","d":1748037,"h":51541355589,"f":34},{"r":65537,"n":"Initialize","d":1748037,"h":55836322885,"f":2},{"r":65537,"n":"Close","d":1748037,"h":60131290181,"f":1},{"r":65537,"n":"Flush","d":1748037,"h":64426257477,"f":1},{"r":0,"n":"GetSupportedAttributes","d":1748037,"h":68721224773,"f":144},{"r":65537,"n":"RefreshAll","d":1748037,"h":73016192069,"f":40},{"r":65537,"n":"Refresh","d":1748037,"h":77311159365,"f":8},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361}],"n":"TraceEvent","d":1748037,"h":81606126661,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"message","p":1310721}],"n":"TraceEvent","o":"@$1","d":1748037,"h":85901093957,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceEvent","o":"@$2","d":1748037,"h":90196061253,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"data","p":131073}],"n":"TraceData","d":1748037,"h":94491028549,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"data","p":0,"f":16}],"n":"TraceData","o":"@$1","d":1748037,"h":98785995845,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"TraceInformation","d":1748037,"h":103080963141,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"format","p":1310721},{"n":"args","p":0,"f":16}],"n":"TraceInformation","o":"@$1","d":1748037,"h":107375930437,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"id","p":655361},{"n":"message","p":1310721},{"n":"relatedActivityId","p":56164353}],"n":"TraceTransfer","d":1748037,"h":111670897733,"f":1,"a":[{"t":35913729,"c":4330881025,"a":[{"v":"TRACE","t":1310721}]}]},{"r":65537,"p":[{"n":"e","p":633925}],"n":"OnInitializing","d":1748037,"h":146030636101,"f":8}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$spc.System.WeakReference$$($.$sdts.System.Diagnostics.TraceSource)).$h,"n":"s_tracesources","d":1748037,"h":4296715333,"f":34},{"t":655361,"n":"s_LastCollectionCount","d":1748037,"h":8591682629,"f":34},{"t":830533,"n":"_internalSwitch","d":1748037,"h":12886649925,"f":2},{"t":1616965,"n":"_listeners","d":1748037,"h":17181617221,"f":2},{"t":764997,"n":"_switchLevel","d":1748037,"h":21476584517,"f":2},{"t":1310721,"n":"_sourceName","d":1748037,"h":25771551813,"f":2},{"t":262145,"n":"_initCalled","d":1748037,"h":30066519109,"f":8},{"t":262145,"n":"_configInitializing","d":1748037,"h":34361486405,"f":8},{"t":1310756,"n":"_attributes","d":1748037,"h":38656453701,"f":2}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$1","d":1748037,"h":42951420997,"f":1},{"p":[{"n":"name","p":1310721},{"n":"defaultLevel","p":764997}],"n":".ctor","o":"$ctor$2","d":1748037,"h":47246388293,"f":1}],"e":[{"e":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h}],"n":"add_Initializing","d":1748037,"h":133145734213,"f":33},"r":{"r":65537,"p":[{"n":"value","p":$.$spc.System.EventHandler$$($.$sdts.System.Diagnostics.InitializingTraceSourceEventArgs).$h}],"n":"remove_Initializing","d":1748037,"h":137440701509,"f":33},"n":"Initializing","d":1748037,"h":141735668805,"f":33}],"h":1748037}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceSource`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceUtils", ($self) => class TraceUtils
        {
            static /*void */ VerifyAttributes(/*StringDictionary?*/ attributes, /*string[]?*/ supportedAttributes, /*object*/ parent)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(attributes, "attributes");
                var $en2 = attributes.Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (supportedAttributes === null || !$.$spc.System.MemoryExtensions.Contains$1($.$spc.System.String, $.$spc.System.ReadOnlySpan$$($.$spc.System.String).op_Implicit(supportedAttributes), key))
                        {
                            throw new $.$spc.System.ArgumentException().$ctor$10($.$sdts.System.SR.Format$1($.$sdts.System.SR.AttributeNotSupported, key, $.$spc.System.Object.GetType.call(parent).FullName));
                        }
                    }
                }
            }
            static $h = 1879109;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"attributes","p":1310756},{"n":"supportedAttributes","p":0},{"n":"parent","p":131073}],"n":"VerifyAttributes","d":1879109,"h":4296846405,"f":40}],"h":1879109}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Diagnostics.TraceUtils`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceListenerCollection", ($self) => class TraceListenerCollection extends $.$spc.System.Object
        {
            /*List<TraceListener?>*/ _list = null;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._list = new ($.$spc.System.Collections.Generic.List$$($.$sdts.System.Diagnostics.TraceListener))().$ctor$2(1);
                }
                return this;
            }
            /*TraceListener*/ get_Item(/*int*/ i)
            {
                return this._list.get_Item(i);
            }
            /*void*/ set_Item(/*int*/ i, /*TraceListener*/ value)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(value);
                this._list.set_Item(i, value);
            }
            /*TraceListener?*/ get_Item$1(/*string*/ name)
            {
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var listener = $en2.Current;
                    {
                        if ($.$spc.System.String.op_Equality(listener.Name, name))
                        {
                            return listener;
                        }
                    }
                }
                return null;
            }
            /*int */ get Count()
            {
                return this._list.Count;
            }
            /*int */ Add(/*TraceListener*/ listener)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        return (this._list).System$Collections$IList$Add(listener);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ AddRange(/*TraceListener[]*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                for(/*int*/ let i = 0; (i) < (value.length); i = ((((i) + (1)) | 0)))
                {
                    this.Add($.$spc.System.Array.$ReadT1.call(value, i));
                }
            }
            /*void */ AddRange$1(/*TraceListenerCollection*/ value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                /*int*/ let currentCount = value.Count;
                for(/*int*/ let i = 0; i < currentCount; i = ((((i) + (1)) | 0)))
                {
                    this.Add(value.get_Item(i));
                }
            }
            /*void */ Clear()
            {
                this._list.Clear();
            }
            /*bool */ Contains(/*TraceListener?*/ listener)
            {
                return (this).System$Collections$IList$Contains(listener);
            }
            /*void */ CopyTo(/*TraceListener[]*/ listeners, /*int*/ index)
            {
                (this).System$Collections$ICollection$CopyTo(listeners, index);
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this._list.GetEnumerator();
            }
            static /*void */ InitializeListener(/*TraceListener*/ listener)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(listener, "listener");
                listener.IndentSize = $.$sdts.System.Diagnostics.TraceInternal.IndentSize;
                listener.IndentLevel = $.$sdts.System.Diagnostics.TraceInternal.IndentLevel;
            }
            /*int */ IndexOf(/*TraceListener?*/ listener)
            {
                return (this).System$Collections$IList$IndexOf(listener);
            }
            /*void */ Insert(/*int*/ index, /*TraceListener*/ listener)
            {
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Insert(index, listener);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ Remove(/*TraceListener?*/ listener)
            {
                (this).System$Collections$IList$Remove(listener);
            }
            /*void */ Remove$1(/*string*/ name)
            {
                /*TraceListener?*/ let listener = this.get_Item$1(name);
                if (listener !== null)
                {
                    (this).System$Collections$IList$Remove(listener);
                }
            }
            /*void */ RemoveAt(/*int*/ index)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.RemoveAt(index);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*object?*/ System$Collections$IList$get_Item(/*int*/ index)
            {
                return this._list.get_Item(index);
            }
            /*void*/ System$Collections$IList$set_Item(/*int*/ index, /*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                this._list.set_Item(index, listener);
            }
            /*bool */ get System$Collections$IList$IsReadOnly()
            {
                return false;
            }
            /*bool */ get System$Collections$IList$IsFixedSize()
            {
                return false;
            }
            /*int */ System$Collections$IList$Add(/*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        return (this._list).System$Collections$IList$Add(value);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*bool */ System$Collections$IList$Contains(/*object?*/ value)
            {
                return this._list.Contains($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
            }
            /*int */ System$Collections$IList$IndexOf(/*object?*/ value)
            {
                return this._list.IndexOf($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
            }
            /*void */ System$Collections$IList$Insert(/*int*/ index, /*object?*/ value)
            {
                /*TraceListener?*/ let listener = $.$as(value, $.$sdts.System.Diagnostics.TraceListener);
                if (listener === null)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$sdts.System.SR.MustAddListener, "value");
                }
                $.$sdts.System.Diagnostics.TraceListenerCollection.InitializeListener(listener);
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Insert(index, $.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*void */ System$Collections$IList$Remove(/*object?*/ value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter($.$sdts.System.Diagnostics.TraceInternal.critSec)
                    {
                        this._list.Remove($.$cast(value, $.$sdts.System.Diagnostics.TraceListener));
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit($.$sdts.System.Diagnostics.TraceInternal.critSec)
                }
            }
            /*object */ get System$Collections$ICollection$SyncRoot()
            {
                return this;
            }
            /*bool */ get System$Collections$ICollection$IsSynchronized()
            {
                return true;
            }
            /*void */ System$Collections$ICollection$CopyTo(/*Array*/ array, /*int*/ index)
            {
                (this._list).System$Collections$ICollection$CopyTo(array, index);
            }
            //Generated interface implemetation for System.Collections.IList.Clear()
            System$Collections$IList$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.IList.RemoveAt(int)
            System$Collections$IList$RemoveAt()
            {
                return this.RemoveAt(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1616965;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1551429,"i":[{"n":"i","p":655361}],"g":{"r":0,"d":0,"h":17181486149,"f":1},"s":{"r":0,"d":0,"h":21476453445,"f":1},"n":"Item","o":"@$2","d":1616965,"h":12886518853,"f":1},{"p":1551429,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":30066388037,"f":1},"n":"Item","o":"@$3","d":1616965,"h":25771420741,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38656322629,"f":1},"n":"Count","d":1616965,"h":34361355333,"f":1},{"p":131073,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":103080832069,"f":2},"s":{"r":0,"d":0,"h":107375799365,"f":2},"n":"{31916033}.this[]","o":"System$Collections$IList$Item","d":1616965,"h":98785864773,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":115965733957,"f":2},"n":"{31916033}.IsReadOnly","o":"System$Collections$IList$IsReadOnly","d":1616965,"h":111670766661,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":124555668549,"f":2},"n":"{31916033}.IsFixedSize","o":"System$Collections$IList$IsFixedSize","d":1616965,"h":120260701253,"f":2},{"p":131073,"g":{"r":0,"d":0,"h":154620439621,"f":2},"n":"{31326209}.SyncRoot","o":"System$Collections$ICollection$SyncRoot","d":1616965,"h":150325472325,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":163210374213,"f":2},"n":"{31326209}.IsSynchronized","o":"System$Collections$ICollection$IsSynchronized","d":1616965,"h":158915406917,"f":2}],"m":[{"r":655361,"p":[{"n":"listener","p":1551429}],"n":"Add","d":1616965,"h":42951289925,"f":1},{"r":65537,"p":[{"n":"value","p":0}],"n":"AddRange","d":1616965,"h":47246257221,"f":1},{"r":65537,"p":[{"n":"value","p":1616965}],"n":"AddRange","o":"@$1","d":1616965,"h":51541224517,"f":1},{"r":65537,"n":"Clear","d":1616965,"h":55836191813,"f":1},{"r":262145,"p":[{"n":"listener","p":1551429}],"n":"Contains","d":1616965,"h":60131159109,"f":1},{"r":65537,"p":[{"n":"listeners","p":0},{"n":"index","p":655361}],"n":"CopyTo","d":1616965,"h":64426126405,"f":1},{"r":31719425,"n":"GetEnumerator","d":1616965,"h":68721093701,"f":1},{"r":65537,"p":[{"n":"listener","p":1551429}],"n":"InitializeListener","d":1616965,"h":73016060997,"f":40},{"r":655361,"p":[{"n":"listener","p":1551429}],"n":"IndexOf","d":1616965,"h":77311028293,"f":1},{"r":65537,"p":[{"n":"index","p":655361},{"n":"listener","p":1551429}],"n":"Insert","d":1616965,"h":81605995589,"f":1},{"r":65537,"p":[{"n":"listener","p":1551429}],"n":"Remove","d":1616965,"h":85900962885,"f":1},{"r":65537,"p":[{"n":"name","p":1310721}],"n":"Remove","o":"@$1","d":1616965,"h":90195930181,"f":1},{"r":65537,"p":[{"n":"index","p":655361}],"n":"RemoveAt","d":1616965,"h":94490897477,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.List$$($.$sdts.System.Diagnostics.TraceListener).$h,"n":"_list","d":1616965,"h":4296584261,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1616965,"h":8591551557,"f":8}],"i":[31916033,31326209,31588353],"h":1616965}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IList, $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Diagnostics.TraceListenerCollection`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.EventTypeFilter", ($self) => class EventTypeFilter extends $.$sdts.System.Diagnostics.TraceFilter
        {
            /*SourceLevels*/ _level = 0;
            $ctor$2(/*SourceLevels*/ level)
            {
                super.$ctor$1();
                {
                    this._level = level;
                }
                return this;
            }
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                return (eventType & this._level) !== 0;
            }
            /*SourceLevels */ get EventType()
            {
                return this._level;
            }
            /*SourceLevels */ set EventType(value)
            {
                this._level = value;
            }
            static $h = 502853;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1289285,"p":[{"p":764997,"g":{"r":0,"d":0,"h":21475339333,"f":1},"s":{"r":0,"d":0,"h":25770306629,"f":1},"n":"EventType","d":502853,"h":17180372037,"f":1}],"m":[{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":0},{"n":"data1","p":131073},{"n":"data","p":0}],"n":"ShouldTrace","d":502853,"h":12885404741,"f":32769}],"l":[{"t":764997,"n":"_level","d":502853,"h":4295470149,"f":2}],"c":[{"p":[{"n":"level","p":764997}],"n":".ctor","o":"$ctor$2","d":502853,"h":8590437445,"f":1}],"h":502853}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceFilter; }
            static get $fullName() { return `System.Diagnostics.EventTypeFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SourceSwitch", ($self) => class SourceSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$3(/*string*/ name)
            {
                super.$ctor$1(name, $.$spc.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ displayName, /*string*/ defaultSwitchValue)
            {
                super.$ctor$2(displayName, $.$spc.System.String.Empty, defaultSwitchValue);
                {
                }
                return this;
            }
            /*SourceLevels */ get Level()
            {
                return $.$cast(this.SwitchSetting, $.$sdts.System.Diagnostics.SourceLevels);
            }
            /*SourceLevels */ set Level(value)
            {
                this.SwitchSetting = value;
            }
            /*bool */ ShouldTrace(/*TraceEventType*/ eventType)
            {
                return (this.SwitchSetting & eventType) !== 0;
            }
            /*void */ OnValueChanged()
            {
                this.SwitchSetting = $.$spc.System.Enum.Parse$6($.$sdts.System.Diagnostics.SourceLevels, this.Value, true);
            }
            static $h = 830533;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":896069,"p":[{"p":764997,"g":{"r":0,"d":0,"h":17180699717,"f":1},"s":{"r":0,"d":0,"h":21475667013,"f":1},"n":"Level","d":830533,"h":12885732421,"f":1}],"m":[{"r":262145,"p":[{"n":"eventType","p":1223749}],"n":"ShouldTrace","d":830533,"h":25770634309,"f":1},{"r":65537,"n":"OnValueChanged","d":830533,"h":30065601605,"f":32772}],"c":[{"p":[{"n":"name","p":1310721}],"n":".ctor","o":"$ctor$3","d":830533,"h":4295797829,"f":1},{"p":[{"n":"displayName","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$4","d":830533,"h":8590765125,"f":1}],"h":830533}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.SourceSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SourceFilter", ($self) => class SourceFilter extends $.$sdts.System.Diagnostics.TraceFilter
        {
            /*string*/ _src = null;
            $ctor$2(/*string*/ source)
            {
                super.$ctor$1();
                {
                    this.Source = source;
                }
                return this;
            }
            /*bool */ ShouldTrace(/*TraceEventCache?*/ cache, /*string*/ source, /*TraceEventType*/ eventType, /*int*/ id, /*string?*/ formatOrMessage, /*object?[]?*/ args, /*object?*/ data1, /*object?[]?*/ data)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$spc.System.String.Equals$4(this._src, source);
            }
            /*string */ get Source()
            {
                return this._src;
            }
            /*string */ set Source(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "Source");
                this._src = value;
            }
            static $h = 699461;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1289285,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475535941,"f":1},"s":{"r":0,"d":0,"h":25770503237,"f":1},"n":"Source","d":699461,"h":17180568645,"f":1}],"m":[{"r":262145,"p":[{"n":"cache","p":1158213},{"n":"source","p":1310721},{"n":"eventType","p":1223749},{"n":"id","p":655361},{"n":"formatOrMessage","p":1310721},{"n":"args","p":0},{"n":"data1","p":131073},{"n":"data","p":0}],"n":"ShouldTrace","d":699461,"h":12885601349,"f":32769}],"l":[{"t":1310721,"n":"_src","d":699461,"h":4295666757,"f":2}],"c":[{"p":[{"n":"source","p":1310721}],"n":".ctor","o":"$ctor$2","d":699461,"h":8590634053,"f":1}],"h":699461}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceFilter; }
            static get $fullName() { return `System.Diagnostics.SourceFilter`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.BooleanSwitch", ($self) => class BooleanSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$3(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$1(displayName, description);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$2(displayName, description, defaultSwitchValue);
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                return (this.SwitchSetting === 0) ? false : true;
            }
            /*bool */ set Enabled(value)
            {
                this.SwitchSetting = value ? 1 : 0;
            }
            /*void */ OnValueChanged()
            {
                /*bool*/ let b;
                if ($.$spc.System.Boolean.TryParse(this.Value, $.$ref(() => b, ($v) => b = $v, $.$spc.System.Boolean)))
                {
                    this.SwitchSetting = (b ? 1 : 0);
                }
                else 
                {
                    super.OnValueChanged();
                }
            }
            static $h = 109637;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":896069,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17179978821,"f":1},"s":{"r":0,"d":0,"h":21474946117,"f":1},"n":"Enabled","d":109637,"h":12885011525,"f":1}],"m":[{"r":65537,"n":"OnValueChanged","d":109637,"h":25769913413,"f":32772}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$3","d":109637,"h":4295076933,"f":1},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$4","d":109637,"h":8590044229,"f":1}],"h":109637,"a":[{"t":1027141,"c":8590961733,"a":[{"v":262145,"t":142606337}]}]}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.BooleanSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.TraceSwitch", ($self) => class TraceSwitch extends $.$sdts.System.Diagnostics.Switch
        {
            $ctor$3(/*string*/ displayName, /*string?*/ description)
            {
                super.$ctor$1(displayName, description);
                {
                }
                return this;
            }
            $ctor$4(/*string*/ displayName, /*string?*/ description, /*string*/ defaultSwitchValue)
            {
                super.$ctor$2(displayName, description, defaultSwitchValue);
                {
                }
                return this;
            }
            /*TraceLevel */ get Level()
            {
                return $.$cast(this.SwitchSetting, $.$sdts.System.Diagnostics.TraceLevel);
            }
            /*TraceLevel */ set Level(value)
            {
                if (value < 0/*TraceLevel.Off*/ || value > 4/*TraceLevel.Verbose*/)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdts.System.SR.TraceSwitchInvalidLevel);
                }
                this.SetSwitchValues(value, $.$spc.System.Enum.ToStringT($.$sdts.System.Diagnostics.TraceLevel, $.$spc.System.UInt32, value));
            }
            /*bool */ get TraceError()
            {
                return this.Level >= 1/*TraceLevel.Error*/;
            }
            /*bool */ get TraceWarning()
            {
                return this.Level >= 2/*TraceLevel.Warning*/;
            }
            /*bool */ get TraceInfo()
            {
                return this.Level >= 3/*TraceLevel.Info*/;
            }
            /*bool */ get TraceVerbose()
            {
                return this.Level === 4/*TraceLevel.Verbose*/;
            }
            /*void */ OnSwitchSettingChanged()
            {
                /*int*/ let level = this.SwitchSetting;
                if (level < 0/*TraceLevel.Off*/)
                {
                    ;
                    this.SwitchSetting = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    ;
                    this.SwitchSetting = 4/*TraceLevel.Verbose*/;
                }
            }
            /*void */ OnValueChanged()
            {
                /*TraceLevel*/ let level = $.$spc.System.Enum.Parse$6($.$sdts.System.Diagnostics.TraceLevel, this.Value, true);
                if (level < 0/*TraceLevel.Off*/)
                {
                    level = 0/*TraceLevel.Off*/;
                }
                else if (level > 4/*TraceLevel.Verbose*/)
                {
                    level = 4/*TraceLevel.Verbose*/;
                }
                this.SetSwitchValues(level, $.$spc.System.Enum.ToStringT($.$sdts.System.Diagnostics.TraceLevel, $.$spc.System.UInt32, level));
            }
            static $h = 1813573;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":896069,"p":[{"p":1485893,"g":{"r":0,"d":0,"h":17181682757,"f":1},"s":{"r":0,"d":0,"h":21476650053,"f":1},"n":"Level","d":1813573,"h":12886715461,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30066584645,"f":1},"n":"TraceError","d":1813573,"h":25771617349,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38656519237,"f":1},"n":"TraceWarning","d":1813573,"h":34361551941,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246453829,"f":1},"n":"TraceInfo","d":1813573,"h":42951486533,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":55836388421,"f":1},"n":"TraceVerbose","d":1813573,"h":51541421125,"f":1}],"m":[{"r":65537,"n":"OnSwitchSettingChanged","d":1813573,"h":60131355717,"f":32772},{"r":65537,"n":"OnValueChanged","d":1813573,"h":64426323013,"f":32772}],"c":[{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721}],"n":".ctor","o":"$ctor$3","d":1813573,"h":4296780869,"f":1},{"p":[{"n":"displayName","p":1310721},{"n":"description","p":1310721},{"n":"defaultSwitchValue","p":1310721}],"n":".ctor","o":"$ctor$4","d":1813573,"h":8591748165,"f":1}],"h":1813573,"a":[{"t":1027141,"c":8590961733,"a":[{"v":1485893,"t":142606337}]}]}; }
            static get $b() { return $.$sdts.System.Diagnostics.Switch; }
            static get $fullName() { return `System.Diagnostics.TraceSwitch`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SwitchLevelAttribute", ($self) => class SwitchLevelAttribute extends $.$spc.System.Attribute
        {
            /*Type*/ _type = null;
            $ctor$2(/*Type*/ switchLevelType)
            {
                super.$ctor$1();
                {
                    this.SwitchLevelType = switchLevelType;
                }
                return this;
            }
            /*Type */ get SwitchLevelType()
            {
                return this._type;
            }
            /*Type */ set SwitchLevelType(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this._type = value;
            }
            static $h = 1027141;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":17180896325,"f":1},"s":{"r":0,"d":0,"h":21475863621,"f":1},"n":"SwitchLevelType","d":1027141,"h":12885929029,"f":1}],"l":[{"t":142606337,"n":"_type","d":1027141,"h":4295994437,"f":2}],"c":[{"p":[{"n":"switchLevelType","p":142606337}],"n":".ctor","o":"$ctor$2","d":1027141,"h":8590961733,"f":1}],"h":1027141,"a":[{"t":14614529,"c":21489451009,"a":[{"v":4,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Diagnostics.SwitchLevelAttribute`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.SwitchAttribute", ($self) => class SwitchAttribute extends $.$spc.System.Attribute
        {
            /*Type*/ _type = null;
            /*string*/ _name = null;
            $ctor$2(/*string*/ switchName, /*Type*/ switchType)
            {
                super.$ctor$1();
                {
                    this.SwitchName = switchName;
                    this.SwitchType = switchType;
                }
                return this;
            }
            /*string */ get SwitchName()
            {
                return this._name;
            }
            /*string */ set SwitchName(value)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(value, "value");
                this._name = value;
            }
            /*Type */ get SwitchType()
            {
                return this._type;
            }
            /*Type */ set SwitchType(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this._type = value;
            }
            /*string?*/ SwitchDescription = null;
            static /*SwitchAttribute[] */ GetAll(/*Assembly*/ assembly)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(assembly, "assembly");
                /*List<object>*/ let switchAttribs = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                /*object[]*/ let attribs = assembly.GetCustomAttributes$1($.$sdts.System.Diagnostics.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
                let $i1 = 0;
                let $arr1 = assembly.GetTypes();
                while ($i1 < $arr1.length)
                {
                    let type = $arr1[$i1++];
                    $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive(type, switchAttribs);
                }
                /*SwitchAttribute[]*/ let ret = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sdts.System.Diagnostics.SwitchAttribute), null, [switchAttribs.Count], null);
                switchAttribs.CopyTo$2(ret, 0);
                return ret;
            }
            static /*void */ GetAllRecursive(/*Type*/ type, /*List<object>*/ switchAttribs)
            {
                $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive$1(type, switchAttribs);
                /*MemberInfo[]*/ let members = type.GetMembers$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 2/*BindingFlags.DeclaredOnly*/ | 4/*BindingFlags.Instance*/ | 8/*BindingFlags.Static*/);
                let $i1 = 0;
                let $arr1 = members;
                while ($i1 < $arr1.length)
                {
                    let member = $arr1[$i1++];
                    if (!($.$is(member, $.$spc.System.Type)))
                    {
                        $.$sdts.System.Diagnostics.SwitchAttribute.GetAllRecursive$1(member, switchAttribs);
                    }
                }
            }
            static /*void */ GetAllRecursive$1(/*MemberInfo*/ member, /*List<object>*/ switchAttribs)
            {
                /*object[]*/ let attribs = member.GetCustomAttributes$1($.$sdts.System.Diagnostics.SwitchAttribute.$type, false);
                switchAttribs.AddRange(attribs);
            }
            static $h = 961605;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":14483457,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475798085,"f":1},"s":{"r":0,"d":0,"h":25770765381,"f":1},"n":"SwitchName","d":961605,"h":17180830789,"f":1},{"p":142606337,"g":{"r":0,"d":0,"h":34360699973,"f":1},"s":{"r":0,"d":0,"h":38655667269,"f":1},"n":"SwitchType","d":961605,"h":30065732677,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540569157,"f":1},"s":{"r":0,"d":0,"h":55835536453,"f":1},"n":"SwitchDescription","d":961605,"h":47245601861,"f":1}],"m":[{"r":0,"p":[{"n":"assembly","p":73465857}],"n":"GetAll","d":961605,"h":60130503749,"f":33},{"r":65537,"p":[{"n":"type","p":142606337},{"n":"switchAttribs","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h}],"n":"GetAllRecursive","d":961605,"h":64425471045,"f":34},{"r":65537,"p":[{"n":"member","p":78249985},{"n":"switchAttribs","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.Object).$h}],"n":"GetAllRecursive","o":"@$1","d":961605,"h":68720438341,"f":34}],"l":[{"t":142606337,"n":"_type","d":961605,"h":4295928901,"f":2},{"t":1310721,"n":"_name","d":961605,"h":8590896197,"f":2}],"c":[{"p":[{"n":"switchName","p":1310721},{"n":"switchType","p":142606337}],"n":".ctor","o":"$ctor$2","d":961605,"h":12885863493,"f":1}],"h":961605,"a":[{"t":14614529,"c":21489451009,"a":[{"v":741,"t":14548993}]}]}; }
            static get $b() { return $.$spc.System.Attribute; }
            static get $fullName() { return `System.Diagnostics.SwitchAttribute`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.DefaultTraceListener", ($self) => class DefaultTraceListener extends $.$sdts.System.Diagnostics.TraceListener
        {
            /*bool*/ _assertUIEnabled = false;
            /*bool*/ _settingsInitialized = false;
            /*string?*/ _logFileName = null;
            $ctor$4()
            {
                super.$ctor$3("Default");
                {
                }
                return this;
            }
            /*bool */ get AssertUiEnabled()
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._assertUIEnabled;
            }
            /*bool */ set AssertUiEnabled(value)
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._assertUIEnabled = value;
            }
            /*string? */ get LogFileName()
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                return this._logFileName;
            }
            /*string? */ set LogFileName(value)
            {
                if (!this._settingsInitialized)
                {
                    this.InitializeSettings();
                }
                this._logFileName = value;
            }
            /*void */ Fail(/*string?*/ message)
            {
                this.Fail$1(message, null);
            }
            /*void */ Fail$1(/*string?*/ message, /*string?*/ detailMessage)
            {
                /*string*/ let stackTrace;
                try
                {
                    stackTrace = $.$spc.System.Diagnostics.StackTrace.ToString.call(new $.$spc.System.Diagnostics.StackTrace().$ctor$2(true));
                }
                catch($e)
                {
                    stackTrace = "";
                }
                this.WriteAssert(stackTrace, message, detailMessage);
                if (this.AssertUiEnabled)
                {
                    $.$spc.System.Diagnostics.DebugProvider.FailCore(stackTrace, message, detailMessage, "Assertion Failed");
                }
            }
            /*void */ InitializeSettings()
            {
                this._assertUIEnabled = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.AssertUIEnabled;
                this._logFileName = $.$sdts.System.Diagnostics.DiagnosticsConfiguration.LogFileName;
                this._settingsInitialized = true;
            }
            /*void */ WriteAssert(/*string*/ stackTrace, /*string?*/ message, /*string?*/ detailMessage)
            {
                this.WriteLine($.$sdts.System.SR.DebugAssertBanner + $.$spc.System.Environment.NewLine + $.$sdts.System.SR.DebugAssertShortMessage + $.$spc.System.Environment.NewLine + message + $.$spc.System.Environment.NewLine + $.$sdts.System.SR.DebugAssertLongMessage + $.$spc.System.Environment.NewLine + detailMessage + $.$spc.System.Environment.NewLine + stackTrace);
            }
            /*void */ Write(/*string?*/ message)
            {
                this.Write$4(message, true);
            }
            /*void */ WriteLine(/*string?*/ message)
            {
                this.WriteLine$4(message, true);
            }
            /*void */ WriteLine$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                if (this.NeedIndent)
                {
                    this.WriteIndent();
                }
                this.Write$4(message + $.$spc.System.Environment.NewLine, useLogFile);
                this.NeedIndent = true;
            }
            /*void */ Write$4(/*string?*/ message, /*bool*/ useLogFile)
            {
                message ??= $.$spc.System.String.Empty;
                if (this.NeedIndent && message.length !== 0)
                {
                    this.WriteIndent();
                }
                $.$spc.System.Diagnostics.DebugProvider.WriteCore(message);
                if (useLogFile && !$.$spc.System.String.IsNullOrEmpty(this.LogFileName))
                {
                    this.WriteToLogFile(message);
                }
            }
            /*void */ WriteToLogFile(/*string*/ message)
            {
                try
                {
                    $.$spc.System.IO.File.AppendAllText(this.LogFileName, message);
                }
                catch(e)
                {
                    this.WriteLine$4($.$sdts.System.SR.Format$1($.$sdts.System.SR.ExceptionOccurred, this.LogFileName, e), false);
                }
            }
            static $h = 371781;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1551429,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770175557,"f":1},"s":{"r":0,"d":0,"h":30065142853,"f":1},"n":"AssertUiEnabled","d":371781,"h":21475208261,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655077445,"f":1},"s":{"r":0,"d":0,"h":42950044741,"f":1},"n":"LogFileName","d":371781,"h":34360110149,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Fail","d":371781,"h":47245012037,"f":32769},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"Fail","o":"@$1","d":371781,"h":51539979333,"f":32769},{"r":65537,"n":"InitializeSettings","d":371781,"h":55834946629,"f":2},{"r":65537,"p":[{"n":"stackTrace","p":1310721},{"n":"message","p":1310721},{"n":"detailMessage","p":1310721}],"n":"WriteAssert","d":371781,"h":60129913925,"f":2},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"Write","d":371781,"h":64424881221,"f":32769},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteLine","d":371781,"h":68719848517,"f":32769},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"useLogFile","p":262145}],"n":"WriteLine","o":"@$4","d":371781,"h":73014815813,"f":2},{"r":65537,"p":[{"n":"message","p":1310721},{"n":"useLogFile","p":262145}],"n":"Write","o":"@$4","d":371781,"h":77309783109,"f":2},{"r":65537,"p":[{"n":"message","p":1310721}],"n":"WriteToLogFile","d":371781,"h":81604750405,"f":2}],"l":[{"t":262145,"n":"_assertUIEnabled","d":371781,"h":4295339077,"f":2},{"t":262145,"n":"_settingsInitialized","d":371781,"h":8590306373,"f":2},{"t":1310721,"n":"_logFileName","d":371781,"h":12885273669,"f":2}],"c":[{"n":".ctor","o":"$ctor$4","d":371781,"h":17180240965,"f":1}],"i":[57475073],"h":371781}; }
            static get $b() { return $.$sdts.System.Diagnostics.TraceListener; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Diagnostics.DefaultTraceListener`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.SourceLevels", ($self) => class SourceLevels extends $.$spc.System.Enum
        {
            static Off = 0;
            static Critical = 1;
            static Error = 3;
            static Warning = 7;
            static Information = 15;
            static Verbose = 31;
            static ActivityTracing = 65280;
            static All = -1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Critical": 1n,
                    "Error": 3n,
                    "Warning": 7n,
                    "Information": 15n,
                    "Verbose": 31n,
                    "ActivityTracing": 65280n,
                    "All": -1n
                };
            }
            static $h = 764997;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":764997,"n":"Off","d":764997,"h":4295732293,"f":33},{"t":764997,"n":"Critical","d":764997,"h":8590699589,"f":33},{"t":764997,"n":"Error","d":764997,"h":12885666885,"f":33},{"t":764997,"n":"Warning","d":764997,"h":17180634181,"f":33},{"t":764997,"n":"Information","d":764997,"h":21475601477,"f":33},{"t":764997,"n":"Verbose","d":764997,"h":25770568773,"f":33},{"t":764997,"n":"ActivityTracing","d":764997,"h":30065536069,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":2,"t":33226753}]}]},{"t":764997,"n":"All","d":764997,"h":34360503365,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":764997,"h":38655470661,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":764997,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.SourceLevels`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceEventType", ($self) => class TraceEventType extends $.$spc.System.Enum
        {
            static Critical = 1;
            static Error = 2;
            static Warning = 4;
            static Information = 8;
            static Verbose = 16;
            static Start = 256;
            static Stop = 512;
            static Suspend = 1024;
            static Resume = 2048;
            static Transfer = 4096;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Critical": 1n,
                    "Error": 2n,
                    "Warning": 4n,
                    "Information": 8n,
                    "Verbose": 16n,
                    "Start": 256n,
                    "Stop": 512n,
                    "Suspend": 1024n,
                    "Resume": 2048n,
                    "Transfer": 4096n
                };
            }
            static $h = 1223749;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1223749,"n":"Critical","d":1223749,"h":4296191045,"f":33},{"t":1223749,"n":"Error","d":1223749,"h":8591158341,"f":33},{"t":1223749,"n":"Warning","d":1223749,"h":12886125637,"f":33},{"t":1223749,"n":"Information","d":1223749,"h":17181092933,"f":33},{"t":1223749,"n":"Verbose","d":1223749,"h":21476060229,"f":33},{"t":1223749,"n":"Start","d":1223749,"h":25771027525,"f":33},{"t":1223749,"n":"Stop","d":1223749,"h":30065994821,"f":33},{"t":1223749,"n":"Suspend","d":1223749,"h":34360962117,"f":33},{"t":1223749,"n":"Resume","d":1223749,"h":38655929413,"f":33},{"t":1223749,"n":"Transfer","d":1223749,"h":42950896709,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1223749,"h":47245864005,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1223749}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceEventType`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceLevel", ($self) => class TraceLevel extends $.$spc.System.Enum
        {
            static Off = 0;
            static Error = 1;
            static Warning = 2;
            static Info = 3;
            static Verbose = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Off": 0n,
                    "Error": 1n,
                    "Warning": 2n,
                    "Info": 3n,
                    "Verbose": 4n
                };
            }
            static $h = 1485893;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1485893,"n":"Off","d":1485893,"h":4296453189,"f":33},{"t":1485893,"n":"Error","d":1485893,"h":8591420485,"f":33},{"t":1485893,"n":"Warning","d":1485893,"h":12886387781,"f":33},{"t":1485893,"n":"Info","d":1485893,"h":17181355077,"f":33},{"t":1485893,"n":"Verbose","d":1485893,"h":21476322373,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1485893,"h":25771289669,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1485893}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceLevel`; }
        });
        
        $asm.$str("$sdts.System.Diagnostics.TraceOptions", ($self) => class TraceOptions extends $.$spc.System.Enum
        {
            static None = 0;
            static LogicalOperationStack = 1;
            static DateTime = 2;
            static Timestamp = 4;
            static ProcessId = 8;
            static ThreadId = 16;
            static Callstack = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "LogicalOperationStack": 1n,
                    "DateTime": 2n,
                    "Timestamp": 4n,
                    "ProcessId": 8n,
                    "ThreadId": 16n,
                    "Callstack": 32n
                };
            }
            static $h = 1682501;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1682501,"n":"None","d":1682501,"h":4296649797,"f":33},{"t":1682501,"n":"LogicalOperationStack","d":1682501,"h":8591617093,"f":33},{"t":1682501,"n":"DateTime","d":1682501,"h":12886584389,"f":33},{"t":1682501,"n":"Timestamp","d":1682501,"h":17181551685,"f":33},{"t":1682501,"n":"ProcessId","d":1682501,"h":21476518981,"f":33},{"t":1682501,"n":"ThreadId","d":1682501,"h":25771486277,"f":33},{"t":1682501,"n":"Callstack","d":1682501,"h":30066453573,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1682501,"h":34361420869,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1682501,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Diagnostics.TraceOptions`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.InitializingTraceSourceEventArgs", ($self) => class InitializingTraceSourceEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*TraceSource*/ traceSource)
            {
                super.$ctor$1();
                {
                    this.TraceSource = traceSource;
                }
                return this;
            }
            /*TraceSource*/ TraceSource = null;
            /*bool*/ WasInitialized = false;
            //default member initializer
            constructor()
            {
                super();
                this.WasInitialized = false;
            }
            static $h = 633925;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":1748037,"g":{"r":0,"d":0,"h":17180503109,"f":1},"n":"TraceSource","d":633925,"h":12885535813,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":30065404997,"f":1},"s":{"r":0,"d":0,"h":34360372293,"f":1},"n":"WasInitialized","d":633925,"h":25770437701,"f":1}],"c":[{"p":[{"n":"traceSource","p":1748037}],"n":".ctor","o":"$ctor$2","d":633925,"h":4295601221,"f":1}],"h":633925}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.InitializingTraceSourceEventArgs`; }
        });
        
        $asm.$cls("$sdts.System.Diagnostics.InitializingSwitchEventArgs", ($self) => class InitializingSwitchEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2(/*Switch*/ $switch)
            {
                super.$ctor$1();
                {
                    this.Switch = $switch;
                }
                return this;
            }
            /*Switch*/ Switch = null;
            static $h = 568389;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":896069,"g":{"r":0,"d":0,"h":17180437573,"f":1},"n":"Switch","d":568389,"h":12885470277,"f":1}],"c":[{"p":[{"n":"switch","p":896069}],"n":".ctor","o":"$ctor$2","d":568389,"h":4295535685,"f":1}],"h":568389}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Diagnostics.InitializingSwitchEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized"))