
(function ($global, $, $spc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Diagnostics.Tracing", 
    {"h":37321,"f":"System.Diagnostics.Tracing","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Diagnostics.Tracing","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Diagnostics.Tracing","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))