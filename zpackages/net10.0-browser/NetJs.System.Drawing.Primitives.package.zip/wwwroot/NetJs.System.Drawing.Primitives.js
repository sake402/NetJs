
//--TRIMMABLE-BOUNDARY-START(25)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $snv, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {
  "h": 25,
  "f": "System.Drawing.Primitives",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Drawing.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Drawing.Primitives",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(393241)
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            //--TRIMMABLE-BOUNDARY-START(12885295129)
            /*string[]*/ static s_colorNameTable = null;
            //--TRIMMABLE-BOUNDARY-END(12885295129)
            
            //--TRIMMABLE-BOUNDARY-START(8590327833)
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590327833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$$.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(8590327833)
            
            //--TRIMMABLE-BOUNDARY-START(4295360537)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295129)
                    this.s_colorNameTable = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                    //--TRIMMABLE-BOUNDARY-END(12885295129)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360537)
            
            static $h = 393241;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590327833),
    {
      "r": 1310721,
      "p": [
        {
          "n": "color",
          "p": 327705
        }
      ],
      "n": "KnownColorToName",
      "d": 393241,
      "h": 8590327833,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590327833)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295129),
    {
      "t": $.$typeArray($.$$.System.String).$h,
      "n": "s_colorNameTable",
      "d": 393241,
      "h": 12885295129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(12885295129)
  ],
  "h": 393241
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393241)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048601)
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(137440002073)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(137440002073)
            
            //--TRIMMABLE-BOUNDARY-START(128850067481)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(128850067481)
            
            //--TRIMMABLE-BOUNDARY-START(133145034777)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080263705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(133145034777)
            
            //--TRIMMABLE-BOUNDARY-START(12885950489)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310459929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324903961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdp.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(12885950489)
            
            //--TRIMMABLE-BOUNDARY-START(8590983193)
            static /*string */ get ConvertInvalidPrimitive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720525337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is not a valid value for {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590983193)
            
            //--TRIMMABLE-BOUNDARY-START(51540656153)
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540656153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("{0} is not a valid value for {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(51540656153)
            
            //--TRIMMABLE-BOUNDARY-START(120260132889)
            static /*string */ get InvalidColor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900394521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Color '{0}' is not valid.";
            }
            //--TRIMMABLE-BOUNDARY-END(120260132889)
            
            //--TRIMMABLE-BOUNDARY-START(55835623449)
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Color '{0}' is not valid.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(55835623449)
            
            //--TRIMMABLE-BOUNDARY-START(124555100185)
            static /*string */ get InvalidEx2BoundArgument()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490329113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            //--TRIMMABLE-BOUNDARY-END(124555100185)
            
            //--TRIMMABLE-BOUNDARY-START(60130590745)
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130590745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$11("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            //--TRIMMABLE-BOUNDARY-END(60130590745)
            
            //--TRIMMABLE-BOUNDARY-START(141734969369)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(141734969369)
            
            //--TRIMMABLE-BOUNDARY-START(115965165593)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115965165593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115965165593)
            
            //--TRIMMABLE-BOUNDARY-START(154619871257)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619871257);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619871257)
            
            //--TRIMMABLE-BOUNDARY-START(111670198297)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670198297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(111670198297)
            
            //--TRIMMABLE-BOUNDARY-START(107375231001)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375231001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(107375231001)
            
            //--TRIMMABLE-BOUNDARY-START(42950721561)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950721561)
            
            //--TRIMMABLE-BOUNDARY-START(38655754265)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655754265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(38655754265)
            
            //--TRIMMABLE-BOUNDARY-START(34360786969)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360786969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360786969)
            
            //--TRIMMABLE-BOUNDARY-START(47245688857)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245688857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(47245688857)
            
            //--TRIMMABLE-BOUNDARY-START(25770852377)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770852377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770852377)
            
            //--TRIMMABLE-BOUNDARY-START(21475885081)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(21475885081)
            
            //--TRIMMABLE-BOUNDARY-START(17180917785)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(17180917785)
            
            //--TRIMMABLE-BOUNDARY-START(30065819673)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065819673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(30065819673)
            
            //--TRIMMABLE-BOUNDARY-START(4296015897)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(141734969369)
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(141734969369)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296015897)
            
            static $h = 1048601;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1048601
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048601)
        
        
        //--TRIMMABLE-BOUNDARY-START(917529)
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            //--TRIMMABLE-BOUNDARY-START(420907712537)
            /*bool*/ static s_useAlternativeColorSet = false;
            //--TRIMMABLE-BOUNDARY-END(420907712537)
            
            //--TRIMMABLE-BOUNDARY-START(4295884825)
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            //--TRIMMABLE-BOUNDARY-END(4295884825)
            
            //--TRIMMABLE-BOUNDARY-START(8590852121)
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            //--TRIMMABLE-BOUNDARY-END(8590852121)
            
            //--TRIMMABLE-BOUNDARY-START(12885819417)
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(12885819417)
            
            //--TRIMMABLE-BOUNDARY-START(17180786713)
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            //--TRIMMABLE-BOUNDARY-END(17180786713)
            
            //--TRIMMABLE-BOUNDARY-START(21475754009)
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21475754009)
            
            //--TRIMMABLE-BOUNDARY-START(25770721305)
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25770721305)
            
            //--TRIMMABLE-BOUNDARY-START(30065688601)
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30065688601)
            
            //--TRIMMABLE-BOUNDARY-START(34360655897)
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34360655897)
            
            //--TRIMMABLE-BOUNDARY-START(38655623193)
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38655623193)
            
            //--TRIMMABLE-BOUNDARY-START(42950590489)
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            //--TRIMMABLE-BOUNDARY-END(42950590489)
            
            //--TRIMMABLE-BOUNDARY-START(47245557785)
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            //--TRIMMABLE-BOUNDARY-END(47245557785)
            
            //--TRIMMABLE-BOUNDARY-START(51540525081)
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            //--TRIMMABLE-BOUNDARY-END(51540525081)
            
            //--TRIMMABLE-BOUNDARY-START(55835492377)
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(55835492377)
            
            //--TRIMMABLE-BOUNDARY-START(60130459673)
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            //--TRIMMABLE-BOUNDARY-END(60130459673)
            
            //--TRIMMABLE-BOUNDARY-START(356483203097)
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            //--TRIMMABLE-BOUNDARY-END(356483203097)
            
            //--TRIMMABLE-BOUNDARY-START(360778170393)
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            //--TRIMMABLE-BOUNDARY-END(360778170393)
            
            //--TRIMMABLE-BOUNDARY-START(365073137689)
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(365073137689)
            
            //--TRIMMABLE-BOUNDARY-START(369368104985)
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            //--TRIMMABLE-BOUNDARY-END(369368104985)
            
            //--TRIMMABLE-BOUNDARY-START(373663072281)
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(373663072281)
            
            //--TRIMMABLE-BOUNDARY-START(377958039577)
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            //--TRIMMABLE-BOUNDARY-END(377958039577)
            
            //--TRIMMABLE-BOUNDARY-START(382253006873)
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            //--TRIMMABLE-BOUNDARY-END(382253006873)
            
            //--TRIMMABLE-BOUNDARY-START(386547974169)
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            //--TRIMMABLE-BOUNDARY-END(386547974169)
            
            //--TRIMMABLE-BOUNDARY-START(390842941465)
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(390842941465)
            
            //--TRIMMABLE-BOUNDARY-START(395137908761)
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            //--TRIMMABLE-BOUNDARY-END(395137908761)
            
            //--TRIMMABLE-BOUNDARY-START(399432876057)
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(399432876057)
            
            //--TRIMMABLE-BOUNDARY-START(403727843353)
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            //--TRIMMABLE-BOUNDARY-END(403727843353)
            
            //--TRIMMABLE-BOUNDARY-START(408022810649)
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            //--TRIMMABLE-BOUNDARY-END(408022810649)
            
            //--TRIMMABLE-BOUNDARY-START(412317777945)
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            //--TRIMMABLE-BOUNDARY-END(412317777945)
            
            //--TRIMMABLE-BOUNDARY-START(416612745241)
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(416612745241)
            
            //--TRIMMABLE-BOUNDARY-START(425202679833)
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            //--TRIMMABLE-BOUNDARY-END(425202679833)
            
            //--TRIMMABLE-BOUNDARY-START(442382549017)
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            //--TRIMMABLE-BOUNDARY-END(442382549017)
            
            //--TRIMMABLE-BOUNDARY-START(446677516313)
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            //--TRIMMABLE-BOUNDARY-END(446677516313)
            
            //--TRIMMABLE-BOUNDARY-START(450972483609)
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            //--TRIMMABLE-BOUNDARY-END(450972483609)
            
            //--TRIMMABLE-BOUNDARY-START(438087581721)
            static /*bool */ get UseAlternativeColorSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418432025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792614425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            //--TRIMMABLE-BOUNDARY-END(438087581721)
            
            static $h = 917529;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(4295884825),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720394265,
        "f": 50331681
      },
      "n": "ActiveBorder",
      "d": 917529,
      "h": 4295884825,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(4295884825),
//--TRIMMABLE-BOUNDARY-START(8590852121),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310328857,
        "f": 50331681
      },
      "n": "ActiveCaption",
      "d": 917529,
      "h": 8590852121,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8590852121),
//--TRIMMABLE-BOUNDARY-START(12885819417),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900263449,
        "f": 50331681
      },
      "n": "ActiveCaptionText",
      "d": 917529,
      "h": 12885819417,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885819417),
//--TRIMMABLE-BOUNDARY-START(17180786713),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490198041,
        "f": 50331681
      },
      "n": "AppWorkspace",
      "d": 917529,
      "h": 17180786713,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180786713),
//--TRIMMABLE-BOUNDARY-START(21475754009),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080132633,
        "f": 50331681
      },
      "n": "ButtonFace",
      "d": 917529,
      "h": 21475754009,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475754009),
//--TRIMMABLE-BOUNDARY-START(25770721305),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670067225,
        "f": 50331681
      },
      "n": "ButtonHighlight",
      "d": 917529,
      "h": 25770721305,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25770721305),
//--TRIMMABLE-BOUNDARY-START(30065688601),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260001817,
        "f": 50331681
      },
      "n": "ButtonShadow",
      "d": 917529,
      "h": 30065688601,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30065688601),
//--TRIMMABLE-BOUNDARY-START(34360655897),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849936409,
        "f": 50331681
      },
      "n": "Control",
      "d": 917529,
      "h": 34360655897,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34360655897),
//--TRIMMABLE-BOUNDARY-START(38655623193),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439871001,
        "f": 50331681
      },
      "n": "ControlDark",
      "d": 917529,
      "h": 38655623193,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38655623193),
//--TRIMMABLE-BOUNDARY-START(42950590489),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029805593,
        "f": 50331681
      },
      "n": "ControlDarkDark",
      "d": 917529,
      "h": 42950590489,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(42950590489),
//--TRIMMABLE-BOUNDARY-START(47245557785),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619740185,
        "f": 50331681
      },
      "n": "ControlLight",
      "d": 917529,
      "h": 47245557785,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(47245557785),
//--TRIMMABLE-BOUNDARY-START(51540525081),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209674777,
        "f": 50331681
      },
      "n": "ControlLightLight",
      "d": 917529,
      "h": 51540525081,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540525081),
//--TRIMMABLE-BOUNDARY-START(55835492377),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799609369,
        "f": 50331681
      },
      "n": "ControlText",
      "d": 917529,
      "h": 55835492377,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55835492377),
//--TRIMMABLE-BOUNDARY-START(60130459673),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389543961,
        "f": 50331681
      },
      "n": "Desktop",
      "d": 917529,
      "h": 60130459673,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(60130459673),
//--TRIMMABLE-BOUNDARY-START(356483203097),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979478553,
        "f": 50331681
      },
      "n": "GradientActiveCaption",
      "d": 917529,
      "h": 356483203097,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(356483203097),
//--TRIMMABLE-BOUNDARY-START(360778170393),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569413145,
        "f": 50331681
      },
      "n": "GradientInactiveCaption",
      "d": 917529,
      "h": 360778170393,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(360778170393),
//--TRIMMABLE-BOUNDARY-START(365073137689),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159347737,
        "f": 50331681
      },
      "n": "GrayText",
      "d": 917529,
      "h": 365073137689,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(365073137689),
//--TRIMMABLE-BOUNDARY-START(369368104985),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749282329,
        "f": 50331681
      },
      "n": "Highlight",
      "d": 917529,
      "h": 369368104985,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(369368104985),
//--TRIMMABLE-BOUNDARY-START(373663072281),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339216921,
        "f": 50331681
      },
      "n": "HighlightText",
      "d": 917529,
      "h": 373663072281,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(373663072281),
//--TRIMMABLE-BOUNDARY-START(377958039577),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929151513,
        "f": 50331681
      },
      "n": "HotTrack",
      "d": 917529,
      "h": 377958039577,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(377958039577),
//--TRIMMABLE-BOUNDARY-START(382253006873),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519086105,
        "f": 50331681
      },
      "n": "InactiveBorder",
      "d": 917529,
      "h": 382253006873,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(382253006873),
//--TRIMMABLE-BOUNDARY-START(386547974169),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109020697,
        "f": 50331681
      },
      "n": "InactiveCaption",
      "d": 917529,
      "h": 386547974169,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(386547974169),
//--TRIMMABLE-BOUNDARY-START(390842941465),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698955289,
        "f": 50331681
      },
      "n": "InactiveCaptionText",
      "d": 917529,
      "h": 390842941465,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(390842941465),
//--TRIMMABLE-BOUNDARY-START(395137908761),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288889881,
        "f": 50331681
      },
      "n": "Info",
      "d": 917529,
      "h": 395137908761,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(395137908761),
//--TRIMMABLE-BOUNDARY-START(399432876057),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878824473,
        "f": 50331681
      },
      "n": "InfoText",
      "d": 917529,
      "h": 399432876057,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(399432876057),
//--TRIMMABLE-BOUNDARY-START(403727843353),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468759065,
        "f": 50331681
      },
      "n": "Menu",
      "d": 917529,
      "h": 403727843353,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(403727843353),
//--TRIMMABLE-BOUNDARY-START(408022810649),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058693657,
        "f": 50331681
      },
      "n": "MenuBar",
      "d": 917529,
      "h": 408022810649,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(408022810649),
//--TRIMMABLE-BOUNDARY-START(412317777945),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648628249,
        "f": 50331681
      },
      "n": "MenuHighlight",
      "d": 917529,
      "h": 412317777945,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(412317777945),
//--TRIMMABLE-BOUNDARY-START(416612745241),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238562841,
        "f": 50331681
      },
      "n": "MenuText",
      "d": 917529,
      "h": 416612745241,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(416612745241),
//--TRIMMABLE-BOUNDARY-START(425202679833),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317828497433,
        "f": 50331681
      },
      "n": "ScrollBar",
      "d": 917529,
      "h": 425202679833,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(425202679833),
//--TRIMMABLE-BOUNDARY-START(442382549017),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335008366617,
        "f": 50331681
      },
      "n": "Window",
      "d": 917529,
      "h": 442382549017,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(442382549017),
//--TRIMMABLE-BOUNDARY-START(446677516313),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343598301209,
        "f": 50331681
      },
      "n": "WindowFrame",
      "d": 917529,
      "h": 446677516313,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(446677516313),
//--TRIMMABLE-BOUNDARY-START(450972483609),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352188235801,
        "f": 50331681
      },
      "n": "WindowText",
      "d": 917529,
      "h": 450972483609,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(450972483609),
//--TRIMMABLE-BOUNDARY-START(438087581721),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326418432025,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792614425,
        "f": 83886113
      },
      "n": "UseAlternativeColorSet",
      "d": 917529,
      "h": 438087581721,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(438087581721)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(420907712537),
    {
      "t": 262145,
      "n": "s_useAlternativeColorSet",
      "d": 917529,
      "h": 420907712537,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907712537)
  ],
  "h": 917529
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917529)
        
        
        //--TRIMMABLE-BOUNDARY-START(983065)
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            //--TRIMMABLE-BOUNDARY-START(12885884953)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(12885884953)
            
            //--TRIMMABLE-BOUNDARY-START(21475819545)
            /*string*/ static TensorTDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475819545)
            
            //--TRIMMABLE-BOUNDARY-START(17180852249)
            /*string*/ static SystemColorsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(17180852249)
            
            //--TRIMMABLE-BOUNDARY-START(4295950361)
            /*string*/ static ArmSveDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295950361)
            
            //--TRIMMABLE-BOUNDARY-START(25770786841)
            /*string*/ static X86BaseDivRemDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(25770786841)
            
            //--TRIMMABLE-BOUNDARY-START(8590917657)
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(8590917657)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885884953)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(12885884953)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475819545)
                    this.TensorTDiagId = "SYSLIB5001";
                    //--TRIMMABLE-BOUNDARY-END(21475819545)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180852249)
                    this.SystemColorsDiagId = "SYSLIB5002";
                    //--TRIMMABLE-BOUNDARY-END(17180852249)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295950361)
                    this.ArmSveDiagId = "SYSLIB5003";
                    //--TRIMMABLE-BOUNDARY-END(4295950361)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770786841)
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                    //--TRIMMABLE-BOUNDARY-END(25770786841)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590917657)
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                    //--TRIMMABLE-BOUNDARY-END(8590917657)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 983065;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885884953),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 983065,
      "h": 12885884953,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885884953),
//--TRIMMABLE-BOUNDARY-START(21475819545),
    {
      "t": 1310721,
      "n": "TensorTDiagId",
      "d": 983065,
      "h": 21475819545,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475819545),
//--TRIMMABLE-BOUNDARY-START(17180852249),
    {
      "t": 1310721,
      "n": "SystemColorsDiagId",
      "d": 983065,
      "h": 17180852249,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180852249),
//--TRIMMABLE-BOUNDARY-START(4295950361),
    {
      "t": 1310721,
      "n": "ArmSveDiagId",
      "d": 983065,
      "h": 4295950361,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295950361),
//--TRIMMABLE-BOUNDARY-START(25770786841),
    {
      "t": 1310721,
      "n": "X86BaseDivRemDiagId",
      "d": 983065,
      "h": 25770786841,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770786841),
//--TRIMMABLE-BOUNDARY-START(8590917657),
    {
      "t": 1310721,
      "n": "PostQuantumCryptographyDiagId",
      "d": 983065,
      "h": 8590917657,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590917657)
  ],
  "h": 983065
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983065)
        
        
        //--TRIMMABLE-BOUNDARY-START(196633)
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            //--TRIMMABLE-BOUNDARY-START(34359935001)
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            //--TRIMMABLE-BOUNDARY-END(34359935001)
            
            //--TRIMMABLE-BOUNDARY-START(25770000409)
            static /*Dictionary<string, Color> */ GetColors()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let colors = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000409)
            
            //--TRIMMABLE-BOUNDARY-START(12885098521)
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$$.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098521)
            
            //--TRIMMABLE-BOUNDARY-START(8590131225)
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131225)
            
            //--TRIMMABLE-BOUNDARY-START(38654902297)
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654902297);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654902297)
            
            //--TRIMMABLE-BOUNDARY-START(30064967705)
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064967705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064967705)
            
            //--TRIMMABLE-BOUNDARY-START(4295163929)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34359935001)
                    this.s_colorConstants = new ($.$$.System.Lazy$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)))().$ctor$6(new ($.$$.System.Func$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)))().$ctor($.$sdp.System.Drawing.ColorTable, $.$sdp.System.Drawing.ColorTable.GetColors));
                    //--TRIMMABLE-BOUNDARY-END(34359935001)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295163929)
            
            static $h = 196633;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590131225),
    {
      "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475033113,
        "f": 50331688
      },
      "n": "Colors",
      "d": 196633,
      "h": 8590131225,
      "f": 2097192
    },
//--TRIMMABLE-BOUNDARY-END(8590131225)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770000409),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,
      "n": "GetColors",
      "d": 196633,
      "h": 25770000409,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770000409),
//--TRIMMABLE-BOUNDARY-START(12885098521),
    {
      "r": 65537,
      "p": [
        {
          "n": "dictionary",
          "p": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h
        },
        {
          "n": "typeWithColors",
          "p": 187760641
        }
      ],
      "n": "FillWithProperties",
      "d": 196633,
      "h": 12885098521,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885098521),
//--TRIMMABLE-BOUNDARY-START(38654902297),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "result",
          "p": 65561,
          "f": 2
        }
      ],
      "n": "TryGetNamedColor",
      "d": 196633,
      "h": 38654902297,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(38654902297),
//--TRIMMABLE-BOUNDARY-START(30064967705),
    {
      "r": 262145,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "IsKnownNamedColor",
      "d": 196633,
      "h": 30064967705,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(30064967705)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34359935001),
    {
      "t": $.$$.System.Lazy$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)).$h,
      "n": "s_colorConstants",
      "d": 196633,
      "h": 34359935001,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(34359935001)
  ],
  "h": 196633
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196633)
        
        
        //--TRIMMABLE-BOUNDARY-START(131097)
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            //--TRIMMABLE-BOUNDARY-START(4295098393)
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(culture !== null, "culture != null");
                /*string*/ let text = $.$$.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$$.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$$.System.String.Contains$1.call(text, sep))
                {
                    if (text.length >= 2 && ($.$$.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$$.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$$.System.String.get_Chars.call(text, 0) === $.$$.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$$.System.String.Substring.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$$.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$$.System.String.StartsWith$3.call(text, "0x") || $.$$.System.String.StartsWith$3.call(text, "0X"))) || (text.length === 8 && ($.$$.System.String.StartsWith$3.call(text, "&h") || $.$$.System.String.StartsWith$3.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$3(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$$.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$$.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$$.System.MemoryExtensions.Split(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$3($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sdp.System.SR.Format$6($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098393)
            
            //--TRIMMABLE-BOUNDARY-START(12885032985)
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            //--TRIMMABLE-BOUNDARY-END(12885032985)
            
            //--TRIMMABLE-BOUNDARY-START(8590065689)
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                text = $.$$.System.MemoryExtensions.Trim$4(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$$.System.Convert.ToInt32$14($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text.Slice$1(1)), 16);
                    }
                    else if ($.$$.System.MemoryExtensions.StartsWith(text, $.$$.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.MemoryExtensions.StartsWith(text, $.$$.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$$.System.Convert.ToInt32$14($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text.Slice$1(2)), 16);
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$$.System.Globalization.NumberFormatInfo.$type), $.$$.System.Globalization.NumberFormatInfo);
                        return $.$$.System.Int32.Parse$3(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$5($.$sdp.System.SR.ConvertInvalidPrimitive, $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590065689)
            
            static $h = 131097;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295098393),
    {
      "r": 65561,
      "p": [
        {
          "n": "strValue",
          "p": 1310721
        },
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "ConvertFromString",
      "d": 131097,
      "h": 4295098393,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295098393),
//--TRIMMABLE-BOUNDARY-START(12885032985),
    {
      "r": 65561,
      "p": [
        {
          "n": "color",
          "p": 65561
        }
      ],
      "n": "PossibleKnownColor",
      "d": 131097,
      "h": 12885032985,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12885032985),
//--TRIMMABLE-BOUNDARY-START(8590065689),
    {
      "r": 655361,
      "p": [
        {
          "n": "text",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "culture",
          "p": 83951617
        }
      ],
      "n": "IntFromString",
      "d": 131097,
      "h": 8590065689,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590065689)
  ],
  "h": 131097
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131097)
        
        
        //--TRIMMABLE-BOUNDARY-START(458777)
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            //--TRIMMABLE-BOUNDARY-START(55835033625)
            /*byte*/ static KnownColorKindSystem = 0;
            //--TRIMMABLE-BOUNDARY-END(55835033625)
            
            //--TRIMMABLE-BOUNDARY-START(64424968217)
            /*byte*/ static KnownColorKindWeb = 1;
            //--TRIMMABLE-BOUNDARY-END(64424968217)
            
            //--TRIMMABLE-BOUNDARY-START(60130000921)
            /*byte*/ static KnownColorKindUnknown = 2;
            //--TRIMMABLE-BOUNDARY-END(60130000921)
            
            //--TRIMMABLE-BOUNDARY-START(17180327961)
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.UInt32))().$ctor$4([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(17180327961)
            
            //--TRIMMABLE-BOUNDARY-START(12885360665)
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            //--TRIMMABLE-BOUNDARY-END(12885360665)
            
            //--TRIMMABLE-BOUNDARY-START(4295426073)
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.UInt32))().$ctor$4([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            //--TRIMMABLE-BOUNDARY-END(4295426073)
            
            //--TRIMMABLE-BOUNDARY-START(8590393369)
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$$.System.Diagnostics.Debug.Assert$2($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$3((argb | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(8590393369)
            
            //--TRIMMABLE-BOUNDARY-START(68719935513)
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(68719935513)
            
            //--TRIMMABLE-BOUNDARY-START(47245099033)
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            //--TRIMMABLE-BOUNDARY-END(47245099033)
            
            //--TRIMMABLE-BOUNDARY-START(51540066329)
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            //--TRIMMABLE-BOUNDARY-END(51540066329)
            
            static $h = 458777;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180327961),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.UInt32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950131737,
        "f": 50331681
      },
      "n": "ColorValueTable",
      "d": 458777,
      "h": 17180327961,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17180327961),
//--TRIMMABLE-BOUNDARY-START(12885360665),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360197145,
        "f": 50331681
      },
      "n": "ColorKindTable",
      "d": 458777,
      "h": 12885360665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12885360665),
//--TRIMMABLE-BOUNDARY-START(4295426073),
    {
      "p": $.$$.System.ReadOnlySpan$$($.$$.System.UInt32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770262553,
        "f": 50331682
      },
      "n": "AlternateSystemColors",
      "d": 458777,
      "h": 4295426073,
      "f": 2097186
    },
//--TRIMMABLE-BOUNDARY-END(4295426073)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393369),
    {
      "r": 65561,
      "p": [
        {
          "n": "argb",
          "p": 720897
        }
      ],
      "n": "ArgbToKnownColor",
      "d": 458777,
      "h": 8590393369,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590393369),
//--TRIMMABLE-BOUNDARY-START(68719935513),
    {
      "r": 720897,
      "p": [
        {
          "n": "color",
          "p": 327705
        }
      ],
      "n": "KnownColorToArgb",
      "d": 458777,
      "h": 68719935513,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719935513),
//--TRIMMABLE-BOUNDARY-START(47245099033),
    {
      "r": 720897,
      "p": [
        {
          "n": "color",
          "p": 327705
        }
      ],
      "n": "GetAlternateSystemColorArgb",
      "d": 458777,
      "h": 47245099033,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245099033),
//--TRIMMABLE-BOUNDARY-START(51540066329),
    {
      "r": 720897,
      "p": [
        {
          "n": "color",
          "p": 327705
        }
      ],
      "n": "GetSystemColorArgb",
      "d": 458777,
      "h": 51540066329,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540066329)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835033625),
    {
      "t": 393217,
      "n": "KnownColorKindSystem",
      "d": 458777,
      "h": 55835033625,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835033625),
//--TRIMMABLE-BOUNDARY-START(64424968217),
    {
      "t": 393217,
      "n": "KnownColorKindWeb",
      "d": 458777,
      "h": 64424968217,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424968217),
//--TRIMMABLE-BOUNDARY-START(60130000921),
    {
      "t": 393217,
      "n": "KnownColorKindUnknown",
      "d": 458777,
      "h": 60130000921,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130000921)
  ],
  "h": 458777
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458777)
        
        
        //--TRIMMABLE-BOUNDARY-START(262169)
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            //--TRIMMABLE-BOUNDARY-START(12885164057)
            /*int*/ static COLORREF_RedShift = 0;
            //--TRIMMABLE-BOUNDARY-END(12885164057)
            
            //--TRIMMABLE-BOUNDARY-START(8590196761)
            /*int*/ static COLORREF_GreenShift = 8;
            //--TRIMMABLE-BOUNDARY-END(8590196761)
            
            //--TRIMMABLE-BOUNDARY-START(4295229465)
            /*int*/ static COLORREF_BlueShift = 16;
            //--TRIMMABLE-BOUNDARY-END(4295229465)
            
            //--TRIMMABLE-BOUNDARY-START(38654967833)
            /*int*/ static OleSystemColorFlag = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(38654967833)
            
            //--TRIMMABLE-BOUNDARY-START(42949935129)
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            //--TRIMMABLE-BOUNDARY-END(42949935129)
            
            //--TRIMMABLE-BOUNDARY-START(17180131353)
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180131353)
            
            //--TRIMMABLE-BOUNDARY-START(55834837017)
            static /*int */ ToWin32(/*Color*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            //--TRIMMABLE-BOUNDARY-END(55834837017)
            
            //--TRIMMABLE-BOUNDARY-START(51539869721)
            static /*int */ ToOle(/*Color*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539869721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            //--TRIMMABLE-BOUNDARY-END(51539869721)
            
            //--TRIMMABLE-BOUNDARY-START(25770065945)
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            //--TRIMMABLE-BOUNDARY-END(25770065945)
            
            //--TRIMMABLE-BOUNDARY-START(30065033241)
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            //--TRIMMABLE-BOUNDARY-END(30065033241)
            
            //--TRIMMABLE-BOUNDARY-START(21475098649)
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$$.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$$.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$1($.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 1, 2), 16), $.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 3, 2), 16), $.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$1($.$$.System.Convert.ToInt32$14(r + r, 16), $.$$.System.Convert.ToInt32$14(g + g, 16), $.$$.System.Convert.ToInt32$14(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$$.System.String.Equals$2(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$$.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$$.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098649)
            
            //--TRIMMABLE-BOUNDARY-START(47244902425)
            static /*string */ ToHtml(/*Color*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let colorString = $.$$.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted($.$box(r, $.$$.System.Int32), null, "X2");
                        $handler.AppendFormatted($.$box(g, $.$$.System.Int32), null, "X2");
                        $handler.AppendFormatted($.$box(b, $.$$.System.Int32), null, "X2");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                return colorString;
            }
            //--TRIMMABLE-BOUNDARY-END(47244902425)
            
            //--TRIMMABLE-BOUNDARY-START(34360000537)
            static /*void */ InitializeHtmlSysColorTable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360000537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$8(27);
                    $i1.set_Item("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.set_Item("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.set_Item("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.set_Item("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.set_Item("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.set_Item("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.set_Item("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.set_Item("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.set_Item("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.set_Item("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.set_Item("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.set_Item("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.set_Item("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.set_Item("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.set_Item("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.set_Item("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.set_Item("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.set_Item("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.set_Item("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.set_Item("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.set_Item("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.set_Item("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.set_Item("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(34360000537)
            
            static $h = 262169;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131353),
    {
      "r": 720897,
      "p": [
        {
          "n": "value",
          "p": 720897
        }
      ],
      "n": "COLORREFToARGB",
      "d": 262169,
      "h": 17180131353,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180131353),
//--TRIMMABLE-BOUNDARY-START(55834837017),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 65561
        }
      ],
      "n": "ToWin32",
      "d": 262169,
      "h": 55834837017,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834837017),
//--TRIMMABLE-BOUNDARY-START(51539869721),
    {
      "r": 655361,
      "p": [
        {
          "n": "c",
          "p": 65561
        }
      ],
      "n": "ToOle",
      "d": 262169,
      "h": 51539869721,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539869721),
//--TRIMMABLE-BOUNDARY-START(25770065945),
    {
      "r": 65561,
      "p": [
        {
          "n": "oleColor",
          "p": 655361
        }
      ],
      "n": "FromOle",
      "d": 262169,
      "h": 25770065945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770065945),
//--TRIMMABLE-BOUNDARY-START(30065033241),
    {
      "r": 65561,
      "p": [
        {
          "n": "win32Color",
          "p": 655361
        }
      ],
      "n": "FromWin32",
      "d": 262169,
      "h": 30065033241,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065033241),
//--TRIMMABLE-BOUNDARY-START(21475098649),
    {
      "r": 65561,
      "p": [
        {
          "n": "htmlColor",
          "p": 1310721
        }
      ],
      "n": "FromHtml",
      "d": 262169,
      "h": 21475098649,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475098649),
//--TRIMMABLE-BOUNDARY-START(47244902425),
    {
      "r": 1310721,
      "p": [
        {
          "n": "c",
          "p": 65561
        }
      ],
      "n": "ToHtml",
      "d": 262169,
      "h": 47244902425,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244902425),
//--TRIMMABLE-BOUNDARY-START(34360000537),
    {
      "r": 65537,
      "n": "InitializeHtmlSysColorTable",
      "d": 262169,
      "h": 34360000537,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360000537)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885164057),
    {
      "t": 655361,
      "n": "COLORREF_RedShift",
      "d": 262169,
      "h": 12885164057,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885164057),
//--TRIMMABLE-BOUNDARY-START(8590196761),
    {
      "t": 655361,
      "n": "COLORREF_GreenShift",
      "d": 262169,
      "h": 8590196761,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590196761),
//--TRIMMABLE-BOUNDARY-START(4295229465),
    {
      "t": 655361,
      "n": "COLORREF_BlueShift",
      "d": 262169,
      "h": 4295229465,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295229465),
//--TRIMMABLE-BOUNDARY-START(38654967833),
    {
      "t": 655361,
      "n": "OleSystemColorFlag",
      "d": 262169,
      "h": 38654967833,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38654967833),
//--TRIMMABLE-BOUNDARY-START(42949935129),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,
      "n": "s_htmlSysColorTable",
      "d": 262169,
      "h": 42949935129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949935129)
  ],
  "h": 262169
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262169)
        
        
        //--TRIMMABLE-BOUNDARY-START(655385)
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38655361049)
            /*Rectangle*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(38655361049)
            
            //--TRIMMABLE-BOUNDARY-START(309238300697)
            /*int*/  get x() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(309238300697)
            
            //--TRIMMABLE-BOUNDARY-START(317828235289)
            /*int*/  get y() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(317828235289)
            
            //--TRIMMABLE-BOUNDARY-START(300648366105)
            /*int*/  get width() { return this.$getField(8, $.$$.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(300648366105)
            
            //--TRIMMABLE-BOUNDARY-START(154619478041)
            /*int*/  get height() { return this.$getField(12, $.$$.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(154619478041)
            
            //--TRIMMABLE-BOUNDARY-START(8590589977)
            $ctor$3(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590589977);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590589977)
            
            //--TRIMMABLE-BOUNDARY-START(12885557273)
            $ctor$4(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885557273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885557273)
            
            //--TRIMMABLE-BOUNDARY-START(51540262937)
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540262937);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3(left, top, ((right - left) | 0), ((bottom - top) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540262937)
            
            //--TRIMMABLE-BOUNDARY-START(197569151001)
            /*Point */ get Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489935897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sdp.System.Drawing.Point().$ctor$3(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518823961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.X = value.X;
                this.Y = value.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(197569151001)
            
            //--TRIMMABLE-BOUNDARY-START(279173529625)
            /*Size */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669805081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108758553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Width = value.Width;
                this.Height = value.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(279173529625)
            
            //--TRIMMABLE-BOUNDARY-START(313533267993)
            /*int */ get X()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439608857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x;
            }
            /*int */ set X(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288627737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x = value;
            }
            //--TRIMMABLE-BOUNDARY-END(313533267993)
            
            //--TRIMMABLE-BOUNDARY-START(322123202585)
            /*int */ get Y()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029543449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y;
            }
            /*int */ set Y(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878562329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y = value;
            }
            //--TRIMMABLE-BOUNDARY-END(322123202585)
            
            //--TRIMMABLE-BOUNDARY-START(304943333401)
            /*int */ get Width()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849674265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width;
            }
            /*int */ set Width(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698693145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width = value;
            }
            //--TRIMMABLE-BOUNDARY-END(304943333401)
            
            //--TRIMMABLE-BOUNDARY-START(158914445337)
            /*int */ get Height()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height;
            }
            /*int */ set Height(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928889369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height = value;
            }
            //--TRIMMABLE-BOUNDARY-END(158914445337)
            
            //--TRIMMABLE-BOUNDARY-START(193274183705)
            /*int */ get Left()
            {
                return this.X;
            }
            //--TRIMMABLE-BOUNDARY-END(193274183705)
            
            //--TRIMMABLE-BOUNDARY-START(283468496921)
            /*int */ get Top()
            {
                return this.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(283468496921)
            
            //--TRIMMABLE-BOUNDARY-START(219043987481)
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(219043987481)
            
            //--TRIMMABLE-BOUNDARY-START(17180524569)
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(17180524569)
            
            //--TRIMMABLE-BOUNDARY-START(188979216409)
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(188979216409)
            
            //--TRIMMABLE-BOUNDARY-START(42950328345)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950328345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Rectangle.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(42950328345)
            
            //--TRIMMABLE-BOUNDARY-START(47245295641)
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245295641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245295641)
            
            //--TRIMMABLE-BOUNDARY-START(210454052889)
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                {
                    return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(210454052889)
            
            //--TRIMMABLE-BOUNDARY-START(214749020185)
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                {
                    return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214749020185)
            
            //--TRIMMABLE-BOUNDARY-START(21475491865)
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475491865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast(Math.ceil(value.X), $.$$.System.Int32), $.$cast(Math.ceil(value.Y), $.$$.System.Int32), $.$cast(Math.ceil(value.Width), $.$$.System.Int32), $.$cast(Math.ceil(value.Height), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475491865)
            
            //--TRIMMABLE-BOUNDARY-START(292058431513)
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058431513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast(value.X, $.$$.System.Int32), $.$cast(value.Y, $.$$.System.Int32), $.$cast(value.Width, $.$$.System.Int32), $.$cast(value.Height, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292058431513)
            
            //--TRIMMABLE-BOUNDARY-START(223338954777)
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338954777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast($.$$.System.Math.Round$7(value.X), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Y), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Width), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Height), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338954777)
            
            //--TRIMMABLE-BOUNDARY-START(25770459161)
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770459161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770459161)
            
            //--TRIMMABLE-BOUNDARY-START(30065426457)
            /*bool */ Contains$1(/*Point*/ pt)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065426457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Contains(pt.X, pt.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065426457)
            
            //--TRIMMABLE-BOUNDARY-START(34360393753)
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360393753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360393753)
            
            //--TRIMMABLE-BOUNDARY-START(150324510745)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324510745);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$4($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, this.X, this.Y, this.Width, this.Height);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(150324510745)
            
            //--TRIMMABLE-BOUNDARY-START(163209412633)
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209412633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209412633)
            
            //--TRIMMABLE-BOUNDARY-START(171799347225)
            /*void */ Inflate$2(/*Size*/ size)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799347225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Inflate(size.Width, size.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799347225)
            
            //--TRIMMABLE-BOUNDARY-START(167504379929)
            static /*Rectangle */ Inflate$1(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504379929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            //--TRIMMABLE-BOUNDARY-END(167504379929)
            
            //--TRIMMABLE-BOUNDARY-START(180389281817)
            /*void */ Intersect$1(/*Rectangle*/ rect)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389281817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(180389281817)
            
            //--TRIMMABLE-BOUNDARY-START(176094314521)
            static /*Rectangle */ Intersect(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094314521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let x1 = $.$$.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$$.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$$.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$$.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(176094314521)
            
            //--TRIMMABLE-BOUNDARY-START(184684249113)
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684249113);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684249113)
            
            //--TRIMMABLE-BOUNDARY-START(296353398809)
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353398809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let x1 = $.$$.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$$.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$$.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$$.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$3(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            //--TRIMMABLE-BOUNDARY-END(296353398809)
            
            //--TRIMMABLE-BOUNDARY-START(206159085593)
            /*void */ Offset$1(/*Point*/ pos)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(206159085593);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Offset(pos.X, pos.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(206159085593)
            
            //--TRIMMABLE-BOUNDARY-START(201864118297)
            /*void */ Offset(/*int*/ x, /*int*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864118297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864118297)
            
            //--TRIMMABLE-BOUNDARY-START(287763464217)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287763464217);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(287763464217)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(4295622681)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622681)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(309238300697)
                this.x = 0;
                //--TRIMMABLE-BOUNDARY-END(309238300697)
                
                //--TRIMMABLE-BOUNDARY-START(317828235289)
                this.y = 0;
                //--TRIMMABLE-BOUNDARY-END(317828235289)
                
                //--TRIMMABLE-BOUNDARY-START(300648366105)
                this.width = 0;
                //--TRIMMABLE-BOUNDARY-END(300648366105)
                
                //--TRIMMABLE-BOUNDARY-START(154619478041)
                this.height = 0;
                //--TRIMMABLE-BOUNDARY-END(154619478041)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655361049)
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                    //--TRIMMABLE-BOUNDARY-END(38655361049)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 655385;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(197569151001),
    {
      "p": 524313,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518823961,
        "f": 83886081
      },
      "n": "Location",
      "d": 655385,
      "h": 197569151001,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(197569151001),
//--TRIMMABLE-BOUNDARY-START(279173529625),
    {
      "p": 786457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805081,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108758553,
        "f": 83886081
      },
      "n": "Size",
      "d": 655385,
      "h": 279173529625,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173529625),
//--TRIMMABLE-BOUNDARY-START(313533267993),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288627737,
        "f": 83886081
      },
      "n": "X",
      "d": 655385,
      "h": 313533267993,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313533267993),
//--TRIMMABLE-BOUNDARY-START(322123202585),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878562329,
        "f": 83886081
      },
      "n": "Y",
      "d": 655385,
      "h": 322123202585,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322123202585),
//--TRIMMABLE-BOUNDARY-START(304943333401),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698693145,
        "f": 83886081
      },
      "n": "Width",
      "d": 655385,
      "h": 304943333401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304943333401),
//--TRIMMABLE-BOUNDARY-START(158914445337),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132121,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928889369,
        "f": 83886081
      },
      "n": "Height",
      "d": 655385,
      "h": 158914445337,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914445337),
//--TRIMMABLE-BOUNDARY-START(193274183705),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001305,
        "f": 50331649
      },
      "n": "Left",
      "d": 655385,
      "h": 193274183705,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(193274183705),
//--TRIMMABLE-BOUNDARY-START(283468496921),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739673,
        "f": 50331649
      },
      "n": "Top",
      "d": 655385,
      "h": 283468496921,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468496921),
//--TRIMMABLE-BOUNDARY-START(219043987481),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870489,
        "f": 50331649
      },
      "n": "Right",
      "d": 655385,
      "h": 219043987481,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043987481),
//--TRIMMABLE-BOUNDARY-START(17180524569),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197529,
        "f": 50331649
      },
      "n": "Bottom",
      "d": 655385,
      "h": 17180524569,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180524569),
//--TRIMMABLE-BOUNDARY-START(188979216409),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066713,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 655385,
      "h": 188979216409,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(188979216409)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540262937),
    {
      "r": 655385,
      "p": [
        {
          "n": "left",
          "p": 655361
        },
        {
          "n": "top",
          "p": 655361
        },
        {
          "n": "right",
          "p": 655361
        },
        {
          "n": "bottom",
          "p": 655361
        }
      ],
      "n": "FromLTRB",
      "d": 655385,
      "h": 51540262937,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540262937),
//--TRIMMABLE-BOUNDARY-START(42950328345),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 655385,
      "h": 42950328345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950328345),
//--TRIMMABLE-BOUNDARY-START(47245295641),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 655385
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 655385,
      "h": 47245295641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245295641),
//--TRIMMABLE-BOUNDARY-START(21475491865),
    {
      "r": 655385,
      "p": [
        {
          "n": "value",
          "p": 720921
        }
      ],
      "n": "Ceiling",
      "d": 655385,
      "h": 21475491865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475491865),
//--TRIMMABLE-BOUNDARY-START(292058431513),
    {
      "r": 655385,
      "p": [
        {
          "n": "value",
          "p": 720921
        }
      ],
      "n": "Truncate",
      "d": 655385,
      "h": 292058431513,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(292058431513),
//--TRIMMABLE-BOUNDARY-START(223338954777),
    {
      "r": 655385,
      "p": [
        {
          "n": "value",
          "p": 720921
        }
      ],
      "n": "Round",
      "d": 655385,
      "h": 223338954777,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(223338954777),
//--TRIMMABLE-BOUNDARY-START(25770459161),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "Contains",
      "d": 655385,
      "h": 25770459161,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770459161),
//--TRIMMABLE-BOUNDARY-START(30065426457),
    {
      "r": 262145,
      "p": [
        {
          "n": "pt",
          "p": 524313
        }
      ],
      "n": "Contains",
      "o": "@$1",
      "d": 655385,
      "h": 30065426457,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065426457),
//--TRIMMABLE-BOUNDARY-START(34360393753),
    {
      "r": 262145,
      "p": [
        {
          "n": "rect",
          "p": 655385
        }
      ],
      "n": "Contains",
      "o": "@$2",
      "d": 655385,
      "h": 34360393753,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360393753),
//--TRIMMABLE-BOUNDARY-START(150324510745),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 655385,
      "h": 150324510745,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324510745),
//--TRIMMABLE-BOUNDARY-START(163209412633),
    {
      "r": 65537,
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": "Inflate",
      "d": 655385,
      "h": 163209412633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209412633),
//--TRIMMABLE-BOUNDARY-START(171799347225),
    {
      "r": 65537,
      "p": [
        {
          "n": "size",
          "p": 786457
        }
      ],
      "n": "Inflate",
      "o": "@$2",
      "d": 655385,
      "h": 171799347225,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799347225),
//--TRIMMABLE-BOUNDARY-START(167504379929),
    {
      "r": 655385,
      "p": [
        {
          "n": "rect",
          "p": 655385
        },
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "Inflate",
      "o": "@$1",
      "d": 655385,
      "h": 167504379929,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(167504379929),
//--TRIMMABLE-BOUNDARY-START(180389281817),
    {
      "r": 65537,
      "p": [
        {
          "n": "rect",
          "p": 655385
        }
      ],
      "n": "Intersect",
      "o": "@$1",
      "d": 655385,
      "h": 180389281817,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389281817),
//--TRIMMABLE-BOUNDARY-START(176094314521),
    {
      "r": 655385,
      "p": [
        {
          "n": "a",
          "p": 655385
        },
        {
          "n": "b",
          "p": 655385
        }
      ],
      "n": "Intersect",
      "d": 655385,
      "h": 176094314521,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(176094314521),
//--TRIMMABLE-BOUNDARY-START(184684249113),
    {
      "r": 262145,
      "p": [
        {
          "n": "rect",
          "p": 655385
        }
      ],
      "n": "IntersectsWith",
      "d": 655385,
      "h": 184684249113,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684249113),
//--TRIMMABLE-BOUNDARY-START(296353398809),
    {
      "r": 655385,
      "p": [
        {
          "n": "a",
          "p": 655385
        },
        {
          "n": "b",
          "p": 655385
        }
      ],
      "n": "Union",
      "d": 655385,
      "h": 296353398809,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(296353398809),
//--TRIMMABLE-BOUNDARY-START(206159085593),
    {
      "r": 65537,
      "p": [
        {
          "n": "pos",
          "p": 524313
        }
      ],
      "n": "Offset",
      "o": "@$1",
      "d": 655385,
      "h": 206159085593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(206159085593),
//--TRIMMABLE-BOUNDARY-START(201864118297),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": "Offset",
      "d": 655385,
      "h": 201864118297,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864118297),
//--TRIMMABLE-BOUNDARY-START(287763464217),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 655385,
      "h": 287763464217,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(287763464217)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655361049),
    {
      "t": 655385,
      "n": "Empty",
      "d": 655385,
      "h": 38655361049,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655361049),
//--TRIMMABLE-BOUNDARY-START(309238300697),
    {
      "t": 655361,
      "n": "x",
      "d": 655385,
      "h": 309238300697,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(309238300697),
//--TRIMMABLE-BOUNDARY-START(317828235289),
    {
      "t": 655361,
      "n": "y",
      "d": 655385,
      "h": 317828235289,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(317828235289),
//--TRIMMABLE-BOUNDARY-START(300648366105),
    {
      "t": 655361,
      "n": "width",
      "d": 655385,
      "h": 300648366105,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(300648366105),
//--TRIMMABLE-BOUNDARY-START(154619478041),
    {
      "t": 655361,
      "n": "height",
      "d": 655385,
      "h": 154619478041,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154619478041)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590589977),
    {
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        },
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655385,
      "h": 8590589977,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590589977),
//--TRIMMABLE-BOUNDARY-START(12885557273),
    {
      "p": [
        {
          "n": "location",
          "p": 524313
        },
        {
          "n": "size",
          "p": 786457
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 655385,
      "h": 12885557273,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885557273),
//--TRIMMABLE-BOUNDARY-START(4295622681),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655385,
      "h": 4295622681,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622681)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h
  ],
  "h": 655385,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655385)
        
        
        //--TRIMMABLE-BOUNDARY-START(720921)
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(51540328473)
            /*RectangleF*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(51540328473)
            
            //--TRIMMABLE-BOUNDARY-START(317828300825)
            /*float*/  get x() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(317828300825)
            
            //--TRIMMABLE-BOUNDARY-START(326418235417)
            /*float*/  get y() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(326418235417)
            
            //--TRIMMABLE-BOUNDARY-START(309238366233)
            /*float*/  get width() { return this.$getField(8, $.$$.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(309238366233)
            
            //--TRIMMABLE-BOUNDARY-START(167504445465)
            /*float*/  get height() { return this.$getField(12, $.$$.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(167504445465)
            
            //--TRIMMABLE-BOUNDARY-START(25770524697)
            $ctor$4(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770524697);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770524697)
            
            //--TRIMMABLE-BOUNDARY-START(30065491993)
            $ctor$5(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065491993);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065491993)
            
            //--TRIMMABLE-BOUNDARY-START(21475557401)
            $ctor$3(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475557401);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475557401)
            
            //--TRIMMABLE-BOUNDARY-START(300648431641)
            /*Vector4 */ ToVector4()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(300648431641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.Numerics.Vector4().$ctor$6(this.x, this.y, this.width, this.height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(300648431641)
            
            //--TRIMMABLE-BOUNDARY-START(4295688217)
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                {
                    return rectangle.ToVector4();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295688217)
            
            //--TRIMMABLE-BOUNDARY-START(8590655513)
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$3(vector.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590655513)
            
            //--TRIMMABLE-BOUNDARY-START(64425230361)
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425230361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$4(left, top, right - left, bottom - top);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425230361)
            
            //--TRIMMABLE-BOUNDARY-START(210454118425)
            /*PointF */ get Location()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sdp.System.Drawing.PointF().$ctor$4(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108824089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.X = value.X;
                this.Y = value.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(210454118425)
            
            //--TRIMMABLE-BOUNDARY-START(287763529753)
            /*SizeF */ get Size()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698758681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Width = value.Width;
                this.Height = value.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(287763529753)
            
            //--TRIMMABLE-BOUNDARY-START(322123268121)
            /*float */ get X()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x;
            }
            /*float */ set X(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878627865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x = value;
            }
            //--TRIMMABLE-BOUNDARY-END(322123268121)
            
            //--TRIMMABLE-BOUNDARY-START(330713202713)
            /*float */ get Y()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y;
            }
            /*float */ set Y(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468562457);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y = value;
            }
            //--TRIMMABLE-BOUNDARY-END(330713202713)
            
            //--TRIMMABLE-BOUNDARY-START(313533333529)
            /*float */ get Width()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width;
            }
            /*float */ set Width(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width = value;
            }
            //--TRIMMABLE-BOUNDARY-END(313533333529)
            
            //--TRIMMABLE-BOUNDARY-START(171799412761)
            /*float */ get Height()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height;
            }
            /*float */ set Height(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518889497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height = value;
            }
            //--TRIMMABLE-BOUNDARY-END(171799412761)
            
            //--TRIMMABLE-BOUNDARY-START(206159151129)
            /*float */ get Left()
            {
                return this.X;
            }
            //--TRIMMABLE-BOUNDARY-END(206159151129)
            
            //--TRIMMABLE-BOUNDARY-START(292058497049)
            /*float */ get Top()
            {
                return this.Y;
            }
            //--TRIMMABLE-BOUNDARY-END(292058497049)
            
            //--TRIMMABLE-BOUNDARY-START(231928954905)
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            //--TRIMMABLE-BOUNDARY-END(231928954905)
            
            //--TRIMMABLE-BOUNDARY-START(34360459289)
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(34360459289)
            
            //--TRIMMABLE-BOUNDARY-START(201864183833)
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            //--TRIMMABLE-BOUNDARY-END(201864183833)
            
            //--TRIMMABLE-BOUNDARY-START(55835295769)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835295769);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.RectangleF.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(55835295769)
            
            //--TRIMMABLE-BOUNDARY-START(60130263065)
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130263065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130263065)
            
            //--TRIMMABLE-BOUNDARY-START(223339020313)
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                {
                    return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339020313)
            
            //--TRIMMABLE-BOUNDARY-START(227633987609)
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                {
                    return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633987609)
            
            //--TRIMMABLE-BOUNDARY-START(38655426585)
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655426585);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655426585)
            
            //--TRIMMABLE-BOUNDARY-START(42950393881)
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950393881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Contains(pt.X, pt.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950393881)
            
            //--TRIMMABLE-BOUNDARY-START(47245361177)
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245361177);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245361177)
            
            //--TRIMMABLE-BOUNDARY-START(163209478169)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209478169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$4($.$$.System.Single, $.$$.System.Single, $.$$.System.Single, $.$$.System.Single, this.X, this.Y, this.Width, this.Height);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(163209478169)
            
            //--TRIMMABLE-BOUNDARY-START(176094380057)
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094380057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            //--TRIMMABLE-BOUNDARY-END(176094380057)
            
            //--TRIMMABLE-BOUNDARY-START(184684314649)
            /*void */ Inflate$2(/*SizeF*/ size)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684314649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Inflate(size.Width, size.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684314649)
            
            //--TRIMMABLE-BOUNDARY-START(180389347353)
            static /*RectangleF */ Inflate$1(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            //--TRIMMABLE-BOUNDARY-END(180389347353)
            
            //--TRIMMABLE-BOUNDARY-START(193274249241)
            /*void */ Intersect$1(/*RectangleF*/ rect)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274249241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            //--TRIMMABLE-BOUNDARY-END(193274249241)
            
            //--TRIMMABLE-BOUNDARY-START(188979281945)
            static /*RectangleF */ Intersect(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979281945);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*float*/ let x1 = $.$$.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$$.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$$.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$$.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$4(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(188979281945)
            
            //--TRIMMABLE-BOUNDARY-START(197569216537)
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(197569216537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(197569216537)
            
            //--TRIMMABLE-BOUNDARY-START(304943398937)
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943398937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*float*/ let x1 = $.$$.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$$.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$$.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$$.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(x1, y1, x2 - x1, y2 - y1);
            }
            //--TRIMMABLE-BOUNDARY-END(304943398937)
            
            //--TRIMMABLE-BOUNDARY-START(219044053017)
            /*void */ Offset$1(/*PointF*/ pos)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219044053017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Offset(pos.X, pos.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219044053017)
            
            //--TRIMMABLE-BOUNDARY-START(214749085721)
            /*void */ Offset(/*float*/ x, /*float*/ y)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749085721);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.X += x;
                this.Y += y;
            }
            //--TRIMMABLE-BOUNDARY-END(214749085721)
            
            //--TRIMMABLE-BOUNDARY-START(12885622809)
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$4(r.X, r.Y, r.Width, r.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885622809)
            
            //--TRIMMABLE-BOUNDARY-START(296353464345)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(296353464345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(296353464345)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(17180590105)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590105)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(317828300825)
                this.x = 0;
                //--TRIMMABLE-BOUNDARY-END(317828300825)
                
                //--TRIMMABLE-BOUNDARY-START(326418235417)
                this.y = 0;
                //--TRIMMABLE-BOUNDARY-END(326418235417)
                
                //--TRIMMABLE-BOUNDARY-START(309238366233)
                this.width = 0;
                //--TRIMMABLE-BOUNDARY-END(309238366233)
                
                //--TRIMMABLE-BOUNDARY-START(167504445465)
                this.height = 0;
                //--TRIMMABLE-BOUNDARY-END(167504445465)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328473)
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                    //--TRIMMABLE-BOUNDARY-END(51540328473)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 720921;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(210454118425),
    {
      "p": 589849,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903321,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108824089,
        "f": 83886081
      },
      "n": "Location",
      "d": 720921,
      "h": 210454118425,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(210454118425),
//--TRIMMABLE-BOUNDARY-START(287763529753),
    {
      "p": 851993,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554772505,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698758681,
        "f": 83886081
      },
      "n": "Size",
      "d": 720921,
      "h": 287763529753,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763529753),
//--TRIMMABLE-BOUNDARY-START(322123268121),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324576281,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878627865,
        "f": 83886081
      },
      "n": "X",
      "d": 720921,
      "h": 322123268121,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(322123268121),
//--TRIMMABLE-BOUNDARY-START(330713202713),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914510873,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283468562457,
        "f": 83886081
      },
      "n": "Y",
      "d": 720921,
      "h": 330713202713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(330713202713),
//--TRIMMABLE-BOUNDARY-START(313533333529),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734641689,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288693273,
        "f": 83886081
      },
      "n": "Width",
      "d": 720921,
      "h": 313533333529,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(313533333529),
//--TRIMMABLE-BOUNDARY-START(171799412761),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099545,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518889497,
        "f": 83886081
      },
      "n": "Height",
      "d": 720921,
      "h": 171799412761,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799412761),
//--TRIMMABLE-BOUNDARY-START(206159151129),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968729,
        "f": 50331649
      },
      "n": "Left",
      "d": 720921,
      "h": 206159151129,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(206159151129),
//--TRIMMABLE-BOUNDARY-START(292058497049),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144707097,
        "f": 50331649
      },
      "n": "Top",
      "d": 720921,
      "h": 292058497049,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(292058497049),
//--TRIMMABLE-BOUNDARY-START(231928954905),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837913,
        "f": 50331649
      },
      "n": "Right",
      "d": 720921,
      "h": 231928954905,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928954905),
//--TRIMMABLE-BOUNDARY-START(34360459289),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015164953,
        "f": 50331649
      },
      "n": "Bottom",
      "d": 720921,
      "h": 34360459289,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360459289),
//--TRIMMABLE-BOUNDARY-START(201864183833),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034137,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 720921,
      "h": 201864183833,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(201864183833)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(300648431641),
    {
      "r": 103546881,
      "n": "ToVector4",
      "d": 720921,
      "h": 300648431641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648431641),
//--TRIMMABLE-BOUNDARY-START(64425230361),
    {
      "r": 720921,
      "p": [
        {
          "n": "left",
          "p": 1114113
        },
        {
          "n": "top",
          "p": 1114113
        },
        {
          "n": "right",
          "p": 1114113
        },
        {
          "n": "bottom",
          "p": 1114113
        }
      ],
      "n": "FromLTRB",
      "d": 720921,
      "h": 64425230361,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425230361),
//--TRIMMABLE-BOUNDARY-START(55835295769),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 720921,
      "h": 55835295769,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835295769),
//--TRIMMABLE-BOUNDARY-START(60130263065),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 720921
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 720921,
      "h": 60130263065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130263065),
//--TRIMMABLE-BOUNDARY-START(38655426585),
    {
      "r": 262145,
      "p": [
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "Contains",
      "d": 720921,
      "h": 38655426585,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426585),
//--TRIMMABLE-BOUNDARY-START(42950393881),
    {
      "r": 262145,
      "p": [
        {
          "n": "pt",
          "p": 589849
        }
      ],
      "n": "Contains",
      "o": "@$1",
      "d": 720921,
      "h": 42950393881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950393881),
//--TRIMMABLE-BOUNDARY-START(47245361177),
    {
      "r": 262145,
      "p": [
        {
          "n": "rect",
          "p": 720921
        }
      ],
      "n": "Contains",
      "o": "@$2",
      "d": 720921,
      "h": 47245361177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245361177),
//--TRIMMABLE-BOUNDARY-START(163209478169),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 720921,
      "h": 163209478169,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209478169),
//--TRIMMABLE-BOUNDARY-START(176094380057),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "Inflate",
      "d": 720921,
      "h": 176094380057,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094380057),
//--TRIMMABLE-BOUNDARY-START(184684314649),
    {
      "r": 65537,
      "p": [
        {
          "n": "size",
          "p": 851993
        }
      ],
      "n": "Inflate",
      "o": "@$2",
      "d": 720921,
      "h": 184684314649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684314649),
//--TRIMMABLE-BOUNDARY-START(180389347353),
    {
      "r": 720921,
      "p": [
        {
          "n": "rect",
          "p": 720921
        },
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "Inflate",
      "o": "@$1",
      "d": 720921,
      "h": 180389347353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(180389347353),
//--TRIMMABLE-BOUNDARY-START(193274249241),
    {
      "r": 65537,
      "p": [
        {
          "n": "rect",
          "p": 720921
        }
      ],
      "n": "Intersect",
      "o": "@$1",
      "d": 720921,
      "h": 193274249241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274249241),
//--TRIMMABLE-BOUNDARY-START(188979281945),
    {
      "r": 720921,
      "p": [
        {
          "n": "a",
          "p": 720921
        },
        {
          "n": "b",
          "p": 720921
        }
      ],
      "n": "Intersect",
      "d": 720921,
      "h": 188979281945,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(188979281945),
//--TRIMMABLE-BOUNDARY-START(197569216537),
    {
      "r": 262145,
      "p": [
        {
          "n": "rect",
          "p": 720921
        }
      ],
      "n": "IntersectsWith",
      "d": 720921,
      "h": 197569216537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569216537),
//--TRIMMABLE-BOUNDARY-START(304943398937),
    {
      "r": 720921,
      "p": [
        {
          "n": "a",
          "p": 720921
        },
        {
          "n": "b",
          "p": 720921
        }
      ],
      "n": "Union",
      "d": 720921,
      "h": 304943398937,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(304943398937),
//--TRIMMABLE-BOUNDARY-START(219044053017),
    {
      "r": 65537,
      "p": [
        {
          "n": "pos",
          "p": 589849
        }
      ],
      "n": "Offset",
      "o": "@$1",
      "d": 720921,
      "h": 219044053017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(219044053017),
//--TRIMMABLE-BOUNDARY-START(214749085721),
    {
      "r": 65537,
      "p": [
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": "Offset",
      "d": 720921,
      "h": 214749085721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(214749085721),
//--TRIMMABLE-BOUNDARY-START(296353464345),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 720921,
      "h": 296353464345,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(296353464345)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(51540328473),
    {
      "t": 720921,
      "n": "Empty",
      "d": 720921,
      "h": 51540328473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540328473),
//--TRIMMABLE-BOUNDARY-START(317828300825),
    {
      "t": 1114113,
      "n": "x",
      "d": 720921,
      "h": 317828300825,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(317828300825),
//--TRIMMABLE-BOUNDARY-START(326418235417),
    {
      "t": 1114113,
      "n": "y",
      "d": 720921,
      "h": 326418235417,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(326418235417),
//--TRIMMABLE-BOUNDARY-START(309238366233),
    {
      "t": 1114113,
      "n": "width",
      "d": 720921,
      "h": 309238366233,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(309238366233),
//--TRIMMABLE-BOUNDARY-START(167504445465),
    {
      "t": 1114113,
      "n": "height",
      "d": 720921,
      "h": 167504445465,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(167504445465)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770524697),
    {
      "p": [
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        },
        {
          "n": "width",
          "p": 1114113
        },
        {
          "n": "height",
          "p": 1114113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 720921,
      "h": 25770524697,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770524697),
//--TRIMMABLE-BOUNDARY-START(30065491993),
    {
      "p": [
        {
          "n": "location",
          "p": 589849
        },
        {
          "n": "size",
          "p": 851993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720921,
      "h": 30065491993,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065491993),
//--TRIMMABLE-BOUNDARY-START(21475557401),
    {
      "p": [
        {
          "n": "vector",
          "p": 103546881
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720921,
      "h": 21475557401,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475557401),
//--TRIMMABLE-BOUNDARY-START(17180590105),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 720921,
      "h": 17180590105,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180590105)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h
  ],
  "h": 720921,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720921)
        
        
        //--TRIMMABLE-BOUNDARY-START(524313)
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(38655229977)
            /*Point*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(38655229977)
            
            //--TRIMMABLE-BOUNDARY-START(154619346969)
            /*int*/  get x() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(154619346969)
            
            //--TRIMMABLE-BOUNDARY-START(163209281561)
            /*int*/  get y() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(163209281561)
            
            //--TRIMMABLE-BOUNDARY-START(17180393497)
            $ctor$3(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180393497)
            
            //--TRIMMABLE-BOUNDARY-START(25770328089)
            $ctor$5(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328089);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328089)
            
            //--TRIMMABLE-BOUNDARY-START(21475360793)
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360793);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475360793)
            
            //--TRIMMABLE-BOUNDARY-START(85899870233)
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(85899870233)
            
            //--TRIMMABLE-BOUNDARY-START(158914314265)
            /*int */ get X()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x;
            }
            /*int */ set X(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849543193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x = value;
            }
            //--TRIMMABLE-BOUNDARY-END(158914314265)
            
            //--TRIMMABLE-BOUNDARY-START(167504248857)
            /*int */ get Y()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y;
            }
            /*int */ set Y(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439477785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y = value;
            }
            //--TRIMMABLE-BOUNDARY-END(167504248857)
            
            //--TRIMMABLE-BOUNDARY-START(4295491609)
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                {
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(p.X, p.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491609)
            
            //--TRIMMABLE-BOUNDARY-START(8590458905)
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                {
                    return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458905)
            
            //--TRIMMABLE-BOUNDARY-START(103079739417)
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079739417)
            
            //--TRIMMABLE-BOUNDARY-START(115964641305)
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964641305)
            
            //--TRIMMABLE-BOUNDARY-START(107374706713)
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                {
                    return left.X === right.X && left.Y === right.Y;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374706713)
            
            //--TRIMMABLE-BOUNDARY-START(111669674009)
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                {
                    return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669674009)
            
            //--TRIMMABLE-BOUNDARY-START(30065295385)
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295385);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Point().$ctor$3(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065295385)
            
            //--TRIMMABLE-BOUNDARY-START(141734445081)
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734445081);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Point().$ctor$3(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734445081)
            
            //--TRIMMABLE-BOUNDARY-START(34360262681)
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262681);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast(Math.ceil(value.X), $.$$.System.Int32), $.$cast(Math.ceil(value.Y), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360262681)
            
            //--TRIMMABLE-BOUNDARY-START(150324379673)
            static /*Point */ Truncate(/*PointF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324379673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast(value.X, $.$$.System.Int32), $.$cast(value.Y, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324379673)
            
            //--TRIMMABLE-BOUNDARY-START(120259608601)
            static /*Point */ Round(/*PointF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259608601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast($.$$.System.Math.Round$7(value.X), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Y), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259608601)
            
            //--TRIMMABLE-BOUNDARY-START(42950197273)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197273);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Point.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(42950197273)
            
            //--TRIMMABLE-BOUNDARY-START(47245164569)
            /*bool */ Equals$2(/*Point*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245164569);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Point.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245164569)
            
            //--TRIMMABLE-BOUNDARY-START(77309935641)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309935641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, this.X, this.Y);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(77309935641)
            
            //--TRIMMABLE-BOUNDARY-START(94489804825)
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489804825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489804825)
            
            //--TRIMMABLE-BOUNDARY-START(98784772121)
            /*void */ Offset$1(/*Point*/ p)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784772121);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Offset(p.X, p.Y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784772121)
            
            //--TRIMMABLE-BOUNDARY-START(146029412377)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029412377);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{X=${this.X},Y=${this.Y}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(146029412377)
            
            //--TRIMMABLE-BOUNDARY-START(81604902937)
            static /*short */ HighInt16(/*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604902937);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast(((n >> 16) & 65535), $.$$.System.Int16);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604902937)
            
            //--TRIMMABLE-BOUNDARY-START(90194837529)
            static /*short */ LowInt16(/*int*/ n)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194837529);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast((n & 65535), $.$$.System.Int16);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194837529)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12885426201)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885426201)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(154619346969)
                this.x = 0;
                //--TRIMMABLE-BOUNDARY-END(154619346969)
                
                //--TRIMMABLE-BOUNDARY-START(163209281561)
                this.y = 0;
                //--TRIMMABLE-BOUNDARY-END(163209281561)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(38655229977)
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                    //--TRIMMABLE-BOUNDARY-END(38655229977)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 524313;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85899870233),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099161,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 524313,
      "h": 85899870233,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899870233),
//--TRIMMABLE-BOUNDARY-START(158914314265),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425033753,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 128849543193,
        "f": 83886081
      },
      "n": "X",
      "d": 524313,
      "h": 158914314265,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(158914314265),
//--TRIMMABLE-BOUNDARY-START(167504248857),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014968345,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439477785,
        "f": 83886081
      },
      "n": "Y",
      "d": 524313,
      "h": 167504248857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(167504248857)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065295385),
    {
      "r": 524313,
      "p": [
        {
          "n": "pt",
          "p": 524313
        },
        {
          "n": "sz",
          "p": 786457
        }
      ],
      "n": "Add",
      "d": 524313,
      "h": 30065295385,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065295385),
//--TRIMMABLE-BOUNDARY-START(141734445081),
    {
      "r": 524313,
      "p": [
        {
          "n": "pt",
          "p": 524313
        },
        {
          "n": "sz",
          "p": 786457
        }
      ],
      "n": "Subtract",
      "d": 524313,
      "h": 141734445081,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734445081),
//--TRIMMABLE-BOUNDARY-START(34360262681),
    {
      "r": 524313,
      "p": [
        {
          "n": "value",
          "p": 589849
        }
      ],
      "n": "Ceiling",
      "d": 524313,
      "h": 34360262681,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34360262681),
//--TRIMMABLE-BOUNDARY-START(150324379673),
    {
      "r": 524313,
      "p": [
        {
          "n": "value",
          "p": 589849
        }
      ],
      "n": "Truncate",
      "d": 524313,
      "h": 150324379673,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324379673),
//--TRIMMABLE-BOUNDARY-START(120259608601),
    {
      "r": 524313,
      "p": [
        {
          "n": "value",
          "p": 589849
        }
      ],
      "n": "Round",
      "d": 524313,
      "h": 120259608601,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259608601),
//--TRIMMABLE-BOUNDARY-START(42950197273),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 524313,
      "h": 42950197273,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950197273),
//--TRIMMABLE-BOUNDARY-START(47245164569),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 524313
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 524313,
      "h": 47245164569,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245164569),
//--TRIMMABLE-BOUNDARY-START(77309935641),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 524313,
      "h": 77309935641,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77309935641),
//--TRIMMABLE-BOUNDARY-START(94489804825),
    {
      "r": 65537,
      "p": [
        {
          "n": "dx",
          "p": 655361
        },
        {
          "n": "dy",
          "p": 655361
        }
      ],
      "n": "Offset",
      "d": 524313,
      "h": 94489804825,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489804825),
//--TRIMMABLE-BOUNDARY-START(98784772121),
    {
      "r": 65537,
      "p": [
        {
          "n": "p",
          "p": 524313
        }
      ],
      "n": "Offset",
      "o": "@$1",
      "d": 524313,
      "h": 98784772121,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784772121),
//--TRIMMABLE-BOUNDARY-START(146029412377),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 524313,
      "h": 146029412377,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029412377),
//--TRIMMABLE-BOUNDARY-START(81604902937),
    {
      "r": 524289,
      "p": [
        {
          "n": "n",
          "p": 655361
        }
      ],
      "n": "HighInt16",
      "d": 524313,
      "h": 81604902937,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604902937),
//--TRIMMABLE-BOUNDARY-START(90194837529),
    {
      "r": 524289,
      "p": [
        {
          "n": "n",
          "p": 655361
        }
      ],
      "n": "LowInt16",
      "d": 524313,
      "h": 90194837529,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90194837529)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(38655229977),
    {
      "t": 524313,
      "n": "Empty",
      "d": 524313,
      "h": 38655229977,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655229977),
//--TRIMMABLE-BOUNDARY-START(154619346969),
    {
      "t": 655361,
      "n": "x",
      "d": 524313,
      "h": 154619346969,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(154619346969),
//--TRIMMABLE-BOUNDARY-START(163209281561),
    {
      "t": 655361,
      "n": "y",
      "d": 524313,
      "h": 163209281561,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(163209281561)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180393497),
    {
      "p": [
        {
          "n": "x",
          "p": 655361
        },
        {
          "n": "y",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524313,
      "h": 17180393497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180393497),
//--TRIMMABLE-BOUNDARY-START(25770328089),
    {
      "p": [
        {
          "n": "sz",
          "p": 786457
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 524313,
      "h": 25770328089,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328089),
//--TRIMMABLE-BOUNDARY-START(21475360793),
    {
      "p": [
        {
          "n": "dw",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 524313,
      "h": 21475360793,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475360793),
//--TRIMMABLE-BOUNDARY-START(12885426201),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 524313,
      "h": 12885426201,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885426201)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.Point).$h
  ],
  "h": 524313,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524313)
        
        
        //--TRIMMABLE-BOUNDARY-START(851993)
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(42950524953)
            /*SizeF*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(42950524953)
            
            //--TRIMMABLE-BOUNDARY-START(171799543833)
            /*float*/  get width() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(171799543833)
            
            //--TRIMMABLE-BOUNDARY-START(85900197913)
            /*float*/  get height() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(85900197913)
            
            //--TRIMMABLE-BOUNDARY-START(34360590361)
            $ctor$6(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360590361);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360590361)
            
            //--TRIMMABLE-BOUNDARY-START(30065623065)
            $ctor$5(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065623065);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065623065)
            
            //--TRIMMABLE-BOUNDARY-START(21475688473)
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475688473);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475688473)
            
            //--TRIMMABLE-BOUNDARY-START(167504576537)
            /*Vector2 */ ToVector2()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504576537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.Numerics.Vector2().$ctor$4(this.width, this.height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504576537)
            
            //--TRIMMABLE-BOUNDARY-START(25770655769)
            $ctor$4(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770655769);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770655769)
            
            //--TRIMMABLE-BOUNDARY-START(4295819289)
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                {
                    return size.ToVector2();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295819289)
            
            //--TRIMMABLE-BOUNDARY-START(12885753881)
            static /*SizeF */ op_Explicit$2(/*Vector2*/ vector)
            {
                {
                    return new $.$sdp.System.Drawing.SizeF().$ctor$3(vector.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885753881)
            
            //--TRIMMABLE-BOUNDARY-START(103080067097)
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080067097)
            
            //--TRIMMABLE-BOUNDARY-START(128849870873)
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849870873)
            
            //--TRIMMABLE-BOUNDARY-START(120259936281)
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                {
                    return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259936281)
            
            //--TRIMMABLE-BOUNDARY-START(124554903577)
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                {
                    return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554903577)
            
            //--TRIMMABLE-BOUNDARY-START(107375034393)
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                {
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(left.width / right, left.height / right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107375034393)
            
            //--TRIMMABLE-BOUNDARY-START(111670001689)
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111670001689)
            
            //--TRIMMABLE-BOUNDARY-START(115964968985)
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964968985)
            
            //--TRIMMABLE-BOUNDARY-START(8590786585)
            static /*PointF */ op_Explicit$1(/*SizeF*/ size)
            {
                {
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(size.Width, size.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590786585)
            
            //--TRIMMABLE-BOUNDARY-START(94490132505)
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(94490132505)
            
            //--TRIMMABLE-BOUNDARY-START(176094511129)
            /*float */ get Width()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310263321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width;
            }
            /*float */ set Width(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029740057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width = value;
            }
            //--TRIMMABLE-BOUNDARY-END(176094511129)
            
            //--TRIMMABLE-BOUNDARY-START(90195165209)
            /*float */ get Height()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130394137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height;
            }
            /*float */ set Height(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439805465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height = value;
            }
            //--TRIMMABLE-BOUNDARY-END(90195165209)
            
            //--TRIMMABLE-BOUNDARY-START(38655557657)
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655557657);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655557657)
            
            //--TRIMMABLE-BOUNDARY-START(150324707353)
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324707353);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324707353)
            
            //--TRIMMABLE-BOUNDARY-START(47245492249)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245492249);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.SizeF.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(47245492249)
            
            //--TRIMMABLE-BOUNDARY-START(51540459545)
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540459545);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540459545)
            
            //--TRIMMABLE-BOUNDARY-START(81605230617)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81605230617);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.Single, $.$$.System.Single, this.Width, this.Height);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(81605230617)
            
            //--TRIMMABLE-BOUNDARY-START(154619674649)
            /*PointF */ ToPointF()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154619674649);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.SizeF.op_Explicit$1(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619674649)
            
            //--TRIMMABLE-BOUNDARY-START(158914641945)
            /*Size */ ToSize()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158914641945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Size.Truncate(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914641945)
            
            //--TRIMMABLE-BOUNDARY-START(163209609241)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209609241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{Width=${this.width}, Height=${this.height}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(163209609241)
            
            //--TRIMMABLE-BOUNDARY-START(98785099801)
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98785099801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(size.width * multiplier, size.height * multiplier);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785099801)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(17180721177)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721177)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(171799543833)
                this.width = 0;
                //--TRIMMABLE-BOUNDARY-END(171799543833)
                
                //--TRIMMABLE-BOUNDARY-START(85900197913)
                this.height = 0;
                //--TRIMMABLE-BOUNDARY-END(85900197913)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(42950524953)
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                    //--TRIMMABLE-BOUNDARY-END(42950524953)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 851993;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(94490132505),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720328729,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 851993,
      "h": 94490132505,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490132505),
//--TRIMMABLE-BOUNDARY-START(176094511129),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310263321,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 146029740057,
        "f": 83886081
      },
      "n": "Width",
      "d": 851993,
      "h": 176094511129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(176094511129),
//--TRIMMABLE-BOUNDARY-START(90195165209),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130394137,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 137439805465,
        "f": 83886081
      },
      "n": "Height",
      "d": 851993,
      "h": 90195165209,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195165209)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504576537),
    {
      "r": 103415809,
      "n": "ToVector2",
      "d": 851993,
      "h": 167504576537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504576537),
//--TRIMMABLE-BOUNDARY-START(38655557657),
    {
      "r": 851993,
      "p": [
        {
          "n": "sz1",
          "p": 851993
        },
        {
          "n": "sz2",
          "p": 851993
        }
      ],
      "n": "Add",
      "d": 851993,
      "h": 38655557657,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655557657),
//--TRIMMABLE-BOUNDARY-START(150324707353),
    {
      "r": 851993,
      "p": [
        {
          "n": "sz1",
          "p": 851993
        },
        {
          "n": "sz2",
          "p": 851993
        }
      ],
      "n": "Subtract",
      "d": 851993,
      "h": 150324707353,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(150324707353),
//--TRIMMABLE-BOUNDARY-START(47245492249),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 851993,
      "h": 47245492249,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245492249),
//--TRIMMABLE-BOUNDARY-START(51540459545),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 851993
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 851993,
      "h": 51540459545,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540459545),
//--TRIMMABLE-BOUNDARY-START(81605230617),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 851993,
      "h": 81605230617,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(81605230617),
//--TRIMMABLE-BOUNDARY-START(154619674649),
    {
      "r": 589849,
      "n": "ToPointF",
      "d": 851993,
      "h": 154619674649,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(154619674649),
//--TRIMMABLE-BOUNDARY-START(158914641945),
    {
      "r": 786457,
      "n": "ToSize",
      "d": 851993,
      "h": 158914641945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914641945),
//--TRIMMABLE-BOUNDARY-START(163209609241),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 851993,
      "h": 163209609241,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(163209609241),
//--TRIMMABLE-BOUNDARY-START(98785099801),
    {
      "r": 851993,
      "p": [
        {
          "n": "size",
          "p": 851993
        },
        {
          "n": "multiplier",
          "p": 1114113
        }
      ],
      "n": "Multiply",
      "d": 851993,
      "h": 98785099801,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(98785099801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(42950524953),
    {
      "t": 851993,
      "n": "Empty",
      "d": 851993,
      "h": 42950524953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950524953),
//--TRIMMABLE-BOUNDARY-START(171799543833),
    {
      "t": 1114113,
      "n": "width",
      "d": 851993,
      "h": 171799543833,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(171799543833),
//--TRIMMABLE-BOUNDARY-START(85900197913),
    {
      "t": 1114113,
      "n": "height",
      "d": 851993,
      "h": 85900197913,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(85900197913)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360590361),
    {
      "p": [
        {
          "n": "size",
          "p": 851993
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 851993,
      "h": 34360590361,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360590361),
//--TRIMMABLE-BOUNDARY-START(30065623065),
    {
      "p": [
        {
          "n": "pt",
          "p": 589849
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 851993,
      "h": 30065623065,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065623065),
//--TRIMMABLE-BOUNDARY-START(21475688473),
    {
      "p": [
        {
          "n": "vector",
          "p": 103415809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 851993,
      "h": 21475688473,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475688473),
//--TRIMMABLE-BOUNDARY-START(25770655769),
    {
      "p": [
        {
          "n": "width",
          "p": 1114113
        },
        {
          "n": "height",
          "p": 1114113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 851993,
      "h": 25770655769,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770655769),
//--TRIMMABLE-BOUNDARY-START(17180721177),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 851993,
      "h": 17180721177,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180721177)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h
  ],
  "h": 851993,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        //--TRIMMABLE-BOUNDARY-END(851993)
        
        
        //--TRIMMABLE-BOUNDARY-START(786457)
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360524825)
            /*Size*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(34360524825)
            
            //--TRIMMABLE-BOUNDARY-START(176094445593)
            /*int*/  get width() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(176094445593)
            
            //--TRIMMABLE-BOUNDARY-START(77310197785)
            /*int*/  get height() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$$.System.Int32, value); }
            //--TRIMMABLE-BOUNDARY-END(77310197785)
            
            //--TRIMMABLE-BOUNDARY-START(21475622937)
            $ctor$4(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475622937);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475622937)
            
            //--TRIMMABLE-BOUNDARY-START(17180655641)
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180655641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180655641)
            
            //--TRIMMABLE-BOUNDARY-START(8590721049)
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                {
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(p.Width, p.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590721049)
            
            //--TRIMMABLE-BOUNDARY-START(98785034265)
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98785034265)
            
            //--TRIMMABLE-BOUNDARY-START(137439739929)
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439739929)
            
            //--TRIMMABLE-BOUNDARY-START(120259870745)
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                {
                    return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259870745)
            
            //--TRIMMABLE-BOUNDARY-START(128849805337)
            static /*Size */ op_Multiply$2(/*Size*/ left, /*int*/ right)
            {
                {
                    return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849805337)
            
            //--TRIMMABLE-BOUNDARY-START(103080001561)
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                {
                    return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103080001561)
            
            //--TRIMMABLE-BOUNDARY-START(124554838041)
            static /*SizeF */ op_Multiply$1(/*float*/ left, /*Size*/ right)
            {
                {
                    return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554838041)
            
            //--TRIMMABLE-BOUNDARY-START(133144772633)
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                {
                    return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144772633)
            
            //--TRIMMABLE-BOUNDARY-START(107374968857)
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                {
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(left.width / right, left.height / right);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374968857)
            
            //--TRIMMABLE-BOUNDARY-START(111669936153)
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669936153)
            
            //--TRIMMABLE-BOUNDARY-START(115964903449)
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964903449)
            
            //--TRIMMABLE-BOUNDARY-START(4295753753)
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                {
                    return new $.$sdp.System.Drawing.Point().$ctor$3(size.Width, size.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295753753)
            
            //--TRIMMABLE-BOUNDARY-START(85900132377)
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(85900132377)
            
            //--TRIMMABLE-BOUNDARY-START(180389412889)
            /*int */ get Width()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720263193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width;
            }
            /*int */ set Width(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914576409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.width = value;
            }
            //--TRIMMABLE-BOUNDARY-END(180389412889)
            
            //--TRIMMABLE-BOUNDARY-START(81605165081)
            /*int */ get Height()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540394009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height;
            }
            /*int */ set Height(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324641817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.height = value;
            }
            //--TRIMMABLE-BOUNDARY-END(81605165081)
            
            //--TRIMMABLE-BOUNDARY-START(25770590233)
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770590233);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770590233)
            
            //--TRIMMABLE-BOUNDARY-START(30065557529)
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065557529);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$$.System.Int32), $.$cast(Math.ceil(value.Height), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065557529)
            
            //--TRIMMABLE-BOUNDARY-START(163209543705)
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163209543705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209543705)
            
            //--TRIMMABLE-BOUNDARY-START(171799478297)
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799478297);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$$.System.Int32), $.$cast(value.Height, $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799478297)
            
            //--TRIMMABLE-BOUNDARY-START(141734707225)
            static /*Size */ Round(/*SizeF*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734707225);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$$.System.Math.Round$7(value.Width), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Height), $.$$.System.Int32));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734707225)
            
            //--TRIMMABLE-BOUNDARY-START(38655492121)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655492121);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Size.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38655492121)
            
            //--TRIMMABLE-BOUNDARY-START(42950459417)
            /*bool */ Equals$2(/*Size*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950459417);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Size.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950459417)
            
            //--TRIMMABLE-BOUNDARY-START(73015230489)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015230489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, this.Width, this.Height);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(73015230489)
            
            //--TRIMMABLE-BOUNDARY-START(167504511001)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167504511001);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{Width=${this.width}, Height=${this.height}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(167504511001)
            
            //--TRIMMABLE-BOUNDARY-START(90195099673)
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90195099673);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90195099673)
            
            //--TRIMMABLE-BOUNDARY-START(94490066969)
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94490066969);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.SizeF().$ctor$4(size.width * multiplier, size.height * multiplier);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94490066969)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12885688345)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688345)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(176094445593)
                this.width = 0;
                //--TRIMMABLE-BOUNDARY-END(176094445593)
                
                //--TRIMMABLE-BOUNDARY-START(77310197785)
                this.height = 0;
                //--TRIMMABLE-BOUNDARY-END(77310197785)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34360524825)
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                    //--TRIMMABLE-BOUNDARY-END(34360524825)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 786457;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(85900132377),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130328601,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 786457,
      "h": 85900132377,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900132377),
//--TRIMMABLE-BOUNDARY-START(180389412889),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720263193,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914576409,
        "f": 83886081
      },
      "n": "Width",
      "d": 786457,
      "h": 180389412889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180389412889),
//--TRIMMABLE-BOUNDARY-START(81605165081),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540394009,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324641817,
        "f": 83886081
      },
      "n": "Height",
      "d": 786457,
      "h": 81605165081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605165081)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770590233),
    {
      "r": 786457,
      "p": [
        {
          "n": "sz1",
          "p": 786457
        },
        {
          "n": "sz2",
          "p": 786457
        }
      ],
      "n": "Add",
      "d": 786457,
      "h": 25770590233,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770590233),
//--TRIMMABLE-BOUNDARY-START(30065557529),
    {
      "r": 786457,
      "p": [
        {
          "n": "value",
          "p": 851993
        }
      ],
      "n": "Ceiling",
      "d": 786457,
      "h": 30065557529,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065557529),
//--TRIMMABLE-BOUNDARY-START(163209543705),
    {
      "r": 786457,
      "p": [
        {
          "n": "sz1",
          "p": 786457
        },
        {
          "n": "sz2",
          "p": 786457
        }
      ],
      "n": "Subtract",
      "d": 786457,
      "h": 163209543705,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(163209543705),
//--TRIMMABLE-BOUNDARY-START(171799478297),
    {
      "r": 786457,
      "p": [
        {
          "n": "value",
          "p": 851993
        }
      ],
      "n": "Truncate",
      "d": 786457,
      "h": 171799478297,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799478297),
//--TRIMMABLE-BOUNDARY-START(141734707225),
    {
      "r": 786457,
      "p": [
        {
          "n": "value",
          "p": 851993
        }
      ],
      "n": "Round",
      "d": 786457,
      "h": 141734707225,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141734707225),
//--TRIMMABLE-BOUNDARY-START(38655492121),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 786457,
      "h": 38655492121,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655492121),
//--TRIMMABLE-BOUNDARY-START(42950459417),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 786457
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 786457,
      "h": 42950459417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950459417),
//--TRIMMABLE-BOUNDARY-START(73015230489),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 786457,
      "h": 73015230489,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015230489),
//--TRIMMABLE-BOUNDARY-START(167504511001),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 786457,
      "h": 167504511001,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504511001),
//--TRIMMABLE-BOUNDARY-START(90195099673),
    {
      "r": 786457,
      "p": [
        {
          "n": "size",
          "p": 786457
        },
        {
          "n": "multiplier",
          "p": 655361
        }
      ],
      "n": "Multiply",
      "d": 786457,
      "h": 90195099673,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(90195099673),
//--TRIMMABLE-BOUNDARY-START(94490066969),
    {
      "r": 851993,
      "p": [
        {
          "n": "size",
          "p": 786457
        },
        {
          "n": "multiplier",
          "p": 1114113
        }
      ],
      "n": "Multiply",
      "o": "@$1",
      "d": 786457,
      "h": 94490066969,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(94490066969)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360524825),
    {
      "t": 786457,
      "n": "Empty",
      "d": 786457,
      "h": 34360524825,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360524825),
//--TRIMMABLE-BOUNDARY-START(176094445593),
    {
      "t": 655361,
      "n": "width",
      "d": 786457,
      "h": 176094445593,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(176094445593),
//--TRIMMABLE-BOUNDARY-START(77310197785),
    {
      "t": 655361,
      "n": "height",
      "d": 786457,
      "h": 77310197785,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(77310197785)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475622937),
    {
      "p": [
        {
          "n": "pt",
          "p": 524313
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 786457,
      "h": 21475622937,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475622937),
//--TRIMMABLE-BOUNDARY-START(17180655641),
    {
      "p": [
        {
          "n": "width",
          "p": 655361
        },
        {
          "n": "height",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 786457,
      "h": 17180655641,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180655641),
//--TRIMMABLE-BOUNDARY-START(12885688345),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786457,
      "h": 12885688345,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688345)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.Size).$h
  ],
  "h": 786457,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786457)
        
        
        //--TRIMMABLE-BOUNDARY-START(589849)
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(34360328217)
            /*PointF*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(34360328217)
            
            //--TRIMMABLE-BOUNDARY-START(141734510617)
            /*float*/  get x() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(141734510617)
            
            //--TRIMMABLE-BOUNDARY-START(150324445209)
            /*float*/  get y() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$$.System.Single, value); }
            //--TRIMMABLE-BOUNDARY-END(150324445209)
            
            //--TRIMMABLE-BOUNDARY-START(21475426329)
            $ctor$4(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475426329);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475426329)
            
            //--TRIMMABLE-BOUNDARY-START(17180459033)
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180459033);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180459033)
            
            //--TRIMMABLE-BOUNDARY-START(137439543321)
            /*Vector2 */ ToVector2()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439543321);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.Numerics.Vector2().$ctor$4(this.x, this.y);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439543321)
            
            //--TRIMMABLE-BOUNDARY-START(77310001177)
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001177)
            
            //--TRIMMABLE-BOUNDARY-START(146029477913)
            /*float */ get X()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130131993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x;
            }
            /*float */ set X(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.x = value;
            }
            //--TRIMMABLE-BOUNDARY-END(146029477913)
            
            //--TRIMMABLE-BOUNDARY-START(154619412505)
            /*float */ get Y()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y;
            }
            /*float */ set Y(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.y = value;
            }
            //--TRIMMABLE-BOUNDARY-END(154619412505)
            
            //--TRIMMABLE-BOUNDARY-START(4295557145)
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                {
                    return point.ToVector2();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295557145)
            
            //--TRIMMABLE-BOUNDARY-START(8590524441)
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                {
                    return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590524441)
            
            //--TRIMMABLE-BOUNDARY-START(81604968473)
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604968473)
            
            //--TRIMMABLE-BOUNDARY-START(98784837657)
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784837657)
            
            //--TRIMMABLE-BOUNDARY-START(85899935769)
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(85899935769)
            
            //--TRIMMABLE-BOUNDARY-START(103079804953)
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                {
                    return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079804953)
            
            //--TRIMMABLE-BOUNDARY-START(90194903065)
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                {
                    return left.X === right.X && left.Y === right.Y;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903065)
            
            //--TRIMMABLE-BOUNDARY-START(94489870361)
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                {
                    return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489870361)
            
            //--TRIMMABLE-BOUNDARY-START(25770393625)
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770393625);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X + sz.Width, pt.Y + sz.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770393625)
            
            //--TRIMMABLE-BOUNDARY-START(124554641433)
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554641433);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X - sz.Width, pt.Y - sz.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554641433)
            
            //--TRIMMABLE-BOUNDARY-START(30065360921)
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065360921);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X + sz.Width, pt.Y + sz.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065360921)
            
            //--TRIMMABLE-BOUNDARY-START(128849608729)
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849608729);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X - sz.Width, pt.Y - sz.Height);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849608729)
            
            //--TRIMMABLE-BOUNDARY-START(38655295513)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655295513);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.PointF.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(38655295513)
            
            //--TRIMMABLE-BOUNDARY-START(42950262809)
            /*bool */ Equals$2(/*PointF*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950262809);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950262809)
            
            //--TRIMMABLE-BOUNDARY-START(73015033881)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73015033881);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Single.GetHashCode.call(this.X), $.$$.System.Single.GetHashCode.call(this.Y));
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(73015033881)
            
            //--TRIMMABLE-BOUNDARY-START(133144576025)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144576025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return `{{X=${this.x}, Y=${this.y}}}`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(133144576025)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(12885491737)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885491737)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(141734510617)
                this.x = 0;
                //--TRIMMABLE-BOUNDARY-END(141734510617)
                
                //--TRIMMABLE-BOUNDARY-START(150324445209)
                this.y = 0;
                //--TRIMMABLE-BOUNDARY-END(150324445209)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(34360328217)
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                    //--TRIMMABLE-BOUNDARY-END(34360328217)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 589849;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77310001177),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540197401,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 589849,
      "h": 77310001177,
      "f": 2097153,
      "a": [
        {
          "t": 65576,
          "c": 12884967464,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310001177),
//--TRIMMABLE-BOUNDARY-START(146029477913),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130131993,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 111669739545,
        "f": 83886081
      },
      "n": "X",
      "d": 589849,
      "h": 146029477913,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029477913),
//--TRIMMABLE-BOUNDARY-START(154619412505),
    {
      "p": 1114113,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720066585,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259674137,
        "f": 83886081
      },
      "n": "Y",
      "d": 589849,
      "h": 154619412505,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619412505)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(137439543321),
    {
      "r": 103415809,
      "n": "ToVector2",
      "d": 589849,
      "h": 137439543321,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439543321),
//--TRIMMABLE-BOUNDARY-START(25770393625),
    {
      "r": 589849,
      "p": [
        {
          "n": "pt",
          "p": 589849
        },
        {
          "n": "sz",
          "p": 786457
        }
      ],
      "n": "Add",
      "d": 589849,
      "h": 25770393625,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770393625),
//--TRIMMABLE-BOUNDARY-START(124554641433),
    {
      "r": 589849,
      "p": [
        {
          "n": "pt",
          "p": 589849
        },
        {
          "n": "sz",
          "p": 786457
        }
      ],
      "n": "Subtract",
      "d": 589849,
      "h": 124554641433,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554641433),
//--TRIMMABLE-BOUNDARY-START(30065360921),
    {
      "r": 589849,
      "p": [
        {
          "n": "pt",
          "p": 589849
        },
        {
          "n": "sz",
          "p": 851993
        }
      ],
      "n": "Add",
      "o": "@$1",
      "d": 589849,
      "h": 30065360921,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065360921),
//--TRIMMABLE-BOUNDARY-START(128849608729),
    {
      "r": 589849,
      "p": [
        {
          "n": "pt",
          "p": 589849
        },
        {
          "n": "sz",
          "p": 851993
        }
      ],
      "n": "Subtract",
      "o": "@$1",
      "d": 589849,
      "h": 128849608729,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(128849608729),
//--TRIMMABLE-BOUNDARY-START(38655295513),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 589849,
      "h": 38655295513,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655295513),
//--TRIMMABLE-BOUNDARY-START(42950262809),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 589849
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 589849,
      "h": 42950262809,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950262809),
//--TRIMMABLE-BOUNDARY-START(73015033881),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 589849,
      "h": 73015033881,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015033881),
//--TRIMMABLE-BOUNDARY-START(133144576025),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 589849,
      "h": 133144576025,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144576025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(34360328217),
    {
      "t": 589849,
      "n": "Empty",
      "d": 589849,
      "h": 34360328217,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360328217),
//--TRIMMABLE-BOUNDARY-START(141734510617),
    {
      "t": 1114113,
      "n": "x",
      "d": 589849,
      "h": 141734510617,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(141734510617),
//--TRIMMABLE-BOUNDARY-START(150324445209),
    {
      "t": 1114113,
      "n": "y",
      "d": 589849,
      "h": 150324445209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(150324445209)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426329),
    {
      "p": [
        {
          "n": "x",
          "p": 1114113
        },
        {
          "n": "y",
          "p": 1114113
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589849,
      "h": 21475426329,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426329),
//--TRIMMABLE-BOUNDARY-START(17180459033),
    {
      "p": [
        {
          "n": "vector",
          "p": 103415809
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589849,
      "h": 17180459033,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459033),
//--TRIMMABLE-BOUNDARY-START(12885491737),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589849,
      "h": 12885491737,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885491737)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h
  ],
  "h": 589849,
  "a": [
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589849)
        
        
        //--TRIMMABLE-BOUNDARY-START(65561)
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(244813201433)
            /*Color*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(244813201433)
            
            //--TRIMMABLE-BOUNDARY-START(2117418942489)
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(27/*KnownColor.Transparent*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2117418942489)
            
            //--TRIMMABLE-BOUNDARY-START(21474902041)
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(28/*KnownColor.AliceBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(21474902041)
            
            //--TRIMMABLE-BOUNDARY-START(25769869337)
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(29/*KnownColor.AntiqueWhite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(25769869337)
            
            //--TRIMMABLE-BOUNDARY-START(30064836633)
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(30/*KnownColor.Aqua*/);
            }
            //--TRIMMABLE-BOUNDARY-END(30064836633)
            
            //--TRIMMABLE-BOUNDARY-START(34359803929)
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(31/*KnownColor.Aquamarine*/);
            }
            //--TRIMMABLE-BOUNDARY-END(34359803929)
            
            //--TRIMMABLE-BOUNDARY-START(73014509593)
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(32/*KnownColor.Azure*/);
            }
            //--TRIMMABLE-BOUNDARY-END(73014509593)
            
            //--TRIMMABLE-BOUNDARY-START(81604444185)
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(33/*KnownColor.Beige*/);
            }
            //--TRIMMABLE-BOUNDARY-END(81604444185)
            
            //--TRIMMABLE-BOUNDARY-START(85899411481)
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(34/*KnownColor.Bisque*/);
            }
            //--TRIMMABLE-BOUNDARY-END(85899411481)
            
            //--TRIMMABLE-BOUNDARY-START(90194378777)
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(35/*KnownColor.Black*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90194378777)
            
            //--TRIMMABLE-BOUNDARY-START(94489346073)
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(36/*KnownColor.BlanchedAlmond*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94489346073)
            
            //--TRIMMABLE-BOUNDARY-START(98784313369)
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(37/*KnownColor.Blue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313369)
            
            //--TRIMMABLE-BOUNDARY-START(103079280665)
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(38/*KnownColor.BlueViolet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(103079280665)
            
            //--TRIMMABLE-BOUNDARY-START(107374247961)
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(39/*KnownColor.Brown*/);
            }
            //--TRIMMABLE-BOUNDARY-END(107374247961)
            
            //--TRIMMABLE-BOUNDARY-START(111669215257)
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(40/*KnownColor.BurlyWood*/);
            }
            //--TRIMMABLE-BOUNDARY-END(111669215257)
            
            //--TRIMMABLE-BOUNDARY-START(115964182553)
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(41/*KnownColor.CadetBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(115964182553)
            
            //--TRIMMABLE-BOUNDARY-START(120259149849)
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(42/*KnownColor.Chartreuse*/);
            }
            //--TRIMMABLE-BOUNDARY-END(120259149849)
            
            //--TRIMMABLE-BOUNDARY-START(128849084441)
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(43/*KnownColor.Chocolate*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128849084441)
            
            //--TRIMMABLE-BOUNDARY-START(133144051737)
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(44/*KnownColor.Coral*/);
            }
            //--TRIMMABLE-BOUNDARY-END(133144051737)
            
            //--TRIMMABLE-BOUNDARY-START(137439019033)
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(45/*KnownColor.CornflowerBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(137439019033)
            
            //--TRIMMABLE-BOUNDARY-START(141733986329)
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(46/*KnownColor.Cornsilk*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141733986329)
            
            //--TRIMMABLE-BOUNDARY-START(146028953625)
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(47/*KnownColor.Crimson*/);
            }
            //--TRIMMABLE-BOUNDARY-END(146028953625)
            
            //--TRIMMABLE-BOUNDARY-START(150323920921)
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(48/*KnownColor.Cyan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(150323920921)
            
            //--TRIMMABLE-BOUNDARY-START(154618888217)
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(49/*KnownColor.DarkBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(154618888217)
            
            //--TRIMMABLE-BOUNDARY-START(158913855513)
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(50/*KnownColor.DarkCyan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(158913855513)
            
            //--TRIMMABLE-BOUNDARY-START(163208822809)
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(51/*KnownColor.DarkGoldenrod*/);
            }
            //--TRIMMABLE-BOUNDARY-END(163208822809)
            
            //--TRIMMABLE-BOUNDARY-START(167503790105)
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(52/*KnownColor.DarkGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(167503790105)
            
            //--TRIMMABLE-BOUNDARY-START(171798757401)
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(53/*KnownColor.DarkGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(171798757401)
            
            //--TRIMMABLE-BOUNDARY-START(176093724697)
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(54/*KnownColor.DarkKhaki*/);
            }
            //--TRIMMABLE-BOUNDARY-END(176093724697)
            
            //--TRIMMABLE-BOUNDARY-START(180388691993)
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(55/*KnownColor.DarkMagenta*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180388691993)
            
            //--TRIMMABLE-BOUNDARY-START(184683659289)
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(56/*KnownColor.DarkOliveGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(184683659289)
            
            //--TRIMMABLE-BOUNDARY-START(188978626585)
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(57/*KnownColor.DarkOrange*/);
            }
            //--TRIMMABLE-BOUNDARY-END(188978626585)
            
            //--TRIMMABLE-BOUNDARY-START(193273593881)
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(58/*KnownColor.DarkOrchid*/);
            }
            //--TRIMMABLE-BOUNDARY-END(193273593881)
            
            //--TRIMMABLE-BOUNDARY-START(197568561177)
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(59/*KnownColor.DarkRed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(197568561177)
            
            //--TRIMMABLE-BOUNDARY-START(201863528473)
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(60/*KnownColor.DarkSalmon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(201863528473)
            
            //--TRIMMABLE-BOUNDARY-START(206158495769)
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(61/*KnownColor.DarkSeaGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206158495769)
            
            //--TRIMMABLE-BOUNDARY-START(210453463065)
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(62/*KnownColor.DarkSlateBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(210453463065)
            
            //--TRIMMABLE-BOUNDARY-START(214748430361)
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(63/*KnownColor.DarkSlateGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(214748430361)
            
            //--TRIMMABLE-BOUNDARY-START(219043397657)
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(64/*KnownColor.DarkTurquoise*/);
            }
            //--TRIMMABLE-BOUNDARY-END(219043397657)
            
            //--TRIMMABLE-BOUNDARY-START(223338364953)
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(65/*KnownColor.DarkViolet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(223338364953)
            
            //--TRIMMABLE-BOUNDARY-START(227633332249)
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(66/*KnownColor.DeepPink*/);
            }
            //--TRIMMABLE-BOUNDARY-END(227633332249)
            
            //--TRIMMABLE-BOUNDARY-START(231928299545)
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(67/*KnownColor.DeepSkyBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(231928299545)
            
            //--TRIMMABLE-BOUNDARY-START(236223266841)
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(68/*KnownColor.DimGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(236223266841)
            
            //--TRIMMABLE-BOUNDARY-START(240518234137)
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(69/*KnownColor.DodgerBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(240518234137)
            
            //--TRIMMABLE-BOUNDARY-START(257698103321)
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(70/*KnownColor.Firebrick*/);
            }
            //--TRIMMABLE-BOUNDARY-END(257698103321)
            
            //--TRIMMABLE-BOUNDARY-START(261993070617)
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(71/*KnownColor.FloralWhite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(261993070617)
            
            //--TRIMMABLE-BOUNDARY-START(266288037913)
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(72/*KnownColor.ForestGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(266288037913)
            
            //--TRIMMABLE-BOUNDARY-START(300647776281)
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(73/*KnownColor.Fuchsia*/);
            }
            //--TRIMMABLE-BOUNDARY-END(300647776281)
            
            //--TRIMMABLE-BOUNDARY-START(309237710873)
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(74/*KnownColor.Gainsboro*/);
            }
            //--TRIMMABLE-BOUNDARY-END(309237710873)
            
            //--TRIMMABLE-BOUNDARY-START(1649267507225)
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(75/*KnownColor.GhostWhite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1649267507225)
            
            //--TRIMMABLE-BOUNDARY-START(1653562474521)
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(76/*KnownColor.Gold*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1653562474521)
            
            //--TRIMMABLE-BOUNDARY-START(1657857441817)
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(77/*KnownColor.Goldenrod*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1657857441817)
            
            //--TRIMMABLE-BOUNDARY-START(1662152409113)
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(78/*KnownColor.Gray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1662152409113)
            
            //--TRIMMABLE-BOUNDARY-START(1666447376409)
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(79/*KnownColor.Green*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1666447376409)
            
            //--TRIMMABLE-BOUNDARY-START(1670742343705)
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(80/*KnownColor.GreenYellow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1670742343705)
            
            //--TRIMMABLE-BOUNDARY-START(1675037311001)
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(81/*KnownColor.Honeydew*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1675037311001)
            
            //--TRIMMABLE-BOUNDARY-START(1679332278297)
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(82/*KnownColor.HotPink*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1679332278297)
            
            //--TRIMMABLE-BOUNDARY-START(1683627245593)
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(83/*KnownColor.IndianRed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1683627245593)
            
            //--TRIMMABLE-BOUNDARY-START(1687922212889)
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(84/*KnownColor.Indigo*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1687922212889)
            
            //--TRIMMABLE-BOUNDARY-START(1713692016665)
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(85/*KnownColor.Ivory*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1713692016665)
            
            //--TRIMMABLE-BOUNDARY-START(1717986983961)
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(86/*KnownColor.Khaki*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1717986983961)
            
            //--TRIMMABLE-BOUNDARY-START(1726576918553)
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(87/*KnownColor.Lavender*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1726576918553)
            
            //--TRIMMABLE-BOUNDARY-START(1730871885849)
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(88/*KnownColor.LavenderBlush*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1730871885849)
            
            //--TRIMMABLE-BOUNDARY-START(1735166853145)
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(89/*KnownColor.LawnGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1735166853145)
            
            //--TRIMMABLE-BOUNDARY-START(1739461820441)
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(90/*KnownColor.LemonChiffon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1739461820441)
            
            //--TRIMMABLE-BOUNDARY-START(1743756787737)
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(91/*KnownColor.LightBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1743756787737)
            
            //--TRIMMABLE-BOUNDARY-START(1748051755033)
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(92/*KnownColor.LightCoral*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1748051755033)
            
            //--TRIMMABLE-BOUNDARY-START(1752346722329)
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(93/*KnownColor.LightCyan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1752346722329)
            
            //--TRIMMABLE-BOUNDARY-START(1756641689625)
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(94/*KnownColor.LightGoldenrodYellow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1756641689625)
            
            //--TRIMMABLE-BOUNDARY-START(1765231624217)
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(96/*KnownColor.LightGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1765231624217)
            
            //--TRIMMABLE-BOUNDARY-START(1760936656921)
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(95/*KnownColor.LightGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1760936656921)
            
            //--TRIMMABLE-BOUNDARY-START(1769526591513)
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(97/*KnownColor.LightPink*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1769526591513)
            
            //--TRIMMABLE-BOUNDARY-START(1773821558809)
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(98/*KnownColor.LightSalmon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1773821558809)
            
            //--TRIMMABLE-BOUNDARY-START(1778116526105)
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(99/*KnownColor.LightSeaGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1778116526105)
            
            //--TRIMMABLE-BOUNDARY-START(1782411493401)
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(100/*KnownColor.LightSkyBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1782411493401)
            
            //--TRIMMABLE-BOUNDARY-START(1786706460697)
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(101/*KnownColor.LightSlateGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1786706460697)
            
            //--TRIMMABLE-BOUNDARY-START(1791001427993)
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(102/*KnownColor.LightSteelBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1791001427993)
            
            //--TRIMMABLE-BOUNDARY-START(1795296395289)
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(103/*KnownColor.LightYellow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1795296395289)
            
            //--TRIMMABLE-BOUNDARY-START(1799591362585)
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(104/*KnownColor.Lime*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1799591362585)
            
            //--TRIMMABLE-BOUNDARY-START(1803886329881)
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(105/*KnownColor.LimeGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1803886329881)
            
            //--TRIMMABLE-BOUNDARY-START(1808181297177)
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(106/*KnownColor.Linen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1808181297177)
            
            //--TRIMMABLE-BOUNDARY-START(1812476264473)
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(107/*KnownColor.Magenta*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1812476264473)
            
            //--TRIMMABLE-BOUNDARY-START(1816771231769)
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(108/*KnownColor.Maroon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1816771231769)
            
            //--TRIMMABLE-BOUNDARY-START(1821066199065)
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(109/*KnownColor.MediumAquamarine*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1821066199065)
            
            //--TRIMMABLE-BOUNDARY-START(1825361166361)
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(110/*KnownColor.MediumBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1825361166361)
            
            //--TRIMMABLE-BOUNDARY-START(1829656133657)
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(111/*KnownColor.MediumOrchid*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1829656133657)
            
            //--TRIMMABLE-BOUNDARY-START(1833951100953)
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(112/*KnownColor.MediumPurple*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1833951100953)
            
            //--TRIMMABLE-BOUNDARY-START(1838246068249)
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(113/*KnownColor.MediumSeaGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1838246068249)
            
            //--TRIMMABLE-BOUNDARY-START(1842541035545)
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(114/*KnownColor.MediumSlateBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1842541035545)
            
            //--TRIMMABLE-BOUNDARY-START(1846836002841)
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(115/*KnownColor.MediumSpringGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1846836002841)
            
            //--TRIMMABLE-BOUNDARY-START(1851130970137)
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(116/*KnownColor.MediumTurquoise*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1851130970137)
            
            //--TRIMMABLE-BOUNDARY-START(1855425937433)
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(117/*KnownColor.MediumVioletRed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1855425937433)
            
            //--TRIMMABLE-BOUNDARY-START(1859720904729)
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(118/*KnownColor.MidnightBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1859720904729)
            
            //--TRIMMABLE-BOUNDARY-START(1868310839321)
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(119/*KnownColor.MintCream*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1868310839321)
            
            //--TRIMMABLE-BOUNDARY-START(1872605806617)
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(120/*KnownColor.MistyRose*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1872605806617)
            
            //--TRIMMABLE-BOUNDARY-START(1876900773913)
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(121/*KnownColor.Moccasin*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1876900773913)
            
            //--TRIMMABLE-BOUNDARY-START(1894080643097)
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(122/*KnownColor.NavajoWhite*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1894080643097)
            
            //--TRIMMABLE-BOUNDARY-START(1898375610393)
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(123/*KnownColor.Navy*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1898375610393)
            
            //--TRIMMABLE-BOUNDARY-START(1906965544985)
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(124/*KnownColor.OldLace*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1906965544985)
            
            //--TRIMMABLE-BOUNDARY-START(1911260512281)
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(125/*KnownColor.Olive*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1911260512281)
            
            //--TRIMMABLE-BOUNDARY-START(1915555479577)
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(126/*KnownColor.OliveDrab*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1915555479577)
            
            //--TRIMMABLE-BOUNDARY-START(1928440381465)
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(127/*KnownColor.Orange*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1928440381465)
            
            //--TRIMMABLE-BOUNDARY-START(1932735348761)
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(128/*KnownColor.OrangeRed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1932735348761)
            
            //--TRIMMABLE-BOUNDARY-START(1937030316057)
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(129/*KnownColor.Orchid*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1937030316057)
            
            //--TRIMMABLE-BOUNDARY-START(1941325283353)
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(130/*KnownColor.PaleGoldenrod*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1941325283353)
            
            //--TRIMMABLE-BOUNDARY-START(1945620250649)
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(131/*KnownColor.PaleGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1945620250649)
            
            //--TRIMMABLE-BOUNDARY-START(1949915217945)
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(132/*KnownColor.PaleTurquoise*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1949915217945)
            
            //--TRIMMABLE-BOUNDARY-START(1954210185241)
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(133/*KnownColor.PaleVioletRed*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1954210185241)
            
            //--TRIMMABLE-BOUNDARY-START(1958505152537)
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(134/*KnownColor.PapayaWhip*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1958505152537)
            
            //--TRIMMABLE-BOUNDARY-START(1962800119833)
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(135/*KnownColor.PeachPuff*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1962800119833)
            
            //--TRIMMABLE-BOUNDARY-START(1967095087129)
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(136/*KnownColor.Peru*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1967095087129)
            
            //--TRIMMABLE-BOUNDARY-START(1971390054425)
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(137/*KnownColor.Pink*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1971390054425)
            
            //--TRIMMABLE-BOUNDARY-START(1975685021721)
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(138/*KnownColor.Plum*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1975685021721)
            
            //--TRIMMABLE-BOUNDARY-START(1979979989017)
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(139/*KnownColor.PowderBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1979979989017)
            
            //--TRIMMABLE-BOUNDARY-START(1984274956313)
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(140/*KnownColor.Purple*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1984274956313)
            
            //--TRIMMABLE-BOUNDARY-START(1992864890905)
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(175/*KnownColor.RebeccaPurple*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1992864890905)
            
            //--TRIMMABLE-BOUNDARY-START(1997159858201)
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(141/*KnownColor.Red*/);
            }
            //--TRIMMABLE-BOUNDARY-END(1997159858201)
            
            //--TRIMMABLE-BOUNDARY-START(2001454825497)
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(142/*KnownColor.RosyBrown*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2001454825497)
            
            //--TRIMMABLE-BOUNDARY-START(2005749792793)
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(143/*KnownColor.RoyalBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2005749792793)
            
            //--TRIMMABLE-BOUNDARY-START(2010044760089)
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(144/*KnownColor.SaddleBrown*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2010044760089)
            
            //--TRIMMABLE-BOUNDARY-START(2014339727385)
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(145/*KnownColor.Salmon*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2014339727385)
            
            //--TRIMMABLE-BOUNDARY-START(2018634694681)
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(146/*KnownColor.SandyBrown*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2018634694681)
            
            //--TRIMMABLE-BOUNDARY-START(2022929661977)
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(147/*KnownColor.SeaGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2022929661977)
            
            //--TRIMMABLE-BOUNDARY-START(2027224629273)
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(148/*KnownColor.SeaShell*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2027224629273)
            
            //--TRIMMABLE-BOUNDARY-START(2031519596569)
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(149/*KnownColor.Sienna*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2031519596569)
            
            //--TRIMMABLE-BOUNDARY-START(2035814563865)
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(150/*KnownColor.Silver*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2035814563865)
            
            //--TRIMMABLE-BOUNDARY-START(2040109531161)
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(151/*KnownColor.SkyBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2040109531161)
            
            //--TRIMMABLE-BOUNDARY-START(2044404498457)
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(152/*KnownColor.SlateBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2044404498457)
            
            //--TRIMMABLE-BOUNDARY-START(2048699465753)
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(153/*KnownColor.SlateGray*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2048699465753)
            
            //--TRIMMABLE-BOUNDARY-START(2052994433049)
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(154/*KnownColor.Snow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2052994433049)
            
            //--TRIMMABLE-BOUNDARY-START(2057289400345)
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(155/*KnownColor.SpringGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2057289400345)
            
            //--TRIMMABLE-BOUNDARY-START(2083059204121)
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(156/*KnownColor.SteelBlue*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2083059204121)
            
            //--TRIMMABLE-BOUNDARY-START(2087354171417)
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(157/*KnownColor.Tan*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2087354171417)
            
            //--TRIMMABLE-BOUNDARY-START(2091649138713)
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(158/*KnownColor.Teal*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2091649138713)
            
            //--TRIMMABLE-BOUNDARY-START(2095944106009)
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(159/*KnownColor.Thistle*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2095944106009)
            
            //--TRIMMABLE-BOUNDARY-START(2108829007897)
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(160/*KnownColor.Tomato*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2108829007897)
            
            //--TRIMMABLE-BOUNDARY-START(2121713909785)
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(161/*KnownColor.Turquoise*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2121713909785)
            
            //--TRIMMABLE-BOUNDARY-START(2134598811673)
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(162/*KnownColor.Violet*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2134598811673)
            
            //--TRIMMABLE-BOUNDARY-START(2138893778969)
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(163/*KnownColor.Wheat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2138893778969)
            
            //--TRIMMABLE-BOUNDARY-START(2143188746265)
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(164/*KnownColor.White*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2143188746265)
            
            //--TRIMMABLE-BOUNDARY-START(2147483713561)
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(165/*KnownColor.WhiteSmoke*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2147483713561)
            
            //--TRIMMABLE-BOUNDARY-START(2151778680857)
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(166/*KnownColor.Yellow*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2151778680857)
            
            //--TRIMMABLE-BOUNDARY-START(2156073648153)
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(167/*KnownColor.YellowGreen*/);
            }
            //--TRIMMABLE-BOUNDARY-END(2156073648153)
            
            //--TRIMMABLE-BOUNDARY-START(2070174302233)
            /*short*/ static StateKnownColorValid = 1;
            //--TRIMMABLE-BOUNDARY-END(2070174302233)
            
            //--TRIMMABLE-BOUNDARY-START(2065879334937)
            /*short*/ static StateARGBValueValid = 2;
            //--TRIMMABLE-BOUNDARY-END(2065879334937)
            
            //--TRIMMABLE-BOUNDARY-START(2078764236825)
            /*short*/ static StateValueMask = 2;
            //--TRIMMABLE-BOUNDARY-END(2078764236825)
            
            //--TRIMMABLE-BOUNDARY-START(2074469269529)
            /*short*/ static StateNameValid = 8;
            //--TRIMMABLE-BOUNDARY-END(2074469269529)
            
            //--TRIMMABLE-BOUNDARY-START(1902670577689)
            /*long*/ static NotDefinedValue = 0n;
            //--TRIMMABLE-BOUNDARY-END(1902670577689)
            
            //--TRIMMABLE-BOUNDARY-START(42949738521)
            /*int*/ static ARGBAlphaShift = 24;
            //--TRIMMABLE-BOUNDARY-END(42949738521)
            
            //--TRIMMABLE-BOUNDARY-START(68719542297)
            /*int*/ static ARGBRedShift = 16;
            //--TRIMMABLE-BOUNDARY-END(68719542297)
            
            //--TRIMMABLE-BOUNDARY-START(60129607705)
            /*int*/ static ARGBGreenShift = 8;
            //--TRIMMABLE-BOUNDARY-END(60129607705)
            
            //--TRIMMABLE-BOUNDARY-START(51539673113)
            /*int*/ static ARGBBlueShift = 0;
            //--TRIMMABLE-BOUNDARY-END(51539673113)
            
            //--TRIMMABLE-BOUNDARY-START(38654771225)
            /*uint*/ static ARGBAlphaMask = 4278190080;
            //--TRIMMABLE-BOUNDARY-END(38654771225)
            
            //--TRIMMABLE-BOUNDARY-START(64424575001)
            /*uint*/ static ARGBRedMask = 16711680;
            //--TRIMMABLE-BOUNDARY-END(64424575001)
            
            //--TRIMMABLE-BOUNDARY-START(55834640409)
            /*uint*/ static ARGBGreenMask = 65280;
            //--TRIMMABLE-BOUNDARY-END(55834640409)
            
            //--TRIMMABLE-BOUNDARY-START(47244705817)
            /*uint*/ static ARGBBlueMask = 255;
            //--TRIMMABLE-BOUNDARY-END(47244705817)
            
            //--TRIMMABLE-BOUNDARY-START(1881195741209)
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(1881195741209)
            
            //--TRIMMABLE-BOUNDARY-START(2126008877081)
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(2126008877081)
            
            //--TRIMMABLE-BOUNDARY-START(1722281951257)
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            //--TRIMMABLE-BOUNDARY-END(1722281951257)
            
            //--TRIMMABLE-BOUNDARY-START(2061584367641)
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            //--TRIMMABLE-BOUNDARY-END(2061584367641)
            
            //--TRIMMABLE-BOUNDARY-START(12884967449)
            $ctor$4(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967449);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$$.System.Int16);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967449)
            
            //--TRIMMABLE-BOUNDARY-START(8590000153)
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000153);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$$.System.Int16);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590000153)
            
            //--TRIMMABLE-BOUNDARY-START(1988569923609)
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(1988569923609)
            
            //--TRIMMABLE-BOUNDARY-START(304942743577)
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(304942743577)
            
            //--TRIMMABLE-BOUNDARY-START(77309476889)
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(77309476889)
            
            //--TRIMMABLE-BOUNDARY-START(17179934745)
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$$.System.Byte);
            }
            //--TRIMMABLE-BOUNDARY-END(17179934745)
            
            //--TRIMMABLE-BOUNDARY-START(1696512147481)
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            //--TRIMMABLE-BOUNDARY-END(1696512147481)
            
            //--TRIMMABLE-BOUNDARY-START(1692217180185)
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            //--TRIMMABLE-BOUNDARY-END(1692217180185)
            
            //--TRIMMABLE-BOUNDARY-START(1705102082073)
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            //--TRIMMABLE-BOUNDARY-END(1705102082073)
            
            //--TRIMMABLE-BOUNDARY-START(1709397049369)
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            //--TRIMMABLE-BOUNDARY-END(1709397049369)
            
            //--TRIMMABLE-BOUNDARY-START(1700807114777)
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(1700807114777);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1700807114777)
            
            //--TRIMMABLE-BOUNDARY-START(1889785675801)
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            //--TRIMMABLE-BOUNDARY-END(1889785675801)
            
            //--TRIMMABLE-BOUNDARY-START(1885490708505)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1185411039257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$$.System.Diagnostics.Debug.Assert$4($.$$.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$$.System.Int64.ToString$3.call(this.value, "x");
            }
            //--TRIMMABLE-BOUNDARY-END(1885490708505)
            
            //--TRIMMABLE-BOUNDARY-START(2130303844377)
            /*long */ get Value()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1571958095897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(2130303844377)
            
            //--TRIMMABLE-BOUNDARY-START(124554117145)
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554117145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    {
                        throw new $.$$.System.ArgumentException().$ctor$14($.$sdp.System.SR.Format$7($.$sdp.System.SR.InvalidEx2BoundArgument, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ n, $.$box(v, $.$$.System.Int32), $.$box(0/*byte.MinValue*/, $.$$.System.Byte), $.$box(255/*byte.MaxValue*/, $.$$.System.Byte) ], null, null)));
                    }
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554117145)
            
            //--TRIMMABLE-BOUNDARY-START(287762874393)
            static /*Color */ FromArgb$4(/*uint*/ argb)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(287762874393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287762874393)
            
            //--TRIMMABLE-BOUNDARY-START(283467907097)
            static /*Color */ FromArgb$3(/*int*/ argb)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(283467907097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Color.FromArgb$4((argb >>> 0));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283467907097)
            
            //--TRIMMABLE-BOUNDARY-START(270583005209)
            static /*Color */ FromArgb(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583005209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb$4(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(270583005209)
            
            //--TRIMMABLE-BOUNDARY-START(279172939801)
            static /*Color */ FromArgb$2(/*int*/ alpha, /*Color*/ baseColor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279172939801);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb$4(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$$.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            //--TRIMMABLE-BOUNDARY-END(279172939801)
            
            //--TRIMMABLE-BOUNDARY-START(274877972505)
            static /*Color */ FromArgb$1(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(274877972505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Color.FromArgb(255/*byte.MaxValue*/, red, green, blue);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(274877972505)
            
            //--TRIMMABLE-BOUNDARY-START(292057841689)
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(292057841689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$$.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$$.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$4(color);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(292057841689)
            
            //--TRIMMABLE-BOUNDARY-START(296352808985)
            static /*Color */ FromName(/*string*/ name)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296352808985);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            //--TRIMMABLE-BOUNDARY-END(296352808985)
            
            //--TRIMMABLE-BOUNDARY-START(1640677572633)
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1640677572633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let value = $.$cast(this.Value, $.$$.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            //--TRIMMABLE-BOUNDARY-END(1640677572633)
            
            //--TRIMMABLE-BOUNDARY-START(1864015872025)
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1864015872025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1864015872025)
            
            //--TRIMMABLE-BOUNDARY-START(1627792670745)
            /*float */ GetBrightness()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1627792670745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            //--TRIMMABLE-BOUNDARY-END(1627792670745)
            
            //--TRIMMABLE-BOUNDARY-START(1636382605337)
            /*float */ GetHue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1636382605337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            //--TRIMMABLE-BOUNDARY-END(1636382605337)
            
            //--TRIMMABLE-BOUNDARY-START(1644972539929)
            /*float */ GetSaturation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1644972539929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$$.System.Single);
            }
            //--TRIMMABLE-BOUNDARY-END(1644972539929)
            
            //--TRIMMABLE-BOUNDARY-START(2100239073305)
            /*int */ ToArgb()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(2100239073305);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast(this.Value, $.$$.System.Int32);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(2100239073305)
            
            //--TRIMMABLE-BOUNDARY-START(2104534040601)
            /*KnownColor */ ToKnownColor()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(2104534040601);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(2104534040601)
            
            //--TRIMMABLE-BOUNDARY-START(2113123975193)
            static/*conventional*/ /*string */ ToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(2113123975193);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(2113123975193)
            
            //--TRIMMABLE-BOUNDARY-START(1919850446873)
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                {
                    return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$$.System.String.op_Equality(left.name, right.name);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1919850446873)
            
            //--TRIMMABLE-BOUNDARY-START(1924145414169)
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                {
                    return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(1924145414169)
            
            //--TRIMMABLE-BOUNDARY-START(249108168729)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(249108168729);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Color.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(249108168729)
            
            //--TRIMMABLE-BOUNDARY-START(253403136025)
            /*bool */ Equals$2(/*Color*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253403136025);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sdp.System.Drawing.Color.op_Equality(this, other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403136025)
            
            //--TRIMMABLE-BOUNDARY-START(1632087638041)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1632087638041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$$.System.String.GetHashCode.call(this.name);
                }
                return $.$$.System.HashCode.Combine$5($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int64.GetHashCode.call(this.value), $.$$.System.Int16.GetHashCode.call(this.state), $.$$.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(1632087638041)
            
            //--TRIMMABLE-BOUNDARY-START(4385341441)
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385341441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385341441)
            
            //--TRIMMABLE-BOUNDARY-START(4295032857)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032857)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(1881195741209)
                this.name = null;
                //--TRIMMABLE-BOUNDARY-END(1881195741209)
                
                //--TRIMMABLE-BOUNDARY-START(2126008877081)
                this.value = 0n;
                //--TRIMMABLE-BOUNDARY-END(2126008877081)
                
                //--TRIMMABLE-BOUNDARY-START(1722281951257)
                this.knownColor = 0;
                //--TRIMMABLE-BOUNDARY-END(1722281951257)
                
                //--TRIMMABLE-BOUNDARY-START(2061584367641)
                this.state = 0;
                //--TRIMMABLE-BOUNDARY-END(2061584367641)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(244813201433)
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                    //--TRIMMABLE-BOUNDARY-END(244813201433)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65561;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(2117418942489),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1554778226713,
        "f": 50331681
      },
      "n": "Transparent",
      "d": 65561,
      "h": 2117418942489,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2117418942489),
//--TRIMMABLE-BOUNDARY-START(21474902041),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326417580057,
        "f": 50331681
      },
      "n": "AliceBlue",
      "d": 65561,
      "h": 21474902041,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21474902041),
//--TRIMMABLE-BOUNDARY-START(25769869337),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335007514649,
        "f": 50331681
      },
      "n": "AntiqueWhite",
      "d": 65561,
      "h": 25769869337,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25769869337),
//--TRIMMABLE-BOUNDARY-START(30064836633),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343597449241,
        "f": 50331681
      },
      "n": "Aqua",
      "d": 65561,
      "h": 30064836633,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30064836633),
//--TRIMMABLE-BOUNDARY-START(34359803929),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352187383833,
        "f": 50331681
      },
      "n": "Aquamarine",
      "d": 65561,
      "h": 34359803929,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(34359803929),
//--TRIMMABLE-BOUNDARY-START(73014509593),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360777318425,
        "f": 50331681
      },
      "n": "Azure",
      "d": 65561,
      "h": 73014509593,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73014509593),
//--TRIMMABLE-BOUNDARY-START(81604444185),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377957187609,
        "f": 50331681
      },
      "n": "Beige",
      "d": 65561,
      "h": 81604444185,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(81604444185),
//--TRIMMABLE-BOUNDARY-START(85899411481),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386547122201,
        "f": 50331681
      },
      "n": "Bisque",
      "d": 65561,
      "h": 85899411481,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(85899411481),
//--TRIMMABLE-BOUNDARY-START(90194378777),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395137056793,
        "f": 50331681
      },
      "n": "Black",
      "d": 65561,
      "h": 90194378777,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(90194378777),
//--TRIMMABLE-BOUNDARY-START(94489346073),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403726991385,
        "f": 50331681
      },
      "n": "BlanchedAlmond",
      "d": 65561,
      "h": 94489346073,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(94489346073),
//--TRIMMABLE-BOUNDARY-START(98784313369),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412316925977,
        "f": 50331681
      },
      "n": "Blue",
      "d": 65561,
      "h": 98784313369,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(98784313369),
//--TRIMMABLE-BOUNDARY-START(103079280665),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420906860569,
        "f": 50331681
      },
      "n": "BlueViolet",
      "d": 65561,
      "h": 103079280665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(103079280665),
//--TRIMMABLE-BOUNDARY-START(107374247961),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429496795161,
        "f": 50331681
      },
      "n": "Brown",
      "d": 65561,
      "h": 107374247961,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(107374247961),
//--TRIMMABLE-BOUNDARY-START(111669215257),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 438086729753,
        "f": 50331681
      },
      "n": "BurlyWood",
      "d": 65561,
      "h": 111669215257,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(111669215257),
//--TRIMMABLE-BOUNDARY-START(115964182553),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 446676664345,
        "f": 50331681
      },
      "n": "CadetBlue",
      "d": 65561,
      "h": 115964182553,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(115964182553),
//--TRIMMABLE-BOUNDARY-START(120259149849),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 455266598937,
        "f": 50331681
      },
      "n": "Chartreuse",
      "d": 65561,
      "h": 120259149849,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(120259149849),
//--TRIMMABLE-BOUNDARY-START(128849084441),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 463856533529,
        "f": 50331681
      },
      "n": "Chocolate",
      "d": 65561,
      "h": 128849084441,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(128849084441),
//--TRIMMABLE-BOUNDARY-START(133144051737),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 472446468121,
        "f": 50331681
      },
      "n": "Coral",
      "d": 65561,
      "h": 133144051737,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(133144051737),
//--TRIMMABLE-BOUNDARY-START(137439019033),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 481036402713,
        "f": 50331681
      },
      "n": "CornflowerBlue",
      "d": 65561,
      "h": 137439019033,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(137439019033),
//--TRIMMABLE-BOUNDARY-START(141733986329),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 489626337305,
        "f": 50331681
      },
      "n": "Cornsilk",
      "d": 65561,
      "h": 141733986329,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(141733986329),
//--TRIMMABLE-BOUNDARY-START(146028953625),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 498216271897,
        "f": 50331681
      },
      "n": "Crimson",
      "d": 65561,
      "h": 146028953625,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(146028953625),
//--TRIMMABLE-BOUNDARY-START(150323920921),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 506806206489,
        "f": 50331681
      },
      "n": "Cyan",
      "d": 65561,
      "h": 150323920921,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(150323920921),
//--TRIMMABLE-BOUNDARY-START(154618888217),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 515396141081,
        "f": 50331681
      },
      "n": "DarkBlue",
      "d": 65561,
      "h": 154618888217,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(154618888217),
//--TRIMMABLE-BOUNDARY-START(158913855513),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 523986075673,
        "f": 50331681
      },
      "n": "DarkCyan",
      "d": 65561,
      "h": 158913855513,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158913855513),
//--TRIMMABLE-BOUNDARY-START(163208822809),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 532576010265,
        "f": 50331681
      },
      "n": "DarkGoldenrod",
      "d": 65561,
      "h": 163208822809,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(163208822809),
//--TRIMMABLE-BOUNDARY-START(167503790105),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 541165944857,
        "f": 50331681
      },
      "n": "DarkGray",
      "d": 65561,
      "h": 167503790105,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(167503790105),
//--TRIMMABLE-BOUNDARY-START(171798757401),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 549755879449,
        "f": 50331681
      },
      "n": "DarkGreen",
      "d": 65561,
      "h": 171798757401,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(171798757401),
//--TRIMMABLE-BOUNDARY-START(176093724697),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 558345814041,
        "f": 50331681
      },
      "n": "DarkKhaki",
      "d": 65561,
      "h": 176093724697,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(176093724697),
//--TRIMMABLE-BOUNDARY-START(180388691993),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 566935748633,
        "f": 50331681
      },
      "n": "DarkMagenta",
      "d": 65561,
      "h": 180388691993,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(180388691993),
//--TRIMMABLE-BOUNDARY-START(184683659289),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 575525683225,
        "f": 50331681
      },
      "n": "DarkOliveGreen",
      "d": 65561,
      "h": 184683659289,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(184683659289),
//--TRIMMABLE-BOUNDARY-START(188978626585),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 584115617817,
        "f": 50331681
      },
      "n": "DarkOrange",
      "d": 65561,
      "h": 188978626585,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(188978626585),
//--TRIMMABLE-BOUNDARY-START(193273593881),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 592705552409,
        "f": 50331681
      },
      "n": "DarkOrchid",
      "d": 65561,
      "h": 193273593881,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(193273593881),
//--TRIMMABLE-BOUNDARY-START(197568561177),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 601295487001,
        "f": 50331681
      },
      "n": "DarkRed",
      "d": 65561,
      "h": 197568561177,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(197568561177),
//--TRIMMABLE-BOUNDARY-START(201863528473),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 609885421593,
        "f": 50331681
      },
      "n": "DarkSalmon",
      "d": 65561,
      "h": 201863528473,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(201863528473),
//--TRIMMABLE-BOUNDARY-START(206158495769),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 618475356185,
        "f": 50331681
      },
      "n": "DarkSeaGreen",
      "d": 65561,
      "h": 206158495769,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(206158495769),
//--TRIMMABLE-BOUNDARY-START(210453463065),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 627065290777,
        "f": 50331681
      },
      "n": "DarkSlateBlue",
      "d": 65561,
      "h": 210453463065,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(210453463065),
//--TRIMMABLE-BOUNDARY-START(214748430361),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 635655225369,
        "f": 50331681
      },
      "n": "DarkSlateGray",
      "d": 65561,
      "h": 214748430361,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(214748430361),
//--TRIMMABLE-BOUNDARY-START(219043397657),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 644245159961,
        "f": 50331681
      },
      "n": "DarkTurquoise",
      "d": 65561,
      "h": 219043397657,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(219043397657),
//--TRIMMABLE-BOUNDARY-START(223338364953),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 652835094553,
        "f": 50331681
      },
      "n": "DarkViolet",
      "d": 65561,
      "h": 223338364953,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(223338364953),
//--TRIMMABLE-BOUNDARY-START(227633332249),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 661425029145,
        "f": 50331681
      },
      "n": "DeepPink",
      "d": 65561,
      "h": 227633332249,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(227633332249),
//--TRIMMABLE-BOUNDARY-START(231928299545),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 670014963737,
        "f": 50331681
      },
      "n": "DeepSkyBlue",
      "d": 65561,
      "h": 231928299545,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(231928299545),
//--TRIMMABLE-BOUNDARY-START(236223266841),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 678604898329,
        "f": 50331681
      },
      "n": "DimGray",
      "d": 65561,
      "h": 236223266841,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(236223266841),
//--TRIMMABLE-BOUNDARY-START(240518234137),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 687194832921,
        "f": 50331681
      },
      "n": "DodgerBlue",
      "d": 65561,
      "h": 240518234137,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(240518234137),
//--TRIMMABLE-BOUNDARY-START(257698103321),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 695784767513,
        "f": 50331681
      },
      "n": "Firebrick",
      "d": 65561,
      "h": 257698103321,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(257698103321),
//--TRIMMABLE-BOUNDARY-START(261993070617),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 704374702105,
        "f": 50331681
      },
      "n": "FloralWhite",
      "d": 65561,
      "h": 261993070617,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(261993070617),
//--TRIMMABLE-BOUNDARY-START(266288037913),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 712964636697,
        "f": 50331681
      },
      "n": "ForestGreen",
      "d": 65561,
      "h": 266288037913,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(266288037913),
//--TRIMMABLE-BOUNDARY-START(300647776281),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 721554571289,
        "f": 50331681
      },
      "n": "Fuchsia",
      "d": 65561,
      "h": 300647776281,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(300647776281),
//--TRIMMABLE-BOUNDARY-START(309237710873),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 738734440473,
        "f": 50331681
      },
      "n": "Gainsboro",
      "d": 65561,
      "h": 309237710873,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(309237710873),
//--TRIMMABLE-BOUNDARY-START(1649267507225),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 747324375065,
        "f": 50331681
      },
      "n": "GhostWhite",
      "d": 65561,
      "h": 1649267507225,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1649267507225),
//--TRIMMABLE-BOUNDARY-START(1653562474521),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 755914309657,
        "f": 50331681
      },
      "n": "Gold",
      "d": 65561,
      "h": 1653562474521,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1653562474521),
//--TRIMMABLE-BOUNDARY-START(1657857441817),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 764504244249,
        "f": 50331681
      },
      "n": "Goldenrod",
      "d": 65561,
      "h": 1657857441817,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1657857441817),
//--TRIMMABLE-BOUNDARY-START(1662152409113),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 773094178841,
        "f": 50331681
      },
      "n": "Gray",
      "d": 65561,
      "h": 1662152409113,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1662152409113),
//--TRIMMABLE-BOUNDARY-START(1666447376409),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 781684113433,
        "f": 50331681
      },
      "n": "Green",
      "d": 65561,
      "h": 1666447376409,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1666447376409),
//--TRIMMABLE-BOUNDARY-START(1670742343705),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 790274048025,
        "f": 50331681
      },
      "n": "GreenYellow",
      "d": 65561,
      "h": 1670742343705,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1670742343705),
//--TRIMMABLE-BOUNDARY-START(1675037311001),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 798863982617,
        "f": 50331681
      },
      "n": "Honeydew",
      "d": 65561,
      "h": 1675037311001,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1675037311001),
//--TRIMMABLE-BOUNDARY-START(1679332278297),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 807453917209,
        "f": 50331681
      },
      "n": "HotPink",
      "d": 65561,
      "h": 1679332278297,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1679332278297),
//--TRIMMABLE-BOUNDARY-START(1683627245593),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 816043851801,
        "f": 50331681
      },
      "n": "IndianRed",
      "d": 65561,
      "h": 1683627245593,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1683627245593),
//--TRIMMABLE-BOUNDARY-START(1687922212889),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 824633786393,
        "f": 50331681
      },
      "n": "Indigo",
      "d": 65561,
      "h": 1687922212889,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1687922212889),
//--TRIMMABLE-BOUNDARY-START(1713692016665),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 867583459353,
        "f": 50331681
      },
      "n": "Ivory",
      "d": 65561,
      "h": 1713692016665,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1713692016665),
//--TRIMMABLE-BOUNDARY-START(1717986983961),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 876173393945,
        "f": 50331681
      },
      "n": "Khaki",
      "d": 65561,
      "h": 1717986983961,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1717986983961),
//--TRIMMABLE-BOUNDARY-START(1726576918553),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 884763328537,
        "f": 50331681
      },
      "n": "Lavender",
      "d": 65561,
      "h": 1726576918553,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1726576918553),
//--TRIMMABLE-BOUNDARY-START(1730871885849),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 893353263129,
        "f": 50331681
      },
      "n": "LavenderBlush",
      "d": 65561,
      "h": 1730871885849,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1730871885849),
//--TRIMMABLE-BOUNDARY-START(1735166853145),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 901943197721,
        "f": 50331681
      },
      "n": "LawnGreen",
      "d": 65561,
      "h": 1735166853145,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1735166853145),
//--TRIMMABLE-BOUNDARY-START(1739461820441),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 910533132313,
        "f": 50331681
      },
      "n": "LemonChiffon",
      "d": 65561,
      "h": 1739461820441,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1739461820441),
//--TRIMMABLE-BOUNDARY-START(1743756787737),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 919123066905,
        "f": 50331681
      },
      "n": "LightBlue",
      "d": 65561,
      "h": 1743756787737,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1743756787737),
//--TRIMMABLE-BOUNDARY-START(1748051755033),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 927713001497,
        "f": 50331681
      },
      "n": "LightCoral",
      "d": 65561,
      "h": 1748051755033,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1748051755033),
//--TRIMMABLE-BOUNDARY-START(1752346722329),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 936302936089,
        "f": 50331681
      },
      "n": "LightCyan",
      "d": 65561,
      "h": 1752346722329,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1752346722329),
//--TRIMMABLE-BOUNDARY-START(1756641689625),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 944892870681,
        "f": 50331681
      },
      "n": "LightGoldenrodYellow",
      "d": 65561,
      "h": 1756641689625,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1756641689625),
//--TRIMMABLE-BOUNDARY-START(1765231624217),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 962072739865,
        "f": 50331681
      },
      "n": "LightGreen",
      "d": 65561,
      "h": 1765231624217,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1765231624217),
//--TRIMMABLE-BOUNDARY-START(1760936656921),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 953482805273,
        "f": 50331681
      },
      "n": "LightGray",
      "d": 65561,
      "h": 1760936656921,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1760936656921),
//--TRIMMABLE-BOUNDARY-START(1769526591513),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 970662674457,
        "f": 50331681
      },
      "n": "LightPink",
      "d": 65561,
      "h": 1769526591513,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1769526591513),
//--TRIMMABLE-BOUNDARY-START(1773821558809),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 979252609049,
        "f": 50331681
      },
      "n": "LightSalmon",
      "d": 65561,
      "h": 1773821558809,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1773821558809),
//--TRIMMABLE-BOUNDARY-START(1778116526105),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 987842543641,
        "f": 50331681
      },
      "n": "LightSeaGreen",
      "d": 65561,
      "h": 1778116526105,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1778116526105),
//--TRIMMABLE-BOUNDARY-START(1782411493401),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 996432478233,
        "f": 50331681
      },
      "n": "LightSkyBlue",
      "d": 65561,
      "h": 1782411493401,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1782411493401),
//--TRIMMABLE-BOUNDARY-START(1786706460697),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1005022412825,
        "f": 50331681
      },
      "n": "LightSlateGray",
      "d": 65561,
      "h": 1786706460697,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1786706460697),
//--TRIMMABLE-BOUNDARY-START(1791001427993),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1013612347417,
        "f": 50331681
      },
      "n": "LightSteelBlue",
      "d": 65561,
      "h": 1791001427993,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1791001427993),
//--TRIMMABLE-BOUNDARY-START(1795296395289),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1022202282009,
        "f": 50331681
      },
      "n": "LightYellow",
      "d": 65561,
      "h": 1795296395289,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1795296395289),
//--TRIMMABLE-BOUNDARY-START(1799591362585),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1030792216601,
        "f": 50331681
      },
      "n": "Lime",
      "d": 65561,
      "h": 1799591362585,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1799591362585),
//--TRIMMABLE-BOUNDARY-START(1803886329881),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1039382151193,
        "f": 50331681
      },
      "n": "LimeGreen",
      "d": 65561,
      "h": 1803886329881,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1803886329881),
//--TRIMMABLE-BOUNDARY-START(1808181297177),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1047972085785,
        "f": 50331681
      },
      "n": "Linen",
      "d": 65561,
      "h": 1808181297177,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1808181297177),
//--TRIMMABLE-BOUNDARY-START(1812476264473),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1056562020377,
        "f": 50331681
      },
      "n": "Magenta",
      "d": 65561,
      "h": 1812476264473,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1812476264473),
//--TRIMMABLE-BOUNDARY-START(1816771231769),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1065151954969,
        "f": 50331681
      },
      "n": "Maroon",
      "d": 65561,
      "h": 1816771231769,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1816771231769),
//--TRIMMABLE-BOUNDARY-START(1821066199065),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1073741889561,
        "f": 50331681
      },
      "n": "MediumAquamarine",
      "d": 65561,
      "h": 1821066199065,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1821066199065),
//--TRIMMABLE-BOUNDARY-START(1825361166361),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1082331824153,
        "f": 50331681
      },
      "n": "MediumBlue",
      "d": 65561,
      "h": 1825361166361,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1825361166361),
//--TRIMMABLE-BOUNDARY-START(1829656133657),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1090921758745,
        "f": 50331681
      },
      "n": "MediumOrchid",
      "d": 65561,
      "h": 1829656133657,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1829656133657),
//--TRIMMABLE-BOUNDARY-START(1833951100953),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1099511693337,
        "f": 50331681
      },
      "n": "MediumPurple",
      "d": 65561,
      "h": 1833951100953,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1833951100953),
//--TRIMMABLE-BOUNDARY-START(1838246068249),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1108101627929,
        "f": 50331681
      },
      "n": "MediumSeaGreen",
      "d": 65561,
      "h": 1838246068249,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1838246068249),
//--TRIMMABLE-BOUNDARY-START(1842541035545),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1116691562521,
        "f": 50331681
      },
      "n": "MediumSlateBlue",
      "d": 65561,
      "h": 1842541035545,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1842541035545),
//--TRIMMABLE-BOUNDARY-START(1846836002841),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1125281497113,
        "f": 50331681
      },
      "n": "MediumSpringGreen",
      "d": 65561,
      "h": 1846836002841,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1846836002841),
//--TRIMMABLE-BOUNDARY-START(1851130970137),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1133871431705,
        "f": 50331681
      },
      "n": "MediumTurquoise",
      "d": 65561,
      "h": 1851130970137,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1851130970137),
//--TRIMMABLE-BOUNDARY-START(1855425937433),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1142461366297,
        "f": 50331681
      },
      "n": "MediumVioletRed",
      "d": 65561,
      "h": 1855425937433,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1855425937433),
//--TRIMMABLE-BOUNDARY-START(1859720904729),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1151051300889,
        "f": 50331681
      },
      "n": "MidnightBlue",
      "d": 65561,
      "h": 1859720904729,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1859720904729),
//--TRIMMABLE-BOUNDARY-START(1868310839321),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1159641235481,
        "f": 50331681
      },
      "n": "MintCream",
      "d": 65561,
      "h": 1868310839321,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1868310839321),
//--TRIMMABLE-BOUNDARY-START(1872605806617),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1168231170073,
        "f": 50331681
      },
      "n": "MistyRose",
      "d": 65561,
      "h": 1872605806617,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1872605806617),
//--TRIMMABLE-BOUNDARY-START(1876900773913),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1176821104665,
        "f": 50331681
      },
      "n": "Moccasin",
      "d": 65561,
      "h": 1876900773913,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1876900773913),
//--TRIMMABLE-BOUNDARY-START(1894080643097),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1202590908441,
        "f": 50331681
      },
      "n": "NavajoWhite",
      "d": 65561,
      "h": 1894080643097,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1894080643097),
//--TRIMMABLE-BOUNDARY-START(1898375610393),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1211180843033,
        "f": 50331681
      },
      "n": "Navy",
      "d": 65561,
      "h": 1898375610393,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1898375610393),
//--TRIMMABLE-BOUNDARY-START(1906965544985),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1219770777625,
        "f": 50331681
      },
      "n": "OldLace",
      "d": 65561,
      "h": 1906965544985,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1906965544985),
//--TRIMMABLE-BOUNDARY-START(1911260512281),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1228360712217,
        "f": 50331681
      },
      "n": "Olive",
      "d": 65561,
      "h": 1911260512281,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1911260512281),
//--TRIMMABLE-BOUNDARY-START(1915555479577),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1236950646809,
        "f": 50331681
      },
      "n": "OliveDrab",
      "d": 65561,
      "h": 1915555479577,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1915555479577),
//--TRIMMABLE-BOUNDARY-START(1928440381465),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1245540581401,
        "f": 50331681
      },
      "n": "Orange",
      "d": 65561,
      "h": 1928440381465,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1928440381465),
//--TRIMMABLE-BOUNDARY-START(1932735348761),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1254130515993,
        "f": 50331681
      },
      "n": "OrangeRed",
      "d": 65561,
      "h": 1932735348761,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1932735348761),
//--TRIMMABLE-BOUNDARY-START(1937030316057),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1262720450585,
        "f": 50331681
      },
      "n": "Orchid",
      "d": 65561,
      "h": 1937030316057,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1937030316057),
//--TRIMMABLE-BOUNDARY-START(1941325283353),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1271310385177,
        "f": 50331681
      },
      "n": "PaleGoldenrod",
      "d": 65561,
      "h": 1941325283353,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1941325283353),
//--TRIMMABLE-BOUNDARY-START(1945620250649),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1279900319769,
        "f": 50331681
      },
      "n": "PaleGreen",
      "d": 65561,
      "h": 1945620250649,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1945620250649),
//--TRIMMABLE-BOUNDARY-START(1949915217945),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1288490254361,
        "f": 50331681
      },
      "n": "PaleTurquoise",
      "d": 65561,
      "h": 1949915217945,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1949915217945),
//--TRIMMABLE-BOUNDARY-START(1954210185241),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1297080188953,
        "f": 50331681
      },
      "n": "PaleVioletRed",
      "d": 65561,
      "h": 1954210185241,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1954210185241),
//--TRIMMABLE-BOUNDARY-START(1958505152537),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1305670123545,
        "f": 50331681
      },
      "n": "PapayaWhip",
      "d": 65561,
      "h": 1958505152537,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1958505152537),
//--TRIMMABLE-BOUNDARY-START(1962800119833),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1314260058137,
        "f": 50331681
      },
      "n": "PeachPuff",
      "d": 65561,
      "h": 1962800119833,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1962800119833),
//--TRIMMABLE-BOUNDARY-START(1967095087129),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1322849992729,
        "f": 50331681
      },
      "n": "Peru",
      "d": 65561,
      "h": 1967095087129,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1967095087129),
//--TRIMMABLE-BOUNDARY-START(1971390054425),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1331439927321,
        "f": 50331681
      },
      "n": "Pink",
      "d": 65561,
      "h": 1971390054425,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1971390054425),
//--TRIMMABLE-BOUNDARY-START(1975685021721),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1340029861913,
        "f": 50331681
      },
      "n": "Plum",
      "d": 65561,
      "h": 1975685021721,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1975685021721),
//--TRIMMABLE-BOUNDARY-START(1979979989017),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1348619796505,
        "f": 50331681
      },
      "n": "PowderBlue",
      "d": 65561,
      "h": 1979979989017,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1979979989017),
//--TRIMMABLE-BOUNDARY-START(1984274956313),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1357209731097,
        "f": 50331681
      },
      "n": "Purple",
      "d": 65561,
      "h": 1984274956313,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1984274956313),
//--TRIMMABLE-BOUNDARY-START(1992864890905),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1374389600281,
        "f": 50331681
      },
      "n": "RebeccaPurple",
      "d": 65561,
      "h": 1992864890905,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1992864890905),
//--TRIMMABLE-BOUNDARY-START(1997159858201),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1382979534873,
        "f": 50331681
      },
      "n": "Red",
      "d": 65561,
      "h": 1997159858201,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(1997159858201),
//--TRIMMABLE-BOUNDARY-START(2001454825497),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1391569469465,
        "f": 50331681
      },
      "n": "RosyBrown",
      "d": 65561,
      "h": 2001454825497,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2001454825497),
//--TRIMMABLE-BOUNDARY-START(2005749792793),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1400159404057,
        "f": 50331681
      },
      "n": "RoyalBlue",
      "d": 65561,
      "h": 2005749792793,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2005749792793),
//--TRIMMABLE-BOUNDARY-START(2010044760089),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1408749338649,
        "f": 50331681
      },
      "n": "SaddleBrown",
      "d": 65561,
      "h": 2010044760089,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2010044760089),
//--TRIMMABLE-BOUNDARY-START(2014339727385),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1417339273241,
        "f": 50331681
      },
      "n": "Salmon",
      "d": 65561,
      "h": 2014339727385,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2014339727385),
//--TRIMMABLE-BOUNDARY-START(2018634694681),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1425929207833,
        "f": 50331681
      },
      "n": "SandyBrown",
      "d": 65561,
      "h": 2018634694681,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2018634694681),
//--TRIMMABLE-BOUNDARY-START(2022929661977),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1434519142425,
        "f": 50331681
      },
      "n": "SeaGreen",
      "d": 65561,
      "h": 2022929661977,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2022929661977),
//--TRIMMABLE-BOUNDARY-START(2027224629273),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1443109077017,
        "f": 50331681
      },
      "n": "SeaShell",
      "d": 65561,
      "h": 2027224629273,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2027224629273),
//--TRIMMABLE-BOUNDARY-START(2031519596569),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1451699011609,
        "f": 50331681
      },
      "n": "Sienna",
      "d": 65561,
      "h": 2031519596569,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2031519596569),
//--TRIMMABLE-BOUNDARY-START(2035814563865),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1460288946201,
        "f": 50331681
      },
      "n": "Silver",
      "d": 65561,
      "h": 2035814563865,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2035814563865),
//--TRIMMABLE-BOUNDARY-START(2040109531161),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1468878880793,
        "f": 50331681
      },
      "n": "SkyBlue",
      "d": 65561,
      "h": 2040109531161,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2040109531161),
//--TRIMMABLE-BOUNDARY-START(2044404498457),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1477468815385,
        "f": 50331681
      },
      "n": "SlateBlue",
      "d": 65561,
      "h": 2044404498457,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2044404498457),
//--TRIMMABLE-BOUNDARY-START(2048699465753),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1486058749977,
        "f": 50331681
      },
      "n": "SlateGray",
      "d": 65561,
      "h": 2048699465753,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2048699465753),
//--TRIMMABLE-BOUNDARY-START(2052994433049),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1494648684569,
        "f": 50331681
      },
      "n": "Snow",
      "d": 65561,
      "h": 2052994433049,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2052994433049),
//--TRIMMABLE-BOUNDARY-START(2057289400345),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1503238619161,
        "f": 50331681
      },
      "n": "SpringGreen",
      "d": 65561,
      "h": 2057289400345,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2057289400345),
//--TRIMMABLE-BOUNDARY-START(2083059204121),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1511828553753,
        "f": 50331681
      },
      "n": "SteelBlue",
      "d": 65561,
      "h": 2083059204121,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2083059204121),
//--TRIMMABLE-BOUNDARY-START(2087354171417),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1520418488345,
        "f": 50331681
      },
      "n": "Tan",
      "d": 65561,
      "h": 2087354171417,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2087354171417),
//--TRIMMABLE-BOUNDARY-START(2091649138713),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1529008422937,
        "f": 50331681
      },
      "n": "Teal",
      "d": 65561,
      "h": 2091649138713,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2091649138713),
//--TRIMMABLE-BOUNDARY-START(2095944106009),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1537598357529,
        "f": 50331681
      },
      "n": "Thistle",
      "d": 65561,
      "h": 2095944106009,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2095944106009),
//--TRIMMABLE-BOUNDARY-START(2108829007897),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1546188292121,
        "f": 50331681
      },
      "n": "Tomato",
      "d": 65561,
      "h": 2108829007897,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2108829007897),
//--TRIMMABLE-BOUNDARY-START(2121713909785),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1563368161305,
        "f": 50331681
      },
      "n": "Turquoise",
      "d": 65561,
      "h": 2121713909785,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2121713909785),
//--TRIMMABLE-BOUNDARY-START(2134598811673),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1580548030489,
        "f": 50331681
      },
      "n": "Violet",
      "d": 65561,
      "h": 2134598811673,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2134598811673),
//--TRIMMABLE-BOUNDARY-START(2138893778969),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1589137965081,
        "f": 50331681
      },
      "n": "Wheat",
      "d": 65561,
      "h": 2138893778969,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2138893778969),
//--TRIMMABLE-BOUNDARY-START(2143188746265),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1597727899673,
        "f": 50331681
      },
      "n": "White",
      "d": 65561,
      "h": 2143188746265,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2143188746265),
//--TRIMMABLE-BOUNDARY-START(2147483713561),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1606317834265,
        "f": 50331681
      },
      "n": "WhiteSmoke",
      "d": 65561,
      "h": 2147483713561,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2147483713561),
//--TRIMMABLE-BOUNDARY-START(2151778680857),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1614907768857,
        "f": 50331681
      },
      "n": "Yellow",
      "d": 65561,
      "h": 2151778680857,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2151778680857),
//--TRIMMABLE-BOUNDARY-START(2156073648153),
    {
      "p": 65561,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1623497703449,
        "f": 50331681
      },
      "n": "YellowGreen",
      "d": 65561,
      "h": 2156073648153,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(2156073648153),
//--TRIMMABLE-BOUNDARY-START(1988569923609),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1365799665689,
        "f": 50331649
      },
      "n": "R",
      "d": 65561,
      "h": 1988569923609,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1988569923609),
//--TRIMMABLE-BOUNDARY-START(304942743577),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 730144505881,
        "f": 50331649
      },
      "n": "G",
      "d": 65561,
      "h": 304942743577,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(304942743577),
//--TRIMMABLE-BOUNDARY-START(77309476889),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369367253017,
        "f": 50331649
      },
      "n": "B",
      "d": 65561,
      "h": 77309476889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309476889),
//--TRIMMABLE-BOUNDARY-START(17179934745),
    {
      "p": 393217,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317827645465,
        "f": 50331649
      },
      "n": "A",
      "d": 65561,
      "h": 17179934745,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17179934745),
//--TRIMMABLE-BOUNDARY-START(1696512147481),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 841813655577,
        "f": 50331649
      },
      "n": "IsKnownColor",
      "d": 65561,
      "h": 1696512147481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1696512147481),
//--TRIMMABLE-BOUNDARY-START(1692217180185),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 833223720985,
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": 65561,
      "h": 1692217180185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1692217180185),
//--TRIMMABLE-BOUNDARY-START(1705102082073),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 850403590169,
        "f": 50331649
      },
      "n": "IsNamedColor",
      "d": 65561,
      "h": 1705102082073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1705102082073),
//--TRIMMABLE-BOUNDARY-START(1709397049369),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 858993524761,
        "f": 50331649
      },
      "n": "IsSystemColor",
      "d": 65561,
      "h": 1709397049369,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1709397049369),
//--TRIMMABLE-BOUNDARY-START(1889785675801),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1194000973849,
        "f": 50331650
      },
      "n": "NameAndARGBValue",
      "d": 65561,
      "h": 1889785675801,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(1889785675801),
//--TRIMMABLE-BOUNDARY-START(1885490708505),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1185411039257,
        "f": 50331649
      },
      "n": "Name",
      "d": 65561,
      "h": 1885490708505,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1885490708505),
//--TRIMMABLE-BOUNDARY-START(2130303844377),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 1571958095897,
        "f": 50331650
      },
      "n": "Value",
      "d": 65561,
      "h": 2130303844377,
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(2130303844377)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(1700807114777),
    {
      "r": 262145,
      "p": [
        {
          "n": "knownColor",
          "p": 327705
        }
      ],
      "n": "IsKnownColorSystem",
      "d": 65561,
      "h": 1700807114777,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(1700807114777),
//--TRIMMABLE-BOUNDARY-START(124554117145),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 655361
        },
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "CheckByte",
      "d": 65561,
      "h": 124554117145,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(124554117145),
//--TRIMMABLE-BOUNDARY-START(287762874393),
    {
      "r": 65561,
      "p": [
        {
          "n": "argb",
          "p": 720897
        }
      ],
      "n": "FromArgb",
      "o": "@$4",
      "d": 65561,
      "h": 287762874393,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(287762874393),
//--TRIMMABLE-BOUNDARY-START(283467907097),
    {
      "r": 65561,
      "p": [
        {
          "n": "argb",
          "p": 655361
        }
      ],
      "n": "FromArgb",
      "o": "@$3",
      "d": 65561,
      "h": 283467907097,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(283467907097),
//--TRIMMABLE-BOUNDARY-START(270583005209),
    {
      "r": 65561,
      "p": [
        {
          "n": "alpha",
          "p": 655361
        },
        {
          "n": "red",
          "p": 655361
        },
        {
          "n": "green",
          "p": 655361
        },
        {
          "n": "blue",
          "p": 655361
        }
      ],
      "n": "FromArgb",
      "d": 65561,
      "h": 270583005209,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(270583005209),
//--TRIMMABLE-BOUNDARY-START(279172939801),
    {
      "r": 65561,
      "p": [
        {
          "n": "alpha",
          "p": 655361
        },
        {
          "n": "baseColor",
          "p": 65561
        }
      ],
      "n": "FromArgb",
      "o": "@$2",
      "d": 65561,
      "h": 279172939801,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(279172939801),
//--TRIMMABLE-BOUNDARY-START(274877972505),
    {
      "r": 65561,
      "p": [
        {
          "n": "red",
          "p": 655361
        },
        {
          "n": "green",
          "p": 655361
        },
        {
          "n": "blue",
          "p": 655361
        }
      ],
      "n": "FromArgb",
      "o": "@$1",
      "d": 65561,
      "h": 274877972505,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(274877972505),
//--TRIMMABLE-BOUNDARY-START(292057841689),
    {
      "r": 65561,
      "p": [
        {
          "n": "color",
          "p": 327705
        }
      ],
      "n": "FromKnownColor",
      "d": 65561,
      "h": 292057841689,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(292057841689),
//--TRIMMABLE-BOUNDARY-START(296352808985),
    {
      "r": 65561,
      "p": [
        {
          "n": "name",
          "p": 1310721
        }
      ],
      "n": "FromName",
      "d": 65561,
      "h": 296352808985,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(296352808985),
//--TRIMMABLE-BOUNDARY-START(1640677572633),
    {
      "r": 65537,
      "p": [
        {
          "n": "r",
          "p": 655361,
          "f": 2
        },
        {
          "n": "g",
          "p": 655361,
          "f": 2
        },
        {
          "n": "b",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "GetRgbValues",
      "d": 65561,
      "h": 1640677572633,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(1640677572633),
//--TRIMMABLE-BOUNDARY-START(1864015872025),
    {
      "r": 65537,
      "p": [
        {
          "n": "min",
          "p": 655361,
          "f": 2
        },
        {
          "n": "max",
          "p": 655361,
          "f": 2
        },
        {
          "n": "r",
          "p": 655361
        },
        {
          "n": "g",
          "p": 655361
        },
        {
          "n": "b",
          "p": 655361
        }
      ],
      "n": "MinMaxRgb",
      "d": 65561,
      "h": 1864015872025,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(1864015872025),
//--TRIMMABLE-BOUNDARY-START(1627792670745),
    {
      "r": 1114113,
      "n": "GetBrightness",
      "d": 65561,
      "h": 1627792670745,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1627792670745),
//--TRIMMABLE-BOUNDARY-START(1636382605337),
    {
      "r": 1114113,
      "n": "GetHue",
      "d": 65561,
      "h": 1636382605337,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1636382605337),
//--TRIMMABLE-BOUNDARY-START(1644972539929),
    {
      "r": 1114113,
      "n": "GetSaturation",
      "d": 65561,
      "h": 1644972539929,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(1644972539929),
//--TRIMMABLE-BOUNDARY-START(2100239073305),
    {
      "r": 655361,
      "n": "ToArgb",
      "d": 65561,
      "h": 2100239073305,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(2100239073305),
//--TRIMMABLE-BOUNDARY-START(2104534040601),
    {
      "r": 327705,
      "n": "ToKnownColor",
      "d": 65561,
      "h": 2104534040601,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(2104534040601),
//--TRIMMABLE-BOUNDARY-START(2113123975193),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 65561,
      "h": 2113123975193,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(2113123975193),
//--TRIMMABLE-BOUNDARY-START(249108168729),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 65561,
      "h": 249108168729,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108168729),
//--TRIMMABLE-BOUNDARY-START(253403136025),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 65561
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 65561,
      "h": 253403136025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403136025),
//--TRIMMABLE-BOUNDARY-START(1632087638041),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 65561,
      "h": 1632087638041,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(1632087638041)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(244813201433),
    {
      "t": 65561,
      "n": "Empty",
      "d": 65561,
      "h": 244813201433,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813201433),
//--TRIMMABLE-BOUNDARY-START(2070174302233),
    {
      "t": 524289,
      "n": "StateKnownColorValid",
      "d": 65561,
      "h": 2070174302233,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(2070174302233),
//--TRIMMABLE-BOUNDARY-START(2065879334937),
    {
      "t": 524289,
      "n": "StateARGBValueValid",
      "d": 65561,
      "h": 2065879334937,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(2065879334937),
//--TRIMMABLE-BOUNDARY-START(2078764236825),
    {
      "t": 524289,
      "n": "StateValueMask",
      "d": 65561,
      "h": 2078764236825,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(2078764236825),
//--TRIMMABLE-BOUNDARY-START(2074469269529),
    {
      "t": 524289,
      "n": "StateNameValid",
      "d": 65561,
      "h": 2074469269529,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(2074469269529),
//--TRIMMABLE-BOUNDARY-START(1902670577689),
    {
      "t": 917505,
      "n": "NotDefinedValue",
      "d": 65561,
      "h": 1902670577689,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(1902670577689),
//--TRIMMABLE-BOUNDARY-START(42949738521),
    {
      "t": 655361,
      "n": "ARGBAlphaShift",
      "d": 65561,
      "h": 42949738521,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42949738521),
//--TRIMMABLE-BOUNDARY-START(68719542297),
    {
      "t": 655361,
      "n": "ARGBRedShift",
      "d": 65561,
      "h": 68719542297,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68719542297),
//--TRIMMABLE-BOUNDARY-START(60129607705),
    {
      "t": 655361,
      "n": "ARGBGreenShift",
      "d": 65561,
      "h": 60129607705,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60129607705),
//--TRIMMABLE-BOUNDARY-START(51539673113),
    {
      "t": 655361,
      "n": "ARGBBlueShift",
      "d": 65561,
      "h": 51539673113,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51539673113),
//--TRIMMABLE-BOUNDARY-START(38654771225),
    {
      "t": 720897,
      "n": "ARGBAlphaMask",
      "d": 65561,
      "h": 38654771225,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38654771225),
//--TRIMMABLE-BOUNDARY-START(64424575001),
    {
      "t": 720897,
      "n": "ARGBRedMask",
      "d": 65561,
      "h": 64424575001,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64424575001),
//--TRIMMABLE-BOUNDARY-START(55834640409),
    {
      "t": 720897,
      "n": "ARGBGreenMask",
      "d": 65561,
      "h": 55834640409,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55834640409),
//--TRIMMABLE-BOUNDARY-START(47244705817),
    {
      "t": 720897,
      "n": "ARGBBlueMask",
      "d": 65561,
      "h": 47244705817,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47244705817),
//--TRIMMABLE-BOUNDARY-START(1881195741209),
    {
      "t": 1310721,
      "n": "name",
      "d": 65561,
      "h": 1881195741209,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(1881195741209),
//--TRIMMABLE-BOUNDARY-START(2126008877081),
    {
      "t": 917505,
      "n": "value",
      "d": 65561,
      "h": 2126008877081,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(2126008877081),
//--TRIMMABLE-BOUNDARY-START(1722281951257),
    {
      "t": 524289,
      "n": "knownColor",
      "d": 65561,
      "h": 1722281951257,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(1722281951257),
//--TRIMMABLE-BOUNDARY-START(2061584367641),
    {
      "t": 524289,
      "n": "state",
      "d": 65561,
      "h": 2061584367641,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(2061584367641)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967449),
    {
      "p": [
        {
          "n": "knownColor",
          "p": 327705
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 65561,
      "h": 12884967449,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12884967449),
//--TRIMMABLE-BOUNDARY-START(8590000153),
    {
      "p": [
        {
          "n": "value",
          "p": 917505
        },
        {
          "n": "state",
          "p": 524289
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "knownColor",
          "p": 327705
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65561,
      "h": 8590000153,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590000153),
//--TRIMMABLE-BOUNDARY-START(4295032857),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 65561,
      "h": 4295032857,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032857)
  ],
  "i": [$.$$.System.IEquatable$$($.$sdp.System.Drawing.Color).$h
  ],
  "h": 65561,
  "a": [
    {
      "t": 70385665,
      "c": 25840189441,
      "a": [
        {
          "v": "{NameAndARGBValue}",
          "t": 1310721
        }
      ]
    },
    {
      "t": 852008,
      "c": 21475688488,
      "a": [
        {
          "v": "System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        },
        {
          "v": "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 162332673,
      "c": 4457299969
    },
    {
      "t": 1572882,
      "c": 17181442066,
      "a": [
        {
          "v": "System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    },
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65561)
        
        
        //--TRIMMABLE-BOUNDARY-START(327705)
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$$.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 327705;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262297),
    {
      "t": 327705,
      "n": "ActiveBorder",
      "d": 327705,
      "h": 8590262297,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262297),
//--TRIMMABLE-BOUNDARY-START(12885229593),
    {
      "t": 327705,
      "n": "ActiveCaption",
      "d": 327705,
      "h": 12885229593,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229593),
//--TRIMMABLE-BOUNDARY-START(17180196889),
    {
      "t": 327705,
      "n": "ActiveCaptionText",
      "d": 327705,
      "h": 17180196889,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196889),
//--TRIMMABLE-BOUNDARY-START(30065098777),
    {
      "t": 327705,
      "n": "AppWorkspace",
      "d": 327705,
      "h": 30065098777,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065098777),
//--TRIMMABLE-BOUNDARY-START(107374510105),
    {
      "t": 327705,
      "n": "Control",
      "d": 327705,
      "h": 107374510105,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374510105),
//--TRIMMABLE-BOUNDARY-START(111669477401),
    {
      "t": 327705,
      "n": "ControlDark",
      "d": 327705,
      "h": 111669477401,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669477401),
//--TRIMMABLE-BOUNDARY-START(115964444697),
    {
      "t": 327705,
      "n": "ControlDarkDark",
      "d": 327705,
      "h": 115964444697,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964444697),
//--TRIMMABLE-BOUNDARY-START(120259411993),
    {
      "t": 327705,
      "n": "ControlLight",
      "d": 327705,
      "h": 120259411993,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259411993),
//--TRIMMABLE-BOUNDARY-START(124554379289),
    {
      "t": 327705,
      "n": "ControlLightLight",
      "d": 327705,
      "h": 124554379289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554379289),
//--TRIMMABLE-BOUNDARY-START(128849346585),
    {
      "t": 327705,
      "n": "ControlText",
      "d": 327705,
      "h": 128849346585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849346585),
//--TRIMMABLE-BOUNDARY-START(236223528985),
    {
      "t": 327705,
      "n": "Desktop",
      "d": 327705,
      "h": 236223528985,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236223528985),
//--TRIMMABLE-BOUNDARY-START(296353071129),
    {
      "t": 327705,
      "n": "GrayText",
      "d": 327705,
      "h": 296353071129,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296353071129),
//--TRIMMABLE-BOUNDARY-START(309237973017),
    {
      "t": 327705,
      "n": "Highlight",
      "d": 327705,
      "h": 309237973017,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309237973017),
//--TRIMMABLE-BOUNDARY-START(313532940313),
    {
      "t": 327705,
      "n": "HighlightText",
      "d": 327705,
      "h": 313532940313,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313532940313),
//--TRIMMABLE-BOUNDARY-START(326417842201),
    {
      "t": 327705,
      "n": "HotTrack",
      "d": 327705,
      "h": 326417842201,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326417842201),
//--TRIMMABLE-BOUNDARY-START(330712809497),
    {
      "t": 327705,
      "n": "InactiveBorder",
      "d": 327705,
      "h": 330712809497,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330712809497),
//--TRIMMABLE-BOUNDARY-START(335007776793),
    {
      "t": 327705,
      "n": "InactiveCaption",
      "d": 327705,
      "h": 335007776793,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335007776793),
//--TRIMMABLE-BOUNDARY-START(339302744089),
    {
      "t": 327705,
      "n": "InactiveCaptionText",
      "d": 327705,
      "h": 339302744089,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339302744089),
//--TRIMMABLE-BOUNDARY-START(352187645977),
    {
      "t": 327705,
      "n": "Info",
      "d": 327705,
      "h": 352187645977,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352187645977),
//--TRIMMABLE-BOUNDARY-START(356482613273),
    {
      "t": 327705,
      "n": "InfoText",
      "d": 327705,
      "h": 356482613273,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356482613273),
//--TRIMMABLE-BOUNDARY-START(502511501337),
    {
      "t": 327705,
      "n": "Menu",
      "d": 327705,
      "h": 502511501337,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(502511501337),
//--TRIMMABLE-BOUNDARY-START(515396403225),
    {
      "t": 327705,
      "n": "MenuText",
      "d": 327705,
      "h": 515396403225,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(515396403225),
//--TRIMMABLE-BOUNDARY-START(648540389401),
    {
      "t": 327705,
      "n": "ScrollBar",
      "d": 327705,
      "h": 648540389401,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(648540389401),
//--TRIMMABLE-BOUNDARY-START(738734702617),
    {
      "t": 327705,
      "n": "Window",
      "d": 327705,
      "h": 738734702617,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(738734702617),
//--TRIMMABLE-BOUNDARY-START(743029669913),
    {
      "t": 327705,
      "n": "WindowFrame",
      "d": 327705,
      "h": 743029669913,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(743029669913),
//--TRIMMABLE-BOUNDARY-START(747324637209),
    {
      "t": 327705,
      "n": "WindowText",
      "d": 327705,
      "h": 747324637209,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(747324637209),
//--TRIMMABLE-BOUNDARY-START(712964898841),
    {
      "t": 327705,
      "n": "Transparent",
      "d": 327705,
      "h": 712964898841,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(712964898841),
//--TRIMMABLE-BOUNDARY-START(21475164185),
    {
      "t": 327705,
      "n": "AliceBlue",
      "d": 327705,
      "h": 21475164185,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164185),
//--TRIMMABLE-BOUNDARY-START(25770131481),
    {
      "t": 327705,
      "n": "AntiqueWhite",
      "d": 327705,
      "h": 25770131481,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131481),
//--TRIMMABLE-BOUNDARY-START(34360066073),
    {
      "t": 327705,
      "n": "Aqua",
      "d": 327705,
      "h": 34360066073,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360066073),
//--TRIMMABLE-BOUNDARY-START(38655033369),
    {
      "t": 327705,
      "n": "Aquamarine",
      "d": 327705,
      "h": 38655033369,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033369),
//--TRIMMABLE-BOUNDARY-START(42950000665),
    {
      "t": 327705,
      "n": "Azure",
      "d": 327705,
      "h": 42950000665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000665),
//--TRIMMABLE-BOUNDARY-START(47244967961),
    {
      "t": 327705,
      "n": "Beige",
      "d": 327705,
      "h": 47244967961,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244967961),
//--TRIMMABLE-BOUNDARY-START(51539935257),
    {
      "t": 327705,
      "n": "Bisque",
      "d": 327705,
      "h": 51539935257,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539935257),
//--TRIMMABLE-BOUNDARY-START(55834902553),
    {
      "t": 327705,
      "n": "Black",
      "d": 327705,
      "h": 55834902553,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834902553),
//--TRIMMABLE-BOUNDARY-START(60129869849),
    {
      "t": 327705,
      "n": "BlanchedAlmond",
      "d": 327705,
      "h": 60129869849,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129869849),
//--TRIMMABLE-BOUNDARY-START(64424837145),
    {
      "t": 327705,
      "n": "Blue",
      "d": 327705,
      "h": 64424837145,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424837145),
//--TRIMMABLE-BOUNDARY-START(68719804441),
    {
      "t": 327705,
      "n": "BlueViolet",
      "d": 327705,
      "h": 68719804441,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719804441),
//--TRIMMABLE-BOUNDARY-START(73014771737),
    {
      "t": 327705,
      "n": "Brown",
      "d": 327705,
      "h": 73014771737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014771737),
//--TRIMMABLE-BOUNDARY-START(77309739033),
    {
      "t": 327705,
      "n": "BurlyWood",
      "d": 327705,
      "h": 77309739033,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309739033),
//--TRIMMABLE-BOUNDARY-START(94489608217),
    {
      "t": 327705,
      "n": "CadetBlue",
      "d": 327705,
      "h": 94489608217,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489608217),
//--TRIMMABLE-BOUNDARY-START(98784575513),
    {
      "t": 327705,
      "n": "Chartreuse",
      "d": 327705,
      "h": 98784575513,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784575513),
//--TRIMMABLE-BOUNDARY-START(103079542809),
    {
      "t": 327705,
      "n": "Chocolate",
      "d": 327705,
      "h": 103079542809,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079542809),
//--TRIMMABLE-BOUNDARY-START(133144313881),
    {
      "t": 327705,
      "n": "Coral",
      "d": 327705,
      "h": 133144313881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144313881),
//--TRIMMABLE-BOUNDARY-START(137439281177),
    {
      "t": 327705,
      "n": "CornflowerBlue",
      "d": 327705,
      "h": 137439281177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439281177),
//--TRIMMABLE-BOUNDARY-START(141734248473),
    {
      "t": 327705,
      "n": "Cornsilk",
      "d": 327705,
      "h": 141734248473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734248473),
//--TRIMMABLE-BOUNDARY-START(146029215769),
    {
      "t": 327705,
      "n": "Crimson",
      "d": 327705,
      "h": 146029215769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029215769),
//--TRIMMABLE-BOUNDARY-START(150324183065),
    {
      "t": 327705,
      "n": "Cyan",
      "d": 327705,
      "h": 150324183065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324183065),
//--TRIMMABLE-BOUNDARY-START(154619150361),
    {
      "t": 327705,
      "n": "DarkBlue",
      "d": 327705,
      "h": 154619150361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619150361),
//--TRIMMABLE-BOUNDARY-START(158914117657),
    {
      "t": 327705,
      "n": "DarkCyan",
      "d": 327705,
      "h": 158914117657,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914117657),
//--TRIMMABLE-BOUNDARY-START(163209084953),
    {
      "t": 327705,
      "n": "DarkGoldenrod",
      "d": 327705,
      "h": 163209084953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209084953),
//--TRIMMABLE-BOUNDARY-START(167504052249),
    {
      "t": 327705,
      "n": "DarkGray",
      "d": 327705,
      "h": 167504052249,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504052249),
//--TRIMMABLE-BOUNDARY-START(171799019545),
    {
      "t": 327705,
      "n": "DarkGreen",
      "d": 327705,
      "h": 171799019545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799019545),
//--TRIMMABLE-BOUNDARY-START(176093986841),
    {
      "t": 327705,
      "n": "DarkKhaki",
      "d": 327705,
      "h": 176093986841,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176093986841),
//--TRIMMABLE-BOUNDARY-START(180388954137),
    {
      "t": 327705,
      "n": "DarkMagenta",
      "d": 327705,
      "h": 180388954137,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180388954137),
//--TRIMMABLE-BOUNDARY-START(184683921433),
    {
      "t": 327705,
      "n": "DarkOliveGreen",
      "d": 327705,
      "h": 184683921433,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184683921433),
//--TRIMMABLE-BOUNDARY-START(188978888729),
    {
      "t": 327705,
      "n": "DarkOrange",
      "d": 327705,
      "h": 188978888729,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188978888729),
//--TRIMMABLE-BOUNDARY-START(193273856025),
    {
      "t": 327705,
      "n": "DarkOrchid",
      "d": 327705,
      "h": 193273856025,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193273856025),
//--TRIMMABLE-BOUNDARY-START(197568823321),
    {
      "t": 327705,
      "n": "DarkRed",
      "d": 327705,
      "h": 197568823321,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197568823321),
//--TRIMMABLE-BOUNDARY-START(201863790617),
    {
      "t": 327705,
      "n": "DarkSalmon",
      "d": 327705,
      "h": 201863790617,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201863790617),
//--TRIMMABLE-BOUNDARY-START(206158757913),
    {
      "t": 327705,
      "n": "DarkSeaGreen",
      "d": 327705,
      "h": 206158757913,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206158757913),
//--TRIMMABLE-BOUNDARY-START(210453725209),
    {
      "t": 327705,
      "n": "DarkSlateBlue",
      "d": 327705,
      "h": 210453725209,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210453725209),
//--TRIMMABLE-BOUNDARY-START(214748692505),
    {
      "t": 327705,
      "n": "DarkSlateGray",
      "d": 327705,
      "h": 214748692505,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214748692505),
//--TRIMMABLE-BOUNDARY-START(219043659801),
    {
      "t": 327705,
      "n": "DarkTurquoise",
      "d": 327705,
      "h": 219043659801,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219043659801),
//--TRIMMABLE-BOUNDARY-START(223338627097),
    {
      "t": 327705,
      "n": "DarkViolet",
      "d": 327705,
      "h": 223338627097,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223338627097),
//--TRIMMABLE-BOUNDARY-START(227633594393),
    {
      "t": 327705,
      "n": "DeepPink",
      "d": 327705,
      "h": 227633594393,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227633594393),
//--TRIMMABLE-BOUNDARY-START(231928561689),
    {
      "t": 327705,
      "n": "DeepSkyBlue",
      "d": 327705,
      "h": 231928561689,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231928561689),
//--TRIMMABLE-BOUNDARY-START(240518496281),
    {
      "t": 327705,
      "n": "DimGray",
      "d": 327705,
      "h": 240518496281,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240518496281),
//--TRIMMABLE-BOUNDARY-START(244813463577),
    {
      "t": 327705,
      "n": "DodgerBlue",
      "d": 327705,
      "h": 244813463577,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244813463577),
//--TRIMMABLE-BOUNDARY-START(249108430873),
    {
      "t": 327705,
      "n": "Firebrick",
      "d": 327705,
      "h": 249108430873,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249108430873),
//--TRIMMABLE-BOUNDARY-START(253403398169),
    {
      "t": 327705,
      "n": "FloralWhite",
      "d": 327705,
      "h": 253403398169,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253403398169),
//--TRIMMABLE-BOUNDARY-START(257698365465),
    {
      "t": 327705,
      "n": "ForestGreen",
      "d": 327705,
      "h": 257698365465,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257698365465),
//--TRIMMABLE-BOUNDARY-START(261993332761),
    {
      "t": 327705,
      "n": "Fuchsia",
      "d": 327705,
      "h": 261993332761,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261993332761),
//--TRIMMABLE-BOUNDARY-START(266288300057),
    {
      "t": 327705,
      "n": "Gainsboro",
      "d": 327705,
      "h": 266288300057,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266288300057),
//--TRIMMABLE-BOUNDARY-START(270583267353),
    {
      "t": 327705,
      "n": "GhostWhite",
      "d": 327705,
      "h": 270583267353,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270583267353),
//--TRIMMABLE-BOUNDARY-START(274878234649),
    {
      "t": 327705,
      "n": "Gold",
      "d": 327705,
      "h": 274878234649,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274878234649),
//--TRIMMABLE-BOUNDARY-START(279173201945),
    {
      "t": 327705,
      "n": "Goldenrod",
      "d": 327705,
      "h": 279173201945,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279173201945),
//--TRIMMABLE-BOUNDARY-START(292058103833),
    {
      "t": 327705,
      "n": "Gray",
      "d": 327705,
      "h": 292058103833,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292058103833),
//--TRIMMABLE-BOUNDARY-START(300648038425),
    {
      "t": 327705,
      "n": "Green",
      "d": 327705,
      "h": 300648038425,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300648038425),
//--TRIMMABLE-BOUNDARY-START(304943005721),
    {
      "t": 327705,
      "n": "GreenYellow",
      "d": 327705,
      "h": 304943005721,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304943005721),
//--TRIMMABLE-BOUNDARY-START(317827907609),
    {
      "t": 327705,
      "n": "Honeydew",
      "d": 327705,
      "h": 317827907609,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317827907609),
//--TRIMMABLE-BOUNDARY-START(322122874905),
    {
      "t": 327705,
      "n": "HotPink",
      "d": 327705,
      "h": 322122874905,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322122874905),
//--TRIMMABLE-BOUNDARY-START(343597711385),
    {
      "t": 327705,
      "n": "IndianRed",
      "d": 327705,
      "h": 343597711385,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343597711385),
//--TRIMMABLE-BOUNDARY-START(347892678681),
    {
      "t": 327705,
      "n": "Indigo",
      "d": 327705,
      "h": 347892678681,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347892678681),
//--TRIMMABLE-BOUNDARY-START(360777580569),
    {
      "t": 327705,
      "n": "Ivory",
      "d": 327705,
      "h": 360777580569,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360777580569),
//--TRIMMABLE-BOUNDARY-START(365072547865),
    {
      "t": 327705,
      "n": "Khaki",
      "d": 327705,
      "h": 365072547865,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365072547865),
//--TRIMMABLE-BOUNDARY-START(369367515161),
    {
      "t": 327705,
      "n": "Lavender",
      "d": 327705,
      "h": 369367515161,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369367515161),
//--TRIMMABLE-BOUNDARY-START(373662482457),
    {
      "t": 327705,
      "n": "LavenderBlush",
      "d": 327705,
      "h": 373662482457,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373662482457),
//--TRIMMABLE-BOUNDARY-START(377957449753),
    {
      "t": 327705,
      "n": "LawnGreen",
      "d": 327705,
      "h": 377957449753,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377957449753),
//--TRIMMABLE-BOUNDARY-START(382252417049),
    {
      "t": 327705,
      "n": "LemonChiffon",
      "d": 327705,
      "h": 382252417049,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382252417049),
//--TRIMMABLE-BOUNDARY-START(386547384345),
    {
      "t": 327705,
      "n": "LightBlue",
      "d": 327705,
      "h": 386547384345,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386547384345),
//--TRIMMABLE-BOUNDARY-START(390842351641),
    {
      "t": 327705,
      "n": "LightCoral",
      "d": 327705,
      "h": 390842351641,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390842351641),
//--TRIMMABLE-BOUNDARY-START(395137318937),
    {
      "t": 327705,
      "n": "LightCyan",
      "d": 327705,
      "h": 395137318937,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395137318937),
//--TRIMMABLE-BOUNDARY-START(399432286233),
    {
      "t": 327705,
      "n": "LightGoldenrodYellow",
      "d": 327705,
      "h": 399432286233,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399432286233),
//--TRIMMABLE-BOUNDARY-START(403727253529),
    {
      "t": 327705,
      "n": "LightGray",
      "d": 327705,
      "h": 403727253529,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403727253529),
//--TRIMMABLE-BOUNDARY-START(408022220825),
    {
      "t": 327705,
      "n": "LightGreen",
      "d": 327705,
      "h": 408022220825,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408022220825),
//--TRIMMABLE-BOUNDARY-START(412317188121),
    {
      "t": 327705,
      "n": "LightPink",
      "d": 327705,
      "h": 412317188121,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412317188121),
//--TRIMMABLE-BOUNDARY-START(416612155417),
    {
      "t": 327705,
      "n": "LightSalmon",
      "d": 327705,
      "h": 416612155417,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416612155417),
//--TRIMMABLE-BOUNDARY-START(420907122713),
    {
      "t": 327705,
      "n": "LightSeaGreen",
      "d": 327705,
      "h": 420907122713,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(420907122713),
//--TRIMMABLE-BOUNDARY-START(425202090009),
    {
      "t": 327705,
      "n": "LightSkyBlue",
      "d": 327705,
      "h": 425202090009,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(425202090009),
//--TRIMMABLE-BOUNDARY-START(429497057305),
    {
      "t": 327705,
      "n": "LightSlateGray",
      "d": 327705,
      "h": 429497057305,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(429497057305),
//--TRIMMABLE-BOUNDARY-START(433792024601),
    {
      "t": 327705,
      "n": "LightSteelBlue",
      "d": 327705,
      "h": 433792024601,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(433792024601),
//--TRIMMABLE-BOUNDARY-START(438086991897),
    {
      "t": 327705,
      "n": "LightYellow",
      "d": 327705,
      "h": 438086991897,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(438086991897),
//--TRIMMABLE-BOUNDARY-START(442381959193),
    {
      "t": 327705,
      "n": "Lime",
      "d": 327705,
      "h": 442381959193,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(442381959193),
//--TRIMMABLE-BOUNDARY-START(446676926489),
    {
      "t": 327705,
      "n": "LimeGreen",
      "d": 327705,
      "h": 446676926489,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(446676926489),
//--TRIMMABLE-BOUNDARY-START(450971893785),
    {
      "t": 327705,
      "n": "Linen",
      "d": 327705,
      "h": 450971893785,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(450971893785),
//--TRIMMABLE-BOUNDARY-START(455266861081),
    {
      "t": 327705,
      "n": "Magenta",
      "d": 327705,
      "h": 455266861081,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(455266861081),
//--TRIMMABLE-BOUNDARY-START(459561828377),
    {
      "t": 327705,
      "n": "Maroon",
      "d": 327705,
      "h": 459561828377,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(459561828377),
//--TRIMMABLE-BOUNDARY-START(463856795673),
    {
      "t": 327705,
      "n": "MediumAquamarine",
      "d": 327705,
      "h": 463856795673,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(463856795673),
//--TRIMMABLE-BOUNDARY-START(468151762969),
    {
      "t": 327705,
      "n": "MediumBlue",
      "d": 327705,
      "h": 468151762969,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(468151762969),
//--TRIMMABLE-BOUNDARY-START(472446730265),
    {
      "t": 327705,
      "n": "MediumOrchid",
      "d": 327705,
      "h": 472446730265,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(472446730265),
//--TRIMMABLE-BOUNDARY-START(476741697561),
    {
      "t": 327705,
      "n": "MediumPurple",
      "d": 327705,
      "h": 476741697561,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(476741697561),
//--TRIMMABLE-BOUNDARY-START(481036664857),
    {
      "t": 327705,
      "n": "MediumSeaGreen",
      "d": 327705,
      "h": 481036664857,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(481036664857),
//--TRIMMABLE-BOUNDARY-START(485331632153),
    {
      "t": 327705,
      "n": "MediumSlateBlue",
      "d": 327705,
      "h": 485331632153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(485331632153),
//--TRIMMABLE-BOUNDARY-START(489626599449),
    {
      "t": 327705,
      "n": "MediumSpringGreen",
      "d": 327705,
      "h": 489626599449,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(489626599449),
//--TRIMMABLE-BOUNDARY-START(493921566745),
    {
      "t": 327705,
      "n": "MediumTurquoise",
      "d": 327705,
      "h": 493921566745,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(493921566745),
//--TRIMMABLE-BOUNDARY-START(498216534041),
    {
      "t": 327705,
      "n": "MediumVioletRed",
      "d": 327705,
      "h": 498216534041,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(498216534041),
//--TRIMMABLE-BOUNDARY-START(519691370521),
    {
      "t": 327705,
      "n": "MidnightBlue",
      "d": 327705,
      "h": 519691370521,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(519691370521),
//--TRIMMABLE-BOUNDARY-START(523986337817),
    {
      "t": 327705,
      "n": "MintCream",
      "d": 327705,
      "h": 523986337817,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(523986337817),
//--TRIMMABLE-BOUNDARY-START(528281305113),
    {
      "t": 327705,
      "n": "MistyRose",
      "d": 327705,
      "h": 528281305113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(528281305113),
//--TRIMMABLE-BOUNDARY-START(532576272409),
    {
      "t": 327705,
      "n": "Moccasin",
      "d": 327705,
      "h": 532576272409,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(532576272409),
//--TRIMMABLE-BOUNDARY-START(536871239705),
    {
      "t": 327705,
      "n": "NavajoWhite",
      "d": 327705,
      "h": 536871239705,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(536871239705),
//--TRIMMABLE-BOUNDARY-START(541166207001),
    {
      "t": 327705,
      "n": "Navy",
      "d": 327705,
      "h": 541166207001,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(541166207001),
//--TRIMMABLE-BOUNDARY-START(545461174297),
    {
      "t": 327705,
      "n": "OldLace",
      "d": 327705,
      "h": 545461174297,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(545461174297),
//--TRIMMABLE-BOUNDARY-START(549756141593),
    {
      "t": 327705,
      "n": "Olive",
      "d": 327705,
      "h": 549756141593,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(549756141593),
//--TRIMMABLE-BOUNDARY-START(554051108889),
    {
      "t": 327705,
      "n": "OliveDrab",
      "d": 327705,
      "h": 554051108889,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(554051108889),
//--TRIMMABLE-BOUNDARY-START(558346076185),
    {
      "t": 327705,
      "n": "Orange",
      "d": 327705,
      "h": 558346076185,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(558346076185),
//--TRIMMABLE-BOUNDARY-START(562641043481),
    {
      "t": 327705,
      "n": "OrangeRed",
      "d": 327705,
      "h": 562641043481,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(562641043481),
//--TRIMMABLE-BOUNDARY-START(566936010777),
    {
      "t": 327705,
      "n": "Orchid",
      "d": 327705,
      "h": 566936010777,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(566936010777),
//--TRIMMABLE-BOUNDARY-START(571230978073),
    {
      "t": 327705,
      "n": "PaleGoldenrod",
      "d": 327705,
      "h": 571230978073,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(571230978073),
//--TRIMMABLE-BOUNDARY-START(575525945369),
    {
      "t": 327705,
      "n": "PaleGreen",
      "d": 327705,
      "h": 575525945369,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(575525945369),
//--TRIMMABLE-BOUNDARY-START(579820912665),
    {
      "t": 327705,
      "n": "PaleTurquoise",
      "d": 327705,
      "h": 579820912665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(579820912665),
//--TRIMMABLE-BOUNDARY-START(584115879961),
    {
      "t": 327705,
      "n": "PaleVioletRed",
      "d": 327705,
      "h": 584115879961,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(584115879961),
//--TRIMMABLE-BOUNDARY-START(588410847257),
    {
      "t": 327705,
      "n": "PapayaWhip",
      "d": 327705,
      "h": 588410847257,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(588410847257),
//--TRIMMABLE-BOUNDARY-START(592705814553),
    {
      "t": 327705,
      "n": "PeachPuff",
      "d": 327705,
      "h": 592705814553,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(592705814553),
//--TRIMMABLE-BOUNDARY-START(597000781849),
    {
      "t": 327705,
      "n": "Peru",
      "d": 327705,
      "h": 597000781849,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(597000781849),
//--TRIMMABLE-BOUNDARY-START(601295749145),
    {
      "t": 327705,
      "n": "Pink",
      "d": 327705,
      "h": 601295749145,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(601295749145),
//--TRIMMABLE-BOUNDARY-START(605590716441),
    {
      "t": 327705,
      "n": "Plum",
      "d": 327705,
      "h": 605590716441,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(605590716441),
//--TRIMMABLE-BOUNDARY-START(609885683737),
    {
      "t": 327705,
      "n": "PowderBlue",
      "d": 327705,
      "h": 609885683737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(609885683737),
//--TRIMMABLE-BOUNDARY-START(614180651033),
    {
      "t": 327705,
      "n": "Purple",
      "d": 327705,
      "h": 614180651033,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(614180651033),
//--TRIMMABLE-BOUNDARY-START(622770585625),
    {
      "t": 327705,
      "n": "Red",
      "d": 327705,
      "h": 622770585625,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(622770585625),
//--TRIMMABLE-BOUNDARY-START(627065552921),
    {
      "t": 327705,
      "n": "RosyBrown",
      "d": 327705,
      "h": 627065552921,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(627065552921),
//--TRIMMABLE-BOUNDARY-START(631360520217),
    {
      "t": 327705,
      "n": "RoyalBlue",
      "d": 327705,
      "h": 631360520217,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(631360520217),
//--TRIMMABLE-BOUNDARY-START(635655487513),
    {
      "t": 327705,
      "n": "SaddleBrown",
      "d": 327705,
      "h": 635655487513,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(635655487513),
//--TRIMMABLE-BOUNDARY-START(639950454809),
    {
      "t": 327705,
      "n": "Salmon",
      "d": 327705,
      "h": 639950454809,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(639950454809),
//--TRIMMABLE-BOUNDARY-START(644245422105),
    {
      "t": 327705,
      "n": "SandyBrown",
      "d": 327705,
      "h": 644245422105,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(644245422105),
//--TRIMMABLE-BOUNDARY-START(652835356697),
    {
      "t": 327705,
      "n": "SeaGreen",
      "d": 327705,
      "h": 652835356697,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(652835356697),
//--TRIMMABLE-BOUNDARY-START(657130323993),
    {
      "t": 327705,
      "n": "SeaShell",
      "d": 327705,
      "h": 657130323993,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(657130323993),
//--TRIMMABLE-BOUNDARY-START(661425291289),
    {
      "t": 327705,
      "n": "Sienna",
      "d": 327705,
      "h": 661425291289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(661425291289),
//--TRIMMABLE-BOUNDARY-START(665720258585),
    {
      "t": 327705,
      "n": "Silver",
      "d": 327705,
      "h": 665720258585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(665720258585),
//--TRIMMABLE-BOUNDARY-START(670015225881),
    {
      "t": 327705,
      "n": "SkyBlue",
      "d": 327705,
      "h": 670015225881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(670015225881),
//--TRIMMABLE-BOUNDARY-START(674310193177),
    {
      "t": 327705,
      "n": "SlateBlue",
      "d": 327705,
      "h": 674310193177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(674310193177),
//--TRIMMABLE-BOUNDARY-START(678605160473),
    {
      "t": 327705,
      "n": "SlateGray",
      "d": 327705,
      "h": 678605160473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(678605160473),
//--TRIMMABLE-BOUNDARY-START(682900127769),
    {
      "t": 327705,
      "n": "Snow",
      "d": 327705,
      "h": 682900127769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(682900127769),
//--TRIMMABLE-BOUNDARY-START(687195095065),
    {
      "t": 327705,
      "n": "SpringGreen",
      "d": 327705,
      "h": 687195095065,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(687195095065),
//--TRIMMABLE-BOUNDARY-START(691490062361),
    {
      "t": 327705,
      "n": "SteelBlue",
      "d": 327705,
      "h": 691490062361,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(691490062361),
//--TRIMMABLE-BOUNDARY-START(695785029657),
    {
      "t": 327705,
      "n": "Tan",
      "d": 327705,
      "h": 695785029657,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(695785029657),
//--TRIMMABLE-BOUNDARY-START(700079996953),
    {
      "t": 327705,
      "n": "Teal",
      "d": 327705,
      "h": 700079996953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(700079996953),
//--TRIMMABLE-BOUNDARY-START(704374964249),
    {
      "t": 327705,
      "n": "Thistle",
      "d": 327705,
      "h": 704374964249,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(704374964249),
//--TRIMMABLE-BOUNDARY-START(708669931545),
    {
      "t": 327705,
      "n": "Tomato",
      "d": 327705,
      "h": 708669931545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(708669931545),
//--TRIMMABLE-BOUNDARY-START(717259866137),
    {
      "t": 327705,
      "n": "Turquoise",
      "d": 327705,
      "h": 717259866137,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(717259866137),
//--TRIMMABLE-BOUNDARY-START(721554833433),
    {
      "t": 327705,
      "n": "Violet",
      "d": 327705,
      "h": 721554833433,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(721554833433),
//--TRIMMABLE-BOUNDARY-START(725849800729),
    {
      "t": 327705,
      "n": "Wheat",
      "d": 327705,
      "h": 725849800729,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(725849800729),
//--TRIMMABLE-BOUNDARY-START(730144768025),
    {
      "t": 327705,
      "n": "White",
      "d": 327705,
      "h": 730144768025,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(730144768025),
//--TRIMMABLE-BOUNDARY-START(734439735321),
    {
      "t": 327705,
      "n": "WhiteSmoke",
      "d": 327705,
      "h": 734439735321,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(734439735321),
//--TRIMMABLE-BOUNDARY-START(751619604505),
    {
      "t": 327705,
      "n": "Yellow",
      "d": 327705,
      "h": 751619604505,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(751619604505),
//--TRIMMABLE-BOUNDARY-START(755914571801),
    {
      "t": 327705,
      "n": "YellowGreen",
      "d": 327705,
      "h": 755914571801,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(755914571801),
//--TRIMMABLE-BOUNDARY-START(81604706329),
    {
      "t": 327705,
      "n": "ButtonFace",
      "d": 327705,
      "h": 81604706329,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604706329),
//--TRIMMABLE-BOUNDARY-START(85899673625),
    {
      "t": 327705,
      "n": "ButtonHighlight",
      "d": 327705,
      "h": 85899673625,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899673625),
//--TRIMMABLE-BOUNDARY-START(90194640921),
    {
      "t": 327705,
      "n": "ButtonShadow",
      "d": 327705,
      "h": 90194640921,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194640921),
//--TRIMMABLE-BOUNDARY-START(283468169241),
    {
      "t": 327705,
      "n": "GradientActiveCaption",
      "d": 327705,
      "h": 283468169241,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283468169241),
//--TRIMMABLE-BOUNDARY-START(287763136537),
    {
      "t": 327705,
      "n": "GradientInactiveCaption",
      "d": 327705,
      "h": 287763136537,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287763136537),
//--TRIMMABLE-BOUNDARY-START(506806468633),
    {
      "t": 327705,
      "n": "MenuBar",
      "d": 327705,
      "h": 506806468633,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(506806468633),
//--TRIMMABLE-BOUNDARY-START(511101435929),
    {
      "t": 327705,
      "n": "MenuHighlight",
      "d": 327705,
      "h": 511101435929,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(511101435929),
//--TRIMMABLE-BOUNDARY-START(618475618329),
    {
      "t": 327705,
      "n": "RebeccaPurple",
      "d": 327705,
      "h": 618475618329,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(618475618329)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295001),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327705,
      "h": 4295295001,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295001)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 327705,
  "a": [
    {
      "t": 133758977,
      "c": 8723693569,
      "a": [
        {
          "v": "System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327705)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.InteropServices"))
//--TRIMMABLE-BOUNDARY-END(25)
