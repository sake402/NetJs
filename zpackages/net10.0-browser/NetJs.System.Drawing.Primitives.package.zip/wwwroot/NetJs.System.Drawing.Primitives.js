
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $scm, $so, $scp, $snv, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {"h":37933,"f":"System.Drawing.Primitives","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            /*string[]*/ static s_colorNameTable = null;
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$$.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorNameTable = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                }
            }
            static $h = 431149;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"color","p":365613}],"n":"KnownColorToName","d":431149,"h":8590365741,"f":16777249}],"l":[{"t":$.$typeArray($.$$.System.String).$h,"n":"s_colorNameTable","d":431149,"h":4295398445,"f":4194338}],"h":431149}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdp.System.SR.resourceCulture = value;
            }
            static /*string */ get ConvertInvalidPrimitive()
            {
                return "{0} is not a valid value for {1}.";
            }
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("{0} is not a valid value for {1}.", arg1, arg2);
            }
            static /*string */ get InvalidColor()
            {
                return "Color '{0}' is not valid.";
            }
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Color '{0}' is not valid.", arg1);
            }
            static /*string */ get InvalidEx2BoundArgument()
            {
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                return $.$$.System.String.Format$11("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1086509;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1086509}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(culture !== null, "culture != null");
                /*string*/ let text = $.$$.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$$.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$$.System.String.Contains$1.call(text, sep))
                {
                    if (text.length >= 2 && ($.$$.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$$.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$$.System.String.get_Chars.call(text, 0) === $.$$.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$$.System.String.Substring.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$$.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$$.System.String.StartsWith$3.call(text, "0x") || $.$$.System.String.StartsWith$3.call(text, "0X"))) || (text.length === 8 && ($.$$.System.String.StartsWith$3.call(text, "&h") || $.$$.System.String.StartsWith$3.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$3(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$$.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$$.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$$.System.MemoryExtensions.Split(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$3($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sdp.System.SR.Format$6($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                text = $.$$.System.MemoryExtensions.Trim$4(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$$.System.Convert.ToInt32$14($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text.Slice$1(1)), 16);
                    }
                    else if ($.$$.System.MemoryExtensions.StartsWith(text, $.$$.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$$.System.MemoryExtensions.StartsWith(text, $.$$.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$$.System.Convert.ToInt32$14($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text.Slice$1(2)), 16);
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$$.System.Globalization.NumberFormatInfo.$type), $.$$.System.Globalization.NumberFormatInfo);
                        return $.$$.System.Int32.Parse$3(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$$.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$5($.$sdp.System.SR.ConvertInvalidPrimitive, $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            static $h = 169005;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":103469,"p":[{"n":"strValue","p":1310721},{"n":"culture","p":51183617}],"n":"ConvertFromString","d":169005,"h":4295136301,"f":16777249},{"r":103469,"p":[{"n":"color","p":103469}],"n":"PossibleKnownColor","d":169005,"h":8590103597,"f":16777250},{"r":655361,"p":[{"n":"text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"culture","p":51183617}],"n":"IntFromString","d":169005,"h":12885070893,"f":16777250}],"h":169005}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            /*bool*/ static s_useAlternativeColorSet = false;
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            static /*bool */ get UseAlternativeColorSet()
            {
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            static $h = 955437;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":103469,"g":{"r":0,"d":0,"h":12885857325,"f":50331681},"n":"ActiveBorder","d":955437,"h":8590890029,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":21475791917,"f":50331681},"n":"ActiveCaption","d":955437,"h":17180824621,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":30065726509,"f":50331681},"n":"ActiveCaptionText","d":955437,"h":25770759213,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":38655661101,"f":50331681},"n":"AppWorkspace","d":955437,"h":34360693805,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":47245595693,"f":50331681},"n":"ButtonFace","d":955437,"h":42950628397,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":55835530285,"f":50331681},"n":"ButtonHighlight","d":955437,"h":51540562989,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":64425464877,"f":50331681},"n":"ButtonShadow","d":955437,"h":60130497581,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":73015399469,"f":50331681},"n":"Control","d":955437,"h":68720432173,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":81605334061,"f":50331681},"n":"ControlDark","d":955437,"h":77310366765,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":90195268653,"f":50331681},"n":"ControlDarkDark","d":955437,"h":85900301357,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":98785203245,"f":50331681},"n":"ControlLight","d":955437,"h":94490235949,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":107375137837,"f":50331681},"n":"ControlLightLight","d":955437,"h":103080170541,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":115965072429,"f":50331681},"n":"ControlText","d":955437,"h":111670105133,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":124555007021,"f":50331681},"n":"Desktop","d":955437,"h":120260039725,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":133144941613,"f":50331681},"n":"GradientActiveCaption","d":955437,"h":128849974317,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":141734876205,"f":50331681},"n":"GradientInactiveCaption","d":955437,"h":137439908909,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":150324810797,"f":50331681},"n":"GrayText","d":955437,"h":146029843501,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":158914745389,"f":50331681},"n":"Highlight","d":955437,"h":154619778093,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":167504679981,"f":50331681},"n":"HighlightText","d":955437,"h":163209712685,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":176094614573,"f":50331681},"n":"HotTrack","d":955437,"h":171799647277,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":184684549165,"f":50331681},"n":"InactiveBorder","d":955437,"h":180389581869,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":193274483757,"f":50331681},"n":"InactiveCaption","d":955437,"h":188979516461,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":201864418349,"f":50331681},"n":"InactiveCaptionText","d":955437,"h":197569451053,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":210454352941,"f":50331681},"n":"Info","d":955437,"h":206159385645,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":219044287533,"f":50331681},"n":"InfoText","d":955437,"h":214749320237,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":227634222125,"f":50331681},"n":"Menu","d":955437,"h":223339254829,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":236224156717,"f":50331681},"n":"MenuBar","d":955437,"h":231929189421,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":244814091309,"f":50331681},"n":"MenuHighlight","d":955437,"h":240519124013,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":253404025901,"f":50331681},"n":"MenuText","d":955437,"h":249109058605,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":261993960493,"f":50331681},"n":"ScrollBar","d":955437,"h":257698993197,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":270583895085,"f":50331681},"n":"Window","d":955437,"h":266288927789,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":279173829677,"f":50331681},"n":"WindowFrame","d":955437,"h":274878862381,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":287763764269,"f":50331681},"n":"WindowText","d":955437,"h":283468796973,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":296353698861,"f":50331681},"s":{"r":0,"d":0,"h":300648666157,"f":83886113},"n":"UseAlternativeColorSet","d":955437,"h":292058731565,"f":2097185}],"l":[{"t":262145,"n":"s_useAlternativeColorSet","d":955437,"h":4295922733,"f":4194344}],"h":955437}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            /*byte*/ static KnownColorKindSystem = 0;
            /*byte*/ static KnownColorKindWeb = 1;
            /*byte*/ static KnownColorKindUnknown = 2;
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.UInt32))().$ctor$4([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.UInt32))().$ctor$4([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$$.System.Diagnostics.Debug.Assert$2($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$3((argb | 0));
            }
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            static $h = 496685;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt32).$h,"g":{"r":0,"d":0,"h":21475333165,"f":50331681},"n":"ColorValueTable","d":496685,"h":17180365869,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30065267757,"f":50331681},"n":"ColorKindTable","d":496685,"h":25770300461,"f":2097185},{"p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt32).$h,"g":{"r":0,"d":0,"h":38655202349,"f":50331682},"n":"AlternateSystemColors","d":496685,"h":34360235053,"f":2097186}],"m":[{"r":103469,"p":[{"n":"argb","p":720897}],"n":"ArgbToKnownColor","d":496685,"h":42950169645,"f":16777256},{"r":720897,"p":[{"n":"color","p":365613}],"n":"KnownColorToArgb","d":496685,"h":47245136941,"f":16777249},{"r":720897,"p":[{"n":"color","p":365613}],"n":"GetAlternateSystemColorArgb","d":496685,"h":51540104237,"f":16777250},{"r":720897,"p":[{"n":"color","p":365613}],"n":"GetSystemColorArgb","d":496685,"h":55835071533,"f":16777249}],"l":[{"t":393217,"n":"KnownColorKindSystem","d":496685,"h":4295463981,"f":4194337},{"t":393217,"n":"KnownColorKindWeb","d":496685,"h":8590431277,"f":4194337},{"t":393217,"n":"KnownColorKindUnknown","d":496685,"h":12885398573,"f":4194337}],"h":496685}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 1020973;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1020973,"h":4295988269,"f":4194344},{"t":1310721,"n":"TensorTDiagId","d":1020973,"h":8590955565,"f":4194344},{"t":1310721,"n":"SystemColorsDiagId","d":1020973,"h":12885922861,"f":4194344},{"t":1310721,"n":"ArmSveDiagId","d":1020973,"h":17180890157,"f":4194344},{"t":1310721,"n":"X86BaseDivRemDiagId","d":1020973,"h":21475857453,"f":4194344},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":1020973,"h":25770824749,"f":4194344}],"h":1020973}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            /*int*/ static COLORREF_RedShift = 0;
            /*int*/ static COLORREF_GreenShift = 8;
            /*int*/ static COLORREF_BlueShift = 16;
            /*int*/ static OleSystemColorFlag = -2147483648;
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
            }
            static /*int */ ToWin32(/*Color*/ c)
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            static /*int */ ToOle(/*Color*/ c)
            {
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$$.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$$.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$1($.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 1, 2), 16), $.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 3, 2), 16), $.$$.System.Convert.ToInt32$14($.$$.System.String.Substring.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$$.System.Char.ToString$1($.$$.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$1($.$$.System.Convert.ToInt32$14(r + r, 16), $.$$.System.Convert.ToInt32$14(g + g, 16), $.$$.System.Convert.ToInt32$14(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$$.System.String.Equals$2(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$$.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$$.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            static /*string */ ToHtml(/*Color*/ c)
            {
                /*string*/ let colorString = $.$$.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted($.$box(r, $.$$.System.Int32), null, "X2");
                        $handler.AppendFormatted($.$box(g, $.$$.System.Int32), null, "X2");
                        $handler.AppendFormatted($.$box(b, $.$$.System.Int32), null, "X2");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                return colorString;
            }
            static /*void */ InitializeHtmlSysColorTable()
            {
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$8(27);
                    $i1.set_Item("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.set_Item("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.set_Item("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.set_Item("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.set_Item("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.set_Item("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.set_Item("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.set_Item("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.set_Item("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.set_Item("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.set_Item("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.set_Item("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.set_Item("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.set_Item("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.set_Item("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.set_Item("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.set_Item("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.set_Item("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.set_Item("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.set_Item("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.set_Item("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.set_Item("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.set_Item("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.set_Item("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.set_Item("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            static $h = 300077;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"value","p":720897}],"n":"COLORREFToARGB","d":300077,"h":25770103853,"f":16777256},{"r":655361,"p":[{"n":"c","p":103469}],"n":"ToWin32","d":300077,"h":30065071149,"f":16777249},{"r":655361,"p":[{"n":"c","p":103469}],"n":"ToOle","d":300077,"h":34360038445,"f":16777249},{"r":103469,"p":[{"n":"oleColor","p":655361}],"n":"FromOle","d":300077,"h":38655005741,"f":16777249},{"r":103469,"p":[{"n":"win32Color","p":655361}],"n":"FromWin32","d":300077,"h":42949973037,"f":16777249},{"r":103469,"p":[{"n":"htmlColor","p":1310721}],"n":"FromHtml","d":300077,"h":47244940333,"f":16777249},{"r":1310721,"p":[{"n":"c","p":103469}],"n":"ToHtml","d":300077,"h":51539907629,"f":16777249},{"r":65537,"n":"InitializeHtmlSysColorTable","d":300077,"h":55834874925,"f":16777250}],"l":[{"t":655361,"n":"COLORREF_RedShift","d":300077,"h":4295267373,"f":4194344},{"t":655361,"n":"COLORREF_GreenShift","d":300077,"h":8590234669,"f":4194344},{"t":655361,"n":"COLORREF_BlueShift","d":300077,"h":12885201965,"f":4194344},{"t":655361,"n":"OleSystemColorFlag","d":300077,"h":17180169261,"f":4194338},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,"n":"s_htmlSysColorTable","d":300077,"h":21475136557,"f":4194338}],"h":300077}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            static /*Dictionary<string, Color> */ GetColors()
            {
                /*var*/ let colors = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color))().$ctor$6($.$$.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$$.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
            }
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorConstants = new ($.$$.System.Lazy$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)))().$ctor$6(new ($.$$.System.Func$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)))().$ctor($.$sdp.System.Drawing.ColorTable, $.$sdp.System.Drawing.ColorTable.GetColors));
                }
            }
            static $h = 234541;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,"g":{"r":0,"d":0,"h":21475071021,"f":50331688},"n":"Colors","d":234541,"h":17180103725,"f":2097192}],"m":[{"r":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h,"n":"GetColors","d":234541,"h":8590169133,"f":16777250},{"r":65537,"p":[{"n":"dictionary","p":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color).$h},{"n":"typeWithColors","p":142475265}],"n":"FillWithProperties","d":234541,"h":12885136429,"f":16777250},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"result","p":103469,"f":2}],"n":"TryGetNamedColor","d":234541,"h":25770038317,"f":16777256},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"IsKnownNamedColor","d":234541,"h":30065005613,"f":16777256}],"l":[{"t":$.$$.System.Lazy$$($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$sdp.System.Drawing.Color)).$h,"n":"s_colorConstants","d":234541,"h":4295201837,"f":4194338}],"h":234541}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$$.System.ValueType
        {
            /*Point*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$$.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$$.System.Int32, value); }
            $ctor$3(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$5(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(p.X, p.Y);
            }
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
            }
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
            }
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
            }
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
            }
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
            }
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast(Math.ceil(value.X), $.$$.System.Int32), $.$cast(Math.ceil(value.Y), $.$$.System.Int32));
            }
            static /*Point */ Truncate(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast(value.X, $.$$.System.Int32), $.$cast(value.Y, $.$$.System.Int32));
            }
            static /*Point */ Round(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3($.$cast($.$$.System.Math.Round$7(value.X), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Y), $.$$.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Point.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*Point*/ other)
            {
                return $.$sdp.System.Drawing.Point.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, this.X, this.Y);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            /*void */ Offset$1(/*Point*/ p)
            {
                return this.Offset(p.X, p.Y);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            static /*short */ HighInt16(/*int*/ n)
            {
                return $.$cast(((n >> 16) & 65535), $.$$.System.Int16);
            }
            static /*short */ LowInt16(/*int*/ n)
            {
                return $.$cast((n & 65535), $.$$.System.Int16);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                }
            }
            static $h = 562221;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360300589,"f":50331649},"n":"IsEmpty","d":562221,"h":30065333293,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":42950235181,"f":50331649},"s":{"r":0,"d":0,"h":47245202477,"f":83886081},"n":"X","d":562221,"h":38655267885,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":55835137069,"f":50331649},"s":{"r":0,"d":0,"h":60130104365,"f":83886081},"n":"Y","d":562221,"h":51540169773,"f":2097153}],"m":[{"r":562221,"p":[{"n":"pt","p":562221},{"n":"sz","p":824365}],"n":"Add","d":562221,"h":90194875437,"f":16777249},{"r":562221,"p":[{"n":"pt","p":562221},{"n":"sz","p":824365}],"n":"Subtract","d":562221,"h":94489842733,"f":16777249},{"r":562221,"p":[{"n":"value","p":627757}],"n":"Ceiling","d":562221,"h":98784810029,"f":16777249},{"r":562221,"p":[{"n":"value","p":627757}],"n":"Truncate","d":562221,"h":103079777325,"f":16777249},{"r":562221,"p":[{"n":"value","p":627757}],"n":"Round","d":562221,"h":107374744621,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":562221,"h":111669711917,"f":16809985},{"r":262145,"p":[{"n":"other","p":562221}],"n":"Equals","o":"@$2","d":562221,"h":115964679213,"f":16777217},{"r":655361,"n":"GetHashCode","d":562221,"h":120259646509,"f":16809985},{"r":65537,"p":[{"n":"dx","p":655361},{"n":"dy","p":655361}],"n":"Offset","d":562221,"h":124554613805,"f":16777217},{"r":65537,"p":[{"n":"p","p":562221}],"n":"Offset","o":"@$1","d":562221,"h":128849581101,"f":16777217},{"r":1310721,"n":"ToString","d":562221,"h":133144548397,"f":16809985},{"r":524289,"p":[{"n":"n","p":655361}],"n":"HighInt16","d":562221,"h":137439515693,"f":16777250},{"r":524289,"p":[{"n":"n","p":655361}],"n":"LowInt16","d":562221,"h":141734482989,"f":16777250}],"l":[{"t":562221,"n":"Empty","d":562221,"h":4295529517,"f":4194337},{"t":655361,"n":"x","d":562221,"h":8590496813,"f":4194306},{"t":655361,"n":"y","d":562221,"h":12885464109,"f":4194306}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":".ctor","o":"$ctor$3","d":562221,"h":17180431405,"f":16777217},{"p":[{"n":"sz","p":824365}],"n":".ctor","o":"$ctor$5","d":562221,"h":21475398701,"f":16777217},{"p":[{"n":"dw","p":655361}],"n":".ctor","o":"$ctor$4","d":562221,"h":25770365997,"f":16777217},{"n":".ctor","o":"$ctor$2","d":562221,"h":146029450285,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.Point).$h],"h":562221,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$$.System.ValueType
        {
            /*RectangleF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$$.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$$.System.Single, value); }
            /*float*/  get width() { return this.$getField(8, $.$$.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$$.System.Single, value); }
            /*float*/  get height() { return this.$getField(12, $.$$.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$$.System.Single, value); }
            $ctor$4(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$5(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            $ctor$3(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            /*Vector4 */ ToVector4()
            {
                return new $.$$.System.Numerics.Vector4().$ctor$6(this.x, this.y, this.width, this.height);
            }
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                return rectangle.ToVector4();
            }
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$3(vector.Clone());
            }
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(left, top, right - left, bottom - top);
            }
            /*PointF */ get Location()
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*SizeF */ get Size()
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            /*float */ get Left()
            {
                return this.X;
            }
            /*float */ get Top()
            {
                return this.Y;
            }
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.RectangleF.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
            }
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
            }
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$4($.$$.System.Single, $.$$.System.Single, $.$$.System.Single, $.$$.System.Single, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            /*void */ Inflate$2(/*SizeF*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*RectangleF */ Inflate$1(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect$1(/*RectangleF*/ rect)
            {
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*RectangleF */ Intersect(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$$.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$$.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$$.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$$.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$4(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
            }
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$$.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$$.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$$.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$$.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(x1, y1, x2 - x1, y2 - y1);
            }
            /*void */ Offset$1(/*PointF*/ pos)
            {
                return this.Offset(pos.X, pos.Y);
            }
            /*void */ Offset(/*float*/ x, /*float*/ y)
            {
                this.X += x;
                this.Y += y;
            }
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(r.X, r.Y, r.Width, r.Height);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                }
            }
            static $h = 758829;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":627757,"g":{"r":0,"d":0,"h":60130300973,"f":50331649},"s":{"r":0,"d":0,"h":64425268269,"f":83886081},"n":"Location","d":758829,"h":55835333677,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":889901,"g":{"r":0,"d":0,"h":73015202861,"f":50331649},"s":{"r":0,"d":0,"h":77310170157,"f":83886081},"n":"Size","d":758829,"h":68720235565,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":85900104749,"f":50331649},"s":{"r":0,"d":0,"h":90195072045,"f":83886081},"n":"X","d":758829,"h":81605137453,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":98785006637,"f":50331649},"s":{"r":0,"d":0,"h":103079973933,"f":83886081},"n":"Y","d":758829,"h":94490039341,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":111669908525,"f":50331649},"s":{"r":0,"d":0,"h":115964875821,"f":83886081},"n":"Width","d":758829,"h":107374941229,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":124554810413,"f":50331649},"s":{"r":0,"d":0,"h":128849777709,"f":83886081},"n":"Height","d":758829,"h":120259843117,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":137439712301,"f":50331649},"n":"Left","d":758829,"h":133144745005,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":146029646893,"f":50331649},"n":"Top","d":758829,"h":141734679597,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":154619581485,"f":50331649},"n":"Right","d":758829,"h":150324614189,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":163209516077,"f":50331649},"n":"Bottom","d":758829,"h":158914548781,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":171799450669,"f":50331649},"n":"IsEmpty","d":758829,"h":167504483373,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":70713345,"n":"ToVector4","d":758829,"h":38655464493,"f":16777217},{"r":758829,"p":[{"n":"left","p":1114113},{"n":"top","p":1114113},{"n":"right","p":1114113},{"n":"bottom","p":1114113}],"n":"FromLTRB","d":758829,"h":51540366381,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":758829,"h":176094417965,"f":16809985},{"r":262145,"p":[{"n":"other","p":758829}],"n":"Equals","o":"@$2","d":758829,"h":180389385261,"f":16777217},{"r":262145,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Contains","d":758829,"h":193274287149,"f":16777217},{"r":262145,"p":[{"n":"pt","p":627757}],"n":"Contains","o":"@$1","d":758829,"h":197569254445,"f":16777217},{"r":262145,"p":[{"n":"rect","p":758829}],"n":"Contains","o":"@$2","d":758829,"h":201864221741,"f":16777217},{"r":655361,"n":"GetHashCode","d":758829,"h":206159189037,"f":16809985},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","d":758829,"h":210454156333,"f":16777217},{"r":65537,"p":[{"n":"size","p":889901}],"n":"Inflate","o":"@$2","d":758829,"h":214749123629,"f":16777217},{"r":758829,"p":[{"n":"rect","p":758829},{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","o":"@$1","d":758829,"h":219044090925,"f":16777249},{"r":65537,"p":[{"n":"rect","p":758829}],"n":"Intersect","o":"@$1","d":758829,"h":223339058221,"f":16777217},{"r":758829,"p":[{"n":"a","p":758829},{"n":"b","p":758829}],"n":"Intersect","d":758829,"h":227634025517,"f":16777249},{"r":262145,"p":[{"n":"rect","p":758829}],"n":"IntersectsWith","d":758829,"h":231928992813,"f":16777217},{"r":758829,"p":[{"n":"a","p":758829},{"n":"b","p":758829}],"n":"Union","d":758829,"h":236223960109,"f":16777249},{"r":65537,"p":[{"n":"pos","p":627757}],"n":"Offset","o":"@$1","d":758829,"h":240518927405,"f":16777217},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Offset","d":758829,"h":244813894701,"f":16777217},{"r":1310721,"n":"ToString","d":758829,"h":253403829293,"f":16809985}],"l":[{"t":758829,"n":"Empty","d":758829,"h":4295726125,"f":4194337},{"t":1114113,"n":"x","d":758829,"h":8590693421,"f":4194306},{"t":1114113,"n":"y","d":758829,"h":12885660717,"f":4194306},{"t":1114113,"n":"width","d":758829,"h":17180628013,"f":4194306},{"t":1114113,"n":"height","d":758829,"h":21475595309,"f":4194306}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113},{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$4","d":758829,"h":25770562605,"f":16777217},{"p":[{"n":"location","p":627757},{"n":"size","p":889901}],"n":".ctor","o":"$ctor$5","d":758829,"h":30065529901,"f":16777217},{"p":[{"n":"vector","p":70713345}],"n":".ctor","o":"$ctor$3","d":758829,"h":34360497197,"f":16777217},{"n":".ctor","o":"$ctor$2","d":758829,"h":257698796589,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h],"h":758829,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$$.System.ValueType
        {
            /*Size*/ static Empty;
            /*int*/  get width() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$$.System.Int32, value); }
            /*int*/  get height() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$$.System.Int32, value); }
            $ctor$4(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(p.Width, p.Height);
            }
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
            }
            static /*Size */ op_Multiply$2(/*Size*/ left, /*int*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
            }
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
            }
            static /*SizeF */ op_Multiply$1(/*float*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
            }
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
            }
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
            }
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$$.System.Int32), $.$cast(Math.ceil(value.Height), $.$$.System.Int32));
            }
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
            }
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$$.System.Int32), $.$cast(value.Height, $.$$.System.Int32));
            }
            static /*Size */ Round(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$$.System.Math.Round$7(value.Width), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Height), $.$$.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Size.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*Size*/ other)
            {
                return $.$sdp.System.Drawing.Size.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
            }
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                }
            }
            static $h = 824365;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81605202989,"f":50331649},"n":"IsEmpty","d":824365,"h":77310235693,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":90195137581,"f":50331649},"s":{"r":0,"d":0,"h":94490104877,"f":83886081},"n":"Width","d":824365,"h":85900170285,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103080039469,"f":50331649},"s":{"r":0,"d":0,"h":107375006765,"f":83886081},"n":"Height","d":824365,"h":98785072173,"f":2097153}],"m":[{"r":824365,"p":[{"n":"sz1","p":824365},{"n":"sz2","p":824365}],"n":"Add","d":824365,"h":111669974061,"f":16777249},{"r":824365,"p":[{"n":"value","p":889901}],"n":"Ceiling","d":824365,"h":115964941357,"f":16777249},{"r":824365,"p":[{"n":"sz1","p":824365},{"n":"sz2","p":824365}],"n":"Subtract","d":824365,"h":120259908653,"f":16777249},{"r":824365,"p":[{"n":"value","p":889901}],"n":"Truncate","d":824365,"h":124554875949,"f":16777249},{"r":824365,"p":[{"n":"value","p":889901}],"n":"Round","d":824365,"h":128849843245,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":824365,"h":133144810541,"f":16809985},{"r":262145,"p":[{"n":"other","p":824365}],"n":"Equals","o":"@$2","d":824365,"h":137439777837,"f":16777217},{"r":655361,"n":"GetHashCode","d":824365,"h":141734745133,"f":16809985},{"r":1310721,"n":"ToString","d":824365,"h":146029712429,"f":16809985},{"r":824365,"p":[{"n":"size","p":824365},{"n":"multiplier","p":655361}],"n":"Multiply","d":824365,"h":150324679725,"f":16777250},{"r":889901,"p":[{"n":"size","p":824365},{"n":"multiplier","p":1114113}],"n":"Multiply","o":"@$1","d":824365,"h":154619647021,"f":16777250}],"l":[{"t":824365,"n":"Empty","d":824365,"h":4295791661,"f":4194337},{"t":655361,"n":"width","d":824365,"h":8590758957,"f":4194306},{"t":655361,"n":"height","d":824365,"h":12885726253,"f":4194306}],"c":[{"p":[{"n":"pt","p":562221}],"n":".ctor","o":"$ctor$4","d":824365,"h":17180693549,"f":16777217},{"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":824365,"h":21475660845,"f":16777217},{"n":".ctor","o":"$ctor$2","d":824365,"h":158914614317,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.Size).$h],"h":824365,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$$.System.ValueType
        {
            /*PointF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$$.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$$.System.Single, value); }
            $ctor$4(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$$.System.Numerics.Vector2().$ctor$4(this.x, this.y);
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                return point.ToVector2();
            }
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
            }
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
            }
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.PointF.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*PointF*/ other)
            {
                return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Single.GetHashCode.call(this.X), $.$$.System.Single.GetHashCode.call(this.Y));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.x}, Y=${this.y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                }
            }
            static $h = 627757;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360366125,"f":50331649},"n":"IsEmpty","d":627757,"h":30065398829,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":42950300717,"f":50331649},"s":{"r":0,"d":0,"h":47245268013,"f":83886081},"n":"X","d":627757,"h":38655333421,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":55835202605,"f":50331649},"s":{"r":0,"d":0,"h":60130169901,"f":83886081},"n":"Y","d":627757,"h":51540235309,"f":2097153}],"m":[{"r":70582273,"n":"ToVector2","d":627757,"h":25770431533,"f":16777217},{"r":627757,"p":[{"n":"pt","p":627757},{"n":"sz","p":824365}],"n":"Add","d":627757,"h":98784875565,"f":16777249},{"r":627757,"p":[{"n":"pt","p":627757},{"n":"sz","p":824365}],"n":"Subtract","d":627757,"h":103079842861,"f":16777249},{"r":627757,"p":[{"n":"pt","p":627757},{"n":"sz","p":889901}],"n":"Add","o":"@$1","d":627757,"h":107374810157,"f":16777249},{"r":627757,"p":[{"n":"pt","p":627757},{"n":"sz","p":889901}],"n":"Subtract","o":"@$1","d":627757,"h":111669777453,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":627757,"h":115964744749,"f":16809985},{"r":262145,"p":[{"n":"other","p":627757}],"n":"Equals","o":"@$2","d":627757,"h":120259712045,"f":16777217},{"r":655361,"n":"GetHashCode","d":627757,"h":124554679341,"f":16809985},{"r":1310721,"n":"ToString","d":627757,"h":128849646637,"f":16809985}],"l":[{"t":627757,"n":"Empty","d":627757,"h":4295595053,"f":4194337},{"t":1114113,"n":"x","d":627757,"h":8590562349,"f":4194306},{"t":1114113,"n":"y","d":627757,"h":12885529645,"f":4194306}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":".ctor","o":"$ctor$4","d":627757,"h":17180496941,"f":16777217},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":627757,"h":21475464237,"f":16777217},{"n":".ctor","o":"$ctor$2","d":627757,"h":133144613933,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h],"h":627757,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$$.System.ValueType
        {
            /*Rectangle*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$$.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$$.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$$.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$$.System.Int32, value); }
            /*int*/  get width() { return this.$getField(8, $.$$.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$$.System.Int32, value); }
            /*int*/  get height() { return this.$getField(12, $.$$.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$$.System.Int32, value); }
            $ctor$3(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$4(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                return new $.$sdp.System.Drawing.Rectangle().$ctor$3(left, top, ((right - left) | 0), ((bottom - top) | 0));
            }
            /*Point */ get Location()
            {
                return new $.$sdp.System.Drawing.Point().$ctor$3(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*Size */ get Size()
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            /*int */ get Left()
            {
                return this.X;
            }
            /*int */ get Top()
            {
                return this.Y;
            }
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Rectangle.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
            }
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast(Math.ceil(value.X), $.$$.System.Int32), $.$cast(Math.ceil(value.Y), $.$$.System.Int32), $.$cast(Math.ceil(value.Width), $.$$.System.Int32), $.$cast(Math.ceil(value.Height), $.$$.System.Int32));
                }
            }
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast(value.X, $.$$.System.Int32), $.$cast(value.Y, $.$$.System.Int32), $.$cast(value.Width, $.$$.System.Int32), $.$cast(value.Height, $.$$.System.Int32));
                }
            }
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3($.$cast($.$$.System.Math.Round$7(value.X), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Y), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Width), $.$$.System.Int32), $.$cast($.$$.System.Math.Round$7(value.Height), $.$$.System.Int32));
                }
            }
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
            }
            /*bool */ Contains$1(/*Point*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$4($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            /*void */ Inflate$2(/*Size*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*Rectangle */ Inflate$1(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect$1(/*Rectangle*/ rect)
            {
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*Rectangle */ Intersect(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$$.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$$.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$$.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$$.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$3(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
            }
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$$.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$$.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$$.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$$.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$3(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            /*void */ Offset$1(/*Point*/ pos)
            {
                return this.Offset(pos.X, pos.Y);
            }
            /*void */ Offset(/*int*/ x, /*int*/ y)
            {
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                }
            }
            static $h = 693293;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":562221,"g":{"r":0,"d":0,"h":42950366253,"f":50331649},"s":{"r":0,"d":0,"h":47245333549,"f":83886081},"n":"Location","d":693293,"h":38655398957,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":824365,"g":{"r":0,"d":0,"h":55835268141,"f":50331649},"s":{"r":0,"d":0,"h":60130235437,"f":83886081},"n":"Size","d":693293,"h":51540300845,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":68720170029,"f":50331649},"s":{"r":0,"d":0,"h":73015137325,"f":83886081},"n":"X","d":693293,"h":64425202733,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":81605071917,"f":50331649},"s":{"r":0,"d":0,"h":85900039213,"f":83886081},"n":"Y","d":693293,"h":77310104621,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":94489973805,"f":50331649},"s":{"r":0,"d":0,"h":98784941101,"f":83886081},"n":"Width","d":693293,"h":90195006509,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":107374875693,"f":50331649},"s":{"r":0,"d":0,"h":111669842989,"f":83886081},"n":"Height","d":693293,"h":103079908397,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":120259777581,"f":50331649},"n":"Left","d":693293,"h":115964810285,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":128849712173,"f":50331649},"n":"Top","d":693293,"h":124554744877,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":137439646765,"f":50331649},"n":"Right","d":693293,"h":133144679469,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":146029581357,"f":50331649},"n":"Bottom","d":693293,"h":141734614061,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619515949,"f":50331649},"n":"IsEmpty","d":693293,"h":150324548653,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":693293,"p":[{"n":"left","p":655361},{"n":"top","p":655361},{"n":"right","p":655361},{"n":"bottom","p":655361}],"n":"FromLTRB","d":693293,"h":34360431661,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":693293,"h":158914483245,"f":16809985},{"r":262145,"p":[{"n":"other","p":693293}],"n":"Equals","o":"@$2","d":693293,"h":163209450541,"f":16777217},{"r":693293,"p":[{"n":"value","p":758829}],"n":"Ceiling","d":693293,"h":176094352429,"f":16777249},{"r":693293,"p":[{"n":"value","p":758829}],"n":"Truncate","d":693293,"h":180389319725,"f":16777249},{"r":693293,"p":[{"n":"value","p":758829}],"n":"Round","d":693293,"h":184684287021,"f":16777249},{"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Contains","d":693293,"h":188979254317,"f":16777217},{"r":262145,"p":[{"n":"pt","p":562221}],"n":"Contains","o":"@$1","d":693293,"h":193274221613,"f":16777217},{"r":262145,"p":[{"n":"rect","p":693293}],"n":"Contains","o":"@$2","d":693293,"h":197569188909,"f":16777217},{"r":655361,"n":"GetHashCode","d":693293,"h":201864156205,"f":16809985},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"Inflate","d":693293,"h":206159123501,"f":16777217},{"r":65537,"p":[{"n":"size","p":824365}],"n":"Inflate","o":"@$2","d":693293,"h":210454090797,"f":16777217},{"r":693293,"p":[{"n":"rect","p":693293},{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Inflate","o":"@$1","d":693293,"h":214749058093,"f":16777249},{"r":65537,"p":[{"n":"rect","p":693293}],"n":"Intersect","o":"@$1","d":693293,"h":219044025389,"f":16777217},{"r":693293,"p":[{"n":"a","p":693293},{"n":"b","p":693293}],"n":"Intersect","d":693293,"h":223338992685,"f":16777249},{"r":262145,"p":[{"n":"rect","p":693293}],"n":"IntersectsWith","d":693293,"h":227633959981,"f":16777217},{"r":693293,"p":[{"n":"a","p":693293},{"n":"b","p":693293}],"n":"Union","d":693293,"h":231928927277,"f":16777249},{"r":65537,"p":[{"n":"pos","p":562221}],"n":"Offset","o":"@$1","d":693293,"h":236223894573,"f":16777217},{"r":65537,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Offset","d":693293,"h":240518861869,"f":16777217},{"r":1310721,"n":"ToString","d":693293,"h":244813829165,"f":16809985}],"l":[{"t":693293,"n":"Empty","d":693293,"h":4295660589,"f":4194337},{"t":655361,"n":"x","d":693293,"h":8590627885,"f":4194306},{"t":655361,"n":"y","d":693293,"h":12885595181,"f":4194306},{"t":655361,"n":"width","d":693293,"h":17180562477,"f":4194306},{"t":655361,"n":"height","d":693293,"h":21475529773,"f":4194306}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361},{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":693293,"h":25770497069,"f":16777217},{"p":[{"n":"location","p":562221},{"n":"size","p":824365}],"n":".ctor","o":"$ctor$4","d":693293,"h":30065464365,"f":16777217},{"n":".ctor","o":"$ctor$2","d":693293,"h":249108796461,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h],"h":693293,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$$.System.ValueType
        {
            /*SizeF*/ static Empty;
            /*float*/  get width() { return this.$getField(0, $.$$.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$$.System.Single, value); }
            /*float*/  get height() { return this.$getField(4, $.$$.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$$.System.Single, value); }
            $ctor$6(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            $ctor$5(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$$.System.Numerics.Vector2().$ctor$4(this.width, this.height);
            }
            $ctor$4(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                return size.ToVector2();
            }
            static /*SizeF */ op_Explicit$2(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$3(vector.Clone());
            }
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
            }
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
            }
            static /*PointF */ op_Explicit$1(/*SizeF*/ size)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$4(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
            }
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.SizeF.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$$.System.Single, $.$$.System.Single, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            /*PointF */ ToPointF()
            {
                return $.$sdp.System.Drawing.SizeF.op_Explicit$1(this);
            }
            /*Size */ ToSize()
            {
                return $.$sdp.System.Drawing.Size.Truncate(this);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                }
            }
            static $h = 889901;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85900235821,"f":50331649},"n":"IsEmpty","d":889901,"h":81605268525,"f":2097153,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":94490170413,"f":50331649},"s":{"r":0,"d":0,"h":98785137709,"f":83886081},"n":"Width","d":889901,"h":90195203117,"f":2097153},{"p":1114113,"g":{"r":0,"d":0,"h":107375072301,"f":50331649},"s":{"r":0,"d":0,"h":111670039597,"f":83886081},"n":"Height","d":889901,"h":103080105005,"f":2097153}],"m":[{"r":70582273,"n":"ToVector2","d":889901,"h":30065660973,"f":16777217},{"r":889901,"p":[{"n":"sz1","p":889901},{"n":"sz2","p":889901}],"n":"Add","d":889901,"h":115965006893,"f":16777249},{"r":889901,"p":[{"n":"sz1","p":889901},{"n":"sz2","p":889901}],"n":"Subtract","d":889901,"h":120259974189,"f":16777249},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":889901,"h":124554941485,"f":16809985},{"r":262145,"p":[{"n":"other","p":889901}],"n":"Equals","o":"@$2","d":889901,"h":128849908781,"f":16777217},{"r":655361,"n":"GetHashCode","d":889901,"h":133144876077,"f":16809985},{"r":627757,"n":"ToPointF","d":889901,"h":137439843373,"f":16777217},{"r":824365,"n":"ToSize","d":889901,"h":141734810669,"f":16777217},{"r":1310721,"n":"ToString","d":889901,"h":146029777965,"f":16809985},{"r":889901,"p":[{"n":"size","p":889901},{"n":"multiplier","p":1114113}],"n":"Multiply","d":889901,"h":150324745261,"f":16777250}],"l":[{"t":889901,"n":"Empty","d":889901,"h":4295857197,"f":4194337},{"t":1114113,"n":"width","d":889901,"h":8590824493,"f":4194306},{"t":1114113,"n":"height","d":889901,"h":12885791789,"f":4194306}],"c":[{"p":[{"n":"size","p":889901}],"n":".ctor","o":"$ctor$6","d":889901,"h":17180759085,"f":16777217},{"p":[{"n":"pt","p":627757}],"n":".ctor","o":"$ctor$5","d":889901,"h":21475726381,"f":16777217},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":889901,"h":25770693677,"f":16777217},{"p":[{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$4","d":889901,"h":34360628269,"f":16777217},{"n":".ctor","o":"$ctor$2","d":889901,"h":154619712557,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h],"h":889901,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1479695,"c":17181348879,"a":[{"v":"System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$$.System.ValueType
        {
            /*Color*/ static Empty;
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(27/*KnownColor.Transparent*/);
            }
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(28/*KnownColor.AliceBlue*/);
            }
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(29/*KnownColor.AntiqueWhite*/);
            }
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(30/*KnownColor.Aqua*/);
            }
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(31/*KnownColor.Aquamarine*/);
            }
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(32/*KnownColor.Azure*/);
            }
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(33/*KnownColor.Beige*/);
            }
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(34/*KnownColor.Bisque*/);
            }
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(35/*KnownColor.Black*/);
            }
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(36/*KnownColor.BlanchedAlmond*/);
            }
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(37/*KnownColor.Blue*/);
            }
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(38/*KnownColor.BlueViolet*/);
            }
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(39/*KnownColor.Brown*/);
            }
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(40/*KnownColor.BurlyWood*/);
            }
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(41/*KnownColor.CadetBlue*/);
            }
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(42/*KnownColor.Chartreuse*/);
            }
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(43/*KnownColor.Chocolate*/);
            }
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(44/*KnownColor.Coral*/);
            }
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(45/*KnownColor.CornflowerBlue*/);
            }
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(46/*KnownColor.Cornsilk*/);
            }
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(47/*KnownColor.Crimson*/);
            }
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(48/*KnownColor.Cyan*/);
            }
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(49/*KnownColor.DarkBlue*/);
            }
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(50/*KnownColor.DarkCyan*/);
            }
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(51/*KnownColor.DarkGoldenrod*/);
            }
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(52/*KnownColor.DarkGray*/);
            }
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(53/*KnownColor.DarkGreen*/);
            }
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(54/*KnownColor.DarkKhaki*/);
            }
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(55/*KnownColor.DarkMagenta*/);
            }
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(56/*KnownColor.DarkOliveGreen*/);
            }
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(57/*KnownColor.DarkOrange*/);
            }
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(58/*KnownColor.DarkOrchid*/);
            }
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(59/*KnownColor.DarkRed*/);
            }
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(60/*KnownColor.DarkSalmon*/);
            }
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(61/*KnownColor.DarkSeaGreen*/);
            }
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(62/*KnownColor.DarkSlateBlue*/);
            }
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(63/*KnownColor.DarkSlateGray*/);
            }
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(64/*KnownColor.DarkTurquoise*/);
            }
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(65/*KnownColor.DarkViolet*/);
            }
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(66/*KnownColor.DeepPink*/);
            }
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(67/*KnownColor.DeepSkyBlue*/);
            }
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(68/*KnownColor.DimGray*/);
            }
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(69/*KnownColor.DodgerBlue*/);
            }
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(70/*KnownColor.Firebrick*/);
            }
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(71/*KnownColor.FloralWhite*/);
            }
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(72/*KnownColor.ForestGreen*/);
            }
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(73/*KnownColor.Fuchsia*/);
            }
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(74/*KnownColor.Gainsboro*/);
            }
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(75/*KnownColor.GhostWhite*/);
            }
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(76/*KnownColor.Gold*/);
            }
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(77/*KnownColor.Goldenrod*/);
            }
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(78/*KnownColor.Gray*/);
            }
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(79/*KnownColor.Green*/);
            }
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(80/*KnownColor.GreenYellow*/);
            }
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(81/*KnownColor.Honeydew*/);
            }
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(82/*KnownColor.HotPink*/);
            }
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(83/*KnownColor.IndianRed*/);
            }
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(84/*KnownColor.Indigo*/);
            }
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(85/*KnownColor.Ivory*/);
            }
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(86/*KnownColor.Khaki*/);
            }
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(87/*KnownColor.Lavender*/);
            }
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(88/*KnownColor.LavenderBlush*/);
            }
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(89/*KnownColor.LawnGreen*/);
            }
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(90/*KnownColor.LemonChiffon*/);
            }
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(91/*KnownColor.LightBlue*/);
            }
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(92/*KnownColor.LightCoral*/);
            }
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(93/*KnownColor.LightCyan*/);
            }
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(94/*KnownColor.LightGoldenrodYellow*/);
            }
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(96/*KnownColor.LightGreen*/);
            }
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(95/*KnownColor.LightGray*/);
            }
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(97/*KnownColor.LightPink*/);
            }
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(98/*KnownColor.LightSalmon*/);
            }
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(99/*KnownColor.LightSeaGreen*/);
            }
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(100/*KnownColor.LightSkyBlue*/);
            }
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(101/*KnownColor.LightSlateGray*/);
            }
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(102/*KnownColor.LightSteelBlue*/);
            }
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(103/*KnownColor.LightYellow*/);
            }
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(104/*KnownColor.Lime*/);
            }
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(105/*KnownColor.LimeGreen*/);
            }
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(106/*KnownColor.Linen*/);
            }
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(107/*KnownColor.Magenta*/);
            }
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(108/*KnownColor.Maroon*/);
            }
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(109/*KnownColor.MediumAquamarine*/);
            }
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(110/*KnownColor.MediumBlue*/);
            }
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(111/*KnownColor.MediumOrchid*/);
            }
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(112/*KnownColor.MediumPurple*/);
            }
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(113/*KnownColor.MediumSeaGreen*/);
            }
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(114/*KnownColor.MediumSlateBlue*/);
            }
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(115/*KnownColor.MediumSpringGreen*/);
            }
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(116/*KnownColor.MediumTurquoise*/);
            }
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(117/*KnownColor.MediumVioletRed*/);
            }
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(118/*KnownColor.MidnightBlue*/);
            }
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(119/*KnownColor.MintCream*/);
            }
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(120/*KnownColor.MistyRose*/);
            }
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(121/*KnownColor.Moccasin*/);
            }
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(122/*KnownColor.NavajoWhite*/);
            }
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(123/*KnownColor.Navy*/);
            }
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(124/*KnownColor.OldLace*/);
            }
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(125/*KnownColor.Olive*/);
            }
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(126/*KnownColor.OliveDrab*/);
            }
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(127/*KnownColor.Orange*/);
            }
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(128/*KnownColor.OrangeRed*/);
            }
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(129/*KnownColor.Orchid*/);
            }
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(130/*KnownColor.PaleGoldenrod*/);
            }
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(131/*KnownColor.PaleGreen*/);
            }
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(132/*KnownColor.PaleTurquoise*/);
            }
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(133/*KnownColor.PaleVioletRed*/);
            }
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(134/*KnownColor.PapayaWhip*/);
            }
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(135/*KnownColor.PeachPuff*/);
            }
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(136/*KnownColor.Peru*/);
            }
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(137/*KnownColor.Pink*/);
            }
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(138/*KnownColor.Plum*/);
            }
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(139/*KnownColor.PowderBlue*/);
            }
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(140/*KnownColor.Purple*/);
            }
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(175/*KnownColor.RebeccaPurple*/);
            }
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(141/*KnownColor.Red*/);
            }
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(142/*KnownColor.RosyBrown*/);
            }
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(143/*KnownColor.RoyalBlue*/);
            }
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(144/*KnownColor.SaddleBrown*/);
            }
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(145/*KnownColor.Salmon*/);
            }
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(146/*KnownColor.SandyBrown*/);
            }
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(147/*KnownColor.SeaGreen*/);
            }
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(148/*KnownColor.SeaShell*/);
            }
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(149/*KnownColor.Sienna*/);
            }
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(150/*KnownColor.Silver*/);
            }
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(151/*KnownColor.SkyBlue*/);
            }
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(152/*KnownColor.SlateBlue*/);
            }
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(153/*KnownColor.SlateGray*/);
            }
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(154/*KnownColor.Snow*/);
            }
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(155/*KnownColor.SpringGreen*/);
            }
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(156/*KnownColor.SteelBlue*/);
            }
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(157/*KnownColor.Tan*/);
            }
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(158/*KnownColor.Teal*/);
            }
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(159/*KnownColor.Thistle*/);
            }
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(160/*KnownColor.Tomato*/);
            }
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(161/*KnownColor.Turquoise*/);
            }
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(162/*KnownColor.Violet*/);
            }
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(163/*KnownColor.Wheat*/);
            }
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(164/*KnownColor.White*/);
            }
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(165/*KnownColor.WhiteSmoke*/);
            }
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(166/*KnownColor.Yellow*/);
            }
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$4(167/*KnownColor.YellowGreen*/);
            }
            /*short*/ static StateKnownColorValid = 1;
            /*short*/ static StateARGBValueValid = 2;
            /*short*/ static StateValueMask = 2;
            /*short*/ static StateNameValid = 8;
            /*long*/ static NotDefinedValue = 0n;
            /*int*/ static ARGBAlphaShift = 24;
            /*int*/ static ARGBRedShift = 16;
            /*int*/ static ARGBGreenShift = 8;
            /*int*/ static ARGBBlueShift = 0;
            /*uint*/ static ARGBAlphaMask = 4278190080;
            /*uint*/ static ARGBRedMask = 16711680;
            /*uint*/ static ARGBGreenMask = 65280;
            /*uint*/ static ARGBBlueMask = 255;
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            $ctor$4(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$$.System.Int16);
                }
                return this;
            }
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$$.System.Int16);
                }
                return this;
            }
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$$.System.Byte);
            }
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$$.System.Byte);
            }
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$$.System.Byte);
            }
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$$.System.Byte);
            }
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
            }
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            /*string */ get Name()
            {
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$$.System.Diagnostics.Debug.Assert$4($.$$.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$$.System.Int64.ToString$3.call(this.value, "x");
            }
            /*long */ get Value()
            {
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$sdp.System.SR.Format$7($.$sdp.System.SR.InvalidEx2BoundArgument, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ n, $.$box(v, $.$$.System.Int32), $.$box(0/*byte.MinValue*/, $.$$.System.Byte), $.$box(255/*byte.MaxValue*/, $.$$.System.Byte) ], null, null)));
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            static /*Color */ FromArgb$4(/*uint*/ argb)
            {
                return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            static /*Color */ FromArgb$3(/*int*/ argb)
            {
                return $.$sdp.System.Drawing.Color.FromArgb$4((argb >>> 0));
            }
            static /*Color */ FromArgb(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb$4(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            static /*Color */ FromArgb$2(/*int*/ alpha, /*Color*/ baseColor)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb$4(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$$.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            static /*Color */ FromArgb$1(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                return $.$sdp.System.Drawing.Color.FromArgb(255/*byte.MaxValue*/, red, green, blue);
            }
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$$.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$$.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$4(color);
            }
            static /*Color */ FromName(/*string*/ name)
            {
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                /*uint*/ let value = $.$cast(this.Value, $.$$.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            /*float */ GetBrightness()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            /*float */ GetHue()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            /*float */ GetSaturation()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$$.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$$.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$$.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$$.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$$.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$$.System.Single);
            }
            /*int */ ToArgb()
            {
                return $.$cast(this.Value, $.$$.System.Int32);
            }
            /*KnownColor */ ToKnownColor()
            {
                return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$$.System.String.op_Equality(left.name, right.name);
            }
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sdp.System.Drawing.Color.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*Color*/ other)
            {
                return $.$sdp.System.Drawing.Color.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if ($.$$.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$$.System.String.GetHashCode.call(this.name);
                }
                return $.$$.System.HashCode.Combine$5($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int64.GetHashCode.call(this.value), $.$$.System.Int16.GetHashCode.call(this.state), $.$$.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
                this.value = 0n;
                this.knownColor = 0;
                this.state = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                }
            }
            static $h = 103469;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":103469,"g":{"r":0,"d":0,"h":12885005357,"f":50331681},"n":"Transparent","d":103469,"h":8590038061,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":21474939949,"f":50331681},"n":"AliceBlue","d":103469,"h":17179972653,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":30064874541,"f":50331681},"n":"AntiqueWhite","d":103469,"h":25769907245,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":38654809133,"f":50331681},"n":"Aqua","d":103469,"h":34359841837,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":47244743725,"f":50331681},"n":"Aquamarine","d":103469,"h":42949776429,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":55834678317,"f":50331681},"n":"Azure","d":103469,"h":51539711021,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":64424612909,"f":50331681},"n":"Beige","d":103469,"h":60129645613,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":73014547501,"f":50331681},"n":"Bisque","d":103469,"h":68719580205,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":81604482093,"f":50331681},"n":"Black","d":103469,"h":77309514797,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":90194416685,"f":50331681},"n":"BlanchedAlmond","d":103469,"h":85899449389,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":98784351277,"f":50331681},"n":"Blue","d":103469,"h":94489383981,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":107374285869,"f":50331681},"n":"BlueViolet","d":103469,"h":103079318573,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":115964220461,"f":50331681},"n":"Brown","d":103469,"h":111669253165,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":124554155053,"f":50331681},"n":"BurlyWood","d":103469,"h":120259187757,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":133144089645,"f":50331681},"n":"CadetBlue","d":103469,"h":128849122349,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":141734024237,"f":50331681},"n":"Chartreuse","d":103469,"h":137439056941,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":150323958829,"f":50331681},"n":"Chocolate","d":103469,"h":146028991533,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":158913893421,"f":50331681},"n":"Coral","d":103469,"h":154618926125,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":167503828013,"f":50331681},"n":"CornflowerBlue","d":103469,"h":163208860717,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":176093762605,"f":50331681},"n":"Cornsilk","d":103469,"h":171798795309,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":184683697197,"f":50331681},"n":"Crimson","d":103469,"h":180388729901,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":193273631789,"f":50331681},"n":"Cyan","d":103469,"h":188978664493,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":201863566381,"f":50331681},"n":"DarkBlue","d":103469,"h":197568599085,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":210453500973,"f":50331681},"n":"DarkCyan","d":103469,"h":206158533677,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":219043435565,"f":50331681},"n":"DarkGoldenrod","d":103469,"h":214748468269,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":227633370157,"f":50331681},"n":"DarkGray","d":103469,"h":223338402861,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":236223304749,"f":50331681},"n":"DarkGreen","d":103469,"h":231928337453,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":244813239341,"f":50331681},"n":"DarkKhaki","d":103469,"h":240518272045,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":253403173933,"f":50331681},"n":"DarkMagenta","d":103469,"h":249108206637,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":261993108525,"f":50331681},"n":"DarkOliveGreen","d":103469,"h":257698141229,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":270583043117,"f":50331681},"n":"DarkOrange","d":103469,"h":266288075821,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":279172977709,"f":50331681},"n":"DarkOrchid","d":103469,"h":274878010413,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":287762912301,"f":50331681},"n":"DarkRed","d":103469,"h":283467945005,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":296352846893,"f":50331681},"n":"DarkSalmon","d":103469,"h":292057879597,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":304942781485,"f":50331681},"n":"DarkSeaGreen","d":103469,"h":300647814189,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":313532716077,"f":50331681},"n":"DarkSlateBlue","d":103469,"h":309237748781,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":322122650669,"f":50331681},"n":"DarkSlateGray","d":103469,"h":317827683373,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":330712585261,"f":50331681},"n":"DarkTurquoise","d":103469,"h":326417617965,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":339302519853,"f":50331681},"n":"DarkViolet","d":103469,"h":335007552557,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":347892454445,"f":50331681},"n":"DeepPink","d":103469,"h":343597487149,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":356482389037,"f":50331681},"n":"DeepSkyBlue","d":103469,"h":352187421741,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":365072323629,"f":50331681},"n":"DimGray","d":103469,"h":360777356333,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":373662258221,"f":50331681},"n":"DodgerBlue","d":103469,"h":369367290925,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":382252192813,"f":50331681},"n":"Firebrick","d":103469,"h":377957225517,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":390842127405,"f":50331681},"n":"FloralWhite","d":103469,"h":386547160109,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":399432061997,"f":50331681},"n":"ForestGreen","d":103469,"h":395137094701,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":408021996589,"f":50331681},"n":"Fuchsia","d":103469,"h":403727029293,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":416611931181,"f":50331681},"n":"Gainsboro","d":103469,"h":412316963885,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":425201865773,"f":50331681},"n":"GhostWhite","d":103469,"h":420906898477,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":433791800365,"f":50331681},"n":"Gold","d":103469,"h":429496833069,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":442381734957,"f":50331681},"n":"Goldenrod","d":103469,"h":438086767661,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":450971669549,"f":50331681},"n":"Gray","d":103469,"h":446676702253,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":459561604141,"f":50331681},"n":"Green","d":103469,"h":455266636845,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":468151538733,"f":50331681},"n":"GreenYellow","d":103469,"h":463856571437,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":476741473325,"f":50331681},"n":"Honeydew","d":103469,"h":472446506029,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":485331407917,"f":50331681},"n":"HotPink","d":103469,"h":481036440621,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":493921342509,"f":50331681},"n":"IndianRed","d":103469,"h":489626375213,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":502511277101,"f":50331681},"n":"Indigo","d":103469,"h":498216309805,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":511101211693,"f":50331681},"n":"Ivory","d":103469,"h":506806244397,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":519691146285,"f":50331681},"n":"Khaki","d":103469,"h":515396178989,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":528281080877,"f":50331681},"n":"Lavender","d":103469,"h":523986113581,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":536871015469,"f":50331681},"n":"LavenderBlush","d":103469,"h":532576048173,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":545460950061,"f":50331681},"n":"LawnGreen","d":103469,"h":541165982765,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":554050884653,"f":50331681},"n":"LemonChiffon","d":103469,"h":549755917357,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":562640819245,"f":50331681},"n":"LightBlue","d":103469,"h":558345851949,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":571230753837,"f":50331681},"n":"LightCoral","d":103469,"h":566935786541,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":579820688429,"f":50331681},"n":"LightCyan","d":103469,"h":575525721133,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":588410623021,"f":50331681},"n":"LightGoldenrodYellow","d":103469,"h":584115655725,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":597000557613,"f":50331681},"n":"LightGreen","d":103469,"h":592705590317,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":605590492205,"f":50331681},"n":"LightGray","d":103469,"h":601295524909,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":614180426797,"f":50331681},"n":"LightPink","d":103469,"h":609885459501,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":622770361389,"f":50331681},"n":"LightSalmon","d":103469,"h":618475394093,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":631360295981,"f":50331681},"n":"LightSeaGreen","d":103469,"h":627065328685,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":639950230573,"f":50331681},"n":"LightSkyBlue","d":103469,"h":635655263277,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":648540165165,"f":50331681},"n":"LightSlateGray","d":103469,"h":644245197869,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":657130099757,"f":50331681},"n":"LightSteelBlue","d":103469,"h":652835132461,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":665720034349,"f":50331681},"n":"LightYellow","d":103469,"h":661425067053,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":674309968941,"f":50331681},"n":"Lime","d":103469,"h":670015001645,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":682899903533,"f":50331681},"n":"LimeGreen","d":103469,"h":678604936237,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":691489838125,"f":50331681},"n":"Linen","d":103469,"h":687194870829,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":700079772717,"f":50331681},"n":"Magenta","d":103469,"h":695784805421,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":708669707309,"f":50331681},"n":"Maroon","d":103469,"h":704374740013,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":717259641901,"f":50331681},"n":"MediumAquamarine","d":103469,"h":712964674605,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":725849576493,"f":50331681},"n":"MediumBlue","d":103469,"h":721554609197,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":734439511085,"f":50331681},"n":"MediumOrchid","d":103469,"h":730144543789,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":743029445677,"f":50331681},"n":"MediumPurple","d":103469,"h":738734478381,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":751619380269,"f":50331681},"n":"MediumSeaGreen","d":103469,"h":747324412973,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":760209314861,"f":50331681},"n":"MediumSlateBlue","d":103469,"h":755914347565,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":768799249453,"f":50331681},"n":"MediumSpringGreen","d":103469,"h":764504282157,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":777389184045,"f":50331681},"n":"MediumTurquoise","d":103469,"h":773094216749,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":785979118637,"f":50331681},"n":"MediumVioletRed","d":103469,"h":781684151341,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":794569053229,"f":50331681},"n":"MidnightBlue","d":103469,"h":790274085933,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":803158987821,"f":50331681},"n":"MintCream","d":103469,"h":798864020525,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":811748922413,"f":50331681},"n":"MistyRose","d":103469,"h":807453955117,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":820338857005,"f":50331681},"n":"Moccasin","d":103469,"h":816043889709,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":828928791597,"f":50331681},"n":"NavajoWhite","d":103469,"h":824633824301,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":837518726189,"f":50331681},"n":"Navy","d":103469,"h":833223758893,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":846108660781,"f":50331681},"n":"OldLace","d":103469,"h":841813693485,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":854698595373,"f":50331681},"n":"Olive","d":103469,"h":850403628077,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":863288529965,"f":50331681},"n":"OliveDrab","d":103469,"h":858993562669,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":871878464557,"f":50331681},"n":"Orange","d":103469,"h":867583497261,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":880468399149,"f":50331681},"n":"OrangeRed","d":103469,"h":876173431853,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":889058333741,"f":50331681},"n":"Orchid","d":103469,"h":884763366445,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":897648268333,"f":50331681},"n":"PaleGoldenrod","d":103469,"h":893353301037,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":906238202925,"f":50331681},"n":"PaleGreen","d":103469,"h":901943235629,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":914828137517,"f":50331681},"n":"PaleTurquoise","d":103469,"h":910533170221,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":923418072109,"f":50331681},"n":"PaleVioletRed","d":103469,"h":919123104813,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":932008006701,"f":50331681},"n":"PapayaWhip","d":103469,"h":927713039405,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":940597941293,"f":50331681},"n":"PeachPuff","d":103469,"h":936302973997,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":949187875885,"f":50331681},"n":"Peru","d":103469,"h":944892908589,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":957777810477,"f":50331681},"n":"Pink","d":103469,"h":953482843181,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":966367745069,"f":50331681},"n":"Plum","d":103469,"h":962072777773,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":974957679661,"f":50331681},"n":"PowderBlue","d":103469,"h":970662712365,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":983547614253,"f":50331681},"n":"Purple","d":103469,"h":979252646957,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":992137548845,"f":50331681},"n":"RebeccaPurple","d":103469,"h":987842581549,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1000727483437,"f":50331681},"n":"Red","d":103469,"h":996432516141,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1009317418029,"f":50331681},"n":"RosyBrown","d":103469,"h":1005022450733,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1017907352621,"f":50331681},"n":"RoyalBlue","d":103469,"h":1013612385325,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1026497287213,"f":50331681},"n":"SaddleBrown","d":103469,"h":1022202319917,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1035087221805,"f":50331681},"n":"Salmon","d":103469,"h":1030792254509,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1043677156397,"f":50331681},"n":"SandyBrown","d":103469,"h":1039382189101,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1052267090989,"f":50331681},"n":"SeaGreen","d":103469,"h":1047972123693,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1060857025581,"f":50331681},"n":"SeaShell","d":103469,"h":1056562058285,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1069446960173,"f":50331681},"n":"Sienna","d":103469,"h":1065151992877,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1078036894765,"f":50331681},"n":"Silver","d":103469,"h":1073741927469,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1086626829357,"f":50331681},"n":"SkyBlue","d":103469,"h":1082331862061,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1095216763949,"f":50331681},"n":"SlateBlue","d":103469,"h":1090921796653,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1103806698541,"f":50331681},"n":"SlateGray","d":103469,"h":1099511731245,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1112396633133,"f":50331681},"n":"Snow","d":103469,"h":1108101665837,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1120986567725,"f":50331681},"n":"SpringGreen","d":103469,"h":1116691600429,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1129576502317,"f":50331681},"n":"SteelBlue","d":103469,"h":1125281535021,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1138166436909,"f":50331681},"n":"Tan","d":103469,"h":1133871469613,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1146756371501,"f":50331681},"n":"Teal","d":103469,"h":1142461404205,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1155346306093,"f":50331681},"n":"Thistle","d":103469,"h":1151051338797,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1163936240685,"f":50331681},"n":"Tomato","d":103469,"h":1159641273389,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1172526175277,"f":50331681},"n":"Turquoise","d":103469,"h":1168231207981,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1181116109869,"f":50331681},"n":"Violet","d":103469,"h":1176821142573,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1189706044461,"f":50331681},"n":"Wheat","d":103469,"h":1185411077165,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1198295979053,"f":50331681},"n":"White","d":103469,"h":1194001011757,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1206885913645,"f":50331681},"n":"WhiteSmoke","d":103469,"h":1202590946349,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1215475848237,"f":50331681},"n":"Yellow","d":103469,"h":1211180880941,"f":2097185},{"p":103469,"g":{"r":0,"d":0,"h":1224065782829,"f":50331681},"n":"YellowGreen","d":103469,"h":1219770815533,"f":2097185},{"p":393217,"g":{"r":0,"d":0,"h":1314260096045,"f":50331649},"n":"R","d":103469,"h":1309965128749,"f":2097153},{"p":393217,"g":{"r":0,"d":0,"h":1322850030637,"f":50331649},"n":"G","d":103469,"h":1318555063341,"f":2097153},{"p":393217,"g":{"r":0,"d":0,"h":1331439965229,"f":50331649},"n":"B","d":103469,"h":1327144997933,"f":2097153},{"p":393217,"g":{"r":0,"d":0,"h":1340029899821,"f":50331649},"n":"A","d":103469,"h":1335734932525,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":1348619834413,"f":50331649},"n":"IsKnownColor","d":103469,"h":1344324867117,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":1357209769005,"f":50331649},"n":"IsEmpty","d":103469,"h":1352914801709,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":1365799703597,"f":50331649},"n":"IsNamedColor","d":103469,"h":1361504736301,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":1374389638189,"f":50331649},"n":"IsSystemColor","d":103469,"h":1370094670893,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":1387274540077,"f":50331650},"n":"NameAndARGBValue","d":103469,"h":1382979572781,"f":2097154},{"p":1310721,"g":{"r":0,"d":0,"h":1395864474669,"f":50331649},"n":"Name","d":103469,"h":1391569507373,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":1404454409261,"f":50331650},"n":"Value","d":103469,"h":1400159441965,"f":2097154}],"m":[{"r":262145,"p":[{"n":"knownColor","p":365613}],"n":"IsKnownColorSystem","d":103469,"h":1378684605485,"f":16777256},{"r":65537,"p":[{"n":"value","p":655361},{"n":"name","p":1310721}],"n":"CheckByte","d":103469,"h":1408749376557,"f":16777250},{"r":103469,"p":[{"n":"argb","p":720897}],"n":"FromArgb","o":"@$4","d":103469,"h":1413044343853,"f":16777250},{"r":103469,"p":[{"n":"argb","p":655361}],"n":"FromArgb","o":"@$3","d":103469,"h":1417339311149,"f":16777249},{"r":103469,"p":[{"n":"alpha","p":655361},{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","d":103469,"h":1421634278445,"f":16777249},{"r":103469,"p":[{"n":"alpha","p":655361},{"n":"baseColor","p":103469}],"n":"FromArgb","o":"@$2","d":103469,"h":1425929245741,"f":16777249},{"r":103469,"p":[{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$1","d":103469,"h":1430224213037,"f":16777249},{"r":103469,"p":[{"n":"color","p":365613}],"n":"FromKnownColor","d":103469,"h":1434519180333,"f":16777249},{"r":103469,"p":[{"n":"name","p":1310721}],"n":"FromName","d":103469,"h":1438814147629,"f":16777249},{"r":65537,"p":[{"n":"r","p":655361,"f":2},{"n":"g","p":655361,"f":2},{"n":"b","p":655361,"f":2}],"n":"GetRgbValues","d":103469,"h":1443109114925,"f":16777224},{"r":65537,"p":[{"n":"min","p":655361,"f":2},{"n":"max","p":655361,"f":2},{"n":"r","p":655361},{"n":"g","p":655361},{"n":"b","p":655361}],"n":"MinMaxRgb","d":103469,"h":1447404082221,"f":16777250},{"r":1114113,"n":"GetBrightness","d":103469,"h":1451699049517,"f":16777217},{"r":1114113,"n":"GetHue","d":103469,"h":1455994016813,"f":16777217},{"r":1114113,"n":"GetSaturation","d":103469,"h":1460288984109,"f":16777217},{"r":655361,"n":"ToArgb","d":103469,"h":1464583951405,"f":16777217},{"r":365613,"n":"ToKnownColor","d":103469,"h":1468878918701,"f":16777217},{"r":1310721,"n":"ToString","d":103469,"h":1473173885997,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":103469,"h":1486058787885,"f":16809985},{"r":262145,"p":[{"n":"other","p":103469}],"n":"Equals","o":"@$2","d":103469,"h":1490353755181,"f":16777217},{"r":655361,"n":"GetHashCode","d":103469,"h":1494648722477,"f":16809985}],"l":[{"t":103469,"n":"Empty","d":103469,"h":4295070765,"f":4194337},{"t":524289,"n":"StateKnownColorValid","d":103469,"h":1228360750125,"f":4194338},{"t":524289,"n":"StateARGBValueValid","d":103469,"h":1232655717421,"f":4194338},{"t":524289,"n":"StateValueMask","d":103469,"h":1236950684717,"f":4194338},{"t":524289,"n":"StateNameValid","d":103469,"h":1241245652013,"f":4194338},{"t":917505,"n":"NotDefinedValue","d":103469,"h":1245540619309,"f":4194338},{"t":655361,"n":"ARGBAlphaShift","d":103469,"h":1249835586605,"f":4194344},{"t":655361,"n":"ARGBRedShift","d":103469,"h":1254130553901,"f":4194344},{"t":655361,"n":"ARGBGreenShift","d":103469,"h":1258425521197,"f":4194344},{"t":655361,"n":"ARGBBlueShift","d":103469,"h":1262720488493,"f":4194344},{"t":720897,"n":"ARGBAlphaMask","d":103469,"h":1267015455789,"f":4194344},{"t":720897,"n":"ARGBRedMask","d":103469,"h":1271310423085,"f":4194344},{"t":720897,"n":"ARGBGreenMask","d":103469,"h":1275605390381,"f":4194344},{"t":720897,"n":"ARGBBlueMask","d":103469,"h":1279900357677,"f":4194344},{"t":1310721,"n":"name","d":103469,"h":1284195324973,"f":4194306},{"t":917505,"n":"value","d":103469,"h":1288490292269,"f":4194306},{"t":524289,"n":"knownColor","d":103469,"h":1292785259565,"f":4194306},{"t":524289,"n":"state","d":103469,"h":1297080226861,"f":4194306}],"c":[{"p":[{"n":"knownColor","p":365613}],"n":".ctor","o":"$ctor$4","d":103469,"h":1301375194157,"f":16777224},{"p":[{"n":"value","p":917505},{"n":"state","p":524289},{"n":"name","p":1310721},{"n":"knownColor","p":365613}],"n":".ctor","o":"$ctor$3","d":103469,"h":1305670161453,"f":16777218},{"n":".ctor","o":"$ctor$2","d":103469,"h":1498943689773,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sdp.System.Drawing.Color).$h],"h":103469,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"{NameAndARGBValue}","t":1310721}]},{"t":852007,"c":12885753895,"a":[{"v":"System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":118095873,"c":4413063169},{"t":1479695,"c":17181348879,"a":[{"v":"System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$$.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 365613;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":365613,"n":"ActiveBorder","d":365613,"h":4295332909,"f":4194337},{"t":365613,"n":"ActiveCaption","d":365613,"h":8590300205,"f":4194337},{"t":365613,"n":"ActiveCaptionText","d":365613,"h":12885267501,"f":4194337},{"t":365613,"n":"AppWorkspace","d":365613,"h":17180234797,"f":4194337},{"t":365613,"n":"Control","d":365613,"h":21475202093,"f":4194337},{"t":365613,"n":"ControlDark","d":365613,"h":25770169389,"f":4194337},{"t":365613,"n":"ControlDarkDark","d":365613,"h":30065136685,"f":4194337},{"t":365613,"n":"ControlLight","d":365613,"h":34360103981,"f":4194337},{"t":365613,"n":"ControlLightLight","d":365613,"h":38655071277,"f":4194337},{"t":365613,"n":"ControlText","d":365613,"h":42950038573,"f":4194337},{"t":365613,"n":"Desktop","d":365613,"h":47245005869,"f":4194337},{"t":365613,"n":"GrayText","d":365613,"h":51539973165,"f":4194337},{"t":365613,"n":"Highlight","d":365613,"h":55834940461,"f":4194337},{"t":365613,"n":"HighlightText","d":365613,"h":60129907757,"f":4194337},{"t":365613,"n":"HotTrack","d":365613,"h":64424875053,"f":4194337},{"t":365613,"n":"InactiveBorder","d":365613,"h":68719842349,"f":4194337},{"t":365613,"n":"InactiveCaption","d":365613,"h":73014809645,"f":4194337},{"t":365613,"n":"InactiveCaptionText","d":365613,"h":77309776941,"f":4194337},{"t":365613,"n":"Info","d":365613,"h":81604744237,"f":4194337},{"t":365613,"n":"InfoText","d":365613,"h":85899711533,"f":4194337},{"t":365613,"n":"Menu","d":365613,"h":90194678829,"f":4194337},{"t":365613,"n":"MenuText","d":365613,"h":94489646125,"f":4194337},{"t":365613,"n":"ScrollBar","d":365613,"h":98784613421,"f":4194337},{"t":365613,"n":"Window","d":365613,"h":103079580717,"f":4194337},{"t":365613,"n":"WindowFrame","d":365613,"h":107374548013,"f":4194337},{"t":365613,"n":"WindowText","d":365613,"h":111669515309,"f":4194337},{"t":365613,"n":"Transparent","d":365613,"h":115964482605,"f":4194337},{"t":365613,"n":"AliceBlue","d":365613,"h":120259449901,"f":4194337},{"t":365613,"n":"AntiqueWhite","d":365613,"h":124554417197,"f":4194337},{"t":365613,"n":"Aqua","d":365613,"h":128849384493,"f":4194337},{"t":365613,"n":"Aquamarine","d":365613,"h":133144351789,"f":4194337},{"t":365613,"n":"Azure","d":365613,"h":137439319085,"f":4194337},{"t":365613,"n":"Beige","d":365613,"h":141734286381,"f":4194337},{"t":365613,"n":"Bisque","d":365613,"h":146029253677,"f":4194337},{"t":365613,"n":"Black","d":365613,"h":150324220973,"f":4194337},{"t":365613,"n":"BlanchedAlmond","d":365613,"h":154619188269,"f":4194337},{"t":365613,"n":"Blue","d":365613,"h":158914155565,"f":4194337},{"t":365613,"n":"BlueViolet","d":365613,"h":163209122861,"f":4194337},{"t":365613,"n":"Brown","d":365613,"h":167504090157,"f":4194337},{"t":365613,"n":"BurlyWood","d":365613,"h":171799057453,"f":4194337},{"t":365613,"n":"CadetBlue","d":365613,"h":176094024749,"f":4194337},{"t":365613,"n":"Chartreuse","d":365613,"h":180388992045,"f":4194337},{"t":365613,"n":"Chocolate","d":365613,"h":184683959341,"f":4194337},{"t":365613,"n":"Coral","d":365613,"h":188978926637,"f":4194337},{"t":365613,"n":"CornflowerBlue","d":365613,"h":193273893933,"f":4194337},{"t":365613,"n":"Cornsilk","d":365613,"h":197568861229,"f":4194337},{"t":365613,"n":"Crimson","d":365613,"h":201863828525,"f":4194337},{"t":365613,"n":"Cyan","d":365613,"h":206158795821,"f":4194337},{"t":365613,"n":"DarkBlue","d":365613,"h":210453763117,"f":4194337},{"t":365613,"n":"DarkCyan","d":365613,"h":214748730413,"f":4194337},{"t":365613,"n":"DarkGoldenrod","d":365613,"h":219043697709,"f":4194337},{"t":365613,"n":"DarkGray","d":365613,"h":223338665005,"f":4194337},{"t":365613,"n":"DarkGreen","d":365613,"h":227633632301,"f":4194337},{"t":365613,"n":"DarkKhaki","d":365613,"h":231928599597,"f":4194337},{"t":365613,"n":"DarkMagenta","d":365613,"h":236223566893,"f":4194337},{"t":365613,"n":"DarkOliveGreen","d":365613,"h":240518534189,"f":4194337},{"t":365613,"n":"DarkOrange","d":365613,"h":244813501485,"f":4194337},{"t":365613,"n":"DarkOrchid","d":365613,"h":249108468781,"f":4194337},{"t":365613,"n":"DarkRed","d":365613,"h":253403436077,"f":4194337},{"t":365613,"n":"DarkSalmon","d":365613,"h":257698403373,"f":4194337},{"t":365613,"n":"DarkSeaGreen","d":365613,"h":261993370669,"f":4194337},{"t":365613,"n":"DarkSlateBlue","d":365613,"h":266288337965,"f":4194337},{"t":365613,"n":"DarkSlateGray","d":365613,"h":270583305261,"f":4194337},{"t":365613,"n":"DarkTurquoise","d":365613,"h":274878272557,"f":4194337},{"t":365613,"n":"DarkViolet","d":365613,"h":279173239853,"f":4194337},{"t":365613,"n":"DeepPink","d":365613,"h":283468207149,"f":4194337},{"t":365613,"n":"DeepSkyBlue","d":365613,"h":287763174445,"f":4194337},{"t":365613,"n":"DimGray","d":365613,"h":292058141741,"f":4194337},{"t":365613,"n":"DodgerBlue","d":365613,"h":296353109037,"f":4194337},{"t":365613,"n":"Firebrick","d":365613,"h":300648076333,"f":4194337},{"t":365613,"n":"FloralWhite","d":365613,"h":304943043629,"f":4194337},{"t":365613,"n":"ForestGreen","d":365613,"h":309238010925,"f":4194337},{"t":365613,"n":"Fuchsia","d":365613,"h":313532978221,"f":4194337},{"t":365613,"n":"Gainsboro","d":365613,"h":317827945517,"f":4194337},{"t":365613,"n":"GhostWhite","d":365613,"h":322122912813,"f":4194337},{"t":365613,"n":"Gold","d":365613,"h":326417880109,"f":4194337},{"t":365613,"n":"Goldenrod","d":365613,"h":330712847405,"f":4194337},{"t":365613,"n":"Gray","d":365613,"h":335007814701,"f":4194337},{"t":365613,"n":"Green","d":365613,"h":339302781997,"f":4194337},{"t":365613,"n":"GreenYellow","d":365613,"h":343597749293,"f":4194337},{"t":365613,"n":"Honeydew","d":365613,"h":347892716589,"f":4194337},{"t":365613,"n":"HotPink","d":365613,"h":352187683885,"f":4194337},{"t":365613,"n":"IndianRed","d":365613,"h":356482651181,"f":4194337},{"t":365613,"n":"Indigo","d":365613,"h":360777618477,"f":4194337},{"t":365613,"n":"Ivory","d":365613,"h":365072585773,"f":4194337},{"t":365613,"n":"Khaki","d":365613,"h":369367553069,"f":4194337},{"t":365613,"n":"Lavender","d":365613,"h":373662520365,"f":4194337},{"t":365613,"n":"LavenderBlush","d":365613,"h":377957487661,"f":4194337},{"t":365613,"n":"LawnGreen","d":365613,"h":382252454957,"f":4194337},{"t":365613,"n":"LemonChiffon","d":365613,"h":386547422253,"f":4194337},{"t":365613,"n":"LightBlue","d":365613,"h":390842389549,"f":4194337},{"t":365613,"n":"LightCoral","d":365613,"h":395137356845,"f":4194337},{"t":365613,"n":"LightCyan","d":365613,"h":399432324141,"f":4194337},{"t":365613,"n":"LightGoldenrodYellow","d":365613,"h":403727291437,"f":4194337},{"t":365613,"n":"LightGray","d":365613,"h":408022258733,"f":4194337},{"t":365613,"n":"LightGreen","d":365613,"h":412317226029,"f":4194337},{"t":365613,"n":"LightPink","d":365613,"h":416612193325,"f":4194337},{"t":365613,"n":"LightSalmon","d":365613,"h":420907160621,"f":4194337},{"t":365613,"n":"LightSeaGreen","d":365613,"h":425202127917,"f":4194337},{"t":365613,"n":"LightSkyBlue","d":365613,"h":429497095213,"f":4194337},{"t":365613,"n":"LightSlateGray","d":365613,"h":433792062509,"f":4194337},{"t":365613,"n":"LightSteelBlue","d":365613,"h":438087029805,"f":4194337},{"t":365613,"n":"LightYellow","d":365613,"h":442381997101,"f":4194337},{"t":365613,"n":"Lime","d":365613,"h":446676964397,"f":4194337},{"t":365613,"n":"LimeGreen","d":365613,"h":450971931693,"f":4194337},{"t":365613,"n":"Linen","d":365613,"h":455266898989,"f":4194337},{"t":365613,"n":"Magenta","d":365613,"h":459561866285,"f":4194337},{"t":365613,"n":"Maroon","d":365613,"h":463856833581,"f":4194337},{"t":365613,"n":"MediumAquamarine","d":365613,"h":468151800877,"f":4194337},{"t":365613,"n":"MediumBlue","d":365613,"h":472446768173,"f":4194337},{"t":365613,"n":"MediumOrchid","d":365613,"h":476741735469,"f":4194337},{"t":365613,"n":"MediumPurple","d":365613,"h":481036702765,"f":4194337},{"t":365613,"n":"MediumSeaGreen","d":365613,"h":485331670061,"f":4194337},{"t":365613,"n":"MediumSlateBlue","d":365613,"h":489626637357,"f":4194337},{"t":365613,"n":"MediumSpringGreen","d":365613,"h":493921604653,"f":4194337},{"t":365613,"n":"MediumTurquoise","d":365613,"h":498216571949,"f":4194337},{"t":365613,"n":"MediumVioletRed","d":365613,"h":502511539245,"f":4194337},{"t":365613,"n":"MidnightBlue","d":365613,"h":506806506541,"f":4194337},{"t":365613,"n":"MintCream","d":365613,"h":511101473837,"f":4194337},{"t":365613,"n":"MistyRose","d":365613,"h":515396441133,"f":4194337},{"t":365613,"n":"Moccasin","d":365613,"h":519691408429,"f":4194337},{"t":365613,"n":"NavajoWhite","d":365613,"h":523986375725,"f":4194337},{"t":365613,"n":"Navy","d":365613,"h":528281343021,"f":4194337},{"t":365613,"n":"OldLace","d":365613,"h":532576310317,"f":4194337},{"t":365613,"n":"Olive","d":365613,"h":536871277613,"f":4194337},{"t":365613,"n":"OliveDrab","d":365613,"h":541166244909,"f":4194337},{"t":365613,"n":"Orange","d":365613,"h":545461212205,"f":4194337},{"t":365613,"n":"OrangeRed","d":365613,"h":549756179501,"f":4194337},{"t":365613,"n":"Orchid","d":365613,"h":554051146797,"f":4194337},{"t":365613,"n":"PaleGoldenrod","d":365613,"h":558346114093,"f":4194337},{"t":365613,"n":"PaleGreen","d":365613,"h":562641081389,"f":4194337},{"t":365613,"n":"PaleTurquoise","d":365613,"h":566936048685,"f":4194337},{"t":365613,"n":"PaleVioletRed","d":365613,"h":571231015981,"f":4194337},{"t":365613,"n":"PapayaWhip","d":365613,"h":575525983277,"f":4194337},{"t":365613,"n":"PeachPuff","d":365613,"h":579820950573,"f":4194337},{"t":365613,"n":"Peru","d":365613,"h":584115917869,"f":4194337},{"t":365613,"n":"Pink","d":365613,"h":588410885165,"f":4194337},{"t":365613,"n":"Plum","d":365613,"h":592705852461,"f":4194337},{"t":365613,"n":"PowderBlue","d":365613,"h":597000819757,"f":4194337},{"t":365613,"n":"Purple","d":365613,"h":601295787053,"f":4194337},{"t":365613,"n":"Red","d":365613,"h":605590754349,"f":4194337},{"t":365613,"n":"RosyBrown","d":365613,"h":609885721645,"f":4194337},{"t":365613,"n":"RoyalBlue","d":365613,"h":614180688941,"f":4194337},{"t":365613,"n":"SaddleBrown","d":365613,"h":618475656237,"f":4194337},{"t":365613,"n":"Salmon","d":365613,"h":622770623533,"f":4194337},{"t":365613,"n":"SandyBrown","d":365613,"h":627065590829,"f":4194337},{"t":365613,"n":"SeaGreen","d":365613,"h":631360558125,"f":4194337},{"t":365613,"n":"SeaShell","d":365613,"h":635655525421,"f":4194337},{"t":365613,"n":"Sienna","d":365613,"h":639950492717,"f":4194337},{"t":365613,"n":"Silver","d":365613,"h":644245460013,"f":4194337},{"t":365613,"n":"SkyBlue","d":365613,"h":648540427309,"f":4194337},{"t":365613,"n":"SlateBlue","d":365613,"h":652835394605,"f":4194337},{"t":365613,"n":"SlateGray","d":365613,"h":657130361901,"f":4194337},{"t":365613,"n":"Snow","d":365613,"h":661425329197,"f":4194337},{"t":365613,"n":"SpringGreen","d":365613,"h":665720296493,"f":4194337},{"t":365613,"n":"SteelBlue","d":365613,"h":670015263789,"f":4194337},{"t":365613,"n":"Tan","d":365613,"h":674310231085,"f":4194337},{"t":365613,"n":"Teal","d":365613,"h":678605198381,"f":4194337},{"t":365613,"n":"Thistle","d":365613,"h":682900165677,"f":4194337},{"t":365613,"n":"Tomato","d":365613,"h":687195132973,"f":4194337},{"t":365613,"n":"Turquoise","d":365613,"h":691490100269,"f":4194337},{"t":365613,"n":"Violet","d":365613,"h":695785067565,"f":4194337},{"t":365613,"n":"Wheat","d":365613,"h":700080034861,"f":4194337},{"t":365613,"n":"White","d":365613,"h":704375002157,"f":4194337},{"t":365613,"n":"WhiteSmoke","d":365613,"h":708669969453,"f":4194337},{"t":365613,"n":"Yellow","d":365613,"h":712964936749,"f":4194337},{"t":365613,"n":"YellowGreen","d":365613,"h":717259904045,"f":4194337},{"t":365613,"n":"ButtonFace","d":365613,"h":721554871341,"f":4194337},{"t":365613,"n":"ButtonHighlight","d":365613,"h":725849838637,"f":4194337},{"t":365613,"n":"ButtonShadow","d":365613,"h":730144805933,"f":4194337},{"t":365613,"n":"GradientActiveCaption","d":365613,"h":734439773229,"f":4194337},{"t":365613,"n":"GradientInactiveCaption","d":365613,"h":738734740525,"f":4194337},{"t":365613,"n":"MenuBar","d":365613,"h":743029707821,"f":4194337},{"t":365613,"n":"MenuHighlight","d":365613,"h":747324675117,"f":4194337},{"t":365613,"n":"RebeccaPurple","d":365613,"h":751619642413,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":365613,"h":755914609709,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":365613,"a":[{"t":96141313,"c":4391108609,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.InteropServices"))