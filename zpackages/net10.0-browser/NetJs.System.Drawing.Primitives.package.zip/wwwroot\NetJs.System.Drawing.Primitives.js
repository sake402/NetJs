
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $st, $sr, $scc, $scn, $scm, $so, $sris, $scp) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Drawing.Primitives", 
    {"h":50875,"f":"System.Drawing.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Drawing.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sdp.System.Drawing.KnownColorNames", ($self) => class KnownColorNames
        {
            /*string[]*/ static s_colorNameTable = null;
            static /*string */ KnownColorToName(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$spc.System.Array.$ReadT1.call($.$sdp.System.Drawing.KnownColorNames.s_colorNameTable, ((color - 1) | 0));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorNameTable = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), ["ActiveBorder", "ActiveCaption", "ActiveCaptionText", "AppWorkspace", "Control", "ControlDark", "ControlDarkDark", "ControlLight", "ControlLightLight", "ControlText", "Desktop", "GrayText", "Highlight", "HighlightText", "HotTrack", "InactiveBorder", "InactiveCaption", "InactiveCaptionText", "Info", "InfoText", "Menu", "MenuText", "ScrollBar", "Window", "WindowFrame", "WindowText", "Transparent", "AliceBlue", "AntiqueWhite", "Aqua", "Aquamarine", "Azure", "Beige", "Bisque", "Black", "BlanchedAlmond", "Blue", "BlueViolet", "Brown", "BurlyWood", "CadetBlue", "Chartreuse", "Chocolate", "Coral", "CornflowerBlue", "Cornsilk", "Crimson", "Cyan", "DarkBlue", "DarkCyan", "DarkGoldenrod", "DarkGray", "DarkGreen", "DarkKhaki", "DarkMagenta", "DarkOliveGreen", "DarkOrange", "DarkOrchid", "DarkRed", "DarkSalmon", "DarkSeaGreen", "DarkSlateBlue", "DarkSlateGray", "DarkTurquoise", "DarkViolet", "DeepPink", "DeepSkyBlue", "DimGray", "DodgerBlue", "Firebrick", "FloralWhite", "ForestGreen", "Fuchsia", "Gainsboro", "GhostWhite", "Gold", "Goldenrod", "Gray", "Green", "GreenYellow", "Honeydew", "HotPink", "IndianRed", "Indigo", "Ivory", "Khaki", "Lavender", "LavenderBlush", "LawnGreen", "LemonChiffon", "LightBlue", "LightCoral", "LightCyan", "LightGoldenrodYellow", "LightGray", "LightGreen", "LightPink", "LightSalmon", "LightSeaGreen", "LightSkyBlue", "LightSlateGray", "LightSteelBlue", "LightYellow", "Lime", "LimeGreen", "Linen", "Magenta", "Maroon", "MediumAquamarine", "MediumBlue", "MediumOrchid", "MediumPurple", "MediumSeaGreen", "MediumSlateBlue", "MediumSpringGreen", "MediumTurquoise", "MediumVioletRed", "MidnightBlue", "MintCream", "MistyRose", "Moccasin", "NavajoWhite", "Navy", "OldLace", "Olive", "OliveDrab", "Orange", "OrangeRed", "Orchid", "PaleGoldenrod", "PaleGreen", "PaleTurquoise", "PaleVioletRed", "PapayaWhip", "PeachPuff", "Peru", "Pink", "Plum", "PowderBlue", "Purple", "Red", "RosyBrown", "RoyalBlue", "SaddleBrown", "Salmon", "SandyBrown", "SeaGreen", "SeaShell", "Sienna", "Silver", "SkyBlue", "SlateBlue", "SlateGray", "Snow", "SpringGreen", "SteelBlue", "Tan", "Teal", "Thistle", "Tomato", "Turquoise", "Violet", "Wheat", "White", "WhiteSmoke", "Yellow", "YellowGreen", "ButtonFace", "ButtonHighlight", "ButtonShadow", "GradientActiveCaption", "GradientInactiveCaption", "MenuBar", "MenuHighlight", "RebeccaPurple"], [-1], null);
                }
            }
            static $h = 444091;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"color","p":378555}],"n":"KnownColorToName","d":444091,"h":8590378683,"f":33}],"l":[{"t":0,"n":"s_colorNameTable","d":444091,"h":4295411387,"f":34}],"h":444091}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorNames`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.KnownColorTable", ($self) => class KnownColorTable
        {
            /*byte*/ static KnownColorKindSystem = 0;
            /*byte*/ static KnownColorKindWeb = 1;
            /*byte*/ static KnownColorKindUnknown = 2;
            static /*ReadOnlySpan<uint> */ get ColorValueTable()
            {
                return this.$cacheColorValueTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4292137160, 4278211811, 4294967295, 4286611584, 4293716440, 4289505433, 4285624164, 4294045666, 4294967295, 4278190080, 4278210200, 4289505433, 4281428677, 4294967295, 4278190208, 4292137160, 4286224095, 4292404472, 4294967265, 4278190080, 4294967295, 4278190080, 4292137160, 4294967295, 4278190080, 4278190080, 16777215, 4293982463, 4294634455, 4278255615, 4286578644, 4293984255, 4294309340, 4294960324, 4278190080, 4294962125, 4278190335, 4287245282, 4289014314, 4292786311, 4284456608, 4286578432, 4291979550, 4294934352, 4284782061, 4294965468, 4292613180, 4278255615, 4278190219, 4278225803, 4290283019, 4289309097, 4278215680, 4290623339, 4287299723, 4283788079, 4294937600, 4288230092, 4287299584, 4293498490, 4287609999, 4282924427, 4281290575, 4278243025, 4287889619, 4294907027, 4278239231, 4285098345, 4280193279, 4289864226, 4294966000, 4280453922, 4294902015, 4292664540, 4294506751, 4294956800, 4292519200, 4286611584, 4278222848, 4289593135, 4293984240, 4294928820, 4291648604, 4283105410, 4294967280, 4293977740, 4293322490, 4294963445, 4286381056, 4294965965, 4289583334, 4293951616, 4292935679, 4294638290, 4292072403, 4287688336, 4294948545, 4294942842, 4280332970, 4287090426, 4286023833, 4289774814, 4294967264, 4278255360, 4281519410, 4294635750, 4294902015, 4286578688, 4284927402, 4278190285, 4290401747, 4287852763, 4282168177, 4286277870, 4278254234, 4282962380, 4291237253, 4279834992, 4294311930, 4294960353, 4294960309, 4294958765, 4278190208, 4294833638, 4286611456, 4285238819, 4294944000, 4294919424, 4292505814, 4293847210, 4288215960, 4289720046, 4292571283, 4294963157, 4294957753, 4291659071, 4294951115, 4292714717, 4289781990, 4286578816, 4294901760, 4290547599, 4282477025, 4287317267, 4294606962, 4294222944, 4281240407, 4294964718, 4288696877, 4290822336, 4287090411, 4285160141, 4285563024, 4294966010, 4278255487, 4282811060, 4291998860, 4278222976, 4292394968, 4294927175, 4282441936, 4293821166, 4294303411, 4294967295, 4294309365, 4294967040, 4288335154, 4293980400, 4294967295, 4288716960, 4290367978, 4292338930, 4293980400, 4281571839, 4284887961 ]);
            }
            static /*ReadOnlySpan<byte> */ get ColorKindTable()
            {
                return this.$cacheColorKindTable ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 2/*KnownColorKindUnknown*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 1/*KnownColorKindWeb*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 0/*KnownColorKindSystem*/, 1/*KnownColorKindWeb*/ ]);
            }
            static /*ReadOnlySpan<uint> */ get AlternateSystemColors()
            {
                return this.$cacheAlternateSystemColors ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32))().$ctor$2([ 0, 4282795590, 4282146680, 4294967295, 4282137660, 4280295456, 4283058762, 4284111450, 4281216558, 4280229663, 4294967295, 4279242768, 4288059030, 4280837300, 4278190080, 4281163695, 4282138433, 4281813850, 4290690750, 4283453500, 4290690750, 4281808695, 4293980400, 4283453520, 4281479730, 4280821800, 4293980400, 4280295456, 4279242768, 4282795590, 4282475650, 4283790230, 4281808695, 4280975570 ]);
            }
            static /*Color */ ArgbToKnownColor(/*uint*/ argb)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((argb & 4278190080/*Color.ARGBAlphaMask*/) === 4278190080/*Color.ARGBAlphaMask*/, "(argb & Color.ARGBAlphaMask) == Color.ARGBAlphaMask");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.KnownColorTable.ColorValueTable.Length === $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.Length, "ColorValueTable.Length == ColorKindTable.Length");
                /*ReadOnlySpan<uint>*/ let colorValueTable = $.$sdp.System.Drawing.KnownColorTable.ColorValueTable;
                for(/*int*/ let index = 1; index < colorValueTable.Length; ++index)
                {
                    if ($.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(index).$v === 1/*KnownColorKindWeb*/ && colorValueTable.get_Item(index).$v === argb)
                    {
                        return $.$sdp.System.Drawing.Color.FromKnownColor($.$cast(index, $.$sdp.System.Drawing.KnownColor));
                    }
                }
                return $.$sdp.System.Drawing.Color.FromArgb$1((argb | 0));
            }
            static /*uint */ KnownColorToArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(color > 0 && color <= 175/*KnownColor.RebeccaPurple*/, "color > 0 && color <= KnownColor.RebeccaPurple");
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(color).$v === 0/*KnownColorKindSystem*/ ? $.$sdp.System.Drawing.KnownColorTable.GetSystemColorArgb(color) : $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v;
            }
            static /*uint */ GetAlternateSystemColorArgb(/*KnownColor*/ color)
            {
                /*int*/ let index = color <= 26/*KnownColor.WindowText*/ ? color : ((((((color - 168/*KnownColor.ButtonFace*/) | 0) + 26/*KnownColor.WindowText*/) | 0) + 1) | 0);
                return $.$sdp.System.Drawing.KnownColorTable.AlternateSystemColors.get_Item(index).$v;
            }
            static /*uint */ GetSystemColorArgb(/*KnownColor*/ color)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$sdp.System.Drawing.Color.IsKnownColorSystem(color), "Color.IsKnownColorSystem(color)");
                return (!$.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet) ? $.$sdp.System.Drawing.KnownColorTable.ColorValueTable.get_Item(color).$v : $.$sdp.System.Drawing.KnownColorTable.GetAlternateSystemColorArgb(color);
            }
            static $h = 509627;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":21475346107,"f":33},"n":"ColorValueTable","d":509627,"h":17180378811,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":30065280699,"f":33},"n":"ColorKindTable","d":509627,"h":25770313403,"f":33},{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt32).$h,"g":{"r":0,"d":0,"h":38655215291,"f":34},"n":"AlternateSystemColors","d":509627,"h":34360247995,"f":34}],"m":[{"r":116411,"p":[{"n":"argb","p":720897}],"n":"ArgbToKnownColor","d":509627,"h":42950182587,"f":40},{"r":720897,"p":[{"n":"color","p":378555}],"n":"KnownColorToArgb","d":509627,"h":47245149883,"f":33},{"r":720897,"p":[{"n":"color","p":378555}],"n":"GetAlternateSystemColorArgb","d":509627,"h":51540117179,"f":34},{"r":720897,"p":[{"n":"color","p":378555}],"n":"GetSystemColorArgb","d":509627,"h":55835084475,"f":33}],"l":[{"t":393217,"n":"KnownColorKindSystem","d":509627,"h":4295476923,"f":33},{"t":393217,"n":"KnownColorKindWeb","d":509627,"h":8590444219,"f":33},{"t":393217,"n":"KnownColorKindUnknown","d":509627,"h":12885411515,"f":33}],"h":509627}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.KnownColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTranslator", ($self) => class ColorTranslator
        {
            /*int*/ static COLORREF_RedShift = 0;
            /*int*/ static COLORREF_GreenShift = 8;
            /*int*/ static COLORREF_BlueShift = 16;
            /*int*/ static OleSystemColorFlag = -2147483648;
            /*Dictionary<string, Color>?*/ static s_htmlSysColorTable = null;
            static /*uint */ COLORREFToARGB(/*uint*/ value)
            {
                return (((value >>> 0/*COLORREF_RedShift*/) & 255) << 16/*Color.ARGBRedShift*/) >>> 0 | (((value >>> 8/*COLORREF_GreenShift*/) & 255) << 8/*Color.ARGBGreenShift*/) >>> 0 | (((value >>> 16/*COLORREF_BlueShift*/) & 255) << 0/*Color.ARGBBlueShift*/) >>> 0 | 4278190080/*Color.ARGBAlphaMask*/;
            }
            static /*int */ ToWin32(/*Color*/ c)
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                return r << 0/*COLORREF_RedShift*/ | g << 8/*COLORREF_GreenShift*/ | b << 16/*COLORREF_BlueShift*/;
            }
            static /*int */ ToOle(/*Color*/ c)
            {
                if (c.IsKnownColor && c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        return (2147483658 | 0);
                        case 2/*KnownColor.ActiveCaption*/:
                        return (2147483650 | 0);
                        case 3/*KnownColor.ActiveCaptionText*/:
                        return (2147483657 | 0);
                        case 4/*KnownColor.AppWorkspace*/:
                        return (2147483660 | 0);
                        case 168/*KnownColor.ButtonFace*/:
                        return (2147483663 | 0);
                        case 169/*KnownColor.ButtonHighlight*/:
                        return (2147483668 | 0);
                        case 170/*KnownColor.ButtonShadow*/:
                        return (2147483664 | 0);
                        case 5/*KnownColor.Control*/:
                        return (2147483663 | 0);
                        case 6/*KnownColor.ControlDark*/:
                        return (2147483664 | 0);
                        case 7/*KnownColor.ControlDarkDark*/:
                        return (2147483669 | 0);
                        case 8/*KnownColor.ControlLight*/:
                        return (2147483670 | 0);
                        case 9/*KnownColor.ControlLightLight*/:
                        return (2147483668 | 0);
                        case 10/*KnownColor.ControlText*/:
                        return (2147483666 | 0);
                        case 11/*KnownColor.Desktop*/:
                        return (2147483649 | 0);
                        case 171/*KnownColor.GradientActiveCaption*/:
                        return (2147483675 | 0);
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        return (2147483676 | 0);
                        case 12/*KnownColor.GrayText*/:
                        return (2147483665 | 0);
                        case 13/*KnownColor.Highlight*/:
                        return (2147483661 | 0);
                        case 14/*KnownColor.HighlightText*/:
                        return (2147483662 | 0);
                        case 15/*KnownColor.HotTrack*/:
                        return (2147483674 | 0);
                        case 16/*KnownColor.InactiveBorder*/:
                        return (2147483659 | 0);
                        case 17/*KnownColor.InactiveCaption*/:
                        return (2147483651 | 0);
                        case 18/*KnownColor.InactiveCaptionText*/:
                        return (2147483667 | 0);
                        case 19/*KnownColor.Info*/:
                        return (2147483672 | 0);
                        case 20/*KnownColor.InfoText*/:
                        return (2147483671 | 0);
                        case 21/*KnownColor.Menu*/:
                        return (2147483652 | 0);
                        case 173/*KnownColor.MenuBar*/:
                        return (2147483678 | 0);
                        case 174/*KnownColor.MenuHighlight*/:
                        return (2147483677 | 0);
                        case 22/*KnownColor.MenuText*/:
                        return (2147483655 | 0);
                        case 23/*KnownColor.ScrollBar*/:
                        return (2147483648 | 0);
                        case 24/*KnownColor.Window*/:
                        return (2147483653 | 0);
                        case 25/*KnownColor.WindowFrame*/:
                        return (2147483654 | 0);
                        case 26/*KnownColor.WindowText*/:
                        return (2147483656 | 0);
                    }
                }
                return $.$sdp.System.Drawing.ColorTranslator.ToWin32(c);
            }
            static /*Color */ FromOle(/*int*/ oleColor)
            {
                if ((oleColor & -2147483648/*OleSystemColorFlag*/) !== 0)
                {
                    switch(oleColor)
                    {
                        case (2147483658 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
                        case (2147483650 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
                        case (2147483657 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
                        case (2147483660 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
                        case (2147483663 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
                        case (2147483664 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
                        case (2147483669 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
                        case (2147483670 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
                        case (2147483668 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
                        case (2147483666 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
                        case (2147483649 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
                        case (2147483675 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
                        case (2147483676 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
                        case (2147483665 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
                        case (2147483661 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
                        case (2147483662 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
                        case (2147483674 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
                        case (2147483659 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
                        case (2147483651 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
                        case (2147483667 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
                        case (2147483672 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
                        case (2147483671 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
                        case (2147483652 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
                        case (2147483678 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
                        case (2147483677 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
                        case (2147483655 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
                        case (2147483648 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
                        case (2147483653 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
                        case (2147483654 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
                        case (2147483656 | 0):
                        return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
                    }
                }
                return $.$sdp.System.Drawing.KnownColorTable.ArgbToKnownColor($.$sdp.System.Drawing.ColorTranslator.COLORREFToARGB((oleColor >>> 0)));
            }
            static /*Color */ FromWin32(/*int*/ win32Color)
            {
                return $.$sdp.System.Drawing.ColorTranslator.FromOle(win32Color);
            }
            static /*Color */ FromHtml(/*string*/ htmlColor)
            {
                /*Color*/ let c = $.$sdp.System.Drawing.Color.Empty;
                if (($.$spc.System.String.op_Equality(htmlColor, null)) || (htmlColor.length === 0))
                {
                    return c;
                }
                if (($.$spc.System.String.get_Chars.call(htmlColor, 0) === /*#*/ 35) && ((htmlColor.length === 7) || (htmlColor.length === 4)))
                {
                    if (htmlColor.length === 7)
                    {
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 1, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 3, 2), 16), $.$spc.System.Convert.ToInt32$18($.$spc.System.String.Substring$1.call(htmlColor, 5, 2), 16));
                    }
                    else 
                    {
                        /*string*/ let r = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 1));
                        /*string*/ let g = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 2));
                        /*string*/ let b = $.$spc.System.Char.ToString$2($.$spc.System.String.get_Chars.call(htmlColor, 3));
                        c = $.$sdp.System.Drawing.Color.FromArgb$4($.$spc.System.Convert.ToInt32$18(r + r, 16), $.$spc.System.Convert.ToInt32$18(g + g, 16), $.$spc.System.Convert.ToInt32$18(b + b, 16));
                    }
                }
                if (c.IsEmpty && $.$spc.System.String.Equals$5(htmlColor, "LightGrey", 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    c = $.$sdp.System.Drawing.Color.LightGray;
                }
                if (c.IsEmpty)
                {
                    if ($.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable === null)
                    {
                        $.$sdp.System.Drawing.ColorTranslator.InitializeHtmlSysColorTable();
                    }
                    $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable.TryGetValue($.$spc.System.String.ToLowerInvariant.call(htmlColor), $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color));
                }
                if (c.IsEmpty)
                {
                    try
                    {
                        c = $.$sdp.System.Drawing.ColorConverterCommon.ConvertFromString(htmlColor, $.$spc.System.Globalization.CultureInfo.CurrentCulture);
                    }
                    catch(ex)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$12(ex.Message, "htmlColor", ex);
                    }
                }
                return c;
            }
            static /*string */ ToHtml(/*Color*/ c)
            {
                /*string*/ let colorString = $.$spc.System.String.Empty;
                if (c.IsEmpty)
                {
                    return colorString;
                }
                if (c.IsSystemColor)
                {
                    let $switch1 = c.ToKnownColor();
                    switch($switch1)
                    {
                        case 1/*KnownColor.ActiveBorder*/:
                        colorString = "activeborder";
                        break;
                        case 171/*KnownColor.GradientActiveCaption*/:
                        case 2/*KnownColor.ActiveCaption*/:
                        colorString = "activecaption";
                        break;
                        case 4/*KnownColor.AppWorkspace*/:
                        colorString = "appworkspace";
                        break;
                        case 11/*KnownColor.Desktop*/:
                        colorString = "background";
                        break;
                        case 5/*KnownColor.Control*/:
                        case 8/*KnownColor.ControlLight*/:
                        colorString = "buttonface";
                        break;
                        case 6/*KnownColor.ControlDark*/:
                        colorString = "buttonshadow";
                        break;
                        case 10/*KnownColor.ControlText*/:
                        colorString = "buttontext";
                        break;
                        case 3/*KnownColor.ActiveCaptionText*/:
                        colorString = "captiontext";
                        break;
                        case 12/*KnownColor.GrayText*/:
                        colorString = "graytext";
                        break;
                        case 15/*KnownColor.HotTrack*/:
                        case 13/*KnownColor.Highlight*/:
                        colorString = "highlight";
                        break;
                        case 174/*KnownColor.MenuHighlight*/:
                        case 14/*KnownColor.HighlightText*/:
                        colorString = "highlighttext";
                        break;
                        case 16/*KnownColor.InactiveBorder*/:
                        colorString = "inactiveborder";
                        break;
                        case 172/*KnownColor.GradientInactiveCaption*/:
                        case 17/*KnownColor.InactiveCaption*/:
                        colorString = "inactivecaption";
                        break;
                        case 18/*KnownColor.InactiveCaptionText*/:
                        colorString = "inactivecaptiontext";
                        break;
                        case 19/*KnownColor.Info*/:
                        colorString = "infobackground";
                        break;
                        case 20/*KnownColor.InfoText*/:
                        colorString = "infotext";
                        break;
                        case 173/*KnownColor.MenuBar*/:
                        case 21/*KnownColor.Menu*/:
                        colorString = "menu";
                        break;
                        case 22/*KnownColor.MenuText*/:
                        colorString = "menutext";
                        break;
                        case 23/*KnownColor.ScrollBar*/:
                        colorString = "scrollbar";
                        break;
                        case 7/*KnownColor.ControlDarkDark*/:
                        colorString = "threeddarkshadow";
                        break;
                        case 9/*KnownColor.ControlLightLight*/:
                        colorString = "buttonhighlight";
                        break;
                        case 24/*KnownColor.Window*/:
                        colorString = "window";
                        break;
                        case 25/*KnownColor.WindowFrame*/:
                        colorString = "windowframe";
                        break;
                        case 26/*KnownColor.WindowText*/:
                        colorString = "windowtext";
                        break;
                    }
                }
                else if (c.IsNamedColor)
                {
                    if ($.$sdp.System.Drawing.Color.op_Equality(c, $.$sdp.System.Drawing.Color.LightGray))
                    {
                        colorString = "LightGrey";
                    }
                    else 
                    {
                        colorString = c.Name;
                    }
                }
                else 
                {
                    /*int*/ let r;
                    /*int*/ let g;
                    /*int*/ let b;
                    c.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                    colorString = (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 3);
                        $handler.AppendLiteral("#");
                        $handler.AppendFormatted$8($.$box(r, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(g, $.$spc.System.Int32), null, "X2");
                        $handler.AppendFormatted$8($.$box(b, $.$spc.System.Int32), null, "X2");
                        return $handler.ToStringAndClear();
                    })();
                }
                return colorString;
            }
            static /*void */ InitializeHtmlSysColorTable()
            {
                $.$sdp.System.Drawing.ColorTranslator.s_htmlSysColorTable = (() =>
                {
                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)()
                    const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color);
                    const $i1 = new $t1();
                    $i1.$ctor$2(27);
                    $i1.Add("activeborder", $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/));
                    $i1.Add("activecaption", $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/));
                    $i1.Add("appworkspace", $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/));
                    $i1.Add("background", $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/));
                    $i1.Add("buttonface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("buttonhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("buttonshadow", $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/));
                    $i1.Add("buttontext", $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/));
                    $i1.Add("captiontext", $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/));
                    $i1.Add("graytext", $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/));
                    $i1.Add("highlight", $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/));
                    $i1.Add("highlighttext", $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/));
                    $i1.Add("inactiveborder", $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/));
                    $i1.Add("inactivecaption", $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/));
                    $i1.Add("inactivecaptiontext", $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/));
                    $i1.Add("infobackground", $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/));
                    $i1.Add("infotext", $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/));
                    $i1.Add("menu", $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/));
                    $i1.Add("menutext", $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/));
                    $i1.Add("scrollbar", $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/));
                    $i1.Add("threeddarkshadow", $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/));
                    $i1.Add("threedface", $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/));
                    $i1.Add("threedhighlight", $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/));
                    $i1.Add("threedlightshadow", $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/));
                    $i1.Add("window", $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/));
                    $i1.Add("windowframe", $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/));
                    $i1.Add("windowtext", $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/));
                    return $i1;
                })();
            }
            static $h = 313019;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"value","p":720897}],"n":"COLORREFToARGB","d":313019,"h":25770116795,"f":40},{"r":655361,"p":[{"n":"c","p":116411}],"n":"ToWin32","d":313019,"h":30065084091,"f":33},{"r":655361,"p":[{"n":"c","p":116411}],"n":"ToOle","d":313019,"h":34360051387,"f":33},{"r":116411,"p":[{"n":"oleColor","p":655361}],"n":"FromOle","d":313019,"h":38655018683,"f":33},{"r":116411,"p":[{"n":"win32Color","p":655361}],"n":"FromWin32","d":313019,"h":42949985979,"f":33},{"r":116411,"p":[{"n":"htmlColor","p":1310721}],"n":"FromHtml","d":313019,"h":47244953275,"f":33},{"r":1310721,"p":[{"n":"c","p":116411}],"n":"ToHtml","d":313019,"h":51539920571,"f":33},{"r":65537,"n":"InitializeHtmlSysColorTable","d":313019,"h":55834887867,"f":34}],"l":[{"t":655361,"n":"COLORREF_RedShift","d":313019,"h":4295280315,"f":40},{"t":655361,"n":"COLORREF_GreenShift","d":313019,"h":8590247611,"f":40},{"t":655361,"n":"COLORREF_BlueShift","d":313019,"h":12885214907,"f":40},{"t":655361,"n":"OleSystemColorFlag","d":313019,"h":17180182203,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"s_htmlSysColorTable","d":313019,"h":21475149499,"f":34}],"h":313019}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTranslator`; }
        });
        
        $asm.$cls("$sdp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sdp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Drawing.Primitives", $.$sdp.System.SR.$type.Assembly);
                    $.$sdp.System.SR.s_resourceManager = temp;
                }
                return $.$sdp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sdp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sdp.System.SR.resourceCulture = value;
            }
            static /*string */ get ConvertInvalidPrimitive()
            {
                return "{0} is not a valid value for {1}.";
            }
            static /*string */ FormatConvertInvalidPrimitive(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("{0} is not a valid value for {1}.", arg1, arg2);
            }
            static /*string */ get InvalidColor()
            {
                return "Color '{0}' is not valid.";
            }
            static /*string */ FormatInvalidColor(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Color '{0}' is not valid.", arg1);
            }
            static /*string */ get InvalidEx2BoundArgument()
            {
                return "Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.";
            }
            static /*string */ FormatInvalidEx2BoundArgument(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3, /*object*/ arg4, /*object*/ arg5)
            {
                return $.$spc.System.String.Format$4("Value of '{1}' is not valid for '{0}'. '{0}' should be greater than or equal to {2} and less than or equal to {3}.", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ arg1, arg2, arg3, arg4, arg5 ]));
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sdp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sdp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sdp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sdp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sdp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sdp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1099451;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1099451}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sdp.System.Experimentals", ($self) => class Experimentals
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static TensorTDiagId = null;
            /*string*/ static SystemColorsDiagId = null;
            /*string*/ static ArmSveDiagId = null;
            /*string*/ static X86BaseDivRemDiagId = null;
            /*string*/ static PostQuantumCryptographyDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.TensorTDiagId = "SYSLIB5001";
                }
                {
                    this.SystemColorsDiagId = "SYSLIB5002";
                }
                {
                    this.ArmSveDiagId = "SYSLIB5003";
                }
                {
                    this.X86BaseDivRemDiagId = "SYSLIB5004";
                }
                {
                    this.PostQuantumCryptographyDiagId = "SYSLIB5006";
                }
            }
            static $h = 1033915;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":1033915,"h":4296001211,"f":40},{"t":1310721,"n":"TensorTDiagId","d":1033915,"h":8590968507,"f":40},{"t":1310721,"n":"SystemColorsDiagId","d":1033915,"h":12885935803,"f":40},{"t":1310721,"n":"ArmSveDiagId","d":1033915,"h":17180903099,"f":40},{"t":1310721,"n":"X86BaseDivRemDiagId","d":1033915,"h":21475870395,"f":40},{"t":1310721,"n":"PostQuantumCryptographyDiagId","d":1033915,"h":25770837691,"f":40}],"h":1033915}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Experimentals`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.SystemColors", ($self) => class SystemColors
        {
            /*bool*/ static s_useAlternativeColorSet = false;
            static /*Color */ get ActiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(1/*KnownColor.ActiveBorder*/);
            }
            static /*Color */ get ActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(2/*KnownColor.ActiveCaption*/);
            }
            static /*Color */ get ActiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(3/*KnownColor.ActiveCaptionText*/);
            }
            static /*Color */ get AppWorkspace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(4/*KnownColor.AppWorkspace*/);
            }
            static /*Color */ get ButtonFace()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(168/*KnownColor.ButtonFace*/);
            }
            static /*Color */ get ButtonHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(169/*KnownColor.ButtonHighlight*/);
            }
            static /*Color */ get ButtonShadow()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(170/*KnownColor.ButtonShadow*/);
            }
            static /*Color */ get Control()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(5/*KnownColor.Control*/);
            }
            static /*Color */ get ControlDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(6/*KnownColor.ControlDark*/);
            }
            static /*Color */ get ControlDarkDark()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(7/*KnownColor.ControlDarkDark*/);
            }
            static /*Color */ get ControlLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(8/*KnownColor.ControlLight*/);
            }
            static /*Color */ get ControlLightLight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(9/*KnownColor.ControlLightLight*/);
            }
            static /*Color */ get ControlText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(10/*KnownColor.ControlText*/);
            }
            static /*Color */ get Desktop()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(11/*KnownColor.Desktop*/);
            }
            static /*Color */ get GradientActiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(171/*KnownColor.GradientActiveCaption*/);
            }
            static /*Color */ get GradientInactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(172/*KnownColor.GradientInactiveCaption*/);
            }
            static /*Color */ get GrayText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(12/*KnownColor.GrayText*/);
            }
            static /*Color */ get Highlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(13/*KnownColor.Highlight*/);
            }
            static /*Color */ get HighlightText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(14/*KnownColor.HighlightText*/);
            }
            static /*Color */ get HotTrack()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(15/*KnownColor.HotTrack*/);
            }
            static /*Color */ get InactiveBorder()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(16/*KnownColor.InactiveBorder*/);
            }
            static /*Color */ get InactiveCaption()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(17/*KnownColor.InactiveCaption*/);
            }
            static /*Color */ get InactiveCaptionText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(18/*KnownColor.InactiveCaptionText*/);
            }
            static /*Color */ get Info()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(19/*KnownColor.Info*/);
            }
            static /*Color */ get InfoText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(20/*KnownColor.InfoText*/);
            }
            static /*Color */ get Menu()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(21/*KnownColor.Menu*/);
            }
            static /*Color */ get MenuBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(173/*KnownColor.MenuBar*/);
            }
            static /*Color */ get MenuHighlight()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(174/*KnownColor.MenuHighlight*/);
            }
            static /*Color */ get MenuText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(22/*KnownColor.MenuText*/);
            }
            static /*Color */ get ScrollBar()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(23/*KnownColor.ScrollBar*/);
            }
            static /*Color */ get Window()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(24/*KnownColor.Window*/);
            }
            static /*Color */ get WindowFrame()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(25/*KnownColor.WindowFrame*/);
            }
            static /*Color */ get WindowText()
            {
                return $.$sdp.System.Drawing.Color.FromKnownColor(26/*KnownColor.WindowText*/);
            }
            static /*bool */ get UseAlternativeColorSet()
            {
                return $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet;
            }
            static /*bool */ set UseAlternativeColorSet(value)
            {
                $.$sdp.System.Drawing.SystemColors.s_useAlternativeColorSet = value;
            }
            static $h = 968379;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":116411,"g":{"r":0,"d":0,"h":12885870267,"f":33},"n":"ActiveBorder","d":968379,"h":8590902971,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":21475804859,"f":33},"n":"ActiveCaption","d":968379,"h":17180837563,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":30065739451,"f":33},"n":"ActiveCaptionText","d":968379,"h":25770772155,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":38655674043,"f":33},"n":"AppWorkspace","d":968379,"h":34360706747,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":47245608635,"f":33},"n":"ButtonFace","d":968379,"h":42950641339,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":55835543227,"f":33},"n":"ButtonHighlight","d":968379,"h":51540575931,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":64425477819,"f":33},"n":"ButtonShadow","d":968379,"h":60130510523,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":73015412411,"f":33},"n":"Control","d":968379,"h":68720445115,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":81605347003,"f":33},"n":"ControlDark","d":968379,"h":77310379707,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":90195281595,"f":33},"n":"ControlDarkDark","d":968379,"h":85900314299,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":98785216187,"f":33},"n":"ControlLight","d":968379,"h":94490248891,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":107375150779,"f":33},"n":"ControlLightLight","d":968379,"h":103080183483,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":115965085371,"f":33},"n":"ControlText","d":968379,"h":111670118075,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":124555019963,"f":33},"n":"Desktop","d":968379,"h":120260052667,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":133144954555,"f":33},"n":"GradientActiveCaption","d":968379,"h":128849987259,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":141734889147,"f":33},"n":"GradientInactiveCaption","d":968379,"h":137439921851,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":150324823739,"f":33},"n":"GrayText","d":968379,"h":146029856443,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":158914758331,"f":33},"n":"Highlight","d":968379,"h":154619791035,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":167504692923,"f":33},"n":"HighlightText","d":968379,"h":163209725627,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":176094627515,"f":33},"n":"HotTrack","d":968379,"h":171799660219,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":184684562107,"f":33},"n":"InactiveBorder","d":968379,"h":180389594811,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":193274496699,"f":33},"n":"InactiveCaption","d":968379,"h":188979529403,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":201864431291,"f":33},"n":"InactiveCaptionText","d":968379,"h":197569463995,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":210454365883,"f":33},"n":"Info","d":968379,"h":206159398587,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":219044300475,"f":33},"n":"InfoText","d":968379,"h":214749333179,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":227634235067,"f":33},"n":"Menu","d":968379,"h":223339267771,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":236224169659,"f":33},"n":"MenuBar","d":968379,"h":231929202363,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":244814104251,"f":33},"n":"MenuHighlight","d":968379,"h":240519136955,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":253404038843,"f":33},"n":"MenuText","d":968379,"h":249109071547,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":261993973435,"f":33},"n":"ScrollBar","d":968379,"h":257699006139,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":270583908027,"f":33},"n":"Window","d":968379,"h":266288940731,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":279173842619,"f":33},"n":"WindowFrame","d":968379,"h":274878875323,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":287763777211,"f":33},"n":"WindowText","d":968379,"h":283468809915,"f":33},{"p":262145,"g":{"r":0,"d":0,"h":296353711803,"f":33},"s":{"r":0,"d":0,"h":300648679099,"f":33},"n":"UseAlternativeColorSet","d":968379,"h":292058744507,"f":33}],"l":[{"t":262145,"n":"s_useAlternativeColorSet","d":968379,"h":4295935675,"f":40}],"h":968379}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.SystemColors`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorTable", ($self) => class ColorTable
        {
            /*Lazy<Dictionary<string, Color>>*/ static s_colorConstants = null;
            static /*Dictionary<string, Color> */ GetColors()
            {
                /*var*/ let colors = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color))().$ctor$3($.$spc.System.StringComparer.OrdinalIgnoreCase);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.Color.$type);
                $.$sdp.System.Drawing.ColorTable.FillWithProperties(colors, $.$sdp.System.Drawing.SystemColors.$type);
                return colors;
            }
            static /*void */ FillWithProperties(/*Dictionary<string, Color>*/ dictionary, /*Type*/ typeWithColors)
            {
                let $i1 = 0;
                let $arr1 = typeWithColors.GetProperties$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                while ($i1 < $arr1.length)
                {
                    let prop = $arr1[$i1++];
                    if ($.$spc.System.Type.op_Equality$1(prop.PropertyType, $.$sdp.System.Drawing.Color.$type))
                    {
                        dictionary.set_Item(prop.Name, $.$cast(prop.GetValue$1(null, null), $.$sdp.System.Drawing.Color));
                    }
                }
            }
            static /*Dictionary<string, Color> */ get Colors()
            {
                return $.$sdp.System.Drawing.ColorTable.s_colorConstants.Value;
            }
            static /*bool */ TryGetNamedColor(/*string*/ name, /*out Color*/ result)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, result);
            }
            static /*bool */ IsKnownNamedColor(/*string*/ name)
            {
                return $.$sdp.System.Drawing.ColorTable.Colors.TryGetValue(name, $.$discardRef());
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_colorConstants = new ($.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor$3(new ($.$spc.System.Func$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)))().$ctor(null, $.$sdp.System.Drawing.ColorTable.GetColors));
                }
            }
            static $h = 247483;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"g":{"r":0,"d":0,"h":21475083963,"f":40},"n":"Colors","d":247483,"h":17180116667,"f":40}],"m":[{"r":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h,"n":"GetColors","d":247483,"h":8590182075,"f":34},{"r":65537,"p":[{"n":"dictionary","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color).$h},{"n":"typeWithColors","p":142606337}],"n":"FillWithProperties","d":247483,"h":12885149371,"f":34},{"r":262145,"p":[{"n":"name","p":1310721},{"n":"result","p":116411,"f":2}],"n":"TryGetNamedColor","d":247483,"h":25770051259,"f":40},{"r":262145,"p":[{"n":"name","p":1310721}],"n":"IsKnownNamedColor","d":247483,"h":30065018555,"f":40}],"l":[{"t":$.$spc.System.Lazy$$($.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.String, $.$sdp.System.Drawing.Color)).$h,"n":"s_colorConstants","d":247483,"h":4295214779,"f":34}],"h":247483}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorTable`; }
        });
        
        $asm.$cls("$sdp.System.Drawing.ColorConverterCommon", ($self) => class ColorConverterCommon
        {
            static /*Color */ ConvertFromString(/*string*/ strValue, /*CultureInfo*/ culture)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                /*string*/ let text = $.$spc.System.String.Trim.call(strValue);
                if (text.length === 0)
                {
                    return $.$sdp.System.Drawing.Color.Empty;
                }
                {
                    /*Color*/ let c;
                    if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(text, $.$ref(() => c, ($v) => c = $v, $.$sdp.System.Drawing.Color)))
                    {
                        return c;
                    }
                }
                /*char*/ let sep = $.$spc.System.String.get_Chars.call(culture.TextInfo.ListSeparator, 0);
                if (!$.$spc.System.String.Contains$2.call(text, sep))
                {
                    if (text.length >= 2 && ($.$spc.System.String.get_Chars.call(text, 0) === /*'*/ 39 || $.$spc.System.String.get_Chars.call(text, 0) === /*\"*/ 34) && $.$spc.System.String.get_Chars.call(text, 0) === $.$spc.System.String.get_Chars.call(text, ((text.length - 1) | 0)))
                    {
                        /*string*/ let colorName = $.$spc.System.String.Substring$1.call(text, 1, ((text.length - 2) | 0));
                        return $.$sdp.System.Drawing.Color.FromName(colorName);
                    }
                    else if ((text.length === 7 && $.$spc.System.String.get_Chars.call(text, 0) === /*#*/ 35) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "0x") || $.$spc.System.String.StartsWith.call(text, "0X"))) || (text.length === 8 && ($.$spc.System.String.StartsWith.call(text, "&h") || $.$spc.System.String.StartsWith.call(text, "&H"))))
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1(((4278190080 | ($.$sdp.System.Drawing.ColorConverterCommon.IntFromString($.$spc.System.String.op_Implicit(text), culture) >>> 0)) | 0)));
                    }
                }
                /*ReadOnlySpan<char>*/ let textSpan = $.$spc.System.String.op_Implicit(text);
                /*Span<Range>*/ let tokens = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Range, 5, null);
                return (() =>
                {
                    let $switch1 = $.$spc.System.MemoryExtensions.Split$2(textSpan, tokens, sep, 0);
                    if ($switch1 === 1)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$1($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture)));
                    }
                    if ($switch1 === 3)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$4($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture)));
                    }
                    if ($switch1 === 4)
                    {
                        return $.$sdp.System.Drawing.ColorConverterCommon.PossibleKnownColor($.$sdp.System.Drawing.Color.FromArgb$2($.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(0).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(1).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(2).$v], culture), $.$sdp.System.Drawing.ColorConverterCommon.IntFromString(textSpan[tokens.get_Item(3).$v], culture)));
                    }
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format($.$sdp.System.SR.InvalidColor, text));
                })();
            }
            static /*Color */ PossibleKnownColor(/*Color*/ color)
            {
                /*int*/ let targetARGB = color.ToArgb();
                var $en2 = $.$sdp.System.Drawing.ColorTable.Colors.Values.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if (c.ToArgb() === targetARGB)
                        {
                            return c;
                        }
                    }
                }
                return color;
            }
            static /*int */ IntFromString(/*ReadOnlySpan<char>*/ text, /*CultureInfo*/ culture)
            {
                text = $.$spc.System.MemoryExtensions.Trim$10(text);
                try
                {
                    if (text.get_Item(0).$v === /*#*/ 35)
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(1)), 16);
                    }
                    else if ($.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("0x"), 5/*StringComparison.OrdinalIgnoreCase*/) || $.$spc.System.MemoryExtensions.StartsWith$5(text, $.$spc.System.String.op_Implicit("&h"), 5/*StringComparison.OrdinalIgnoreCase*/))
                    {
                        return $.$spc.System.Convert.ToInt32$18($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text.Slice(2)), 16);
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(culture !== null, "culture != null");
                        /*var*/ let formatInfo = $.$cast(culture.GetFormat($.$spc.System.Globalization.NumberFormatInfo.$type), $.$spc.System.Globalization.NumberFormatInfo);
                        return $.$spc.System.Int32.Parse$5(text, formatInfo);
                    }
                }
                catch(e)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$11($.$sdp.System.SR.Format$1($.$sdp.System.SR.ConvertInvalidPrimitive, $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call(text), "Int32"), e);
                }
            }
            static $h = 181947;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":116411,"p":[{"n":"strValue","p":1310721},{"n":"culture","p":51118081}],"n":"ConvertFromString","d":181947,"h":4295149243,"f":33},{"r":116411,"p":[{"n":"color","p":116411}],"n":"PossibleKnownColor","d":181947,"h":8590116539,"f":34},{"r":655361,"p":[{"n":"text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"culture","p":51118081}],"n":"IntFromString","d":181947,"h":12885083835,"f":34}],"h":181947}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Drawing.ColorConverterCommon`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Size", ($self) => class Size extends $.$spc.System.ValueType
        {
            /*Size*/ static Empty;
            /*int*/  get width() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*Point*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$3(/*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*SizeF */ op_Implicit(/*Size*/ p)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(p.Width, p.Height);
            }
            static /*Size */ op_Addition(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Add(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Subtraction(/*Size*/ sz1, /*Size*/ sz2)
            {
                return $.$sdp.System.Drawing.Size.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*Size */ op_Multiply(/*int*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(right.Clone(), left);
            }
            static /*Size */ op_Multiply$1(/*Size*/ left, /*int*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply(left.Clone(), right);
            }
            static /*Size */ op_Division(/*Size*/ left, /*int*/ right)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.trunc(left.width / right), $.trunc(left.height / right));
            }
            static /*SizeF */ op_Multiply$2(/*float*/ left, /*Size*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$3(/*Size*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.Size.Multiply$1(left.Clone(), right);
            }
            static /*SizeF */ op_Division$1(/*Size*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*Size*/ sz1, /*Size*/ sz2)
            {
                return !($.$sdp.System.Drawing.Size.op_Equality(sz1, sz2));
            }
            static /*Point */ op_Explicit(/*Size*/ size)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            static /*Size */ Add(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width + sz2.Width) | 0), ((sz1.Height + sz2.Height) | 0));
            }
            static /*Size */ Ceiling(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
            }
            static /*Size */ Subtract(/*Size*/ sz1, /*Size*/ sz2)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((sz1.Width - sz2.Width) | 0), ((sz1.Height - sz2.Height) | 0));
            }
            static /*Size */ Truncate(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
            }
            static /*Size */ Round(/*SizeF*/ value)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3($.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Size) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Size));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Size.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Size*/ other)
            {
                return $.$sdp.System.Drawing.Size.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Size.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Size.ToString.apply(this, arguments); }
            static /*Size */ Multiply(/*Size*/ size, /*int*/ multiplier)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(((size.width * multiplier) | 0), ((size.height * multiplier) | 0));
            }
            static /*SizeF */ Multiply$1(/*Size*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Size>.Equals(System.Drawing.Size)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Size);
                }
            }
            static $h = 837307;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":81605215931,"f":1},"n":"IsEmpty","d":837307,"h":77310248635,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":90195150523,"f":1},"s":{"r":0,"d":0,"h":94490117819,"f":1},"n":"Width","d":837307,"h":85900183227,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103080052411,"f":1},"s":{"r":0,"d":0,"h":107375019707,"f":1},"n":"Height","d":837307,"h":98785085115,"f":1}],"m":[{"r":837307,"p":[{"n":"sz1","p":837307},{"n":"sz2","p":837307}],"n":"Add","d":837307,"h":111669987003,"f":33},{"r":837307,"p":[{"n":"value","p":902843}],"n":"Ceiling","d":837307,"h":115964954299,"f":33},{"r":837307,"p":[{"n":"sz1","p":837307},{"n":"sz2","p":837307}],"n":"Subtract","d":837307,"h":120259921595,"f":33},{"r":837307,"p":[{"n":"value","p":902843}],"n":"Truncate","d":837307,"h":124554888891,"f":33},{"r":837307,"p":[{"n":"value","p":902843}],"n":"Round","d":837307,"h":128849856187,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":837307,"h":133144823483,"f":32769},{"r":262145,"p":[{"n":"other","p":837307}],"n":"Equals","o":"@$2","d":837307,"h":137439790779,"f":1},{"r":655361,"n":"GetHashCode","d":837307,"h":141734758075,"f":32769},{"r":1310721,"n":"ToString","d":837307,"h":146029725371,"f":32769},{"r":837307,"p":[{"n":"size","p":837307},{"n":"multiplier","p":655361}],"n":"Multiply","d":837307,"h":150324692667,"f":34},{"r":902843,"p":[{"n":"size","p":837307},{"n":"multiplier","p":1114113}],"n":"Multiply","o":"@$1","d":837307,"h":154619659963,"f":34}],"l":[{"t":837307,"n":"Empty","d":837307,"h":4295804603,"f":33},{"t":655361,"n":"width","d":837307,"h":8590771899,"f":2},{"t":655361,"n":"height","d":837307,"h":12885739195,"f":2}],"c":[{"p":[{"n":"pt","p":575163}],"n":".ctor","o":"$ctor$2","d":837307,"h":17180706491,"f":1},{"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$3","d":837307,"h":21475673787,"f":1},{"n":".ctor","o":"$ctor$4","d":837307,"h":158914627259,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size).$h],"h":837307,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496742,"c":17181365926,"a":[{"v":"System.Drawing.SizeConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Size) ]; }
            static get $fullName() { return `System.Drawing.Size`; }
        });
        
        $asm.$str("$sdp.System.Drawing.PointF", ($self) => class PointF extends $.$spc.System.ValueType
        {
            /*PointF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.x, this.y);
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            static /*Vector2 */ op_Explicit(/*PointF*/ point)
            {
                return point.ToVector2();
            }
            static /*PointF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$3(vector.Clone());
            }
            static /*PointF */ op_Addition(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction(/*PointF*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Addition$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Add$1(pt.Clone(), sz.Clone());
            }
            static /*PointF */ op_Subtraction$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return $.$sdp.System.Drawing.PointF.Subtract$1(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*PointF*/ left, /*PointF*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*PointF*/ left, /*PointF*/ right)
            {
                return !($.$sdp.System.Drawing.PointF.op_Equality(left, right));
            }
            static /*PointF */ Add(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract(/*PointF*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static /*PointF */ Add$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X + sz.Width, pt.Y + sz.Height);
            }
            static /*PointF */ Subtract$1(/*PointF*/ pt, /*SizeF*/ sz)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(pt.X - sz.Width, pt.Y - sz.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.PointF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.PointF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.PointF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*PointF*/ other)
            {
                return $.$sdp.System.Drawing.PointF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Single.GetHashCode.call(this.X), $.$spc.System.Single.GetHashCode.call(this.Y));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.PointF.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.x}, Y=${this.y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.PointF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.PointF>.Equals(System.Drawing.PointF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.PointF);
                }
            }
            static $h = 640699;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360379067,"f":1},"n":"IsEmpty","d":640699,"h":30065411771,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":42950313659,"f":1},"s":{"r":0,"d":0,"h":47245280955,"f":1},"n":"X","d":640699,"h":38655346363,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":55835215547,"f":1},"s":{"r":0,"d":0,"h":60130182843,"f":1},"n":"Y","d":640699,"h":51540248251,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":640699,"h":25770444475,"f":1},{"r":640699,"p":[{"n":"pt","p":640699},{"n":"sz","p":837307}],"n":"Add","d":640699,"h":98784888507,"f":33},{"r":640699,"p":[{"n":"pt","p":640699},{"n":"sz","p":837307}],"n":"Subtract","d":640699,"h":103079855803,"f":33},{"r":640699,"p":[{"n":"pt","p":640699},{"n":"sz","p":902843}],"n":"Add","o":"@$1","d":640699,"h":107374823099,"f":33},{"r":640699,"p":[{"n":"pt","p":640699},{"n":"sz","p":902843}],"n":"Subtract","o":"@$1","d":640699,"h":111669790395,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":640699,"h":115964757691,"f":32769},{"r":262145,"p":[{"n":"other","p":640699}],"n":"Equals","o":"@$2","d":640699,"h":120259724987,"f":1},{"r":655361,"n":"GetHashCode","d":640699,"h":124554692283,"f":32769},{"r":1310721,"n":"ToString","d":640699,"h":128849659579,"f":32769}],"l":[{"t":640699,"n":"Empty","d":640699,"h":4295607995,"f":33},{"t":1114113,"n":"x","d":640699,"h":8590575291,"f":2},{"t":1114113,"n":"y","d":640699,"h":12885542587,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":".ctor","o":"$ctor$2","d":640699,"h":17180509883,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$3","d":640699,"h":21475477179,"f":1},{"n":".ctor","o":"$ctor$4","d":640699,"h":133144626875,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF).$h],"h":640699,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.PointF) ]; }
            static get $fullName() { return `System.Drawing.PointF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Color", ($self) => class Color extends $.$spc.System.ValueType
        {
            /*Color*/ static Empty;
            static /*Color */ get Transparent()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(27/*KnownColor.Transparent*/);
            }
            static /*Color */ get AliceBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(28/*KnownColor.AliceBlue*/);
            }
            static /*Color */ get AntiqueWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(29/*KnownColor.AntiqueWhite*/);
            }
            static /*Color */ get Aqua()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(30/*KnownColor.Aqua*/);
            }
            static /*Color */ get Aquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(31/*KnownColor.Aquamarine*/);
            }
            static /*Color */ get Azure()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(32/*KnownColor.Azure*/);
            }
            static /*Color */ get Beige()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(33/*KnownColor.Beige*/);
            }
            static /*Color */ get Bisque()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(34/*KnownColor.Bisque*/);
            }
            static /*Color */ get Black()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(35/*KnownColor.Black*/);
            }
            static /*Color */ get BlanchedAlmond()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(36/*KnownColor.BlanchedAlmond*/);
            }
            static /*Color */ get Blue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(37/*KnownColor.Blue*/);
            }
            static /*Color */ get BlueViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(38/*KnownColor.BlueViolet*/);
            }
            static /*Color */ get Brown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(39/*KnownColor.Brown*/);
            }
            static /*Color */ get BurlyWood()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(40/*KnownColor.BurlyWood*/);
            }
            static /*Color */ get CadetBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(41/*KnownColor.CadetBlue*/);
            }
            static /*Color */ get Chartreuse()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(42/*KnownColor.Chartreuse*/);
            }
            static /*Color */ get Chocolate()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(43/*KnownColor.Chocolate*/);
            }
            static /*Color */ get Coral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(44/*KnownColor.Coral*/);
            }
            static /*Color */ get CornflowerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(45/*KnownColor.CornflowerBlue*/);
            }
            static /*Color */ get Cornsilk()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(46/*KnownColor.Cornsilk*/);
            }
            static /*Color */ get Crimson()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(47/*KnownColor.Crimson*/);
            }
            static /*Color */ get Cyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(48/*KnownColor.Cyan*/);
            }
            static /*Color */ get DarkBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(49/*KnownColor.DarkBlue*/);
            }
            static /*Color */ get DarkCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(50/*KnownColor.DarkCyan*/);
            }
            static /*Color */ get DarkGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(51/*KnownColor.DarkGoldenrod*/);
            }
            static /*Color */ get DarkGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(52/*KnownColor.DarkGray*/);
            }
            static /*Color */ get DarkGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(53/*KnownColor.DarkGreen*/);
            }
            static /*Color */ get DarkKhaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(54/*KnownColor.DarkKhaki*/);
            }
            static /*Color */ get DarkMagenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(55/*KnownColor.DarkMagenta*/);
            }
            static /*Color */ get DarkOliveGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(56/*KnownColor.DarkOliveGreen*/);
            }
            static /*Color */ get DarkOrange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(57/*KnownColor.DarkOrange*/);
            }
            static /*Color */ get DarkOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(58/*KnownColor.DarkOrchid*/);
            }
            static /*Color */ get DarkRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(59/*KnownColor.DarkRed*/);
            }
            static /*Color */ get DarkSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(60/*KnownColor.DarkSalmon*/);
            }
            static /*Color */ get DarkSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(61/*KnownColor.DarkSeaGreen*/);
            }
            static /*Color */ get DarkSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(62/*KnownColor.DarkSlateBlue*/);
            }
            static /*Color */ get DarkSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(63/*KnownColor.DarkSlateGray*/);
            }
            static /*Color */ get DarkTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(64/*KnownColor.DarkTurquoise*/);
            }
            static /*Color */ get DarkViolet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(65/*KnownColor.DarkViolet*/);
            }
            static /*Color */ get DeepPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(66/*KnownColor.DeepPink*/);
            }
            static /*Color */ get DeepSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(67/*KnownColor.DeepSkyBlue*/);
            }
            static /*Color */ get DimGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(68/*KnownColor.DimGray*/);
            }
            static /*Color */ get DodgerBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(69/*KnownColor.DodgerBlue*/);
            }
            static /*Color */ get Firebrick()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(70/*KnownColor.Firebrick*/);
            }
            static /*Color */ get FloralWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(71/*KnownColor.FloralWhite*/);
            }
            static /*Color */ get ForestGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(72/*KnownColor.ForestGreen*/);
            }
            static /*Color */ get Fuchsia()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(73/*KnownColor.Fuchsia*/);
            }
            static /*Color */ get Gainsboro()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(74/*KnownColor.Gainsboro*/);
            }
            static /*Color */ get GhostWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(75/*KnownColor.GhostWhite*/);
            }
            static /*Color */ get Gold()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(76/*KnownColor.Gold*/);
            }
            static /*Color */ get Goldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(77/*KnownColor.Goldenrod*/);
            }
            static /*Color */ get Gray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(78/*KnownColor.Gray*/);
            }
            static /*Color */ get Green()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(79/*KnownColor.Green*/);
            }
            static /*Color */ get GreenYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(80/*KnownColor.GreenYellow*/);
            }
            static /*Color */ get Honeydew()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(81/*KnownColor.Honeydew*/);
            }
            static /*Color */ get HotPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(82/*KnownColor.HotPink*/);
            }
            static /*Color */ get IndianRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(83/*KnownColor.IndianRed*/);
            }
            static /*Color */ get Indigo()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(84/*KnownColor.Indigo*/);
            }
            static /*Color */ get Ivory()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(85/*KnownColor.Ivory*/);
            }
            static /*Color */ get Khaki()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(86/*KnownColor.Khaki*/);
            }
            static /*Color */ get Lavender()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(87/*KnownColor.Lavender*/);
            }
            static /*Color */ get LavenderBlush()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(88/*KnownColor.LavenderBlush*/);
            }
            static /*Color */ get LawnGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(89/*KnownColor.LawnGreen*/);
            }
            static /*Color */ get LemonChiffon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(90/*KnownColor.LemonChiffon*/);
            }
            static /*Color */ get LightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(91/*KnownColor.LightBlue*/);
            }
            static /*Color */ get LightCoral()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(92/*KnownColor.LightCoral*/);
            }
            static /*Color */ get LightCyan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(93/*KnownColor.LightCyan*/);
            }
            static /*Color */ get LightGoldenrodYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(94/*KnownColor.LightGoldenrodYellow*/);
            }
            static /*Color */ get LightGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(96/*KnownColor.LightGreen*/);
            }
            static /*Color */ get LightGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(95/*KnownColor.LightGray*/);
            }
            static /*Color */ get LightPink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(97/*KnownColor.LightPink*/);
            }
            static /*Color */ get LightSalmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(98/*KnownColor.LightSalmon*/);
            }
            static /*Color */ get LightSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(99/*KnownColor.LightSeaGreen*/);
            }
            static /*Color */ get LightSkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(100/*KnownColor.LightSkyBlue*/);
            }
            static /*Color */ get LightSlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(101/*KnownColor.LightSlateGray*/);
            }
            static /*Color */ get LightSteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(102/*KnownColor.LightSteelBlue*/);
            }
            static /*Color */ get LightYellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(103/*KnownColor.LightYellow*/);
            }
            static /*Color */ get Lime()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(104/*KnownColor.Lime*/);
            }
            static /*Color */ get LimeGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(105/*KnownColor.LimeGreen*/);
            }
            static /*Color */ get Linen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(106/*KnownColor.Linen*/);
            }
            static /*Color */ get Magenta()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(107/*KnownColor.Magenta*/);
            }
            static /*Color */ get Maroon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(108/*KnownColor.Maroon*/);
            }
            static /*Color */ get MediumAquamarine()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(109/*KnownColor.MediumAquamarine*/);
            }
            static /*Color */ get MediumBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(110/*KnownColor.MediumBlue*/);
            }
            static /*Color */ get MediumOrchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(111/*KnownColor.MediumOrchid*/);
            }
            static /*Color */ get MediumPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(112/*KnownColor.MediumPurple*/);
            }
            static /*Color */ get MediumSeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(113/*KnownColor.MediumSeaGreen*/);
            }
            static /*Color */ get MediumSlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(114/*KnownColor.MediumSlateBlue*/);
            }
            static /*Color */ get MediumSpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(115/*KnownColor.MediumSpringGreen*/);
            }
            static /*Color */ get MediumTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(116/*KnownColor.MediumTurquoise*/);
            }
            static /*Color */ get MediumVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(117/*KnownColor.MediumVioletRed*/);
            }
            static /*Color */ get MidnightBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(118/*KnownColor.MidnightBlue*/);
            }
            static /*Color */ get MintCream()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(119/*KnownColor.MintCream*/);
            }
            static /*Color */ get MistyRose()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(120/*KnownColor.MistyRose*/);
            }
            static /*Color */ get Moccasin()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(121/*KnownColor.Moccasin*/);
            }
            static /*Color */ get NavajoWhite()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(122/*KnownColor.NavajoWhite*/);
            }
            static /*Color */ get Navy()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(123/*KnownColor.Navy*/);
            }
            static /*Color */ get OldLace()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(124/*KnownColor.OldLace*/);
            }
            static /*Color */ get Olive()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(125/*KnownColor.Olive*/);
            }
            static /*Color */ get OliveDrab()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(126/*KnownColor.OliveDrab*/);
            }
            static /*Color */ get Orange()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(127/*KnownColor.Orange*/);
            }
            static /*Color */ get OrangeRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(128/*KnownColor.OrangeRed*/);
            }
            static /*Color */ get Orchid()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(129/*KnownColor.Orchid*/);
            }
            static /*Color */ get PaleGoldenrod()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(130/*KnownColor.PaleGoldenrod*/);
            }
            static /*Color */ get PaleGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(131/*KnownColor.PaleGreen*/);
            }
            static /*Color */ get PaleTurquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(132/*KnownColor.PaleTurquoise*/);
            }
            static /*Color */ get PaleVioletRed()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(133/*KnownColor.PaleVioletRed*/);
            }
            static /*Color */ get PapayaWhip()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(134/*KnownColor.PapayaWhip*/);
            }
            static /*Color */ get PeachPuff()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(135/*KnownColor.PeachPuff*/);
            }
            static /*Color */ get Peru()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(136/*KnownColor.Peru*/);
            }
            static /*Color */ get Pink()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(137/*KnownColor.Pink*/);
            }
            static /*Color */ get Plum()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(138/*KnownColor.Plum*/);
            }
            static /*Color */ get PowderBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(139/*KnownColor.PowderBlue*/);
            }
            static /*Color */ get Purple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(140/*KnownColor.Purple*/);
            }
            static /*Color */ get RebeccaPurple()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(175/*KnownColor.RebeccaPurple*/);
            }
            static /*Color */ get Red()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(141/*KnownColor.Red*/);
            }
            static /*Color */ get RosyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(142/*KnownColor.RosyBrown*/);
            }
            static /*Color */ get RoyalBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(143/*KnownColor.RoyalBlue*/);
            }
            static /*Color */ get SaddleBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(144/*KnownColor.SaddleBrown*/);
            }
            static /*Color */ get Salmon()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(145/*KnownColor.Salmon*/);
            }
            static /*Color */ get SandyBrown()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(146/*KnownColor.SandyBrown*/);
            }
            static /*Color */ get SeaGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(147/*KnownColor.SeaGreen*/);
            }
            static /*Color */ get SeaShell()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(148/*KnownColor.SeaShell*/);
            }
            static /*Color */ get Sienna()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(149/*KnownColor.Sienna*/);
            }
            static /*Color */ get Silver()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(150/*KnownColor.Silver*/);
            }
            static /*Color */ get SkyBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(151/*KnownColor.SkyBlue*/);
            }
            static /*Color */ get SlateBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(152/*KnownColor.SlateBlue*/);
            }
            static /*Color */ get SlateGray()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(153/*KnownColor.SlateGray*/);
            }
            static /*Color */ get Snow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(154/*KnownColor.Snow*/);
            }
            static /*Color */ get SpringGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(155/*KnownColor.SpringGreen*/);
            }
            static /*Color */ get SteelBlue()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(156/*KnownColor.SteelBlue*/);
            }
            static /*Color */ get Tan()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(157/*KnownColor.Tan*/);
            }
            static /*Color */ get Teal()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(158/*KnownColor.Teal*/);
            }
            static /*Color */ get Thistle()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(159/*KnownColor.Thistle*/);
            }
            static /*Color */ get Tomato()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(160/*KnownColor.Tomato*/);
            }
            static /*Color */ get Turquoise()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(161/*KnownColor.Turquoise*/);
            }
            static /*Color */ get Violet()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(162/*KnownColor.Violet*/);
            }
            static /*Color */ get Wheat()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(163/*KnownColor.Wheat*/);
            }
            static /*Color */ get White()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(164/*KnownColor.White*/);
            }
            static /*Color */ get WhiteSmoke()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(165/*KnownColor.WhiteSmoke*/);
            }
            static /*Color */ get Yellow()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(166/*KnownColor.Yellow*/);
            }
            static /*Color */ get YellowGreen()
            {
                return new $.$sdp.System.Drawing.Color().$ctor$2(167/*KnownColor.YellowGreen*/);
            }
            /*short*/ static StateKnownColorValid = 1;
            /*short*/ static StateARGBValueValid = 2;
            /*short*/ static StateValueMask = 2;
            /*short*/ static StateNameValid = 8;
            /*long*/ static NotDefinedValue = 0n;
            /*int*/ static ARGBAlphaShift = 24;
            /*int*/ static ARGBRedShift = 16;
            /*int*/ static ARGBGreenShift = 8;
            /*int*/ static ARGBBlueShift = 0;
            /*uint*/ static ARGBAlphaMask = 4278190080;
            /*uint*/ static ARGBRedMask = 16711680;
            /*uint*/ static ARGBGreenMask = 65280;
            /*uint*/ static ARGBBlueMask = 255;
            /*string?*/  get name() { return this.$getField(0, 4); }
            /*string?*/  set name(value) { this.$setField(0, 4, value); }
            /*long*/  get value() { return this.$getField(4, 8); }
            /*long*/  set value(value) { this.$setField(4, 8, value); }
            /*short*/  get knownColor() { return this.$getField(12, 2); }
            /*short*/  set knownColor(value) { this.$setField(12, 2, value); }
            /*short*/  get state() { return this.$getField(14, 2); }
            /*short*/  set state(value) { this.$setField(14, 2, value); }
            $ctor$2(/*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = 0n;
                    this.state = 1/*StateKnownColorValid*/;
                    this.name = null;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            $ctor$3(/*long*/ value, /*short*/ state, /*string?*/ name, /*KnownColor*/ knownColor)
            {
                super.$ctor$1();
                {
                    this.value = value;
                    this.state = state;
                    this.name = name;
                    this.knownColor = $.$cast(knownColor, $.$spc.System.Int16);
                }
                return this;
            }
            /*byte */ get R()
            {
                return $.$cast((this.Value >> BigInt(16/*ARGBRedShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get G()
            {
                return $.$cast((this.Value >> BigInt(8/*ARGBGreenShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get B()
            {
                return $.$cast((this.Value >> BigInt(0/*ARGBBlueShift*/)), $.$spc.System.Byte);
            }
            /*byte */ get A()
            {
                return $.$cast((this.Value >> BigInt(24/*ARGBAlphaShift*/)), $.$spc.System.Byte);
            }
            /*bool */ get IsKnownColor()
            {
                return (this.state & 1/*StateKnownColorValid*/) !== 0;
            }
            /*bool */ get IsEmpty()
            {
                return this.state === 0;
            }
            /*bool */ get IsNamedColor()
            {
                return ((this.state & 8/*StateNameValid*/) !== 0) || this.IsKnownColor;
            }
            /*bool */ get IsSystemColor()
            {
                return this.IsKnownColor && $.$sdp.System.Drawing.Color.IsKnownColorSystem($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
            }
            static /*bool */ IsKnownColorSystem(/*KnownColor*/ knownColor)
            {
                return $.$sdp.System.Drawing.KnownColorTable.ColorKindTable.get_Item(knownColor).$v === 0/*KnownColorTable.KnownColorKindSystem*/;
            }
            /*string */ get NameAndARGBValue()
            {
                return `{{Name = ${this.Name}, ARGB = (${this.A}, ${this.R}, ${this.G}, ${this.B})}}`;
            }
            /*string */ get Name()
            {
                if ((this.state & 8/*StateNameValid*/) !== 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(this.name, null), "name != null");
                    return this.name;
                }
                if (this.IsKnownColor)
                {
                    /*string*/ let tablename = $.$sdp.System.Drawing.KnownColorNames.KnownColorToName($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor));
                    $.$spc.System.Diagnostics.Debug.Assert$2($.$spc.System.String.op_Inequality(tablename, null), `Could not find known color '${$.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)}' in the KnownColorTable`);
                    return tablename;
                }
                return $.$spc.System.Int64.ToString$2.call(this.value, "x");
            }
            /*long */ get Value()
            {
                if ((this.state & 2/*StateValueMask*/) !== 0)
                {
                    return this.value;
                }
                if (this.IsKnownColor)
                {
                    return BigInt($.$sdp.System.Drawing.KnownColorTable.KnownColorToArgb($.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor)));
                }
                return 0n;
            }
            static /*void */ CheckByte(/*int*/ value, /*string*/ name)
            {
                /*static void*/  function ThrowOutOfByteRange(/*int*/ v, /*string*/ n)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$sdp.System.SR.Format$3($.$sdp.System.SR.InvalidEx2BoundArgument, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ n, $.$box(v, $.$spc.System.Int32), $.$box(0/*byte.MinValue*/, $.$spc.System.Byte), $.$box(255/*byte.MaxValue*/, $.$spc.System.Byte) ], null, null)));
                }
                if ((value >>> 0) > 255/*byte.MaxValue*/)
                {
                    ThrowOutOfByteRange(value, name);
                }
            }
            static /*Color */ FromArgb(/*uint*/ argb)
            {
                return new $.$sdp.System.Drawing.Color().$ctor$3(BigInt(argb), 2/*StateARGBValueValid*/, null, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            static /*Color */ FromArgb$1(/*int*/ argb)
            {
                return $.$sdp.System.Drawing.Color.FromArgb((argb >>> 0));
            }
            static /*Color */ FromArgb$2(/*int*/ alpha, /*int*/ red, /*int*/ green, /*int*/ blue)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                $.$sdp.System.Drawing.Color.CheckByte(red, "red");
                $.$sdp.System.Drawing.Color.CheckByte(green, "green");
                $.$sdp.System.Drawing.Color.CheckByte(blue, "blue");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | ((red >>> 0) << 16/*ARGBRedShift*/) >>> 0 | ((green >>> 0) << 8/*ARGBGreenShift*/) >>> 0 | ((blue >>> 0) << 0/*ARGBBlueShift*/) >>> 0);
            }
            static /*Color */ FromArgb$3(/*int*/ alpha, /*Color*/ baseColor)
            {
                $.$sdp.System.Drawing.Color.CheckByte(alpha, "alpha");
                return $.$sdp.System.Drawing.Color.FromArgb(((alpha >>> 0) << 24/*ARGBAlphaShift*/) >>> 0 | $.$cast(baseColor.Value, $.$spc.System.UInt32) & ~4278190080/*ARGBAlphaMask*/);
            }
            static /*Color */ FromArgb$4(/*int*/ red, /*int*/ green, /*int*/ blue)
            {
                return $.$sdp.System.Drawing.Color.FromArgb$2(255/*byte.MaxValue*/, red, green, blue);
            }
            static /*Color */ FromKnownColor(/*KnownColor*/ color)
            {
                return color <= 0 || color > 175/*KnownColor.RebeccaPurple*/ ? $.$sdp.System.Drawing.Color.FromName($.$spc.System.Enum.ToStringT($.$sdp.System.Drawing.KnownColor, $.$spc.System.UInt32, color)) : new $.$sdp.System.Drawing.Color().$ctor$2(color);
            }
            static /*Color */ FromName(/*string*/ name)
            {
                /*Color*/ let color;
                if ($.$sdp.System.Drawing.ColorTable.TryGetNamedColor(name, $.$ref(() => color, ($v) => color = $v, $.$sdp.System.Drawing.Color)))
                {
                    return color;
                }
                return new $.$sdp.System.Drawing.Color().$ctor$3(0n, 8/*StateNameValid*/, name, $.$cast(0, $.$sdp.System.Drawing.KnownColor));
            }
            /*void */ GetRgbValues(/*out int*/ r, /*out int*/ g, /*out int*/ b)
            {
                /*uint*/ let value = $.$cast(this.Value, $.$spc.System.UInt32);
                r.$v = ((value & 16711680/*ARGBRedMask*/) | 0) >> 16/*ARGBRedShift*/;
                g.$v = ((value & 65280/*ARGBGreenMask*/) | 0) >> 8/*ARGBGreenShift*/;
                b.$v = ((value & 255/*ARGBBlueMask*/) | 0) >> 0/*ARGBBlueShift*/;
            }
            static /*void */ MinMaxRgb(/*out int*/ min, /*out int*/ max, /*int*/ r, /*int*/ g, /*int*/ b)
            {
                if (r > g)
                {
                    max.$v = r;
                    min.$v = g;
                }
                else 
                {
                    max.$v = g;
                    min.$v = r;
                }
                if (b > max.$v)
                {
                    max.$v = b;
                }
                else if (b < min.$v)
                {
                    min.$v = b;
                }
            }
            /*float */ GetBrightness()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                return (((max + min) | 0)) / (255/*byte.MaxValue*/ * 2);
            }
            /*float */ GetHue()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*float*/ let delta = ((max - min) | 0);
                /*float*/ let hue;
                if (r === max)
                {
                    hue = (((g - b) | 0)) / delta;
                }
                else if (g === max)
                {
                    hue = (((b - r) | 0)) / delta + 2;
                }
                else 
                {
                    hue = (((r - g) | 0)) / delta + 4;
                }
                hue *= 60;
                if (hue < 0)
                {
                    hue += 360;
                }
                return hue;
            }
            /*float */ GetSaturation()
            {
                /*int*/ let r;
                /*int*/ let g;
                /*int*/ let b;
                this.GetRgbValues($.$ref(() => r, ($v) => r = $v, $.$spc.System.Int32), $.$ref(() => g, ($v) => g = $v, $.$spc.System.Int32), $.$ref(() => b, ($v) => b = $v, $.$spc.System.Int32));
                if (r === g && g === b)
                {
                    return 0;
                }
                /*int*/ let min;
                /*int*/ let max;
                $.$sdp.System.Drawing.Color.MinMaxRgb($.$ref(() => min, ($v) => min = $v, $.$spc.System.Int32), $.$ref(() => max, ($v) => max = $v, $.$spc.System.Int32), r, g, b);
                /*int*/ let div = ((max + min) | 0);
                if (div > 255/*byte.MaxValue*/)
                {
                    div = ((((((255/*byte.MaxValue*/ * 2) | 0) - max) | 0) - min) | 0);
                }
                return (((max - min) | 0)) / $.$cast(div, $.$spc.System.Single);
            }
            /*int */ ToArgb()
            {
                return $.$cast(this.Value, $.$spc.System.Int32);
            }
            /*KnownColor */ ToKnownColor()
            {
                return $.$cast(this.knownColor, $.$sdp.System.Drawing.KnownColor);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this.IsNamedColor ? `${"Color"} [${this.Name}]` : (this.state & 2/*StateValueMask*/) !== 0 ? `${"Color"} [A=${this.A}, R=${this.R}, G=${this.G}, B=${this.B}]` : `${"Color"} [Empty]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Color.ToString.apply(this, arguments); }
            static /*bool */ op_Equality(/*Color*/ left, /*Color*/ right)
            {
                return left.value === right.value && left.state === right.state && left.knownColor === right.knownColor && $.$spc.System.String.op_Equality(left.name, right.name);
            }
            static /*bool */ op_Inequality(/*Color*/ left, /*Color*/ right)
            {
                return !($.$sdp.System.Drawing.Color.op_Equality(left, right));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sdp.System.Drawing.Color, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Color.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Color*/ other)
            {
                return $.$sdp.System.Drawing.Color.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if ($.$spc.System.String.op_Inequality(this.name, null) && !this.IsKnownColor)
                {
                    return $.$spc.System.String.GetHashCode.call(this.name);
                }
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int64.GetHashCode.call(this.value), $.$spc.System.Int16.GetHashCode.call(this.state), $.$spc.System.Int16.GetHashCode.call(this.knownColor));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Color.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Color>.Equals(System.Drawing.Color)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.name = this.name;
                copy.value = this.value;
                copy.knownColor = this.knownColor;
                copy.state = this.state;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.name = null;
                this.value = 0n;
                this.knownColor = 0;
                this.state = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Color);
                }
            }
            static $h = 116411;
            static $z = 16;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":116411,"g":{"r":0,"d":0,"h":12885018299,"f":33},"n":"Transparent","d":116411,"h":8590051003,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":21474952891,"f":33},"n":"AliceBlue","d":116411,"h":17179985595,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":30064887483,"f":33},"n":"AntiqueWhite","d":116411,"h":25769920187,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":38654822075,"f":33},"n":"Aqua","d":116411,"h":34359854779,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":47244756667,"f":33},"n":"Aquamarine","d":116411,"h":42949789371,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":55834691259,"f":33},"n":"Azure","d":116411,"h":51539723963,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":64424625851,"f":33},"n":"Beige","d":116411,"h":60129658555,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":73014560443,"f":33},"n":"Bisque","d":116411,"h":68719593147,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":81604495035,"f":33},"n":"Black","d":116411,"h":77309527739,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":90194429627,"f":33},"n":"BlanchedAlmond","d":116411,"h":85899462331,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":98784364219,"f":33},"n":"Blue","d":116411,"h":94489396923,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":107374298811,"f":33},"n":"BlueViolet","d":116411,"h":103079331515,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":115964233403,"f":33},"n":"Brown","d":116411,"h":111669266107,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":124554167995,"f":33},"n":"BurlyWood","d":116411,"h":120259200699,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":133144102587,"f":33},"n":"CadetBlue","d":116411,"h":128849135291,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":141734037179,"f":33},"n":"Chartreuse","d":116411,"h":137439069883,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":150323971771,"f":33},"n":"Chocolate","d":116411,"h":146029004475,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":158913906363,"f":33},"n":"Coral","d":116411,"h":154618939067,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":167503840955,"f":33},"n":"CornflowerBlue","d":116411,"h":163208873659,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":176093775547,"f":33},"n":"Cornsilk","d":116411,"h":171798808251,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":184683710139,"f":33},"n":"Crimson","d":116411,"h":180388742843,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":193273644731,"f":33},"n":"Cyan","d":116411,"h":188978677435,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":201863579323,"f":33},"n":"DarkBlue","d":116411,"h":197568612027,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":210453513915,"f":33},"n":"DarkCyan","d":116411,"h":206158546619,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":219043448507,"f":33},"n":"DarkGoldenrod","d":116411,"h":214748481211,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":227633383099,"f":33},"n":"DarkGray","d":116411,"h":223338415803,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":236223317691,"f":33},"n":"DarkGreen","d":116411,"h":231928350395,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":244813252283,"f":33},"n":"DarkKhaki","d":116411,"h":240518284987,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":253403186875,"f":33},"n":"DarkMagenta","d":116411,"h":249108219579,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":261993121467,"f":33},"n":"DarkOliveGreen","d":116411,"h":257698154171,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":270583056059,"f":33},"n":"DarkOrange","d":116411,"h":266288088763,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":279172990651,"f":33},"n":"DarkOrchid","d":116411,"h":274878023355,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":287762925243,"f":33},"n":"DarkRed","d":116411,"h":283467957947,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":296352859835,"f":33},"n":"DarkSalmon","d":116411,"h":292057892539,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":304942794427,"f":33},"n":"DarkSeaGreen","d":116411,"h":300647827131,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":313532729019,"f":33},"n":"DarkSlateBlue","d":116411,"h":309237761723,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":322122663611,"f":33},"n":"DarkSlateGray","d":116411,"h":317827696315,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":330712598203,"f":33},"n":"DarkTurquoise","d":116411,"h":326417630907,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":339302532795,"f":33},"n":"DarkViolet","d":116411,"h":335007565499,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":347892467387,"f":33},"n":"DeepPink","d":116411,"h":343597500091,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":356482401979,"f":33},"n":"DeepSkyBlue","d":116411,"h":352187434683,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":365072336571,"f":33},"n":"DimGray","d":116411,"h":360777369275,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":373662271163,"f":33},"n":"DodgerBlue","d":116411,"h":369367303867,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":382252205755,"f":33},"n":"Firebrick","d":116411,"h":377957238459,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":390842140347,"f":33},"n":"FloralWhite","d":116411,"h":386547173051,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":399432074939,"f":33},"n":"ForestGreen","d":116411,"h":395137107643,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":408022009531,"f":33},"n":"Fuchsia","d":116411,"h":403727042235,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":416611944123,"f":33},"n":"Gainsboro","d":116411,"h":412316976827,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":425201878715,"f":33},"n":"GhostWhite","d":116411,"h":420906911419,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":433791813307,"f":33},"n":"Gold","d":116411,"h":429496846011,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":442381747899,"f":33},"n":"Goldenrod","d":116411,"h":438086780603,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":450971682491,"f":33},"n":"Gray","d":116411,"h":446676715195,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":459561617083,"f":33},"n":"Green","d":116411,"h":455266649787,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":468151551675,"f":33},"n":"GreenYellow","d":116411,"h":463856584379,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":476741486267,"f":33},"n":"Honeydew","d":116411,"h":472446518971,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":485331420859,"f":33},"n":"HotPink","d":116411,"h":481036453563,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":493921355451,"f":33},"n":"IndianRed","d":116411,"h":489626388155,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":502511290043,"f":33},"n":"Indigo","d":116411,"h":498216322747,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":511101224635,"f":33},"n":"Ivory","d":116411,"h":506806257339,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":519691159227,"f":33},"n":"Khaki","d":116411,"h":515396191931,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":528281093819,"f":33},"n":"Lavender","d":116411,"h":523986126523,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":536871028411,"f":33},"n":"LavenderBlush","d":116411,"h":532576061115,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":545460963003,"f":33},"n":"LawnGreen","d":116411,"h":541165995707,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":554050897595,"f":33},"n":"LemonChiffon","d":116411,"h":549755930299,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":562640832187,"f":33},"n":"LightBlue","d":116411,"h":558345864891,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":571230766779,"f":33},"n":"LightCoral","d":116411,"h":566935799483,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":579820701371,"f":33},"n":"LightCyan","d":116411,"h":575525734075,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":588410635963,"f":33},"n":"LightGoldenrodYellow","d":116411,"h":584115668667,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":597000570555,"f":33},"n":"LightGreen","d":116411,"h":592705603259,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":605590505147,"f":33},"n":"LightGray","d":116411,"h":601295537851,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":614180439739,"f":33},"n":"LightPink","d":116411,"h":609885472443,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":622770374331,"f":33},"n":"LightSalmon","d":116411,"h":618475407035,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":631360308923,"f":33},"n":"LightSeaGreen","d":116411,"h":627065341627,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":639950243515,"f":33},"n":"LightSkyBlue","d":116411,"h":635655276219,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":648540178107,"f":33},"n":"LightSlateGray","d":116411,"h":644245210811,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":657130112699,"f":33},"n":"LightSteelBlue","d":116411,"h":652835145403,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":665720047291,"f":33},"n":"LightYellow","d":116411,"h":661425079995,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":674309981883,"f":33},"n":"Lime","d":116411,"h":670015014587,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":682899916475,"f":33},"n":"LimeGreen","d":116411,"h":678604949179,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":691489851067,"f":33},"n":"Linen","d":116411,"h":687194883771,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":700079785659,"f":33},"n":"Magenta","d":116411,"h":695784818363,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":708669720251,"f":33},"n":"Maroon","d":116411,"h":704374752955,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":717259654843,"f":33},"n":"MediumAquamarine","d":116411,"h":712964687547,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":725849589435,"f":33},"n":"MediumBlue","d":116411,"h":721554622139,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":734439524027,"f":33},"n":"MediumOrchid","d":116411,"h":730144556731,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":743029458619,"f":33},"n":"MediumPurple","d":116411,"h":738734491323,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":751619393211,"f":33},"n":"MediumSeaGreen","d":116411,"h":747324425915,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":760209327803,"f":33},"n":"MediumSlateBlue","d":116411,"h":755914360507,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":768799262395,"f":33},"n":"MediumSpringGreen","d":116411,"h":764504295099,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":777389196987,"f":33},"n":"MediumTurquoise","d":116411,"h":773094229691,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":785979131579,"f":33},"n":"MediumVioletRed","d":116411,"h":781684164283,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":794569066171,"f":33},"n":"MidnightBlue","d":116411,"h":790274098875,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":803159000763,"f":33},"n":"MintCream","d":116411,"h":798864033467,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":811748935355,"f":33},"n":"MistyRose","d":116411,"h":807453968059,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":820338869947,"f":33},"n":"Moccasin","d":116411,"h":816043902651,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":828928804539,"f":33},"n":"NavajoWhite","d":116411,"h":824633837243,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":837518739131,"f":33},"n":"Navy","d":116411,"h":833223771835,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":846108673723,"f":33},"n":"OldLace","d":116411,"h":841813706427,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":854698608315,"f":33},"n":"Olive","d":116411,"h":850403641019,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":863288542907,"f":33},"n":"OliveDrab","d":116411,"h":858993575611,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":871878477499,"f":33},"n":"Orange","d":116411,"h":867583510203,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":880468412091,"f":33},"n":"OrangeRed","d":116411,"h":876173444795,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":889058346683,"f":33},"n":"Orchid","d":116411,"h":884763379387,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":897648281275,"f":33},"n":"PaleGoldenrod","d":116411,"h":893353313979,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":906238215867,"f":33},"n":"PaleGreen","d":116411,"h":901943248571,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":914828150459,"f":33},"n":"PaleTurquoise","d":116411,"h":910533183163,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":923418085051,"f":33},"n":"PaleVioletRed","d":116411,"h":919123117755,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":932008019643,"f":33},"n":"PapayaWhip","d":116411,"h":927713052347,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":940597954235,"f":33},"n":"PeachPuff","d":116411,"h":936302986939,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":949187888827,"f":33},"n":"Peru","d":116411,"h":944892921531,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":957777823419,"f":33},"n":"Pink","d":116411,"h":953482856123,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":966367758011,"f":33},"n":"Plum","d":116411,"h":962072790715,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":974957692603,"f":33},"n":"PowderBlue","d":116411,"h":970662725307,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":983547627195,"f":33},"n":"Purple","d":116411,"h":979252659899,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":992137561787,"f":33},"n":"RebeccaPurple","d":116411,"h":987842594491,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1000727496379,"f":33},"n":"Red","d":116411,"h":996432529083,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1009317430971,"f":33},"n":"RosyBrown","d":116411,"h":1005022463675,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1017907365563,"f":33},"n":"RoyalBlue","d":116411,"h":1013612398267,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1026497300155,"f":33},"n":"SaddleBrown","d":116411,"h":1022202332859,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1035087234747,"f":33},"n":"Salmon","d":116411,"h":1030792267451,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1043677169339,"f":33},"n":"SandyBrown","d":116411,"h":1039382202043,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1052267103931,"f":33},"n":"SeaGreen","d":116411,"h":1047972136635,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1060857038523,"f":33},"n":"SeaShell","d":116411,"h":1056562071227,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1069446973115,"f":33},"n":"Sienna","d":116411,"h":1065152005819,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1078036907707,"f":33},"n":"Silver","d":116411,"h":1073741940411,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1086626842299,"f":33},"n":"SkyBlue","d":116411,"h":1082331875003,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1095216776891,"f":33},"n":"SlateBlue","d":116411,"h":1090921809595,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1103806711483,"f":33},"n":"SlateGray","d":116411,"h":1099511744187,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1112396646075,"f":33},"n":"Snow","d":116411,"h":1108101678779,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1120986580667,"f":33},"n":"SpringGreen","d":116411,"h":1116691613371,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1129576515259,"f":33},"n":"SteelBlue","d":116411,"h":1125281547963,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1138166449851,"f":33},"n":"Tan","d":116411,"h":1133871482555,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1146756384443,"f":33},"n":"Teal","d":116411,"h":1142461417147,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1155346319035,"f":33},"n":"Thistle","d":116411,"h":1151051351739,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1163936253627,"f":33},"n":"Tomato","d":116411,"h":1159641286331,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1172526188219,"f":33},"n":"Turquoise","d":116411,"h":1168231220923,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1181116122811,"f":33},"n":"Violet","d":116411,"h":1176821155515,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1189706057403,"f":33},"n":"Wheat","d":116411,"h":1185411090107,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1198295991995,"f":33},"n":"White","d":116411,"h":1194001024699,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1206885926587,"f":33},"n":"WhiteSmoke","d":116411,"h":1202590959291,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1215475861179,"f":33},"n":"Yellow","d":116411,"h":1211180893883,"f":33},{"p":116411,"g":{"r":0,"d":0,"h":1224065795771,"f":33},"n":"YellowGreen","d":116411,"h":1219770828475,"f":33},{"p":393217,"g":{"r":0,"d":0,"h":1314260108987,"f":1},"n":"R","d":116411,"h":1309965141691,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1322850043579,"f":1},"n":"G","d":116411,"h":1318555076283,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1331439978171,"f":1},"n":"B","d":116411,"h":1327145010875,"f":1},{"p":393217,"g":{"r":0,"d":0,"h":1340029912763,"f":1},"n":"A","d":116411,"h":1335734945467,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1348619847355,"f":1},"n":"IsKnownColor","d":116411,"h":1344324880059,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1357209781947,"f":1},"n":"IsEmpty","d":116411,"h":1352914814651,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1365799716539,"f":1},"n":"IsNamedColor","d":116411,"h":1361504749243,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":1374389651131,"f":1},"n":"IsSystemColor","d":116411,"h":1370094683835,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":1387274553019,"f":2},"n":"NameAndARGBValue","d":116411,"h":1382979585723,"f":2},{"p":1310721,"g":{"r":0,"d":0,"h":1395864487611,"f":1},"n":"Name","d":116411,"h":1391569520315,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":1404454422203,"f":2},"n":"Value","d":116411,"h":1400159454907,"f":2}],"m":[{"r":262145,"p":[{"n":"knownColor","p":378555}],"n":"IsKnownColorSystem","d":116411,"h":1378684618427,"f":40},{"r":65537,"p":[{"n":"value","p":655361},{"n":"name","p":1310721}],"n":"CheckByte","d":116411,"h":1408749389499,"f":34},{"r":116411,"p":[{"n":"argb","p":720897}],"n":"FromArgb","d":116411,"h":1413044356795,"f":34},{"r":116411,"p":[{"n":"argb","p":655361}],"n":"FromArgb","o":"@$1","d":116411,"h":1417339324091,"f":33},{"r":116411,"p":[{"n":"alpha","p":655361},{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$2","d":116411,"h":1421634291387,"f":33},{"r":116411,"p":[{"n":"alpha","p":655361},{"n":"baseColor","p":116411}],"n":"FromArgb","o":"@$3","d":116411,"h":1425929258683,"f":33},{"r":116411,"p":[{"n":"red","p":655361},{"n":"green","p":655361},{"n":"blue","p":655361}],"n":"FromArgb","o":"@$4","d":116411,"h":1430224225979,"f":33},{"r":116411,"p":[{"n":"color","p":378555}],"n":"FromKnownColor","d":116411,"h":1434519193275,"f":33},{"r":116411,"p":[{"n":"name","p":1310721}],"n":"FromName","d":116411,"h":1438814160571,"f":33},{"r":65537,"p":[{"n":"r","p":655361,"f":2},{"n":"g","p":655361,"f":2},{"n":"b","p":655361,"f":2}],"n":"GetRgbValues","d":116411,"h":1443109127867,"f":8},{"r":65537,"p":[{"n":"min","p":655361,"f":2},{"n":"max","p":655361,"f":2},{"n":"r","p":655361},{"n":"g","p":655361},{"n":"b","p":655361}],"n":"MinMaxRgb","d":116411,"h":1447404095163,"f":34},{"r":1114113,"n":"GetBrightness","d":116411,"h":1451699062459,"f":1},{"r":1114113,"n":"GetHue","d":116411,"h":1455994029755,"f":1},{"r":1114113,"n":"GetSaturation","d":116411,"h":1460288997051,"f":1},{"r":655361,"n":"ToArgb","d":116411,"h":1464583964347,"f":1},{"r":378555,"n":"ToKnownColor","d":116411,"h":1468878931643,"f":1},{"r":1310721,"n":"ToString","d":116411,"h":1473173898939,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":116411,"h":1486058800827,"f":32769},{"r":262145,"p":[{"n":"other","p":116411}],"n":"Equals","o":"@$2","d":116411,"h":1490353768123,"f":1},{"r":655361,"n":"GetHashCode","d":116411,"h":1494648735419,"f":32769}],"l":[{"t":116411,"n":"Empty","d":116411,"h":4295083707,"f":33},{"t":524289,"n":"StateKnownColorValid","d":116411,"h":1228360763067,"f":34},{"t":524289,"n":"StateARGBValueValid","d":116411,"h":1232655730363,"f":34},{"t":524289,"n":"StateValueMask","d":116411,"h":1236950697659,"f":34},{"t":524289,"n":"StateNameValid","d":116411,"h":1241245664955,"f":34},{"t":917505,"n":"NotDefinedValue","d":116411,"h":1245540632251,"f":34},{"t":655361,"n":"ARGBAlphaShift","d":116411,"h":1249835599547,"f":40},{"t":655361,"n":"ARGBRedShift","d":116411,"h":1254130566843,"f":40},{"t":655361,"n":"ARGBGreenShift","d":116411,"h":1258425534139,"f":40},{"t":655361,"n":"ARGBBlueShift","d":116411,"h":1262720501435,"f":40},{"t":720897,"n":"ARGBAlphaMask","d":116411,"h":1267015468731,"f":40},{"t":720897,"n":"ARGBRedMask","d":116411,"h":1271310436027,"f":40},{"t":720897,"n":"ARGBGreenMask","d":116411,"h":1275605403323,"f":40},{"t":720897,"n":"ARGBBlueMask","d":116411,"h":1279900370619,"f":40},{"t":1310721,"n":"name","d":116411,"h":1284195337915,"f":2},{"t":917505,"n":"value","d":116411,"h":1288490305211,"f":2},{"t":524289,"n":"knownColor","d":116411,"h":1292785272507,"f":2},{"t":524289,"n":"state","d":116411,"h":1297080239803,"f":2}],"c":[{"p":[{"n":"knownColor","p":378555}],"n":".ctor","o":"$ctor$2","d":116411,"h":1301375207099,"f":8},{"p":[{"n":"value","p":917505},{"n":"state","p":524289},{"n":"name","p":1310721},{"n":"knownColor","p":378555}],"n":".ctor","o":"$ctor$3","d":116411,"h":1305670174395,"f":2},{"n":".ctor","o":"$ctor$4","d":116411,"h":1498943702715,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color).$h],"h":116411,"a":[{"t":37552129,"c":8627486721,"a":[{"v":"{NameAndARGBValue}","t":1310721}]},{"t":852007,"c":12885753895,"a":[{"v":"System.Drawing.Design.ColorEditor, System.Drawing.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721},{"v":"System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":118226945,"c":4413194241},{"t":1496742,"c":17181365926,"a":[{"v":"System.Drawing.ColorConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Color) ]; }
            static get $fullName() { return `System.Drawing.Color`; }
        });
        
        $asm.$str("$sdp.System.Drawing.RectangleF", ($self) => class RectangleF extends $.$spc.System.ValueType
        {
            /*RectangleF*/ static Empty;
            /*float*/  get x() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set x(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get y() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set y(value) { this.$setField(4, $.$spc.System.Single, value); }
            /*float*/  get width() { return this.$getField(8, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(8, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(12, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(12, $.$spc.System.Single, value); }
            $ctor$2(/*float*/ x, /*float*/ y, /*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ location, /*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            $ctor$4(/*Vector4*/ vector)
            {
                super.$ctor$1();
                {
                    this.x = vector.X;
                    this.y = vector.Y;
                    this.width = vector.Z;
                    this.height = vector.W;
                }
                return this;
            }
            /*Vector4 */ ToVector4()
            {
                return new $.$spc.System.Numerics.Vector4().$ctor$5(this.x, this.y, this.width, this.height);
            }
            static /*Vector4 */ op_Explicit(/*RectangleF*/ rectangle)
            {
                return rectangle.ToVector4();
            }
            static /*RectangleF */ op_Explicit$1(/*Vector4*/ vector)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$4(vector.Clone());
            }
            static /*RectangleF */ FromLTRB(/*float*/ left, /*float*/ top, /*float*/ right, /*float*/ bottom)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(left, top, right - left, bottom - top);
            }
            /*PointF */ get Location()
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(this.X, this.Y);
            }
            /*PointF */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*SizeF */ get Size()
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(this.Width, this.Height);
            }
            /*SizeF */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*float */ get X()
            {
                return this.x;
            }
            /*float */ set X(value)
            {
                this.x = value;
            }
            /*float */ get Y()
            {
                return this.y;
            }
            /*float */ set Y(value)
            {
                this.y = value;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            /*float */ get Left()
            {
                return this.X;
            }
            /*float */ get Top()
            {
                return this.Y;
            }
            /*float */ get Right()
            {
                return this.X + this.Width;
            }
            /*float */ get Bottom()
            {
                return this.Y + this.Height;
            }
            /*bool */ get IsEmpty()
            {
                return (this.Width <= 0) || (this.Height <= 0);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.RectangleF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.RectangleF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.RectangleF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*RectangleF*/ other)
            {
                return $.$sdp.System.Drawing.RectangleF.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*RectangleF*/ left, /*RectangleF*/ right)
            {
                return !($.$sdp.System.Drawing.RectangleF.op_Equality(left, right));
            }
            /*bool */ Contains(/*float*/ x, /*float*/ y)
            {
                return this.X <= x && x < this.X + this.Width && this.Y <= y && y < this.Y + this.Height;
            }
            /*bool */ Contains$1(/*PointF*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*RectangleF*/ rect)
            {
                return (this.X <= rect.X) && (rect.X + rect.Width <= this.X + this.Width) && (this.Y <= rect.Y) && (rect.Y + rect.Height <= this.Y + this.Height);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, $.$spc.System.Single, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.RectangleF.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*float*/ x, /*float*/ y)
            {
                this.X -= x;
                this.Y -= y;
                this.Width += 2 * x;
                this.Height += 2 * y;
            }
            /*void */ Inflate$1(/*SizeF*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*RectangleF */ Inflate$2(/*RectangleF*/ rect, /*float*/ x, /*float*/ y)
            {
                /*RectangleF*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*RectangleF*/ rect)
            {
                /*RectangleF*/ let result = $.$sdp.System.Drawing.RectangleF.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*RectangleF */ Intersect$1(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Max$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Min$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Max$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Min$8(a.Y + a.Height, b.Y + b.Height);
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
                }
                return $.$sdp.System.Drawing.RectangleF.Empty;
            }
            /*bool */ IntersectsWith(/*RectangleF*/ rect)
            {
                return (rect.X < this.X + this.Width) && (this.X < rect.X + rect.Width) && (rect.Y < this.Y + this.Height) && (this.Y < rect.Y + rect.Height);
            }
            static /*RectangleF */ Union(/*RectangleF*/ a, /*RectangleF*/ b)
            {
                /*float*/ let x1 = $.$spc.System.Math.Min$8(a.X, b.X);
                /*float*/ let x2 = $.$spc.System.Math.Max$8(a.X + a.Width, b.X + b.Width);
                /*float*/ let y1 = $.$spc.System.Math.Min$8(a.Y, b.Y);
                /*float*/ let y2 = $.$spc.System.Math.Max$8(a.Y + a.Height, b.Y + b.Height);
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(x1, y1, x2 - x1, y2 - y1);
            }
            /*void */ Offset(/*PointF*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*float*/ x, /*float*/ y)
            {
                this.X += x;
                this.Y += y;
            }
            static /*RectangleF */ op_Implicit(/*Rectangle*/ r)
            {
                return new $.$sdp.System.Drawing.RectangleF().$ctor$2(r.X, r.Y, r.Width, r.Height);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.RectangleF.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.RectangleF>.Equals(System.Drawing.RectangleF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.RectangleF);
                }
            }
            static $h = 771771;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":640699,"g":{"r":0,"d":0,"h":60130313915,"f":1},"s":{"r":0,"d":0,"h":64425281211,"f":1},"n":"Location","d":771771,"h":55835346619,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":902843,"g":{"r":0,"d":0,"h":73015215803,"f":1},"s":{"r":0,"d":0,"h":77310183099,"f":1},"n":"Size","d":771771,"h":68720248507,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":85900117691,"f":1},"s":{"r":0,"d":0,"h":90195084987,"f":1},"n":"X","d":771771,"h":81605150395,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":98785019579,"f":1},"s":{"r":0,"d":0,"h":103079986875,"f":1},"n":"Y","d":771771,"h":94490052283,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":111669921467,"f":1},"s":{"r":0,"d":0,"h":115964888763,"f":1},"n":"Width","d":771771,"h":107374954171,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":124554823355,"f":1},"s":{"r":0,"d":0,"h":128849790651,"f":1},"n":"Height","d":771771,"h":120259856059,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":137439725243,"f":1},"n":"Left","d":771771,"h":133144757947,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":146029659835,"f":1},"n":"Top","d":771771,"h":141734692539,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":154619594427,"f":1},"n":"Right","d":771771,"h":150324627131,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":163209529019,"f":1},"n":"Bottom","d":771771,"h":158914561723,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":171799463611,"f":1},"n":"IsEmpty","d":771771,"h":167504496315,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":70713345,"n":"ToVector4","d":771771,"h":38655477435,"f":1},{"r":771771,"p":[{"n":"left","p":1114113},{"n":"top","p":1114113},{"n":"right","p":1114113},{"n":"bottom","p":1114113}],"n":"FromLTRB","d":771771,"h":51540379323,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":771771,"h":176094430907,"f":32769},{"r":262145,"p":[{"n":"other","p":771771}],"n":"Equals","o":"@$2","d":771771,"h":180389398203,"f":1},{"r":262145,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Contains","d":771771,"h":193274300091,"f":1},{"r":262145,"p":[{"n":"pt","p":640699}],"n":"Contains","o":"@$1","d":771771,"h":197569267387,"f":1},{"r":262145,"p":[{"n":"rect","p":771771}],"n":"Contains","o":"@$2","d":771771,"h":201864234683,"f":1},{"r":655361,"n":"GetHashCode","d":771771,"h":206159201979,"f":32769},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","d":771771,"h":210454169275,"f":1},{"r":65537,"p":[{"n":"size","p":902843}],"n":"Inflate","o":"@$1","d":771771,"h":214749136571,"f":1},{"r":771771,"p":[{"n":"rect","p":771771},{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Inflate","o":"@$2","d":771771,"h":219044103867,"f":33},{"r":65537,"p":[{"n":"rect","p":771771}],"n":"Intersect","d":771771,"h":223339071163,"f":1},{"r":771771,"p":[{"n":"a","p":771771},{"n":"b","p":771771}],"n":"Intersect","o":"@$1","d":771771,"h":227634038459,"f":33},{"r":262145,"p":[{"n":"rect","p":771771}],"n":"IntersectsWith","d":771771,"h":231929005755,"f":1},{"r":771771,"p":[{"n":"a","p":771771},{"n":"b","p":771771}],"n":"Union","d":771771,"h":236223973051,"f":33},{"r":65537,"p":[{"n":"pos","p":640699}],"n":"Offset","d":771771,"h":240518940347,"f":1},{"r":65537,"p":[{"n":"x","p":1114113},{"n":"y","p":1114113}],"n":"Offset","o":"@$1","d":771771,"h":244813907643,"f":1},{"r":1310721,"n":"ToString","d":771771,"h":253403842235,"f":32769}],"l":[{"t":771771,"n":"Empty","d":771771,"h":4295739067,"f":33},{"t":1114113,"n":"x","d":771771,"h":8590706363,"f":2},{"t":1114113,"n":"y","d":771771,"h":12885673659,"f":2},{"t":1114113,"n":"width","d":771771,"h":17180640955,"f":2},{"t":1114113,"n":"height","d":771771,"h":21475608251,"f":2}],"c":[{"p":[{"n":"x","p":1114113},{"n":"y","p":1114113},{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$2","d":771771,"h":25770575547,"f":1},{"p":[{"n":"location","p":640699},{"n":"size","p":902843}],"n":".ctor","o":"$ctor$3","d":771771,"h":30065542843,"f":1},{"p":[{"n":"vector","p":70713345}],"n":".ctor","o":"$ctor$4","d":771771,"h":34360510139,"f":1},{"n":".ctor","o":"$ctor$5","d":771771,"h":257698809531,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF).$h],"h":771771,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.RectangleF) ]; }
            static get $fullName() { return `System.Drawing.RectangleF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Rectangle", ($self) => class Rectangle extends $.$spc.System.ValueType
        {
            /*Rectangle*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            /*int*/  get width() { return this.$getField(8, $.$spc.System.Int32); }
            /*int*/  set width(value) { this.$setField(8, $.$spc.System.Int32, value); }
            /*int*/  get height() { return this.$getField(12, $.$spc.System.Int32); }
            /*int*/  set height(value) { this.$setField(12, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y, /*int*/ width, /*int*/ height)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            $ctor$3(/*Point*/ location, /*Size*/ size)
            {
                super.$ctor$1();
                {
                    this.x = location.X;
                    this.y = location.Y;
                    this.width = size.Width;
                    this.height = size.Height;
                }
                return this;
            }
            static /*Rectangle */ FromLTRB(/*int*/ left, /*int*/ top, /*int*/ right, /*int*/ bottom)
            {
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(left, top, ((right - left) | 0), ((bottom - top) | 0));
            }
            /*Point */ get Location()
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(this.X, this.Y);
            }
            /*Point */ set Location(value)
            {
                this.X = value.X;
                this.Y = value.Y;
            }
            /*Size */ get Size()
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(this.Width, this.Height);
            }
            /*Size */ set Size(value)
            {
                this.Width = value.Width;
                this.Height = value.Height;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            /*int */ get Width()
            {
                return this.width;
            }
            /*int */ set Width(value)
            {
                this.width = value;
            }
            /*int */ get Height()
            {
                return this.height;
            }
            /*int */ set Height(value)
            {
                this.height = value;
            }
            /*int */ get Left()
            {
                return this.X;
            }
            /*int */ get Top()
            {
                return this.Y;
            }
            /*int */ get Right()
            {
                return ((this.X + this.Width) | 0);
            }
            /*int */ get Bottom()
            {
                return ((this.Y + this.Height) | 0);
            }
            /*bool */ get IsEmpty()
            {
                return this.height === 0 && this.width === 0 && this.x === 0 && this.y === 0;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Rectangle) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Rectangle));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Rectangle.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Rectangle*/ other)
            {
                return $.$sdp.System.Drawing.Rectangle.op_Equality(this, other);
            }
            static /*bool */ op_Equality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return left.X === right.X && left.Y === right.Y && left.Width === right.Width && left.Height === right.Height;
            }
            static /*bool */ op_Inequality(/*Rectangle*/ left, /*Rectangle*/ right)
            {
                return !($.$sdp.System.Drawing.Rectangle.op_Equality(left, right));
            }
            static /*Rectangle */ Ceiling(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32), $.$cast(Math.ceil(value.Width), $.$spc.System.Int32), $.$cast(Math.ceil(value.Height), $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Truncate(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32), $.$cast(value.Width, $.$spc.System.Int32), $.$cast(value.Height, $.$spc.System.Int32));
                }
            }
            static /*Rectangle */ Round(/*RectangleF*/ value)
            {
                //unchecked
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Width), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Height), $.$spc.System.Int32));
                }
            }
            /*bool */ Contains(/*int*/ x, /*int*/ y)
            {
                return this.X <= x && x < ((this.X + this.Width) | 0) && this.Y <= y && y < ((this.Y + this.Height) | 0);
            }
            /*bool */ Contains$1(/*Point*/ pt)
            {
                return this.Contains(pt.X, pt.Y);
            }
            /*bool */ Contains$2(/*Rectangle*/ rect)
            {
                return (this.X <= rect.X) && (((rect.X + rect.Width) | 0) <= ((this.X + this.Width) | 0)) && (this.Y <= rect.Y) && (((rect.Y + rect.Height) | 0) <= ((this.Y + this.Height) | 0));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$3($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Rectangle.GetHashCode.apply(this, arguments); }
            /*void */ Inflate(/*int*/ width, /*int*/ height)
            {
                //unchecked
                {
                    this.X -= width;
                    this.Y -= height;
                    this.Width += ((2 * width) | 0);
                    this.Height += ((2 * height) | 0);
                }
            }
            /*void */ Inflate$1(/*Size*/ size)
            {
                return this.Inflate(size.Width, size.Height);
            }
            static /*Rectangle */ Inflate$2(/*Rectangle*/ rect, /*int*/ x, /*int*/ y)
            {
                /*Rectangle*/ let r = rect;
                r.Inflate(x, y);
                return r;
            }
            /*void */ Intersect(/*Rectangle*/ rect)
            {
                /*Rectangle*/ let result = $.$sdp.System.Drawing.Rectangle.Intersect$1(rect.Clone(), this);
                this.X = result.X;
                this.Y = result.Y;
                this.Width = result.Width;
                this.Height = result.Height;
            }
            static /*Rectangle */ Intersect$1(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Max$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Min$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Max$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Min$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                if (x2 >= x1 && y2 >= y1)
                {
                    return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
                }
                return $.$sdp.System.Drawing.Rectangle.Empty;
            }
            /*bool */ IntersectsWith(/*Rectangle*/ rect)
            {
                return (rect.X < ((this.X + this.Width) | 0)) && (this.X < ((rect.X + rect.Width) | 0)) && (rect.Y < ((this.Y + this.Height) | 0)) && (this.Y < ((rect.Y + rect.Height) | 0));
            }
            static /*Rectangle */ Union(/*Rectangle*/ a, /*Rectangle*/ b)
            {
                /*int*/ let x1 = $.$spc.System.Math.Min$4(a.X, b.X);
                /*int*/ let x2 = $.$spc.System.Math.Max$4(((a.X + a.Width) | 0), ((b.X + b.Width) | 0));
                /*int*/ let y1 = $.$spc.System.Math.Min$4(a.Y, b.Y);
                /*int*/ let y2 = $.$spc.System.Math.Max$4(((a.Y + a.Height) | 0), ((b.Y + b.Height) | 0));
                return new $.$sdp.System.Drawing.Rectangle().$ctor$2(x1, y1, ((x2 - x1) | 0), ((y2 - y1) | 0));
            }
            /*void */ Offset(/*Point*/ pos)
            {
                return this.Offset$1(pos.X, pos.Y);
            }
            /*void */ Offset$1(/*int*/ x, /*int*/ y)
            {
                //unchecked
                {
                    this.X += x;
                    this.Y += y;
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y},Width=${this.Width},Height=${this.Height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Rectangle.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Rectangle>.Equals(System.Drawing.Rectangle)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Rectangle);
                }
            }
            static $h = 706235;
            static $z = 16;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":575163,"g":{"r":0,"d":0,"h":42950379195,"f":1},"s":{"r":0,"d":0,"h":47245346491,"f":1},"n":"Location","d":706235,"h":38655411899,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":837307,"g":{"r":0,"d":0,"h":55835281083,"f":1},"s":{"r":0,"d":0,"h":60130248379,"f":1},"n":"Size","d":706235,"h":51540313787,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":68720182971,"f":1},"s":{"r":0,"d":0,"h":73015150267,"f":1},"n":"X","d":706235,"h":64425215675,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":81605084859,"f":1},"s":{"r":0,"d":0,"h":85900052155,"f":1},"n":"Y","d":706235,"h":77310117563,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":94489986747,"f":1},"s":{"r":0,"d":0,"h":98784954043,"f":1},"n":"Width","d":706235,"h":90195019451,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":107374888635,"f":1},"s":{"r":0,"d":0,"h":111669855931,"f":1},"n":"Height","d":706235,"h":103079921339,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":120259790523,"f":1},"n":"Left","d":706235,"h":115964823227,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":128849725115,"f":1},"n":"Top","d":706235,"h":124554757819,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":137439659707,"f":1},"n":"Right","d":706235,"h":133144692411,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":146029594299,"f":1},"n":"Bottom","d":706235,"h":141734627003,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":262145,"g":{"r":0,"d":0,"h":154619528891,"f":1},"n":"IsEmpty","d":706235,"h":150324561595,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]}],"m":[{"r":706235,"p":[{"n":"left","p":655361},{"n":"top","p":655361},{"n":"right","p":655361},{"n":"bottom","p":655361}],"n":"FromLTRB","d":706235,"h":34360444603,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":706235,"h":158914496187,"f":32769},{"r":262145,"p":[{"n":"other","p":706235}],"n":"Equals","o":"@$2","d":706235,"h":163209463483,"f":1},{"r":706235,"p":[{"n":"value","p":771771}],"n":"Ceiling","d":706235,"h":176094365371,"f":33},{"r":706235,"p":[{"n":"value","p":771771}],"n":"Truncate","d":706235,"h":180389332667,"f":33},{"r":706235,"p":[{"n":"value","p":771771}],"n":"Round","d":706235,"h":184684299963,"f":33},{"r":262145,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Contains","d":706235,"h":188979267259,"f":1},{"r":262145,"p":[{"n":"pt","p":575163}],"n":"Contains","o":"@$1","d":706235,"h":193274234555,"f":1},{"r":262145,"p":[{"n":"rect","p":706235}],"n":"Contains","o":"@$2","d":706235,"h":197569201851,"f":1},{"r":655361,"n":"GetHashCode","d":706235,"h":201864169147,"f":32769},{"r":65537,"p":[{"n":"width","p":655361},{"n":"height","p":655361}],"n":"Inflate","d":706235,"h":206159136443,"f":1},{"r":65537,"p":[{"n":"size","p":837307}],"n":"Inflate","o":"@$1","d":706235,"h":210454103739,"f":1},{"r":706235,"p":[{"n":"rect","p":706235},{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Inflate","o":"@$2","d":706235,"h":214749071035,"f":33},{"r":65537,"p":[{"n":"rect","p":706235}],"n":"Intersect","d":706235,"h":219044038331,"f":1},{"r":706235,"p":[{"n":"a","p":706235},{"n":"b","p":706235}],"n":"Intersect","o":"@$1","d":706235,"h":223339005627,"f":33},{"r":262145,"p":[{"n":"rect","p":706235}],"n":"IntersectsWith","d":706235,"h":227633972923,"f":1},{"r":706235,"p":[{"n":"a","p":706235},{"n":"b","p":706235}],"n":"Union","d":706235,"h":231928940219,"f":33},{"r":65537,"p":[{"n":"pos","p":575163}],"n":"Offset","d":706235,"h":236223907515,"f":1},{"r":65537,"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":"Offset","o":"@$1","d":706235,"h":240518874811,"f":1},{"r":1310721,"n":"ToString","d":706235,"h":244813842107,"f":32769}],"l":[{"t":706235,"n":"Empty","d":706235,"h":4295673531,"f":33},{"t":655361,"n":"x","d":706235,"h":8590640827,"f":2},{"t":655361,"n":"y","d":706235,"h":12885608123,"f":2},{"t":655361,"n":"width","d":706235,"h":17180575419,"f":2},{"t":655361,"n":"height","d":706235,"h":21475542715,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361},{"n":"width","p":655361},{"n":"height","p":655361}],"n":".ctor","o":"$ctor$2","d":706235,"h":25770510011,"f":1},{"p":[{"n":"location","p":575163},{"n":"size","p":837307}],"n":".ctor","o":"$ctor$3","d":706235,"h":30065477307,"f":1},{"n":".ctor","o":"$ctor$4","d":706235,"h":249108809403,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle).$h],"h":706235,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496742,"c":17181365926,"a":[{"v":"System.Drawing.RectangleConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Rectangle) ]; }
            static get $fullName() { return `System.Drawing.Rectangle`; }
        });
        
        $asm.$str("$sdp.System.Drawing.Point", ($self) => class Point extends $.$spc.System.ValueType
        {
            /*Point*/ static Empty;
            /*int*/  get x() { return this.$getField(0, $.$spc.System.Int32); }
            /*int*/  set x(value) { this.$setField(0, $.$spc.System.Int32, value); }
            /*int*/  get y() { return this.$getField(4, $.$spc.System.Int32); }
            /*int*/  set y(value) { this.$setField(4, $.$spc.System.Int32, value); }
            $ctor$2(/*int*/ x, /*int*/ y)
            {
                super.$ctor$1();
                {
                    this.x = x;
                    this.y = y;
                }
                return this;
            }
            $ctor$3(/*Size*/ sz)
            {
                super.$ctor$1();
                {
                    this.x = sz.Width;
                    this.y = sz.Height;
                }
                return this;
            }
            $ctor$4(/*int*/ dw)
            {
                super.$ctor$1();
                {
                    this.x = $.$sdp.System.Drawing.Point.LowInt16(dw);
                    this.y = $.$sdp.System.Drawing.Point.HighInt16(dw);
                }
                return this;
            }
            /*bool */ get IsEmpty()
            {
                return this.x === 0 && this.y === 0;
            }
            /*int */ get X()
            {
                return this.x;
            }
            /*int */ set X(value)
            {
                this.x = value;
            }
            /*int */ get Y()
            {
                return this.y;
            }
            /*int */ set Y(value)
            {
                this.y = value;
            }
            static /*PointF */ op_Implicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(p.X, p.Y);
            }
            static /*Size */ op_Explicit(/*Point*/ p)
            {
                return new $.$sdp.System.Drawing.Size().$ctor$3(p.X, p.Y);
            }
            static /*Point */ op_Addition(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Add(pt.Clone(), sz.Clone());
            }
            static /*Point */ op_Subtraction(/*Point*/ pt, /*Size*/ sz)
            {
                return $.$sdp.System.Drawing.Point.Subtract(pt.Clone(), sz.Clone());
            }
            static /*bool */ op_Equality(/*Point*/ left, /*Point*/ right)
            {
                return left.X === right.X && left.Y === right.Y;
            }
            static /*bool */ op_Inequality(/*Point*/ left, /*Point*/ right)
            {
                return !($.$sdp.System.Drawing.Point.op_Equality(left, right));
            }
            static /*Point */ Add(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X + sz.Width) | 0), ((pt.Y + sz.Height) | 0));
            }
            static /*Point */ Subtract(/*Point*/ pt, /*Size*/ sz)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2(((pt.X - sz.Width) | 0), ((pt.Y - sz.Height) | 0));
            }
            static /*Point */ Ceiling(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(Math.ceil(value.X), $.$spc.System.Int32), $.$cast(Math.ceil(value.Y), $.$spc.System.Int32));
            }
            static /*Point */ Truncate(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast(value.X, $.$spc.System.Int32), $.$cast(value.Y, $.$spc.System.Int32));
            }
            static /*Point */ Round(/*PointF*/ value)
            {
                return new $.$sdp.System.Drawing.Point().$ctor$2($.$cast($.$spc.System.Math.Round$4(value.X), $.$spc.System.Int32), $.$cast($.$spc.System.Math.Round$4(value.Y), $.$spc.System.Int32));
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.Point) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.Point));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.Point.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*Point*/ other)
            {
                return $.$sdp.System.Drawing.Point.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Int32, $.$spc.System.Int32, this.X, this.Y);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.Point.GetHashCode.apply(this, arguments); }
            /*void */ Offset(/*int*/ dx, /*int*/ dy)
            {
                //unchecked
                {
                    this.X += dx;
                    this.Y += dy;
                }
            }
            /*void */ Offset$1(/*Point*/ p)
            {
                return this.Offset(p.X, p.Y);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{X=${this.X},Y=${this.Y}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.Point.ToString.apply(this, arguments); }
            static /*short */ HighInt16(/*int*/ n)
            {
                return $.$cast(((n >> 16) & 65535), $.$spc.System.Int16);
            }
            static /*short */ LowInt16(/*int*/ n)
            {
                return $.$cast((n & 65535), $.$spc.System.Int16);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.Point>.Equals(System.Drawing.Point)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$5()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.x = this.x;
                copy.y = this.y;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.x = 0;
                this.y = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.Point);
                }
            }
            static $h = 575163;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360313531,"f":1},"n":"IsEmpty","d":575163,"h":30065346235,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":655361,"g":{"r":0,"d":0,"h":42950248123,"f":1},"s":{"r":0,"d":0,"h":47245215419,"f":1},"n":"X","d":575163,"h":38655280827,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55835150011,"f":1},"s":{"r":0,"d":0,"h":60130117307,"f":1},"n":"Y","d":575163,"h":51540182715,"f":1}],"m":[{"r":575163,"p":[{"n":"pt","p":575163},{"n":"sz","p":837307}],"n":"Add","d":575163,"h":90194888379,"f":33},{"r":575163,"p":[{"n":"pt","p":575163},{"n":"sz","p":837307}],"n":"Subtract","d":575163,"h":94489855675,"f":33},{"r":575163,"p":[{"n":"value","p":640699}],"n":"Ceiling","d":575163,"h":98784822971,"f":33},{"r":575163,"p":[{"n":"value","p":640699}],"n":"Truncate","d":575163,"h":103079790267,"f":33},{"r":575163,"p":[{"n":"value","p":640699}],"n":"Round","d":575163,"h":107374757563,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":575163,"h":111669724859,"f":32769},{"r":262145,"p":[{"n":"other","p":575163}],"n":"Equals","o":"@$2","d":575163,"h":115964692155,"f":1},{"r":655361,"n":"GetHashCode","d":575163,"h":120259659451,"f":32769},{"r":65537,"p":[{"n":"dx","p":655361},{"n":"dy","p":655361}],"n":"Offset","d":575163,"h":124554626747,"f":1},{"r":65537,"p":[{"n":"p","p":575163}],"n":"Offset","o":"@$1","d":575163,"h":128849594043,"f":1},{"r":1310721,"n":"ToString","d":575163,"h":133144561339,"f":32769},{"r":524289,"p":[{"n":"n","p":655361}],"n":"HighInt16","d":575163,"h":137439528635,"f":34},{"r":524289,"p":[{"n":"n","p":655361}],"n":"LowInt16","d":575163,"h":141734495931,"f":34}],"l":[{"t":575163,"n":"Empty","d":575163,"h":4295542459,"f":33},{"t":655361,"n":"x","d":575163,"h":8590509755,"f":2},{"t":655361,"n":"y","d":575163,"h":12885477051,"f":2}],"c":[{"p":[{"n":"x","p":655361},{"n":"y","p":655361}],"n":".ctor","o":"$ctor$2","d":575163,"h":17180444347,"f":1},{"p":[{"n":"sz","p":837307}],"n":".ctor","o":"$ctor$3","d":575163,"h":21475411643,"f":1},{"p":[{"n":"dw","p":655361}],"n":".ctor","o":"$ctor$4","d":575163,"h":25770378939,"f":1},{"n":".ctor","o":"$ctor$5","d":575163,"h":146029463227,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point).$h],"h":575163,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496742,"c":17181365926,"a":[{"v":"System.Drawing.PointConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.Point) ]; }
            static get $fullName() { return `System.Drawing.Point`; }
        });
        
        $asm.$str("$sdp.System.Drawing.SizeF", ($self) => class SizeF extends $.$spc.System.ValueType
        {
            /*SizeF*/ static Empty;
            /*float*/  get width() { return this.$getField(0, $.$spc.System.Single); }
            /*float*/  set width(value) { this.$setField(0, $.$spc.System.Single, value); }
            /*float*/  get height() { return this.$getField(4, $.$spc.System.Single); }
            /*float*/  set height(value) { this.$setField(4, $.$spc.System.Single, value); }
            $ctor$2(/*SizeF*/ size)
            {
                super.$ctor$1();
                {
                    this.width = size.width;
                    this.height = size.height;
                }
                return this;
            }
            $ctor$3(/*PointF*/ pt)
            {
                super.$ctor$1();
                {
                    this.width = pt.X;
                    this.height = pt.Y;
                }
                return this;
            }
            $ctor$4(/*Vector2*/ vector)
            {
                super.$ctor$1();
                {
                    this.width = vector.X;
                    this.height = vector.Y;
                }
                return this;
            }
            /*Vector2 */ ToVector2()
            {
                return new $.$spc.System.Numerics.Vector2().$ctor$3(this.width, this.height);
            }
            $ctor$5(/*float*/ width, /*float*/ height)
            {
                super.$ctor$1();
                {
                    this.width = width;
                    this.height = height;
                }
                return this;
            }
            static /*Vector2 */ op_Explicit(/*SizeF*/ size)
            {
                return size.ToVector2();
            }
            static /*SizeF */ op_Explicit$1(/*Vector2*/ vector)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$4(vector.Clone());
            }
            static /*SizeF */ op_Addition(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Add(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Subtraction(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return $.$sdp.System.Drawing.SizeF.Subtract(sz1.Clone(), sz2.Clone());
            }
            static /*SizeF */ op_Multiply(/*float*/ left, /*SizeF*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(right.Clone(), left);
            }
            static /*SizeF */ op_Multiply$1(/*SizeF*/ left, /*float*/ right)
            {
                return $.$sdp.System.Drawing.SizeF.Multiply(left.Clone(), right);
            }
            static /*SizeF */ op_Division(/*SizeF*/ left, /*float*/ right)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(left.width / right, left.height / right);
            }
            static /*bool */ op_Equality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return sz1.Width === sz2.Width && sz1.Height === sz2.Height;
            }
            static /*bool */ op_Inequality(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return !($.$sdp.System.Drawing.SizeF.op_Equality(sz1, sz2));
            }
            static /*PointF */ op_Explicit$2(/*SizeF*/ size)
            {
                return new $.$sdp.System.Drawing.PointF().$ctor$2(size.Width, size.Height);
            }
            /*bool */ get IsEmpty()
            {
                return this.width === 0 && this.height === 0;
            }
            /*float */ get Width()
            {
                return this.width;
            }
            /*float */ set Width(value)
            {
                this.width = value;
            }
            /*float */ get Height()
            {
                return this.height;
            }
            /*float */ set Height(value)
            {
                this.height = value;
            }
            static /*SizeF */ Add(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width + sz2.Width, sz1.Height + sz2.Height);
            }
            static /*SizeF */ Subtract(/*SizeF*/ sz1, /*SizeF*/ sz2)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(sz1.Width - sz2.Width, sz1.Height - sz2.Height);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$sdp.System.Drawing.SizeF) && this.Equals$2($.$cast(obj, $.$sdp.System.Drawing.SizeF));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$sdp.System.Drawing.SizeF.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SizeF*/ other)
            {
                return $.$sdp.System.Drawing.SizeF.op_Equality(this, other);
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$spc.System.Single, $.$spc.System.Single, this.Width, this.Height);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sdp.System.Drawing.SizeF.GetHashCode.apply(this, arguments); }
            /*PointF */ ToPointF()
            {
                return $.$sdp.System.Drawing.SizeF.op_Explicit$2(this);
            }
            /*Size */ ToSize()
            {
                return $.$sdp.System.Drawing.Size.Truncate(this);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return `{{Width=${this.width}, Height=${this.height}}}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sdp.System.Drawing.SizeF.ToString.apply(this, arguments); }
            static /*SizeF */ Multiply(/*SizeF*/ size, /*float*/ multiplier)
            {
                return new $.$sdp.System.Drawing.SizeF().$ctor$5(size.width * multiplier, size.height * multiplier);
            }
            //Generated interface implemetation for System.IEquatable<System.Drawing.SizeF>.Equals(System.Drawing.SizeF)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$6()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.width = this.width;
                copy.height = this.height;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.width = 0;
                this.height = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = $.$default($.$sdp.System.Drawing.SizeF);
                }
            }
            static $h = 902843;
            static $z = 8;
            static $f = 0b10000000000001010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":85900248763,"f":1},"n":"IsEmpty","d":902843,"h":81605281467,"f":1,"a":[{"t":65575,"c":17179934759,"a":[{"v":false,"t":262145}]}]},{"p":1114113,"g":{"r":0,"d":0,"h":94490183355,"f":1},"s":{"r":0,"d":0,"h":98785150651,"f":1},"n":"Width","d":902843,"h":90195216059,"f":1},{"p":1114113,"g":{"r":0,"d":0,"h":107375085243,"f":1},"s":{"r":0,"d":0,"h":111670052539,"f":1},"n":"Height","d":902843,"h":103080117947,"f":1}],"m":[{"r":70582273,"n":"ToVector2","d":902843,"h":30065673915,"f":1},{"r":902843,"p":[{"n":"sz1","p":902843},{"n":"sz2","p":902843}],"n":"Add","d":902843,"h":115965019835,"f":33},{"r":902843,"p":[{"n":"sz1","p":902843},{"n":"sz2","p":902843}],"n":"Subtract","d":902843,"h":120259987131,"f":33},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":902843,"h":124554954427,"f":32769},{"r":262145,"p":[{"n":"other","p":902843}],"n":"Equals","o":"@$2","d":902843,"h":128849921723,"f":1},{"r":655361,"n":"GetHashCode","d":902843,"h":133144889019,"f":32769},{"r":640699,"n":"ToPointF","d":902843,"h":137439856315,"f":1},{"r":837307,"n":"ToSize","d":902843,"h":141734823611,"f":1},{"r":1310721,"n":"ToString","d":902843,"h":146029790907,"f":32769},{"r":902843,"p":[{"n":"size","p":902843},{"n":"multiplier","p":1114113}],"n":"Multiply","d":902843,"h":150324758203,"f":34}],"l":[{"t":902843,"n":"Empty","d":902843,"h":4295870139,"f":33},{"t":1114113,"n":"width","d":902843,"h":8590837435,"f":2},{"t":1114113,"n":"height","d":902843,"h":12885804731,"f":2}],"c":[{"p":[{"n":"size","p":902843}],"n":".ctor","o":"$ctor$2","d":902843,"h":17180772027,"f":1},{"p":[{"n":"pt","p":640699}],"n":".ctor","o":"$ctor$3","d":902843,"h":21475739323,"f":1},{"p":[{"n":"vector","p":70582273}],"n":".ctor","o":"$ctor$4","d":902843,"h":25770706619,"f":1},{"p":[{"n":"width","p":1114113},{"n":"height","p":1114113}],"n":".ctor","o":"$ctor$5","d":902843,"h":34360641211,"f":1},{"n":".ctor","o":"$ctor$6","d":902843,"h":154619725499,"f":1}],"i":[$.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF).$h],"h":902843,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]},{"t":1496742,"c":17181365926,"a":[{"v":"System.Drawing.SizeFConverter, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$sdp.System.Drawing.SizeF) ]; }
            static get $fullName() { return `System.Drawing.SizeF`; }
        });
        
        $asm.$str("$sdp.System.Drawing.KnownColor", ($self) => class KnownColor extends $.$spc.System.Enum
        {
            static ActiveBorder = 1;
            static ActiveCaption = 2;
            static ActiveCaptionText = 3;
            static AppWorkspace = 4;
            static Control = 5;
            static ControlDark = 6;
            static ControlDarkDark = 7;
            static ControlLight = 8;
            static ControlLightLight = 9;
            static ControlText = 10;
            static Desktop = 11;
            static GrayText = 12;
            static Highlight = 13;
            static HighlightText = 14;
            static HotTrack = 15;
            static InactiveBorder = 16;
            static InactiveCaption = 17;
            static InactiveCaptionText = 18;
            static Info = 19;
            static InfoText = 20;
            static Menu = 21;
            static MenuText = 22;
            static ScrollBar = 23;
            static Window = 24;
            static WindowFrame = 25;
            static WindowText = 26;
            static Transparent = 27;
            static AliceBlue = 28;
            static AntiqueWhite = 29;
            static Aqua = 30;
            static Aquamarine = 31;
            static Azure = 32;
            static Beige = 33;
            static Bisque = 34;
            static Black = 35;
            static BlanchedAlmond = 36;
            static Blue = 37;
            static BlueViolet = 38;
            static Brown = 39;
            static BurlyWood = 40;
            static CadetBlue = 41;
            static Chartreuse = 42;
            static Chocolate = 43;
            static Coral = 44;
            static CornflowerBlue = 45;
            static Cornsilk = 46;
            static Crimson = 47;
            static Cyan = 48;
            static DarkBlue = 49;
            static DarkCyan = 50;
            static DarkGoldenrod = 51;
            static DarkGray = 52;
            static DarkGreen = 53;
            static DarkKhaki = 54;
            static DarkMagenta = 55;
            static DarkOliveGreen = 56;
            static DarkOrange = 57;
            static DarkOrchid = 58;
            static DarkRed = 59;
            static DarkSalmon = 60;
            static DarkSeaGreen = 61;
            static DarkSlateBlue = 62;
            static DarkSlateGray = 63;
            static DarkTurquoise = 64;
            static DarkViolet = 65;
            static DeepPink = 66;
            static DeepSkyBlue = 67;
            static DimGray = 68;
            static DodgerBlue = 69;
            static Firebrick = 70;
            static FloralWhite = 71;
            static ForestGreen = 72;
            static Fuchsia = 73;
            static Gainsboro = 74;
            static GhostWhite = 75;
            static Gold = 76;
            static Goldenrod = 77;
            static Gray = 78;
            static Green = 79;
            static GreenYellow = 80;
            static Honeydew = 81;
            static HotPink = 82;
            static IndianRed = 83;
            static Indigo = 84;
            static Ivory = 85;
            static Khaki = 86;
            static Lavender = 87;
            static LavenderBlush = 88;
            static LawnGreen = 89;
            static LemonChiffon = 90;
            static LightBlue = 91;
            static LightCoral = 92;
            static LightCyan = 93;
            static LightGoldenrodYellow = 94;
            static LightGray = 95;
            static LightGreen = 96;
            static LightPink = 97;
            static LightSalmon = 98;
            static LightSeaGreen = 99;
            static LightSkyBlue = 100;
            static LightSlateGray = 101;
            static LightSteelBlue = 102;
            static LightYellow = 103;
            static Lime = 104;
            static LimeGreen = 105;
            static Linen = 106;
            static Magenta = 107;
            static Maroon = 108;
            static MediumAquamarine = 109;
            static MediumBlue = 110;
            static MediumOrchid = 111;
            static MediumPurple = 112;
            static MediumSeaGreen = 113;
            static MediumSlateBlue = 114;
            static MediumSpringGreen = 115;
            static MediumTurquoise = 116;
            static MediumVioletRed = 117;
            static MidnightBlue = 118;
            static MintCream = 119;
            static MistyRose = 120;
            static Moccasin = 121;
            static NavajoWhite = 122;
            static Navy = 123;
            static OldLace = 124;
            static Olive = 125;
            static OliveDrab = 126;
            static Orange = 127;
            static OrangeRed = 128;
            static Orchid = 129;
            static PaleGoldenrod = 130;
            static PaleGreen = 131;
            static PaleTurquoise = 132;
            static PaleVioletRed = 133;
            static PapayaWhip = 134;
            static PeachPuff = 135;
            static Peru = 136;
            static Pink = 137;
            static Plum = 138;
            static PowderBlue = 139;
            static Purple = 140;
            static Red = 141;
            static RosyBrown = 142;
            static RoyalBlue = 143;
            static SaddleBrown = 144;
            static Salmon = 145;
            static SandyBrown = 146;
            static SeaGreen = 147;
            static SeaShell = 148;
            static Sienna = 149;
            static Silver = 150;
            static SkyBlue = 151;
            static SlateBlue = 152;
            static SlateGray = 153;
            static Snow = 154;
            static SpringGreen = 155;
            static SteelBlue = 156;
            static Tan = 157;
            static Teal = 158;
            static Thistle = 159;
            static Tomato = 160;
            static Turquoise = 161;
            static Violet = 162;
            static Wheat = 163;
            static White = 164;
            static WhiteSmoke = 165;
            static Yellow = 166;
            static YellowGreen = 167;
            static ButtonFace = 168;
            static ButtonHighlight = 169;
            static ButtonShadow = 170;
            static GradientActiveCaption = 171;
            static GradientInactiveCaption = 172;
            static MenuBar = 173;
            static MenuHighlight = 174;
            static RebeccaPurple = 175;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "ActiveBorder": 1n,
                    "ActiveCaption": 2n,
                    "ActiveCaptionText": 3n,
                    "AppWorkspace": 4n,
                    "Control": 5n,
                    "ControlDark": 6n,
                    "ControlDarkDark": 7n,
                    "ControlLight": 8n,
                    "ControlLightLight": 9n,
                    "ControlText": 10n,
                    "Desktop": 11n,
                    "GrayText": 12n,
                    "Highlight": 13n,
                    "HighlightText": 14n,
                    "HotTrack": 15n,
                    "InactiveBorder": 16n,
                    "InactiveCaption": 17n,
                    "InactiveCaptionText": 18n,
                    "Info": 19n,
                    "InfoText": 20n,
                    "Menu": 21n,
                    "MenuText": 22n,
                    "ScrollBar": 23n,
                    "Window": 24n,
                    "WindowFrame": 25n,
                    "WindowText": 26n,
                    "Transparent": 27n,
                    "AliceBlue": 28n,
                    "AntiqueWhite": 29n,
                    "Aqua": 30n,
                    "Aquamarine": 31n,
                    "Azure": 32n,
                    "Beige": 33n,
                    "Bisque": 34n,
                    "Black": 35n,
                    "BlanchedAlmond": 36n,
                    "Blue": 37n,
                    "BlueViolet": 38n,
                    "Brown": 39n,
                    "BurlyWood": 40n,
                    "CadetBlue": 41n,
                    "Chartreuse": 42n,
                    "Chocolate": 43n,
                    "Coral": 44n,
                    "CornflowerBlue": 45n,
                    "Cornsilk": 46n,
                    "Crimson": 47n,
                    "Cyan": 48n,
                    "DarkBlue": 49n,
                    "DarkCyan": 50n,
                    "DarkGoldenrod": 51n,
                    "DarkGray": 52n,
                    "DarkGreen": 53n,
                    "DarkKhaki": 54n,
                    "DarkMagenta": 55n,
                    "DarkOliveGreen": 56n,
                    "DarkOrange": 57n,
                    "DarkOrchid": 58n,
                    "DarkRed": 59n,
                    "DarkSalmon": 60n,
                    "DarkSeaGreen": 61n,
                    "DarkSlateBlue": 62n,
                    "DarkSlateGray": 63n,
                    "DarkTurquoise": 64n,
                    "DarkViolet": 65n,
                    "DeepPink": 66n,
                    "DeepSkyBlue": 67n,
                    "DimGray": 68n,
                    "DodgerBlue": 69n,
                    "Firebrick": 70n,
                    "FloralWhite": 71n,
                    "ForestGreen": 72n,
                    "Fuchsia": 73n,
                    "Gainsboro": 74n,
                    "GhostWhite": 75n,
                    "Gold": 76n,
                    "Goldenrod": 77n,
                    "Gray": 78n,
                    "Green": 79n,
                    "GreenYellow": 80n,
                    "Honeydew": 81n,
                    "HotPink": 82n,
                    "IndianRed": 83n,
                    "Indigo": 84n,
                    "Ivory": 85n,
                    "Khaki": 86n,
                    "Lavender": 87n,
                    "LavenderBlush": 88n,
                    "LawnGreen": 89n,
                    "LemonChiffon": 90n,
                    "LightBlue": 91n,
                    "LightCoral": 92n,
                    "LightCyan": 93n,
                    "LightGoldenrodYellow": 94n,
                    "LightGray": 95n,
                    "LightGreen": 96n,
                    "LightPink": 97n,
                    "LightSalmon": 98n,
                    "LightSeaGreen": 99n,
                    "LightSkyBlue": 100n,
                    "LightSlateGray": 101n,
                    "LightSteelBlue": 102n,
                    "LightYellow": 103n,
                    "Lime": 104n,
                    "LimeGreen": 105n,
                    "Linen": 106n,
                    "Magenta": 107n,
                    "Maroon": 108n,
                    "MediumAquamarine": 109n,
                    "MediumBlue": 110n,
                    "MediumOrchid": 111n,
                    "MediumPurple": 112n,
                    "MediumSeaGreen": 113n,
                    "MediumSlateBlue": 114n,
                    "MediumSpringGreen": 115n,
                    "MediumTurquoise": 116n,
                    "MediumVioletRed": 117n,
                    "MidnightBlue": 118n,
                    "MintCream": 119n,
                    "MistyRose": 120n,
                    "Moccasin": 121n,
                    "NavajoWhite": 122n,
                    "Navy": 123n,
                    "OldLace": 124n,
                    "Olive": 125n,
                    "OliveDrab": 126n,
                    "Orange": 127n,
                    "OrangeRed": 128n,
                    "Orchid": 129n,
                    "PaleGoldenrod": 130n,
                    "PaleGreen": 131n,
                    "PaleTurquoise": 132n,
                    "PaleVioletRed": 133n,
                    "PapayaWhip": 134n,
                    "PeachPuff": 135n,
                    "Peru": 136n,
                    "Pink": 137n,
                    "Plum": 138n,
                    "PowderBlue": 139n,
                    "Purple": 140n,
                    "Red": 141n,
                    "RosyBrown": 142n,
                    "RoyalBlue": 143n,
                    "SaddleBrown": 144n,
                    "Salmon": 145n,
                    "SandyBrown": 146n,
                    "SeaGreen": 147n,
                    "SeaShell": 148n,
                    "Sienna": 149n,
                    "Silver": 150n,
                    "SkyBlue": 151n,
                    "SlateBlue": 152n,
                    "SlateGray": 153n,
                    "Snow": 154n,
                    "SpringGreen": 155n,
                    "SteelBlue": 156n,
                    "Tan": 157n,
                    "Teal": 158n,
                    "Thistle": 159n,
                    "Tomato": 160n,
                    "Turquoise": 161n,
                    "Violet": 162n,
                    "Wheat": 163n,
                    "White": 164n,
                    "WhiteSmoke": 165n,
                    "Yellow": 166n,
                    "YellowGreen": 167n,
                    "ButtonFace": 168n,
                    "ButtonHighlight": 169n,
                    "ButtonShadow": 170n,
                    "GradientActiveCaption": 171n,
                    "GradientInactiveCaption": 172n,
                    "MenuBar": 173n,
                    "MenuHighlight": 174n,
                    "RebeccaPurple": 175n
                };
            }
            static $h = 378555;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":378555,"n":"ActiveBorder","d":378555,"h":4295345851,"f":33},{"t":378555,"n":"ActiveCaption","d":378555,"h":8590313147,"f":33},{"t":378555,"n":"ActiveCaptionText","d":378555,"h":12885280443,"f":33},{"t":378555,"n":"AppWorkspace","d":378555,"h":17180247739,"f":33},{"t":378555,"n":"Control","d":378555,"h":21475215035,"f":33},{"t":378555,"n":"ControlDark","d":378555,"h":25770182331,"f":33},{"t":378555,"n":"ControlDarkDark","d":378555,"h":30065149627,"f":33},{"t":378555,"n":"ControlLight","d":378555,"h":34360116923,"f":33},{"t":378555,"n":"ControlLightLight","d":378555,"h":38655084219,"f":33},{"t":378555,"n":"ControlText","d":378555,"h":42950051515,"f":33},{"t":378555,"n":"Desktop","d":378555,"h":47245018811,"f":33},{"t":378555,"n":"GrayText","d":378555,"h":51539986107,"f":33},{"t":378555,"n":"Highlight","d":378555,"h":55834953403,"f":33},{"t":378555,"n":"HighlightText","d":378555,"h":60129920699,"f":33},{"t":378555,"n":"HotTrack","d":378555,"h":64424887995,"f":33},{"t":378555,"n":"InactiveBorder","d":378555,"h":68719855291,"f":33},{"t":378555,"n":"InactiveCaption","d":378555,"h":73014822587,"f":33},{"t":378555,"n":"InactiveCaptionText","d":378555,"h":77309789883,"f":33},{"t":378555,"n":"Info","d":378555,"h":81604757179,"f":33},{"t":378555,"n":"InfoText","d":378555,"h":85899724475,"f":33},{"t":378555,"n":"Menu","d":378555,"h":90194691771,"f":33},{"t":378555,"n":"MenuText","d":378555,"h":94489659067,"f":33},{"t":378555,"n":"ScrollBar","d":378555,"h":98784626363,"f":33},{"t":378555,"n":"Window","d":378555,"h":103079593659,"f":33},{"t":378555,"n":"WindowFrame","d":378555,"h":107374560955,"f":33},{"t":378555,"n":"WindowText","d":378555,"h":111669528251,"f":33},{"t":378555,"n":"Transparent","d":378555,"h":115964495547,"f":33},{"t":378555,"n":"AliceBlue","d":378555,"h":120259462843,"f":33},{"t":378555,"n":"AntiqueWhite","d":378555,"h":124554430139,"f":33},{"t":378555,"n":"Aqua","d":378555,"h":128849397435,"f":33},{"t":378555,"n":"Aquamarine","d":378555,"h":133144364731,"f":33},{"t":378555,"n":"Azure","d":378555,"h":137439332027,"f":33},{"t":378555,"n":"Beige","d":378555,"h":141734299323,"f":33},{"t":378555,"n":"Bisque","d":378555,"h":146029266619,"f":33},{"t":378555,"n":"Black","d":378555,"h":150324233915,"f":33},{"t":378555,"n":"BlanchedAlmond","d":378555,"h":154619201211,"f":33},{"t":378555,"n":"Blue","d":378555,"h":158914168507,"f":33},{"t":378555,"n":"BlueViolet","d":378555,"h":163209135803,"f":33},{"t":378555,"n":"Brown","d":378555,"h":167504103099,"f":33},{"t":378555,"n":"BurlyWood","d":378555,"h":171799070395,"f":33},{"t":378555,"n":"CadetBlue","d":378555,"h":176094037691,"f":33},{"t":378555,"n":"Chartreuse","d":378555,"h":180389004987,"f":33},{"t":378555,"n":"Chocolate","d":378555,"h":184683972283,"f":33},{"t":378555,"n":"Coral","d":378555,"h":188978939579,"f":33},{"t":378555,"n":"CornflowerBlue","d":378555,"h":193273906875,"f":33},{"t":378555,"n":"Cornsilk","d":378555,"h":197568874171,"f":33},{"t":378555,"n":"Crimson","d":378555,"h":201863841467,"f":33},{"t":378555,"n":"Cyan","d":378555,"h":206158808763,"f":33},{"t":378555,"n":"DarkBlue","d":378555,"h":210453776059,"f":33},{"t":378555,"n":"DarkCyan","d":378555,"h":214748743355,"f":33},{"t":378555,"n":"DarkGoldenrod","d":378555,"h":219043710651,"f":33},{"t":378555,"n":"DarkGray","d":378555,"h":223338677947,"f":33},{"t":378555,"n":"DarkGreen","d":378555,"h":227633645243,"f":33},{"t":378555,"n":"DarkKhaki","d":378555,"h":231928612539,"f":33},{"t":378555,"n":"DarkMagenta","d":378555,"h":236223579835,"f":33},{"t":378555,"n":"DarkOliveGreen","d":378555,"h":240518547131,"f":33},{"t":378555,"n":"DarkOrange","d":378555,"h":244813514427,"f":33},{"t":378555,"n":"DarkOrchid","d":378555,"h":249108481723,"f":33},{"t":378555,"n":"DarkRed","d":378555,"h":253403449019,"f":33},{"t":378555,"n":"DarkSalmon","d":378555,"h":257698416315,"f":33},{"t":378555,"n":"DarkSeaGreen","d":378555,"h":261993383611,"f":33},{"t":378555,"n":"DarkSlateBlue","d":378555,"h":266288350907,"f":33},{"t":378555,"n":"DarkSlateGray","d":378555,"h":270583318203,"f":33},{"t":378555,"n":"DarkTurquoise","d":378555,"h":274878285499,"f":33},{"t":378555,"n":"DarkViolet","d":378555,"h":279173252795,"f":33},{"t":378555,"n":"DeepPink","d":378555,"h":283468220091,"f":33},{"t":378555,"n":"DeepSkyBlue","d":378555,"h":287763187387,"f":33},{"t":378555,"n":"DimGray","d":378555,"h":292058154683,"f":33},{"t":378555,"n":"DodgerBlue","d":378555,"h":296353121979,"f":33},{"t":378555,"n":"Firebrick","d":378555,"h":300648089275,"f":33},{"t":378555,"n":"FloralWhite","d":378555,"h":304943056571,"f":33},{"t":378555,"n":"ForestGreen","d":378555,"h":309238023867,"f":33},{"t":378555,"n":"Fuchsia","d":378555,"h":313532991163,"f":33},{"t":378555,"n":"Gainsboro","d":378555,"h":317827958459,"f":33},{"t":378555,"n":"GhostWhite","d":378555,"h":322122925755,"f":33},{"t":378555,"n":"Gold","d":378555,"h":326417893051,"f":33},{"t":378555,"n":"Goldenrod","d":378555,"h":330712860347,"f":33},{"t":378555,"n":"Gray","d":378555,"h":335007827643,"f":33},{"t":378555,"n":"Green","d":378555,"h":339302794939,"f":33},{"t":378555,"n":"GreenYellow","d":378555,"h":343597762235,"f":33},{"t":378555,"n":"Honeydew","d":378555,"h":347892729531,"f":33},{"t":378555,"n":"HotPink","d":378555,"h":352187696827,"f":33},{"t":378555,"n":"IndianRed","d":378555,"h":356482664123,"f":33},{"t":378555,"n":"Indigo","d":378555,"h":360777631419,"f":33},{"t":378555,"n":"Ivory","d":378555,"h":365072598715,"f":33},{"t":378555,"n":"Khaki","d":378555,"h":369367566011,"f":33},{"t":378555,"n":"Lavender","d":378555,"h":373662533307,"f":33},{"t":378555,"n":"LavenderBlush","d":378555,"h":377957500603,"f":33},{"t":378555,"n":"LawnGreen","d":378555,"h":382252467899,"f":33},{"t":378555,"n":"LemonChiffon","d":378555,"h":386547435195,"f":33},{"t":378555,"n":"LightBlue","d":378555,"h":390842402491,"f":33},{"t":378555,"n":"LightCoral","d":378555,"h":395137369787,"f":33},{"t":378555,"n":"LightCyan","d":378555,"h":399432337083,"f":33},{"t":378555,"n":"LightGoldenrodYellow","d":378555,"h":403727304379,"f":33},{"t":378555,"n":"LightGray","d":378555,"h":408022271675,"f":33},{"t":378555,"n":"LightGreen","d":378555,"h":412317238971,"f":33},{"t":378555,"n":"LightPink","d":378555,"h":416612206267,"f":33},{"t":378555,"n":"LightSalmon","d":378555,"h":420907173563,"f":33},{"t":378555,"n":"LightSeaGreen","d":378555,"h":425202140859,"f":33},{"t":378555,"n":"LightSkyBlue","d":378555,"h":429497108155,"f":33},{"t":378555,"n":"LightSlateGray","d":378555,"h":433792075451,"f":33},{"t":378555,"n":"LightSteelBlue","d":378555,"h":438087042747,"f":33},{"t":378555,"n":"LightYellow","d":378555,"h":442382010043,"f":33},{"t":378555,"n":"Lime","d":378555,"h":446676977339,"f":33},{"t":378555,"n":"LimeGreen","d":378555,"h":450971944635,"f":33},{"t":378555,"n":"Linen","d":378555,"h":455266911931,"f":33},{"t":378555,"n":"Magenta","d":378555,"h":459561879227,"f":33},{"t":378555,"n":"Maroon","d":378555,"h":463856846523,"f":33},{"t":378555,"n":"MediumAquamarine","d":378555,"h":468151813819,"f":33},{"t":378555,"n":"MediumBlue","d":378555,"h":472446781115,"f":33},{"t":378555,"n":"MediumOrchid","d":378555,"h":476741748411,"f":33},{"t":378555,"n":"MediumPurple","d":378555,"h":481036715707,"f":33},{"t":378555,"n":"MediumSeaGreen","d":378555,"h":485331683003,"f":33},{"t":378555,"n":"MediumSlateBlue","d":378555,"h":489626650299,"f":33},{"t":378555,"n":"MediumSpringGreen","d":378555,"h":493921617595,"f":33},{"t":378555,"n":"MediumTurquoise","d":378555,"h":498216584891,"f":33},{"t":378555,"n":"MediumVioletRed","d":378555,"h":502511552187,"f":33},{"t":378555,"n":"MidnightBlue","d":378555,"h":506806519483,"f":33},{"t":378555,"n":"MintCream","d":378555,"h":511101486779,"f":33},{"t":378555,"n":"MistyRose","d":378555,"h":515396454075,"f":33},{"t":378555,"n":"Moccasin","d":378555,"h":519691421371,"f":33},{"t":378555,"n":"NavajoWhite","d":378555,"h":523986388667,"f":33},{"t":378555,"n":"Navy","d":378555,"h":528281355963,"f":33},{"t":378555,"n":"OldLace","d":378555,"h":532576323259,"f":33},{"t":378555,"n":"Olive","d":378555,"h":536871290555,"f":33},{"t":378555,"n":"OliveDrab","d":378555,"h":541166257851,"f":33},{"t":378555,"n":"Orange","d":378555,"h":545461225147,"f":33},{"t":378555,"n":"OrangeRed","d":378555,"h":549756192443,"f":33},{"t":378555,"n":"Orchid","d":378555,"h":554051159739,"f":33},{"t":378555,"n":"PaleGoldenrod","d":378555,"h":558346127035,"f":33},{"t":378555,"n":"PaleGreen","d":378555,"h":562641094331,"f":33},{"t":378555,"n":"PaleTurquoise","d":378555,"h":566936061627,"f":33},{"t":378555,"n":"PaleVioletRed","d":378555,"h":571231028923,"f":33},{"t":378555,"n":"PapayaWhip","d":378555,"h":575525996219,"f":33},{"t":378555,"n":"PeachPuff","d":378555,"h":579820963515,"f":33},{"t":378555,"n":"Peru","d":378555,"h":584115930811,"f":33},{"t":378555,"n":"Pink","d":378555,"h":588410898107,"f":33},{"t":378555,"n":"Plum","d":378555,"h":592705865403,"f":33},{"t":378555,"n":"PowderBlue","d":378555,"h":597000832699,"f":33},{"t":378555,"n":"Purple","d":378555,"h":601295799995,"f":33},{"t":378555,"n":"Red","d":378555,"h":605590767291,"f":33},{"t":378555,"n":"RosyBrown","d":378555,"h":609885734587,"f":33},{"t":378555,"n":"RoyalBlue","d":378555,"h":614180701883,"f":33},{"t":378555,"n":"SaddleBrown","d":378555,"h":618475669179,"f":33},{"t":378555,"n":"Salmon","d":378555,"h":622770636475,"f":33},{"t":378555,"n":"SandyBrown","d":378555,"h":627065603771,"f":33},{"t":378555,"n":"SeaGreen","d":378555,"h":631360571067,"f":33},{"t":378555,"n":"SeaShell","d":378555,"h":635655538363,"f":33},{"t":378555,"n":"Sienna","d":378555,"h":639950505659,"f":33},{"t":378555,"n":"Silver","d":378555,"h":644245472955,"f":33},{"t":378555,"n":"SkyBlue","d":378555,"h":648540440251,"f":33},{"t":378555,"n":"SlateBlue","d":378555,"h":652835407547,"f":33},{"t":378555,"n":"SlateGray","d":378555,"h":657130374843,"f":33},{"t":378555,"n":"Snow","d":378555,"h":661425342139,"f":33},{"t":378555,"n":"SpringGreen","d":378555,"h":665720309435,"f":33},{"t":378555,"n":"SteelBlue","d":378555,"h":670015276731,"f":33},{"t":378555,"n":"Tan","d":378555,"h":674310244027,"f":33},{"t":378555,"n":"Teal","d":378555,"h":678605211323,"f":33},{"t":378555,"n":"Thistle","d":378555,"h":682900178619,"f":33},{"t":378555,"n":"Tomato","d":378555,"h":687195145915,"f":33},{"t":378555,"n":"Turquoise","d":378555,"h":691490113211,"f":33},{"t":378555,"n":"Violet","d":378555,"h":695785080507,"f":33},{"t":378555,"n":"Wheat","d":378555,"h":700080047803,"f":33},{"t":378555,"n":"White","d":378555,"h":704375015099,"f":33},{"t":378555,"n":"WhiteSmoke","d":378555,"h":708669982395,"f":33},{"t":378555,"n":"Yellow","d":378555,"h":712964949691,"f":33},{"t":378555,"n":"YellowGreen","d":378555,"h":717259916987,"f":33},{"t":378555,"n":"ButtonFace","d":378555,"h":721554884283,"f":33},{"t":378555,"n":"ButtonHighlight","d":378555,"h":725849851579,"f":33},{"t":378555,"n":"ButtonShadow","d":378555,"h":730144818875,"f":33},{"t":378555,"n":"GradientActiveCaption","d":378555,"h":734439786171,"f":33},{"t":378555,"n":"GradientInactiveCaption","d":378555,"h":738734753467,"f":33},{"t":378555,"n":"MenuBar","d":378555,"h":743029720763,"f":33},{"t":378555,"n":"MenuHighlight","d":378555,"h":747324688059,"f":33},{"t":378555,"n":"RebeccaPurple","d":378555,"h":751619655355,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":378555,"h":755914622651,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":378555,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Drawing.KnownColor`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Runtime.InteropServices", "NetJs.System.ComponentModel.Primitives"))